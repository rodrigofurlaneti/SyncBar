import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/finance/ReportsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getSalesReport } from "/src/features/finance/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { dayOfWeekLabel, formatBRL } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
function currentMonthValue() {
  const now = /* @__PURE__ */ new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}
function Bar({ value, max, label, sub }) {
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 3 }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", fontSize: "0.85rem" }, children: [
      /* @__PURE__ */ jsxDEV("span", { children: label }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--ink-dim)" }, children: sub }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { background: "var(--bg-press)", borderRadius: 999, height: 10, overflow: "hidden" }, children: /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          width: `${max <= 0 ? 0 : Math.max(2, value / max * 100)}%`,
          height: "100%",
          background: "var(--amber)",
          borderRadius: 999
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
        lineNumber: 40,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
      lineNumber: 39,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
}
_c = Bar;
export function ReportsPage() {
  _s();
  const { branchId } = useAuthStore();
  const [monthValue, setMonthValue] = useState(currentMonthValue());
  const [yearStr, monthStr] = monthValue.split("-");
  const year = Number(yearStr);
  const month = Number(monthStr);
  const reportQuery = useQuery({
    queryKey: ["report", branchId, year, month],
    queryFn: () => getSalesReport(branchId, year, month),
    enabled: Number.isFinite(year) && Number.isFinite(month)
  });
  const report = reportQuery.data;
  const maxProduct = Math.max(1, ...(report?.topProducts ?? []).map((p) => p.revenue));
  const maxWeekday = Math.max(1, ...(report?.revenueByWeekday ?? []).map((d) => d.revenue));
  const maxHour = Math.max(1, ...(report?.revenueByHour ?? []).map((h) => h.revenue));
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "center", gap: 14, marginBottom: 16, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Relatórios" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
        lineNumber: 74,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
        lineNumber: 75,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "month", value: monthValue, onChange: (e) => setMonthValue(e.target.value), style: { width: 190 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
        lineNumber: 76,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
      lineNumber: 73,
      columnNumber: 7
    }, this),
    reportQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: reportQuery.error, what: "o relatório" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
      lineNumber: 79,
      columnNumber: 31
    }, this),
    report && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rise rise-1", style: { display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", marginBottom: 16 }, children: [
        { label: "Receita", value: formatBRL(report.revenue), tone: "var(--amber)" },
        { label: `Vendas`, value: String(report.salesCount), tone: "var(--ink)" },
        { label: "Ticket médio", value: formatBRL(report.averageTicket), tone: "var(--ink)" },
        { label: "Taxa de serviço", value: formatBRL(report.serviceFeeTotal), tone: "var(--ok)" },
        { label: "Itens cancelados", value: String(report.cancelledItemsCount), tone: report.cancelledItemsCount > 0 ? "var(--danger)" : "var(--ok)" }
      ].map(
        (card) => /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: "14px 18px", display: "grid", gap: 4 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontFamily: "var(--font-cond)", textTransform: "uppercase", letterSpacing: "0.08em", fontSize: "0.78rem", color: "var(--ink-faint)" }, children: card.label }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 92,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mono-num display", style: { fontSize: "1.6rem", color: card.tone }, children: card.value }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 95,
            columnNumber: 17
          }, this)
        ] }, card.label, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
          lineNumber: 91,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
        lineNumber: 83,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rise rise-2", style: { display: "grid", gap: 14, gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 18, display: "grid", gap: 10, alignContent: "start" }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Top produtos" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 102,
            columnNumber: 15
          }, this),
          report.topProducts.map(
            (p) => /* @__PURE__ */ jsxDEV(
              Bar,
              {
                value: p.revenue,
                max: maxProduct,
                label: p.productName,
                sub: `${p.quantity} un · ${formatBRL(p.revenue)}`
              },
              p.productId,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
                lineNumber: 104,
                columnNumber: 13
              },
              this
            )
          ),
          report.topProducts.length === 0 && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "Sem vendas no mês." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 107,
            columnNumber: 51
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
          lineNumber: 101,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 18, display: "grid", gap: 10, alignContent: "start" }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Vendas por funcionário" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 111,
            columnNumber: 15
          }, this),
          report.salesByEmployee.map(
            (e) => /* @__PURE__ */ jsxDEV(
              Bar,
              {
                value: e.revenue,
                max: Math.max(1, report.salesByEmployee[0]?.revenue ?? 1),
                label: e.employeeName,
                sub: `${e.salesCount} vendas · ${formatBRL(e.revenue)} · serviço ${formatBRL(e.serviceFee)}`
              },
              e.employeeId,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
                lineNumber: 113,
                columnNumber: 13
              },
              this
            )
          ),
          report.salesByEmployee.length === 0 && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "Sem vendas no mês." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 117,
            columnNumber: 55
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
          lineNumber: 110,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 18, display: "grid", gap: 10, alignContent: "start" }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Receita por dia da semana" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 121,
            columnNumber: 15
          }, this),
          [1, 2, 3, 4, 5, 6, 0].map((d) => {
            const row = report.revenueByWeekday.find((w) => w.dayOfWeek === d);
            return /* @__PURE__ */ jsxDEV(
              Bar,
              {
                value: row?.revenue ?? 0,
                max: maxWeekday,
                label: dayOfWeekLabel[d],
                sub: `${row?.salesCount ?? 0} vendas · ${formatBRL(row?.revenue ?? 0)}`
              },
              d,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
                lineNumber: 125,
                columnNumber: 17
              },
              this
            );
          })
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
          lineNumber: 120,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 18, display: "grid", gap: 10, alignContent: "start" }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Horários de pico" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 132,
            columnNumber: 15
          }, this),
          report.revenueByHour.map(
            (h) => /* @__PURE__ */ jsxDEV(
              Bar,
              {
                value: h.revenue,
                max: maxHour,
                label: `${String(h.hour).padStart(2, "0")}h`,
                sub: formatBRL(h.revenue)
              },
              h.hour,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
                lineNumber: 134,
                columnNumber: 13
              },
              this
            )
          ),
          report.revenueByHour.length === 0 && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "Sem vendas no mês." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 137,
            columnNumber: 53
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
          lineNumber: 131,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
        lineNumber: 100,
        columnNumber: 11
      }, this),
      report.cancelledItems.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket rise rise-3", style: { marginTop: 14 }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem", color: "var(--danger)" }, children: [
          "Cancelamentos (",
          report.cancelledItemsCount,
          ")"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
          lineNumber: 144,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
          lineNumber: 143,
          columnNumber: 15
        }, this),
        report.cancelledItems.map(
          (item, index) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              item.quantity,
              " × ",
              item.productName,
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)", marginLeft: 8 }, children: new Date(item.cancelledAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
                lineNumber: 152,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
              lineNumber: 150,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { color: item.cancelledBy ? "var(--ink-dim)" : "var(--danger)", fontSize: "0.85rem" }, children: item.cancelledBy ? `por ${item.cancelledBy}` : "sem responsável" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
              lineNumber: 156,
              columnNumber: 19
            }, this)
          ] }, index, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
            lineNumber: 149,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
        lineNumber: 142,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
      lineNumber: 82,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx",
    lineNumber: 72,
    columnNumber: 5
  }, this);
}
_s(ReportsPage, "Ze071h8ScWB6LvAENfyC8suIO5g=", false, function() {
  return [useAuthStore, useQuery];
});
_c2 = ReportsPage;
var _c, _c2;
$RefreshReg$(_c, "Bar");
$RefreshReg$(_c2, "ReportsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ReportsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JRLFNBOENBLFVBOUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhCUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCQyxpQkFBaUI7QUFDMUMsU0FBU0Msa0JBQWtCO0FBRTNCLFNBQVNDLG9CQUE0QjtBQUNuQyxRQUFNQyxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFNBQU8sR0FBR0QsSUFBSUUsWUFBWSxDQUFDLElBQUlDLE9BQU9ILElBQUlJLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDNUU7QUFFQSxTQUFTQyxJQUFJLEVBQUVDLE9BQU9DLEtBQUtDLE9BQU9DLElBQWdFLEdBQUc7QUFDbkcsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSwyQkFBQyxTQUFJLE9BQU8sRUFBRUQsU0FBUyxRQUFRRSxnQkFBZ0IsaUJBQWlCQyxVQUFVLFVBQVUsR0FDbEY7QUFBQSw2QkFBQyxVQUFNTCxtQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWE7QUFBQSxNQUNiLHVCQUFDLFVBQUssV0FBVSxZQUFXLE9BQU8sRUFBRU0sT0FBTyxpQkFBaUIsR0FBSUwsaUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0U7QUFBQSxTQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFTSxZQUFZLG1CQUFtQkMsY0FBYyxLQUFLQyxRQUFRLElBQUlDLFVBQVUsU0FBUyxHQUM3RjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFVBQ0xDLE9BQU8sR0FBR1osT0FBTyxJQUFJLElBQUlhLEtBQUtiLElBQUksR0FBSUQsUUFBUUMsTUFBTyxHQUFHLENBQUM7QUFBQSxVQUN6RFUsUUFBUTtBQUFBLFVBQ1JGLFlBQVk7QUFBQSxVQUNaQyxjQUFjO0FBQUEsUUFDaEI7QUFBQTtBQUFBLE1BTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUksS0FQTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxPQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQTtBQUVKO0FBQUNLLEtBbkJRaEI7QUFxQkYsZ0JBQVNpQixjQUFjO0FBQUFDLEtBQUE7QUFDNUIsUUFBTSxFQUFFQyxTQUFTLElBQUk5QixhQUFhO0FBQ2xDLFFBQU0sQ0FBQytCLFlBQVlDLGFBQWEsSUFBSW5DLFNBQVNPLGtCQUFrQixDQUFDO0FBQ2hFLFFBQU0sQ0FBQzZCLFNBQVNDLFFBQVEsSUFBSUgsV0FBV0ksTUFBTSxHQUFHO0FBQ2hELFFBQU1DLE9BQU9DLE9BQU9KLE9BQU87QUFDM0IsUUFBTUssUUFBUUQsT0FBT0gsUUFBUTtBQUU3QixRQUFNSyxjQUFjekMsU0FBUztBQUFBLElBQzNCMEMsVUFBVSxDQUFDLFVBQVVWLFVBQVVNLE1BQU1FLEtBQUs7QUFBQSxJQUMxQ0csU0FBU0EsTUFBTTFDLGVBQWUrQixVQUFVTSxNQUFNRSxLQUFLO0FBQUEsSUFDbkRJLFNBQVNMLE9BQU9NLFNBQVNQLElBQUksS0FBS0MsT0FBT00sU0FBU0wsS0FBSztBQUFBLEVBQ3pELENBQUM7QUFFRCxRQUFNTSxTQUFTTCxZQUFZTTtBQUMzQixRQUFNQyxhQUFhcEIsS0FBS2IsSUFBSSxHQUFHLElBQUkrQixRQUFRRyxlQUFlLElBQUlDLElBQUksQ0FBQ0MsTUFBTUEsRUFBRUMsT0FBTyxDQUFDO0FBQ25GLFFBQU1DLGFBQWF6QixLQUFLYixJQUFJLEdBQUcsSUFBSStCLFFBQVFRLG9CQUFvQixJQUFJSixJQUFJLENBQUNLLE1BQU1BLEVBQUVILE9BQU8sQ0FBQztBQUN4RixRQUFNSSxVQUFVNUIsS0FBS2IsSUFBSSxHQUFHLElBQUkrQixRQUFRVyxpQkFBaUIsSUFBSVAsSUFBSSxDQUFDUSxNQUFNQSxFQUFFTixPQUFPLENBQUM7QUFFbEYsU0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRU8sU0FBUyxJQUFJQyxVQUFVLE1BQU1DLFFBQVEsU0FBUyxHQUMzRDtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRTNDLFNBQVMsUUFBUTRDLFlBQVksVUFBVTNDLEtBQUssSUFBSTRDLGNBQWMsSUFBSUMsVUFBVSxPQUFPLEdBQ2hIO0FBQUEsNkJBQUMsUUFBRyxXQUFVLFdBQVUsT0FBTyxFQUFFM0MsVUFBVSxTQUFTLEdBQUcsMEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUU7QUFBQSxNQUNqRSx1QkFBQyxVQUFLLE9BQU8sRUFBRTRDLE1BQU0sRUFBRSxLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsV0FBTSxNQUFLLFNBQVEsT0FBT2hDLFlBQVksVUFBVSxDQUFDaUMsTUFBTWhDLGNBQWNnQyxFQUFFQyxPQUFPckQsS0FBSyxHQUFHLE9BQU8sRUFBRWEsT0FBTyxJQUFJLEtBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkc7QUFBQSxTQUgvRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUVDYyxZQUFZMkIsV0FBVyx1QkFBQyxjQUFXLE9BQU8zQixZQUFZNEIsT0FBTyxNQUFLLGlCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdEO0FBQUEsSUFFL0V2QixVQUNDLG1DQUNFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGVBQWMsT0FBTyxFQUFFNUIsU0FBUyxRQUFRQyxLQUFLLElBQUltRCxxQkFBcUIsd0NBQXdDUCxjQUFjLEdBQUcsR0FDM0k7QUFBQSxRQUNDLEVBQUUvQyxPQUFPLFdBQVdGLE9BQU9WLFVBQVUwQyxPQUFPTSxPQUFPLEdBQUdtQixNQUFNLGVBQWU7QUFBQSxRQUMzRSxFQUFFdkQsT0FBTyxVQUFVRixPQUFPSixPQUFPb0MsT0FBTzBCLFVBQVUsR0FBR0QsTUFBTSxhQUFhO0FBQUEsUUFDeEUsRUFBRXZELE9BQU8sZ0JBQWdCRixPQUFPVixVQUFVMEMsT0FBTzJCLGFBQWEsR0FBR0YsTUFBTSxhQUFhO0FBQUEsUUFDcEYsRUFBRXZELE9BQU8sbUJBQW1CRixPQUFPVixVQUFVMEMsT0FBTzRCLGVBQWUsR0FBR0gsTUFBTSxZQUFZO0FBQUEsUUFDeEYsRUFBRXZELE9BQU8sb0JBQW9CRixPQUFPSixPQUFPb0MsT0FBTzZCLG1CQUFtQixHQUFHSixNQUFNekIsT0FBTzZCLHNCQUFzQixJQUFJLGtCQUFrQixZQUFZO0FBQUEsTUFBQyxFQUM5SXpCO0FBQUFBLFFBQUksQ0FBQzBCLFNBQ0wsdUJBQUMsU0FBSSxXQUFVLFVBQTBCLE9BQU8sRUFBRWpCLFNBQVMsYUFBYXpDLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQzlGO0FBQUEsaUNBQUMsVUFBSyxPQUFPLEVBQUUwRCxZQUFZLG9CQUFvQkMsZUFBZSxhQUFhQyxlQUFlLFVBQVUxRCxVQUFVLFdBQVdDLE9BQU8sbUJBQW1CLEdBQ2hKc0QsZUFBSzVELFNBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQixPQUFPLEVBQUVLLFVBQVUsVUFBVUMsT0FBT3NELEtBQUtMLEtBQUssR0FBSUssZUFBSzlELFNBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdHO0FBQUEsYUFKckU4RCxLQUFLNUQsT0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsTUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGVBQWMsT0FBTyxFQUFFRSxTQUFTLFFBQVFDLEtBQUssSUFBSW1ELHFCQUFxQix1Q0FBdUMsR0FDMUg7QUFBQSwrQkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVYLFNBQVMsSUFBSXpDLFNBQVMsUUFBUUMsS0FBSyxJQUFJNkQsY0FBYyxRQUFRLEdBQzVGO0FBQUEsaUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFM0QsVUFBVSxTQUFTLEdBQUcsNEJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsVUFDcEV5QixPQUFPRyxZQUFZQztBQUFBQSxZQUFJLENBQUNDLE1BQ3ZCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQXNCLE9BQU9BLEVBQUVDO0FBQUFBLGdCQUFTLEtBQUtKO0FBQUFBLGdCQUM1QyxPQUFPRyxFQUFFOEI7QUFBQUEsZ0JBQWEsS0FBSyxHQUFHOUIsRUFBRStCLFFBQVEsU0FBUzlFLFVBQVUrQyxFQUFFQyxPQUFPLENBQUM7QUFBQTtBQUFBLGNBRDdERCxFQUFFZ0M7QUFBQUEsY0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQzBFO0FBQUEsVUFDM0U7QUFBQSxVQUNBckMsT0FBT0csWUFBWW1DLFdBQVcsS0FBSyx1QkFBQyxVQUFLLE9BQU8sRUFBRTlELE9BQU8sbUJBQW1CLEdBQUcsa0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsYUFOcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVxQyxTQUFTLElBQUl6QyxTQUFTLFFBQVFDLEtBQUssSUFBSTZELGNBQWMsUUFBUSxHQUM1RjtBQUFBLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRTNELFVBQVUsU0FBUyxHQUFHLHNDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQzlFeUIsT0FBT3VDLGdCQUFnQm5DO0FBQUFBLFlBQUksQ0FBQ2dCLE1BQzNCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQXVCLE9BQU9BLEVBQUVkO0FBQUFBLGdCQUFTLEtBQUt4QixLQUFLYixJQUFJLEdBQUcrQixPQUFPdUMsZ0JBQWdCLENBQUMsR0FBR2pDLFdBQVcsQ0FBQztBQUFBLGdCQUNoRyxPQUFPYyxFQUFFb0I7QUFBQUEsZ0JBQ1QsS0FBSyxHQUFHcEIsRUFBRU0sVUFBVSxhQUFhcEUsVUFBVThELEVBQUVkLE9BQU8sQ0FBQyxjQUFjaEQsVUFBVThELEVBQUVxQixVQUFVLENBQUM7QUFBQTtBQUFBLGNBRmxGckIsRUFBRXNCO0FBQUFBLGNBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUUrRjtBQUFBLFVBQ2hHO0FBQUEsVUFDQTFDLE9BQU91QyxnQkFBZ0JELFdBQVcsS0FBSyx1QkFBQyxVQUFLLE9BQU8sRUFBRTlELE9BQU8sbUJBQW1CLEdBQUcsa0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsYUFQeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVxQyxTQUFTLElBQUl6QyxTQUFTLFFBQVFDLEtBQUssSUFBSTZELGNBQWMsUUFBUSxHQUM1RjtBQUFBLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRTNELFVBQVUsU0FBUyxHQUFHLHlDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQ2pGLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxFQUFFNkIsSUFBSSxDQUFDSyxNQUFNO0FBQ2hDLGtCQUFNa0MsTUFBTTNDLE9BQU9RLGlCQUFpQm9DLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRUMsY0FBY3JDLENBQUM7QUFDakUsbUJBQ0U7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBWSxPQUFPa0MsS0FBS3JDLFdBQVc7QUFBQSxnQkFBRyxLQUFLQztBQUFBQSxnQkFDMUMsT0FBT2xELGVBQWVvRCxDQUFDO0FBQUEsZ0JBQUcsS0FBSyxHQUFHa0MsS0FBS2pCLGNBQWMsQ0FBQyxhQUFhcEUsVUFBVXFGLEtBQUtyQyxXQUFXLENBQUMsQ0FBQztBQUFBO0FBQUEsY0FEdkZHO0FBQUFBLGNBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNvRztBQUFBLFVBRXhHLENBQUM7QUFBQSxhQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFSSxTQUFTLElBQUl6QyxTQUFTLFFBQVFDLEtBQUssSUFBSTZELGNBQWMsUUFBUSxHQUM1RjtBQUFBLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRTNELFVBQVUsU0FBUyxHQUFHLGdDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3hFeUIsT0FBT1csY0FBY1A7QUFBQUEsWUFBSSxDQUFDUSxNQUN6QjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUFpQixPQUFPQSxFQUFFTjtBQUFBQSxnQkFBUyxLQUFLSTtBQUFBQSxnQkFDdkMsT0FBTyxHQUFHOUMsT0FBT2dELEVBQUVtQyxJQUFJLEVBQUVqRixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQUEsZ0JBQUssS0FBS1IsVUFBVXNELEVBQUVOLE9BQU87QUFBQTtBQUFBLGNBRDlETSxFQUFFbUM7QUFBQUEsY0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQzBFO0FBQUEsVUFDM0U7QUFBQSxVQUNBL0MsT0FBT1csY0FBYzJCLFdBQVcsS0FBSyx1QkFBQyxVQUFLLE9BQU8sRUFBRTlELE9BQU8sbUJBQW1CLEdBQUcsa0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsYUFOdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVDQTtBQUFBLE1BRUN3QixPQUFPZ0QsZUFBZVYsU0FBUyxLQUM5Qix1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRVcsV0FBVyxHQUFHLEdBQ3pEO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGVBQ2IsaUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFMUUsVUFBVSxVQUFVQyxPQUFPLGdCQUFnQixHQUFFO0FBQUE7QUFBQSxVQUM5RHdCLE9BQU82QjtBQUFBQSxVQUFvQjtBQUFBLGFBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBQ0M3QixPQUFPZ0QsZUFBZTVDO0FBQUFBLFVBQUksQ0FBQzhDLE1BQU1DLFVBQ2hDLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsVUFDRUQ7QUFBQUEsbUJBQUtkO0FBQUFBLGNBQVM7QUFBQSxjQUFJYyxLQUFLZjtBQUFBQSxjQUN4Qix1QkFBQyxVQUFLLE9BQU8sRUFBRTVELFVBQVUsVUFBVUMsT0FBTyxvQkFBb0I0RSxZQUFZLEVBQUUsR0FDekUsY0FBSTFGLEtBQUt3RixLQUFLRyxXQUFXLEVBQUVDLGVBQWUsU0FBUyxFQUFFQyxLQUFLLFdBQVc3RCxPQUFPLFdBQVdxRCxNQUFNLFdBQVdTLFFBQVEsVUFBVSxDQUFDLEtBRDlIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRWhGLE9BQU8wRSxLQUFLTyxjQUFjLG1CQUFtQixpQkFBaUJsRixVQUFVLFVBQVUsR0FDOUYyRSxlQUFLTyxjQUFjLE9BQU9QLEtBQUtPLFdBQVcsS0FBSyxxQkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVCtCTixPQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsUUFDRDtBQUFBLFdBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxTQS9FSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUZBO0FBQUEsT0EzRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZGQTtBQUVKO0FBQUNsRSxHQWxIZUQsYUFBVztBQUFBLFVBQ0o1QixjQU1ERixRQUFRO0FBQUE7QUFBQSxNQVBkOEI7QUFBVyxJQUFBRCxJQUFBMkU7QUFBQSxhQUFBM0UsSUFBQTtBQUFBLGFBQUEyRSxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VRdWVyeSIsImdldFNhbGVzUmVwb3J0IiwidXNlQXV0aFN0b3JlIiwiZGF5T2ZXZWVrTGFiZWwiLCJmb3JtYXRCUkwiLCJRdWVyeUVycm9yIiwiY3VycmVudE1vbnRoVmFsdWUiLCJub3ciLCJEYXRlIiwiZ2V0RnVsbFllYXIiLCJTdHJpbmciLCJnZXRNb250aCIsInBhZFN0YXJ0IiwiQmFyIiwidmFsdWUiLCJtYXgiLCJsYWJlbCIsInN1YiIsImRpc3BsYXkiLCJnYXAiLCJqdXN0aWZ5Q29udGVudCIsImZvbnRTaXplIiwiY29sb3IiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyUmFkaXVzIiwiaGVpZ2h0Iiwib3ZlcmZsb3ciLCJ3aWR0aCIsIk1hdGgiLCJfYyIsIlJlcG9ydHNQYWdlIiwiX3MiLCJicmFuY2hJZCIsIm1vbnRoVmFsdWUiLCJzZXRNb250aFZhbHVlIiwieWVhclN0ciIsIm1vbnRoU3RyIiwic3BsaXQiLCJ5ZWFyIiwiTnVtYmVyIiwibW9udGgiLCJyZXBvcnRRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImVuYWJsZWQiLCJpc0Zpbml0ZSIsInJlcG9ydCIsImRhdGEiLCJtYXhQcm9kdWN0IiwidG9wUHJvZHVjdHMiLCJtYXAiLCJwIiwicmV2ZW51ZSIsIm1heFdlZWtkYXkiLCJyZXZlbnVlQnlXZWVrZGF5IiwiZCIsIm1heEhvdXIiLCJyZXZlbnVlQnlIb3VyIiwiaCIsInBhZGRpbmciLCJtYXhXaWR0aCIsIm1hcmdpbiIsImFsaWduSXRlbXMiLCJtYXJnaW5Cb3R0b20iLCJmbGV4V3JhcCIsImZsZXgiLCJlIiwidGFyZ2V0IiwiaXNFcnJvciIsImVycm9yIiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsInRvbmUiLCJzYWxlc0NvdW50IiwiYXZlcmFnZVRpY2tldCIsInNlcnZpY2VGZWVUb3RhbCIsImNhbmNlbGxlZEl0ZW1zQ291bnQiLCJjYXJkIiwiZm9udEZhbWlseSIsInRleHRUcmFuc2Zvcm0iLCJsZXR0ZXJTcGFjaW5nIiwiYWxpZ25Db250ZW50IiwicHJvZHVjdE5hbWUiLCJxdWFudGl0eSIsInByb2R1Y3RJZCIsImxlbmd0aCIsInNhbGVzQnlFbXBsb3llZSIsImVtcGxveWVlTmFtZSIsInNlcnZpY2VGZWUiLCJlbXBsb3llZUlkIiwicm93IiwiZmluZCIsInciLCJkYXlPZldlZWsiLCJob3VyIiwiY2FuY2VsbGVkSXRlbXMiLCJtYXJnaW5Ub3AiLCJpdGVtIiwiaW5kZXgiLCJtYXJnaW5MZWZ0IiwiY2FuY2VsbGVkQXQiLCJ0b0xvY2FsZVN0cmluZyIsImRheSIsIm1pbnV0ZSIsImNhbmNlbGxlZEJ5IiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlcG9ydHNQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XG5pbXBvcnQgeyBnZXRTYWxlc1JlcG9ydCB9IGZyb20gXCIuL2FwaVwiO1xuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcbmltcG9ydCB7IGRheU9mV2Vla0xhYmVsLCBmb3JtYXRCUkwgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xuXG5mdW5jdGlvbiBjdXJyZW50TW9udGhWYWx1ZSgpOiBzdHJpbmcge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICByZXR1cm4gYCR7bm93LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKG5vdy5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XG59XG5cbmZ1bmN0aW9uIEJhcih7IHZhbHVlLCBtYXgsIGxhYmVsLCBzdWIgfTogeyB2YWx1ZTogbnVtYmVyOyBtYXg6IG51bWJlcjsgbGFiZWw6IHN0cmluZzsgc3ViOiBzdHJpbmcgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMyB9fT5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxuICAgICAgICA8c3Bhbj57bGFiZWx9PC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+e3N1Yn08L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogXCJ2YXIoLS1iZy1wcmVzcylcIiwgYm9yZGVyUmFkaXVzOiA5OTksIGhlaWdodDogMTAsIG92ZXJmbG93OiBcImhpZGRlblwiIH19PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIHdpZHRoOiBgJHttYXggPD0gMCA/IDAgOiBNYXRoLm1heCgyLCAodmFsdWUgLyBtYXgpICogMTAwKX0lYCxcbiAgICAgICAgICAgIGhlaWdodDogXCIxMDAlXCIsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLWFtYmVyKVwiLFxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA5OTksXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUmVwb3J0c1BhZ2UoKSB7XG4gIGNvbnN0IHsgYnJhbmNoSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xuICBjb25zdCBbbW9udGhWYWx1ZSwgc2V0TW9udGhWYWx1ZV0gPSB1c2VTdGF0ZShjdXJyZW50TW9udGhWYWx1ZSgpKTtcbiAgY29uc3QgW3llYXJTdHIsIG1vbnRoU3RyXSA9IG1vbnRoVmFsdWUuc3BsaXQoXCItXCIpO1xuICBjb25zdCB5ZWFyID0gTnVtYmVyKHllYXJTdHIpO1xuICBjb25zdCBtb250aCA9IE51bWJlcihtb250aFN0cik7XG5cbiAgY29uc3QgcmVwb3J0UXVlcnkgPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFtcInJlcG9ydFwiLCBicmFuY2hJZCwgeWVhciwgbW9udGhdLFxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldFNhbGVzUmVwb3J0KGJyYW5jaElkLCB5ZWFyLCBtb250aCksXG4gICAgZW5hYmxlZDogTnVtYmVyLmlzRmluaXRlKHllYXIpICYmIE51bWJlci5pc0Zpbml0ZShtb250aCksXG4gIH0pO1xuXG4gIGNvbnN0IHJlcG9ydCA9IHJlcG9ydFF1ZXJ5LmRhdGE7XG4gIGNvbnN0IG1heFByb2R1Y3QgPSBNYXRoLm1heCgxLCAuLi4ocmVwb3J0Py50b3BQcm9kdWN0cyA/PyBbXSkubWFwKChwKSA9PiBwLnJldmVudWUpKTtcbiAgY29uc3QgbWF4V2Vla2RheSA9IE1hdGgubWF4KDEsIC4uLihyZXBvcnQ/LnJldmVudWVCeVdlZWtkYXkgPz8gW10pLm1hcCgoZCkgPT4gZC5yZXZlbnVlKSk7XG4gIGNvbnN0IG1heEhvdXIgPSBNYXRoLm1heCgxLCAuLi4ocmVwb3J0Py5yZXZlbnVlQnlIb3VyID8/IFtdKS5tYXAoKGgpID0+IGgucmV2ZW51ZSkpO1xuXG4gIHJldHVybiAoXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMTAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2VcIiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiAxNCwgbWFyZ2luQm90dG9tOiAxNiwgZmxleFdyYXA6IFwid3JhcFwiIH19PlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuN3JlbVwiIH19PlJlbGF0w7NyaW9zPC9oMj5cbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSB9fSAvPlxuICAgICAgICA8aW5wdXQgdHlwZT1cIm1vbnRoXCIgdmFsdWU9e21vbnRoVmFsdWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TW9udGhWYWx1ZShlLnRhcmdldC52YWx1ZSl9IHN0eWxlPXt7IHdpZHRoOiAxOTAgfX0gLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7cmVwb3J0UXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17cmVwb3J0UXVlcnkuZXJyb3J9IHdoYXQ9XCJvIHJlbGF0w7NyaW9cIiAvPn1cblxuICAgICAge3JlcG9ydCAmJiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyLCBncmlkVGVtcGxhdGVDb2x1bW5zOiBcInJlcGVhdChhdXRvLWZpdCwgbWlubWF4KDE3MHB4LCAxZnIpKVwiLCBtYXJnaW5Cb3R0b206IDE2IH19PlxuICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgeyBsYWJlbDogXCJSZWNlaXRhXCIsIHZhbHVlOiBmb3JtYXRCUkwocmVwb3J0LnJldmVudWUpLCB0b25lOiBcInZhcigtLWFtYmVyKVwiIH0sXG4gICAgICAgICAgICAgIHsgbGFiZWw6IGBWZW5kYXNgLCB2YWx1ZTogU3RyaW5nKHJlcG9ydC5zYWxlc0NvdW50KSwgdG9uZTogXCJ2YXIoLS1pbmspXCIgfSxcbiAgICAgICAgICAgICAgeyBsYWJlbDogXCJUaWNrZXQgbcOpZGlvXCIsIHZhbHVlOiBmb3JtYXRCUkwocmVwb3J0LmF2ZXJhZ2VUaWNrZXQpLCB0b25lOiBcInZhcigtLWluaylcIiB9LFxuICAgICAgICAgICAgICB7IGxhYmVsOiBcIlRheGEgZGUgc2VydmnDp29cIiwgdmFsdWU6IGZvcm1hdEJSTChyZXBvcnQuc2VydmljZUZlZVRvdGFsKSwgdG9uZTogXCJ2YXIoLS1vaylcIiB9LFxuICAgICAgICAgICAgICB7IGxhYmVsOiBcIkl0ZW5zIGNhbmNlbGFkb3NcIiwgdmFsdWU6IFN0cmluZyhyZXBvcnQuY2FuY2VsbGVkSXRlbXNDb3VudCksIHRvbmU6IHJlcG9ydC5jYW5jZWxsZWRJdGVtc0NvdW50ID4gMCA/IFwidmFyKC0tZGFuZ2VyKVwiIDogXCJ2YXIoLS1vaylcIiB9LFxuICAgICAgICAgICAgXS5tYXAoKGNhcmQpID0+IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIiBrZXk9e2NhcmQubGFiZWx9IHN0eWxlPXt7IHBhZGRpbmc6IFwiMTRweCAxOHB4XCIsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udEZhbWlseTogXCJ2YXIoLS1mb250LWNvbmQpXCIsIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIsIGxldHRlclNwYWNpbmc6IFwiMC4wOGVtXCIsIGZvbnRTaXplOiBcIjAuNzhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxuICAgICAgICAgICAgICAgICAge2NhcmQubGFiZWx9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtIGRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjZyZW1cIiwgY29sb3I6IGNhcmQudG9uZSB9fT57Y2FyZC52YWx1ZX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2UgcmlzZS0yXCIgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwicmVwZWF0KGF1dG8tZml0LCBtaW5tYXgoMzIwcHgsIDFmcikpXCIgfX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE4LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCwgYWxpZ25Db250ZW50OiBcInN0YXJ0XCIgfX0+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5Ub3AgcHJvZHV0b3M8L3NwYW4+XG4gICAgICAgICAgICAgIHtyZXBvcnQudG9wUHJvZHVjdHMubWFwKChwKSA9PiAoXG4gICAgICAgICAgICAgICAgPEJhciBrZXk9e3AucHJvZHVjdElkfSB2YWx1ZT17cC5yZXZlbnVlfSBtYXg9e21heFByb2R1Y3R9XG4gICAgICAgICAgICAgICAgICBsYWJlbD17cC5wcm9kdWN0TmFtZX0gc3ViPXtgJHtwLnF1YW50aXR5fSB1biDCtyAke2Zvcm1hdEJSTChwLnJldmVudWUpfWB9IC8+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICB7cmVwb3J0LnRvcFByb2R1Y3RzLmxlbmd0aCA9PT0gMCAmJiA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+U2VtIHZlbmRhcyBubyBtw6pzLjwvc3Bhbj59XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIiBzdHlsZT17eyBwYWRkaW5nOiAxOCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAsIGFsaWduQ29udGVudDogXCJzdGFydFwiIH19PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+VmVuZGFzIHBvciBmdW5jaW9uw6FyaW88L3NwYW4+XG4gICAgICAgICAgICAgIHtyZXBvcnQuc2FsZXNCeUVtcGxveWVlLm1hcCgoZSkgPT4gKFxuICAgICAgICAgICAgICAgIDxCYXIga2V5PXtlLmVtcGxveWVlSWR9IHZhbHVlPXtlLnJldmVudWV9IG1heD17TWF0aC5tYXgoMSwgcmVwb3J0LnNhbGVzQnlFbXBsb3llZVswXT8ucmV2ZW51ZSA/PyAxKX1cbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtlLmVtcGxveWVlTmFtZX1cbiAgICAgICAgICAgICAgICAgIHN1Yj17YCR7ZS5zYWxlc0NvdW50fSB2ZW5kYXMgwrcgJHtmb3JtYXRCUkwoZS5yZXZlbnVlKX0gwrcgc2VydmnDp28gJHtmb3JtYXRCUkwoZS5zZXJ2aWNlRmVlKX1gfSAvPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAge3JlcG9ydC5zYWxlc0J5RW1wbG95ZWUubGVuZ3RoID09PSAwICYmIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5TZW0gdmVuZGFzIG5vIG3DqnMuPC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE4LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCwgYWxpZ25Db250ZW50OiBcInN0YXJ0XCIgfX0+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5SZWNlaXRhIHBvciBkaWEgZGEgc2VtYW5hPC9zcGFuPlxuICAgICAgICAgICAgICB7WzEsIDIsIDMsIDQsIDUsIDYsIDBdLm1hcCgoZCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJvdyA9IHJlcG9ydC5yZXZlbnVlQnlXZWVrZGF5LmZpbmQoKHcpID0+IHcuZGF5T2ZXZWVrID09PSBkKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPEJhciBrZXk9e2R9IHZhbHVlPXtyb3c/LnJldmVudWUgPz8gMH0gbWF4PXttYXhXZWVrZGF5fVxuICAgICAgICAgICAgICAgICAgICBsYWJlbD17ZGF5T2ZXZWVrTGFiZWxbZF19IHN1Yj17YCR7cm93Py5zYWxlc0NvdW50ID8/IDB9IHZlbmRhcyDCtyAke2Zvcm1hdEJSTChyb3c/LnJldmVudWUgPz8gMCl9YH0gLz5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE4LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCwgYWxpZ25Db250ZW50OiBcInN0YXJ0XCIgfX0+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5Ib3LDoXJpb3MgZGUgcGljbzwvc3Bhbj5cbiAgICAgICAgICAgICAge3JlcG9ydC5yZXZlbnVlQnlIb3VyLm1hcCgoaCkgPT4gKFxuICAgICAgICAgICAgICAgIDxCYXIga2V5PXtoLmhvdXJ9IHZhbHVlPXtoLnJldmVudWV9IG1heD17bWF4SG91cn1cbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtgJHtTdHJpbmcoaC5ob3VyKS5wYWRTdGFydCgyLCBcIjBcIil9aGB9IHN1Yj17Zm9ybWF0QlJMKGgucmV2ZW51ZSl9IC8+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICB7cmVwb3J0LnJldmVudWVCeUhvdXIubGVuZ3RoID09PSAwICYmIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5TZW0gdmVuZGFzIG5vIG3DqnMuPC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge3JlcG9ydC5jYW5jZWxsZWRJdGVtcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0IHJpc2UgcmlzZS0zXCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAxNCB9fT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtaGVhZFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiwgY29sb3I6IFwidmFyKC0tZGFuZ2VyKVwiIH19PlxuICAgICAgICAgICAgICAgICAgQ2FuY2VsYW1lbnRvcyAoe3JlcG9ydC5jYW5jZWxsZWRJdGVtc0NvdW50fSlcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICB7cmVwb3J0LmNhbmNlbGxlZEl0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBrZXk9e2luZGV4fT5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5xdWFudGl0eX0gw5cge2l0ZW0ucHJvZHVjdE5hbWV9XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIG1hcmdpbkxlZnQ6IDggfX0+XG4gICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGl0ZW0uY2FuY2VsbGVkQXQpLnRvTG9jYWxlU3RyaW5nKFwicHQtQlJcIiwgeyBkYXk6IFwiMi1kaWdpdFwiLCBtb250aDogXCIyLWRpZ2l0XCIsIGhvdXI6IFwiMi1kaWdpdFwiLCBtaW51dGU6IFwiMi1kaWdpdFwiIH0pfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogaXRlbS5jYW5jZWxsZWRCeSA/IFwidmFyKC0taW5rLWRpbSlcIiA6IFwidmFyKC0tZGFuZ2VyKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLmNhbmNlbGxlZEJ5ID8gYHBvciAke2l0ZW0uY2FuY2VsbGVkQnl9YCA6IFwic2VtIHJlc3BvbnPDoXZlbFwifVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8L21haW4+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvZmluYW5jZS9SZXBvcnRzUGFnZS50c3gifQ==