import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ErrorBoundary.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const Component = __vite__cjsImport2_react["Component"];
export class ErrorBoundary extends Component {
  state = { error: null };
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    console.error("[ErrorBoundary]", error, info.componentStack);
  }
  render() {
    if (this.state.error) {
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          role: "alert",
          style: {
            display: "grid",
            placeItems: "center",
            minHeight: "100vh",
            padding: 24,
            textAlign: "center",
            gap: 14,
            background: "var(--bg)",
            color: "var(--ink)"
          },
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "2rem", color: "var(--danger)" }, children: "Algo deu errado" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/ErrorBoundary.tsx",
              lineNumber: 49,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)", maxWidth: 420, margin: 0 }, children: "A tela travou por um erro inesperado. Recarregar a página costuma resolver — se persistir, avise o suporte." }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/ErrorBoundary.tsx",
              lineNumber: 52,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: () => window.location.reload(), children: "Recarregar" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/ErrorBoundary.tsx",
              lineNumber: 56,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/ErrorBoundary.tsx",
          lineNumber: 36,
          columnNumber: 9
        },
        this
      );
    }
    return this.props.children;
  }
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/ErrorBoundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/ErrorBoundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNVOzs7QUE3Q1YsU0FBU0EsaUJBQWlCO0FBaUJuQixhQUFNQyxzQkFBc0JELFVBQXdCO0FBQUEsRUFDekRFLFFBQWUsRUFBRUMsT0FBTyxLQUFLO0FBQUEsRUFFN0IsT0FBT0MseUJBQXlCRCxPQUFxQjtBQUNuRCxXQUFPLEVBQUVBLE1BQU07QUFBQSxFQUNqQjtBQUFBLEVBRUFFLGtCQUFrQkYsT0FBY0csTUFBaUI7QUFFL0NDLFlBQVFKLE1BQU0sbUJBQW1CQSxPQUFPRyxLQUFLRSxjQUFjO0FBQUEsRUFDN0Q7QUFBQSxFQUVBQyxTQUFTO0FBQ1AsUUFBSSxLQUFLUCxNQUFNQyxPQUFPO0FBQ3BCLGFBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU87QUFBQSxZQUNMTyxTQUFTO0FBQUEsWUFDVEMsWUFBWTtBQUFBLFlBQ1pDLFdBQVc7QUFBQSxZQUNYQyxTQUFTO0FBQUEsWUFDVEMsV0FBVztBQUFBLFlBQ1hDLEtBQUs7QUFBQSxZQUNMQyxZQUFZO0FBQUEsWUFDWkMsT0FBTztBQUFBLFVBQ1Q7QUFBQSxVQUVBO0FBQUEsbUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFQyxVQUFVLFFBQVFELE9BQU8sZ0JBQWdCLEdBQUcsK0JBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsT0FBTyxFQUFFQSxPQUFPLGtCQUFrQkUsVUFBVSxLQUFLQyxRQUFRLEVBQUUsR0FBRywySEFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxlQUFjLFNBQVMsTUFBTUMsT0FBT0MsU0FBU0MsT0FBTyxHQUFHLDBCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQTtBQUFBLFFBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXVCQTtBQUFBLElBRUo7QUFDQSxXQUFPLEtBQUtDLE1BQU1DO0FBQUFBLEVBQ3BCO0FBQ0YiLCJuYW1lcyI6WyJDb21wb25lbnQiLCJFcnJvckJvdW5kYXJ5Iiwic3RhdGUiLCJlcnJvciIsImdldERlcml2ZWRTdGF0ZUZyb21FcnJvciIsImNvbXBvbmVudERpZENhdGNoIiwiaW5mbyIsImNvbnNvbGUiLCJjb21wb25lbnRTdGFjayIsInJlbmRlciIsImRpc3BsYXkiLCJwbGFjZUl0ZW1zIiwibWluSGVpZ2h0IiwicGFkZGluZyIsInRleHRBbGlnbiIsImdhcCIsImJhY2tncm91bmQiLCJjb2xvciIsImZvbnRTaXplIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJ3aW5kb3ciLCJsb2NhdGlvbiIsInJlbG9hZCIsInByb3BzIiwiY2hpbGRyZW4iXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRXJyb3JCb3VuZGFyeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB0eXBlIHsgRXJyb3JJbmZvLCBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcclxufVxyXG5cclxuaW50ZXJmYWNlIFN0YXRlIHtcclxuICBlcnJvcjogRXJyb3IgfCBudWxsO1xyXG59XHJcblxyXG4vKipcclxuICogUmVkZSBkZSBzZWd1cmFuw6dhIHBhcmEgZXJyb3MgZGUgcmVuZGVyIG7Do28gdHJhdGFkb3MuIFNlbSBpc3NvLCB1bSBlcnJvXHJcbiAqIGVtIHF1YWxxdWVyIGNvbXBvbmVudGUgKGV4LjogYWNlc3NvIGEgcHJvcHJpZWRhZGUgZGUgdW0gZGFkbyBxdWUgYWluZGFcclxuICogbsOjbyBjaGVnb3UpIGRlcnJ1YmEgYSDDoXJ2b3JlIGludGVpcmEgZG8gUmVhY3QgZSBkZWl4YSB1bWEgdGVsYSBicmFuY2Eg4oCUXHJcbiAqIHDDqXNzaW1vIG51bSBQRFYgZW0gdXNvIGF0aXZvIG5vIGJhbGPDo28uXHJcbiAqL1xyXG5leHBvcnQgY2xhc3MgRXJyb3JCb3VuZGFyeSBleHRlbmRzIENvbXBvbmVudDxQcm9wcywgU3RhdGU+IHtcclxuICBzdGF0ZTogU3RhdGUgPSB7IGVycm9yOiBudWxsIH07XHJcblxyXG4gIHN0YXRpYyBnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IoZXJyb3I6IEVycm9yKTogU3RhdGUge1xyXG4gICAgcmV0dXJuIHsgZXJyb3IgfTtcclxuICB9XHJcblxyXG4gIGNvbXBvbmVudERpZENhdGNoKGVycm9yOiBFcnJvciwgaW5mbzogRXJyb3JJbmZvKSB7XHJcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29uc29sZVxyXG4gICAgY29uc29sZS5lcnJvcihcIltFcnJvckJvdW5kYXJ5XVwiLCBlcnJvciwgaW5mby5jb21wb25lbnRTdGFjayk7XHJcbiAgfVxyXG5cclxuICByZW5kZXIoKSB7XHJcbiAgICBpZiAodGhpcy5zdGF0ZS5lcnJvcikge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBcImdyaWRcIixcclxuICAgICAgICAgICAgcGxhY2VJdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgbWluSGVpZ2h0OiBcIjEwMHZoXCIsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDI0LFxyXG4gICAgICAgICAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgIGdhcDogMTQsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwidmFyKC0tYmcpXCIsXHJcbiAgICAgICAgICAgIGNvbG9yOiBcInZhcigtLWluaylcIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjJyZW1cIiwgY29sb3I6IFwidmFyKC0tZGFuZ2VyKVwiIH19PlxyXG4gICAgICAgICAgICBBbGdvIGRldSBlcnJhZG9cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIG1heFdpZHRoOiA0MjAsIG1hcmdpbjogMCB9fT5cclxuICAgICAgICAgICAgQSB0ZWxhIHRyYXZvdSBwb3IgdW0gZXJybyBpbmVzcGVyYWRvLiBSZWNhcnJlZ2FyIGEgcMOhZ2luYSBjb3N0dW1hIHJlc29sdmVyIOKAlCBzZVxyXG4gICAgICAgICAgICBwZXJzaXN0aXIsIGF2aXNlIG8gc3Vwb3J0ZS5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgb25DbGljaz17KCkgPT4gd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpfT5cclxuICAgICAgICAgICAgUmVjYXJyZWdhclxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5wcm9wcy5jaGlsZHJlbjtcclxuICB9XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvRXJyb3JCb3VuZGFyeS50c3gifQ==