import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/modals/TransferItemModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { api } from "/src/lib/apiClient.ts";
export function TransferItemModal({
  mode = "table",
  myTables = [],
  comandas = [],
  comandaOrders = [],
  ordersByTableId,
  allActiveOrders,
  employeeId,
  onClose,
  onSuccess,
  onError
}) {
  _s();
  const [transferType, setTransferType] = useState(mode);
  const [sourceId, setSourceId] = useState("");
  const [targetId, setTargetId] = useState("");
  const [transferMode, setTransferMode] = useState("single");
  const [selectedItemIds, setSelectedItemIds] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isTransferring, setIsTransferring] = useState(false);
  const effectiveOrdersByTableId = useMemo(() => {
    if (ordersByTableId && ordersByTableId.size > 0) return ordersByTableId;
    const map = /* @__PURE__ */ new Map();
    for (const order of allActiveOrders) {
      if (order.diningTableId !== null) map.set(order.diningTableId, order);
    }
    return map;
  }, [ordersByTableId, allActiveOrders]);
  const sourceOrder = useMemo(() => {
    if (!sourceId) return null;
    const idNum = Number(sourceId);
    if (transferType === "table") {
      return effectiveOrdersByTableId.get(idNum) || allActiveOrders.find((o) => o.diningTableId === idNum) || null;
    } else {
      return allActiveOrders.find((o) => o.comandaId === idNum) || null;
    }
  }, [allActiveOrders, effectiveOrdersByTableId, sourceId, transferType]);
  const productIds = useMemo(() => {
    if (!sourceOrder) return [];
    return Array.from(new Set(sourceOrder.items.map((i) => i.productId)));
  }, [sourceOrder]);
  const productQueries = useQuery({
    queryKey: ["products-details", productIds],
    queryFn: async () => {
      const promises = productIds.map(async (id) => {
        try {
          return await api(`/api/products/${id}`);
        } catch {
          return null;
        }
      });
      const results = await Promise.all(promises);
      const map = /* @__PURE__ */ new Map();
      results.forEach((prod) => {
        if (prod) map.set(prod.id, prod.name);
      });
      return map;
    },
    enabled: productIds.length > 0
  });
  const productsMap = productQueries.data ?? /* @__PURE__ */ new Map();
  const availableItems = useMemo(() => {
    if (!sourceOrder) return [];
    return sourceOrder.items.filter((item) => {
      if (item.orderItemStatusId === 6) return false;
      if (!searchTerm) return true;
      const pId = item.productId || item.ProductId;
      const pName = productsMap.get(pId) || "";
      return pName.toLowerCase().includes(searchTerm.toLowerCase());
    });
  }, [sourceOrder, productsMap, searchTerm]);
  const handleToggleItem = (itemId) => {
    if (isTransferring) return;
    if (transferMode === "single") {
      setSelectedItemIds([itemId]);
    } else {
      setSelectedItemIds(
        (prev) => prev.includes(itemId) ? prev.filter((id) => id !== itemId) : [...prev, itemId]
      );
    }
  };
  const handleSelectAll = () => {
    if (isTransferring) return;
    if (selectedItemIds.length === availableItems.length) {
      setSelectedItemIds([]);
    } else {
      setSelectedItemIds(availableItems.map((i) => i.id));
    }
  };
  const handleTypeChange = (newType) => {
    if (isTransferring) return;
    setTransferType(newType);
    setSourceId("");
    setTargetId("");
    setSelectedItemIds([]);
    setSearchTerm("");
    setTransferMode("single");
  };
  const handleExecuteTransfer = async (e) => {
    e.preventDefault();
    if (isTransferring) return;
    if (!sourceId || !targetId || selectedItemIds.length === 0 || !sourceOrder) {
      return onError("Preencha a origem, o destino e selecione ao menos um item.");
    }
    const targetIdNum = Number(targetId);
    const targetOrder = transferType === "table" ? effectiveOrdersByTableId.get(targetIdNum) || allActiveOrders.find((o) => o.diningTableId === targetIdNum) : allActiveOrders.find((o) => o.comandaId === targetIdNum);
    if (!targetOrder) {
      const destinoTipo = transferType === "table" ? "mesa" : "comanda";
      return onError(`A ${destinoTipo} de destino precisa ter um pedido aberto para receber o(s) item(ns).`);
    }
    setIsTransferring(true);
    try {
      const endpoint = transferType === "table" ? "/api/orders/items/transfer-batch" : "/api/orders/comanda-items/transfer-batch";
      const payload = transferType === "table" ? {
        sourceCustomerOrderId: sourceOrder.id,
        targetCustomerOrderId: targetOrder.id,
        customerOrderItemIds: selectedItemIds,
        sourceDiningTableId: Number(sourceId),
        targetDiningTableId: targetIdNum,
        actorEmployeeId: employeeId ?? 1
      } : {
        sourceCustomerOrderId: sourceOrder.id,
        targetCustomerOrderId: targetOrder.id,
        customerOrderItemIds: selectedItemIds,
        sourceComandaId: Number(sourceId),
        targetComandaId: targetIdNum,
        actorEmployeeId: employeeId ?? 1
      };
      await api(endpoint, {
        method: "PUT",
        body: JSON.stringify(payload)
      });
      onSuccess(`${selectedItemIds.length} item(ns) transferido(s) com sucesso!`);
      onClose();
    } catch (err) {
      onError(err?.message || "Erro ao realizar transferência.");
      setIsTransferring(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      role: "dialog",
      "aria-modal": "true",
      onMouseDown: (e) => {
        if (e.target === e.currentTarget && !isTransferring) onClose();
      },
      style: {
        position: "fixed",
        inset: 0,
        backgroundColor: "rgba(0, 0, 0, 0.75)",
        backdropFilter: "blur(4px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 99999,
        padding: "16px",
        boxSizing: "border-box"
      },
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          style: {
            width: "100%",
            maxWidth: "480px",
            maxHeight: "90vh",
            backgroundColor: "#1e293b",
            color: "#f8fafc",
            borderRadius: "16px",
            padding: "24px",
            boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.7)",
            display: "flex",
            flexDirection: "column",
            boxSizing: "border-box",
            overflowY: "auto",
            border: "1px solid #334155"
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "12px", marginBottom: "16px", borderBottom: "1px solid #334155", paddingBottom: "12px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "1.1rem", fontWeight: "700" }, children: "🔀 Transferir Itens" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                  lineNumber: 246,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: onClose,
                    disabled: isTransferring,
                    "aria-label": "Fechar",
                    style: { background: "none", border: "none", cursor: isTransferring ? "not-allowed" : "pointer", color: "#94a3b8", fontSize: "1.2rem", padding: "4px" },
                    children: "✕"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 247,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                lineNumber: 245,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { role: "tablist", style: { display: "flex", background: "#0f172a", padding: "4px", borderRadius: "8px", border: "1px solid #334155" }, children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    role: "tab",
                    "aria-selected": transferType === "table",
                    disabled: isTransferring,
                    onClick: () => handleTypeChange("table"),
                    style: {
                      flex: 1,
                      padding: "8px",
                      borderRadius: "6px",
                      border: "none",
                      background: transferType === "table" ? "#3b82f6" : "transparent",
                      color: "#fff",
                      fontWeight: "600",
                      fontSize: "0.85rem",
                      cursor: isTransferring ? "not-allowed" : "pointer",
                      transition: "background 0.2s"
                    },
                    children: "🍽️ Mesas"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 259,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    role: "tab",
                    "aria-selected": transferType === "comanda",
                    disabled: isTransferring,
                    onClick: () => handleTypeChange("comanda"),
                    style: {
                      flex: 1,
                      padding: "8px",
                      borderRadius: "6px",
                      border: "none",
                      background: transferType === "comanda" ? "#3b82f6" : "transparent",
                      color: "#fff",
                      fontWeight: "600",
                      fontSize: "0.85rem",
                      cursor: isTransferring ? "not-allowed" : "pointer",
                      transition: "background 0.2s"
                    },
                    children: "📋 Comandas"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 280,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                lineNumber: 258,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
              lineNumber: 244,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("form", { onSubmit: handleExecuteTransfer, style: { display: "flex", flexDirection: "column", gap: "14px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "6px" }, children: [
                /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.80rem", fontWeight: "600", color: "#94a3b8" }, children: transferType === "table" ? "Mesa de Origem (Com pedido)" : "Comanda de Origem (Com pedido)" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                  lineNumber: 308,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    value: sourceId,
                    disabled: isTransferring,
                    onChange: (e) => {
                      setSourceId(e.target.value);
                      setSelectedItemIds([]);
                    },
                    style: { padding: "10px", borderRadius: "8px", border: "1px solid #475569", backgroundColor: "#0f172a", color: "#f8fafc", fontSize: "0.9rem" },
                    required: true,
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione a origem..." }, void 0, false, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                        lineNumber: 321,
                        columnNumber: 29
                      }, this),
                      transferType === "table" ? myTables.filter((t) => effectiveOrdersByTableId.has(t.id)).map(
                        (t) => /* @__PURE__ */ jsxDEV("option", { value: t.id, children: [
                          "Mesa ",
                          t.number
                        ] }, t.id, true, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                          lineNumber: 324,
                          columnNumber: 15
                        }, this)
                      ) : comandas.filter((c) => comandaOrders.some((o) => o.comandaId === c.id)).map(
                        (c) => /* @__PURE__ */ jsxDEV("option", { value: c.id, children: [
                          "Comanda ",
                          c.code
                        ] }, c.id, true, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                          lineNumber: 328,
                          columnNumber: 15
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 311,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                lineNumber: 307,
                columnNumber: 21
              }, this),
              sourceOrder && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "8px", background: "rgba(255,255,255,0.03)", padding: "10px 12px", borderRadius: "8px", border: "1px solid #334155" }, children: [
                /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
                  /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.80rem", fontWeight: "600", color: "#94a3b8" }, children: "Modo:" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 338,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "6px" }, children: [
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        disabled: isTransferring,
                        onClick: () => {
                          setTransferMode("single");
                          setSelectedItemIds([]);
                        },
                        style: { padding: "4px 10px", fontSize: "0.75rem", borderRadius: "6px", border: "1px solid #475569", background: transferMode === "single" ? "#3b82f6" : "transparent", color: "#fff", cursor: isTransferring ? "not-allowed" : "pointer" },
                        children: "Item Único"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                        lineNumber: 340,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        disabled: isTransferring,
                        onClick: () => setTransferMode("batch"),
                        style: { padding: "4px 10px", fontSize: "0.75rem", borderRadius: "6px", border: "1px solid #475569", background: transferMode === "batch" ? "#3b82f6" : "transparent", color: "#fff", cursor: isTransferring ? "not-allowed" : "pointer" },
                        children: "Múltiplos / Todos"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                        lineNumber: 348,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 339,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                  lineNumber: 337,
                  columnNumber: 29
                }, this),
                transferMode === "batch" && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    disabled: isTransferring,
                    onClick: handleSelectAll,
                    style: {
                      marginTop: "4px",
                      padding: "6px",
                      borderRadius: "6px",
                      border: "1px dashed #60a5fa",
                      background: "rgba(96, 165, 250, 0.1)",
                      color: "#60a5fa",
                      fontSize: "0.78rem",
                      fontWeight: "600",
                      cursor: "pointer",
                      textAlign: "center"
                    },
                    children: selectedItemIds.length === availableItems.length ? "☑ Desmarcar Todos" : "✅ Selecionar Todos Automaticamente"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 360,
                    columnNumber: 13
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                lineNumber: 336,
                columnNumber: 11
              }, this),
              sourceId && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "6px" }, children: [
                /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.80rem", fontWeight: "600", color: "#94a3b8" }, children: [
                  "Itens Disponíveis (",
                  availableItems.length,
                  ")"
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                  lineNumber: 386,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "🔍 Buscar item...",
                    value: searchTerm,
                    disabled: isTransferring,
                    onChange: (e) => setSearchTerm(e.target.value),
                    style: { padding: "8px 10px", borderRadius: "6px", border: "1px solid #475569", backgroundColor: "#0f172a", color: "#fff", fontSize: "0.85rem" }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 390,
                    columnNumber: 29
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { style: { maxHeight: "130px", overflowY: "auto", border: "1px solid #334155", borderRadius: "8px", background: "#0f172a" }, children: productQueries.isLoading ? /* @__PURE__ */ jsxDEV("div", { style: { padding: "10px", textAlign: "center", color: "#94a3b8", fontSize: "0.85rem" }, children: "Carregando produtos..." }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                  lineNumber: 401,
                  columnNumber: 15
                }, this) : availableItems.length === 0 ? /* @__PURE__ */ jsxDEV("div", { style: { padding: "10px", textAlign: "center", color: "#94a3b8", fontSize: "0.85rem" }, children: "Nenhum item ativo encontrado." }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                  lineNumber: 403,
                  columnNumber: 15
                }, this) : availableItems.map((item) => {
                  const pId = item.productId || item.ProductId;
                  const productName = productsMap.get(pId) || `Produto #${pId}`;
                  const isSelected = selectedItemIds.includes(item.id);
                  return /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      onClick: () => !isTransferring && handleToggleItem(item.id),
                      style: {
                        display: "flex",
                        alignItems: "center",
                        gap: "12px",
                        padding: "10px 12px",
                        borderBottom: "1px solid rgba(255,255,255,0.05)",
                        backgroundColor: isSelected ? "rgba(59, 130, 246, 0.25)" : "transparent",
                        cursor: isTransferring ? "not-allowed" : "pointer"
                      },
                      children: [
                        transferMode === "batch" && /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "checkbox",
                            checked: isSelected,
                            disabled: isTransferring,
                            onChange: () => {
                            },
                            style: {
                              cursor: "pointer",
                              width: "16px",
                              height: "16px",
                              accentColor: "#3b82f6",
                              flexShrink: 0
                            }
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                            lineNumber: 425,
                            columnNumber: 21
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", fontWeight: "500", lineHeight: "1.2" }, children: [
                          productName,
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { style: { color: "#94a3b8" }, children: [
                            "(Qtd: ",
                            item.quantity,
                            ")"
                          ] }, void 0, true, {
                            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                            lineNumber: 440,
                            columnNumber: 67
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                          lineNumber: 439,
                          columnNumber: 49
                        }, this)
                      ]
                    },
                    item.id,
                    true,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                      lineNumber: 411,
                      columnNumber: 19
                    },
                    this
                  );
                }) }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                  lineNumber: 399,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                lineNumber: 385,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "6px" }, children: [
                /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.80rem", fontWeight: "600", color: "#94a3b8" }, children: transferType === "table" ? "Mesa de Destino" : "Comanda de Destino" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                  lineNumber: 452,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    value: targetId,
                    disabled: isTransferring,
                    onChange: (e) => setTargetId(e.target.value),
                    style: { padding: "10px", borderRadius: "8px", border: "1px solid #475569", backgroundColor: "#0f172a", color: "#f8fafc", fontSize: "0.9rem" },
                    required: true,
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione o destino..." }, void 0, false, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                        lineNumber: 462,
                        columnNumber: 29
                      }, this),
                      transferType === "table" ? myTables.filter((t) => t.id.toString() !== sourceId).map(
                        (t) => /* @__PURE__ */ jsxDEV("option", { value: t.id, children: [
                          "Mesa ",
                          t.number,
                          " (",
                          t.tableStatusId === 1 ? "Livre" : "Ocupada",
                          ")"
                        ] }, t.id, true, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                          lineNumber: 465,
                          columnNumber: 15
                        }, this)
                      ) : comandas.filter((c) => c.id.toString() !== sourceId).map(
                        (c) => /* @__PURE__ */ jsxDEV("option", { value: c.id, children: [
                          "Comanda ",
                          c.code,
                          " ",
                          comandaOrders.some((o) => o.comandaId === c.id) ? "(Em uso)" : "(Livre)"
                        ] }, c.id, true, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                          lineNumber: 471,
                          columnNumber: 15
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 455,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                lineNumber: 451,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "10px", marginTop: "8px" }, children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: onClose,
                    disabled: isTransferring,
                    style: { flex: 1, padding: "10px", borderRadius: "8px", border: "1px solid #475569", background: "transparent", color: "inherit", cursor: isTransferring ? "not-allowed" : "pointer", fontWeight: "600" },
                    children: "Cancelar"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 481,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    disabled: isTransferring || selectedItemIds.length === 0,
                    style: {
                      flex: 1,
                      padding: "10px",
                      borderRadius: "8px",
                      border: "none",
                      background: isTransferring ? "#2563eb" : "#3b82f6",
                      color: "#fff",
                      cursor: isTransferring ? "wait" : "pointer",
                      fontWeight: "600",
                      opacity: isTransferring || selectedItemIds.length === 0 ? 0.6 : 1,
                      transition: "background-color 0.2s ease"
                    },
                    children: isTransferring ? "Transferindo..." : `Confirmar (${selectedItemIds.length})`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                    lineNumber: 489,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
                lineNumber: 480,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
              lineNumber: 304,
              columnNumber: 17
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
          lineNumber: 226,
          columnNumber: 13
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx",
      lineNumber: 207,
      columnNumber: 5
    },
    this
  );
}
_s(TransferItemModal, "OCRgW49ELHqQMVB3aec+Idm4gz8=", false, function() {
  return [useQuery];
});
_c = TransferItemModal;
var _c;
$RefreshReg$(_c, "TransferItemModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/TransferItemModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa093Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsT3ZCLFNBQVNBLFVBQVVDLGVBQWU7QUFDbkMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVc7QUFxQmIsZ0JBQVNDLGtCQUFrQjtBQUFBLEVBQzlCQyxPQUFPO0FBQUEsRUFDUEMsV0FBVztBQUFBLEVBQ1hDLFdBQVc7QUFBQSxFQUNYQyxnQkFBZ0I7QUFBQSxFQUNoQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDb0IsR0FBRztBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJakIsU0FBOEJLLElBQUk7QUFFMUUsUUFBTSxDQUFDYSxVQUFVQyxXQUFXLElBQUluQixTQUFpQixFQUFFO0FBQ25ELFFBQU0sQ0FBQ29CLFVBQVVDLFdBQVcsSUFBSXJCLFNBQWlCLEVBQUU7QUFFbkQsUUFBTSxDQUFDc0IsY0FBY0MsZUFBZSxJQUFJdkIsU0FBNkIsUUFBUTtBQUM3RSxRQUFNLENBQUN3QixpQkFBaUJDLGtCQUFrQixJQUFJekIsU0FBbUIsRUFBRTtBQUNuRSxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEIsZ0JBQWdCQyxpQkFBaUIsSUFBSTdCLFNBQVMsS0FBSztBQUcxRCxRQUFNOEIsMkJBQTJCN0IsUUFBUSxNQUFNO0FBQzNDLFFBQUlRLG1CQUFtQkEsZ0JBQWdCc0IsT0FBTyxFQUFHLFFBQU90QjtBQUN4RCxVQUFNdUIsTUFBTSxvQkFBSUMsSUFBMkI7QUFDM0MsZUFBV0MsU0FBU3hCLGlCQUFpQjtBQUNqQyxVQUFJd0IsTUFBTUMsa0JBQWtCLEtBQU1ILEtBQUlJLElBQUlGLE1BQU1DLGVBQWVELEtBQUs7QUFBQSxJQUN4RTtBQUNBLFdBQU9GO0FBQUFBLEVBQ1gsR0FBRyxDQUFDdkIsaUJBQWlCQyxlQUFlLENBQUM7QUFFckMsUUFBTTJCLGNBQWNwQyxRQUFRLE1BQU07QUFDOUIsUUFBSSxDQUFDaUIsU0FBVSxRQUFPO0FBQ3RCLFVBQU1vQixRQUFRQyxPQUFPckIsUUFBUTtBQUM3QixRQUFJRixpQkFBaUIsU0FBUztBQUMxQixhQUFPYyx5QkFBeUJVLElBQUlGLEtBQUssS0FBSzVCLGdCQUFnQitCLEtBQUssQ0FBQUMsTUFBS0EsRUFBRVAsa0JBQWtCRyxLQUFLLEtBQUs7QUFBQSxJQUMxRyxPQUFPO0FBQ0gsYUFBTzVCLGdCQUFnQitCLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsY0FBY0wsS0FBSyxLQUFLO0FBQUEsSUFDL0Q7QUFBQSxFQUNKLEdBQUcsQ0FBQzVCLGlCQUFpQm9CLDBCQUEwQlosVUFBVUYsWUFBWSxDQUFDO0FBRXRFLFFBQU00QixhQUFhM0MsUUFBUSxNQUFNO0FBQzdCLFFBQUksQ0FBQ29DLFlBQWEsUUFBTztBQUN6QixXQUFPUSxNQUFNQyxLQUFLLElBQUlDLElBQUlWLFlBQVlXLE1BQU1oQixJQUFJLENBQUFpQixNQUFLQSxFQUFFQyxTQUFTLENBQUMsQ0FBQztBQUFBLEVBQ3RFLEdBQUcsQ0FBQ2IsV0FBVyxDQUFDO0FBRWhCLFFBQU1jLGlCQUFpQmpELFNBQVM7QUFBQSxJQUM1QmtELFVBQVUsQ0FBQyxvQkFBb0JSLFVBQVU7QUFBQSxJQUN6Q1MsU0FBUyxZQUFZO0FBQ2pCLFlBQU1DLFdBQVdWLFdBQVdaLElBQUksT0FBT3VCLE9BQU87QUFDMUMsWUFBSTtBQUNBLGlCQUFPLE1BQU1wRCxJQUFvQixpQkFBaUJvRCxFQUFFLEVBQUU7QUFBQSxRQUMxRCxRQUFRO0FBQ0osaUJBQU87QUFBQSxRQUNYO0FBQUEsTUFDSixDQUFDO0FBQ0QsWUFBTUMsVUFBVSxNQUFNQyxRQUFRQyxJQUFJSixRQUFRO0FBQzFDLFlBQU10QixNQUFNLG9CQUFJQyxJQUFvQjtBQUNwQ3VCLGNBQVFHLFFBQVEsQ0FBQUMsU0FBUTtBQUNwQixZQUFJQSxLQUFNNUIsS0FBSUksSUFBSXdCLEtBQUtMLElBQUlLLEtBQUtDLElBQUk7QUFBQSxNQUN4QyxDQUFDO0FBQ0QsYUFBTzdCO0FBQUFBLElBQ1g7QUFBQSxJQUNBOEIsU0FBU2xCLFdBQVdtQixTQUFTO0FBQUEsRUFDakMsQ0FBQztBQUVELFFBQU1DLGNBQWNiLGVBQWVjLFFBQVEsb0JBQUloQyxJQUFvQjtBQUVuRSxRQUFNaUMsaUJBQWlCakUsUUFBUSxNQUFNO0FBQ2pDLFFBQUksQ0FBQ29DLFlBQWEsUUFBTztBQUN6QixXQUFPQSxZQUFZVyxNQUFNbUIsT0FBTyxDQUFDQyxTQUFjO0FBQzNDLFVBQUlBLEtBQUtDLHNCQUFzQixFQUFHLFFBQU87QUFDekMsVUFBSSxDQUFDM0MsV0FBWSxRQUFPO0FBQ3hCLFlBQU00QyxNQUFNRixLQUFLbEIsYUFBYWtCLEtBQUtHO0FBQ25DLFlBQU1DLFFBQVFSLFlBQVl4QixJQUFJOEIsR0FBRyxLQUFLO0FBQ3RDLGFBQU9FLE1BQU1DLFlBQVksRUFBRUMsU0FBU2hELFdBQVcrQyxZQUFZLENBQUM7QUFBQSxJQUNoRSxDQUFDO0FBQUEsRUFDTCxHQUFHLENBQUNwQyxhQUFhMkIsYUFBYXRDLFVBQVUsQ0FBQztBQUV6QyxRQUFNaUQsbUJBQW1CQSxDQUFDQyxXQUFtQjtBQUN6QyxRQUFJaEQsZUFBZ0I7QUFDcEIsUUFBSU4saUJBQWlCLFVBQVU7QUFDM0JHLHlCQUFtQixDQUFDbUQsTUFBTSxDQUFDO0FBQUEsSUFDL0IsT0FBTztBQUNIbkQ7QUFBQUEsUUFBbUIsQ0FBQW9ELFNBQ2ZBLEtBQUtILFNBQVNFLE1BQU0sSUFBSUMsS0FBS1YsT0FBTyxDQUFBWixPQUFNQSxPQUFPcUIsTUFBTSxJQUFJLENBQUMsR0FBR0MsTUFBTUQsTUFBTTtBQUFBLE1BQy9FO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFFQSxRQUFNRSxrQkFBa0JBLE1BQU07QUFDMUIsUUFBSWxELGVBQWdCO0FBQ3BCLFFBQUlKLGdCQUFnQnVDLFdBQVdHLGVBQWVILFFBQVE7QUFDbER0Qyx5QkFBbUIsRUFBRTtBQUFBLElBQ3pCLE9BQU87QUFDSEEseUJBQW1CeUMsZUFBZWxDLElBQUksQ0FBQ2lCLE1BQVdBLEVBQUVNLEVBQUUsQ0FBQztBQUFBLElBQzNEO0FBQUEsRUFDSjtBQUVBLFFBQU13QixtQkFBbUJBLENBQUNDLFlBQWlDO0FBQ3ZELFFBQUlwRCxlQUFnQjtBQUNwQlgsb0JBQWdCK0QsT0FBTztBQUN2QjdELGdCQUFZLEVBQUU7QUFDZEUsZ0JBQVksRUFBRTtBQUNkSSx1QkFBbUIsRUFBRTtBQUNyQkUsa0JBQWMsRUFBRTtBQUNoQkosb0JBQWdCLFFBQVE7QUFBQSxFQUM1QjtBQUVBLFFBQU0wRCx3QkFBd0IsT0FBT0MsTUFBdUI7QUFDeERBLE1BQUVDLGVBQWU7QUFDakIsUUFBSXZELGVBQWdCO0FBRXBCLFFBQUksQ0FBQ1YsWUFBWSxDQUFDRSxZQUFZSSxnQkFBZ0J1QyxXQUFXLEtBQUssQ0FBQzFCLGFBQWE7QUFDeEUsYUFBT3ZCLFFBQVEsNERBQTREO0FBQUEsSUFDL0U7QUFFQSxVQUFNc0UsY0FBYzdDLE9BQU9uQixRQUFRO0FBQ25DLFVBQU1pRSxjQUFjckUsaUJBQWlCLFVBQy9CYyx5QkFBeUJVLElBQUk0QyxXQUFXLEtBQUsxRSxnQkFBZ0IrQixLQUFLLENBQUFDLE1BQUtBLEVBQUVQLGtCQUFrQmlELFdBQVcsSUFDdEcxRSxnQkFBZ0IrQixLQUFLLENBQUFDLE1BQUtBLEVBQUVDLGNBQWN5QyxXQUFXO0FBRTNELFFBQUksQ0FBQ0MsYUFBYTtBQUNkLFlBQU1DLGNBQWN0RSxpQkFBaUIsVUFBVSxTQUFTO0FBQ3hELGFBQU9GLFFBQVEsS0FBS3dFLFdBQVcsc0VBQXNFO0FBQUEsSUFDekc7QUFFQXpELHNCQUFrQixJQUFJO0FBQ3RCLFFBQUk7QUFDQSxZQUFNMEQsV0FBV3ZFLGlCQUFpQixVQUM1QixxQ0FDQTtBQUVOLFlBQU13RSxVQUFVeEUsaUJBQWlCLFVBQVU7QUFBQSxRQUN2Q3lFLHVCQUF1QnBELFlBQVlrQjtBQUFBQSxRQUNuQ21DLHVCQUF1QkwsWUFBWTlCO0FBQUFBLFFBQ25Db0Msc0JBQXNCbkU7QUFBQUEsUUFDdEJvRSxxQkFBcUJyRCxPQUFPckIsUUFBUTtBQUFBLFFBQ3BDMkUscUJBQXFCVDtBQUFBQSxRQUNyQlUsaUJBQWlCbkYsY0FBYztBQUFBLE1BQ25DLElBQUk7QUFBQSxRQUNBOEUsdUJBQXVCcEQsWUFBWWtCO0FBQUFBLFFBQ25DbUMsdUJBQXVCTCxZQUFZOUI7QUFBQUEsUUFDbkNvQyxzQkFBc0JuRTtBQUFBQSxRQUN0QnVFLGlCQUFpQnhELE9BQU9yQixRQUFRO0FBQUEsUUFDaEM4RSxpQkFBaUJaO0FBQUFBLFFBQ2pCVSxpQkFBaUJuRixjQUFjO0FBQUEsTUFDbkM7QUFFQSxZQUFNUixJQUFJb0YsVUFBVTtBQUFBLFFBQ2hCVSxRQUFRO0FBQUEsUUFDUkMsTUFBTUMsS0FBS0MsVUFBVVosT0FBTztBQUFBLE1BQ2hDLENBQUM7QUFFRDNFLGdCQUFVLEdBQUdXLGdCQUFnQnVDLE1BQU0sdUNBQXVDO0FBQzFFbkQsY0FBUTtBQUFBLElBQ1osU0FBU3lGLEtBQVU7QUFDZnZGLGNBQVF1RixLQUFLQyxXQUFXLGlDQUFpQztBQUN6RHpFLHdCQUFrQixLQUFLO0FBQUEsSUFDM0I7QUFBQSxFQUNKO0FBRUEsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csTUFBSztBQUFBLE1BQ0wsY0FBVztBQUFBLE1BQ1gsYUFBYSxDQUFDcUQsTUFBTTtBQUNoQixZQUFJQSxFQUFFcUIsV0FBV3JCLEVBQUVzQixpQkFBaUIsQ0FBQzVFLGVBQWdCaEIsU0FBUTtBQUFBLE1BQ2pFO0FBQUEsTUFDQSxPQUFPO0FBQUEsUUFDSDZGLFVBQVU7QUFBQSxRQUNWQyxPQUFPO0FBQUEsUUFDUEMsaUJBQWlCO0FBQUEsUUFDakJDLGdCQUFnQjtBQUFBLFFBQ2hCQyxTQUFTO0FBQUEsUUFDVEMsWUFBWTtBQUFBLFFBQ1pDLGdCQUFnQjtBQUFBLFFBQ2hCQyxRQUFRO0FBQUEsUUFDUkMsU0FBUztBQUFBLFFBQ1RDLFdBQVc7QUFBQSxNQUNmO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csT0FBTztBQUFBLFlBQ0hDLE9BQU87QUFBQSxZQUNQQyxVQUFVO0FBQUEsWUFDVkMsV0FBVztBQUFBLFlBQ1hWLGlCQUFpQjtBQUFBLFlBQ2pCVyxPQUFPO0FBQUEsWUFDUEMsY0FBYztBQUFBLFlBQ2ROLFNBQVM7QUFBQSxZQUNUTyxXQUFXO0FBQUEsWUFDWFgsU0FBUztBQUFBLFlBQ1RZLGVBQWU7QUFBQSxZQUNmUCxXQUFXO0FBQUEsWUFDWFEsV0FBVztBQUFBLFlBQ1hDLFFBQVE7QUFBQSxVQUNaO0FBQUEsVUFHQTtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFZCxTQUFTLFFBQVFZLGVBQWUsVUFBVUcsS0FBSyxRQUFRQyxjQUFjLFFBQVFDLGNBQWMscUJBQXFCQyxlQUFlLE9BQU8sR0FDaEo7QUFBQSxxQ0FBQyxTQUFJLE9BQU8sRUFBRWxCLFNBQVMsUUFBUUUsZ0JBQWdCLGlCQUFpQkQsWUFBWSxTQUFTLEdBQ2pGO0FBQUEsdUNBQUMsVUFBSyxPQUFPLEVBQUVrQixVQUFVLFVBQVVDLFlBQVksTUFBTSxHQUFHLG1DQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRTtBQUFBLGdCQUMzRTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3JIO0FBQUFBLG9CQUNULFVBQVVnQjtBQUFBQSxvQkFDVixjQUFXO0FBQUEsb0JBQ1gsT0FBTyxFQUFFc0csWUFBWSxRQUFRUCxRQUFRLFFBQVFRLFFBQVF2RyxpQkFBaUIsZ0JBQWdCLFdBQVcwRixPQUFPLFdBQVdVLFVBQVUsVUFBVWYsU0FBUyxNQUFNO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQUw1SjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxtQkFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLE1BQUssV0FBVSxPQUFPLEVBQUVKLFNBQVMsUUFBUXFCLFlBQVksV0FBV2pCLFNBQVMsT0FBT00sY0FBYyxPQUFPSSxRQUFRLG9CQUFvQixHQUNsSTtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsaUJBQWUzRyxpQkFBaUI7QUFBQSxvQkFDaEMsVUFBVVk7QUFBQUEsb0JBQ1YsU0FBUyxNQUFNbUQsaUJBQWlCLE9BQU87QUFBQSxvQkFDdkMsT0FBTztBQUFBLHNCQUNIcUQsTUFBTTtBQUFBLHNCQUNObkIsU0FBUztBQUFBLHNCQUNUTSxjQUFjO0FBQUEsc0JBQ2RJLFFBQVE7QUFBQSxzQkFDUk8sWUFBWWxILGlCQUFpQixVQUFVLFlBQVk7QUFBQSxzQkFDbkRzRyxPQUFPO0FBQUEsc0JBQ1BXLFlBQVk7QUFBQSxzQkFDWkQsVUFBVTtBQUFBLHNCQUNWRyxRQUFRdkcsaUJBQWlCLGdCQUFnQjtBQUFBLHNCQUN6Q3lHLFlBQVk7QUFBQSxvQkFDaEI7QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBakJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFvQkE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLGlCQUFlckgsaUJBQWlCO0FBQUEsb0JBQ2hDLFVBQVVZO0FBQUFBLG9CQUNWLFNBQVMsTUFBTW1ELGlCQUFpQixTQUFTO0FBQUEsb0JBQ3pDLE9BQU87QUFBQSxzQkFDSHFELE1BQU07QUFBQSxzQkFDTm5CLFNBQVM7QUFBQSxzQkFDVE0sY0FBYztBQUFBLHNCQUNkSSxRQUFRO0FBQUEsc0JBQ1JPLFlBQVlsSCxpQkFBaUIsWUFBWSxZQUFZO0FBQUEsc0JBQ3JEc0csT0FBTztBQUFBLHNCQUNQVyxZQUFZO0FBQUEsc0JBQ1pELFVBQVU7QUFBQSxzQkFDVkcsUUFBUXZHLGlCQUFpQixnQkFBZ0I7QUFBQSxzQkFDekN5RyxZQUFZO0FBQUEsb0JBQ2hCO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQWpCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBb0JBO0FBQUEsbUJBMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkNBO0FBQUEsaUJBekRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMERBO0FBQUEsWUFFQSx1QkFBQyxVQUFLLFVBQVVwRCx1QkFBdUIsT0FBTyxFQUFFNEIsU0FBUyxRQUFRWSxlQUFlLFVBQVVHLEtBQUssT0FBTyxHQUdsRztBQUFBLHFDQUFDLFNBQUksT0FBTyxFQUFFZixTQUFTLFFBQVFZLGVBQWUsVUFBVUcsS0FBSyxNQUFNLEdBQy9EO0FBQUEsdUNBQUMsV0FBTSxPQUFPLEVBQUVJLFVBQVUsV0FBV0MsWUFBWSxPQUFPWCxPQUFPLFVBQVUsR0FDcEV0RywyQkFBaUIsVUFBVSxnQ0FBZ0Msb0NBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxPQUFPRTtBQUFBQSxvQkFDUCxVQUFVVTtBQUFBQSxvQkFDVixVQUFVLENBQUNzRCxNQUFNO0FBQ2IvRCxrQ0FBWStELEVBQUVxQixPQUFPK0IsS0FBSztBQUMxQjdHLHlDQUFtQixFQUFFO0FBQUEsb0JBQ3pCO0FBQUEsb0JBQ0EsT0FBTyxFQUFFd0YsU0FBUyxRQUFRTSxjQUFjLE9BQU9JLFFBQVEscUJBQXFCaEIsaUJBQWlCLFdBQVdXLE9BQU8sV0FBV1UsVUFBVSxTQUFTO0FBQUEsb0JBQzdJLFVBQVE7QUFBQSxvQkFFUjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxJQUFHLHFDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFzQztBQUFBLHNCQUNyQ2hILGlCQUFpQixVQUNkVixTQUFTNkQsT0FBTyxDQUFBb0UsTUFBS3pHLHlCQUF5QjBHLElBQUlELEVBQUVoRixFQUFFLENBQUMsRUFBRXZCO0FBQUFBLHdCQUFJLENBQUF1RyxNQUN6RCx1QkFBQyxZQUFrQixPQUFPQSxFQUFFaEYsSUFBSTtBQUFBO0FBQUEsMEJBQU1nRixFQUFFRTtBQUFBQSw2QkFBM0JGLEVBQUVoRixJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStDO0FBQUEsc0JBQ2xELElBRURoRCxTQUFTNEQsT0FBTyxDQUFBdUUsTUFBS2xJLGNBQWNtSSxLQUFLLENBQUFqRyxNQUFLQSxFQUFFQyxjQUFjK0YsRUFBRW5GLEVBQUUsQ0FBQyxFQUFFdkI7QUFBQUEsd0JBQUksQ0FBQTBHLE1BQ3BFLHVCQUFDLFlBQWtCLE9BQU9BLEVBQUVuRixJQUFJO0FBQUE7QUFBQSwwQkFBU21GLEVBQUVFO0FBQUFBLDZCQUE5QkYsRUFBRW5GLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0Q7QUFBQSxzQkFDbkQ7QUFBQTtBQUFBO0FBQUEsa0JBbEJUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFvQkE7QUFBQSxtQkF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF5QkE7QUFBQSxjQUdDbEIsZUFDRyx1QkFBQyxTQUFJLE9BQU8sRUFBRXdFLFNBQVMsUUFBUVksZUFBZSxVQUFVRyxLQUFLLE9BQU9NLFlBQVksMEJBQTBCakIsU0FBUyxhQUFhTSxjQUFjLE9BQU9JLFFBQVEsb0JBQW9CLEdBQzdLO0FBQUEsdUNBQUMsU0FBSSxPQUFPLEVBQUVkLFNBQVMsUUFBUUUsZ0JBQWdCLGlCQUFpQkQsWUFBWSxTQUFTLEdBQ2pGO0FBQUEseUNBQUMsVUFBSyxPQUFPLEVBQUVrQixVQUFVLFdBQVdDLFlBQVksT0FBT1gsT0FBTyxVQUFVLEdBQUcscUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdGO0FBQUEsa0JBQ2hGLHVCQUFDLFNBQUksT0FBTyxFQUFFVCxTQUFTLFFBQVFlLEtBQUssTUFBTSxHQUN0QztBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNHLE1BQUs7QUFBQSx3QkFDTCxVQUFVaEc7QUFBQUEsd0JBQ1YsU0FBUyxNQUFNO0FBQUVMLDBDQUFnQixRQUFRO0FBQUdFLDZDQUFtQixFQUFFO0FBQUEsd0JBQUc7QUFBQSx3QkFDcEUsT0FBTyxFQUFFd0YsU0FBUyxZQUFZZSxVQUFVLFdBQVdULGNBQWMsT0FBT0ksUUFBUSxxQkFBcUJPLFlBQVk1RyxpQkFBaUIsV0FBVyxZQUFZLGVBQWVnRyxPQUFPLFFBQVFhLFFBQVF2RyxpQkFBaUIsZ0JBQWdCLFVBQVU7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBSmhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNHLE1BQUs7QUFBQSx3QkFDTCxVQUFVQTtBQUFBQSx3QkFDVixTQUFTLE1BQU1MLGdCQUFnQixPQUFPO0FBQUEsd0JBQ3RDLE9BQU8sRUFBRTBGLFNBQVMsWUFBWWUsVUFBVSxXQUFXVCxjQUFjLE9BQU9JLFFBQVEscUJBQXFCTyxZQUFZNUcsaUJBQWlCLFVBQVUsWUFBWSxlQUFlZ0csT0FBTyxRQUFRYSxRQUFRdkcsaUJBQWlCLGdCQUFnQixVQUFVO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUovTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSx1QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxxQkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFvQkE7QUFBQSxnQkFFQ04saUJBQWlCLFdBQ2Q7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBSztBQUFBLG9CQUNMLFVBQVVNO0FBQUFBLG9CQUNWLFNBQVNrRDtBQUFBQSxvQkFDVCxPQUFPO0FBQUEsc0JBQ0grRCxXQUFXO0FBQUEsc0JBQ1g1QixTQUFTO0FBQUEsc0JBQ1RNLGNBQWM7QUFBQSxzQkFDZEksUUFBUTtBQUFBLHNCQUNSTyxZQUFZO0FBQUEsc0JBQ1paLE9BQU87QUFBQSxzQkFDUFUsVUFBVTtBQUFBLHNCQUNWQyxZQUFZO0FBQUEsc0JBQ1pFLFFBQVE7QUFBQSxzQkFDUlcsV0FBVztBQUFBLG9CQUNmO0FBQUEsb0JBRUN0SCwwQkFBZ0J1QyxXQUFXRyxlQUFlSCxTQUFTLHNCQUFzQjtBQUFBO0FBQUEsa0JBakI5RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBa0JBO0FBQUEsbUJBMUNSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNENBO0FBQUEsY0FJSDdDLFlBQ0csdUJBQUMsU0FBSSxPQUFPLEVBQUUyRixTQUFTLFFBQVFZLGVBQWUsVUFBVUcsS0FBSyxNQUFNLEdBQy9EO0FBQUEsdUNBQUMsV0FBTSxPQUFPLEVBQUVJLFVBQVUsV0FBV0MsWUFBWSxPQUFPWCxPQUFPLFVBQVUsR0FBRztBQUFBO0FBQUEsa0JBQ3BEcEQsZUFBZUg7QUFBQUEsa0JBQU87QUFBQSxxQkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osT0FBT3JDO0FBQUFBLG9CQUNQLFVBQVVFO0FBQUFBLG9CQUNWLFVBQVUsQ0FBQ3NELE1BQU12RCxjQUFjdUQsRUFBRXFCLE9BQU8rQixLQUFLO0FBQUEsb0JBQzdDLE9BQU8sRUFBRXJCLFNBQVMsWUFBWU0sY0FBYyxPQUFPSSxRQUFRLHFCQUFxQmhCLGlCQUFpQixXQUFXVyxPQUFPLFFBQVFVLFVBQVUsVUFBVTtBQUFBO0FBQUEsa0JBTm5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNcUo7QUFBQSxnQkFHckosdUJBQUMsU0FBSSxPQUFPLEVBQUVYLFdBQVcsU0FBU0ssV0FBVyxRQUFRQyxRQUFRLHFCQUFxQkosY0FBYyxPQUFPVyxZQUFZLFVBQVUsR0FDeEgvRSx5QkFBZTRGLFlBQ1osdUJBQUMsU0FBSSxPQUFPLEVBQUU5QixTQUFTLFFBQVE2QixXQUFXLFVBQVV4QixPQUFPLFdBQVdVLFVBQVUsVUFBVSxHQUFHLHNDQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtSCxJQUNuSDlELGVBQWVILFdBQVcsSUFDMUIsdUJBQUMsU0FBSSxPQUFPLEVBQUVrRCxTQUFTLFFBQVE2QixXQUFXLFVBQVV4QixPQUFPLFdBQVdVLFVBQVUsVUFBVSxHQUFHLDZDQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwSCxJQUUxSDlELGVBQWVsQyxJQUFJLENBQUNvQyxTQUFjO0FBQzlCLHdCQUFNRSxNQUFNRixLQUFLbEIsYUFBYWtCLEtBQUtHO0FBQ25DLHdCQUFNeUUsY0FBY2hGLFlBQVl4QixJQUFJOEIsR0FBRyxLQUFLLFlBQVlBLEdBQUc7QUFDM0Qsd0JBQU0yRSxhQUFhekgsZ0JBQWdCa0QsU0FBU04sS0FBS2IsRUFBRTtBQUVuRCx5QkFDSTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFRyxTQUFTLE1BQU0sQ0FBQzNCLGtCQUFrQitDLGlCQUFpQlAsS0FBS2IsRUFBRTtBQUFBLHNCQUMxRCxPQUFPO0FBQUEsd0JBQ0hzRCxTQUFTO0FBQUEsd0JBQ1RDLFlBQVk7QUFBQSx3QkFDWmMsS0FBSztBQUFBLHdCQUNMWCxTQUFTO0FBQUEsd0JBQ1RhLGNBQWM7QUFBQSx3QkFDZG5CLGlCQUFpQnNDLGFBQWEsNkJBQTZCO0FBQUEsd0JBQzNEZCxRQUFRdkcsaUJBQWlCLGdCQUFnQjtBQUFBLHNCQUM3QztBQUFBLHNCQUVDTjtBQUFBQSx5Q0FBaUIsV0FDZDtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDRyxNQUFLO0FBQUEsNEJBQ0wsU0FBUzJIO0FBQUFBLDRCQUNULFVBQVVySDtBQUFBQSw0QkFDVixVQUFVLE1BQU07QUFBQSw0QkFBRTtBQUFBLDRCQUNsQixPQUFPO0FBQUEsOEJBQ0h1RyxRQUFRO0FBQUEsOEJBQ1JoQixPQUFPO0FBQUEsOEJBQ1ArQixRQUFRO0FBQUEsOEJBQ1JDLGFBQWE7QUFBQSw4QkFDYkMsWUFBWTtBQUFBLDRCQUNoQjtBQUFBO0FBQUEsMEJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVdNO0FBQUEsd0JBR1YsdUJBQUMsVUFBSyxPQUFPLEVBQUVwQixVQUFVLFdBQVdDLFlBQVksT0FBT29CLFlBQVksTUFBTSxHQUNwRUw7QUFBQUE7QUFBQUEsMEJBQVk7QUFBQSwwQkFBQyx1QkFBQyxVQUFLLE9BQU8sRUFBRTFCLE9BQU8sVUFBVSxHQUFHO0FBQUE7QUFBQSw0QkFBT2xELEtBQUtrRjtBQUFBQSw0QkFBUztBQUFBLCtCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUF5RDtBQUFBLDZCQUQzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUE7QUFBQTtBQUFBLG9CQTdCS2xGLEtBQUtiO0FBQUFBLG9CQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBK0JBO0FBQUEsZ0JBRVIsQ0FBQyxLQTdDVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQStDQTtBQUFBLG1CQTdESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQThEQTtBQUFBLGNBSUosdUJBQUMsU0FBSSxPQUFPLEVBQUVzRCxTQUFTLFFBQVFZLGVBQWUsVUFBVUcsS0FBSyxNQUFNLEdBQy9EO0FBQUEsdUNBQUMsV0FBTSxPQUFPLEVBQUVJLFVBQVUsV0FBV0MsWUFBWSxPQUFPWCxPQUFPLFVBQVUsR0FDcEV0RywyQkFBaUIsVUFBVSxvQkFBb0Isd0JBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxPQUFPSTtBQUFBQSxvQkFDUCxVQUFVUTtBQUFBQSxvQkFDVixVQUFVLENBQUNzRCxNQUFNN0QsWUFBWTZELEVBQUVxQixPQUFPK0IsS0FBSztBQUFBLG9CQUMzQyxPQUFPLEVBQUVyQixTQUFTLFFBQVFNLGNBQWMsT0FBT0ksUUFBUSxxQkFBcUJoQixpQkFBaUIsV0FBV1csT0FBTyxXQUFXVSxVQUFVLFNBQVM7QUFBQSxvQkFDN0ksVUFBUTtBQUFBLG9CQUVSO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcsc0NBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVDO0FBQUEsc0JBQ3RDaEgsaUJBQWlCLFVBQ2RWLFNBQVM2RCxPQUFPLENBQUFvRSxNQUFLQSxFQUFFaEYsR0FBR2dHLFNBQVMsTUFBTXJJLFFBQVEsRUFBRWM7QUFBQUEsd0JBQUksQ0FBQXVHLE1BQ25ELHVCQUFDLFlBQWtCLE9BQU9BLEVBQUVoRixJQUFJO0FBQUE7QUFBQSwwQkFDdEJnRixFQUFFRTtBQUFBQSwwQkFBTztBQUFBLDBCQUFHRixFQUFFaUIsa0JBQWtCLElBQUksVUFBVTtBQUFBLDBCQUFVO0FBQUEsNkJBRHJEakIsRUFBRWhGLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNILElBRURoRCxTQUFTNEQsT0FBTyxDQUFBdUUsTUFBS0EsRUFBRW5GLEdBQUdnRyxTQUFTLE1BQU1ySSxRQUFRLEVBQUVjO0FBQUFBLHdCQUFJLENBQUEwRyxNQUNuRCx1QkFBQyxZQUFrQixPQUFPQSxFQUFFbkYsSUFBSTtBQUFBO0FBQUEsMEJBQ25CbUYsRUFBRUU7QUFBQUEsMEJBQUs7QUFBQSwwQkFBRXBJLGNBQWNtSSxLQUFLLENBQUFqRyxNQUFLQSxFQUFFQyxjQUFjK0YsRUFBRW5GLEVBQUUsSUFBSSxhQUFhO0FBQUEsNkJBRHRFbUYsRUFBRW5GLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNIO0FBQUE7QUFBQTtBQUFBLGtCQW5CVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBcUJBO0FBQUEsbUJBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEJBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXNELFNBQVMsUUFBUWUsS0FBSyxRQUFRaUIsV0FBVyxNQUFNLEdBQ3pEO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBSztBQUFBLG9CQUNMLFNBQVNqSTtBQUFBQSxvQkFDVCxVQUFVZ0I7QUFBQUEsb0JBQ1YsT0FBTyxFQUFFd0csTUFBTSxHQUFHbkIsU0FBUyxRQUFRTSxjQUFjLE9BQU9JLFFBQVEscUJBQXFCTyxZQUFZLGVBQWVaLE9BQU8sV0FBV2EsUUFBUXZHLGlCQUFpQixnQkFBZ0IsV0FBV3FHLFlBQVksTUFBTTtBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFKOU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBSztBQUFBLG9CQUNMLFVBQVVyRyxrQkFBa0JKLGdCQUFnQnVDLFdBQVc7QUFBQSxvQkFDdkQsT0FBTztBQUFBLHNCQUNIcUUsTUFBTTtBQUFBLHNCQUNObkIsU0FBUztBQUFBLHNCQUNUTSxjQUFjO0FBQUEsc0JBQ2RJLFFBQVE7QUFBQSxzQkFDUk8sWUFBWXRHLGlCQUFpQixZQUFZO0FBQUEsc0JBQ3pDMEYsT0FBTztBQUFBLHNCQUNQYSxRQUFRdkcsaUJBQWlCLFNBQVM7QUFBQSxzQkFDbENxRyxZQUFZO0FBQUEsc0JBQ1p3QixTQUFVN0gsa0JBQWtCSixnQkFBZ0J1QyxXQUFXLElBQUssTUFBTTtBQUFBLHNCQUNsRXNFLFlBQVk7QUFBQSxvQkFDaEI7QUFBQSxvQkFFQ3pHLDJCQUFpQixvQkFBb0IsY0FBY0osZ0JBQWdCdUMsTUFBTTtBQUFBO0FBQUEsa0JBaEI5RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBaUJBO0FBQUEsbUJBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkJBO0FBQUEsaUJBM01KO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNk1BO0FBQUE7QUFBQTtBQUFBLFFBM1JKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTRSQTtBQUFBO0FBQUEsSUEvU0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBZ1RBO0FBRVI7QUFBQ2hELEdBdGRlWCxtQkFBaUI7QUFBQSxVQStDTkYsUUFBUTtBQUFBO0FBQUEsS0EvQ25CRTtBQUFpQixJQUFBc0o7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNZW1vIiwidXNlUXVlcnkiLCJhcGkiLCJUcmFuc2Zlckl0ZW1Nb2RhbCIsIm1vZGUiLCJteVRhYmxlcyIsImNvbWFuZGFzIiwiY29tYW5kYU9yZGVycyIsIm9yZGVyc0J5VGFibGVJZCIsImFsbEFjdGl2ZU9yZGVycyIsImVtcGxveWVlSWQiLCJvbkNsb3NlIiwib25TdWNjZXNzIiwib25FcnJvciIsIl9zIiwidHJhbnNmZXJUeXBlIiwic2V0VHJhbnNmZXJUeXBlIiwic291cmNlSWQiLCJzZXRTb3VyY2VJZCIsInRhcmdldElkIiwic2V0VGFyZ2V0SWQiLCJ0cmFuc2Zlck1vZGUiLCJzZXRUcmFuc2Zlck1vZGUiLCJzZWxlY3RlZEl0ZW1JZHMiLCJzZXRTZWxlY3RlZEl0ZW1JZHMiLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsImlzVHJhbnNmZXJyaW5nIiwic2V0SXNUcmFuc2ZlcnJpbmciLCJlZmZlY3RpdmVPcmRlcnNCeVRhYmxlSWQiLCJzaXplIiwibWFwIiwiTWFwIiwib3JkZXIiLCJkaW5pbmdUYWJsZUlkIiwic2V0Iiwic291cmNlT3JkZXIiLCJpZE51bSIsIk51bWJlciIsImdldCIsImZpbmQiLCJvIiwiY29tYW5kYUlkIiwicHJvZHVjdElkcyIsIkFycmF5IiwiZnJvbSIsIlNldCIsIml0ZW1zIiwiaSIsInByb2R1Y3RJZCIsInByb2R1Y3RRdWVyaWVzIiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicHJvbWlzZXMiLCJpZCIsInJlc3VsdHMiLCJQcm9taXNlIiwiYWxsIiwiZm9yRWFjaCIsInByb2QiLCJuYW1lIiwiZW5hYmxlZCIsImxlbmd0aCIsInByb2R1Y3RzTWFwIiwiZGF0YSIsImF2YWlsYWJsZUl0ZW1zIiwiZmlsdGVyIiwiaXRlbSIsIm9yZGVySXRlbVN0YXR1c0lkIiwicElkIiwiUHJvZHVjdElkIiwicE5hbWUiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiaGFuZGxlVG9nZ2xlSXRlbSIsIml0ZW1JZCIsInByZXYiLCJoYW5kbGVTZWxlY3RBbGwiLCJoYW5kbGVUeXBlQ2hhbmdlIiwibmV3VHlwZSIsImhhbmRsZUV4ZWN1dGVUcmFuc2ZlciIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldElkTnVtIiwidGFyZ2V0T3JkZXIiLCJkZXN0aW5vVGlwbyIsImVuZHBvaW50IiwicGF5bG9hZCIsInNvdXJjZUN1c3RvbWVyT3JkZXJJZCIsInRhcmdldEN1c3RvbWVyT3JkZXJJZCIsImN1c3RvbWVyT3JkZXJJdGVtSWRzIiwic291cmNlRGluaW5nVGFibGVJZCIsInRhcmdldERpbmluZ1RhYmxlSWQiLCJhY3RvckVtcGxveWVlSWQiLCJzb3VyY2VDb21hbmRhSWQiLCJ0YXJnZXRDb21hbmRhSWQiLCJtZXRob2QiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImVyciIsIm1lc3NhZ2UiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwicG9zaXRpb24iLCJpbnNldCIsImJhY2tncm91bmRDb2xvciIsImJhY2tkcm9wRmlsdGVyIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsInpJbmRleCIsInBhZGRpbmciLCJib3hTaXppbmciLCJ3aWR0aCIsIm1heFdpZHRoIiwibWF4SGVpZ2h0IiwiY29sb3IiLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJmbGV4RGlyZWN0aW9uIiwib3ZlcmZsb3dZIiwiYm9yZGVyIiwiZ2FwIiwibWFyZ2luQm90dG9tIiwiYm9yZGVyQm90dG9tIiwicGFkZGluZ0JvdHRvbSIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImJhY2tncm91bmQiLCJjdXJzb3IiLCJmbGV4IiwidHJhbnNpdGlvbiIsInZhbHVlIiwidCIsImhhcyIsIm51bWJlciIsImMiLCJzb21lIiwiY29kZSIsIm1hcmdpblRvcCIsInRleHRBbGlnbiIsImlzTG9hZGluZyIsInByb2R1Y3ROYW1lIiwiaXNTZWxlY3RlZCIsImhlaWdodCIsImFjY2VudENvbG9yIiwiZmxleFNocmluayIsImxpbmVIZWlnaHQiLCJxdWFudGl0eSIsInRvU3RyaW5nIiwidGFibGVTdGF0dXNJZCIsIm9wYWNpdHkiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUcmFuc2Zlckl0ZW1Nb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB0eXBlIHsgVGFibGVSZXNwb25zZSwgQ29tYW5kYVJlc3BvbnNlLCBPcmRlclJlc3BvbnNlIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2xpYi90eXBlc1wiO1xyXG5cclxuaW50ZXJmYWNlIFRyYW5zZmVySXRlbU1vZGFsUHJvcHMge1xyXG4gICAgbW9kZT86IFwidGFibGVcIiB8IFwiY29tYW5kYVwiO1xyXG4gICAgbXlUYWJsZXM/OiBUYWJsZVJlc3BvbnNlW107XHJcbiAgICBjb21hbmRhcz86IENvbWFuZGFSZXNwb25zZVtdO1xyXG4gICAgY29tYW5kYU9yZGVycz86IE9yZGVyUmVzcG9uc2VbXTtcclxuICAgIG9yZGVyc0J5VGFibGVJZD86IE1hcDxudW1iZXIsIE9yZGVyUmVzcG9uc2U+O1xyXG4gICAgYWxsQWN0aXZlT3JkZXJzOiBPcmRlclJlc3BvbnNlW107XHJcbiAgICBlbXBsb3llZUlkOiBudW1iZXIgfCBudWxsO1xyXG4gICAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxuICAgIG9uU3VjY2VzczogKG1zZzogc3RyaW5nKSA9PiB2b2lkO1xyXG4gICAgb25FcnJvcjogKG1zZzogc3RyaW5nKSA9PiB2b2lkO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgUHJvZHVjdERldGFpbHMge1xyXG4gICAgaWQ6IG51bWJlcjtcclxuICAgIG5hbWU6IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFRyYW5zZmVySXRlbU1vZGFsKHtcclxuICAgIG1vZGUgPSBcInRhYmxlXCIsXHJcbiAgICBteVRhYmxlcyA9IFtdLFxyXG4gICAgY29tYW5kYXMgPSBbXSxcclxuICAgIGNvbWFuZGFPcmRlcnMgPSBbXSxcclxuICAgIG9yZGVyc0J5VGFibGVJZCxcclxuICAgIGFsbEFjdGl2ZU9yZGVycyxcclxuICAgIGVtcGxveWVlSWQsXHJcbiAgICBvbkNsb3NlLFxyXG4gICAgb25TdWNjZXNzLFxyXG4gICAgb25FcnJvclxyXG59OiBUcmFuc2Zlckl0ZW1Nb2RhbFByb3BzKSB7XHJcbiAgICBjb25zdCBbdHJhbnNmZXJUeXBlLCBzZXRUcmFuc2ZlclR5cGVdID0gdXNlU3RhdGU8XCJ0YWJsZVwiIHwgXCJjb21hbmRhXCI+KG1vZGUpO1xyXG5cclxuICAgIGNvbnN0IFtzb3VyY2VJZCwgc2V0U291cmNlSWRdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuICAgIGNvbnN0IFt0YXJnZXRJZCwgc2V0VGFyZ2V0SWRdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuXHJcbiAgICBjb25zdCBbdHJhbnNmZXJNb2RlLCBzZXRUcmFuc2Zlck1vZGVdID0gdXNlU3RhdGU8XCJzaW5nbGVcIiB8IFwiYmF0Y2hcIj4oXCJzaW5nbGVcIik7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRJdGVtSWRzLCBzZXRTZWxlY3RlZEl0ZW1JZHNdID0gdXNlU3RhdGU8bnVtYmVyW10+KFtdKTtcclxuICAgIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW2lzVHJhbnNmZXJyaW5nLCBzZXRJc1RyYW5zZmVycmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gICAgLy8gTWFwZWFtZW50byByb2J1c3RvIGRlIHBlZGlkb3MgcG9yIElEIGRlIG1lc2FcclxuICAgIGNvbnN0IGVmZmVjdGl2ZU9yZGVyc0J5VGFibGVJZCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgICAgIGlmIChvcmRlcnNCeVRhYmxlSWQgJiYgb3JkZXJzQnlUYWJsZUlkLnNpemUgPiAwKSByZXR1cm4gb3JkZXJzQnlUYWJsZUlkO1xyXG4gICAgICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBPcmRlclJlc3BvbnNlPigpO1xyXG4gICAgICAgIGZvciAoY29uc3Qgb3JkZXIgb2YgYWxsQWN0aXZlT3JkZXJzKSB7XHJcbiAgICAgICAgICAgIGlmIChvcmRlci5kaW5pbmdUYWJsZUlkICE9PSBudWxsKSBtYXAuc2V0KG9yZGVyLmRpbmluZ1RhYmxlSWQsIG9yZGVyKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG1hcDtcclxuICAgIH0sIFtvcmRlcnNCeVRhYmxlSWQsIGFsbEFjdGl2ZU9yZGVyc10pO1xyXG5cclxuICAgIGNvbnN0IHNvdXJjZU9yZGVyID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFzb3VyY2VJZCkgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgY29uc3QgaWROdW0gPSBOdW1iZXIoc291cmNlSWQpO1xyXG4gICAgICAgIGlmICh0cmFuc2ZlclR5cGUgPT09IFwidGFibGVcIikge1xyXG4gICAgICAgICAgICByZXR1cm4gZWZmZWN0aXZlT3JkZXJzQnlUYWJsZUlkLmdldChpZE51bSkgfHwgYWxsQWN0aXZlT3JkZXJzLmZpbmQobyA9PiBvLmRpbmluZ1RhYmxlSWQgPT09IGlkTnVtKSB8fCBudWxsO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBhbGxBY3RpdmVPcmRlcnMuZmluZChvID0+IG8uY29tYW5kYUlkID09PSBpZE51bSkgfHwgbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9LCBbYWxsQWN0aXZlT3JkZXJzLCBlZmZlY3RpdmVPcmRlcnNCeVRhYmxlSWQsIHNvdXJjZUlkLCB0cmFuc2ZlclR5cGVdKTtcclxuXHJcbiAgICBjb25zdCBwcm9kdWN0SWRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFzb3VyY2VPcmRlcikgcmV0dXJuIFtdO1xyXG4gICAgICAgIHJldHVybiBBcnJheS5mcm9tKG5ldyBTZXQoc291cmNlT3JkZXIuaXRlbXMubWFwKGkgPT4gaS5wcm9kdWN0SWQpKSk7XHJcbiAgICB9LCBbc291cmNlT3JkZXJdKTtcclxuXHJcbiAgICBjb25zdCBwcm9kdWN0UXVlcmllcyA9IHVzZVF1ZXJ5KHtcclxuICAgICAgICBxdWVyeUtleTogW1wicHJvZHVjdHMtZGV0YWlsc1wiLCBwcm9kdWN0SWRzXSxcclxuICAgICAgICBxdWVyeUZuOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHByb21pc2VzID0gcHJvZHVjdElkcy5tYXAoYXN5bmMgKGlkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhd2FpdCBhcGk8UHJvZHVjdERldGFpbHM+KGAvYXBpL3Byb2R1Y3RzLyR7aWR9YCk7XHJcbiAgICAgICAgICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBQcm9taXNlLmFsbChwcm9taXNlcyk7XHJcbiAgICAgICAgICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XHJcbiAgICAgICAgICAgIHJlc3VsdHMuZm9yRWFjaChwcm9kID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChwcm9kKSBtYXAuc2V0KHByb2QuaWQsIHByb2QubmFtZSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICByZXR1cm4gbWFwO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW5hYmxlZDogcHJvZHVjdElkcy5sZW5ndGggPiAwLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgcHJvZHVjdHNNYXAgPSBwcm9kdWN0UXVlcmllcy5kYXRhID8/IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XHJcblxyXG4gICAgY29uc3QgYXZhaWxhYmxlSXRlbXMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBpZiAoIXNvdXJjZU9yZGVyKSByZXR1cm4gW107XHJcbiAgICAgICAgcmV0dXJuIHNvdXJjZU9yZGVyLml0ZW1zLmZpbHRlcigoaXRlbTogYW55KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpdGVtLm9yZGVySXRlbVN0YXR1c0lkID09PSA2KSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIGlmICghc2VhcmNoVGVybSkgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgIGNvbnN0IHBJZCA9IGl0ZW0ucHJvZHVjdElkIHx8IGl0ZW0uUHJvZHVjdElkO1xyXG4gICAgICAgICAgICBjb25zdCBwTmFtZSA9IHByb2R1Y3RzTWFwLmdldChwSWQpIHx8IFwiXCI7XHJcbiAgICAgICAgICAgIHJldHVybiBwTmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9LCBbc291cmNlT3JkZXIsIHByb2R1Y3RzTWFwLCBzZWFyY2hUZXJtXSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlVG9nZ2xlSXRlbSA9IChpdGVtSWQ6IG51bWJlcikgPT4ge1xyXG4gICAgICAgIGlmIChpc1RyYW5zZmVycmluZykgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0cmFuc2Zlck1vZGUgPT09IFwic2luZ2xlXCIpIHtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRJdGVtSWRzKFtpdGVtSWRdKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzZXRTZWxlY3RlZEl0ZW1JZHMocHJldiA9PlxyXG4gICAgICAgICAgICAgICAgcHJldi5pbmNsdWRlcyhpdGVtSWQpID8gcHJldi5maWx0ZXIoaWQgPT4gaWQgIT09IGl0ZW1JZCkgOiBbLi4ucHJldiwgaXRlbUlkXVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0QWxsID0gKCkgPT4ge1xyXG4gICAgICAgIGlmIChpc1RyYW5zZmVycmluZykgcmV0dXJuO1xyXG4gICAgICAgIGlmIChzZWxlY3RlZEl0ZW1JZHMubGVuZ3RoID09PSBhdmFpbGFibGVJdGVtcy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRJdGVtSWRzKFtdKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzZXRTZWxlY3RlZEl0ZW1JZHMoYXZhaWxhYmxlSXRlbXMubWFwKChpOiBhbnkpID0+IGkuaWQpKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVR5cGVDaGFuZ2UgPSAobmV3VHlwZTogXCJ0YWJsZVwiIHwgXCJjb21hbmRhXCIpID0+IHtcclxuICAgICAgICBpZiAoaXNUcmFuc2ZlcnJpbmcpIHJldHVybjtcclxuICAgICAgICBzZXRUcmFuc2ZlclR5cGUobmV3VHlwZSk7XHJcbiAgICAgICAgc2V0U291cmNlSWQoXCJcIik7XHJcbiAgICAgICAgc2V0VGFyZ2V0SWQoXCJcIik7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRJdGVtSWRzKFtdKTtcclxuICAgICAgICBzZXRTZWFyY2hUZXJtKFwiXCIpO1xyXG4gICAgICAgIHNldFRyYW5zZmVyTW9kZShcInNpbmdsZVwiKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlRXhlY3V0ZVRyYW5zZmVyID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBpZiAoaXNUcmFuc2ZlcnJpbmcpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKCFzb3VyY2VJZCB8fCAhdGFyZ2V0SWQgfHwgc2VsZWN0ZWRJdGVtSWRzLmxlbmd0aCA9PT0gMCB8fCAhc291cmNlT3JkZXIpIHtcclxuICAgICAgICAgICAgcmV0dXJuIG9uRXJyb3IoXCJQcmVlbmNoYSBhIG9yaWdlbSwgbyBkZXN0aW5vIGUgc2VsZWNpb25lIGFvIG1lbm9zIHVtIGl0ZW0uXCIpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgdGFyZ2V0SWROdW0gPSBOdW1iZXIodGFyZ2V0SWQpO1xyXG4gICAgICAgIGNvbnN0IHRhcmdldE9yZGVyID0gdHJhbnNmZXJUeXBlID09PSBcInRhYmxlXCJcclxuICAgICAgICAgICAgPyBlZmZlY3RpdmVPcmRlcnNCeVRhYmxlSWQuZ2V0KHRhcmdldElkTnVtKSB8fCBhbGxBY3RpdmVPcmRlcnMuZmluZChvID0+IG8uZGluaW5nVGFibGVJZCA9PT0gdGFyZ2V0SWROdW0pXHJcbiAgICAgICAgICAgIDogYWxsQWN0aXZlT3JkZXJzLmZpbmQobyA9PiBvLmNvbWFuZGFJZCA9PT0gdGFyZ2V0SWROdW0pO1xyXG5cclxuICAgICAgICBpZiAoIXRhcmdldE9yZGVyKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGRlc3Rpbm9UaXBvID0gdHJhbnNmZXJUeXBlID09PSBcInRhYmxlXCIgPyBcIm1lc2FcIiA6IFwiY29tYW5kYVwiO1xyXG4gICAgICAgICAgICByZXR1cm4gb25FcnJvcihgQSAke2Rlc3Rpbm9UaXBvfSBkZSBkZXN0aW5vIHByZWNpc2EgdGVyIHVtIHBlZGlkbyBhYmVydG8gcGFyYSByZWNlYmVyIG8ocykgaXRlbShucykuYCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzZXRJc1RyYW5zZmVycmluZyh0cnVlKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCBlbmRwb2ludCA9IHRyYW5zZmVyVHlwZSA9PT0gXCJ0YWJsZVwiXHJcbiAgICAgICAgICAgICAgICA/IFwiL2FwaS9vcmRlcnMvaXRlbXMvdHJhbnNmZXItYmF0Y2hcIlxyXG4gICAgICAgICAgICAgICAgOiBcIi9hcGkvb3JkZXJzL2NvbWFuZGEtaXRlbXMvdHJhbnNmZXItYmF0Y2hcIjtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSB0cmFuc2ZlclR5cGUgPT09IFwidGFibGVcIiA/IHtcclxuICAgICAgICAgICAgICAgIHNvdXJjZUN1c3RvbWVyT3JkZXJJZDogc291cmNlT3JkZXIuaWQsXHJcbiAgICAgICAgICAgICAgICB0YXJnZXRDdXN0b21lck9yZGVySWQ6IHRhcmdldE9yZGVyLmlkLFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXJPcmRlckl0ZW1JZHM6IHNlbGVjdGVkSXRlbUlkcyxcclxuICAgICAgICAgICAgICAgIHNvdXJjZURpbmluZ1RhYmxlSWQ6IE51bWJlcihzb3VyY2VJZCksXHJcbiAgICAgICAgICAgICAgICB0YXJnZXREaW5pbmdUYWJsZUlkOiB0YXJnZXRJZE51bSxcclxuICAgICAgICAgICAgICAgIGFjdG9yRW1wbG95ZWVJZDogZW1wbG95ZWVJZCA/PyAxLFxyXG4gICAgICAgICAgICB9IDoge1xyXG4gICAgICAgICAgICAgICAgc291cmNlQ3VzdG9tZXJPcmRlcklkOiBzb3VyY2VPcmRlci5pZCxcclxuICAgICAgICAgICAgICAgIHRhcmdldEN1c3RvbWVyT3JkZXJJZDogdGFyZ2V0T3JkZXIuaWQsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21lck9yZGVySXRlbUlkczogc2VsZWN0ZWRJdGVtSWRzLFxyXG4gICAgICAgICAgICAgICAgc291cmNlQ29tYW5kYUlkOiBOdW1iZXIoc291cmNlSWQpLFxyXG4gICAgICAgICAgICAgICAgdGFyZ2V0Q29tYW5kYUlkOiB0YXJnZXRJZE51bSxcclxuICAgICAgICAgICAgICAgIGFjdG9yRW1wbG95ZWVJZDogZW1wbG95ZWVJZCA/PyAxLFxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgYXdhaXQgYXBpKGVuZHBvaW50LCB7XHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6IFwiUFVUXCIsXHJcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKSxcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBvblN1Y2Nlc3MoYCR7c2VsZWN0ZWRJdGVtSWRzLmxlbmd0aH0gaXRlbShucykgdHJhbnNmZXJpZG8ocykgY29tIHN1Y2Vzc28hYCk7XHJcbiAgICAgICAgICAgIG9uQ2xvc2UoKTtcclxuICAgICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xyXG4gICAgICAgICAgICBvbkVycm9yKGVycj8ubWVzc2FnZSB8fCBcIkVycm8gYW8gcmVhbGl6YXIgdHJhbnNmZXLDqm5jaWEuXCIpO1xyXG4gICAgICAgICAgICBzZXRJc1RyYW5zZmVycmluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgICAgcm9sZT1cImRpYWxvZ1wiXHJcbiAgICAgICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcclxuICAgICAgICAgICAgb25Nb3VzZURvd249eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS50YXJnZXQgPT09IGUuY3VycmVudFRhcmdldCAmJiAhaXNUcmFuc2ZlcnJpbmcpIG9uQ2xvc2UoKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBcImZpeGVkXCIsXHJcbiAgICAgICAgICAgICAgICBpbnNldDogMCxcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCJyZ2JhKDAsIDAsIDAsIDAuNzUpXCIsXHJcbiAgICAgICAgICAgICAgICBiYWNrZHJvcEZpbHRlcjogXCJibHVyKDRweClcIixcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgekluZGV4OiA5OTk5OSxcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMTZweFwiLFxyXG4gICAgICAgICAgICAgICAgYm94U2l6aW5nOiBcImJvcmRlci1ib3hcIlxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbWF4V2lkdGg6IFwiNDgwcHhcIixcclxuICAgICAgICAgICAgICAgICAgICBtYXhIZWlnaHQ6IFwiOTB2aFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjMWUyOTNiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiI2Y4ZmFmY1wiLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCIxNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIyNHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiBcIjAgMjVweCA1MHB4IC0xMnB4IHJnYmEoMCwgMCwgMCwgMC43KVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgYm94U2l6aW5nOiBcImJvcmRlci1ib3hcIixcclxuICAgICAgICAgICAgICAgICAgICBvdmVyZmxvd1k6IFwiYXV0b1wiLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgIzMzNDE1NVwiXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7LyogSGVhZGVyICYgQWJhcyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogXCIxMnB4XCIsIG1hcmdpbkJvdHRvbTogXCIxNnB4XCIsIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgIzMzNDE1NVwiLCBwYWRkaW5nQm90dG9tOiBcIjEycHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMXJlbVwiLCBmb250V2VpZ2h0OiBcIjcwMFwiIH19PvCflIAgVHJhbnNmZXJpciBJdGVuczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVHJhbnNmZXJyaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkZlY2hhclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcIm5vbmVcIiwgYm9yZGVyOiBcIm5vbmVcIiwgY3Vyc29yOiBpc1RyYW5zZmVycmluZyA/IFwibm90LWFsbG93ZWRcIiA6IFwicG9pbnRlclwiLCBjb2xvcjogXCIjOTRhM2I4XCIsIGZvbnRTaXplOiBcIjEuMnJlbVwiLCBwYWRkaW5nOiBcIjRweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKclVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiByb2xlPVwidGFibGlzdFwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBiYWNrZ3JvdW5kOiBcIiMwZjE3MmFcIiwgcGFkZGluZzogXCI0cHhcIiwgYm9yZGVyUmFkaXVzOiBcIjhweFwiLCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMzQxNTVcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlPVwidGFiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtc2VsZWN0ZWQ9e3RyYW5zZmVyVHlwZSA9PT0gXCJ0YWJsZVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVHJhbnNmZXJyaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVHlwZUNoYW5nZShcInRhYmxlXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmbGV4OiAxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiOHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjZweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCJub25lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNmZXJUeXBlID09PSBcInRhYmxlXCIgPyBcIiMzYjgyZjZcIiA6IFwidHJhbnNwYXJlbnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjZmZmXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogXCI2MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIwLjg1cmVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yOiBpc1RyYW5zZmVycmluZyA/IFwibm90LWFsbG93ZWRcIiA6IFwicG9pbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IFwiYmFja2dyb3VuZCAwLjJzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCfjb3vuI8gTWVzYXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm9sZT1cInRhYlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXt0cmFuc2ZlclR5cGUgPT09IFwiY29tYW5kYVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVHJhbnNmZXJyaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVHlwZUNoYW5nZShcImNvbWFuZGFcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXg6IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCI4cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIm5vbmVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc2ZlclR5cGUgPT09IFwiY29tYW5kYVwiID8gXCIjM2I4MmY2XCIgOiBcInRyYW5zcGFyZW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IFwiNjAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC44NXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvcjogaXNUcmFuc2ZlcnJpbmcgPyBcIm5vdC1hbGxvd2VkXCIgOiBcInBvaW50ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBcImJhY2tncm91bmQgMC4yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5OLIENvbWFuZGFzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUV4ZWN1dGVUcmFuc2Zlcn0gc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogXCIxNHB4XCIgfX0+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBPcmlnZW0gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgZ2FwOiBcIjZweFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZm9udFNpemU6IFwiMC44MHJlbVwiLCBmb250V2VpZ2h0OiBcIjYwMFwiLCBjb2xvcjogXCIjOTRhM2I4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNmZXJUeXBlID09PSBcInRhYmxlXCIgPyBcIk1lc2EgZGUgT3JpZ2VtIChDb20gcGVkaWRvKVwiIDogXCJDb21hbmRhIGRlIE9yaWdlbSAoQ29tIHBlZGlkbylcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NvdXJjZUlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVHJhbnNmZXJyaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U291cmNlSWQoZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkSXRlbUlkcyhbXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIxMHB4XCIsIGJvcmRlclJhZGl1czogXCI4cHhcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjNDc1NTY5XCIsIGJhY2tncm91bmRDb2xvcjogXCIjMGYxNzJhXCIsIGNvbG9yOiBcIiNmOGZhZmNcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2lvbmUgYSBvcmlnZW0uLi48L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0cmFuc2ZlclR5cGUgPT09IFwidGFibGVcIiA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBteVRhYmxlcy5maWx0ZXIodCA9PiBlZmZlY3RpdmVPcmRlcnNCeVRhYmxlSWQuaGFzKHQuaWQpKS5tYXAodCA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt0LmlkfSB2YWx1ZT17dC5pZH0+TWVzYSB7dC5udW1iZXJ9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tYW5kYXMuZmlsdGVyKGMgPT4gY29tYW5kYU9yZGVycy5zb21lKG8gPT4gby5jb21hbmRhSWQgPT09IGMuaWQpKS5tYXAoYyA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjLmlkfSB2YWx1ZT17Yy5pZH0+Q29tYW5kYSB7Yy5jb2RlfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFNlbGV0b3IgZGUgTW9kbyBlIEF0YWxobyBkZSBTZWxlw6fDo28gUsOhcGlkYSAqL31cclxuICAgICAgICAgICAgICAgICAgICB7c291cmNlT3JkZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCBnYXA6IFwiOHB4XCIsIGJhY2tncm91bmQ6IFwicmdiYSgyNTUsMjU1LDI1NSwwLjAzKVwiLCBwYWRkaW5nOiBcIjEwcHggMTJweFwiLCBib3JkZXJSYWRpdXM6IFwiOHB4XCIsIGJvcmRlcjogXCIxcHggc29saWQgIzMzNDE1NVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODByZW1cIiwgZm9udFdlaWdodDogXCI2MDBcIiwgY29sb3I6IFwiIzk0YTNiOFwiIH19Pk1vZG86PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogXCI2cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNUcmFuc2ZlcnJpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFRyYW5zZmVyTW9kZShcInNpbmdsZVwiKTsgc2V0U2VsZWN0ZWRJdGVtSWRzKFtdKTsgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiNHB4IDEwcHhcIiwgZm9udFNpemU6IFwiMC43NXJlbVwiLCBib3JkZXJSYWRpdXM6IFwiNnB4XCIsIGJvcmRlcjogXCIxcHggc29saWQgIzQ3NTU2OVwiLCBiYWNrZ3JvdW5kOiB0cmFuc2Zlck1vZGUgPT09IFwic2luZ2xlXCIgPyBcIiMzYjgyZjZcIiA6IFwidHJhbnNwYXJlbnRcIiwgY29sb3I6IFwiI2ZmZlwiLCBjdXJzb3I6IGlzVHJhbnNmZXJyaW5nID8gXCJub3QtYWxsb3dlZFwiIDogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSXRlbSDDmm5pY29cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVHJhbnNmZXJyaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VHJhbnNmZXJNb2RlKFwiYmF0Y2hcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjRweCAxMHB4XCIsIGZvbnRTaXplOiBcIjAuNzVyZW1cIiwgYm9yZGVyUmFkaXVzOiBcIjZweFwiLCBib3JkZXI6IFwiMXB4IHNvbGlkICM0NzU1NjlcIiwgYmFja2dyb3VuZDogdHJhbnNmZXJNb2RlID09PSBcImJhdGNoXCIgPyBcIiMzYjgyZjZcIiA6IFwidHJhbnNwYXJlbnRcIiwgY29sb3I6IFwiI2ZmZlwiLCBjdXJzb3I6IGlzVHJhbnNmZXJyaW5nID8gXCJub3QtYWxsb3dlZFwiIDogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTcO6bHRpcGxvcyAvIFRvZG9zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3RyYW5zZmVyTW9kZSA9PT0gXCJiYXRjaFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNUcmFuc2ZlcnJpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNlbGVjdEFsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpblRvcDogXCI0cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IGRhc2hlZCAjNjBhNWZhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInJnYmEoOTYsIDE2NSwgMjUwLCAwLjEpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjNjBhNWZhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIwLjc4cmVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjYwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkSXRlbUlkcy5sZW5ndGggPT09IGF2YWlsYWJsZUl0ZW1zLmxlbmd0aCA/IFwi4piRIERlc21hcmNhciBUb2Rvc1wiIDogXCLinIUgU2VsZWNpb25hciBUb2RvcyBBdXRvbWF0aWNhbWVudGVcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBMaXN0YSBkZSBJdGVucyAqL31cclxuICAgICAgICAgICAgICAgICAgICB7c291cmNlSWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCBnYXA6IFwiNnB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZm9udFNpemU6IFwiMC44MHJlbVwiLCBmb250V2VpZ2h0OiBcIjYwMFwiLCBjb2xvcjogXCIjOTRhM2I4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSXRlbnMgRGlzcG9uw612ZWlzICh7YXZhaWxhYmxlSXRlbXMubGVuZ3RofSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi8J+UjSBCdXNjYXIgaXRlbS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVHJhbnNmZXJyaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCI4cHggMTBweFwiLCBib3JkZXJSYWRpdXM6IFwiNnB4XCIsIGJvcmRlcjogXCIxcHggc29saWQgIzQ3NTU2OVwiLCBiYWNrZ3JvdW5kQ29sb3I6IFwiIzBmMTcyYVwiLCBjb2xvcjogXCIjZmZmXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1heEhlaWdodDogXCIxMzBweFwiLCBvdmVyZmxvd1k6IFwiYXV0b1wiLCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMzQxNTVcIiwgYm9yZGVyUmFkaXVzOiBcIjhweFwiLCBiYWNrZ3JvdW5kOiBcIiMwZjE3MmFcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdFF1ZXJpZXMuaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6IFwiMTBweFwiLCB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIGNvbG9yOiBcIiM5NGEzYjhcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PkNhcnJlZ2FuZG8gcHJvZHV0b3MuLi48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogYXZhaWxhYmxlSXRlbXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6IFwiMTBweFwiLCB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIGNvbG9yOiBcIiM5NGEzYjhcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19Pk5lbmh1bSBpdGVtIGF0aXZvIGVuY29udHJhZG8uPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlSXRlbXMubWFwKChpdGVtOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBJZCA9IGl0ZW0ucHJvZHVjdElkIHx8IGl0ZW0uUHJvZHVjdElkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJvZHVjdE5hbWUgPSBwcm9kdWN0c01hcC5nZXQocElkKSB8fCBgUHJvZHV0byAjJHtwSWR9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBzZWxlY3RlZEl0ZW1JZHMuaW5jbHVkZXMoaXRlbS5pZCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gIWlzVHJhbnNmZXJyaW5nICYmIGhhbmRsZVRvZ2dsZUl0ZW0oaXRlbS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnYXA6IFwiMTJweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIxMHB4IDEycHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgcmdiYSgyNTUsMjU1LDI1NSwwLjA1KVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBpc1NlbGVjdGVkID8gXCJyZ2JhKDU5LCAxMzAsIDI0NiwgMC4yNSlcIiA6IFwidHJhbnNwYXJlbnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvcjogaXNUcmFuc2ZlcnJpbmcgPyBcIm5vdC1hbGxvd2VkXCIgOiBcInBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RyYW5zZmVyTW9kZSA9PT0gXCJiYXRjaFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17aXNTZWxlY3RlZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNUcmFuc2ZlcnJpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHsgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogXCIxNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIxNnB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VudENvbG9yOiBcIiMzYjgyZjZcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmxleFNocmluazogMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGZvbnRXZWlnaHQ6IFwiNTAwXCIsIGxpbmVIZWlnaHQ6IFwiMS4yXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdE5hbWV9IDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcIiM5NGEzYjhcIiB9fT4oUXRkOiB7aXRlbS5xdWFudGl0eX0pPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIERlc3Rpbm8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgZ2FwOiBcIjZweFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZm9udFNpemU6IFwiMC44MHJlbVwiLCBmb250V2VpZ2h0OiBcIjYwMFwiLCBjb2xvcjogXCIjOTRhM2I4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNmZXJUeXBlID09PSBcInRhYmxlXCIgPyBcIk1lc2EgZGUgRGVzdGlub1wiIDogXCJDb21hbmRhIGRlIERlc3Rpbm9cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhcmdldElkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVHJhbnNmZXJyaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUYXJnZXRJZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjEwcHhcIiwgYm9yZGVyUmFkaXVzOiBcIjhweFwiLCBib3JkZXI6IFwiMXB4IHNvbGlkICM0NzU1NjlcIiwgYmFja2dyb3VuZENvbG9yOiBcIiMwZjE3MmFcIiwgY29sb3I6IFwiI2Y4ZmFmY1wiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjaW9uZSBvIGRlc3Rpbm8uLi48L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0cmFuc2ZlclR5cGUgPT09IFwidGFibGVcIiA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBteVRhYmxlcy5maWx0ZXIodCA9PiB0LmlkLnRvU3RyaW5nKCkgIT09IHNvdXJjZUlkKS5tYXAodCA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt0LmlkfSB2YWx1ZT17dC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNZXNhIHt0Lm51bWJlcn0gKHt0LnRhYmxlU3RhdHVzSWQgPT09IDEgPyBcIkxpdnJlXCIgOiBcIk9jdXBhZGFcIn0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbWFuZGFzLmZpbHRlcihjID0+IGMuaWQudG9TdHJpbmcoKSAhPT0gc291cmNlSWQpLm1hcChjID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2MuaWR9IHZhbHVlPXtjLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbWFuZGEge2MuY29kZX0ge2NvbWFuZGFPcmRlcnMuc29tZShvID0+IG8uY29tYW5kYUlkID09PSBjLmlkKSA/IFwiKEVtIHVzbylcIiA6IFwiKExpdnJlKVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBw6fDtWVzICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogXCIxMHB4XCIsIG1hcmdpblRvcDogXCI4cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVHJhbnNmZXJyaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZmxleDogMSwgcGFkZGluZzogXCIxMHB4XCIsIGJvcmRlclJhZGl1czogXCI4cHhcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjNDc1NTY5XCIsIGJhY2tncm91bmQ6IFwidHJhbnNwYXJlbnRcIiwgY29sb3I6IFwiaW5oZXJpdFwiLCBjdXJzb3I6IGlzVHJhbnNmZXJyaW5nID8gXCJub3QtYWxsb3dlZFwiIDogXCJwb2ludGVyXCIsIGZvbnRXZWlnaHQ6IFwiNjAwXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVHJhbnNmZXJyaW5nIHx8IHNlbGVjdGVkSXRlbUlkcy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXg6IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIxMHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjhweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCJub25lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogaXNUcmFuc2ZlcnJpbmcgPyBcIiMyNTYzZWJcIiA6IFwiIzNiODJmNlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiNmZmZcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IGlzVHJhbnNmZXJyaW5nID8gXCJ3YWl0XCIgOiBcInBvaW50ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjYwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IChpc1RyYW5zZmVycmluZyB8fCBzZWxlY3RlZEl0ZW1JZHMubGVuZ3RoID09PSAwKSA/IDAuNiA6IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogXCJiYWNrZ3JvdW5kLWNvbG9yIDAuMnMgZWFzZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNUcmFuc2ZlcnJpbmcgPyBcIlRyYW5zZmVyaW5kby4uLlwiIDogYENvbmZpcm1hciAoJHtzZWxlY3RlZEl0ZW1JZHMubGVuZ3RofSlgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy93YWl0ZXIvY29tcG9uZW50cy9tb2RhbHMvVHJhbnNmZXJJdGVtTW9kYWwudHN4In0=