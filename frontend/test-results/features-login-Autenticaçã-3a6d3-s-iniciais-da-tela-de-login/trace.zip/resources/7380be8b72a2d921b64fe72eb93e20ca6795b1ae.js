import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodShippingPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  cancelIFoodShippingDelivery,
  getIFoodSafeDeliveryScore,
  getIFoodShippingCancellationReasons,
  getIFoodShippingDeliveries,
  getIFoodShippingQuote,
  getIFoodShippingTracking,
  requestIFoodShippingDriver
} from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useToast } from "/src/ui/Toast.tsx";
import { Button } from "/src/ui/Button.tsx";
import { StatusBadge } from "/src/ui/StatusBadge.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { SelectField, TextField } from "/src/ui/Field.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
const REFRESH_INTERVAL_MS = 2e4;
const STATUS_LABEL = {
  DRIVER_REQUESTED: "Entregador solicitado",
  CANCELLED: "Cancelada"
};
const STATUS_COLOR = {
  DRIVER_REQUESTED: "var(--ok)",
  CANCELLED: "var(--danger)"
};
export function IFoodShippingPage() {
  _s();
  const queryClient = useQueryClient();
  const { branchId } = useAuthStore();
  const [requesting, setRequesting] = useState(false);
  const [tracking, setTracking] = useState(null);
  const [cancelling, setCancelling] = useState(null);
  const deliveriesQuery = useQuery({
    queryKey: ["integrations", "ifood", "shipping", branchId],
    queryFn: () => getIFoodShippingDeliveries(branchId),
    refetchInterval: REFRESH_INTERVAL_MS
  });
  const invalidate = () => void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "shipping"] });
  const deliveries = deliveriesQuery.data ?? [];
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1e3, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood", style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "← Integração iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", alignItems: "flex-end", gap: 12 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Entregas iFood (Shipping)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
            lineNumber: 87,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "peça um entregador do iFood pra um pedido de outro canal (telefone, WhatsApp, balcão)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
            lineNumber: 90,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 86,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => setRequesting(true), children: "+ Nova entrega" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 94,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 85,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 81,
      columnNumber: 7
    }, this),
    deliveriesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: deliveriesQuery.error, what: "as entregas do iFood" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 100,
      columnNumber: 35
    }, this),
    !deliveriesQuery.isLoading && deliveries.length === 0 && !deliveriesQuery.isError && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        title: "Nenhuma entrega em aberto",
        description: "Peça um entregador do iFood pra um pedido de telefone, WhatsApp ou balcão que precise ser entregue."
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 103,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12 }, children: deliveries.map(
      (delivery) => /* @__PURE__ */ jsxDEV(
        ShippingDeliveryCard,
        {
          delivery,
          onTrack: () => setTracking(delivery),
          onCancel: () => setCancelling(delivery)
        },
        delivery.id,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 111,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    requesting && /* @__PURE__ */ jsxDEV(
      RequestDriverModal,
      {
        branchId,
        onClose: () => setRequesting(false),
        onRequested: () => {
          setRequesting(false);
          invalidate();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 121,
        columnNumber: 7
      },
      this
    ),
    tracking && /* @__PURE__ */ jsxDEV(TrackingModal, { delivery: tracking, onClose: () => setTracking(null) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 131,
      columnNumber: 20
    }, this),
    cancelling && /* @__PURE__ */ jsxDEV(
      CancelDeliveryModal,
      {
        delivery: cancelling,
        onClose: () => setCancelling(null),
        onCancelled: () => {
          setCancelling(null);
          invalidate();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 134,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
    lineNumber: 80,
    columnNumber: 5
  }, this);
}
_s(IFoodShippingPage, "2cGqGyNWwLUoETf/DRWF38DiHm0=", false, function() {
  return [useQueryClient, useAuthStore, useQuery];
});
_c = IFoodShippingPage;
function ShippingDeliveryCard({
  delivery,
  onTrack,
  onCancel
}) {
  const canCancel = delivery.status !== "CANCELLED";
  return /* @__PURE__ */ jsxDEV("section", { className: "ticket rise", style: { padding: 18, display: "grid", gap: 10 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 700, fontSize: "1.05rem" }, children: [
          delivery.orderReference ?? `Entrega #${delivery.id}`,
          " — ",
          delivery.customerName
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 162,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: delivery.deliveryAddress }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 165,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 161,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 6, justifyItems: "end" }, children: [
        /* @__PURE__ */ jsxDEV(StatusBadge, { color: STATUS_COLOR[delivery.status] ?? "var(--ink-faint)", children: STATUS_LABEL[delivery.status] ?? delivery.status }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 168,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: delivery.merchantFee.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 171,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 167,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    canCancel && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onTrack, children: "Rastrear" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 179,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onCancel, children: "Cancelar entrega" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 182,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 178,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
    lineNumber: 159,
    columnNumber: 5
  }, this);
}
_c2 = ShippingDeliveryCard;
function RequestDriverModal({
  branchId,
  onClose,
  onRequested
}) {
  _s2();
  const toast = useToast();
  const [step, setStep] = useState("form");
  const [quote, setQuote] = useState(null);
  const [orderReference, setOrderReference] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [phoneAreaCode, setPhoneAreaCode] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [merchantFee, setMerchantFee] = useState("0");
  const [postalCode, setPostalCode] = useState("");
  const [streetName, setStreetName] = useState("");
  const [streetNumber, setStreetNumber] = useState("");
  const [complement, setComplement] = useState("");
  const [neighborhood, setNeighborhood] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [itemName, setItemName] = useState("");
  const [itemQuantity, setItemQuantity] = useState("1");
  const [itemUnitPrice, setItemUnitPrice] = useState("");
  const [items, setItems] = useState([]);
  const hasCoordinates = latitude.trim() !== "" && longitude.trim() !== "";
  const quoteMutation = useMutation({
    mutationFn: () => {
      if (!hasCoordinates) throw new Error("missing-coordinates");
      return getIFoodShippingQuote(branchId, Number(latitude), Number(longitude));
    },
    onSuccess: (result) => {
      setQuote(result);
      setStep("confirm");
    },
    onError: () => toast.error("Não foi possível cotar a entrega — confira as coordenadas e tente de novo.")
  });
  const requestMutation = useMutation({
    mutationFn: () => {
      if (!quote) throw new Error("missing-quote");
      return requestIFoodShippingDriver({
        branchId,
        orderReference: orderReference.trim() || void 0,
        customerName: customerName.trim(),
        customerPhoneAreaCode: phoneAreaCode.trim(),
        customerPhoneNumber: phoneNumber.trim(),
        merchantFee: Number(merchantFee) || 0,
        quoteId: quote.quoteId,
        postalCode: postalCode.trim(),
        streetNumber: streetNumber.trim(),
        streetName: streetName.trim(),
        complement: complement.trim() || void 0,
        neighborhood: neighborhood.trim(),
        city: city.trim(),
        state: state.trim(),
        latitude: hasCoordinates ? Number(latitude) : void 0,
        longitude: hasCoordinates ? Number(longitude) : void 0,
        items
      });
    },
    onSuccess: () => {
      toast.success("Entregador solicitado ao iFood.");
      onRequested();
    },
    onError: () => toast.error("Não foi possível solicitar o entregador — a cotação pode ter expirado, tente cotar de novo.")
  });
  const addItem = () => {
    if (!itemName.trim() || Number(itemUnitPrice) <= 0) return;
    setItems([...items, { name: itemName.trim(), quantity: Number(itemQuantity) || 1, unitPrice: Number(itemUnitPrice) }]);
    setItemName("");
    setItemQuantity("1");
    setItemUnitPrice("");
  };
  const canQuote = customerName.trim() && phoneAreaCode.trim() && phoneNumber.trim() && postalCode.trim() && streetName.trim() && streetNumber.trim() && neighborhood.trim() && city.trim() && state.trim() && hasCoordinates && items.length > 0;
  if (step === "confirm" && quote) {
    return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: "Confirmar entrega", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 340 }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 14, display: "grid", gap: 6 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: "Cotação do iFood" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 285,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Valor: ",
          quote.netValue.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 286,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Prazo estimado: ",
          Math.round(quote.deliveryTimeMinMinutes),
          "–",
          Math.round(quote.deliveryTimeMaxMinutes),
          " min"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 287,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
          "Distância: ",
          (quote.distanceMeters / 1e3).toFixed(1),
          " km"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 290,
          columnNumber: 13
        }, this),
        quote.expirationAt && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--warn, #d97706)", fontSize: "0.8rem" }, children: [
          "Cotação válida até ",
          new Date(quote.expirationAt).toLocaleTimeString("pt-BR"),
          " — confirme logo."
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 292,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 284,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Taxa do estabelecimento (opcional)",
          inputMode: "decimal",
          value: merchantFee,
          onChange: (e) => setMerchantFee(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 298,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setStep("form"), children: "Voltar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 306,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "primary", loading: requestMutation.isPending, onClick: () => requestMutation.mutate(), children: "Confirmar entregador" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 309,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 305,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 283,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 282,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: "Nova entrega via iFood", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 380 }, children: [
    /* @__PURE__ */ jsxDEV(
      TextField,
      {
        label: "Referência do pedido (opcional)",
        placeholder: "ex.: Balcão #45, Telefone (11) 98765-4321",
        value: orderReference,
        onChange: (e) => setOrderReference(e.target.value)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 321,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome do cliente", value: customerName, onChange: (e) => setCustomerName(e.target.value), autoFocus: true }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 327,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { width: 90 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "DDD", inputMode: "numeric", value: phoneAreaCode, onChange: (e) => setPhoneAreaCode(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 330,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 329,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Telefone", inputMode: "numeric", value: phoneNumber, onChange: (e) => setPhoneNumber(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 333,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 332,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 328,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600, marginTop: 4 }, children: "Endereço de entrega" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 337,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "CEP", value: postalCode, onChange: (e) => setPostalCode(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 340,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 339,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { width: 100 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Número", value: streetNumber, onChange: (e) => setStreetNumber(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 343,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 342,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 338,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Rua", value: streetName, onChange: (e) => setStreetName(e.target.value) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 346,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Complemento (opcional)", value: complement, onChange: (e) => setComplement(e.target.value) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 347,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Bairro", value: neighborhood, onChange: (e) => setNeighborhood(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 350,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 349,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Cidade", value: city, onChange: (e) => setCity(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 353,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 352,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { width: 70 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "UF", value: state, onChange: (e) => setState(e.target.value.toUpperCase()) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 356,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 355,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 348,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Latitude",
          inputMode: "decimal",
          value: latitude,
          onChange: (e) => setLatitude(e.target.value),
          hint: "obrigatória para cotar"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 361,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 360,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Longitude", inputMode: "decimal", value: longitude, onChange: (e) => setLongitude(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 370,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 369,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 359,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600, marginTop: 4 }, children: "Itens do pedido" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 374,
      columnNumber: 9
    }, this),
    items.length > 0 && /* @__PURE__ */ jsxDEV("ul", { style: { margin: 0, paddingLeft: 18, display: "grid", gap: 4 }, children: items.map(
      (item, idx) => /* @__PURE__ */ jsxDEV("li", { style: { fontSize: "0.9rem" }, children: [
        item.quantity,
        "x ",
        item.name,
        " —",
        " ",
        (item.unitPrice * item.quantity).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
      ] }, idx, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 378,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 376,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Item", value: itemName, onChange: (e) => setItemName(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 387,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 386,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { width: 70 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Qtd", inputMode: "numeric", value: itemQuantity, onChange: (e) => setItemQuantity(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 390,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 389,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { width: 110 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Preço unit.", inputMode: "decimal", value: itemUnitPrice, onChange: (e) => setItemUnitPrice(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 393,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 392,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: addItem, children: "+ Item" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 395,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 385,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 6 }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 401,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", disabled: !canQuote, loading: quoteMutation.isPending, onClick: () => quoteMutation.mutate(), children: "Cotar entrega" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 404,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 400,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
    lineNumber: 320,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
    lineNumber: 319,
    columnNumber: 5
  }, this);
}
_s2(RequestDriverModal, "qul3cqEU9opuIdmLq1BqWpxbYYU=", false, function() {
  return [useToast, useMutation, useMutation];
});
_c3 = RequestDriverModal;
function TrackingModal({ delivery, onClose }) {
  _s3();
  const trackingQuery = useQuery({
    queryKey: ["integrations", "ifood", "shipping-tracking", delivery.id],
    queryFn: () => getIFoodShippingTracking(delivery.id),
    refetchInterval: 15e3
  });
  const scoreQuery = useQuery({
    queryKey: ["integrations", "ifood", "shipping-safe-score", delivery.id],
    queryFn: () => getIFoodSafeDeliveryScore(delivery.id)
  });
  const tracking = trackingQuery.data;
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: `Rastrear ${delivery.orderReference ?? `entrega #${delivery.id}`}`, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12, minWidth: 300 }, children: [
    trackingQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: trackingQuery.error, what: "o rastreamento" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 430,
      columnNumber: 35
    }, this),
    trackingQuery.isLoading && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "Carregando…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 431,
      columnNumber: 37
    }, this),
    tracking && /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 14, display: "grid", gap: 6 }, children: [
      tracking.latitude != null && tracking.longitude != null ? /* @__PURE__ */ jsxDEV("span", { children: [
        "Posição do entregador: ",
        tracking.latitude.toFixed(5),
        ", ",
        tracking.longitude.toFixed(5)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 435,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "Posição ainda não disponível." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 439,
        columnNumber: 11
      }, this),
      tracking.expectedDelivery && /* @__PURE__ */ jsxDEV("span", { children: [
        "Previsão de entrega: ",
        new Date(tracking.expectedDelivery).toLocaleTimeString("pt-BR")
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 442,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 433,
      columnNumber: 9
    }, this),
    scoreQuery.data?.score && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
      "Índice de segurança da entrega: ",
      scoreQuery.data.score
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 447,
      columnNumber: 9
    }, this),
    delivery.trackingUrl && /* @__PURE__ */ jsxDEV("a", { href: delivery.trackingUrl, target: "_blank", rel: "noreferrer", style: { fontSize: "0.9rem" }, children: "Abrir rastreamento completo do iFood ↗" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 450,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Fechar" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 455,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 454,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
    lineNumber: 429,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
    lineNumber: 428,
    columnNumber: 5
  }, this);
}
_s3(TrackingModal, "VSpt8XNTjxNMpu1tX9hjbtB+JzQ=", false, function() {
  return [useQuery, useQuery];
});
_c4 = TrackingModal;
function CancelDeliveryModal({
  delivery,
  onClose,
  onCancelled
}) {
  _s4();
  const toast = useToast();
  const [cancelCodeId, setCancelCodeId] = useState("");
  const reasonsQuery = useQuery({
    queryKey: ["integrations", "ifood", "shipping-cancellation-reasons", delivery.id],
    queryFn: () => getIFoodShippingCancellationReasons(delivery.id)
  });
  const cancelMutation = useMutation({
    mutationFn: () => {
      const reason = reasonsQuery.data?.find((r) => r.cancelCodeId === cancelCodeId);
      return cancelIFoodShippingDelivery(delivery.id, reason?.description ?? "Cancelado pelo lojista", Number(cancelCodeId) || 0);
    },
    onSuccess: () => {
      toast.success("Entrega cancelada no iFood.");
      onCancelled();
    },
    onError: () => toast.error("Não foi possível cancelar a entrega.")
  });
  const reasons = reasonsQuery.data ?? [];
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: `Cancelar ${delivery.orderReference ?? `entrega #${delivery.id}`}`, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 320 }, children: [
    reasonsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: reasonsQuery.error, what: "os motivos de cancelamento" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 498,
      columnNumber: 34
    }, this),
    /* @__PURE__ */ jsxDEV(
      SelectField,
      {
        label: "Motivo do cancelamento",
        value: cancelCodeId,
        onChange: (e) => setCancelCodeId(e.target.value),
        disabled: reasonsQuery.isLoading,
        children: [
          /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione um motivo…" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
            lineNumber: 506,
            columnNumber: 11
          }, this),
          reasons.map(
            (reason) => /* @__PURE__ */ jsxDEV("option", { value: reason.cancelCodeId, children: reason.description }, reason.cancelCodeId, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
              lineNumber: 508,
              columnNumber: 11
            }, this)
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 500,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
        lineNumber: 515,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "danger",
          disabled: !cancelCodeId,
          loading: cancelMutation.isPending,
          onClick: () => cancelMutation.mutate(),
          children: "Cancelar entrega"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
          lineNumber: 518,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
      lineNumber: 514,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
    lineNumber: 497,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx",
    lineNumber: 496,
    columnNumber: 5
  }, this);
}
_s4(CancelDeliveryModal, "xnDKfO05xFcO2nVfkdatqx8lhEs=", false, function() {
  return [useToast, useQuery, useMutation];
});
_c5 = CancelDeliveryModal;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "IFoodShippingPage");
$RefreshReg$(_c2, "ShippingDeliveryCard");
$RefreshReg$(_c3, "RequestDriverModal");
$RefreshReg$(_c4, "TrackingModal");
$RefreshReg$(_c5, "CancelDeliveryModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodShippingPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERROzs7Ozs7Ozs7Ozs7Ozs7OztBQTlEUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUlLO0FBQ1AsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBUTNCLE1BQU1DLHNCQUFzQjtBQUU1QixNQUFNQyxlQUF1QztBQUFBLEVBQzNDQyxrQkFBa0I7QUFBQSxFQUNsQkMsV0FBVztBQUNiO0FBRUEsTUFBTUMsZUFBdUM7QUFBQSxFQUMzQ0Ysa0JBQWtCO0FBQUEsRUFDbEJDLFdBQVc7QUFDYjtBQUVPLGdCQUFTRSxvQkFBb0I7QUFBQUMsS0FBQTtBQUNsQyxRQUFNQyxjQUFjeEIsZUFBZTtBQUNuQyxRQUFNLEVBQUV5QixTQUFTLElBQUlqQixhQUFhO0FBQ2xDLFFBQU0sQ0FBQ2tCLFlBQVlDLGFBQWEsSUFBSS9CLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUNnQyxVQUFVQyxXQUFXLElBQUlqQyxTQUErQyxJQUFJO0FBQ25GLFFBQU0sQ0FBQ2tDLFlBQVlDLGFBQWEsSUFBSW5DLFNBQStDLElBQUk7QUFFdkYsUUFBTW9DLGtCQUFrQmpDLFNBQVM7QUFBQSxJQUMvQmtDLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxZQUFZUixRQUFRO0FBQUEsSUFDeERTLFNBQVNBLE1BQU05QiwyQkFBMkJxQixRQUFRO0FBQUEsSUFDbERVLGlCQUFpQmxCO0FBQUFBLEVBQ25CLENBQUM7QUFFRCxRQUFNbUIsYUFBYUEsTUFBTSxLQUFLWixZQUFZYSxrQkFBa0IsRUFBRUosVUFBVSxDQUFDLGdCQUFnQixTQUFTLFVBQVUsRUFBRSxDQUFDO0FBRS9HLFFBQU1LLGFBQWFOLGdCQUFnQk8sUUFBUTtBQUUzQyxTQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxTQUFTLElBQUlDLFVBQVUsS0FBTUMsUUFBUSxTQUFTLEdBQzNEO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFQyxjQUFjLEdBQUcsR0FDOUM7QUFBQSw2QkFBQyxRQUFLLElBQUcsc0JBQXFCLE9BQU8sRUFBRUMsT0FBTyxvQkFBb0JDLFVBQVUsVUFBVSxHQUFHLGtDQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFQyxnQkFBZ0IsaUJBQWlCQyxZQUFZLFlBQVlDLEtBQUssR0FBRyxHQUM1RztBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFQyxTQUFTLFFBQVFELEtBQUssRUFBRSxHQUNwQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUgsVUFBVSxTQUFTLEdBQUcseUNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFRCxPQUFPLG9CQUFvQkMsVUFBVSxTQUFTLEdBQUcscUdBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNbEIsY0FBYyxJQUFJLEdBQUcsOEJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBRUNLLGdCQUFnQmtCLFdBQVcsdUJBQUMsY0FBVyxPQUFPbEIsZ0JBQWdCbUIsT0FBTyxNQUFLLDBCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFFO0FBQUEsSUFFaEcsQ0FBQ25CLGdCQUFnQm9CLGFBQWFkLFdBQVdlLFdBQVcsS0FBSyxDQUFDckIsZ0JBQWdCa0IsV0FDekU7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1IO0FBQUEsSUFJckgsdUJBQUMsU0FBSSxPQUFPLEVBQUVELFNBQVMsUUFBUUQsS0FBSyxHQUFHLEdBQ3BDVixxQkFBV2dCO0FBQUFBLE1BQUksQ0FBQ0MsYUFDZjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUM7QUFBQSxVQUNBLFNBQVMsTUFBTTFCLFlBQVkwQixRQUFRO0FBQUEsVUFDbkMsVUFBVSxNQUFNeEIsY0FBY3dCLFFBQVE7QUFBQTtBQUFBLFFBSGpDQSxTQUFTQztBQUFBQSxRQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSTBDO0FBQUEsSUFFM0MsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVDOUIsY0FDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFNBQVMsTUFBTUMsY0FBYyxLQUFLO0FBQUEsUUFDbEMsYUFBYSxNQUFNO0FBQ2pCQSx3QkFBYyxLQUFLO0FBQ25CUyxxQkFBVztBQUFBLFFBQ2I7QUFBQTtBQUFBLE1BTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUk7QUFBQSxJQUlMUixZQUFZLHVCQUFDLGlCQUFjLFVBQVVBLFVBQVUsU0FBUyxNQUFNQyxZQUFZLElBQUksS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRTtBQUFBLElBRWhGQyxjQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxVQUFVQTtBQUFBQSxRQUNWLFNBQVMsTUFBTUMsY0FBYyxJQUFJO0FBQUEsUUFDakMsYUFBYSxNQUFNO0FBQ2pCQSx3QkFBYyxJQUFJO0FBQ2xCSyxxQkFBVztBQUFBLFFBQ2I7QUFBQTtBQUFBLE1BTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUk7QUFBQSxPQTVEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0RBO0FBRUo7QUFBQ2IsR0FuRmVELG1CQUFpQjtBQUFBLFVBQ1h0QixnQkFDQ1EsY0FLR1QsUUFBUTtBQUFBO0FBQUEsS0FQbEJ1QjtBQXFGaEIsU0FBU21DLHFCQUFxQjtBQUFBLEVBQzVCRjtBQUFBQSxFQUNBRztBQUFBQSxFQUNBQztBQUtGLEdBQUc7QUFDRCxRQUFNQyxZQUFZTCxTQUFTTSxXQUFXO0FBRXRDLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLGVBQWMsT0FBTyxFQUFFckIsU0FBUyxJQUFJUyxTQUFTLFFBQVFELEtBQUssR0FBRyxHQUM5RTtBQUFBLDJCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFRixnQkFBZ0IsaUJBQWlCRSxLQUFLLEdBQUcsR0FDcEY7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRUMsU0FBUyxRQUFRRCxLQUFLLEVBQUUsR0FDcEM7QUFBQSwrQkFBQyxVQUFLLE9BQU8sRUFBRWMsWUFBWSxLQUFLakIsVUFBVSxVQUFVLEdBQ2pEVTtBQUFBQSxtQkFBU1Esa0JBQWtCLFlBQVlSLFNBQVNDLEVBQUU7QUFBQSxVQUFHO0FBQUEsVUFBSUQsU0FBU1M7QUFBQUEsYUFEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRXBCLE9BQU8sa0JBQWtCQyxVQUFVLFVBQVUsR0FBSVUsbUJBQVNVLG1CQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsV0FKM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWhCLFNBQVMsUUFBUUQsS0FBSyxHQUFHa0IsY0FBYyxNQUFNLEdBQ3pEO0FBQUEsK0JBQUMsZUFBWSxPQUFPN0MsYUFBYWtDLFNBQVNNLE1BQU0sS0FBSyxvQkFDbEQzQyx1QkFBYXFDLFNBQVNNLE1BQU0sS0FBS04sU0FBU00sVUFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsWUFBWSxJQUFJLEdBQzVCUCxtQkFBU1ksWUFBWUMsZUFBZSxTQUFTLEVBQUVDLE9BQU8sWUFBWUMsVUFBVSxNQUFNLENBQUMsS0FEdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBRUNWLGFBQ0MsdUJBQUMsU0FBSSxPQUFPLEVBQUVYLFNBQVMsUUFBUUQsS0FBSyxJQUFJRixnQkFBZ0IsV0FBVyxHQUNqRTtBQUFBLDZCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVNZLFNBQVMsd0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBU0MsVUFBVSxnQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEJBO0FBRUo7QUFBQ1ksTUExQ1FkO0FBNENULFNBQVNlLG1CQUFtQjtBQUFBLEVBQzFCL0M7QUFBQUEsRUFDQWdEO0FBQUFBLEVBQ0FDO0FBS0YsR0FBRztBQUFBQyxNQUFBO0FBQ0QsUUFBTUMsUUFBUW5FLFNBQVM7QUFDdkIsUUFBTSxDQUFDb0UsTUFBTUMsT0FBTyxJQUFJbEYsU0FBNkIsTUFBTTtBQUMzRCxRQUFNLENBQUNtRixPQUFPQyxRQUFRLElBQUlwRixTQUE0QyxJQUFJO0FBRTFFLFFBQU0sQ0FBQ21FLGdCQUFnQmtCLGlCQUFpQixJQUFJckYsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ29FLGNBQWNrQixlQUFlLElBQUl0RixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDdUYsZUFBZUMsZ0JBQWdCLElBQUl4RixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDeUYsYUFBYUMsY0FBYyxJQUFJMUYsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3VFLGFBQWFvQixjQUFjLElBQUkzRixTQUFTLEdBQUc7QUFDbEQsUUFBTSxDQUFDNEYsWUFBWUMsYUFBYSxJQUFJN0YsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzhGLFlBQVlDLGFBQWEsSUFBSS9GLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNnRyxjQUFjQyxlQUFlLElBQUlqRyxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDa0csWUFBWUMsYUFBYSxJQUFJbkcsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ29HLGNBQWNDLGVBQWUsSUFBSXJHLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNzRyxNQUFNQyxPQUFPLElBQUl2RyxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDd0csT0FBT0MsUUFBUSxJQUFJekcsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzBHLFVBQVVDLFdBQVcsSUFBSTNHLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUM0RyxXQUFXQyxZQUFZLElBQUk3RyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDOEcsVUFBVUMsV0FBVyxJQUFJL0csU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2dILGNBQWNDLGVBQWUsSUFBSWpILFNBQVMsR0FBRztBQUNwRCxRQUFNLENBQUNrSCxlQUFlQyxnQkFBZ0IsSUFBSW5ILFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNvSCxPQUFPQyxRQUFRLElBQUlySCxTQUFtQyxFQUFFO0FBRS9ELFFBQU1zSCxpQkFBaUJaLFNBQVNhLEtBQUssTUFBTSxNQUFNWCxVQUFVVyxLQUFLLE1BQU07QUFFdEUsUUFBTUMsZ0JBQWdCdEgsWUFBWTtBQUFBLElBQ2hDdUgsWUFBWUEsTUFBTTtBQUNoQixVQUFJLENBQUNILGVBQWdCLE9BQU0sSUFBSUksTUFBTSxxQkFBcUI7QUFDMUQsYUFBT2pILHNCQUFzQm9CLFVBQVU4RixPQUFPakIsUUFBUSxHQUFHaUIsT0FBT2YsU0FBUyxDQUFDO0FBQUEsSUFDNUU7QUFBQSxJQUNBZ0IsV0FBV0EsQ0FBQ0MsV0FBVztBQUNyQnpDLGVBQVN5QyxNQUFNO0FBQ2YzQyxjQUFRLFNBQVM7QUFBQSxJQUNuQjtBQUFBLElBQ0E0QyxTQUFTQSxNQUFNOUMsTUFBTXpCLE1BQU0sNEVBQTRFO0FBQUEsRUFDekcsQ0FBQztBQUVELFFBQU13RSxrQkFBa0I3SCxZQUFZO0FBQUEsSUFDbEN1SCxZQUFZQSxNQUFNO0FBQ2hCLFVBQUksQ0FBQ3RDLE1BQU8sT0FBTSxJQUFJdUMsTUFBTSxlQUFlO0FBQzNDLGFBQU8vRywyQkFBMkI7QUFBQSxRQUNoQ2tCO0FBQUFBLFFBQ0FzQyxnQkFBZ0JBLGVBQWVvRCxLQUFLLEtBQUtTO0FBQUFBLFFBQ3pDNUQsY0FBY0EsYUFBYW1ELEtBQUs7QUFBQSxRQUNoQ1UsdUJBQXVCMUMsY0FBY2dDLEtBQUs7QUFBQSxRQUMxQ1cscUJBQXFCekMsWUFBWThCLEtBQUs7QUFBQSxRQUN0Q2hELGFBQWFvRCxPQUFPcEQsV0FBVyxLQUFLO0FBQUEsUUFDcEM0RCxTQUFTaEQsTUFBTWdEO0FBQUFBLFFBQ2Z2QyxZQUFZQSxXQUFXMkIsS0FBSztBQUFBLFFBQzVCdkIsY0FBY0EsYUFBYXVCLEtBQUs7QUFBQSxRQUNoQ3pCLFlBQVlBLFdBQVd5QixLQUFLO0FBQUEsUUFDNUJyQixZQUFZQSxXQUFXcUIsS0FBSyxLQUFLUztBQUFBQSxRQUNqQzVCLGNBQWNBLGFBQWFtQixLQUFLO0FBQUEsUUFDaENqQixNQUFNQSxLQUFLaUIsS0FBSztBQUFBLFFBQ2hCZixPQUFPQSxNQUFNZSxLQUFLO0FBQUEsUUFDbEJiLFVBQVVZLGlCQUFpQkssT0FBT2pCLFFBQVEsSUFBSXNCO0FBQUFBLFFBQzlDcEIsV0FBV1UsaUJBQWlCSyxPQUFPZixTQUFTLElBQUlvQjtBQUFBQSxRQUNoRFo7QUFBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLElBQ0FRLFdBQVdBLE1BQU07QUFDZjVDLFlBQU1vRCxRQUFRLGlDQUFpQztBQUMvQ3RELGtCQUFZO0FBQUEsSUFDZDtBQUFBLElBQ0FnRCxTQUFTQSxNQUFNOUMsTUFBTXpCLE1BQU0sNkZBQTZGO0FBQUEsRUFDMUgsQ0FBQztBQUVELFFBQU04RSxVQUFVQSxNQUFNO0FBQ3BCLFFBQUksQ0FBQ3ZCLFNBQVNTLEtBQUssS0FBS0ksT0FBT1QsYUFBYSxLQUFLLEVBQUc7QUFDcERHLGFBQVMsQ0FBQyxHQUFHRCxPQUFPLEVBQUVrQixNQUFNeEIsU0FBU1MsS0FBSyxHQUFHZ0IsVUFBVVosT0FBT1gsWUFBWSxLQUFLLEdBQUd3QixXQUFXYixPQUFPVCxhQUFhLEVBQUUsQ0FBQyxDQUFDO0FBQ3JISCxnQkFBWSxFQUFFO0FBQ2RFLG9CQUFnQixHQUFHO0FBQ25CRSxxQkFBaUIsRUFBRTtBQUFBLEVBQ3JCO0FBRUEsUUFBTXNCLFdBQ0pyRSxhQUFhbUQsS0FBSyxLQUFLaEMsY0FBY2dDLEtBQUssS0FBSzlCLFlBQVk4QixLQUFLLEtBQUszQixXQUFXMkIsS0FBSyxLQUNyRnpCLFdBQVd5QixLQUFLLEtBQUt2QixhQUFhdUIsS0FBSyxLQUFLbkIsYUFBYW1CLEtBQUssS0FBS2pCLEtBQUtpQixLQUFLLEtBQUtmLE1BQU1lLEtBQUssS0FDN0ZELGtCQUFrQkYsTUFBTTNELFNBQVM7QUFFbkMsTUFBSXdCLFNBQVMsYUFBYUUsT0FBTztBQUMvQixXQUNFLHVCQUFDLFNBQU0sU0FBa0IsT0FBTSxxQkFDN0IsaUNBQUMsU0FBSSxPQUFPLEVBQUU5QixTQUFTLFFBQVFELEtBQUssSUFBSXNGLFVBQVUsSUFBSSxHQUNwRDtBQUFBLDZCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRTlGLFNBQVMsSUFBSVMsU0FBUyxRQUFRRCxLQUFLLEVBQUUsR0FDcEU7QUFBQSwrQkFBQyxVQUFLLE9BQU8sRUFBRWMsWUFBWSxJQUFJLEdBQUcsZ0NBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Q7QUFBQSxRQUNsRCx1QkFBQyxVQUFLO0FBQUE7QUFBQSxVQUFRaUIsTUFBTXdELFNBQVNuRSxlQUFlLFNBQVMsRUFBRUMsT0FBTyxZQUFZQyxVQUFVLE1BQU0sQ0FBQztBQUFBLGFBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxRQUM3Rix1QkFBQyxVQUFLO0FBQUE7QUFBQSxVQUNha0UsS0FBS0MsTUFBTTFELE1BQU0yRCxzQkFBc0I7QUFBQSxVQUFFO0FBQUEsVUFBRUYsS0FBS0MsTUFBTTFELE1BQU00RCxzQkFBc0I7QUFBQSxVQUFFO0FBQUEsYUFEdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRS9GLE9BQU8sb0JBQW9CQyxVQUFVLFVBQVUsR0FBRztBQUFBO0FBQUEsV0FBYWtDLE1BQU02RCxpQkFBaUIsS0FBTUMsUUFBUSxDQUFDO0FBQUEsVUFBRTtBQUFBLGFBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUg7QUFBQSxRQUN4SDlELE1BQU0rRCxnQkFDTCx1QkFBQyxVQUFLLE9BQU8sRUFBRWxHLE9BQU8sd0JBQXdCQyxVQUFVLFNBQVMsR0FBRztBQUFBO0FBQUEsVUFDOUMsSUFBSWtHLEtBQUtoRSxNQUFNK0QsWUFBWSxFQUFFRSxtQkFBbUIsT0FBTztBQUFBLFVBQUU7QUFBQSxhQUQvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLFdBQVU7QUFBQSxVQUNWLE9BQU83RTtBQUFBQSxVQUNQLFVBQVUsQ0FBQzhFLE1BQU0xRCxlQUFlMEQsRUFBRUMsT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWtEO0FBQUEsTUFHbEQsdUJBQUMsU0FBSSxPQUFPLEVBQUVsRyxTQUFTLFFBQVFELEtBQUssSUFBSUYsZ0JBQWdCLFdBQVcsR0FDakU7QUFBQSwrQkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTLE1BQU1nQyxRQUFRLE1BQU0sR0FBRyxzQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTNkMsZ0JBQWdCeUIsV0FBVyxTQUFTLE1BQU16QixnQkFBZ0IwQixPQUFPLEdBQUcsb0NBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQSxLQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FBTSxTQUFrQixPQUFNLDBCQUM3QixpQ0FBQyxTQUFJLE9BQU8sRUFBRXBHLFNBQVMsUUFBUUQsS0FBSyxJQUFJc0YsVUFBVSxJQUFJLEdBQ3BEO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLE9BQU92RTtBQUFBQSxRQUNQLFVBQVUsQ0FBQ2tGLE1BQU1oRSxrQkFBa0JnRSxFQUFFQyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxNQUpuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJcUQ7QUFBQSxJQUVyRCx1QkFBQyxhQUFVLE9BQU0sbUJBQWtCLE9BQU9uRixjQUFjLFVBQVUsQ0FBQ2lGLE1BQU0vRCxnQkFBZ0IrRCxFQUFFQyxPQUFPQyxLQUFLLEdBQUcsV0FBUyxRQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1IO0FBQUEsSUFDbkgsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVuRyxLQUFLLEdBQUcsR0FDbkQ7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRXNHLE9BQU8sR0FBRyxHQUN0QixpQ0FBQyxhQUFVLE9BQU0sT0FBTSxXQUFVLFdBQVUsT0FBT25FLGVBQWUsVUFBVSxDQUFDOEQsTUFBTTdELGlCQUFpQjZELEVBQUVDLE9BQU9DLEtBQUssS0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtSCxLQURySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFSSxNQUFNLEdBQUdqQixVQUFVLElBQUksR0FDbkMsaUNBQUMsYUFBVSxPQUFNLFlBQVcsV0FBVSxXQUFVLE9BQU9qRCxhQUFhLFVBQVUsQ0FBQzRELE1BQU0zRCxlQUFlMkQsRUFBRUMsT0FBT0MsS0FBSyxLQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9ILEtBRHRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQSx1QkFBQyxVQUFLLE9BQU8sRUFBRXJGLFlBQVksS0FBSzBGLFdBQVcsRUFBRSxHQUFHLG1DQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1FO0FBQUEsSUFDbkUsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUV4RyxLQUFLLEdBQUcsR0FDbkQ7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRXVHLE1BQU0sR0FBR2pCLFVBQVUsSUFBSSxHQUNuQyxpQ0FBQyxhQUFVLE9BQU0sT0FBTSxPQUFPOUMsWUFBWSxVQUFVLENBQUN5RCxNQUFNeEQsY0FBY3dELEVBQUVDLE9BQU9DLEtBQUssS0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RixLQUQzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFRyxPQUFPLElBQUksR0FDdkIsaUNBQUMsYUFBVSxPQUFNLFVBQVMsT0FBTzFELGNBQWMsVUFBVSxDQUFDcUQsTUFBTXBELGdCQUFnQm9ELEVBQUVDLE9BQU9DLEtBQUssS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRyxLQURsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsYUFBVSxPQUFNLE9BQU0sT0FBT3pELFlBQVksVUFBVSxDQUFDdUQsTUFBTXRELGNBQWNzRCxFQUFFQyxPQUFPQyxLQUFLLEtBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUY7QUFBQSxJQUN6Rix1QkFBQyxhQUFVLE9BQU0sMEJBQXlCLE9BQU9yRCxZQUFZLFVBQVUsQ0FBQ21ELE1BQU1sRCxjQUFja0QsRUFBRUMsT0FBT0MsS0FBSyxLQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRHO0FBQUEsSUFDNUcsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVuRyxLQUFLLEdBQUcsR0FDbkQ7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRXVHLE1BQU0sR0FBR2pCLFVBQVUsSUFBSSxHQUNuQyxpQ0FBQyxhQUFVLE9BQU0sVUFBUyxPQUFPdEMsY0FBYyxVQUFVLENBQUNpRCxNQUFNaEQsZ0JBQWdCZ0QsRUFBRUMsT0FBT0MsS0FBSyxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdHLEtBRGxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVJLE1BQU0sR0FBR2pCLFVBQVUsSUFBSSxHQUNuQyxpQ0FBQyxhQUFVLE9BQU0sVUFBUyxPQUFPcEMsTUFBTSxVQUFVLENBQUMrQyxNQUFNOUMsUUFBUThDLEVBQUVDLE9BQU9DLEtBQUssS0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRixLQURsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFRyxPQUFPLEdBQUcsR0FDdEIsaUNBQUMsYUFBVSxPQUFNLE1BQUssT0FBT2xELE9BQU8sVUFBVSxDQUFDNkMsTUFBTTVDLFNBQVM0QyxFQUFFQyxPQUFPQyxNQUFNTSxZQUFZLENBQUMsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RixLQUQ5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUV6RyxLQUFLLEdBQUcsR0FDbkQ7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRXVHLE1BQU0sR0FBR2pCLFVBQVUsSUFBSSxHQUNuQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sV0FBVTtBQUFBLFVBQ1YsT0FBT2hDO0FBQUFBLFVBQ1AsVUFBVSxDQUFDMkMsTUFBTTFDLFlBQVkwQyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsVUFDM0MsTUFBSztBQUFBO0FBQUEsUUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLK0IsS0FOakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUksTUFBTSxHQUFHakIsVUFBVSxJQUFJLEdBQ25DLGlDQUFDLGFBQVUsT0FBTSxhQUFZLFdBQVUsV0FBVSxPQUFPOUIsV0FBVyxVQUFVLENBQUN5QyxNQUFNeEMsYUFBYXdDLEVBQUVDLE9BQU9DLEtBQUssS0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSCxLQURuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBRUEsdUJBQUMsVUFBSyxPQUFPLEVBQUVyRixZQUFZLEtBQUswRixXQUFXLEVBQUUsR0FBRywrQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRDtBQUFBLElBQzlEeEMsTUFBTTNELFNBQVMsS0FDZCx1QkFBQyxRQUFHLE9BQU8sRUFBRVgsUUFBUSxHQUFHZ0gsYUFBYSxJQUFJekcsU0FBUyxRQUFRRCxLQUFLLEVBQUUsR0FDOURnRSxnQkFBTTFEO0FBQUFBLE1BQUksQ0FBQ3FHLE1BQU1DLFFBQ2hCLHVCQUFDLFFBQWEsT0FBTyxFQUFFL0csVUFBVSxTQUFTLEdBQ3ZDOEc7QUFBQUEsYUFBS3hCO0FBQUFBLFFBQVM7QUFBQSxRQUFHd0IsS0FBS3pCO0FBQUFBLFFBQUs7QUFBQSxRQUFHO0FBQUEsU0FDN0J5QixLQUFLdkIsWUFBWXVCLEtBQUt4QixVQUFVL0QsZUFBZSxTQUFTLEVBQUVDLE9BQU8sWUFBWUMsVUFBVSxNQUFNLENBQUM7QUFBQSxXQUZ6RnNGLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsSUFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUYsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUU1RyxLQUFLLElBQUlELFlBQVksV0FBVyxHQUMzRTtBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFd0csTUFBTSxHQUFHakIsVUFBVSxJQUFJLEdBQ25DLGlDQUFDLGFBQVUsT0FBTSxRQUFPLE9BQU81QixVQUFVLFVBQVUsQ0FBQ3VDLE1BQU10QyxZQUFZc0MsRUFBRUMsT0FBT0MsS0FBSyxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNGLEtBRHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVHLE9BQU8sR0FBRyxHQUN0QixpQ0FBQyxhQUFVLE9BQU0sT0FBTSxXQUFVLFdBQVUsT0FBTzFDLGNBQWMsVUFBVSxDQUFDcUMsTUFBTXBDLGdCQUFnQm9DLEVBQUVDLE9BQU9DLEtBQUssS0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSCxLQURuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFRyxPQUFPLElBQUksR0FDdkIsaUNBQUMsYUFBVSxPQUFNLGVBQWMsV0FBVSxXQUFVLE9BQU94QyxlQUFlLFVBQVUsQ0FBQ21DLE1BQU1sQyxpQkFBaUJrQyxFQUFFQyxPQUFPQyxLQUFLLEtBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkgsS0FEN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTbEIsU0FBUyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFaEYsU0FBUyxRQUFRRCxLQUFLLElBQUlGLGdCQUFnQixZQUFZMEcsV0FBVyxFQUFFLEdBQy9FO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUy9FLFNBQVMsc0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxTQUFRLFdBQVUsVUFBVSxDQUFDNEQsVUFBVSxTQUFTakIsY0FBY2dDLFdBQVcsU0FBUyxNQUFNaEMsY0FBY2lDLE9BQU8sR0FBRyw2QkFBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQXZGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0ZBLEtBekZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwRkE7QUFFSjtBQUFDMUUsSUE1TlFILG9CQUFrQjtBQUFBLFVBU1gvRCxVQXlCUVgsYUFZRUEsV0FBVztBQUFBO0FBQUEsTUE5QzVCMEU7QUE4TlQsU0FBU3FGLGNBQWMsRUFBRXRHLFVBQVVrQixRQUEwRSxHQUFHO0FBQUFxRixNQUFBO0FBQzlHLFFBQU1DLGdCQUFnQmhLLFNBQVM7QUFBQSxJQUM3QmtDLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxxQkFBcUJzQixTQUFTQyxFQUFFO0FBQUEsSUFDcEV0QixTQUFTQSxNQUFNNUIseUJBQXlCaUQsU0FBU0MsRUFBRTtBQUFBLElBQ25EckIsaUJBQWlCO0FBQUEsRUFDbkIsQ0FBQztBQUVELFFBQU02SCxhQUFhakssU0FBUztBQUFBLElBQzFCa0MsVUFBVSxDQUFDLGdCQUFnQixTQUFTLHVCQUF1QnNCLFNBQVNDLEVBQUU7QUFBQSxJQUN0RXRCLFNBQVNBLE1BQU1oQywwQkFBMEJxRCxTQUFTQyxFQUFFO0FBQUEsRUFDdEQsQ0FBQztBQUVELFFBQU01QixXQUFXbUksY0FBY3hIO0FBRS9CLFNBQ0UsdUJBQUMsU0FBTSxTQUFrQixPQUFPLFlBQVlnQixTQUFTUSxrQkFBa0IsWUFBWVIsU0FBU0MsRUFBRSxFQUFFLElBQzlGLGlDQUFDLFNBQUksT0FBTyxFQUFFUCxTQUFTLFFBQVFELEtBQUssSUFBSXNGLFVBQVUsSUFBSSxHQUNuRHlCO0FBQUFBLGtCQUFjN0csV0FBVyx1QkFBQyxjQUFXLE9BQU82RyxjQUFjNUcsT0FBTyxNQUFLLG9CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZEO0FBQUEsSUFDdEY0RyxjQUFjM0csYUFBYSx1QkFBQyxVQUFLLE9BQU8sRUFBRVIsT0FBTyxtQkFBbUIsR0FBRywyQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RDtBQUFBLElBQ2xGaEIsWUFDQyx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVZLFNBQVMsSUFBSVMsU0FBUyxRQUFRRCxLQUFLLEVBQUUsR0FDbkVwQjtBQUFBQSxlQUFTMEUsWUFBWSxRQUFRMUUsU0FBUzRFLGFBQWEsT0FDbEQsdUJBQUMsVUFBSztBQUFBO0FBQUEsUUFDb0I1RSxTQUFTMEUsU0FBU3VDLFFBQVEsQ0FBQztBQUFBLFFBQUU7QUFBQSxRQUFHakgsU0FBUzRFLFVBQVVxQyxRQUFRLENBQUM7QUFBQSxXQUR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFFQSx1QkFBQyxVQUFLLE9BQU8sRUFBRWpHLE9BQU8sbUJBQW1CLEdBQUcsNkNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUUxRWhCLFNBQVNxSSxvQkFDUix1QkFBQyxVQUFLO0FBQUE7QUFBQSxRQUFzQixJQUFJbEIsS0FBS25ILFNBQVNxSSxnQkFBZ0IsRUFBRWpCLG1CQUFtQixPQUFPO0FBQUEsV0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RjtBQUFBLFNBVGhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBRURnQixXQUFXekgsTUFBTTJILFNBQ2hCLHVCQUFDLFVBQUssT0FBTyxFQUFFdEgsT0FBTyxvQkFBb0JDLFVBQVUsVUFBVSxHQUFHO0FBQUE7QUFBQSxNQUFpQ21ILFdBQVd6SCxLQUFLMkg7QUFBQUEsU0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3SDtBQUFBLElBRXpIM0csU0FBUzRHLGVBQ1IsdUJBQUMsT0FBRSxNQUFNNUcsU0FBUzRHLGFBQWEsUUFBTyxVQUFTLEtBQUksY0FBYSxPQUFPLEVBQUV0SCxVQUFVLFNBQVMsR0FBRyxzREFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFRix1QkFBQyxTQUFJLE9BQU8sRUFBRUksU0FBUyxRQUFRSCxnQkFBZ0IsV0FBVyxHQUN4RCxpQ0FBQyxVQUFPLFNBQVEsU0FBUSxTQUFTMkIsU0FBUyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQSxLQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0NBO0FBRUo7QUFBQ3FGLElBakRRRCxlQUFhO0FBQUEsVUFDRTlKLFVBTUhBLFFBQVE7QUFBQTtBQUFBLE1BUHBCOEo7QUFtRFQsU0FBU08sb0JBQW9CO0FBQUEsRUFDM0I3RztBQUFBQSxFQUNBa0I7QUFBQUEsRUFDQTRGO0FBS0YsR0FBRztBQUFBQyxNQUFBO0FBQ0QsUUFBTTFGLFFBQVFuRSxTQUFTO0FBQ3ZCLFFBQU0sQ0FBQzhKLGNBQWNDLGVBQWUsSUFBSTVLLFNBQVMsRUFBRTtBQUVuRCxRQUFNNkssZUFBZTFLLFNBQVM7QUFBQSxJQUM1QmtDLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxpQ0FBaUNzQixTQUFTQyxFQUFFO0FBQUEsSUFDaEZ0QixTQUFTQSxNQUFNL0Isb0NBQW9Db0QsU0FBU0MsRUFBRTtBQUFBLEVBQ2hFLENBQUM7QUFFRCxRQUFNa0gsaUJBQWlCNUssWUFBWTtBQUFBLElBQ2pDdUgsWUFBWUEsTUFBTTtBQUNoQixZQUFNc0QsU0FBU0YsYUFBYWxJLE1BQU1xSSxLQUFLLENBQUNDLE1BQU1BLEVBQUVOLGlCQUFpQkEsWUFBWTtBQUM3RSxhQUFPdEssNEJBQTRCc0QsU0FBU0MsSUFBSW1ILFFBQVFHLGVBQWUsMEJBQTBCdkQsT0FBT2dELFlBQVksS0FBSyxDQUFDO0FBQUEsSUFDNUg7QUFBQSxJQUNBL0MsV0FBV0EsTUFBTTtBQUNmNUMsWUFBTW9ELFFBQVEsNkJBQTZCO0FBQzNDcUMsa0JBQVk7QUFBQSxJQUNkO0FBQUEsSUFDQTNDLFNBQVNBLE1BQU05QyxNQUFNekIsTUFBTSxzQ0FBc0M7QUFBQSxFQUNuRSxDQUFDO0FBRUQsUUFBTTRILFVBQVVOLGFBQWFsSSxRQUFRO0FBRXJDLFNBQ0UsdUJBQUMsU0FBTSxTQUFrQixPQUFPLFlBQVlnQixTQUFTUSxrQkFBa0IsWUFBWVIsU0FBU0MsRUFBRSxFQUFFLElBQzlGLGlDQUFDLFNBQUksT0FBTyxFQUFFUCxTQUFTLFFBQVFELEtBQUssSUFBSXNGLFVBQVUsSUFBSSxHQUNuRG1DO0FBQUFBLGlCQUFhdkgsV0FBVyx1QkFBQyxjQUFXLE9BQU91SCxhQUFhdEgsT0FBTyxNQUFLLGdDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdFO0FBQUEsSUFFakc7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLE9BQU9vSDtBQUFBQSxRQUNQLFVBQVUsQ0FBQ3RCLE1BQU11QixnQkFBZ0J2QixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsUUFDL0MsVUFBVXNCLGFBQWFySDtBQUFBQSxRQUV2QjtBQUFBLGlDQUFDLFlBQU8sT0FBTSxJQUFHLG9DQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBLFVBQ3BDMkgsUUFBUXpIO0FBQUFBLFlBQUksQ0FBQ3FILFdBQ1osdUJBQUMsWUFBaUMsT0FBT0EsT0FBT0osY0FDN0NJLGlCQUFPRyxlQURHSCxPQUFPSixjQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsVUFDRDtBQUFBO0FBQUE7QUFBQSxNQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVlBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXRILFNBQVMsUUFBUUQsS0FBSyxJQUFJRixnQkFBZ0IsV0FBVyxHQUNqRTtBQUFBLDZCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVMyQixTQUFTLHNCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixVQUFVLENBQUM4RjtBQUFBQSxVQUNYLFNBQVNHLGVBQWV0QjtBQUFBQSxVQUN4QixTQUFTLE1BQU1zQixlQUFlckIsT0FBTztBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQ0E7QUFFSjtBQUFDaUIsSUFsRVFGLHFCQUFtQjtBQUFBLFVBU1ozSixVQUdPVixVQUtFRCxXQUFXO0FBQUE7QUFBQSxNQWpCM0JzSztBQUFtQixJQUFBWSxJQUFBekcsS0FBQTBHLEtBQUFDLEtBQUFDO0FBQUEsYUFBQUgsSUFBQTtBQUFBLGFBQUF6RyxLQUFBO0FBQUEsYUFBQTBHLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsImNhbmNlbElGb29kU2hpcHBpbmdEZWxpdmVyeSIsImdldElGb29kU2FmZURlbGl2ZXJ5U2NvcmUiLCJnZXRJRm9vZFNoaXBwaW5nQ2FuY2VsbGF0aW9uUmVhc29ucyIsImdldElGb29kU2hpcHBpbmdEZWxpdmVyaWVzIiwiZ2V0SUZvb2RTaGlwcGluZ1F1b3RlIiwiZ2V0SUZvb2RTaGlwcGluZ1RyYWNraW5nIiwicmVxdWVzdElGb29kU2hpcHBpbmdEcml2ZXIiLCJ1c2VBdXRoU3RvcmUiLCJ1c2VUb2FzdCIsIkJ1dHRvbiIsIlN0YXR1c0JhZGdlIiwiTW9kYWwiLCJTZWxlY3RGaWVsZCIsIlRleHRGaWVsZCIsIlF1ZXJ5RXJyb3IiLCJFbXB0eVN0YXRlIiwiUkVGUkVTSF9JTlRFUlZBTF9NUyIsIlNUQVRVU19MQUJFTCIsIkRSSVZFUl9SRVFVRVNURUQiLCJDQU5DRUxMRUQiLCJTVEFUVVNfQ09MT1IiLCJJRm9vZFNoaXBwaW5nUGFnZSIsIl9zIiwicXVlcnlDbGllbnQiLCJicmFuY2hJZCIsInJlcXVlc3RpbmciLCJzZXRSZXF1ZXN0aW5nIiwidHJhY2tpbmciLCJzZXRUcmFja2luZyIsImNhbmNlbGxpbmciLCJzZXRDYW5jZWxsaW5nIiwiZGVsaXZlcmllc1F1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicmVmZXRjaEludGVydmFsIiwiaW52YWxpZGF0ZSIsImludmFsaWRhdGVRdWVyaWVzIiwiZGVsaXZlcmllcyIsImRhdGEiLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJtYXJnaW5Cb3R0b20iLCJjb2xvciIsImZvbnRTaXplIiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwiZGlzcGxheSIsImlzRXJyb3IiLCJlcnJvciIsImlzTG9hZGluZyIsImxlbmd0aCIsIm1hcCIsImRlbGl2ZXJ5IiwiaWQiLCJTaGlwcGluZ0RlbGl2ZXJ5Q2FyZCIsIm9uVHJhY2siLCJvbkNhbmNlbCIsImNhbkNhbmNlbCIsInN0YXR1cyIsImZvbnRXZWlnaHQiLCJvcmRlclJlZmVyZW5jZSIsImN1c3RvbWVyTmFtZSIsImRlbGl2ZXJ5QWRkcmVzcyIsImp1c3RpZnlJdGVtcyIsIm1lcmNoYW50RmVlIiwidG9Mb2NhbGVTdHJpbmciLCJzdHlsZSIsImN1cnJlbmN5IiwiX2MyIiwiUmVxdWVzdERyaXZlck1vZGFsIiwib25DbG9zZSIsIm9uUmVxdWVzdGVkIiwiX3MyIiwidG9hc3QiLCJzdGVwIiwic2V0U3RlcCIsInF1b3RlIiwic2V0UXVvdGUiLCJzZXRPcmRlclJlZmVyZW5jZSIsInNldEN1c3RvbWVyTmFtZSIsInBob25lQXJlYUNvZGUiLCJzZXRQaG9uZUFyZWFDb2RlIiwicGhvbmVOdW1iZXIiLCJzZXRQaG9uZU51bWJlciIsInNldE1lcmNoYW50RmVlIiwicG9zdGFsQ29kZSIsInNldFBvc3RhbENvZGUiLCJzdHJlZXROYW1lIiwic2V0U3RyZWV0TmFtZSIsInN0cmVldE51bWJlciIsInNldFN0cmVldE51bWJlciIsImNvbXBsZW1lbnQiLCJzZXRDb21wbGVtZW50IiwibmVpZ2hib3Job29kIiwic2V0TmVpZ2hib3Job29kIiwiY2l0eSIsInNldENpdHkiLCJzdGF0ZSIsInNldFN0YXRlIiwibGF0aXR1ZGUiLCJzZXRMYXRpdHVkZSIsImxvbmdpdHVkZSIsInNldExvbmdpdHVkZSIsIml0ZW1OYW1lIiwic2V0SXRlbU5hbWUiLCJpdGVtUXVhbnRpdHkiLCJzZXRJdGVtUXVhbnRpdHkiLCJpdGVtVW5pdFByaWNlIiwic2V0SXRlbVVuaXRQcmljZSIsIml0ZW1zIiwic2V0SXRlbXMiLCJoYXNDb29yZGluYXRlcyIsInRyaW0iLCJxdW90ZU11dGF0aW9uIiwibXV0YXRpb25GbiIsIkVycm9yIiwiTnVtYmVyIiwib25TdWNjZXNzIiwicmVzdWx0Iiwib25FcnJvciIsInJlcXVlc3RNdXRhdGlvbiIsInVuZGVmaW5lZCIsImN1c3RvbWVyUGhvbmVBcmVhQ29kZSIsImN1c3RvbWVyUGhvbmVOdW1iZXIiLCJxdW90ZUlkIiwic3VjY2VzcyIsImFkZEl0ZW0iLCJuYW1lIiwicXVhbnRpdHkiLCJ1bml0UHJpY2UiLCJjYW5RdW90ZSIsIm1pbldpZHRoIiwibmV0VmFsdWUiLCJNYXRoIiwicm91bmQiLCJkZWxpdmVyeVRpbWVNaW5NaW51dGVzIiwiZGVsaXZlcnlUaW1lTWF4TWludXRlcyIsImRpc3RhbmNlTWV0ZXJzIiwidG9GaXhlZCIsImV4cGlyYXRpb25BdCIsIkRhdGUiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJpc1BlbmRpbmciLCJtdXRhdGUiLCJ3aWR0aCIsImZsZXgiLCJtYXJnaW5Ub3AiLCJ0b1VwcGVyQ2FzZSIsInBhZGRpbmdMZWZ0IiwiaXRlbSIsImlkeCIsIlRyYWNraW5nTW9kYWwiLCJfczMiLCJ0cmFja2luZ1F1ZXJ5Iiwic2NvcmVRdWVyeSIsImV4cGVjdGVkRGVsaXZlcnkiLCJzY29yZSIsInRyYWNraW5nVXJsIiwiQ2FuY2VsRGVsaXZlcnlNb2RhbCIsIm9uQ2FuY2VsbGVkIiwiX3M0IiwiY2FuY2VsQ29kZUlkIiwic2V0Q2FuY2VsQ29kZUlkIiwicmVhc29uc1F1ZXJ5IiwiY2FuY2VsTXV0YXRpb24iLCJyZWFzb24iLCJmaW5kIiwiciIsImRlc2NyaXB0aW9uIiwicmVhc29ucyIsIl9jIiwiX2MzIiwiX2M0IiwiX2M1Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIklGb29kU2hpcHBpbmdQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHtcclxuICBjYW5jZWxJRm9vZFNoaXBwaW5nRGVsaXZlcnksXHJcbiAgZ2V0SUZvb2RTYWZlRGVsaXZlcnlTY29yZSxcclxuICBnZXRJRm9vZFNoaXBwaW5nQ2FuY2VsbGF0aW9uUmVhc29ucyxcclxuICBnZXRJRm9vZFNoaXBwaW5nRGVsaXZlcmllcyxcclxuICBnZXRJRm9vZFNoaXBwaW5nUXVvdGUsXHJcbiAgZ2V0SUZvb2RTaGlwcGluZ1RyYWNraW5nLFxyXG4gIHJlcXVlc3RJRm9vZFNoaXBwaW5nRHJpdmVyLFxyXG4gIHR5cGUgSUZvb2RTaGlwcGluZ0RlbGl2ZXJ5UmVzcG9uc2UsXHJcbiAgdHlwZSBJRm9vZFNoaXBwaW5nSXRlbUlucHV0LFxyXG4gIHR5cGUgSUZvb2RTaGlwcGluZ1F1b3RlUmVzcG9uc2UsXHJcbn0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIi4uLy4uL3VpL1RvYXN0XCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCIuLi8uLi91aS9CdXR0b25cIjtcclxuaW1wb3J0IHsgU3RhdHVzQmFkZ2UgfSBmcm9tIFwiLi4vLi4vdWkvU3RhdHVzQmFkZ2VcIjtcclxuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiLi4vLi4vdWkvTW9kYWxcIjtcclxuaW1wb3J0IHsgU2VsZWN0RmllbGQsIFRleHRGaWVsZCB9IGZyb20gXCIuLi8uLi91aS9GaWVsZFwiO1xyXG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xyXG5pbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSBcIi4uLy4uL3VpL0VtcHR5U3RhdGVcIjtcclxuXHJcbi8vIEZhc2UgOCDigJQgU2hpcHBpbmc6IHBlZGUgdW0gZW50cmVnYWRvciBkbyBpRm9vZCBwcmEgdW0gcGVkaWRvIGRlIE9VVFJPIGNhbmFsICh0ZWxlZm9uZSxcclxuLy8gV2hhdHNBcHAsIGJhbGPDo28pLiBEaWZlcmVudGUgZGEgdGVsYSBcIlBlZGlkb3MgaUZvb2RcIiAoZmFzZSA3LCBmcm90YSBwcsOzcHJpYSBlbnRyZWdhbmRvIHBlZGlkb1xyXG4vLyBRVUUgVkVJTyBkbyBpRm9vZCksIGFxdWkgw6kgbyBpbnZlcnNvIOKAlCBvIHBlZGlkbyBudW5jYSBleGlzdGl1IG5vIGlGb29kLCBzw7MgYSBlbnRyZWdhIMOpIGZlaXRhXHJcbi8vIHBlbG9zIGVudHJlZ2Fkb3JlcyBkZWxlLiBPIGlGb29kIG7Do28gZGV2b2x2ZSB1bSBcInN0YXR1c1wiIGRlIGVudHJlZ2EgbmVzdGUgbcOzZHVsbyAoc8OzIG8gaWQgK1xyXG4vLyB0cmFja2luZ1VybCBuYSBjcmlhw6fDo28sIGUgbGF0L2xvbmcgZW0gL3RyYWNraW5nKSwgZW50w6NvIG8gc3RhdHVzIGFxdWkgc8OzIHJlZmxldGUgc2UgYSBlbnRyZWdhXHJcbi8vIGFpbmRhIGVzdMOhIGF0aXZhIG91IGZvaSBjYW5jZWxhZGEgcGVsbyBTeW5jQmFyLlxyXG5jb25zdCBSRUZSRVNIX0lOVEVSVkFMX01TID0gMjBfMDAwO1xyXG5cclxuY29uc3QgU1RBVFVTX0xBQkVMOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gIERSSVZFUl9SRVFVRVNURUQ6IFwiRW50cmVnYWRvciBzb2xpY2l0YWRvXCIsXHJcbiAgQ0FOQ0VMTEVEOiBcIkNhbmNlbGFkYVwiLFxyXG59O1xyXG5cclxuY29uc3QgU1RBVFVTX0NPTE9SOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gIERSSVZFUl9SRVFVRVNURUQ6IFwidmFyKC0tb2spXCIsXHJcbiAgQ0FOQ0VMTEVEOiBcInZhcigtLWRhbmdlcilcIixcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJRm9vZFNoaXBwaW5nUGFnZSgpIHtcclxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgY29uc3QgeyBicmFuY2hJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgY29uc3QgW3JlcXVlc3RpbmcsIHNldFJlcXVlc3RpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt0cmFja2luZywgc2V0VHJhY2tpbmddID0gdXNlU3RhdGU8SUZvb2RTaGlwcGluZ0RlbGl2ZXJ5UmVzcG9uc2UgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbY2FuY2VsbGluZywgc2V0Q2FuY2VsbGluZ10gPSB1c2VTdGF0ZTxJRm9vZFNoaXBwaW5nRGVsaXZlcnlSZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBkZWxpdmVyaWVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJzaGlwcGluZ1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZFNoaXBwaW5nRGVsaXZlcmllcyhicmFuY2hJZCksXHJcbiAgICByZWZldGNoSW50ZXJ2YWw6IFJFRlJFU0hfSU5URVJWQUxfTVMsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGludmFsaWRhdGUgPSAoKSA9PiB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwic2hpcHBpbmdcIl0gfSk7XHJcblxyXG4gIGNvbnN0IGRlbGl2ZXJpZXMgPSBkZWxpdmVyaWVzUXVlcnkuZGF0YSA/PyBbXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIHN0eWxlPXt7IHBhZGRpbmc6IDIyLCBtYXhXaWR0aDogMTAwMCwgbWFyZ2luOiBcIjAgYXV0b1wiIH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2VcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDE4IH19PlxyXG4gICAgICAgIDxMaW5rIHRvPVwiL2ludGVncmFjb2VzL2lmb29kXCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+XHJcbiAgICAgICAgICDihpAgSW50ZWdyYcOnw6NvIGlGb29kXHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBhbGlnbkl0ZW1zOiBcImZsZXgtZW5kXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS43cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgRW50cmVnYXMgaUZvb2QgKFNoaXBwaW5nKVxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgIHBlw6dhIHVtIGVudHJlZ2Fkb3IgZG8gaUZvb2QgcHJhIHVtIHBlZGlkbyBkZSBvdXRybyBjYW5hbCAodGVsZWZvbmUsIFdoYXRzQXBwLCBiYWxjw6NvKVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXRSZXF1ZXN0aW5nKHRydWUpfT5cclxuICAgICAgICAgICAgKyBOb3ZhIGVudHJlZ2FcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtkZWxpdmVyaWVzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17ZGVsaXZlcmllc1F1ZXJ5LmVycm9yfSB3aGF0PVwiYXMgZW50cmVnYXMgZG8gaUZvb2RcIiAvPn1cclxuXHJcbiAgICAgIHshZGVsaXZlcmllc1F1ZXJ5LmlzTG9hZGluZyAmJiBkZWxpdmVyaWVzLmxlbmd0aCA9PT0gMCAmJiAhZGVsaXZlcmllc1F1ZXJ5LmlzRXJyb3IgJiYgKFxyXG4gICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICB0aXRsZT1cIk5lbmh1bWEgZW50cmVnYSBlbSBhYmVydG9cIlxyXG4gICAgICAgICAgZGVzY3JpcHRpb249XCJQZcOnYSB1bSBlbnRyZWdhZG9yIGRvIGlGb29kIHByYSB1bSBwZWRpZG8gZGUgdGVsZWZvbmUsIFdoYXRzQXBwIG91IGJhbGPDo28gcXVlIHByZWNpc2Ugc2VyIGVudHJlZ3VlLlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAge2RlbGl2ZXJpZXMubWFwKChkZWxpdmVyeSkgPT4gKFxyXG4gICAgICAgICAgPFNoaXBwaW5nRGVsaXZlcnlDYXJkXHJcbiAgICAgICAgICAgIGtleT17ZGVsaXZlcnkuaWR9XHJcbiAgICAgICAgICAgIGRlbGl2ZXJ5PXtkZWxpdmVyeX1cclxuICAgICAgICAgICAgb25UcmFjaz17KCkgPT4gc2V0VHJhY2tpbmcoZGVsaXZlcnkpfVxyXG4gICAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0Q2FuY2VsbGluZyhkZWxpdmVyeSl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtyZXF1ZXN0aW5nICYmIChcclxuICAgICAgICA8UmVxdWVzdERyaXZlck1vZGFsXHJcbiAgICAgICAgICBicmFuY2hJZD17YnJhbmNoSWR9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRSZXF1ZXN0aW5nKGZhbHNlKX1cclxuICAgICAgICAgIG9uUmVxdWVzdGVkPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFJlcXVlc3RpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICBpbnZhbGlkYXRlKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7dHJhY2tpbmcgJiYgPFRyYWNraW5nTW9kYWwgZGVsaXZlcnk9e3RyYWNraW5nfSBvbkNsb3NlPXsoKSA9PiBzZXRUcmFja2luZyhudWxsKX0gLz59XHJcblxyXG4gICAgICB7Y2FuY2VsbGluZyAmJiAoXHJcbiAgICAgICAgPENhbmNlbERlbGl2ZXJ5TW9kYWxcclxuICAgICAgICAgIGRlbGl2ZXJ5PXtjYW5jZWxsaW5nfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0Q2FuY2VsbGluZyhudWxsKX1cclxuICAgICAgICAgIG9uQ2FuY2VsbGVkPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldENhbmNlbGxpbmcobnVsbCk7XHJcbiAgICAgICAgICAgIGludmFsaWRhdGUoKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBTaGlwcGluZ0RlbGl2ZXJ5Q2FyZCh7XHJcbiAgZGVsaXZlcnksXHJcbiAgb25UcmFjayxcclxuICBvbkNhbmNlbCxcclxufToge1xyXG4gIGRlbGl2ZXJ5OiBJRm9vZFNoaXBwaW5nRGVsaXZlcnlSZXNwb25zZTtcclxuICBvblRyYWNrOiAoKSA9PiB2b2lkO1xyXG4gIG9uQ2FuY2VsOiAoKSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgY29uc3QgY2FuQ2FuY2VsID0gZGVsaXZlcnkuc3RhdHVzICE9PSBcIkNBTkNFTExFRFwiO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidGlja2V0IHJpc2VcIiBzdHlsZT17eyBwYWRkaW5nOiAxOCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDcwMCwgZm9udFNpemU6IFwiMS4wNXJlbVwiIH19PlxyXG4gICAgICAgICAgICB7ZGVsaXZlcnkub3JkZXJSZWZlcmVuY2UgPz8gYEVudHJlZ2EgIyR7ZGVsaXZlcnkuaWR9YH0g4oCUIHtkZWxpdmVyeS5jdXN0b21lck5hbWV9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+e2RlbGl2ZXJ5LmRlbGl2ZXJ5QWRkcmVzc308L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA2LCBqdXN0aWZ5SXRlbXM6IFwiZW5kXCIgfX0+XHJcbiAgICAgICAgICA8U3RhdHVzQmFkZ2UgY29sb3I9e1NUQVRVU19DT0xPUltkZWxpdmVyeS5zdGF0dXNdID8/IFwidmFyKC0taW5rLWZhaW50KVwifT5cclxuICAgICAgICAgICAge1NUQVRVU19MQUJFTFtkZWxpdmVyeS5zdGF0dXNdID8/IGRlbGl2ZXJ5LnN0YXR1c31cclxuICAgICAgICAgIDwvU3RhdHVzQmFkZ2U+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAgfX0+XHJcbiAgICAgICAgICAgIHtkZWxpdmVyeS5tZXJjaGFudEZlZS50b0xvY2FsZVN0cmluZyhcInB0LUJSXCIsIHsgc3R5bGU6IFwiY3VycmVuY3lcIiwgY3VycmVuY3k6IFwiQlJMXCIgfSl9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge2NhbkNhbmNlbCAmJiAoXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25UcmFja30+XHJcbiAgICAgICAgICAgIFJhc3RyZWFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DYW5jZWx9PlxyXG4gICAgICAgICAgICBDYW5jZWxhciBlbnRyZWdhXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBSZXF1ZXN0RHJpdmVyTW9kYWwoe1xyXG4gIGJyYW5jaElkLFxyXG4gIG9uQ2xvc2UsXHJcbiAgb25SZXF1ZXN0ZWQsXHJcbn06IHtcclxuICBicmFuY2hJZDogbnVtYmVyO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25SZXF1ZXN0ZWQ6ICgpID0+IHZvaWQ7XHJcbn0pIHtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgW3N0ZXAsIHNldFN0ZXBdID0gdXNlU3RhdGU8XCJmb3JtXCIgfCBcImNvbmZpcm1cIj4oXCJmb3JtXCIpO1xyXG4gIGNvbnN0IFtxdW90ZSwgc2V0UXVvdGVdID0gdXNlU3RhdGU8SUZvb2RTaGlwcGluZ1F1b3RlUmVzcG9uc2UgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3QgW29yZGVyUmVmZXJlbmNlLCBzZXRPcmRlclJlZmVyZW5jZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY3VzdG9tZXJOYW1lLCBzZXRDdXN0b21lck5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Bob25lQXJlYUNvZGUsIHNldFBob25lQXJlYUNvZGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Bob25lTnVtYmVyLCBzZXRQaG9uZU51bWJlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbWVyY2hhbnRGZWUsIHNldE1lcmNoYW50RmVlXSA9IHVzZVN0YXRlKFwiMFwiKTtcclxuICBjb25zdCBbcG9zdGFsQ29kZSwgc2V0UG9zdGFsQ29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc3RyZWV0TmFtZSwgc2V0U3RyZWV0TmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc3RyZWV0TnVtYmVyLCBzZXRTdHJlZXROdW1iZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2NvbXBsZW1lbnQsIHNldENvbXBsZW1lbnRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW25laWdoYm9yaG9vZCwgc2V0TmVpZ2hib3Job29kXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjaXR5LCBzZXRDaXR5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzdGF0ZSwgc2V0U3RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2xhdGl0dWRlLCBzZXRMYXRpdHVkZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbG9uZ2l0dWRlLCBzZXRMb25naXR1ZGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2l0ZW1OYW1lLCBzZXRJdGVtTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaXRlbVF1YW50aXR5LCBzZXRJdGVtUXVhbnRpdHldID0gdXNlU3RhdGUoXCIxXCIpO1xyXG4gIGNvbnN0IFtpdGVtVW5pdFByaWNlLCBzZXRJdGVtVW5pdFByaWNlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGU8SUZvb2RTaGlwcGluZ0l0ZW1JbnB1dFtdPihbXSk7XHJcblxyXG4gIGNvbnN0IGhhc0Nvb3JkaW5hdGVzID0gbGF0aXR1ZGUudHJpbSgpICE9PSBcIlwiICYmIGxvbmdpdHVkZS50cmltKCkgIT09IFwiXCI7XHJcblxyXG4gIGNvbnN0IHF1b3RlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiB7XHJcbiAgICAgIGlmICghaGFzQ29vcmRpbmF0ZXMpIHRocm93IG5ldyBFcnJvcihcIm1pc3NpbmctY29vcmRpbmF0ZXNcIik7XHJcbiAgICAgIHJldHVybiBnZXRJRm9vZFNoaXBwaW5nUXVvdGUoYnJhbmNoSWQsIE51bWJlcihsYXRpdHVkZSksIE51bWJlcihsb25naXR1ZGUpKTtcclxuICAgIH0sXHJcbiAgICBvblN1Y2Nlc3M6IChyZXN1bHQpID0+IHtcclxuICAgICAgc2V0UXVvdGUocmVzdWx0KTtcclxuICAgICAgc2V0U3RlcChcImNvbmZpcm1cIik7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgY290YXIgYSBlbnRyZWdhIOKAlCBjb25maXJhIGFzIGNvb3JkZW5hZGFzIGUgdGVudGUgZGUgbm92by5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJlcXVlc3RNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHtcclxuICAgICAgaWYgKCFxdW90ZSkgdGhyb3cgbmV3IEVycm9yKFwibWlzc2luZy1xdW90ZVwiKTtcclxuICAgICAgcmV0dXJuIHJlcXVlc3RJRm9vZFNoaXBwaW5nRHJpdmVyKHtcclxuICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICBvcmRlclJlZmVyZW5jZTogb3JkZXJSZWZlcmVuY2UudHJpbSgpIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICBjdXN0b21lck5hbWU6IGN1c3RvbWVyTmFtZS50cmltKCksXHJcbiAgICAgICAgY3VzdG9tZXJQaG9uZUFyZWFDb2RlOiBwaG9uZUFyZWFDb2RlLnRyaW0oKSxcclxuICAgICAgICBjdXN0b21lclBob25lTnVtYmVyOiBwaG9uZU51bWJlci50cmltKCksXHJcbiAgICAgICAgbWVyY2hhbnRGZWU6IE51bWJlcihtZXJjaGFudEZlZSkgfHwgMCxcclxuICAgICAgICBxdW90ZUlkOiBxdW90ZS5xdW90ZUlkLFxyXG4gICAgICAgIHBvc3RhbENvZGU6IHBvc3RhbENvZGUudHJpbSgpLFxyXG4gICAgICAgIHN0cmVldE51bWJlcjogc3RyZWV0TnVtYmVyLnRyaW0oKSxcclxuICAgICAgICBzdHJlZXROYW1lOiBzdHJlZXROYW1lLnRyaW0oKSxcclxuICAgICAgICBjb21wbGVtZW50OiBjb21wbGVtZW50LnRyaW0oKSB8fCB1bmRlZmluZWQsXHJcbiAgICAgICAgbmVpZ2hib3Job29kOiBuZWlnaGJvcmhvb2QudHJpbSgpLFxyXG4gICAgICAgIGNpdHk6IGNpdHkudHJpbSgpLFxyXG4gICAgICAgIHN0YXRlOiBzdGF0ZS50cmltKCksXHJcbiAgICAgICAgbGF0aXR1ZGU6IGhhc0Nvb3JkaW5hdGVzID8gTnVtYmVyKGxhdGl0dWRlKSA6IHVuZGVmaW5lZCxcclxuICAgICAgICBsb25naXR1ZGU6IGhhc0Nvb3JkaW5hdGVzID8gTnVtYmVyKGxvbmdpdHVkZSkgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgaXRlbXMsXHJcbiAgICAgIH0pO1xyXG4gICAgfSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiRW50cmVnYWRvciBzb2xpY2l0YWRvIGFvIGlGb29kLlwiKTtcclxuICAgICAgb25SZXF1ZXN0ZWQoKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBzb2xpY2l0YXIgbyBlbnRyZWdhZG9yIOKAlCBhIGNvdGHDp8OjbyBwb2RlIHRlciBleHBpcmFkbywgdGVudGUgY290YXIgZGUgbm92by5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGFkZEl0ZW0gPSAoKSA9PiB7XHJcbiAgICBpZiAoIWl0ZW1OYW1lLnRyaW0oKSB8fCBOdW1iZXIoaXRlbVVuaXRQcmljZSkgPD0gMCkgcmV0dXJuO1xyXG4gICAgc2V0SXRlbXMoWy4uLml0ZW1zLCB7IG5hbWU6IGl0ZW1OYW1lLnRyaW0oKSwgcXVhbnRpdHk6IE51bWJlcihpdGVtUXVhbnRpdHkpIHx8IDEsIHVuaXRQcmljZTogTnVtYmVyKGl0ZW1Vbml0UHJpY2UpIH1dKTtcclxuICAgIHNldEl0ZW1OYW1lKFwiXCIpO1xyXG4gICAgc2V0SXRlbVF1YW50aXR5KFwiMVwiKTtcclxuICAgIHNldEl0ZW1Vbml0UHJpY2UoXCJcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FuUXVvdGUgPVxyXG4gICAgY3VzdG9tZXJOYW1lLnRyaW0oKSAmJiBwaG9uZUFyZWFDb2RlLnRyaW0oKSAmJiBwaG9uZU51bWJlci50cmltKCkgJiYgcG9zdGFsQ29kZS50cmltKCkgJiZcclxuICAgIHN0cmVldE5hbWUudHJpbSgpICYmIHN0cmVldE51bWJlci50cmltKCkgJiYgbmVpZ2hib3Job29kLnRyaW0oKSAmJiBjaXR5LnRyaW0oKSAmJiBzdGF0ZS50cmltKCkgJiZcclxuICAgIGhhc0Nvb3JkaW5hdGVzICYmIGl0ZW1zLmxlbmd0aCA+IDA7XHJcblxyXG4gIGlmIChzdGVwID09PSBcImNvbmZpcm1cIiAmJiBxdW90ZSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPE1vZGFsIG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPVwiQ29uZmlybWFyIGVudHJlZ2FcIj5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE0LCBtaW5XaWR0aDogMzQwIH19PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19PkNvdGHDp8OjbyBkbyBpRm9vZDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+VmFsb3I6IHtxdW90ZS5uZXRWYWx1ZS50b0xvY2FsZVN0cmluZyhcInB0LUJSXCIsIHsgc3R5bGU6IFwiY3VycmVuY3lcIiwgY3VycmVuY3k6IFwiQlJMXCIgfSl9PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICBQcmF6byBlc3RpbWFkbzoge01hdGgucm91bmQocXVvdGUuZGVsaXZlcnlUaW1lTWluTWludXRlcyl94oCTe01hdGgucm91bmQocXVvdGUuZGVsaXZlcnlUaW1lTWF4TWludXRlcyl9IG1pblxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PkRpc3TDom5jaWE6IHsocXVvdGUuZGlzdGFuY2VNZXRlcnMgLyAxMDAwKS50b0ZpeGVkKDEpfSBrbTwvc3Bhbj5cclxuICAgICAgICAgICAge3F1b3RlLmV4cGlyYXRpb25BdCAmJiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0td2FybiwgI2Q5NzcwNilcIiwgZm9udFNpemU6IFwiMC44cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICBDb3Rhw6fDo28gdsOhbGlkYSBhdMOpIHtuZXcgRGF0ZShxdW90ZS5leHBpcmF0aW9uQXQpLnRvTG9jYWxlVGltZVN0cmluZyhcInB0LUJSXCIpfSDigJQgY29uZmlybWUgbG9nby5cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgIGxhYmVsPVwiVGF4YSBkbyBlc3RhYmVsZWNpbWVudG8gKG9wY2lvbmFsKVwiXHJcbiAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxyXG4gICAgICAgICAgICB2YWx1ZT17bWVyY2hhbnRGZWV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWVyY2hhbnRGZWUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEwLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoXCJmb3JtXCIpfT5cclxuICAgICAgICAgICAgICBWb2x0YXJcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBsb2FkaW5nPXtyZXF1ZXN0TXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiByZXF1ZXN0TXV0YXRpb24ubXV0YXRlKCl9PlxyXG4gICAgICAgICAgICAgIENvbmZpcm1hciBlbnRyZWdhZG9yXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvTW9kYWw+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxNb2RhbCBvbkNsb3NlPXtvbkNsb3NlfSB0aXRsZT1cIk5vdmEgZW50cmVnYSB2aWEgaUZvb2RcIj5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxNCwgbWluV2lkdGg6IDM4MCB9fT5cclxuICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICBsYWJlbD1cIlJlZmVyw6puY2lhIGRvIHBlZGlkbyAob3BjaW9uYWwpXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZXguOiBCYWxjw6NvICM0NSwgVGVsZWZvbmUgKDExKSA5ODc2NS00MzIxXCJcclxuICAgICAgICAgIHZhbHVlPXtvcmRlclJlZmVyZW5jZX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0T3JkZXJSZWZlcmVuY2UoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk5vbWUgZG8gY2xpZW50ZVwiIHZhbHVlPXtjdXN0b21lck5hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q3VzdG9tZXJOYW1lKGUudGFyZ2V0LnZhbHVlKX0gYXV0b0ZvY3VzIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyB3aWR0aDogOTAgfX0+XHJcbiAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJERERcIiBpbnB1dE1vZGU9XCJudW1lcmljXCIgdmFsdWU9e3Bob25lQXJlYUNvZGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGhvbmVBcmVhQ29kZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlRlbGVmb25lXCIgaW5wdXRNb2RlPVwibnVtZXJpY1wiIHZhbHVlPXtwaG9uZU51bWJlcn0gb25DaGFuZ2U9eyhlKSA9PiBzZXRQaG9uZU51bWJlcihlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwLCBtYXJnaW5Ub3A6IDQgfX0+RW5kZXJlw6dvIGRlIGVudHJlZ2E8L3NwYW4+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTQwIH19PlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiQ0VQXCIgdmFsdWU9e3Bvc3RhbENvZGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UG9zdGFsQ29kZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IDEwMCB9fT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk7Dum1lcm9cIiB2YWx1ZT17c3RyZWV0TnVtYmVyfSBvbkNoYW5nZT17KGUpID0+IHNldFN0cmVldE51bWJlcihlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiUnVhXCIgdmFsdWU9e3N0cmVldE5hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3RyZWV0TmFtZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkNvbXBsZW1lbnRvIChvcGNpb25hbClcIiB2YWx1ZT17Y29tcGxlbWVudH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRDb21wbGVtZW50KGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNjAgfX0+XHJcbiAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJCYWlycm9cIiB2YWx1ZT17bmVpZ2hib3Job29kfSBvbkNoYW5nZT17KGUpID0+IHNldE5laWdoYm9yaG9vZChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE0MCB9fT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkNpZGFkZVwiIHZhbHVlPXtjaXR5fSBvbkNoYW5nZT17KGUpID0+IHNldENpdHkoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiA3MCB9fT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlVGXCIgdmFsdWU9e3N0YXRlfSBvbkNoYW5nZT17KGUpID0+IHNldFN0YXRlKGUudGFyZ2V0LnZhbHVlLnRvVXBwZXJDYXNlKCkpfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTQwIH19PlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJMYXRpdHVkZVwiXHJcbiAgICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2xhdGl0dWRlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TGF0aXR1ZGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIGhpbnQ9XCJvYnJpZ2F0w7NyaWEgcGFyYSBjb3RhclwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE0MCB9fT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkxvbmdpdHVkZVwiIGlucHV0TW9kZT1cImRlY2ltYWxcIiB2YWx1ZT17bG9uZ2l0dWRlfSBvbkNoYW5nZT17KGUpID0+IHNldExvbmdpdHVkZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwLCBtYXJnaW5Ub3A6IDQgfX0+SXRlbnMgZG8gcGVkaWRvPC9zcGFuPlxyXG4gICAgICAgIHtpdGVtcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgIDx1bCBzdHlsZT17eyBtYXJnaW46IDAsIHBhZGRpbmdMZWZ0OiAxOCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgPGxpIGtleT17aWR4fSBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgIHtpdGVtLnF1YW50aXR5fXgge2l0ZW0ubmFtZX0g4oCUe1wiIFwifVxyXG4gICAgICAgICAgICAgICAgeyhpdGVtLnVuaXRQcmljZSAqIGl0ZW0ucXVhbnRpdHkpLnRvTG9jYWxlU3RyaW5nKFwicHQtQlJcIiwgeyBzdHlsZTogXCJjdXJyZW5jeVwiLCBjdXJyZW5jeTogXCJCUkxcIiB9KX1cclxuICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAsIGFsaWduSXRlbXM6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE0MCB9fT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkl0ZW1cIiB2YWx1ZT17aXRlbU5hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0SXRlbU5hbWUoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiA3MCB9fT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlF0ZFwiIGlucHV0TW9kZT1cIm51bWVyaWNcIiB2YWx1ZT17aXRlbVF1YW50aXR5fSBvbkNoYW5nZT17KGUpID0+IHNldEl0ZW1RdWFudGl0eShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IDExMCB9fT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlByZcOnbyB1bml0LlwiIGlucHV0TW9kZT1cImRlY2ltYWxcIiB2YWx1ZT17aXRlbVVuaXRQcmljZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRJdGVtVW5pdFByaWNlKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXthZGRJdGVtfT5cclxuICAgICAgICAgICAgKyBJdGVtXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiwgbWFyZ2luVG9wOiA2IH19PlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgICAgVm9sdGFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBkaXNhYmxlZD17IWNhblF1b3RlfSBsb2FkaW5nPXtxdW90ZU11dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gcXVvdGVNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgIENvdGFyIGVudHJlZ2FcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvTW9kYWw+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gVHJhY2tpbmdNb2RhbCh7IGRlbGl2ZXJ5LCBvbkNsb3NlIH06IHsgZGVsaXZlcnk6IElGb29kU2hpcHBpbmdEZWxpdmVyeVJlc3BvbnNlOyBvbkNsb3NlOiAoKSA9PiB2b2lkIH0pIHtcclxuICBjb25zdCB0cmFja2luZ1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwic2hpcHBpbmctdHJhY2tpbmdcIiwgZGVsaXZlcnkuaWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RTaGlwcGluZ1RyYWNraW5nKGRlbGl2ZXJ5LmlkKSxcclxuICAgIHJlZmV0Y2hJbnRlcnZhbDogMTVfMDAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBzY29yZVF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwic2hpcHBpbmctc2FmZS1zY29yZVwiLCBkZWxpdmVyeS5pZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZFNhZmVEZWxpdmVyeVNjb3JlKGRlbGl2ZXJ5LmlkKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgdHJhY2tpbmcgPSB0cmFja2luZ1F1ZXJ5LmRhdGE7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TW9kYWwgb25DbG9zZT17b25DbG9zZX0gdGl0bGU9e2BSYXN0cmVhciAke2RlbGl2ZXJ5Lm9yZGVyUmVmZXJlbmNlID8/IGBlbnRyZWdhICMke2RlbGl2ZXJ5LmlkfWB9YH0+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIsIG1pbldpZHRoOiAzMDAgfX0+XHJcbiAgICAgICAge3RyYWNraW5nUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17dHJhY2tpbmdRdWVyeS5lcnJvcn0gd2hhdD1cIm8gcmFzdHJlYW1lbnRvXCIgLz59XHJcbiAgICAgICAge3RyYWNraW5nUXVlcnkuaXNMb2FkaW5nICYmIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5DYXJyZWdhbmRv4oCmPC9zcGFuPn1cclxuICAgICAgICB7dHJhY2tpbmcgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAge3RyYWNraW5nLmxhdGl0dWRlICE9IG51bGwgJiYgdHJhY2tpbmcubG9uZ2l0dWRlICE9IG51bGwgPyAoXHJcbiAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICBQb3Npw6fDo28gZG8gZW50cmVnYWRvcjoge3RyYWNraW5nLmxhdGl0dWRlLnRvRml4ZWQoNSl9LCB7dHJhY2tpbmcubG9uZ2l0dWRlLnRvRml4ZWQoNSl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5Qb3Npw6fDo28gYWluZGEgbsOjbyBkaXNwb27DrXZlbC48L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHt0cmFja2luZy5leHBlY3RlZERlbGl2ZXJ5ICYmIChcclxuICAgICAgICAgICAgICA8c3Bhbj5QcmV2aXPDo28gZGUgZW50cmVnYToge25ldyBEYXRlKHRyYWNraW5nLmV4cGVjdGVkRGVsaXZlcnkpLnRvTG9jYWxlVGltZVN0cmluZyhcInB0LUJSXCIpfTwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge3Njb3JlUXVlcnkuZGF0YT8uc2NvcmUgJiYgKFxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+w41uZGljZSBkZSBzZWd1cmFuw6dhIGRhIGVudHJlZ2E6IHtzY29yZVF1ZXJ5LmRhdGEuc2NvcmV9PC9zcGFuPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge2RlbGl2ZXJ5LnRyYWNraW5nVXJsICYmIChcclxuICAgICAgICAgIDxhIGhyZWY9e2RlbGl2ZXJ5LnRyYWNraW5nVXJsfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub3JlZmVycmVyXCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+XHJcbiAgICAgICAgICAgIEFicmlyIHJhc3RyZWFtZW50byBjb21wbGV0byBkbyBpRm9vZCDihpdcclxuICAgICAgICAgIDwvYT5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICBGZWNoYXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvTW9kYWw+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gQ2FuY2VsRGVsaXZlcnlNb2RhbCh7XHJcbiAgZGVsaXZlcnksXHJcbiAgb25DbG9zZSxcclxuICBvbkNhbmNlbGxlZCxcclxufToge1xyXG4gIGRlbGl2ZXJ5OiBJRm9vZFNoaXBwaW5nRGVsaXZlcnlSZXNwb25zZTtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIG9uQ2FuY2VsbGVkOiAoKSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG4gIGNvbnN0IFtjYW5jZWxDb2RlSWQsIHNldENhbmNlbENvZGVJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgcmVhc29uc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwic2hpcHBpbmctY2FuY2VsbGF0aW9uLXJlYXNvbnNcIiwgZGVsaXZlcnkuaWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RTaGlwcGluZ0NhbmNlbGxhdGlvblJlYXNvbnMoZGVsaXZlcnkuaWQpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjYW5jZWxNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHtcclxuICAgICAgY29uc3QgcmVhc29uID0gcmVhc29uc1F1ZXJ5LmRhdGE/LmZpbmQoKHIpID0+IHIuY2FuY2VsQ29kZUlkID09PSBjYW5jZWxDb2RlSWQpO1xyXG4gICAgICByZXR1cm4gY2FuY2VsSUZvb2RTaGlwcGluZ0RlbGl2ZXJ5KGRlbGl2ZXJ5LmlkLCByZWFzb24/LmRlc2NyaXB0aW9uID8/IFwiQ2FuY2VsYWRvIHBlbG8gbG9qaXN0YVwiLCBOdW1iZXIoY2FuY2VsQ29kZUlkKSB8fCAwKTtcclxuICAgIH0sXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkVudHJlZ2EgY2FuY2VsYWRhIG5vIGlGb29kLlwiKTtcclxuICAgICAgb25DYW5jZWxsZWQoKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBjYW5jZWxhciBhIGVudHJlZ2EuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByZWFzb25zID0gcmVhc29uc1F1ZXJ5LmRhdGEgPz8gW107XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TW9kYWwgb25DbG9zZT17b25DbG9zZX0gdGl0bGU9e2BDYW5jZWxhciAke2RlbGl2ZXJ5Lm9yZGVyUmVmZXJlbmNlID8/IGBlbnRyZWdhICMke2RlbGl2ZXJ5LmlkfWB9YH0+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQsIG1pbldpZHRoOiAzMjAgfX0+XHJcbiAgICAgICAge3JlYXNvbnNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtyZWFzb25zUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBtb3Rpdm9zIGRlIGNhbmNlbGFtZW50b1wiIC8+fVxyXG5cclxuICAgICAgICA8U2VsZWN0RmllbGRcclxuICAgICAgICAgIGxhYmVsPVwiTW90aXZvIGRvIGNhbmNlbGFtZW50b1wiXHJcbiAgICAgICAgICB2YWx1ZT17Y2FuY2VsQ29kZUlkfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYW5jZWxDb2RlSWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3JlYXNvbnNRdWVyeS5pc0xvYWRpbmd9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjaW9uZSB1bSBtb3Rpdm/igKY8L29wdGlvbj5cclxuICAgICAgICAgIHtyZWFzb25zLm1hcCgocmVhc29uKSA9PiAoXHJcbiAgICAgICAgICAgIDxvcHRpb24ga2V5PXtyZWFzb24uY2FuY2VsQ29kZUlkfSB2YWx1ZT17cmVhc29uLmNhbmNlbENvZGVJZH0+XHJcbiAgICAgICAgICAgICAge3JlYXNvbi5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L1NlbGVjdEZpZWxkPlxyXG5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEwLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgICAgVm9sdGFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cImRhbmdlclwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXshY2FuY2VsQ29kZUlkfVxyXG4gICAgICAgICAgICBsb2FkaW5nPXtjYW5jZWxNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNhbmNlbE11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBDYW5jZWxhciBlbnRyZWdhXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L01vZGFsPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2ludGVncmF0aW9ucy9JRm9vZFNoaXBwaW5nUGFnZS50c3gifQ==