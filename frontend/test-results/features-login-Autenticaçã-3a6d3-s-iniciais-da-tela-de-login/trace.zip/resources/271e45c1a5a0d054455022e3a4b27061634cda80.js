import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useAuthStore } from "/src/stores/authStore.ts";
import { AppShell } from "/src/components/AppShell.tsx";
import { LoginPage } from "/src/features/auth/LoginPage.tsx";
import { SignupPage } from "/src/features/auth/SignupPage.tsx";
import { OrdersPage } from "/src/features/orders/OrdersPage.tsx";
import { DeliveryBoardPage } from "/src/features/orders/DeliveryBoardPage.tsx";
import { WaiterDashboardPage } from "/src/features/waiter/WaiterDashboardPage.tsx";
import { ProductsPage } from "/src/features/catalog/ProductsPage.tsx";
import { ComplementsPage } from "/src/features/catalog/ComplementsPage.tsx";
import { StockPage } from "/src/features/stock/StockPage.tsx";
import { EmployeesPage } from "/src/features/employees/EmployeesPage.tsx";
import { UsersPage } from "/src/features/users/UsersPage.tsx";
import { AccessPage } from "/src/features/access/AccessPage.tsx";
import { SettingsPage } from "/src/features/settings/SettingsPage.tsx";
import { FinancePage } from "/src/features/finance/FinancePage.tsx";
import { ScenariosPage } from "/src/features/finance/ScenariosPage.tsx";
import { ReportsPage } from "/src/features/finance/ReportsPage.tsx";
import { PreparationPage } from "/src/features/preparation/PreparationPage.tsx";
import { CashHistoryPage } from "/src/features/cash/CashHistoryPage.tsx";
import { PromotionsPage } from "/src/features/promotions/PromotionsPage.tsx";
import { PrintingPage } from "/src/features/printing/PrintingPage.tsx";
import { PurchasingPage } from "/src/features/purchasing/PurchasingPage.tsx";
import { ReservationsPage } from "/src/features/reservations/ReservationsPage.tsx";
import { CustomersPage } from "/src/features/customers/CustomersPage.tsx";
import { PublicOrderPage } from "/src/features/publicOrdering/PublicOrderPage.tsx";
import { IFoodIntegrationPage } from "/src/features/integrations/IFoodIntegrationPage.tsx";
import { IFoodOrdersPage } from "/src/features/integrations/IFoodOrdersPage.tsx";
import { IFoodShippingPage } from "/src/features/integrations/IFoodShippingPage.tsx";
import { IFoodLogisticsPage } from "/src/features/integrations/IFoodLogisticsPage.tsx";
import { IFoodCatalogPage } from "/src/features/integrations/IFoodCatalogPage.tsx";
import { IFoodFinancialReportsPage } from "/src/features/integrations/IFoodFinancialReportsPage.tsx";
import { IFoodDashboardPage } from "/src/features/integrations/IFoodDashboardPage.tsx";
import { IFoodStatusDetailedPage } from "/src/features/integrations/IFoodStatusDetailedPage.tsx";
import { IFoodReviewsDetailedPage } from "/src/features/integrations/IFoodReviewsDetailedPage.tsx";
import { IFoodAnalyticsEnhancedPage } from "/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx";
import { DiningAreasPage } from "/src/features/diningareas/DiningAreasPage.tsx";
import { FeatureGate, NoAccessPage } from "/src/features/access/FeatureGate.tsx";
import { useMyFeatures } from "/src/features/access/hooks.ts";
import { DigitalMenuPage } from "/src/features/digitalmenu/DigitalMenuPage.tsx";
function ManagerGate({ children }) {
  _s();
  const featuresQuery = useMyFeatures();
  if (featuresQuery.isLoading) return null;
  if (featuresQuery.data?.canManageAccess) return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
    lineNumber: 65,
    columnNumber: 51
  }, this);
  return /* @__PURE__ */ jsxDEV(Navigate, { to: "/", replace: true }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
    lineNumber: 66,
    columnNumber: 10
  }, this);
}
_s(ManagerGate, "a5P5B565tUr9rZvlmICwiaUpNkU=", false, function() {
  return [useMyFeatures];
});
_c = ManagerGate;
function RequireAuth({ children }) {
  _s2();
  const accessToken = useAuthStore((s) => s.accessToken);
  if (!accessToken) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
    lineNumber: 71,
    columnNumber: 28
  }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
    lineNumber: 72,
    columnNumber: 10
  }, this);
}
_s2(RequireAuth, "sY0U5hpw4IS9cPi44xIhW8quCTQ=", false, function() {
  return [useAuthStore];
});
_c2 = RequireAuth;
export default function App() {
  return /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { path: "/login", element: /* @__PURE__ */ jsxDEV(LoginPage, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
      lineNumber: 78,
      columnNumber: 43
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
      lineNumber: 78,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/cadastro", element: /* @__PURE__ */ jsxDEV(SignupPage, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
      lineNumber: 79,
      columnNumber: 46
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
      lineNumber: 79,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/pedido/:token", element: /* @__PURE__ */ jsxDEV(PublicOrderPage, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
      lineNumber: 80,
      columnNumber: 51
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
      lineNumber: 80,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/mesa/:mesa",
        element: /* @__PURE__ */ jsxDEV(RequireAuth, { children: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Salao", children: /* @__PURE__ */ jsxDEV(DigitalMenuPage, {}, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
          lineNumber: 88,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
          lineNumber: 87,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
          lineNumber: 86,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
        lineNumber: 83,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/garcom",
        element: /* @__PURE__ */ jsxDEV(RequireAuth, { children: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Salao", children: /* @__PURE__ */ jsxDEV(WaiterDashboardPage, {}, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
          lineNumber: 100,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
          lineNumber: 99,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
          lineNumber: 98,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
        lineNumber: 95,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        element: /* @__PURE__ */ jsxDEV(RequireAuth, { children: /* @__PURE__ */ jsxDEV(AppShell, {}, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
          lineNumber: 110,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
          lineNumber: 109,
          columnNumber: 9
        }, this),
        children: [
          /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Salao", children: /* @__PURE__ */ jsxDEV(OrdersPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 114,
            columnNumber: 68
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 114,
            columnNumber: 42
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 114,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/delivery", element: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Salao", children: /* @__PURE__ */ jsxDEV(DeliveryBoardPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 118,
            columnNumber: 76
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 118,
            columnNumber: 50
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 118,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/produtos", element: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Cardapio", children: /* @__PURE__ */ jsxDEV(ProductsPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 119,
            columnNumber: 79
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 119,
            columnNumber: 50
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 119,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/complementos", element: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Cardapio", children: /* @__PURE__ */ jsxDEV(ComplementsPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 120,
            columnNumber: 83
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 120,
            columnNumber: 54
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 120,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/estoque", element: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Estoque", children: /* @__PURE__ */ jsxDEV(StockPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 121,
            columnNumber: 77
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 121,
            columnNumber: 49
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 121,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/equipe", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(EmployeesPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 122,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 122,
            columnNumber: 48
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 122,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/usuarios", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(UsersPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 123,
            columnNumber: 63
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 123,
            columnNumber: 50
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 123,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/faturamento", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(FinancePage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 124,
            columnNumber: 66
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 124,
            columnNumber: 53
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 124,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/cenarios", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(ScenariosPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 125,
            columnNumber: 63
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 125,
            columnNumber: 50
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 125,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/relatorios", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(ReportsPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 126,
            columnNumber: 65
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 126,
            columnNumber: 52
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 126,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/preparo", element: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Preparo", children: /* @__PURE__ */ jsxDEV(PreparationPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 127,
            columnNumber: 77
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 127,
            columnNumber: 49
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 127,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/fechamentos", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(CashHistoryPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 128,
            columnNumber: 66
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 128,
            columnNumber: 53
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 128,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/promocoes", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(PromotionsPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 129,
            columnNumber: 64
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 129,
            columnNumber: 51
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 129,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/impressao", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(PrintingPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 130,
            columnNumber: 64
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 130,
            columnNumber: 51
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 130,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/compras", element: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Estoque", children: /* @__PURE__ */ jsxDEV(PurchasingPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 131,
            columnNumber: 77
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 131,
            columnNumber: 49
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 131,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/reservas", element: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Salao", children: /* @__PURE__ */ jsxDEV(ReservationsPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 132,
            columnNumber: 76
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 132,
            columnNumber: 50
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 132,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/clientes", element: /* @__PURE__ */ jsxDEV(FeatureGate, { code: "Salao", children: /* @__PURE__ */ jsxDEV(CustomersPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 133,
            columnNumber: 76
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 133,
            columnNumber: 50
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 133,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/acessos", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(AccessPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 134,
            columnNumber: 62
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 134,
            columnNumber: 49
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 134,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/configuracoes", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(SettingsPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 135,
            columnNumber: 68
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 135,
            columnNumber: 55
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 135,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodIntegrationPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 138,
            columnNumber: 72
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 138,
            columnNumber: 59
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 138,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood/dashboard", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodDashboardPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 139,
            columnNumber: 82
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 139,
            columnNumber: 69
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 139,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood/status", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodStatusDetailedPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 140,
            columnNumber: 79
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 140,
            columnNumber: 66
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 140,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood/pedidos", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodOrdersPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 141,
            columnNumber: 80
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 141,
            columnNumber: 67
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 141,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood/shipping", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodShippingPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 142,
            columnNumber: 81
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 142,
            columnNumber: 68
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 142,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood/logistica", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodLogisticsPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 143,
            columnNumber: 82
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 143,
            columnNumber: 69
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 143,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood/catalogo", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodCatalogPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 144,
            columnNumber: 81
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 144,
            columnNumber: 68
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 144,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood/avaliacoes", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodReviewsDetailedPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 145,
            columnNumber: 83
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 145,
            columnNumber: 70
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 145,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood/indicadores", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodAnalyticsEnhancedPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 146,
            columnNumber: 84
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 146,
            columnNumber: 71
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 146,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/integracoes/ifood/financeiro/relatorios", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(IFoodFinancialReportsPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 147,
            columnNumber: 94
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 147,
            columnNumber: 81
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 147,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/pracas", element: /* @__PURE__ */ jsxDEV(ManagerGate, { children: /* @__PURE__ */ jsxDEV(DiningAreasPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 149,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 149,
            columnNumber: 48
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 149,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/sem-acesso", element: /* @__PURE__ */ jsxDEV(NoAccessPage, {}, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 150,
            columnNumber: 52
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
            lineNumber: 150,
            columnNumber: 17
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
        lineNumber: 107,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/", replace: true }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
      lineNumber: 153,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
      lineNumber: 153,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx",
    lineNumber: 77,
    columnNumber: 5
  }, this);
}
_c3 = App;
var _c, _c2, _c3;
$RefreshReg$(_c, "ManagerGate");
$RefreshReg$(_c2, "RequireAuth");
$RefreshReg$(_c3, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNvRDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1Q3BELFNBQVNBLFVBQVVDLE9BQU9DLGNBQWM7QUFDeEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsaUNBQWlDO0FBQzFDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQywrQkFBK0I7QUFDeEMsU0FBU0MsZ0NBQWdDO0FBQ3pDLFNBQVNDLGtDQUFrQztBQUMzQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsYUFBYUMsb0JBQW9CO0FBQzFDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyx1QkFBdUI7QUFFaEMsU0FBU0MsWUFBWSxFQUFFQyxTQUFrQyxHQUFHO0FBQUFDLEtBQUE7QUFDeEQsUUFBTUMsZ0JBQWdCTCxjQUFjO0FBQ3BDLE1BQUlLLGNBQWNDLFVBQVcsUUFBTztBQUNwQyxNQUFJRCxjQUFjRSxNQUFNQyxnQkFBaUIsUUFBTyxtQ0FBR0wsWUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVk7QUFDNUQsU0FBTyx1QkFBQyxZQUFTLElBQUcsS0FBSSxTQUFPLFFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBd0I7QUFDbkM7QUFBQ0MsR0FMUUYsYUFBVztBQUFBLFVBQ01GLGFBQWE7QUFBQTtBQUFBLEtBRDlCRTtBQU9ULFNBQVNPLFlBQVksRUFBRU4sU0FBa0MsR0FBRztBQUFBTyxNQUFBO0FBQ3hELFFBQU1DLGNBQWNqRCxhQUFhLENBQUNrRCxNQUFNQSxFQUFFRCxXQUFXO0FBQ3JELE1BQUksQ0FBQ0EsWUFBYSxRQUFPLHVCQUFDLFlBQVMsSUFBRyxVQUFTLFNBQU8sUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE2QjtBQUN0RCxTQUFPLG1DQUFHUixZQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBWTtBQUN2QjtBQUFDTyxJQUpRRCxhQUFXO0FBQUEsVUFDSS9DLFlBQVk7QUFBQTtBQUFBLE1BRDNCK0M7QUFNVCx3QkFBd0JJLE1BQU07QUFDMUIsU0FDSSx1QkFBQyxVQUNHO0FBQUEsMkJBQUMsU0FBTSxNQUFLLFVBQVMsU0FBUyx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVSxLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDO0FBQUEsSUFDNUMsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVcsS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRDtBQUFBLElBQ2hELHVCQUFDLFNBQU0sTUFBSyxrQkFBaUIsU0FBUyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCLEtBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEQ7QUFBQSxJQUcxRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBSztBQUFBLFFBQ0wsU0FDSSx1QkFBQyxlQUNHLGlDQUFDLGVBQVksTUFBSyxTQUNkLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0IsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUE7QUFBQSxNQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFLO0FBQUEsSUFJTDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBSztBQUFBLFFBQ0wsU0FDSSx1QkFBQyxlQUNHLGlDQUFDLGVBQVksTUFBSyxTQUNkLGlDQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0IsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUE7QUFBQSxNQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFLO0FBQUEsSUFJTDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csU0FDSSx1QkFBQyxlQUNHLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTLEtBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHSjtBQUFBLGlDQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsZUFBWSxNQUFLLFNBQVEsaUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVyxLQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QyxLQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBSWhGLHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsZUFBWSxNQUFLLFNBQVEsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0IsS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0MsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxVQUMvRix1QkFBQyxTQUFNLE1BQUssYUFBWSxTQUFTLHVCQUFDLGVBQVksTUFBSyxZQUFXLGlDQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWEsS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkMsS0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkY7QUFBQSxVQUM3Rix1QkFBQyxTQUFNLE1BQUssaUJBQWdCLFNBQVMsdUJBQUMsZUFBWSxNQUFLLFlBQVcsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0IsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0QsS0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0c7QUFBQSxVQUNwRyx1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTLHVCQUFDLGVBQVksTUFBSyxXQUFVLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVSxLQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QyxLQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLFVBQ3hGLHVCQUFDLFNBQU0sTUFBSyxXQUFVLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFjLEtBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCLEtBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxlQUFZLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVSxLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRTtBQUFBLFVBQzFFLHVCQUFDLFNBQU0sTUFBSyxnQkFBZSxTQUFTLHVCQUFDLGVBQVksaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWSxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QixLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFjLEtBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThFO0FBQUEsVUFDOUUsdUJBQUMsU0FBTSxNQUFLLGVBQWMsU0FBUyx1QkFBQyxlQUFZLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVksS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEIsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEU7QUFBQSxVQUM5RSx1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTLHVCQUFDLGVBQVksTUFBSyxXQUFVLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdCLEtBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThGO0FBQUEsVUFDOUYsdUJBQUMsU0FBTSxNQUFLLGdCQUFlLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQixLQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQyxLQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ25GLHVCQUFDLFNBQU0sTUFBSyxjQUFhLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlLEtBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCLEtBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsVUFDaEYsdUJBQUMsU0FBTSxNQUFLLGNBQWEsU0FBUyx1QkFBQyxlQUFZLGlDQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWEsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkIsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEU7QUFBQSxVQUM5RSx1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTLHVCQUFDLGVBQVksTUFBSyxXQUFVLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWUsS0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEMsS0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkY7QUFBQSxVQUM3Rix1QkFBQyxTQUFNLE1BQUssYUFBWSxTQUFTLHVCQUFDLGVBQVksTUFBSyxTQUFRLGlDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCLEtBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThGO0FBQUEsVUFDOUYsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxlQUFZLE1BQUssU0FBUSxpQ0FBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFjLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDLEtBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsVUFDM0YsdUJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBUyx1QkFBQyxlQUFZLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVcsS0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkIsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRSx1QkFBQyxTQUFNLE1BQUssa0JBQWlCLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFhLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtGO0FBQUEsVUFHbEYsdUJBQUMsU0FBTSxNQUFLLHNCQUFxQixTQUFTLHVCQUFDLGVBQVksaUNBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUIsS0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUMsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEY7QUFBQSxVQUM5Rix1QkFBQyxTQUFNLE1BQUssZ0NBQStCLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQixLQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQyxLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRztBQUFBLFVBQ3RHLHVCQUFDLFNBQU0sTUFBSyw2QkFBNEIsU0FBUyx1QkFBQyxlQUFZLGlDQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEtBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdHO0FBQUEsVUFDeEcsdUJBQUMsU0FBTSxNQUFLLDhCQUE2QixTQUFTLHVCQUFDLGVBQVksaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0IsS0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0MsS0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUc7QUFBQSxVQUNqRyx1QkFBQyxTQUFNLE1BQUssK0JBQThCLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQixLQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQyxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRztBQUFBLFVBQ3BHLHVCQUFDLFNBQU0sTUFBSyxnQ0FBK0IsU0FBUyx1QkFBQyxlQUFZLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CLEtBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1DLEtBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNHO0FBQUEsVUFDdEcsdUJBQUMsU0FBTSxNQUFLLCtCQUE4QixTQUFTLHVCQUFDLGVBQVksaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUIsS0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUMsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxVQUNuRyx1QkFBQyxTQUFNLE1BQUssaUNBQWdDLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyw4QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QixLQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QyxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RztBQUFBLFVBQzdHLHVCQUFDLFNBQU0sTUFBSyxrQ0FBaUMsU0FBUyx1QkFBQyxlQUFZLGlDQUFDLGdDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDLEtBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdIO0FBQUEsVUFDaEgsdUJBQUMsU0FBTSxNQUFLLDRDQUEyQyxTQUFTLHVCQUFDLGVBQVksaUNBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEIsS0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEMsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUg7QUFBQSxVQUV6SCx1QkFBQyxTQUFNLE1BQUssV0FBVSxTQUFTLHVCQUFDLGVBQVksaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0IsS0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0MsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEU7QUFBQSxVQUM5RSx1QkFBQyxTQUFNLE1BQUssZUFBYyxTQUFTLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWEsS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQTtBQUFBO0FBQUEsTUEzQ3hEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTRDQTtBQUFBLElBRUEsdUJBQUMsU0FBTSxNQUFLLEtBQUksU0FBUyx1QkFBQyxZQUFTLElBQUcsS0FBSSxTQUFPLFFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRDtBQUFBLE9BNUV6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkVBO0FBRVI7QUFBQ0MsTUFqRnVCRDtBQUFHLElBQUFFLElBQUFDLEtBQUFGO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRixLQUFBIiwibmFtZXMiOlsiTmF2aWdhdGUiLCJSb3V0ZSIsIlJvdXRlcyIsInVzZUF1dGhTdG9yZSIsIkFwcFNoZWxsIiwiTG9naW5QYWdlIiwiU2lnbnVwUGFnZSIsIk9yZGVyc1BhZ2UiLCJEZWxpdmVyeUJvYXJkUGFnZSIsIldhaXRlckRhc2hib2FyZFBhZ2UiLCJQcm9kdWN0c1BhZ2UiLCJDb21wbGVtZW50c1BhZ2UiLCJTdG9ja1BhZ2UiLCJFbXBsb3llZXNQYWdlIiwiVXNlcnNQYWdlIiwiQWNjZXNzUGFnZSIsIlNldHRpbmdzUGFnZSIsIkZpbmFuY2VQYWdlIiwiU2NlbmFyaW9zUGFnZSIsIlJlcG9ydHNQYWdlIiwiUHJlcGFyYXRpb25QYWdlIiwiQ2FzaEhpc3RvcnlQYWdlIiwiUHJvbW90aW9uc1BhZ2UiLCJQcmludGluZ1BhZ2UiLCJQdXJjaGFzaW5nUGFnZSIsIlJlc2VydmF0aW9uc1BhZ2UiLCJDdXN0b21lcnNQYWdlIiwiUHVibGljT3JkZXJQYWdlIiwiSUZvb2RJbnRlZ3JhdGlvblBhZ2UiLCJJRm9vZE9yZGVyc1BhZ2UiLCJJRm9vZFNoaXBwaW5nUGFnZSIsIklGb29kTG9naXN0aWNzUGFnZSIsIklGb29kQ2F0YWxvZ1BhZ2UiLCJJRm9vZEZpbmFuY2lhbFJlcG9ydHNQYWdlIiwiSUZvb2REYXNoYm9hcmRQYWdlIiwiSUZvb2RTdGF0dXNEZXRhaWxlZFBhZ2UiLCJJRm9vZFJldmlld3NEZXRhaWxlZFBhZ2UiLCJJRm9vZEFuYWx5dGljc0VuaGFuY2VkUGFnZSIsIkRpbmluZ0FyZWFzUGFnZSIsIkZlYXR1cmVHYXRlIiwiTm9BY2Nlc3NQYWdlIiwidXNlTXlGZWF0dXJlcyIsIkRpZ2l0YWxNZW51UGFnZSIsIk1hbmFnZXJHYXRlIiwiY2hpbGRyZW4iLCJfcyIsImZlYXR1cmVzUXVlcnkiLCJpc0xvYWRpbmciLCJkYXRhIiwiY2FuTWFuYWdlQWNjZXNzIiwiUmVxdWlyZUF1dGgiLCJfczIiLCJhY2Nlc3NUb2tlbiIsInMiLCJBcHAiLCJfYzMiLCJfYyIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IE5hdmlnYXRlLCBSb3V0ZSwgUm91dGVzIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcHBTaGVsbCB9IGZyb20gXCIuL2NvbXBvbmVudHMvQXBwU2hlbGxcIjtcclxuaW1wb3J0IHsgTG9naW5QYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvYXV0aC9Mb2dpblBhZ2VcIjtcclxuaW1wb3J0IHsgU2lnbnVwUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL2F1dGgvU2lnbnVwUGFnZVwiO1xyXG5pbXBvcnQgeyBPcmRlcnNQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvb3JkZXJzL09yZGVyc1BhZ2VcIjtcclxuaW1wb3J0IHsgRGVsaXZlcnlCb2FyZFBhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9vcmRlcnMvRGVsaXZlcnlCb2FyZFBhZ2VcIjtcclxuaW1wb3J0IHsgV2FpdGVyRGFzaGJvYXJkUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3dhaXRlci9XYWl0ZXJEYXNoYm9hcmRQYWdlXCI7XHJcbmltcG9ydCB7IFByb2R1Y3RzUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL2NhdGFsb2cvUHJvZHVjdHNQYWdlXCI7XHJcbmltcG9ydCB7IENvbXBsZW1lbnRzUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL2NhdGFsb2cvQ29tcGxlbWVudHNQYWdlXCI7XHJcbmltcG9ydCB7IFN0b2NrUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3N0b2NrL1N0b2NrUGFnZVwiO1xyXG5pbXBvcnQgeyBFbXBsb3llZXNQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvZW1wbG95ZWVzL0VtcGxveWVlc1BhZ2VcIjtcclxuaW1wb3J0IHsgVXNlcnNQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvdXNlcnMvVXNlcnNQYWdlXCI7XHJcbmltcG9ydCB7IEFjY2Vzc1BhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9hY2Nlc3MvQWNjZXNzUGFnZVwiO1xyXG5pbXBvcnQgeyBTZXR0aW5nc1BhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9zZXR0aW5ncy9TZXR0aW5nc1BhZ2VcIjtcclxuaW1wb3J0IHsgRmluYW5jZVBhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9maW5hbmNlL0ZpbmFuY2VQYWdlXCI7XHJcbmltcG9ydCB7IFNjZW5hcmlvc1BhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9maW5hbmNlL1NjZW5hcmlvc1BhZ2VcIjtcclxuaW1wb3J0IHsgUmVwb3J0c1BhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9maW5hbmNlL1JlcG9ydHNQYWdlXCI7XHJcbmltcG9ydCB7IFByZXBhcmF0aW9uUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3ByZXBhcmF0aW9uL1ByZXBhcmF0aW9uUGFnZVwiO1xyXG5pbXBvcnQgeyBDYXNoSGlzdG9yeVBhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9jYXNoL0Nhc2hIaXN0b3J5UGFnZVwiO1xyXG5pbXBvcnQgeyBQcm9tb3Rpb25zUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3Byb21vdGlvbnMvUHJvbW90aW9uc1BhZ2VcIjtcclxuaW1wb3J0IHsgUHJpbnRpbmdQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvcHJpbnRpbmcvUHJpbnRpbmdQYWdlXCI7XHJcbmltcG9ydCB7IFB1cmNoYXNpbmdQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvcHVyY2hhc2luZy9QdXJjaGFzaW5nUGFnZVwiO1xyXG5pbXBvcnQgeyBSZXNlcnZhdGlvbnNQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvcmVzZXJ2YXRpb25zL1Jlc2VydmF0aW9uc1BhZ2VcIjtcclxuaW1wb3J0IHsgQ3VzdG9tZXJzUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL2N1c3RvbWVycy9DdXN0b21lcnNQYWdlXCI7XHJcbmltcG9ydCB7IFB1YmxpY09yZGVyUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3B1YmxpY09yZGVyaW5nL1B1YmxpY09yZGVyUGFnZVwiO1xyXG5pbXBvcnQgeyBJRm9vZEludGVncmF0aW9uUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL2ludGVncmF0aW9ucy9JRm9vZEludGVncmF0aW9uUGFnZVwiO1xyXG5pbXBvcnQgeyBJRm9vZE9yZGVyc1BhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9pbnRlZ3JhdGlvbnMvSUZvb2RPcmRlcnNQYWdlXCI7XHJcbmltcG9ydCB7IElGb29kU2hpcHBpbmdQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvaW50ZWdyYXRpb25zL0lGb29kU2hpcHBpbmdQYWdlXCI7XHJcbmltcG9ydCB7IElGb29kTG9naXN0aWNzUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL2ludGVncmF0aW9ucy9JRm9vZExvZ2lzdGljc1BhZ2VcIjtcclxuaW1wb3J0IHsgSUZvb2RDYXRhbG9nUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL2ludGVncmF0aW9ucy9JRm9vZENhdGFsb2dQYWdlXCI7XHJcbmltcG9ydCB7IElGb29kRmluYW5jaWFsUmVwb3J0c1BhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9pbnRlZ3JhdGlvbnMvSUZvb2RGaW5hbmNpYWxSZXBvcnRzUGFnZVwiO1xyXG5pbXBvcnQgeyBJRm9vZERhc2hib2FyZFBhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9pbnRlZ3JhdGlvbnMvSUZvb2REYXNoYm9hcmRQYWdlXCI7XHJcbmltcG9ydCB7IElGb29kU3RhdHVzRGV0YWlsZWRQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvaW50ZWdyYXRpb25zL0lGb29kU3RhdHVzRGV0YWlsZWRQYWdlXCI7XHJcbmltcG9ydCB7IElGb29kUmV2aWV3c0RldGFpbGVkUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL2ludGVncmF0aW9ucy9JRm9vZFJldmlld3NEZXRhaWxlZFBhZ2VcIjtcclxuaW1wb3J0IHsgSUZvb2RBbmFseXRpY3NFbmhhbmNlZFBhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9pbnRlZ3JhdGlvbnMvSUZvb2RBbmFseXRpY3NFbmhhbmNlZFBhZ2VcIjtcclxuaW1wb3J0IHsgRGluaW5nQXJlYXNQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvZGluaW5nYXJlYXMvRGluaW5nQXJlYXNQYWdlXCI7XHJcbmltcG9ydCB7IEZlYXR1cmVHYXRlLCBOb0FjY2Vzc1BhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9hY2Nlc3MvRmVhdHVyZUdhdGVcIjtcclxuaW1wb3J0IHsgdXNlTXlGZWF0dXJlcyB9IGZyb20gXCIuL2ZlYXR1cmVzL2FjY2Vzcy9ob29rc1wiO1xyXG5pbXBvcnQgeyBEaWdpdGFsTWVudVBhZ2UgfSBmcm9tIFwiLi9mZWF0dXJlcy9kaWdpdGFsbWVudS9EaWdpdGFsTWVudVBhZ2VcIjtcclxuXHJcbmZ1bmN0aW9uIE1hbmFnZXJHYXRlKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcclxuICAgIGNvbnN0IGZlYXR1cmVzUXVlcnkgPSB1c2VNeUZlYXR1cmVzKCk7XHJcbiAgICBpZiAoZmVhdHVyZXNRdWVyeS5pc0xvYWRpbmcpIHJldHVybiBudWxsO1xyXG4gICAgaWYgKGZlYXR1cmVzUXVlcnkuZGF0YT8uY2FuTWFuYWdlQWNjZXNzKSByZXR1cm4gPD57Y2hpbGRyZW59PC8+O1xyXG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9cIiByZXBsYWNlIC8+O1xyXG59XHJcblxyXG5mdW5jdGlvbiBSZXF1aXJlQXV0aCh7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0Tm9kZSB9KSB7XHJcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IHVzZUF1dGhTdG9yZSgocykgPT4gcy5hY2Nlc3NUb2tlbik7XHJcbiAgICBpZiAoIWFjY2Vzc1Rva2VuKSByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZSAvPjtcclxuICAgIHJldHVybiA8PntjaGlsZHJlbn08Lz47XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFJvdXRlcz5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvbG9naW5cIiBlbGVtZW50PXs8TG9naW5QYWdlIC8+fSAvPlxyXG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9jYWRhc3Ryb1wiIGVsZW1lbnQ9ezxTaWdudXBQYWdlIC8+fSAvPlxyXG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9wZWRpZG8vOnRva2VuXCIgZWxlbWVudD17PFB1YmxpY09yZGVyUGFnZSAvPn0gLz5cclxuXHJcbiAgICAgICAgICAgIHsvKiBSb3RhIGRvIFRhYmxldCBuYSBNZXNhIChTZW0gQXBwU2hlbGwgcGFyYSBzZXIgdGVsYSBjaGVpYSkgKi99XHJcbiAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgcGF0aD1cIi9tZXNhLzptZXNhXCJcclxuICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxSZXF1aXJlQXV0aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZlYXR1cmVHYXRlIGNvZGU9XCJTYWxhb1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERpZ2l0YWxNZW51UGFnZSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0ZlYXR1cmVHYXRlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUmVxdWlyZUF1dGg+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICB7LyogMS4gTW92YSBhIHJvdGEgZG8gR2Fyw6dvbSBwYXJhIEPDgSwgZm9yYSBkbyBBcHBTaGVsbCwgbWFzIGNvbSBSZXF1aXJlQXV0aCAqL31cclxuICAgICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgICAgICBwYXRoPVwiL2dhcmNvbVwiXHJcbiAgICAgICAgICAgICAgICBlbGVtZW50PXtcclxuICAgICAgICAgICAgICAgICAgICA8UmVxdWlyZUF1dGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGZWF0dXJlR2F0ZSBjb2RlPVwiU2FsYW9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxXYWl0ZXJEYXNoYm9hcmRQYWdlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRmVhdHVyZUdhdGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9SZXF1aXJlQXV0aD5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIHsvKiAyLiBPIHJlc3RhbnRlIGRvIHNpc3RlbWEgY29udGludWEgZGVudHJvIGRvIEFwcFNoZWxsICovfVxyXG4gICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxSZXF1aXJlQXV0aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEFwcFNoZWxsIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9SZXF1aXJlQXV0aD5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PEZlYXR1cmVHYXRlIGNvZGU9XCJTYWxhb1wiPjxPcmRlcnNQYWdlIC8+PC9GZWF0dXJlR2F0ZT59IC8+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEEgcm90YSAvZ2FyY29tIGZvaSByZW1vdmlkYSBkYXF1aSAqL31cclxuXHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9kZWxpdmVyeVwiIGVsZW1lbnQ9ezxGZWF0dXJlR2F0ZSBjb2RlPVwiU2FsYW9cIj48RGVsaXZlcnlCb2FyZFBhZ2UgLz48L0ZlYXR1cmVHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3Byb2R1dG9zXCIgZWxlbWVudD17PEZlYXR1cmVHYXRlIGNvZGU9XCJDYXJkYXBpb1wiPjxQcm9kdWN0c1BhZ2UgLz48L0ZlYXR1cmVHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2NvbXBsZW1lbnRvc1wiIGVsZW1lbnQ9ezxGZWF0dXJlR2F0ZSBjb2RlPVwiQ2FyZGFwaW9cIj48Q29tcGxlbWVudHNQYWdlIC8+PC9GZWF0dXJlR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9lc3RvcXVlXCIgZWxlbWVudD17PEZlYXR1cmVHYXRlIGNvZGU9XCJFc3RvcXVlXCI+PFN0b2NrUGFnZSAvPjwvRmVhdHVyZUdhdGU+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvZXF1aXBlXCIgZWxlbWVudD17PE1hbmFnZXJHYXRlPjxFbXBsb3llZXNQYWdlIC8+PC9NYW5hZ2VyR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi91c3Vhcmlvc1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48VXNlcnNQYWdlIC8+PC9NYW5hZ2VyR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9mYXR1cmFtZW50b1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48RmluYW5jZVBhZ2UgLz48L01hbmFnZXJHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2NlbmFyaW9zXCIgZWxlbWVudD17PE1hbmFnZXJHYXRlPjxTY2VuYXJpb3NQYWdlIC8+PC9NYW5hZ2VyR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9yZWxhdG9yaW9zXCIgZWxlbWVudD17PE1hbmFnZXJHYXRlPjxSZXBvcnRzUGFnZSAvPjwvTWFuYWdlckdhdGU+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcHJlcGFyb1wiIGVsZW1lbnQ9ezxGZWF0dXJlR2F0ZSBjb2RlPVwiUHJlcGFyb1wiPjxQcmVwYXJhdGlvblBhZ2UgLz48L0ZlYXR1cmVHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2ZlY2hhbWVudG9zXCIgZWxlbWVudD17PE1hbmFnZXJHYXRlPjxDYXNoSGlzdG9yeVBhZ2UgLz48L01hbmFnZXJHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3Byb21vY29lc1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48UHJvbW90aW9uc1BhZ2UgLz48L01hbmFnZXJHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2ltcHJlc3Nhb1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48UHJpbnRpbmdQYWdlIC8+PC9NYW5hZ2VyR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9jb21wcmFzXCIgZWxlbWVudD17PEZlYXR1cmVHYXRlIGNvZGU9XCJFc3RvcXVlXCI+PFB1cmNoYXNpbmdQYWdlIC8+PC9GZWF0dXJlR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9yZXNlcnZhc1wiIGVsZW1lbnQ9ezxGZWF0dXJlR2F0ZSBjb2RlPVwiU2FsYW9cIj48UmVzZXJ2YXRpb25zUGFnZSAvPjwvRmVhdHVyZUdhdGU+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvY2xpZW50ZXNcIiBlbGVtZW50PXs8RmVhdHVyZUdhdGUgY29kZT1cIlNhbGFvXCI+PEN1c3RvbWVyc1BhZ2UgLz48L0ZlYXR1cmVHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2FjZXNzb3NcIiBlbGVtZW50PXs8TWFuYWdlckdhdGU+PEFjY2Vzc1BhZ2UgLz48L01hbmFnZXJHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2NvbmZpZ3VyYWNvZXNcIiBlbGVtZW50PXs8TWFuYWdlckdhdGU+PFNldHRpbmdzUGFnZSAvPjwvTWFuYWdlckdhdGU+fSAvPlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBJbnRlZ3Jhw6fDtWVzIGlGb29kICovfVxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvaW50ZWdyYWNvZXMvaWZvb2RcIiBlbGVtZW50PXs8TWFuYWdlckdhdGU+PElGb29kSW50ZWdyYXRpb25QYWdlIC8+PC9NYW5hZ2VyR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9pbnRlZ3JhY29lcy9pZm9vZC9kYXNoYm9hcmRcIiBlbGVtZW50PXs8TWFuYWdlckdhdGU+PElGb29kRGFzaGJvYXJkUGFnZSAvPjwvTWFuYWdlckdhdGU+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvaW50ZWdyYWNvZXMvaWZvb2Qvc3RhdHVzXCIgZWxlbWVudD17PE1hbmFnZXJHYXRlPjxJRm9vZFN0YXR1c0RldGFpbGVkUGFnZSAvPjwvTWFuYWdlckdhdGU+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvaW50ZWdyYWNvZXMvaWZvb2QvcGVkaWRvc1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48SUZvb2RPcmRlcnNQYWdlIC8+PC9NYW5hZ2VyR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9pbnRlZ3JhY29lcy9pZm9vZC9zaGlwcGluZ1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48SUZvb2RTaGlwcGluZ1BhZ2UgLz48L01hbmFnZXJHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2ludGVncmFjb2VzL2lmb29kL2xvZ2lzdGljYVwiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48SUZvb2RMb2dpc3RpY3NQYWdlIC8+PC9NYW5hZ2VyR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9pbnRlZ3JhY29lcy9pZm9vZC9jYXRhbG9nb1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48SUZvb2RDYXRhbG9nUGFnZSAvPjwvTWFuYWdlckdhdGU+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvaW50ZWdyYWNvZXMvaWZvb2QvYXZhbGlhY29lc1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48SUZvb2RSZXZpZXdzRGV0YWlsZWRQYWdlIC8+PC9NYW5hZ2VyR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9pbnRlZ3JhY29lcy9pZm9vZC9pbmRpY2Fkb3Jlc1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48SUZvb2RBbmFseXRpY3NFbmhhbmNlZFBhZ2UgLz48L01hbmFnZXJHYXRlPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2ludGVncmFjb2VzL2lmb29kL2ZpbmFuY2Vpcm8vcmVsYXRvcmlvc1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48SUZvb2RGaW5hbmNpYWxSZXBvcnRzUGFnZSAvPjwvTWFuYWdlckdhdGU+fSAvPlxyXG5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3ByYWNhc1wiIGVsZW1lbnQ9ezxNYW5hZ2VyR2F0ZT48RGluaW5nQXJlYXNQYWdlIC8+PC9NYW5hZ2VyR2F0ZT59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9zZW0tYWNlc3NvXCIgZWxlbWVudD17PE5vQWNjZXNzUGFnZSAvPn0gLz5cclxuICAgICAgICAgICAgPC9Sb3V0ZT5cclxuXHJcbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiKlwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9cIiByZXBsYWNlIC8+fSAvPlxyXG4gICAgICAgIDwvUm91dGVzPlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9BcHAudHN4In0=