import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/EmptyState.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/EmptyState.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function EmptyState({ icon, title, description, action }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "rise",
      style: {
        display: "grid",
        placeItems: "center",
        textAlign: "center",
        gap: 10,
        padding: "48px 24px",
        color: "var(--ink-faint)"
      },
      children: [
        icon && /* @__PURE__ */ jsxDEV("div", { "aria-hidden": "true", style: { fontSize: "2.4rem", lineHeight: 1 }, children: icon }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/EmptyState.tsx",
          lineNumber: 49,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.3rem", color: "var(--ink)" }, children: title }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/EmptyState.tsx",
          lineNumber: 53,
          columnNumber: 7
        }, this),
        description && /* @__PURE__ */ jsxDEV("span", { style: { maxWidth: 360 }, children: description }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/EmptyState.tsx",
          lineNumber: 56,
          columnNumber: 23
        }, this),
        action && /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 6 }, children: action }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/EmptyState.tsx",
          lineNumber: 57,
          columnNumber: 18
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/EmptyState.tsx",
      lineNumber: 37,
      columnNumber: 5
    },
    this
  );
}
_c = EmptyState;
var _c;
$RefreshReg$(_c, "EmptyState");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/EmptyState.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/EmptyState.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJROzs7Ozs7Ozs7Ozs7Ozs7O0FBZEQsZ0JBQVNBLFdBQVcsRUFBRUMsTUFBTUMsT0FBT0MsYUFBYUMsT0FBYyxHQUFHO0FBQ3RFLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLE9BQU87QUFBQSxRQUNMQyxTQUFTO0FBQUEsUUFDVEMsWUFBWTtBQUFBLFFBQ1pDLFdBQVc7QUFBQSxRQUNYQyxLQUFLO0FBQUEsUUFDTEMsU0FBUztBQUFBLFFBQ1RDLE9BQU87QUFBQSxNQUNUO0FBQUEsTUFFQ1Q7QUFBQUEsZ0JBQ0MsdUJBQUMsU0FBSSxlQUFZLFFBQU8sT0FBTyxFQUFFVSxVQUFVLFVBQVVDLFlBQVksRUFBRSxHQUNoRVgsa0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFRix1QkFBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVVLFVBQVUsVUFBVUQsT0FBTyxhQUFhLEdBQ3hFUixtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDQyxlQUFlLHVCQUFDLFVBQUssT0FBTyxFQUFFVSxVQUFVLElBQUksR0FBSVYseUJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM1REMsVUFBVSx1QkFBQyxTQUFJLE9BQU8sRUFBRVUsV0FBVyxFQUFFLEdBQUlWLG9CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDO0FBQUE7QUFBQTtBQUFBLElBcEJuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFxQkE7QUFFSjtBQUFDVyxLQXpCZWY7QUFBVSxJQUFBZTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJFbXB0eVN0YXRlIiwiaWNvbiIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY3Rpb24iLCJkaXNwbGF5IiwicGxhY2VJdGVtcyIsInRleHRBbGlnbiIsImdhcCIsInBhZGRpbmciLCJjb2xvciIsImZvbnRTaXplIiwibGluZUhlaWdodCIsIm1heFdpZHRoIiwibWFyZ2luVG9wIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRW1wdHlTdGF0ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgaWNvbj86IFJlYWN0Tm9kZTtcclxuICB0aXRsZTogc3RyaW5nO1xyXG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xyXG4gIGFjdGlvbj86IFJlYWN0Tm9kZTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEVzdGFkbyB2YXppbyBjb20gaGllcmFycXVpYSBjbGFyYSArIENUQSBvcGNpb25hbC4gVXNhciBubyBsdWdhciBkZSB1bWFcclxuICogw7puaWNhIGxpbmhhIGRlIHRleHRvIGNpbnphIChcIk5lbmh1bSBYIGNhZGFzdHJhZG8uXCIpIHNlbXByZSBxdWUgdW1hIGxpc3RhXHJcbiAqIG91IGNvbnN1bHRhIHZvbHRhciB2YXppYSDigJQgZMOhIGNvbnRleHRvIGUgdW0gY2FtaW5obyBkZSBhw6fDo28sIGVtIHZleiBkZVxyXG4gKiBkZWl4YXIgYSBwZXNzb2Egc2VtIHNhYmVyIG8gcXVlIGZhemVyIGEgc2VndWlyLlxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIEVtcHR5U3RhdGUoeyBpY29uLCB0aXRsZSwgZGVzY3JpcHRpb24sIGFjdGlvbiB9OiBQcm9wcykge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzTmFtZT1cInJpc2VcIlxyXG4gICAgICBzdHlsZT17e1xyXG4gICAgICAgIGRpc3BsYXk6IFwiZ3JpZFwiLFxyXG4gICAgICAgIHBsYWNlSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgdGV4dEFsaWduOiBcImNlbnRlclwiLFxyXG4gICAgICAgIGdhcDogMTAsXHJcbiAgICAgICAgcGFkZGluZzogXCI0OHB4IDI0cHhcIixcclxuICAgICAgICBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsXHJcbiAgICAgIH19XHJcbiAgICA+XHJcbiAgICAgIHtpY29uICYmIChcclxuICAgICAgICA8ZGl2IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjIuNHJlbVwiLCBsaW5lSGVpZ2h0OiAxIH19PlxyXG4gICAgICAgICAge2ljb259XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjNyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rKVwiIH19PlxyXG4gICAgICAgIHt0aXRsZX1cclxuICAgICAgPC9zcGFuPlxyXG4gICAgICB7ZGVzY3JpcHRpb24gJiYgPHNwYW4gc3R5bGU9e3sgbWF4V2lkdGg6IDM2MCB9fT57ZGVzY3JpcHRpb259PC9zcGFuPn1cclxuICAgICAge2FjdGlvbiAmJiA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogNiB9fT57YWN0aW9ufTwvZGl2Pn1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL3VpL0VtcHR5U3RhdGUudHN4In0=