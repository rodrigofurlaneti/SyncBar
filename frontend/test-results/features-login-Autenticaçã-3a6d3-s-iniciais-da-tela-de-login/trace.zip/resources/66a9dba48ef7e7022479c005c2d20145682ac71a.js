import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/WaiterTabBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterTabBar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { tabs } from "/src/features/waiter/utils.ts";
export function WaiterTabBar({ activeTab, onTabChange }) {
  return /* @__PURE__ */ jsxDEV("nav", { className: "waiter-tabbar", "aria-label": "Navegação do Modo Garçom", children: tabs.map(
    (tab) => /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: `waiter-tab${tab.key === activeTab ? " is-active" : ""}`,
        onClick: () => onTabChange(tab.key),
        children: [
          /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", children: tab.icon }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterTabBar.tsx",
            lineNumber: 37,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: tab.label }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterTabBar.tsx",
            lineNumber: 38,
            columnNumber: 21
          }, this)
        ]
      },
      tab.key,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterTabBar.tsx",
        lineNumber: 31,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterTabBar.tsx",
    lineNumber: 29,
    columnNumber: 5
  }, this);
}
_c = WaiterTabBar;
var _c;
$RefreshReg$(_c, "WaiterTabBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterTabBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterTabBar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJvQjs7Ozs7Ozs7Ozs7Ozs7OztBQWpCbkIsU0FBaUJBLFlBQVk7QUFPdkIsZ0JBQVNDLGFBQWEsRUFBRUMsV0FBV0MsWUFBK0IsR0FBRztBQUN4RSxTQUNJLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsY0FBVyw0QkFDckNILGVBQUtJO0FBQUFBLElBQUksQ0FBQ0MsUUFDUDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBRUcsTUFBSztBQUFBLFFBQ0wsV0FBVyxhQUFhQSxJQUFJQyxRQUFRSixZQUFZLGVBQWUsRUFBRTtBQUFBLFFBQ2pFLFNBQVMsTUFBTUMsWUFBWUUsSUFBSUMsR0FBRztBQUFBLFFBRWxDO0FBQUEsaUNBQUMsVUFBSyxlQUFZLFFBQVFELGNBQUlFLFFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1DO0FBQUEsVUFDbkMsdUJBQUMsVUFBTUYsY0FBSUcsU0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQjtBQUFBO0FBQUE7QUFBQSxNQU5aSCxJQUFJQztBQUFBQSxNQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRQTtBQUFBLEVBQ0gsS0FYTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFUjtBQUFDRyxLQWhCZVI7QUFBWSxJQUFBUTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ0YWJzIiwiV2FpdGVyVGFiQmFyIiwiYWN0aXZlVGFiIiwib25UYWJDaGFuZ2UiLCJtYXAiLCJ0YWIiLCJrZXkiLCJpY29uIiwibGFiZWwiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJXYWl0ZXJUYWJCYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IFRhYktleSwgdGFicyB9IGZyb20gXCIuLi91dGlsc1wiO1xyXG5cclxuaW50ZXJmYWNlIFdhaXRlclRhYkJhclByb3BzIHtcclxuICAgIGFjdGl2ZVRhYjogVGFiS2V5O1xyXG4gICAgb25UYWJDaGFuZ2U6IChrZXk6IFRhYktleSkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFdhaXRlclRhYkJhcih7IGFjdGl2ZVRhYiwgb25UYWJDaGFuZ2UgfTogV2FpdGVyVGFiQmFyUHJvcHMpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJ3YWl0ZXItdGFiYmFyXCIgYXJpYS1sYWJlbD1cIk5hdmVnYcOnw6NvIGRvIE1vZG8gR2Fyw6dvbVwiPlxyXG4gICAgICAgICAgICB7dGFicy5tYXAoKHRhYikgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17dGFiLmtleX1cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3YWl0ZXItdGFiJHt0YWIua2V5ID09PSBhY3RpdmVUYWIgPyBcIiBpcy1hY3RpdmVcIiA6IFwiXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblRhYkNoYW5nZSh0YWIua2V5KX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj57dGFiLmljb259PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt0YWIubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvbmF2PlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy93YWl0ZXIvY29tcG9uZW50cy9XYWl0ZXJUYWJCYXIudHN4In0=