import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/Overlay.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/Overlay.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Modal } from "/src/ui/Modal.tsx";
export function Overlay({ title, onClose, children, wide = false }) {
  return /* @__PURE__ */ jsxDEV(Modal, { title, onClose, variant: wide ? "drawer" : "center", children }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/Overlay.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_c = Overlay;
var _c;
$RefreshReg$(_c, "Overlay");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/Overlay.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/Overlay.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYSixTQUFTQSxhQUFhO0FBU2YsZ0JBQVNDLFFBQVEsRUFBRUMsT0FBT0MsU0FBU0MsVUFBVUMsT0FBTyxNQUFhLEdBQUc7QUFDekUsU0FDRSx1QkFBQyxTQUFNLE9BQWMsU0FBa0IsU0FBU0EsT0FBTyxXQUFXLFVBQy9ERCxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNFLEtBTmVMO0FBQU8sSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTW9kYWwiLCJPdmVybGF5IiwidGl0bGUiLCJvbkNsb3NlIiwiY2hpbGRyZW4iLCJ3aWRlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT3ZlcmxheS50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiLi4vLi4vdWkvTW9kYWxcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XHJcbiAgd2lkZT86IGJvb2xlYW47XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBPdmVybGF5KHsgdGl0bGUsIG9uQ2xvc2UsIGNoaWxkcmVuLCB3aWRlID0gZmFsc2UgfTogUHJvcHMpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsIHRpdGxlPXt0aXRsZX0gb25DbG9zZT17b25DbG9zZX0gdmFyaWFudD17d2lkZSA/IFwiZHJhd2VyXCIgOiBcImNlbnRlclwifT5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9Nb2RhbD5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9vcmRlcnMvT3ZlcmxheS50c3gifQ==