import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/StatusBadge.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/StatusBadge.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function StatusBadge({ color = "var(--ink-faint)", children, title }) {
  return /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": color }, title, children }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/StatusBadge.tsx",
    lineNumber: 35,
    columnNumber: 5
  }, this);
}
_c = StatusBadge;
var _c;
$RefreshReg$(_c, "StatusBadge");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/StatusBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/StatusBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFGRyxnQkFBU0EsWUFBWSxFQUFFQyxRQUFRLG9CQUFvQkMsVUFBVUMsTUFBYSxHQUFHO0FBQ2xGLFNBQ0UsdUJBQUMsVUFBSyxXQUFVLFFBQU8sT0FBTyxFQUFFLFNBQVNGLE1BQU0sR0FBb0IsT0FDaEVDLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ0UsS0FOZUo7QUFBVyxJQUFBSTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJTdGF0dXNCYWRnZSIsImNvbG9yIiwiY2hpbGRyZW4iLCJ0aXRsZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlN0YXR1c0JhZGdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENTU1Byb3BlcnRpZXMsIFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICAvKiogY29yIGRvIHBvbnRvL2VzdGFkbyAodG9rZW4gQ1NTLCBleC46IFwidmFyKC0tZnJlZSlcIikgKi9cbiAgY29sb3I/OiBzdHJpbmc7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG4gIHRpdGxlPzogc3RyaW5nO1xufVxuXG4vKipcbiAqIFNlbG8gZGUgc3RhdHVzIOKAlCBudW5jYSBjb211bmljYSBzw7MgcG9yIGNvcjogbyByw7N0dWxvIHRleHR1YWwgYWNvbXBhbmhhXG4gKiBvIHBvbnRvIGNvbG9yaWRvIChhY2Vzc8OtdmVsIHBhcmEgZGFsdMO0bmljb3MpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gU3RhdHVzQmFkZ2UoeyBjb2xvciA9IFwidmFyKC0taW5rLWZhaW50KVwiLCBjaGlsZHJlbiwgdGl0bGUgfTogUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGlwXCIgc3R5bGU9e3sgXCItLWRvdFwiOiBjb2xvciB9IGFzIENTU1Byb3BlcnRpZXN9IHRpdGxlPXt0aXRsZX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9zcGFuPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL3VpL1N0YXR1c0JhZGdlLnRzeCJ9