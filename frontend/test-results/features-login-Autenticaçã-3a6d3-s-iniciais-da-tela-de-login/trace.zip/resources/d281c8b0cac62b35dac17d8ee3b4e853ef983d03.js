import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/users/UsersPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { useDialog } from "/src/ui/Dialog.tsx";
import { createRole, createUser, deactivateUser, getRoles, getUsersByCompany, updateUserRoles } from "/src/features/users/api.ts";
import { getEmployeesByBranch } from "/src/features/employees/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { Overlay } from "/src/features/orders/Overlay.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
export function UsersPage() {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const { companyId, branchId } = useAuthStore();
  const [creating, setCreating] = useState(false);
  const [editingRoles, setEditingRoles] = useState(null);
  const [userName, setUserName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [selectedRoles, setSelectedRoles] = useState([]);
  const [newRoleName, setNewRoleName] = useState("");
  const [newRoleDescription, setNewRoleDescription] = useState("");
  const [error, setError] = useState(null);
  const usersQuery = useQuery({
    queryKey: ["users", companyId],
    queryFn: () => getUsersByCompany(companyId ?? 1)
  });
  const rolesQuery = useQuery({
    queryKey: ["roles", companyId],
    queryFn: () => getRoles(companyId ?? 1)
  });
  const employeesQuery = useQuery({
    queryKey: ["employees", branchId],
    queryFn: () => getEmployeesByBranch(branchId)
  });
  const roleName = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const r of rolesQuery.data ?? []) map.set(r.id, r.name);
    return map;
  }, [rolesQuery.data]);
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["users"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const toggleRole = (roleId) => setSelectedRoles(
    (current) => current.includes(roleId) ? current.filter((id) => id !== roleId) : [...current, roleId]
  );
  const createMutation = useMutation({
    mutationFn: () => createUser({
      companyId: companyId ?? 1,
      employeeId: employeeId === "" ? null : Number(employeeId),
      userName: userName.trim(),
      email: email.trim(),
      password,
      roleIds: selectedRoles
    }),
    onSuccess: () => {
      setCreating(false);
      setUserName("");
      setEmail("");
      setPassword("");
      setEmployeeId("");
      setSelectedRoles([]);
      refresh();
    },
    onError: onApiError
  });
  const rolesMutation = useMutation({
    mutationFn: () => updateUserRoles(editingRoles.id, selectedRoles),
    onSuccess: () => {
      setEditingRoles(null);
      refresh();
    },
    onError: onApiError
  });
  const deactivateMutation = useMutation({
    mutationFn: (id) => deactivateUser(id),
    onSuccess: refresh,
    onError: onApiError
  });
  const createRoleMutation = useMutation({
    mutationFn: () => createRole({
      companyId: companyId ?? 1,
      name: newRoleName.trim(),
      description: newRoleDescription.trim() === "" ? null : newRoleDescription.trim()
    }),
    onSuccess: async (newRoleId) => {
      setNewRoleName("");
      setNewRoleDescription("");
      setError(null);
      await queryClient.invalidateQueries({ queryKey: ["roles"] });
      setSelectedRoles((current) => current.includes(newRoleId) ? current : [...current, newRoleId]);
    },
    onError: onApiError
  });
  const roleChecklist = /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 6 }, children: [
    /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Perfis" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
      lineNumber: 133,
      columnNumber: 7
    }, this),
    (rolesQuery.data ?? []).map(
      (role) => /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", gap: 10, alignItems: "center" }, children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            style: { width: 20, minHeight: 20 },
            checked: selectedRoles.includes(role.id),
            onChange: () => toggleRole(role.id)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
            lineNumber: 136,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { children: [
          role.name,
          role.description ? /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.8rem" }, children: [
            " — ",
            role.description
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
            lineNumber: 145,
            columnNumber: 9
          }, this) : null
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 142,
          columnNumber: 11
        }, this)
      ] }, role.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 135,
        columnNumber: 5
      }, this)
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          display: "grid",
          gap: 6,
          marginTop: 4,
          paddingTop: 10,
          borderTop: "1px solid var(--line)"
        },
        children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.8rem" }, children: "Não achou o perfil que precisa? Crie um novo abaixo (ex.: Garçom, Cozinha) — ele já aparece marcado na lista acima." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
            lineNumber: 160,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                placeholder: "Nome do novo perfil",
                value: newRoleName,
                onChange: (e) => setNewRoleName(e.target.value),
                style: { flex: 1 }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
                lineNumber: 165,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                placeholder: "Descrição (opcional)",
                value: newRoleDescription,
                onChange: (e) => setNewRoleDescription(e.target.value),
                style: { flex: 1 }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
                lineNumber: 171,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "btn-ghost",
                style: { minHeight: 44, padding: "0 14px", fontSize: "0.85rem", whiteSpace: "nowrap" },
                disabled: newRoleName.trim() === "" || createRoleMutation.isPending,
                onClick: () => createRoleMutation.mutate(),
                children: createRoleMutation.isPending ? "Criando…" : "+ Novo perfil"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
                lineNumber: 177,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
            lineNumber: 164,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 151,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
    lineNumber: 132,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 16 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Usuários e perfis" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 194,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 195,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          onClick: () => {
            setError(null);
            setSelectedRoles([]);
            setCreating(true);
          },
          children: "+ Novo usuário"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 196,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
      lineNumber: 193,
      columnNumber: 7
    }, this),
    error && !creating && editingRoles === null && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
      lineNumber: 209,
      columnNumber: 55
    }, this),
    usersQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: usersQuery.error, what: "os usuários" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
      lineNumber: 210,
      columnNumber: 30
    }, this),
    rolesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: rolesQuery.error, what: "os perfis" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
      lineNumber: 211,
      columnNumber: 30
    }, this),
    usersQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 5, rowHeight: 58 }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
      lineNumber: 213,
      columnNumber: 32
    }, this),
    !usersQuery.isLoading && usersQuery.data?.length === 0 && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: "👤",
        title: "Nenhum usuário cadastrado",
        description: "Crie o primeiro usuário para dar acesso ao sistema à equipe.",
        action: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "btn-primary",
            onClick: () => {
              setError(null);
              setSelectedRoles([]);
              setCreating(true);
            },
            children: "+ Novo usuário"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
            lineNumber: 221,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 216,
        columnNumber: 7
      },
      this
    ),
    !usersQuery.isLoading && (usersQuery.data?.length ?? 0) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket rise rise-1", children: (usersQuery.data ?? []).map(
      (user) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { opacity: user.isActive ? 1 : 0.45 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
          /* @__PURE__ */ jsxDEV("span", { children: [
            user.userName,
            !user.isActive && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--danger)" }, children: " · desativado" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
              lineNumber: 243,
              columnNumber: 36
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
            lineNumber: 241,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
            user.email,
            " · ",
            user.roleIds.length > 0 ? user.roleIds.map((id) => roleName.get(id) ?? id).join(", ") : "sem perfil"
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
            lineNumber: 245,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 240,
          columnNumber: 13
        }, this),
        user.isActive && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost",
              style: { minHeight: 44, padding: "0 12px", fontSize: "0.85rem" },
              onClick: () => {
                setError(null);
                setSelectedRoles(user.roleIds);
                setEditingRoles(user);
              },
              children: "Perfis"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
              lineNumber: 255,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-danger",
              style: { minHeight: 44, padding: "0 12px", fontSize: "0.85rem" },
              onClick: async () => {
                if (await dialog.confirm({
                  title: "Desativar usuário",
                  message: `Desativar o usuário "${user.userName}"?`,
                  confirmLabel: "Desativar",
                  danger: true
                }))
                  deactivateMutation.mutate(user.id);
              },
              children: "Desativar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
              lineNumber: 267,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 254,
          columnNumber: 11
        }, this)
      ] }, user.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 239,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
      lineNumber: 237,
      columnNumber: 7
    }, this),
    creating && /* @__PURE__ */ jsxDEV(Overlay, { title: "Novo usuário", onClose: () => setCreating(false), children: [
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Usuário" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 295,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("input", { value: userName, onChange: (e) => setUserName(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 296,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 294,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "E-mail" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 299,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("input", { value: email, onChange: (e) => setEmail(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 300,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 298,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Senha (mín. 8 caracteres)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 303,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "password", value: password, onChange: (e) => setPassword(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 304,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 302,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Funcionário vinculado (opcional)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 307,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("select", { value: employeeId, onChange: (e) => setEmployeeId(e.target.value), children: [
          /* @__PURE__ */ jsxDEV("option", { value: "", children: "Nenhum" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
            lineNumber: 309,
            columnNumber: 15
          }, this),
          (employeesQuery.data ?? []).map(
            (emp) => /* @__PURE__ */ jsxDEV("option", { value: emp.id, children: emp.name }, emp.id, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
              lineNumber: 311,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 308,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 306,
        columnNumber: 11
      }, this),
      roleChecklist,
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 316,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          disabled: userName.trim() === "" || email.trim() === "" || password.length < 8 || selectedRoles.length === 0 || createMutation.isPending,
          onClick: () => createMutation.mutate(),
          children: createMutation.isPending ? "Criando…" : "Criar usuário"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 317,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
      lineNumber: 293,
      columnNumber: 7
    }, this),
    editingRoles !== null && /* @__PURE__ */ jsxDEV(Overlay, { title: `Perfis — ${editingRoles.userName}`, onClose: () => setEditingRoles(null), children: [
      roleChecklist,
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
        lineNumber: 334,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          disabled: selectedRoles.length === 0 || rolesMutation.isPending,
          onClick: () => rolesMutation.mutate(),
          children: "Salvar perfis"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
          lineNumber: 335,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
      lineNumber: 332,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx",
    lineNumber: 192,
    columnNumber: 5
  }, this);
}
_s(UsersPage, "4O5/kNFRy/c7yWuv6YQROWssZ5s=", false, function() {
  return [useQueryClient, useDialog, useAuthStore, useQuery, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation];
});
_c = UsersPage;
var _c;
$RefreshReg$(_c, "UsersPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/users/UsersPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUhNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpITixTQUFTQSxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxZQUFZQyxZQUFZQyxnQkFBZ0JDLFVBQVVDLG1CQUFtQkMsdUJBQXVCO0FBQ3JHLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxvQkFBb0I7QUFFdEIsZ0JBQVNDLFlBQVk7QUFBQUMsS0FBQTtBQUMxQixRQUFNQyxjQUFjakIsZUFBZTtBQUNuQyxRQUFNa0IsU0FBU2pCLFVBQVU7QUFDekIsUUFBTSxFQUFFa0IsV0FBV0MsU0FBUyxJQUFJWCxhQUFhO0FBQzdDLFFBQU0sQ0FBQ1ksVUFBVUMsV0FBVyxJQUFJekIsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzBCLGNBQWNDLGVBQWUsSUFBSTNCLFNBQThCLElBQUk7QUFDMUUsUUFBTSxDQUFDNEIsVUFBVUMsV0FBVyxJQUFJN0IsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQzhCLE9BQU9DLFFBQVEsSUFBSS9CLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNnQyxVQUFVQyxXQUFXLElBQUlqQyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDa0MsWUFBWUMsYUFBYSxJQUFJbkMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ29DLGVBQWVDLGdCQUFnQixJQUFJckMsU0FBbUIsRUFBRTtBQUMvRCxRQUFNLENBQUNzQyxhQUFhQyxjQUFjLElBQUl2QyxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDd0Msb0JBQW9CQyxxQkFBcUIsSUFBSXpDLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUMwQyxPQUFPQyxRQUFRLElBQUkzQyxTQUF3QixJQUFJO0FBRXRELFFBQU00QyxhQUFhMUMsU0FBUztBQUFBLElBQzFCMkMsVUFBVSxDQUFDLFNBQVN2QixTQUFTO0FBQUEsSUFDN0J3QixTQUFTQSxNQUFNckMsa0JBQWtCYSxhQUFhLENBQUM7QUFBQSxFQUNqRCxDQUFDO0FBRUQsUUFBTXlCLGFBQWE3QyxTQUFTO0FBQUEsSUFDMUIyQyxVQUFVLENBQUMsU0FBU3ZCLFNBQVM7QUFBQSxJQUM3QndCLFNBQVNBLE1BQU10QyxTQUFTYyxhQUFhLENBQUM7QUFBQSxFQUN4QyxDQUFDO0FBRUQsUUFBTTBCLGlCQUFpQjlDLFNBQVM7QUFBQSxJQUM5QjJDLFVBQVUsQ0FBQyxhQUFhdEIsUUFBUTtBQUFBLElBQ2hDdUIsU0FBU0EsTUFBTW5DLHFCQUFxQlksUUFBUTtBQUFBLEVBQzlDLENBQUM7QUFFRCxRQUFNMEIsV0FBV2xELFFBQVEsTUFBTTtBQUM3QixVQUFNbUQsTUFBTSxvQkFBSUMsSUFBb0I7QUFDcEMsZUFBV0MsS0FBS0wsV0FBV00sUUFBUSxHQUFJSCxLQUFJSSxJQUFJRixFQUFFRyxJQUFJSCxFQUFFSSxJQUFJO0FBQzNELFdBQU9OO0FBQUFBLEVBQ1QsR0FBRyxDQUFDSCxXQUFXTSxJQUFJLENBQUM7QUFFcEIsUUFBTUksVUFBVUEsTUFBTSxLQUFLckMsWUFBWXNDLGtCQUFrQixFQUFFYixVQUFVLENBQUMsT0FBTyxFQUFFLENBQUM7QUFFaEYsUUFBTWMsYUFBYUEsQ0FBQ0MsTUFDbEJqQixTQUFTaUIsYUFBYS9DLFdBQVcrQyxFQUFFQyxVQUFVLGtCQUFrQjtBQUVqRSxRQUFNQyxhQUFhQSxDQUFDQyxXQUNsQjFCO0FBQUFBLElBQWlCLENBQUMyQixZQUNoQkEsUUFBUUMsU0FBU0YsTUFBTSxJQUFJQyxRQUFRRSxPQUFPLENBQUNYLE9BQU9BLE9BQU9RLE1BQU0sSUFBSSxDQUFDLEdBQUdDLFNBQVNELE1BQU07QUFBQSxFQUN4RjtBQUVGLFFBQU1JLGlCQUFpQmxFLFlBQVk7QUFBQSxJQUNqQ21FLFlBQVlBLE1BQ1Y5RCxXQUFXO0FBQUEsTUFDVGdCLFdBQVdBLGFBQWE7QUFBQSxNQUN4QlksWUFBWUEsZUFBZSxLQUFLLE9BQU9tQyxPQUFPbkMsVUFBVTtBQUFBLE1BQ3hETixVQUFVQSxTQUFTMEMsS0FBSztBQUFBLE1BQ3hCeEMsT0FBT0EsTUFBTXdDLEtBQUs7QUFBQSxNQUNsQnRDO0FBQUFBLE1BQ0F1QyxTQUFTbkM7QUFBQUEsSUFDWCxDQUFDO0FBQUEsSUFDSG9DLFdBQVdBLE1BQU07QUFDZi9DLGtCQUFZLEtBQUs7QUFDakJJLGtCQUFZLEVBQUU7QUFBR0UsZUFBUyxFQUFFO0FBQUdFLGtCQUFZLEVBQUU7QUFBR0Usb0JBQWMsRUFBRTtBQUFHRSx1QkFBaUIsRUFBRTtBQUN0Rm9CLGNBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQWdCLFNBQVNkO0FBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1lLGdCQUFnQnpFLFlBQVk7QUFBQSxJQUNoQ21FLFlBQVlBLE1BQU0xRCxnQkFBZ0JnQixhQUFjNkIsSUFBSW5CLGFBQWE7QUFBQSxJQUNqRW9DLFdBQVdBLE1BQU07QUFDZjdDLHNCQUFnQixJQUFJO0FBQ3BCOEIsY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBZ0IsU0FBU2Q7QUFBQUEsRUFDWCxDQUFDO0FBRUQsUUFBTWdCLHFCQUFxQjFFLFlBQVk7QUFBQSxJQUNyQ21FLFlBQVlBLENBQUNiLE9BQWVoRCxlQUFlZ0QsRUFBRTtBQUFBLElBQzdDaUIsV0FBV2Y7QUFBQUEsSUFDWGdCLFNBQVNkO0FBQUFBLEVBQ1gsQ0FBQztBQUlELFFBQU1pQixxQkFBcUIzRSxZQUFZO0FBQUEsSUFDckNtRSxZQUFZQSxNQUNWL0QsV0FBVztBQUFBLE1BQ1RpQixXQUFXQSxhQUFhO0FBQUEsTUFDeEJrQyxNQUFNbEIsWUFBWWdDLEtBQUs7QUFBQSxNQUN2Qk8sYUFBYXJDLG1CQUFtQjhCLEtBQUssTUFBTSxLQUFLLE9BQU85QixtQkFBbUI4QixLQUFLO0FBQUEsSUFDakYsQ0FBQztBQUFBLElBQ0hFLFdBQVcsT0FBT00sY0FBYztBQUM5QnZDLHFCQUFlLEVBQUU7QUFDakJFLDRCQUFzQixFQUFFO0FBQ3hCRSxlQUFTLElBQUk7QUFDYixZQUFNdkIsWUFBWXNDLGtCQUFrQixFQUFFYixVQUFVLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDM0RSLHVCQUFpQixDQUFDMkIsWUFBYUEsUUFBUUMsU0FBU2EsU0FBUyxJQUFJZCxVQUFVLENBQUMsR0FBR0EsU0FBU2MsU0FBUyxDQUFFO0FBQUEsSUFDakc7QUFBQSxJQUNBTCxTQUFTZDtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNb0IsZ0JBQ0osdUJBQUMsU0FBSSxPQUFPLEVBQUVDLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsMkJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCQyxVQUFVLFVBQVUsR0FBRyxzQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRTtBQUFBLEtBQ25FcEMsV0FBV00sUUFBUSxJQUFJSDtBQUFBQSxNQUFJLENBQUNrQyxTQUM1Qix1QkFBQyxXQUFvQixPQUFPLEVBQUVKLFNBQVMsUUFBUUMsS0FBSyxJQUFJSSxZQUFZLFNBQVMsR0FDM0U7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBTyxFQUFFQyxPQUFPLElBQUlDLFdBQVcsR0FBRztBQUFBLFlBQ2xDLFNBQVNuRCxjQUFjNkIsU0FBU21CLEtBQUs3QixFQUFFO0FBQUEsWUFDdkMsVUFBVSxNQUFNTyxXQUFXc0IsS0FBSzdCLEVBQUU7QUFBQTtBQUFBLFVBSnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlzQztBQUFBLFFBRXRDLHVCQUFDLFVBQ0U2QjtBQUFBQSxlQUFLNUI7QUFBQUEsVUFDTDRCLEtBQUtQLGNBQ0osdUJBQUMsVUFBSyxPQUFPLEVBQUVLLE9BQU8sb0JBQW9CQyxVQUFVLFNBQVMsR0FBRztBQUFBO0FBQUEsWUFBSUMsS0FBS1A7QUFBQUEsZUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUYsSUFDbkY7QUFBQSxhQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBWlVPLEtBQUs3QixJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxJQUNEO0FBQUEsSUFFRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFVBQ0x5QixTQUFTO0FBQUEsVUFDVEMsS0FBSztBQUFBLFVBQ0xPLFdBQVc7QUFBQSxVQUNYQyxZQUFZO0FBQUEsVUFDWkMsV0FBVztBQUFBLFFBQ2I7QUFBQSxRQUVBO0FBQUEsaUNBQUMsVUFBSyxPQUFPLEVBQUVSLE9BQU8sb0JBQW9CQyxVQUFVLFNBQVMsR0FBRyxtSUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVILFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osT0FBTzNDO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ3NCLE1BQU1yQixlQUFlcUIsRUFBRStCLE9BQU9DLEtBQUs7QUFBQSxnQkFDOUMsT0FBTyxFQUFFQyxNQUFNLEVBQUU7QUFBQTtBQUFBLGNBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlxQjtBQUFBLFlBRXJCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsYUFBWTtBQUFBLGdCQUNaLE9BQU9yRDtBQUFBQSxnQkFDUCxVQUFVLENBQUNvQixNQUFNbkIsc0JBQXNCbUIsRUFBRStCLE9BQU9DLEtBQUs7QUFBQSxnQkFDckQsT0FBTyxFQUFFQyxNQUFNLEVBQUU7QUFBQTtBQUFBLGNBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlxQjtBQUFBLFlBRXJCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixPQUFPLEVBQUVOLFdBQVcsSUFBSU8sU0FBUyxVQUFVWCxVQUFVLFdBQVdZLFlBQVksU0FBUztBQUFBLGdCQUNyRixVQUFVekQsWUFBWWdDLEtBQUssTUFBTSxNQUFNTSxtQkFBbUJvQjtBQUFBQSxnQkFDMUQsU0FBUyxNQUFNcEIsbUJBQW1CcUIsT0FBTztBQUFBLGdCQUV4Q3JCLDZCQUFtQm9CLFlBQVksYUFBYTtBQUFBO0FBQUEsY0FQL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBO0FBQUE7QUFBQSxNQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFvQ0E7QUFBQSxPQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0RBO0FBR0YsU0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUYsU0FBUyxJQUFJSSxVQUFVLE1BQU1DLFFBQVEsU0FBUyxHQUMzRDtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRW5CLFNBQVMsUUFBUUssWUFBWSxZQUFZSixLQUFLLElBQUltQixjQUFjLEdBQUcsR0FDaEc7QUFBQSw2QkFBQyxRQUFHLFdBQVUsV0FBVSxPQUFPLEVBQUVqQixVQUFVLFNBQVMsR0FBRyxpQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RTtBQUFBLE1BQ3hFLHVCQUFDLFVBQUssT0FBTyxFQUFFVSxNQUFNLEVBQUUsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFDVixTQUFTLE1BQU07QUFDYmxELHFCQUFTLElBQUk7QUFDYk4sNkJBQWlCLEVBQUU7QUFDbkJaLHdCQUFZLElBQUk7QUFBQSxVQUNsQjtBQUFBLFVBQUU7QUFBQTtBQUFBLFFBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxTQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBRUNpQixTQUFTLENBQUNsQixZQUFZRSxpQkFBaUIsUUFBUSx1QkFBQyxPQUFFLFdBQVUsY0FBY2dCLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDaEZFLFdBQVd5RCxXQUFXLHVCQUFDLGNBQVcsT0FBT3pELFdBQVdGLE9BQU8sTUFBSyxpQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RDtBQUFBLElBQzdFSyxXQUFXc0QsV0FBVyx1QkFBQyxjQUFXLE9BQU90RCxXQUFXTCxPQUFPLE1BQUssZUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRDtBQUFBLElBRTNFRSxXQUFXMEQsYUFBYSx1QkFBQyxnQkFBYSxNQUFNLEdBQUcsV0FBVyxNQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFFN0QsQ0FBQzFELFdBQVcwRCxhQUFhMUQsV0FBV1MsTUFBTWtELFdBQVcsS0FDcEQ7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLFFBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTTtBQUNiNUQsdUJBQVMsSUFBSTtBQUNiTiwrQkFBaUIsRUFBRTtBQUNuQlosMEJBQVksSUFBSTtBQUFBLFlBQ2xCO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQTtBQUFBO0FBQUEsTUFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnQkc7QUFBQSxJQUlKLENBQUNtQixXQUFXMEQsY0FBYzFELFdBQVdTLE1BQU1rRCxVQUFVLEtBQUssS0FDM0QsdUJBQUMsU0FBSSxXQUFVLHNCQUNYM0Qsc0JBQVdTLFFBQVEsSUFBSUg7QUFBQUEsTUFBSSxDQUFDc0QsU0FDNUIsdUJBQUMsU0FBSSxXQUFVLGNBQTJCLE9BQU8sRUFBRUMsU0FBU0QsS0FBS0UsV0FBVyxJQUFJLEtBQUssR0FDbkY7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRTFCLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsaUNBQUMsVUFDRXVCO0FBQUFBLGlCQUFLNUU7QUFBQUEsWUFDTCxDQUFDNEUsS0FBS0UsWUFBWSx1QkFBQyxVQUFLLE9BQU8sRUFBRXhCLE9BQU8sZ0JBQWdCLEdBQUcsNkJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsZUFGM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLFVBQVUsVUFBVUQsT0FBTyxtQkFBbUIsR0FDMURzQjtBQUFBQSxpQkFBSzFFO0FBQUFBLFlBQ0w7QUFBQSxZQUNBMEUsS0FBS2pDLFFBQVFnQyxTQUFTLElBQ25CQyxLQUFLakMsUUFBUXJCLElBQUksQ0FBQ0ssT0FBT04sU0FBUzBELElBQUlwRCxFQUFFLEtBQUtBLEVBQUUsRUFBRXFELEtBQUssSUFBSSxJQUMxRDtBQUFBLGVBTE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFDQ0osS0FBS0UsWUFDSix1QkFBQyxTQUFJLE9BQU8sRUFBRTFCLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRU0sV0FBVyxJQUFJTyxTQUFTLFVBQVVYLFVBQVUsVUFBVTtBQUFBLGNBQy9ELFNBQVMsTUFBTTtBQUNieEMseUJBQVMsSUFBSTtBQUNiTixpQ0FBaUJtRSxLQUFLakMsT0FBTztBQUM3QjVDLGdDQUFnQjZFLElBQUk7QUFBQSxjQUN0QjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixPQUFPLEVBQUVqQixXQUFXLElBQUlPLFNBQVMsVUFBVVgsVUFBVSxVQUFVO0FBQUEsY0FDL0QsU0FBUyxZQUFZO0FBQ25CLG9CQUNFLE1BQU05RCxPQUFPd0YsUUFBUTtBQUFBLGtCQUNuQkMsT0FBTztBQUFBLGtCQUNQakQsU0FBUyx3QkFBd0IyQyxLQUFLNUUsUUFBUTtBQUFBLGtCQUM5Q21GLGNBQWM7QUFBQSxrQkFDZEMsUUFBUTtBQUFBLGdCQUNWLENBQUM7QUFFRHJDLHFDQUFtQnNCLE9BQU9PLEtBQUtqRCxFQUFFO0FBQUEsY0FDckM7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWlCQTtBQUFBLGFBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxXQTlDNkJpRCxLQUFLakQsSUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdEQTtBQUFBLElBQ0QsS0FuREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9EQTtBQUFBLElBR0MvQixZQUNDLHVCQUFDLFdBQVEsT0FBTSxnQkFBZSxTQUFTLE1BQU1DLFlBQVksS0FBSyxHQUM1RDtBQUFBLDZCQUFDLFdBQU0sT0FBTyxFQUFFdUQsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDdEM7QUFBQSwrQkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxrQkFBa0JDLFVBQVUsVUFBVSxHQUFHLHVCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsUUFDdEUsdUJBQUMsV0FBTSxPQUFPdkQsVUFBVSxVQUFVLENBQUNnQyxNQUFNL0IsWUFBWStCLEVBQUUrQixPQUFPQyxLQUFLLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxXQUZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFdBQU0sT0FBTyxFQUFFWixTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUN0QztBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGtCQUFrQkMsVUFBVSxVQUFVLEdBQUcsc0JBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxRQUNyRSx1QkFBQyxXQUFNLE9BQU9yRCxPQUFPLFVBQVUsQ0FBQzhCLE1BQU03QixTQUFTNkIsRUFBRStCLE9BQU9DLEtBQUssS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFdBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsV0FBTSxPQUFPLEVBQUVaLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCQyxVQUFVLFVBQVUsR0FBRyx5Q0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RjtBQUFBLFFBQ3hGLHVCQUFDLFdBQU0sTUFBSyxZQUFXLE9BQU9uRCxVQUFVLFVBQVUsQ0FBQzRCLE1BQU0zQixZQUFZMkIsRUFBRStCLE9BQU9DLEtBQUssS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFdBRnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsV0FBTSxPQUFPLEVBQUVaLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCQyxVQUFVLFVBQVUsR0FBRyxnREFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRjtBQUFBLFFBQy9GLHVCQUFDLFlBQU8sT0FBT2pELFlBQVksVUFBVSxDQUFDMEIsTUFBTXpCLGNBQWN5QixFQUFFK0IsT0FBT0MsS0FBSyxHQUN0RTtBQUFBLGlDQUFDLFlBQU8sT0FBTSxJQUFHLHNCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QjtBQUFBLFdBQ3JCNUMsZUFBZUssUUFBUSxJQUFJSDtBQUFBQSxZQUFJLENBQUMrRCxRQUNoQyx1QkFBQyxZQUFvQixPQUFPQSxJQUFJMUQsSUFBSzBELGNBQUl6RCxRQUE1QnlELElBQUkxRCxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFVBQy9DO0FBQUEsYUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0N3QjtBQUFBQSxNQUNBckMsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUMzQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsVUFDRWQsU0FBUzBDLEtBQUssTUFBTSxNQUFNeEMsTUFBTXdDLEtBQUssTUFBTSxNQUFNdEMsU0FBU3VFLFNBQVMsS0FDbkVuRSxjQUFjbUUsV0FBVyxLQUFLcEMsZUFBZTZCO0FBQUFBLFVBRS9DLFNBQVMsTUFBTTdCLGVBQWU4QixPQUFPO0FBQUEsVUFFcEM5Qix5QkFBZTZCLFlBQVksYUFBYTtBQUFBO0FBQUEsUUFUM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxTQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUNBO0FBQUEsSUFHRHRFLGlCQUFpQixRQUNoQix1QkFBQyxXQUFRLE9BQU8sWUFBWUEsYUFBYUUsUUFBUSxJQUFJLFNBQVMsTUFBTUQsZ0JBQWdCLElBQUksR0FDckZvRDtBQUFBQTtBQUFBQSxNQUNBckMsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUMzQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsVUFBVU4sY0FBY21FLFdBQVcsS0FBSzdCLGNBQWNzQjtBQUFBQSxVQUN0RCxTQUFTLE1BQU10QixjQUFjdUIsT0FBTztBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxPQXZKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUpBO0FBRUo7QUFBQzlFLEdBMVRlRCxXQUFTO0FBQUEsVUFDSGYsZ0JBQ0xDLFdBQ2lCUSxjQVliVixVQUtBQSxVQUtJQSxVQXFCQUQsYUFrQkRBLGFBU0tBLGFBUUFBLFdBQVc7QUFBQTtBQUFBLEtBakZ4QmlCO0FBQVMsSUFBQWdHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsInVzZURpYWxvZyIsImNyZWF0ZVJvbGUiLCJjcmVhdGVVc2VyIiwiZGVhY3RpdmF0ZVVzZXIiLCJnZXRSb2xlcyIsImdldFVzZXJzQnlDb21wYW55IiwidXBkYXRlVXNlclJvbGVzIiwiZ2V0RW1wbG95ZWVzQnlCcmFuY2giLCJ1c2VBdXRoU3RvcmUiLCJBcGlFcnJvciIsIk92ZXJsYXkiLCJRdWVyeUVycm9yIiwiRW1wdHlTdGF0ZSIsIlNrZWxldG9uTGlzdCIsIlVzZXJzUGFnZSIsIl9zIiwicXVlcnlDbGllbnQiLCJkaWFsb2ciLCJjb21wYW55SWQiLCJicmFuY2hJZCIsImNyZWF0aW5nIiwic2V0Q3JlYXRpbmciLCJlZGl0aW5nUm9sZXMiLCJzZXRFZGl0aW5nUm9sZXMiLCJ1c2VyTmFtZSIsInNldFVzZXJOYW1lIiwiZW1haWwiLCJzZXRFbWFpbCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJlbXBsb3llZUlkIiwic2V0RW1wbG95ZWVJZCIsInNlbGVjdGVkUm9sZXMiLCJzZXRTZWxlY3RlZFJvbGVzIiwibmV3Um9sZU5hbWUiLCJzZXROZXdSb2xlTmFtZSIsIm5ld1JvbGVEZXNjcmlwdGlvbiIsInNldE5ld1JvbGVEZXNjcmlwdGlvbiIsImVycm9yIiwic2V0RXJyb3IiLCJ1c2Vyc1F1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicm9sZXNRdWVyeSIsImVtcGxveWVlc1F1ZXJ5Iiwicm9sZU5hbWUiLCJtYXAiLCJNYXAiLCJyIiwiZGF0YSIsInNldCIsImlkIiwibmFtZSIsInJlZnJlc2giLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uQXBpRXJyb3IiLCJlIiwibWVzc2FnZSIsInRvZ2dsZVJvbGUiLCJyb2xlSWQiLCJjdXJyZW50IiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJjcmVhdGVNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJOdW1iZXIiLCJ0cmltIiwicm9sZUlkcyIsIm9uU3VjY2VzcyIsIm9uRXJyb3IiLCJyb2xlc011dGF0aW9uIiwiZGVhY3RpdmF0ZU11dGF0aW9uIiwiY3JlYXRlUm9sZU11dGF0aW9uIiwiZGVzY3JpcHRpb24iLCJuZXdSb2xlSWQiLCJyb2xlQ2hlY2tsaXN0IiwiZGlzcGxheSIsImdhcCIsImNvbG9yIiwiZm9udFNpemUiLCJyb2xlIiwiYWxpZ25JdGVtcyIsIndpZHRoIiwibWluSGVpZ2h0IiwibWFyZ2luVG9wIiwicGFkZGluZ1RvcCIsImJvcmRlclRvcCIsInRhcmdldCIsInZhbHVlIiwiZmxleCIsInBhZGRpbmciLCJ3aGl0ZVNwYWNlIiwiaXNQZW5kaW5nIiwibXV0YXRlIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJtYXJnaW5Cb3R0b20iLCJpc0Vycm9yIiwiaXNMb2FkaW5nIiwibGVuZ3RoIiwidXNlciIsIm9wYWNpdHkiLCJpc0FjdGl2ZSIsImdldCIsImpvaW4iLCJjb25maXJtIiwidGl0bGUiLCJjb25maXJtTGFiZWwiLCJkYW5nZXIiLCJlbXAiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc2Vyc1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IHVzZURpYWxvZyB9IGZyb20gXCIuLi8uLi91aS9EaWFsb2dcIjtcclxuaW1wb3J0IHsgY3JlYXRlUm9sZSwgY3JlYXRlVXNlciwgZGVhY3RpdmF0ZVVzZXIsIGdldFJvbGVzLCBnZXRVc2Vyc0J5Q29tcGFueSwgdXBkYXRlVXNlclJvbGVzIH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IGdldEVtcGxveWVlc0J5QnJhbmNoIH0gZnJvbSBcIi4uL2VtcGxveWVlcy9hcGlcIjtcclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tIFwiLi4vLi4vbGliL2FwaUNsaWVudFwiO1xyXG5pbXBvcnQgdHlwZSB7IFVzZXJSZXNwb25zZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgT3ZlcmxheSB9IGZyb20gXCIuLi9vcmRlcnMvT3ZlcmxheVwiO1xyXG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xyXG5pbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSBcIi4uLy4uL3VpL0VtcHR5U3RhdGVcIjtcclxuaW1wb3J0IHsgU2tlbGV0b25MaXN0IH0gZnJvbSBcIi4uLy4uL3VpL1NrZWxldG9uXCI7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVXNlcnNQYWdlKCkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCBkaWFsb2cgPSB1c2VEaWFsb2coKTtcclxuICBjb25zdCB7IGNvbXBhbnlJZCwgYnJhbmNoSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IFtjcmVhdGluZywgc2V0Q3JlYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0aW5nUm9sZXMsIHNldEVkaXRpbmdSb2xlc10gPSB1c2VTdGF0ZTxVc2VyUmVzcG9uc2UgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbdXNlck5hbWUsIHNldFVzZXJOYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZW1wbG95ZWVJZCwgc2V0RW1wbG95ZWVJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRSb2xlcywgc2V0U2VsZWN0ZWRSb2xlc10gPSB1c2VTdGF0ZTxudW1iZXJbXT4oW10pO1xyXG4gIGNvbnN0IFtuZXdSb2xlTmFtZSwgc2V0TmV3Um9sZU5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW25ld1JvbGVEZXNjcmlwdGlvbiwgc2V0TmV3Um9sZURlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IHVzZXJzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1widXNlcnNcIiwgY29tcGFueUlkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldFVzZXJzQnlDb21wYW55KGNvbXBhbnlJZCA/PyAxKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgcm9sZXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJyb2xlc1wiLCBjb21wYW55SWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0Um9sZXMoY29tcGFueUlkID8/IDEpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBlbXBsb3llZXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJlbXBsb3llZXNcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0RW1wbG95ZWVzQnlCcmFuY2goYnJhbmNoSWQpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByb2xlTmFtZSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgbWFwID0gbmV3IE1hcDxudW1iZXIsIHN0cmluZz4oKTtcclxuICAgIGZvciAoY29uc3QgciBvZiByb2xlc1F1ZXJ5LmRhdGEgPz8gW10pIG1hcC5zZXQoci5pZCwgci5uYW1lKTtcclxuICAgIHJldHVybiBtYXA7XHJcbiAgfSwgW3JvbGVzUXVlcnkuZGF0YV0pO1xyXG5cclxuICBjb25zdCByZWZyZXNoID0gKCkgPT4gdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJ1c2Vyc1wiXSB9KTtcclxuXHJcbiAgY29uc3Qgb25BcGlFcnJvciA9IChlOiB1bmtub3duKSA9PlxyXG4gICAgc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEFwaUVycm9yID8gZS5tZXNzYWdlIDogXCJPcGVyYcOnw6NvIGZhbGhvdS5cIik7XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVJvbGUgPSAocm9sZUlkOiBudW1iZXIpID0+XHJcbiAgICBzZXRTZWxlY3RlZFJvbGVzKChjdXJyZW50KSA9PlxyXG4gICAgICBjdXJyZW50LmluY2x1ZGVzKHJvbGVJZCkgPyBjdXJyZW50LmZpbHRlcigoaWQpID0+IGlkICE9PSByb2xlSWQpIDogWy4uLmN1cnJlbnQsIHJvbGVJZF0sXHJcbiAgICApO1xyXG5cclxuICBjb25zdCBjcmVhdGVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIGNyZWF0ZVVzZXIoe1xyXG4gICAgICAgIGNvbXBhbnlJZDogY29tcGFueUlkID8/IDEsXHJcbiAgICAgICAgZW1wbG95ZWVJZDogZW1wbG95ZWVJZCA9PT0gXCJcIiA/IG51bGwgOiBOdW1iZXIoZW1wbG95ZWVJZCksXHJcbiAgICAgICAgdXNlck5hbWU6IHVzZXJOYW1lLnRyaW0oKSxcclxuICAgICAgICBlbWFpbDogZW1haWwudHJpbSgpLFxyXG4gICAgICAgIHBhc3N3b3JkLFxyXG4gICAgICAgIHJvbGVJZHM6IHNlbGVjdGVkUm9sZXMsXHJcbiAgICAgIH0pLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHNldENyZWF0aW5nKGZhbHNlKTtcclxuICAgICAgc2V0VXNlck5hbWUoXCJcIik7IHNldEVtYWlsKFwiXCIpOyBzZXRQYXNzd29yZChcIlwiKTsgc2V0RW1wbG95ZWVJZChcIlwiKTsgc2V0U2VsZWN0ZWRSb2xlcyhbXSk7XHJcbiAgICAgIHJlZnJlc2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByb2xlc011dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gdXBkYXRlVXNlclJvbGVzKGVkaXRpbmdSb2xlcyEuaWQsIHNlbGVjdGVkUm9sZXMpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHNldEVkaXRpbmdSb2xlcyhudWxsKTtcclxuICAgICAgcmVmcmVzaCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGRlYWN0aXZhdGVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46IChpZDogbnVtYmVyKSA9PiBkZWFjdGl2YXRlVXNlcihpZCksXHJcbiAgICBvblN1Y2Nlc3M6IHJlZnJlc2gsXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICAvLyBDcmlhIHVtIG5vdm8gcGVyZmlsIChleC46IFwiR2Fyw6dvbVwiLCBcIkNvemluaGFcIikgc2VtIHNhaXIgZG8gZmx1eG8gZGUgY3JpYXIvZWRpdGFyIHVzdcOhcmlvIOKAlFxyXG4gIC8vIGFudGVzIGRpc3NvIG7Do28gaGF2aWEgbmVuaHVtYSB0ZWxhIHBhcmEgY2FkYXN0cmFyIHBlcmZpbCBhbMOpbSBkbyDDum5pY28gc2VlZGFkbyBubyBvbmJvYXJkaW5nLlxyXG4gIGNvbnN0IGNyZWF0ZVJvbGVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIGNyZWF0ZVJvbGUoe1xyXG4gICAgICAgIGNvbXBhbnlJZDogY29tcGFueUlkID8/IDEsXHJcbiAgICAgICAgbmFtZTogbmV3Um9sZU5hbWUudHJpbSgpLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBuZXdSb2xlRGVzY3JpcHRpb24udHJpbSgpID09PSBcIlwiID8gbnVsbCA6IG5ld1JvbGVEZXNjcmlwdGlvbi50cmltKCksXHJcbiAgICAgIH0pLFxyXG4gICAgb25TdWNjZXNzOiBhc3luYyAobmV3Um9sZUlkKSA9PiB7XHJcbiAgICAgIHNldE5ld1JvbGVOYW1lKFwiXCIpO1xyXG4gICAgICBzZXROZXdSb2xlRGVzY3JpcHRpb24oXCJcIik7XHJcbiAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICBhd2FpdCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJyb2xlc1wiXSB9KTtcclxuICAgICAgc2V0U2VsZWN0ZWRSb2xlcygoY3VycmVudCkgPT4gKGN1cnJlbnQuaW5jbHVkZXMobmV3Um9sZUlkKSA/IGN1cnJlbnQgOiBbLi4uY3VycmVudCwgbmV3Um9sZUlkXSkpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJvbGVDaGVja2xpc3QgPSAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDYgfX0+XHJcbiAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5QZXJmaXM8L3NwYW4+XHJcbiAgICAgIHsocm9sZXNRdWVyeS5kYXRhID8/IFtdKS5tYXAoKHJvbGUpID0+IChcclxuICAgICAgICA8bGFiZWwga2V5PXtyb2xlLmlkfSBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAsIG1pbkhlaWdodDogMjAgfX1cclxuICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRSb2xlcy5pbmNsdWRlcyhyb2xlLmlkKX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHRvZ2dsZVJvbGUocm9sZS5pZCl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgIHtyb2xlLm5hbWV9XHJcbiAgICAgICAgICAgIHtyb2xlLmRlc2NyaXB0aW9uID8gKFxyXG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44cmVtXCIgfX0+IOKAlCB7cm9sZS5kZXNjcmlwdGlvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICkpfVxyXG5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICBkaXNwbGF5OiBcImdyaWRcIixcclxuICAgICAgICAgIGdhcDogNixcclxuICAgICAgICAgIG1hcmdpblRvcDogNCxcclxuICAgICAgICAgIHBhZGRpbmdUb3A6IDEwLFxyXG4gICAgICAgICAgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lKVwiLFxyXG4gICAgICAgIH19XHJcbiAgICAgID5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOHJlbVwiIH19PlxyXG4gICAgICAgICAgTsOjbyBhY2hvdSBvIHBlcmZpbCBxdWUgcHJlY2lzYT8gQ3JpZSB1bSBub3ZvIGFiYWl4byAoZXguOiBHYXLDp29tLCBDb3ppbmhhKSDigJQgZWxlIGrDoVxyXG4gICAgICAgICAgYXBhcmVjZSBtYXJjYWRvIG5hIGxpc3RhIGFjaW1hLlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb21lIGRvIG5vdm8gcGVyZmlsXCJcclxuICAgICAgICAgICAgdmFsdWU9e25ld1JvbGVOYW1lfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1JvbGVOYW1lKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgc3R5bGU9e3sgZmxleDogMSB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlc2NyacOnw6NvIChvcGNpb25hbClcIlxyXG4gICAgICAgICAgICB2YWx1ZT17bmV3Um9sZURlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1JvbGVEZXNjcmlwdGlvbihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHN0eWxlPXt7IGZsZXg6IDEgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTRweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIsIHdoaXRlU3BhY2U6IFwibm93cmFwXCIgfX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e25ld1JvbGVOYW1lLnRyaW0oKSA9PT0gXCJcIiB8fCBjcmVhdGVSb2xlTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjcmVhdGVSb2xlTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtjcmVhdGVSb2xlTXV0YXRpb24uaXNQZW5kaW5nID8gXCJDcmlhbmRv4oCmXCIgOiBcIisgTm92byBwZXJmaWxcIn1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDExMDAsIG1hcmdpbjogXCIwIGF1dG9cIiB9fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlXCIgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiYmFzZWxpbmVcIiwgZ2FwOiAxNCwgbWFyZ2luQm90dG9tOiAxNiB9fT5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuN3JlbVwiIH19PlVzdcOhcmlvcyBlIHBlcmZpczwvaDI+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSB9fSAvPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRSb2xlcyhbXSk7XHJcbiAgICAgICAgICAgIHNldENyZWF0aW5nKHRydWUpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICArIE5vdm8gdXN1w6FyaW9cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7ZXJyb3IgJiYgIWNyZWF0aW5nICYmIGVkaXRpbmdSb2xlcyA9PT0gbnVsbCAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgIHt1c2Vyc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e3VzZXJzUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyB1c3XDoXJpb3NcIiAvPn1cclxuICAgICAge3JvbGVzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17cm9sZXNRdWVyeS5lcnJvcn0gd2hhdD1cIm9zIHBlcmZpc1wiIC8+fVxyXG5cclxuICAgICAge3VzZXJzUXVlcnkuaXNMb2FkaW5nICYmIDxTa2VsZXRvbkxpc3Qgcm93cz17NX0gcm93SGVpZ2h0PXs1OH0gLz59XHJcblxyXG4gICAgICB7IXVzZXJzUXVlcnkuaXNMb2FkaW5nICYmIHVzZXJzUXVlcnkuZGF0YT8ubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICA8RW1wdHlTdGF0ZVxyXG4gICAgICAgICAgaWNvbj1cIvCfkaRcIlxyXG4gICAgICAgICAgdGl0bGU9XCJOZW5odW0gdXN1w6FyaW8gY2FkYXN0cmFkb1wiXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbj1cIkNyaWUgbyBwcmltZWlybyB1c3XDoXJpbyBwYXJhIGRhciBhY2Vzc28gYW8gc2lzdGVtYSDDoCBlcXVpcGUuXCJcclxuICAgICAgICAgIGFjdGlvbj17XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFJvbGVzKFtdKTtcclxuICAgICAgICAgICAgICAgIHNldENyZWF0aW5nKHRydWUpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICArIE5vdm8gdXN1w6FyaW9cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHshdXNlcnNRdWVyeS5pc0xvYWRpbmcgJiYgKHVzZXJzUXVlcnkuZGF0YT8ubGVuZ3RoID8/IDApID4gMCAmJiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0IHJpc2UgcmlzZS0xXCI+XHJcbiAgICAgICAgeyh1c2Vyc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIga2V5PXt1c2VyLmlkfSBzdHlsZT17eyBvcGFjaXR5OiB1c2VyLmlzQWN0aXZlID8gMSA6IDAuNDUgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgIHt1c2VyLnVzZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgeyF1c2VyLmlzQWN0aXZlICYmIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWRhbmdlcilcIiB9fT4gwrcgZGVzYXRpdmFkbzwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICB7dXNlci5lbWFpbH1cclxuICAgICAgICAgICAgICAgIHtcIiDCtyBcIn1cclxuICAgICAgICAgICAgICAgIHt1c2VyLnJvbGVJZHMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICA/IHVzZXIucm9sZUlkcy5tYXAoKGlkKSA9PiByb2xlTmFtZS5nZXQoaWQpID8/IGlkKS5qb2luKFwiLCBcIilcclxuICAgICAgICAgICAgICAgICAgOiBcInNlbSBwZXJmaWxcIn1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7dXNlci5pc0FjdGl2ZSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWluSGVpZ2h0OiA0NCwgcGFkZGluZzogXCIwIDEycHhcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFJvbGVzKHVzZXIucm9sZUlkcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1JvbGVzKHVzZXIpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBQZXJmaXNcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1pbkhlaWdodDogNDQsIHBhZGRpbmc6IFwiMCAxMnB4XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgYXdhaXQgZGlhbG9nLmNvbmZpcm0oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJEZXNhdGl2YXIgdXN1w6FyaW9cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYERlc2F0aXZhciBvIHVzdcOhcmlvIFwiJHt1c2VyLnVzZXJOYW1lfVwiP2AsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJEZXNhdGl2YXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGFuZ2VyOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICBkZWFjdGl2YXRlTXV0YXRpb24ubXV0YXRlKHVzZXIuaWQpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZXNhdGl2YXJcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAge2NyZWF0aW5nICYmIChcclxuICAgICAgICA8T3ZlcmxheSB0aXRsZT1cIk5vdm8gdXN1w6FyaW9cIiBvbkNsb3NlPXsoKSA9PiBzZXRDcmVhdGluZyhmYWxzZSl9PlxyXG4gICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5Vc3XDoXJpbzwvc3Bhbj5cclxuICAgICAgICAgICAgPGlucHV0IHZhbHVlPXt1c2VyTmFtZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VyTmFtZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5FLW1haWw8L3NwYW4+XHJcbiAgICAgICAgICAgIDxpbnB1dCB2YWx1ZT17ZW1haWx9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+U2VuaGEgKG3DrW4uIDggY2FyYWN0ZXJlcyk8L3NwYW4+XHJcbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiB2YWx1ZT17cGFzc3dvcmR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+RnVuY2lvbsOhcmlvIHZpbmN1bGFkbyAob3BjaW9uYWwpPC9zcGFuPlxyXG4gICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtlbXBsb3llZUlkfSBvbkNoYW5nZT17KGUpID0+IHNldEVtcGxveWVlSWQoZS50YXJnZXQudmFsdWUpfT5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+TmVuaHVtPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgeyhlbXBsb3llZXNRdWVyeS5kYXRhID8/IFtdKS5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2VtcC5pZH0gdmFsdWU9e2VtcC5pZH0+e2VtcC5uYW1lfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICB7cm9sZUNoZWNrbGlzdH1cclxuICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtcclxuICAgICAgICAgICAgICB1c2VyTmFtZS50cmltKCkgPT09IFwiXCIgfHwgZW1haWwudHJpbSgpID09PSBcIlwiIHx8IHBhc3N3b3JkLmxlbmd0aCA8IDggfHxcclxuICAgICAgICAgICAgICBzZWxlY3RlZFJvbGVzLmxlbmd0aCA9PT0gMCB8fCBjcmVhdGVNdXRhdGlvbi5pc1BlbmRpbmdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjcmVhdGVNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2NyZWF0ZU11dGF0aW9uLmlzUGVuZGluZyA/IFwiQ3JpYW5kb+KAplwiIDogXCJDcmlhciB1c3XDoXJpb1wifVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9PdmVybGF5PlxyXG4gICAgICApfVxyXG5cclxuICAgICAge2VkaXRpbmdSb2xlcyAhPT0gbnVsbCAmJiAoXHJcbiAgICAgICAgPE92ZXJsYXkgdGl0bGU9e2BQZXJmaXMg4oCUICR7ZWRpdGluZ1JvbGVzLnVzZXJOYW1lfWB9IG9uQ2xvc2U9eygpID0+IHNldEVkaXRpbmdSb2xlcyhudWxsKX0+XHJcbiAgICAgICAgICB7cm9sZUNoZWNrbGlzdH1cclxuICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtzZWxlY3RlZFJvbGVzLmxlbmd0aCA9PT0gMCB8fCByb2xlc011dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcm9sZXNNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgU2FsdmFyIHBlcmZpc1xyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9PdmVybGF5PlxyXG4gICAgICApfVxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3VzZXJzL1VzZXJzUGFnZS50c3gifQ==