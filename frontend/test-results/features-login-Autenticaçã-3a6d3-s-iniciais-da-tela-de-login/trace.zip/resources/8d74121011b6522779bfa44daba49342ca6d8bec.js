import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/StatsGrid.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const GAP = 12;
const MIN_CARD_WIDTH = 200;
export function StatsGrid({ children, columns = 4 }) {
  const track = `max(${MIN_CARD_WIDTH}px, calc((100% - ${(columns - 1) * GAP}px) / ${columns}))`;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      style: {
        display: "grid",
        gridTemplateColumns: `repeat(auto-fit, minmax(${track}, 1fr))`,
        gap: GAP,
        marginBottom: 20
      },
      children
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx",
      lineNumber: 36,
      columnNumber: 5
    },
    this
  );
}
_c = StatsGrid;
export function StatItem({ label, value, subtext, icon, color = "var(--accent)" }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      style: {
        padding: 12,
        borderRadius: 6,
        background: "var(--surface-2)",
        border: `1px solid ${color}`,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      },
      children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.75rem", color: "var(--ink-faint)", margin: 0, fontWeight: 600 }, children: label }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx",
            lineNumber: 71,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.25rem", fontWeight: 700, color, marginTop: 4 }, children: value }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx",
            lineNumber: 74,
            columnNumber: 9
          }, this),
          subtext && /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.7rem", color: "var(--ink-faint)", margin: "2px 0 0", opacity: 0.7 }, children: subtext }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx",
            lineNumber: 76,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx",
          lineNumber: 70,
          columnNumber: 7
        }, this),
        icon && /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.75rem", opacity: 0.6 }, children: icon }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx",
          lineNumber: 81,
          columnNumber: 16
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx",
      lineNumber: 59,
      columnNumber: 5
    },
    this
  );
}
_c2 = StatItem;
var _c, _c2;
$RefreshReg$(_c, "StatsGrid");
$RefreshReg$(_c2, "StatItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/StatsGrid.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JJOzs7Ozs7Ozs7Ozs7Ozs7O0FBVEosTUFBTUEsTUFBTTtBQUNaLE1BQU1DLGlCQUFpQjtBQUtoQixnQkFBU0MsVUFBVSxFQUFFQyxVQUFVQyxVQUFVLEVBQWtCLEdBQUc7QUFDbkUsUUFBTUMsUUFBUSxPQUFPSixjQUFjLHFCQUFxQkcsVUFBVSxLQUFLSixHQUFHLFNBQVNJLE9BQU87QUFDMUYsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsT0FBTztBQUFBLFFBQ0xFLFNBQVM7QUFBQSxRQUNUQyxxQkFBcUIsMkJBQTJCRixLQUFLO0FBQUEsUUFDckRHLEtBQUtSO0FBQUFBLFFBQ0xTLGNBQWM7QUFBQSxNQUNoQjtBQUFBLE1BRUNOO0FBQUFBO0FBQUFBLElBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0E7QUFFSjtBQUFDTyxLQWRlUjtBQXdCVCxnQkFBU1MsU0FBUyxFQUFFQyxPQUFPQyxPQUFPQyxTQUFTQyxNQUFNQyxRQUFRLGdCQUErQixHQUFHO0FBQ2hHLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE9BQU87QUFBQSxRQUNMQyxTQUFTO0FBQUEsUUFDVEMsY0FBYztBQUFBLFFBQ2RDLFlBQVk7QUFBQSxRQUNaQyxRQUFRLGFBQWFKLEtBQUs7QUFBQSxRQUMxQlYsU0FBUztBQUFBLFFBQ1RlLGdCQUFnQjtBQUFBLFFBQ2hCQyxZQUFZO0FBQUEsTUFDZDtBQUFBLE1BRUE7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxPQUFPLEVBQUVDLFVBQVUsV0FBV1AsT0FBTyxvQkFBb0JRLFFBQVEsR0FBR0MsWUFBWSxJQUFJLEdBQ3BGYixtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVcsVUFBVSxXQUFXRSxZQUFZLEtBQUtULE9BQWNVLFdBQVcsRUFBRSxHQUFJYixtQkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxVQUN4RkMsV0FDQyx1QkFBQyxPQUFFLE9BQU8sRUFBRVMsVUFBVSxVQUFVUCxPQUFPLG9CQUFvQlEsUUFBUSxXQUFXRyxTQUFTLElBQUksR0FDeEZiLHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0NDLFFBQVEsdUJBQUMsU0FBSSxPQUFPLEVBQUVRLFVBQVUsV0FBV0ksU0FBUyxJQUFJLEdBQUlaLGtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUE7QUFBQTtBQUFBLElBdEJwRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF1QkE7QUFFSjtBQUFDYSxNQTNCZWpCO0FBQVEsSUFBQUQsSUFBQWtCO0FBQUEsYUFBQWxCLElBQUE7QUFBQSxhQUFBa0IsS0FBQSIsIm5hbWVzIjpbIkdBUCIsIk1JTl9DQVJEX1dJRFRIIiwiU3RhdHNHcmlkIiwiY2hpbGRyZW4iLCJjb2x1bW5zIiwidHJhY2siLCJkaXNwbGF5IiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImdhcCIsIm1hcmdpbkJvdHRvbSIsIl9jIiwiU3RhdEl0ZW0iLCJsYWJlbCIsInZhbHVlIiwic3VidGV4dCIsImljb24iLCJjb2xvciIsInBhZGRpbmciLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwiZm9udFNpemUiLCJtYXJnaW4iLCJmb250V2VpZ2h0IiwibWFyZ2luVG9wIiwib3BhY2l0eSIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTdGF0c0dyaWQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5pbnRlcmZhY2UgU3RhdHNHcmlkUHJvcHMge1xyXG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XHJcbiAgY29sdW1ucz86IG51bWJlcjtcclxufVxyXG5cclxuY29uc3QgR0FQID0gMTI7XHJcbmNvbnN0IE1JTl9DQVJEX1dJRFRIID0gMjAwO1xyXG5cclxuLy8gYGNvbHVtbnNgIMOpIG8gdGV0byBkZSBjb2x1bmFzIGVtIHRlbGFzIGxhcmdhczogY2FkYSBmYWl4YSBwZWRlIGEgZnJhw6fDo28gZXhhdGEgZGVcclxuLy8gMS9jb2x1bW5zIGRhIGxpbmhhLCBtYXMgbnVuY2EgbWVub3MgcXVlIE1JTl9DQVJEX1dJRFRIIOKAlCBlbSB0ZWxhcyBlc3RyZWl0YXMgb1xyXG4vLyBhdXRvLWZpdCBxdWVicmEgcHJhIG1lbm9zIGNvbHVuYXMuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdGF0c0dyaWQoeyBjaGlsZHJlbiwgY29sdW1ucyA9IDQgfTogU3RhdHNHcmlkUHJvcHMpIHtcclxuICBjb25zdCB0cmFjayA9IGBtYXgoJHtNSU5fQ0FSRF9XSURUSH1weCwgY2FsYygoMTAwJSAtICR7KGNvbHVtbnMgLSAxKSAqIEdBUH1weCkgLyAke2NvbHVtbnN9KSlgO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgZGlzcGxheTogXCJncmlkXCIsXHJcbiAgICAgICAgZ3JpZFRlbXBsYXRlQ29sdW1uczogYHJlcGVhdChhdXRvLWZpdCwgbWlubWF4KCR7dHJhY2t9LCAxZnIpKWAsXHJcbiAgICAgICAgZ2FwOiBHQVAsXHJcbiAgICAgICAgbWFyZ2luQm90dG9tOiAyMCxcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuaW50ZXJmYWNlIFN0YXRJdGVtUHJvcHMge1xyXG4gIGxhYmVsOiBzdHJpbmc7XHJcbiAgdmFsdWU6IFJlYWN0Tm9kZTtcclxuICBzdWJ0ZXh0Pzogc3RyaW5nO1xyXG4gIGljb24/OiBSZWFjdE5vZGU7XHJcbiAgY29sb3I/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdGF0SXRlbSh7IGxhYmVsLCB2YWx1ZSwgc3VidGV4dCwgaWNvbiwgY29sb3IgPSBcInZhcigtLWFjY2VudClcIiB9OiBTdGF0SXRlbVByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgc3R5bGU9e3tcclxuICAgICAgICBwYWRkaW5nOiAxMixcclxuICAgICAgICBib3JkZXJSYWRpdXM6IDYsXHJcbiAgICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1zdXJmYWNlLTIpXCIsXHJcbiAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7Y29sb3J9YCxcclxuICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsXHJcbiAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjc1cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgbWFyZ2luOiAwLCBmb250V2VpZ2h0OiA2MDAgfX0+XHJcbiAgICAgICAgICB7bGFiZWx9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4yNXJlbVwiLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiBjb2xvciwgbWFyZ2luVG9wOiA0IH19Pnt2YWx1ZX08L2Rpdj5cclxuICAgICAgICB7c3VidGV4dCAmJiAoXHJcbiAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjdyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBtYXJnaW46IFwiMnB4IDAgMFwiLCBvcGFjaXR5OiAwLjcgfX0+XHJcbiAgICAgICAgICAgIHtzdWJ0ZXh0fVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7aWNvbiAmJiA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuNzVyZW1cIiwgb3BhY2l0eTogMC42IH19PntpY29ufTwvZGl2Pn1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvU3RhdHNHcmlkLnRzeCJ9