import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/customers/CustomersPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { addLoyaltyPoints, createCustomer, getCustomersByCompany } from "/src/features/customers/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { Button } from "/src/ui/Button.tsx";
import { TextField } from "/src/ui/Field.tsx";
import { useToast } from "/src/ui/Toast.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
export function CustomersPage() {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { companyId } = useAuthStore();
  const [search, setSearch] = useState("");
  const [creating, setCreating] = useState(false);
  const [addingPointsTo, setAddingPointsTo] = useState(null);
  const [pointsInput, setPointsInput] = useState("10");
  const [error, setError] = useState(null);
  const [form, setForm] = useState({ name: "", phone: "", cpf: "", email: "" });
  const customersQuery = useQuery({
    queryKey: ["customers", companyId, search],
    queryFn: () => getCustomersByCompany(companyId ?? 1, search)
  });
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["customers"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const createMutation = useMutation({
    mutationFn: () => createCustomer({
      companyId: companyId ?? 1,
      name: form.name.trim(),
      phone: form.phone.trim() === "" ? null : form.phone.trim(),
      cpf: form.cpf.trim() === "" ? null : form.cpf.trim(),
      email: form.email.trim() === "" ? null : form.email.trim()
    }),
    onSuccess: () => {
      setError(null);
      setCreating(false);
      setForm({ name: "", phone: "", cpf: "", email: "" });
      toast.success("Cliente cadastrado.");
      refresh();
    },
    onError: onApiError
  });
  const pointsMutation = useMutation({
    mutationFn: (id) => addLoyaltyPoints(id, Number(pointsInput) || 0),
    onSuccess: () => {
      setError(null);
      setAddingPointsTo(null);
      toast.success("Pontos atualizados.");
      refresh();
    },
    onError: onApiError
  });
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 900, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise ui-row ui-row-wrap", style: { marginBottom: 6 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Clientes" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
        lineNumber: 86,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "ui-spacer" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
        lineNumber: 87,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          placeholder: "Buscar por nome, telefone ou CPF…",
          value: search,
          onChange: (e) => setSearch(e.target.value),
          style: { flex: 1, minWidth: 220 }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 88,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => {
        setError(null);
        setCreating(true);
      }, children: "+ Novo cliente" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
        lineNumber: 94,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
      lineNumber: 85,
      columnNumber: 13
    }, this),
    customersQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: customersQuery.error, what: "os clientes" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
      lineNumber: 99,
      columnNumber: 40
    }, this),
    error && !creating && addingPointsTo === null && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
      lineNumber: 100,
      columnNumber: 63
    }, this),
    customersQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 6, rowHeight: 58 }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
      lineNumber: 102,
      columnNumber: 42
    }, this),
    !customersQuery.isLoading && (customersQuery.data ?? []).length === 0 && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: "👥",
        title: "Nenhum cliente encontrado",
        description: search.trim() === "" ? "Cadastre o primeiro cliente para começar o programa de fidelidade." : "Nenhum cliente bate com essa busca.",
        action: search.trim() === "" ? /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => {
          setError(null);
          setCreating(true);
        }, children: "+ Novo cliente" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 115,
          columnNumber: 9
        }, this) : void 0
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
        lineNumber: 105,
        columnNumber: 7
      },
      this
    ),
    !customersQuery.isLoading && (customersQuery.data ?? []).length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "rise rise-1 ticket", style: { marginTop: 12 }, children: (customersQuery.data ?? []).map(
      (c) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
          /* @__PURE__ */ jsxDEV("span", { children: c.name }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
            lineNumber: 128,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [c.phone, c.cpf, c.email].filter(Boolean).join(" · ") || "sem dados de contato" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
            lineNumber: 129,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 127,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 10 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": "var(--amber)" }, children: [
            c.loyaltyPoints,
            " pts"
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
            lineNumber: 134,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              onClick: () => {
                setError(null);
                setPointsInput("10");
                setAddingPointsTo(c.id);
              },
              children: "+ Pontos"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
              lineNumber: 137,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 133,
          columnNumber: 29
        }, this)
      ] }, c.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
        lineNumber: 126,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
      lineNumber: 124,
      columnNumber: 7
    }, this),
    creating && /* @__PURE__ */ jsxDEV(Modal, { title: "Novo cliente", onClose: () => setCreating(false), children: [
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Nome",
          value: form.name,
          onChange: (e) => setForm((f) => ({ ...f, name: e.target.value })),
          autoFocus: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 152,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Telefone",
            value: form.phone,
            onChange: (e) => setForm((f) => ({ ...f, phone: e.target.value }))
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
            lineNumber: 161,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 160,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "CPF",
            value: form.cpf,
            onChange: (e) => setForm((f) => ({ ...f, cpf: e.target.value })),
            maxLength: 11
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
            lineNumber: 168,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 167,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
        lineNumber: 159,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "E-mail",
          value: form.email,
          onChange: (e) => setForm((f) => ({ ...f, email: e.target.value }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 177,
          columnNumber: 21
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
        lineNumber: 183,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          disabled: form.name.trim() === "",
          loading: createMutation.isPending,
          onClick: () => createMutation.mutate(),
          children: "Criar cliente"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 185,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
      lineNumber: 151,
      columnNumber: 7
    }, this),
    addingPointsTo !== null && /* @__PURE__ */ jsxDEV(Modal, { title: "Adicionar pontos de fidelidade", onClose: () => setAddingPointsTo(null), children: [
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Pontos (use negativo para resgatar)",
          inputMode: "numeric",
          value: pointsInput,
          onChange: (e) => setPointsInput(e.target.value),
          autoFocus: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 199,
          columnNumber: 21
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
        lineNumber: 207,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          loading: pointsMutation.isPending,
          onClick: () => pointsMutation.mutate(addingPointsTo),
          children: "Aplicar"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
          lineNumber: 209,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
      lineNumber: 198,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx",
    lineNumber: 84,
    columnNumber: 5
  }, this);
}
_s(CustomersPage, "2/ybZVxkvfMNmb0m+ziYQzmkp5Y=", false, function() {
  return [useQueryClient, useToast, useAuthStore, useQuery, useMutation, useMutation];
});
_c = CustomersPage;
var _c;
$RefreshReg$(_c, "CustomersPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/customers/CustomersPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0VnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsRWhCLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQsU0FBU0Msa0JBQWtCQyxnQkFBZ0JDLDZCQUE2QjtBQUN4RSxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBRXRCLGdCQUFTQyxnQkFBZ0I7QUFBQUMsS0FBQTtBQUM1QixRQUFNQyxjQUFjZixlQUFlO0FBQ25DLFFBQU1nQixRQUFRTixTQUFTO0FBQ3ZCLFFBQU0sRUFBRU8sVUFBVSxJQUFJYixhQUFhO0FBQ25DLFFBQU0sQ0FBQ2MsUUFBUUMsU0FBUyxJQUFJdEIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3VCLFVBQVVDLFdBQVcsSUFBSXhCLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUN5QixnQkFBZ0JDLGlCQUFpQixJQUFJMUIsU0FBd0IsSUFBSTtBQUN4RSxRQUFNLENBQUMyQixhQUFhQyxjQUFjLElBQUk1QixTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDNkIsT0FBT0MsUUFBUSxJQUFJOUIsU0FBd0IsSUFBSTtBQUV0RCxRQUFNLENBQUMrQixNQUFNQyxPQUFPLElBQUloQyxTQUFTLEVBQUVpQyxNQUFNLElBQUlDLE9BQU8sSUFBSUMsS0FBSyxJQUFJQyxPQUFPLEdBQUcsQ0FBQztBQUU1RSxRQUFNQyxpQkFBaUJuQyxTQUFTO0FBQUEsSUFDNUJvQyxVQUFVLENBQUMsYUFBYWxCLFdBQVdDLE1BQU07QUFBQSxJQUN6Q2tCLFNBQVNBLE1BQU1qQyxzQkFBc0JjLGFBQWEsR0FBR0MsTUFBTTtBQUFBLEVBQy9ELENBQUM7QUFFRCxRQUFNbUIsVUFBVUEsTUFBTSxLQUFLdEIsWUFBWXVCLGtCQUFrQixFQUFFSCxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7QUFDcEYsUUFBTUksYUFBYUEsQ0FBQ0MsTUFBZWIsU0FBU2EsYUFBYW5DLFdBQVdtQyxFQUFFQyxVQUFVLGtCQUFrQjtBQUVsRyxRQUFNQyxpQkFBaUI1QyxZQUFZO0FBQUEsSUFDL0I2QyxZQUFZQSxNQUNSekMsZUFBZTtBQUFBLE1BQ1hlLFdBQVdBLGFBQWE7QUFBQSxNQUN4QmEsTUFBTUYsS0FBS0UsS0FBS2MsS0FBSztBQUFBLE1BQ3JCYixPQUFPSCxLQUFLRyxNQUFNYSxLQUFLLE1BQU0sS0FBSyxPQUFPaEIsS0FBS0csTUFBTWEsS0FBSztBQUFBLE1BQ3pEWixLQUFLSixLQUFLSSxJQUFJWSxLQUFLLE1BQU0sS0FBSyxPQUFPaEIsS0FBS0ksSUFBSVksS0FBSztBQUFBLE1BQ25EWCxPQUFPTCxLQUFLSyxNQUFNVyxLQUFLLE1BQU0sS0FBSyxPQUFPaEIsS0FBS0ssTUFBTVcsS0FBSztBQUFBLElBQzdELENBQUM7QUFBQSxJQUNMQyxXQUFXQSxNQUFNO0FBQ2JsQixlQUFTLElBQUk7QUFDYk4sa0JBQVksS0FBSztBQUNqQlEsY0FBUSxFQUFFQyxNQUFNLElBQUlDLE9BQU8sSUFBSUMsS0FBSyxJQUFJQyxPQUFPLEdBQUcsQ0FBQztBQUNuRGpCLFlBQU04QixRQUFRLHFCQUFxQjtBQUNuQ1QsY0FBUTtBQUFBLElBQ1o7QUFBQSxJQUNBVSxTQUFTUjtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNUyxpQkFBaUJsRCxZQUFZO0FBQUEsSUFDL0I2QyxZQUFZQSxDQUFDTSxPQUFlaEQsaUJBQWlCZ0QsSUFBSUMsT0FBTzFCLFdBQVcsS0FBSyxDQUFDO0FBQUEsSUFDekVxQixXQUFXQSxNQUFNO0FBQ2JsQixlQUFTLElBQUk7QUFDYkosd0JBQWtCLElBQUk7QUFDdEJQLFlBQU04QixRQUFRLHFCQUFxQjtBQUNuQ1QsY0FBUTtBQUFBLElBQ1o7QUFBQSxJQUNBVSxTQUFTUjtBQUFBQSxFQUNiLENBQUM7QUFFRCxTQUNJLHVCQUFDLFVBQUssT0FBTyxFQUFFWSxTQUFTLElBQUlDLFVBQVUsS0FBS0MsUUFBUSxTQUFTLEdBQ3hEO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDJCQUEwQixPQUFPLEVBQUVDLGNBQWMsRUFBRSxHQUM5RDtBQUFBLDZCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxTQUFTLEdBQUcsd0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Q7QUFBQSxNQUMvRCx1QkFBQyxVQUFLLFdBQVUsZUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLE1BQzNCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxhQUFZO0FBQUEsVUFDWixPQUFPckM7QUFBQUEsVUFDUCxVQUFVLENBQUNzQixNQUFNckIsVUFBVXFCLEVBQUVnQixPQUFPQyxLQUFLO0FBQUEsVUFDekMsT0FBTyxFQUFFQyxNQUFNLEdBQUdDLFVBQVUsSUFBSTtBQUFBO0FBQUEsUUFKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXNDO0FBQUEsTUFFdEMsdUJBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNO0FBQUVoQyxpQkFBUyxJQUFJO0FBQUdOLG9CQUFZLElBQUk7QUFBQSxNQUFHLEdBQUcsOEJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFFQ2EsZUFBZTBCLFdBQVcsdUJBQUMsY0FBVyxPQUFPMUIsZUFBZVIsT0FBTyxNQUFLLGlCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJEO0FBQUEsSUFDckZBLFNBQVMsQ0FBQ04sWUFBWUUsbUJBQW1CLFFBQVEsdUJBQUMsT0FBRSxXQUFVLGNBQWNJLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFFbEZRLGVBQWUyQixhQUFhLHVCQUFDLGdCQUFhLE1BQU0sR0FBRyxXQUFXLE1BQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUM7QUFBQSxJQUVqRSxDQUFDM0IsZUFBZTJCLGNBQWMzQixlQUFlNEIsUUFBUSxJQUFJQyxXQUFXLEtBQ2pFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxNQUFLO0FBQUEsUUFDTCxPQUFNO0FBQUEsUUFDTixhQUNJN0MsT0FBTzBCLEtBQUssTUFBTSxLQUNaLHVFQUNBO0FBQUEsUUFFVixRQUNJMUIsT0FBTzBCLEtBQUssTUFBTSxLQUNkLHVCQUFDLFVBQU8sU0FBUSxXQUFVLFNBQVMsTUFBTTtBQUFFakIsbUJBQVMsSUFBSTtBQUFHTixzQkFBWSxJQUFJO0FBQUEsUUFBRyxHQUFHLDhCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFDQTJDO0FBQUFBO0FBQUFBLE1BYlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBY0s7QUFBQSxJQUlSLENBQUM5QixlQUFlMkIsY0FBYzNCLGVBQWU0QixRQUFRLElBQUlDLFNBQVMsS0FDL0QsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVFLFdBQVcsR0FBRyxHQUNyRC9CLDBCQUFlNEIsUUFBUSxJQUFJSTtBQUFBQSxNQUFJLENBQUNDLE1BQzlCLHVCQUFDLFNBQWUsV0FBVSxjQUN0QjtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFQyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNsQztBQUFBLGlDQUFDLFVBQU1GLFlBQUVyQyxRQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWM7QUFBQSxVQUNkLHVCQUFDLFVBQUssT0FBTyxFQUFFeUIsVUFBVSxVQUFVZSxPQUFPLG1CQUFtQixHQUN4RCxXQUFDSCxFQUFFcEMsT0FBT29DLEVBQUVuQyxLQUFLbUMsRUFBRWxDLEtBQUssRUFBRXNDLE9BQU9DLE9BQU8sRUFBRUMsS0FBSyxLQUFLLEtBQUssMEJBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFSixLQUFLLEdBQUcsR0FDckM7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsUUFBTyxPQUFPLEVBQUUsU0FBUyxlQUFlLEdBQ25ERjtBQUFBQSxjQUFFTztBQUFBQSxZQUFjO0FBQUEsZUFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVE7QUFBQSxjQUNSLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTtBQUFFL0MseUJBQVMsSUFBSTtBQUFHRiwrQkFBZSxJQUFJO0FBQUdGLGtDQUFrQjRDLEVBQUVsQixFQUFFO0FBQUEsY0FBRztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSHRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxXQWxCTWtCLEVBQUVsQixJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxJQUNILEtBdEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUdIN0IsWUFDRyx1QkFBQyxTQUFNLE9BQU0sZ0JBQWUsU0FBUyxNQUFNQyxZQUFZLEtBQUssR0FDeEQ7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csT0FBTTtBQUFBLFVBQ04sT0FBT08sS0FBS0U7QUFBQUEsVUFDWixVQUFVLENBQUNVLE1BQU1YLFFBQVEsQ0FBQzhDLE9BQU8sRUFBRSxHQUFHQSxHQUFHN0MsTUFBTVUsRUFBRWdCLE9BQU9DLE1BQU0sRUFBRTtBQUFBLFVBQ2hFLFdBQVM7QUFBQTtBQUFBLFFBSmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWE7QUFBQSxNQUdiLHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFQyxNQUFNLEdBQUdDLFVBQVUsSUFBSSxHQUNqQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csT0FBTTtBQUFBLFlBQ04sT0FBTy9CLEtBQUtHO0FBQUFBLFlBQ1osVUFBVSxDQUFDUyxNQUFNWCxRQUFRLENBQUM4QyxPQUFPLEVBQUUsR0FBR0EsR0FBRzVDLE9BQU9TLEVBQUVnQixPQUFPQyxNQUFNLEVBQUU7QUFBQTtBQUFBLFVBSHJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUd1RSxLQUozRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxNQUFNLEdBQUdDLFVBQVUsSUFBSSxHQUNqQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csT0FBTTtBQUFBLFlBQ04sT0FBTy9CLEtBQUtJO0FBQUFBLFlBQ1osVUFBVSxDQUFDUSxNQUFNWCxRQUFRLENBQUM4QyxPQUFPLEVBQUUsR0FBR0EsR0FBRzNDLEtBQUtRLEVBQUVnQixPQUFPQyxNQUFNLEVBQUU7QUFBQSxZQUMvRCxXQUFXO0FBQUE7QUFBQSxVQUpmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlrQixLQUx0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxPQUFNO0FBQUEsVUFDTixPQUFPN0IsS0FBS0s7QUFBQUEsVUFDWixVQUFVLENBQUNPLE1BQU1YLFFBQVEsQ0FBQzhDLE9BQU8sRUFBRSxHQUFHQSxHQUFHMUMsT0FBT08sRUFBRWdCLE9BQU9DLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFIckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3VFO0FBQUEsTUFHdEUvQixTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BRTNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxTQUFRO0FBQUEsVUFDUjtBQUFBLFVBQ0EsVUFBVUUsS0FBS0UsS0FBS2MsS0FBSyxNQUFNO0FBQUEsVUFDL0IsU0FBU0YsZUFBZWtDO0FBQUFBLFVBQ3hCLFNBQVMsTUFBTWxDLGVBQWVtQyxPQUFPO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFMM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxTQTFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkNBO0FBQUEsSUFHSHZELG1CQUFtQixRQUNoQix1QkFBQyxTQUFNLE9BQU0sa0NBQWlDLFNBQVMsTUFBTUMsa0JBQWtCLElBQUksR0FDL0U7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csT0FBTTtBQUFBLFVBQ04sV0FBVTtBQUFBLFVBQ1YsT0FBT0M7QUFBQUEsVUFDUCxVQUFVLENBQUNnQixNQUFNZixlQUFlZSxFQUFFZ0IsT0FBT0MsS0FBSztBQUFBLFVBQzlDLFdBQVM7QUFBQTtBQUFBLFFBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS2E7QUFBQSxNQUdaL0IsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUUzQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csU0FBUTtBQUFBLFVBQ1I7QUFBQSxVQUNBLFNBQVNzQixlQUFlNEI7QUFBQUEsVUFDeEIsU0FBUyxNQUFNNUIsZUFBZTZCLE9BQU92RCxjQUFjO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFKekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsT0FySVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVJQTtBQUVSO0FBQUNSLEdBNUxlRCxlQUFhO0FBQUEsVUFDTGIsZ0JBQ05VLFVBQ1FOLGNBU0NMLFVBUUFELGFBbUJBQSxXQUFXO0FBQUE7QUFBQSxLQXZDdEJlO0FBQWEsSUFBQWlFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiYWRkTG95YWx0eVBvaW50cyIsImNyZWF0ZUN1c3RvbWVyIiwiZ2V0Q3VzdG9tZXJzQnlDb21wYW55IiwidXNlQXV0aFN0b3JlIiwiQXBpRXJyb3IiLCJRdWVyeUVycm9yIiwiTW9kYWwiLCJCdXR0b24iLCJUZXh0RmllbGQiLCJ1c2VUb2FzdCIsIkVtcHR5U3RhdGUiLCJTa2VsZXRvbkxpc3QiLCJDdXN0b21lcnNQYWdlIiwiX3MiLCJxdWVyeUNsaWVudCIsInRvYXN0IiwiY29tcGFueUlkIiwic2VhcmNoIiwic2V0U2VhcmNoIiwiY3JlYXRpbmciLCJzZXRDcmVhdGluZyIsImFkZGluZ1BvaW50c1RvIiwic2V0QWRkaW5nUG9pbnRzVG8iLCJwb2ludHNJbnB1dCIsInNldFBvaW50c0lucHV0IiwiZXJyb3IiLCJzZXRFcnJvciIsImZvcm0iLCJzZXRGb3JtIiwibmFtZSIsInBob25lIiwiY3BmIiwiZW1haWwiLCJjdXN0b21lcnNRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInJlZnJlc2giLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uQXBpRXJyb3IiLCJlIiwibWVzc2FnZSIsImNyZWF0ZU11dGF0aW9uIiwibXV0YXRpb25GbiIsInRyaW0iLCJvblN1Y2Nlc3MiLCJzdWNjZXNzIiwib25FcnJvciIsInBvaW50c011dGF0aW9uIiwiaWQiLCJOdW1iZXIiLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJtYXJnaW5Cb3R0b20iLCJmb250U2l6ZSIsInRhcmdldCIsInZhbHVlIiwiZmxleCIsIm1pbldpZHRoIiwiaXNFcnJvciIsImlzTG9hZGluZyIsImRhdGEiLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJtYXJnaW5Ub3AiLCJtYXAiLCJjIiwiZGlzcGxheSIsImdhcCIsImNvbG9yIiwiZmlsdGVyIiwiQm9vbGVhbiIsImpvaW4iLCJsb3lhbHR5UG9pbnRzIiwiZiIsImlzUGVuZGluZyIsIm11dGF0ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkN1c3RvbWVyc1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IGFkZExveWFsdHlQb2ludHMsIGNyZWF0ZUN1c3RvbWVyLCBnZXRDdXN0b21lcnNCeUNvbXBhbnkgfSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tIFwiLi4vLi4vbGliL2FwaUNsaWVudFwiO1xyXG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xyXG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gXCIuLi8uLi91aS9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IFRleHRGaWVsZCB9IGZyb20gXCIuLi8uLi91aS9GaWVsZFwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi8uLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSBcIi4uLy4uL3VpL0VtcHR5U3RhdGVcIjtcclxuaW1wb3J0IHsgU2tlbGV0b25MaXN0IH0gZnJvbSBcIi4uLy4uL3VpL1NrZWxldG9uXCI7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ3VzdG9tZXJzUGFnZSgpIHtcclxuICAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICAgIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICAgIGNvbnN0IHsgY29tcGFueUlkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICAgIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtjcmVhdGluZywgc2V0Q3JlYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2FkZGluZ1BvaW50c1RvLCBzZXRBZGRpbmdQb2ludHNUb10gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFtwb2ludHNJbnB1dCwgc2V0UG9pbnRzSW5wdXRdID0gdXNlU3RhdGUoXCIxMFwiKTtcclxuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gICAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUoeyBuYW1lOiBcIlwiLCBwaG9uZTogXCJcIiwgY3BmOiBcIlwiLCBlbWFpbDogXCJcIiB9KTtcclxuXHJcbiAgICBjb25zdCBjdXN0b21lcnNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgICAgICBxdWVyeUtleTogW1wiY3VzdG9tZXJzXCIsIGNvbXBhbnlJZCwgc2VhcmNoXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRDdXN0b21lcnNCeUNvbXBhbnkoY29tcGFueUlkID8/IDEsIHNlYXJjaCksXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCByZWZyZXNoID0gKCkgPT4gdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJjdXN0b21lcnNcIl0gfSk7XHJcbiAgICBjb25zdCBvbkFwaUVycm9yID0gKGU6IHVua25vd24pID0+IHNldEVycm9yKGUgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGUubWVzc2FnZSA6IFwiT3BlcmHDp8OjbyBmYWxob3UuXCIpO1xyXG5cclxuICAgIGNvbnN0IGNyZWF0ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgICAgICAgIGNyZWF0ZUN1c3RvbWVyKHtcclxuICAgICAgICAgICAgICAgIGNvbXBhbnlJZDogY29tcGFueUlkID8/IDEsXHJcbiAgICAgICAgICAgICAgICBuYW1lOiBmb3JtLm5hbWUudHJpbSgpLFxyXG4gICAgICAgICAgICAgICAgcGhvbmU6IGZvcm0ucGhvbmUudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IGZvcm0ucGhvbmUudHJpbSgpLFxyXG4gICAgICAgICAgICAgICAgY3BmOiBmb3JtLmNwZi50cmltKCkgPT09IFwiXCIgPyBudWxsIDogZm9ybS5jcGYudHJpbSgpLFxyXG4gICAgICAgICAgICAgICAgZW1haWw6IGZvcm0uZW1haWwudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IGZvcm0uZW1haWwudHJpbSgpLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgICAgICAgIHNldENyZWF0aW5nKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Rm9ybSh7IG5hbWU6IFwiXCIsIHBob25lOiBcIlwiLCBjcGY6IFwiXCIsIGVtYWlsOiBcIlwiIH0pO1xyXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiQ2xpZW50ZSBjYWRhc3RyYWRvLlwiKTtcclxuICAgICAgICAgICAgcmVmcmVzaCgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHBvaW50c011dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46IChpZDogbnVtYmVyKSA9PiBhZGRMb3lhbHR5UG9pbnRzKGlkLCBOdW1iZXIocG9pbnRzSW5wdXQpIHx8IDApLFxyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICAgICAgc2V0QWRkaW5nUG9pbnRzVG8obnVsbCk7XHJcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJQb250b3MgYXR1YWxpemFkb3MuXCIpO1xyXG4gICAgICAgICAgICByZWZyZXNoKCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDkwMCwgbWFyZ2luOiBcIjAgYXV0b1wiIH19PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2UgdWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiA2IH19PlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjdyZW1cIiB9fT5DbGllbnRlczwvaDI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1aS1zcGFjZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgcG9yIG5vbWUsIHRlbGVmb25lIG91IENQRuKAplwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDIyMCB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBvbkNsaWNrPXsoKSA9PiB7IHNldEVycm9yKG51bGwpOyBzZXRDcmVhdGluZyh0cnVlKTsgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgKyBOb3ZvIGNsaWVudGVcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtjdXN0b21lcnNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtjdXN0b21lcnNRdWVyeS5lcnJvcn0gd2hhdD1cIm9zIGNsaWVudGVzXCIgLz59XHJcbiAgICAgICAgICAgIHtlcnJvciAmJiAhY3JlYXRpbmcgJiYgYWRkaW5nUG9pbnRzVG8gPT09IG51bGwgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgICAgICAge2N1c3RvbWVyc1F1ZXJ5LmlzTG9hZGluZyAmJiA8U2tlbGV0b25MaXN0IHJvd3M9ezZ9IHJvd0hlaWdodD17NTh9IC8+fVxyXG5cclxuICAgICAgICAgICAgeyFjdXN0b21lcnNRdWVyeS5pc0xvYWRpbmcgJiYgKGN1c3RvbWVyc1F1ZXJ5LmRhdGEgPz8gW10pLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8RW1wdHlTdGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIGljb249XCLwn5GlXCJcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIk5lbmh1bSBjbGllbnRlIGVuY29udHJhZG9cIlxyXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoLnRyaW0oKSA9PT0gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkNhZGFzdHJlIG8gcHJpbWVpcm8gY2xpZW50ZSBwYXJhIGNvbWXDp2FyIG8gcHJvZ3JhbWEgZGUgZmlkZWxpZGFkZS5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk5lbmh1bSBjbGllbnRlIGJhdGUgY29tIGVzc2EgYnVzY2EuXCJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aW9uPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoLnRyaW0oKSA9PT0gXCJcIiA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBvbkNsaWNrPXsoKSA9PiB7IHNldEVycm9yKG51bGwpOyBzZXRDcmVhdGluZyh0cnVlKTsgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKyBOb3ZvIGNsaWVudGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHshY3VzdG9tZXJzUXVlcnkuaXNMb2FkaW5nICYmIChjdXN0b21lcnNRdWVyeS5kYXRhID8/IFtdKS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZSByaXNlLTEgdGlja2V0XCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAxMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7KGN1c3RvbWVyc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgoYykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17Yy5pZH0gY2xhc3NOYW1lPVwidGlja2V0LXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntjLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtbYy5waG9uZSwgYy5jcGYsIGMuZW1haWxdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiIMK3IFwiKSB8fCBcInNlbSBkYWRvcyBkZSBjb250YXRvXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogMTAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2hpcFwiIHN0eWxlPXt7IFwiLS1kb3RcIjogXCJ2YXIoLS1hbWJlcilcIiB9IGFzIFJlYWN0LkNTU1Byb3BlcnRpZXN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Yy5sb3lhbHR5UG9pbnRzfSBwdHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldEVycm9yKG51bGwpOyBzZXRQb2ludHNJbnB1dChcIjEwXCIpOyBzZXRBZGRpbmdQb2ludHNUbyhjLmlkKTsgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICsgUG9udG9zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtjcmVhdGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8TW9kYWwgdGl0bGU9XCJOb3ZvIGNsaWVudGVcIiBvbkNsb3NlPXsoKSA9PiBzZXRDcmVhdGluZyhmYWxzZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJOb21lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKChmKSA9PiAoeyAuLi5mLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE0MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlRlbGVmb25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5waG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oKGYpID0+ICh7IC4uLmYsIHBob25lOiBlLnRhcmdldC52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTQwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ1BGXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5jcGZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKChmKSA9PiAoeyAuLi5mLCBjcGY6IGUudGFyZ2V0LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezExfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJFLW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKChmKSA9PiAoeyAuLi5mLCBlbWFpbDogZS50YXJnZXQudmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Zm9ybS5uYW1lLnRyaW0oKSA9PT0gXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17Y3JlYXRlTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjcmVhdGVNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENyaWFyIGNsaWVudGVcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7YWRkaW5nUG9pbnRzVG8gIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgPE1vZGFsIHRpdGxlPVwiQWRpY2lvbmFyIHBvbnRvcyBkZSBmaWRlbGlkYWRlXCIgb25DbG9zZT17KCkgPT4gc2V0QWRkaW5nUG9pbnRzVG8obnVsbCl9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQb250b3MgKHVzZSBuZWdhdGl2byBwYXJhIHJlc2dhdGFyKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cG9pbnRzSW5wdXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UG9pbnRzSW5wdXQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17cG9pbnRzTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwb2ludHNNdXRhdGlvbi5tdXRhdGUoYWRkaW5nUG9pbnRzVG8pfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQXBsaWNhclxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8L21haW4+XHJcbiAgICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9jdXN0b21lcnMvQ3VzdG9tZXJzUGFnZS50c3gifQ==