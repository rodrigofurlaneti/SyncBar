import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/finance/ScenariosPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getScenarios, setRevenueTarget } from "/src/features/finance/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { formatBRL } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
const parsePct = (raw) => {
  if (raw.trim() === "") return void 0;
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) && value > 0 && value < 100 ? value / 100 : void 0;
};
const parseMoney = (raw) => {
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) && value >= 0 ? value : 0;
};
function currentMonthValue() {
  const now = /* @__PURE__ */ new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}
const scenarioTone = {
  Pessimista: "var(--danger)",
  Normal: "var(--amber)",
  Otimista: "var(--ok)"
};
export function ScenariosPage() {
  _s();
  const queryClient = useQueryClient();
  const { branchId } = useAuthStore();
  const [monthValue, setMonthValue] = useState(currentMonthValue());
  const [profitInput, setProfitInput] = useState("");
  const [pessimisticInput, setPessimisticInput] = useState("");
  const [normalInput, setNormalInput] = useState("");
  const [optimisticInput, setOptimisticInput] = useState("");
  const [selected, setSelected] = useState("Normal");
  const [feedback, setFeedback] = useState(null);
  const [yearStr, monthStr] = monthValue.split("-");
  const year = Number(yearStr);
  const month = Number(monthStr);
  const desiredProfit = parseMoney(profitInput);
  const scenariosQuery = useQuery({
    queryKey: [
      "scenarios",
      branchId,
      year,
      month,
      desiredProfit,
      pessimisticInput,
      normalInput,
      optimisticInput
    ],
    queryFn: () => getScenarios(branchId, year, month, desiredProfit, {
      pessimistic: parsePct(pessimisticInput),
      normal: parsePct(normalInput),
      optimistic: parsePct(optimisticInput)
    }),
    enabled: Number.isFinite(year) && Number.isFinite(month),
    placeholderData: (previous) => previous
  });
  const data = scenariosQuery.data;
  const selectedScenario = data?.scenarios.find((s) => s.name === selected);
  const targetMutation = useMutation({
    mutationFn: (scenario) => setRevenueTarget({
      branchId,
      referenceYear: year,
      referenceMonth: month,
      targetAmount: scenario.targetRevenue
    }),
    onSuccess: (_, scenario) => {
      setFeedback(`Meta do mês definida em ${formatBRL(scenario.targetRevenue)} (cenário ${scenario.name}).`);
      void queryClient.invalidateQueries({ queryKey: ["finance"] });
    },
    onError: (e) => setFeedback(e instanceof ApiError ? e.message : "Falha ao definir a meta.")
  });
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "center", gap: 14, marginBottom: 6, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Cenários" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 104,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "month", value: monthValue, onChange: (e) => setMonthValue(e.target.value), style: { width: 190 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "rise", style: { color: "var(--ink-faint)", fontSize: "0.9rem", marginTop: 0 }, children: "Quanto preciso faturar (e ter de estoque) para pagar todos os custos — faturamento necessário = (custos fixos + lucro desejado) ÷ margem de contribuição." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
      lineNumber: 107,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rise rise-1", style: { display: "grid", gap: 8, gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", marginBottom: 16 }, children: [
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.82rem" }, children: "Lucro desejado (R$)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 114,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { inputMode: "decimal", placeholder: "0 = ponto de equilíbrio", value: profitInput, onChange: (e) => setProfitInput(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 115,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 113,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--danger)", fontSize: "0.82rem" }, children: "Margem pessimista (%)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 118,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { inputMode: "decimal", placeholder: "auto", value: pessimisticInput, onChange: (e) => setPessimisticInput(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 119,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 117,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--amber)", fontSize: "0.82rem" }, children: "Margem normal (%)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 122,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { inputMode: "decimal", placeholder: "auto (histórico)", value: normalInput, onChange: (e) => setNormalInput(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 123,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 121,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ok)", fontSize: "0.82rem" }, children: "Margem otimista (%)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 126,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { inputMode: "decimal", placeholder: "auto", value: optimisticInput, onChange: (e) => setOptimisticInput(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 127,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 125,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
      lineNumber: 112,
      columnNumber: 7
    }, this),
    scenariosQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: scenariosQuery.error, what: "os cenários" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
      lineNumber: 131,
      columnNumber: 34
    }, this),
    feedback && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--amber)" }, children: feedback }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
      lineNumber: 132,
      columnNumber: 20
    }, this),
    data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
        "Base do mês: custos fixos ",
        formatBRL(data.fixedCosts),
        data.historicalMarginRate !== null && ` · margem real ${(data.historicalMarginRate * 100).toFixed(1)}%`,
        data.historicalRevenue !== null && ` · receita até agora ${formatBRL(data.historicalRevenue)}`,
        data.averageTicket !== null && ` · ticket médio ${formatBRL(data.averageTicket)}`,
        data.historicalMarginRate === null && " · sem histórico no mês — usando margem padrão de 30%"
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 136,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rise rise-2", style: { display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", marginBottom: 16 }, children: data.scenarios.map((scenario) => {
        const tone = scenarioTone[scenario.name] ?? "var(--ink)";
        const isSelected = selected === scenario.name;
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            role: "button",
            tabIndex: 0,
            onClick: () => setSelected(scenario.name),
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") setSelected(scenario.name);
            },
            className: "ticket",
            style: {
              padding: 18,
              display: "grid",
              gap: 8,
              textAlign: "left",
              cursor: "pointer",
              border: isSelected ? `1px solid ${tone}` : "1px solid var(--line)",
              background: "var(--bg-raise)"
            },
            children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "baseline" }, children: [
                /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.3rem", color: tone }, children: scenario.name }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                  lineNumber: 170,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
                  "margem ",
                  (scenario.marginRate * 100).toFixed(1),
                  "%"
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                  lineNumber: 173,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                lineNumber: 169,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mono-num display", style: { fontSize: "1.7rem" }, children: formatBRL(scenario.targetRevenue) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                lineNumber: 177,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--ink-dim)", fontSize: "0.85rem", display: "grid", gap: 2 }, children: [
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "ponto de equilíbrio: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(scenario.breakEvenRevenue) }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                    lineNumber: 181,
                    columnNumber: 48
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                  lineNumber: 181,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "por dia (",
                  data.daysInMonth,
                  " dias): ",
                  /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(scenario.dailyTarget) }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                    lineNumber: 182,
                    columnNumber: 62
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                  lineNumber: 182,
                  columnNumber: 21
                }, this),
                scenario.estimatedSalesCount !== null && /* @__PURE__ */ jsxDEV("span", { children: [
                  "≈ ",
                  /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: scenario.estimatedSalesCount }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                    lineNumber: 184,
                    columnNumber: 27
                  }, this),
                  " vendas no mês"
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                  lineNumber: 184,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                lineNumber: 180,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "btn-ghost",
                  style: { minHeight: 40 },
                  disabled: targetMutation.isPending,
                  onClick: (e) => {
                    e.stopPropagation();
                    targetMutation.mutate(scenario);
                  },
                  children: "Usar como meta do mês"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                  lineNumber: 187,
                  columnNumber: 19
                },
                this
              )
            ]
          },
          scenario.name,
          true,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
            lineNumber: 150,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 145,
        columnNumber: 11
      }, this),
      selectedScenario && /* @__PURE__ */ jsxDEV("div", { className: "ticket rise rise-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: [
            "Estoque necessário — cenário ",
            selectedScenario.name
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
            lineNumber: 207,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.82rem" }, children: "baseado no mix real de vendas do mês" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
            lineNumber: 210,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 206,
          columnNumber: 15
        }, this),
        selectedScenario.stockPlan.map(
          (item) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
              /* @__PURE__ */ jsxDEV("span", { children: item.productName }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                lineNumber: 217,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
                (item.revenueShare * 100).toFixed(1),
                "% da receita · precisa de",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: item.estimatedUnits }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                  lineNumber: 220,
                  columnNumber: 23
                }, this),
                " un · em estoque",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: item.currentStock }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                  lineNumber: 221,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                lineNumber: 218,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
              lineNumber: 216,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: "mono-num display",
                style: {
                  fontSize: "1.2rem",
                  color: item.unitsToBuy > 0 ? "var(--danger)" : "var(--ok)"
                },
                children: item.unitsToBuy > 0 ? `comprar ${item.unitsToBuy}` : "ok"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
                lineNumber: 224,
                columnNumber: 19
              },
              this
            )
          ] }, item.productId, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
            lineNumber: 215,
            columnNumber: 11
          }, this)
        ),
        selectedScenario.stockPlan.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-faint)" }, children: "Sem vendas com baixa de estoque neste mês — o plano de compra aparece quando houver histórico de mix de vendas." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
          lineNumber: 236,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
        lineNumber: 205,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
      lineNumber: 135,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx",
    lineNumber: 101,
    columnNumber: 5
  }, this);
}
_s(ScenariosPage, "ZgbWX0o4j84OWnNE8KedeXWrUJY=", false, function() {
  return [useQueryClient, useAuthStore, useQuery, useMutation];
});
_c = ScenariosPage;
var _c;
$RefreshReg$(_c, "ScenariosPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/ScenariosPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUZRLFNBZ0NBLFVBaENBOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5GUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLGNBQWNDLHdCQUF3QjtBQUMvQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGlCQUFpQjtBQUUxQixTQUFTQyxrQkFBa0I7QUFFM0IsTUFBTUMsV0FBV0EsQ0FBQ0MsUUFBb0M7QUFDcEQsTUFBSUEsSUFBSUMsS0FBSyxNQUFNLEdBQUksUUFBT0M7QUFDOUIsUUFBTUMsUUFBUUMsT0FBT0osSUFBSUssUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUMxQyxTQUFPRCxPQUFPRSxTQUFTSCxLQUFLLEtBQUtBLFFBQVEsS0FBS0EsUUFBUSxNQUFNQSxRQUFRLE1BQU1EO0FBQzVFO0FBRUEsTUFBTUssYUFBYUEsQ0FBQ1AsUUFBd0I7QUFDMUMsUUFBTUcsUUFBUUMsT0FBT0osSUFBSUssUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUMxQyxTQUFPRCxPQUFPRSxTQUFTSCxLQUFLLEtBQUtBLFNBQVMsSUFBSUEsUUFBUTtBQUN4RDtBQUVBLFNBQVNLLG9CQUE0QjtBQUNuQyxRQUFNQyxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFNBQU8sR0FBR0QsSUFBSUUsWUFBWSxDQUFDLElBQUlDLE9BQU9ILElBQUlJLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDNUU7QUFFQSxNQUFNQyxlQUF1QztBQUFBLEVBQzNDQyxZQUFZO0FBQUEsRUFDWkMsUUFBUTtBQUFBLEVBQ1JDLFVBQVU7QUFDWjtBQUVPLGdCQUFTQyxnQkFBZ0I7QUFBQUMsS0FBQTtBQUM5QixRQUFNQyxjQUFjN0IsZUFBZTtBQUNuQyxRQUFNLEVBQUU4QixTQUFTLElBQUkzQixhQUFhO0FBQ2xDLFFBQU0sQ0FBQzRCLFlBQVlDLGFBQWEsSUFBSW5DLFNBQVNtQixrQkFBa0IsQ0FBQztBQUNoRSxRQUFNLENBQUNpQixhQUFhQyxjQUFjLElBQUlyQyxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDc0Msa0JBQWtCQyxtQkFBbUIsSUFBSXZDLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUN3QyxhQUFhQyxjQUFjLElBQUl6QyxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDMEMsaUJBQWlCQyxrQkFBa0IsSUFBSTNDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUM0QyxVQUFVQyxXQUFXLElBQUk3QyxTQUFpQixRQUFRO0FBQ3pELFFBQU0sQ0FBQzhDLFVBQVVDLFdBQVcsSUFBSS9DLFNBQXdCLElBQUk7QUFFNUQsUUFBTSxDQUFDZ0QsU0FBU0MsUUFBUSxJQUFJZixXQUFXZ0IsTUFBTSxHQUFHO0FBQ2hELFFBQU1DLE9BQU9wQyxPQUFPaUMsT0FBTztBQUMzQixRQUFNSSxRQUFRckMsT0FBT2tDLFFBQVE7QUFDN0IsUUFBTUksZ0JBQWdCbkMsV0FBV2tCLFdBQVc7QUFFNUMsUUFBTWtCLGlCQUFpQnBELFNBQVM7QUFBQSxJQUM5QnFELFVBQVU7QUFBQSxNQUFDO0FBQUEsTUFBYXRCO0FBQUFBLE1BQVVrQjtBQUFBQSxNQUFNQztBQUFBQSxNQUFPQztBQUFBQSxNQUM3Q2Y7QUFBQUEsTUFBa0JFO0FBQUFBLE1BQWFFO0FBQUFBLElBQWU7QUFBQSxJQUNoRGMsU0FBU0EsTUFDUHBELGFBQWE2QixVQUFVa0IsTUFBTUMsT0FBT0MsZUFBZTtBQUFBLE1BQ2pESSxhQUFhL0MsU0FBUzRCLGdCQUFnQjtBQUFBLE1BQ3RDb0IsUUFBUWhELFNBQVM4QixXQUFXO0FBQUEsTUFDNUJtQixZQUFZakQsU0FBU2dDLGVBQWU7QUFBQSxJQUN0QyxDQUFDO0FBQUEsSUFDSGtCLFNBQVM3QyxPQUFPRSxTQUFTa0MsSUFBSSxLQUFLcEMsT0FBT0UsU0FBU21DLEtBQUs7QUFBQSxJQUN2RFMsaUJBQWlCQSxDQUFDQyxhQUFhQTtBQUFBQSxFQUNqQyxDQUFDO0FBRUQsUUFBTUMsT0FBT1QsZUFBZVM7QUFDNUIsUUFBTUMsbUJBQ0pELE1BQU1FLFVBQVVDLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRUMsU0FBU3hCLFFBQVE7QUFFakQsUUFBTXlCLGlCQUFpQnBFLFlBQVk7QUFBQSxJQUNqQ3FFLFlBQVlBLENBQUNDLGFBQ1hsRSxpQkFBaUI7QUFBQSxNQUNmNEI7QUFBQUEsTUFDQXVDLGVBQWVyQjtBQUFBQSxNQUNmc0IsZ0JBQWdCckI7QUFBQUEsTUFDaEJzQixjQUFjSCxTQUFTSTtBQUFBQSxJQUN6QixDQUFDO0FBQUEsSUFDSEMsV0FBV0EsQ0FBQ0MsR0FBR04sYUFBYTtBQUMxQnhCLGtCQUFZLDJCQUEyQnZDLFVBQVUrRCxTQUFTSSxhQUFhLENBQUMsYUFBYUosU0FBU0gsSUFBSSxJQUFJO0FBQ3RHLFdBQUtwQyxZQUFZOEMsa0JBQWtCLEVBQUV2QixVQUFVLENBQUMsU0FBUyxFQUFFLENBQUM7QUFBQSxJQUM5RDtBQUFBLElBQ0F3QixTQUFTQSxDQUFDQyxNQUNSakMsWUFBWWlDLGFBQWF6RSxXQUFXeUUsRUFBRUMsVUFBVSwwQkFBMEI7QUFBQSxFQUM5RSxDQUFDO0FBRUQsU0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsU0FBUyxJQUFJQyxVQUFVLE1BQU1DLFFBQVEsU0FBUyxHQUMzRDtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxZQUFZLFVBQVVDLEtBQUssSUFBSUMsY0FBYyxHQUFHQyxVQUFVLE9BQU8sR0FDL0c7QUFBQSw2QkFBQyxRQUFHLFdBQVUsV0FBVSxPQUFPLEVBQUVDLFVBQVUsU0FBUyxHQUFHLHdCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsTUFDL0QsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE1BQU0sRUFBRSxLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsV0FBTSxNQUFLLFNBQVEsT0FBT3pELFlBQVksVUFBVSxDQUFDOEMsTUFBTTdDLGNBQWM2QyxFQUFFWSxPQUFPOUUsS0FBSyxHQUFHLE9BQU8sRUFBRStFLE9BQU8sSUFBSSxLQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZHO0FBQUEsU0FIL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFDQSx1QkFBQyxPQUFFLFdBQVUsUUFBTyxPQUFPLEVBQUVDLE9BQU8sb0JBQW9CSixVQUFVLFVBQVVLLFdBQVcsRUFBRSxHQUFHLHlLQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU8sRUFBRVYsU0FBUyxRQUFRRSxLQUFLLEdBQUdTLHFCQUFxQix3Q0FBd0NSLGNBQWMsR0FBRyxHQUMzSTtBQUFBLDZCQUFDLFdBQU0sT0FBTyxFQUFFSCxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUN0QztBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFTyxPQUFPLGtCQUFrQkosVUFBVSxVQUFVLEdBQUcsbUNBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUNsRix1QkFBQyxXQUFNLFdBQVUsV0FBVSxhQUFZLDJCQUEwQixPQUFPdEQsYUFBYSxVQUFVLENBQUM0QyxNQUFNM0MsZUFBZTJDLEVBQUVZLE9BQU85RSxLQUFLLEtBQW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUk7QUFBQSxXQUZ2STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFdBQU0sT0FBTyxFQUFFdUUsU0FBUyxRQUFRRSxLQUFLLEVBQUUsR0FDdEM7QUFBQSwrQkFBQyxVQUFLLE9BQU8sRUFBRU8sT0FBTyxpQkFBaUJKLFVBQVUsVUFBVSxHQUFHLHFDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsUUFDbkYsdUJBQUMsV0FBTSxXQUFVLFdBQVUsYUFBWSxRQUFPLE9BQU9wRCxrQkFBa0IsVUFBVSxDQUFDMEMsTUFBTXpDLG9CQUFvQnlDLEVBQUVZLE9BQU85RSxLQUFLLEtBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEg7QUFBQSxXQUY5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFdBQU0sT0FBTyxFQUFFdUUsU0FBUyxRQUFRRSxLQUFLLEVBQUUsR0FDdEM7QUFBQSwrQkFBQyxVQUFLLE9BQU8sRUFBRU8sT0FBTyxnQkFBZ0JKLFVBQVUsVUFBVSxHQUFHLGlDQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDOUUsdUJBQUMsV0FBTSxXQUFVLFdBQVUsYUFBWSxvQkFBbUIsT0FBT2xELGFBQWEsVUFBVSxDQUFDd0MsTUFBTXZDLGVBQWV1QyxFQUFFWSxPQUFPOUUsS0FBSyxLQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThIO0FBQUEsV0FGaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxXQUFNLE9BQU8sRUFBRXVFLFNBQVMsUUFBUUUsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVPLE9BQU8sYUFBYUosVUFBVSxVQUFVLEdBQUcsbUNBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxRQUM3RSx1QkFBQyxXQUFNLFdBQVUsV0FBVSxhQUFZLFFBQU8sT0FBT2hELGlCQUFpQixVQUFVLENBQUNzQyxNQUFNckMsbUJBQW1CcUMsRUFBRVksT0FBTzlFLEtBQUssS0FBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSDtBQUFBLFdBRjVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUVDd0MsZUFBZTJDLFdBQVcsdUJBQUMsY0FBVyxPQUFPM0MsZUFBZTRDLE9BQU8sTUFBSyxpQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRDtBQUFBLElBQ3JGcEQsWUFBWSx1QkFBQyxPQUFFLE9BQU8sRUFBRWdELE9BQU8sZUFBZSxHQUFJaEQsc0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0M7QUFBQSxJQUUzRGlCLFFBQ0MsbUNBQ0U7QUFBQSw2QkFBQyxPQUFFLE9BQU8sRUFBRStCLE9BQU8sb0JBQW9CSixVQUFVLFVBQVUsR0FBRztBQUFBO0FBQUEsUUFDakNsRixVQUFVdUQsS0FBS29DLFVBQVU7QUFBQSxRQUNuRHBDLEtBQUtxQyx5QkFBeUIsUUFDN0IsbUJBQW1CckMsS0FBS3FDLHVCQUF1QixLQUFLQyxRQUFRLENBQUMsQ0FBQztBQUFBLFFBQy9EdEMsS0FBS3VDLHNCQUFzQixRQUFRLHdCQUF3QjlGLFVBQVV1RCxLQUFLdUMsaUJBQWlCLENBQUM7QUFBQSxRQUM1RnZDLEtBQUt3QyxrQkFBa0IsUUFBUSxtQkFBbUIvRixVQUFVdUQsS0FBS3dDLGFBQWEsQ0FBQztBQUFBLFFBQy9FeEMsS0FBS3FDLHlCQUF5QixRQUFRO0FBQUEsV0FOekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFBYyxPQUFPLEVBQUVmLFNBQVMsUUFBUUUsS0FBSyxJQUFJUyxxQkFBcUIsd0NBQXdDUixjQUFjLEdBQUcsR0FDM0l6QixlQUFLRSxVQUFVdUMsSUFBSSxDQUFDakMsYUFBYTtBQUNoQyxjQUFNa0MsT0FBTy9FLGFBQWE2QyxTQUFTSCxJQUFJLEtBQUs7QUFDNUMsY0FBTXNDLGFBQWE5RCxhQUFhMkIsU0FBU0g7QUFDekMsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsTUFBSztBQUFBLFlBQ0wsVUFBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNdkIsWUFBWTBCLFNBQVNILElBQUk7QUFBQSxZQUN4QyxXQUFXLENBQUNZLE1BQU07QUFDaEIsa0JBQUlBLEVBQUUyQixRQUFRLFdBQVczQixFQUFFMkIsUUFBUSxJQUFLOUQsYUFBWTBCLFNBQVNILElBQUk7QUFBQSxZQUNuRTtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQ1YsT0FBTztBQUFBLGNBQ0xjLFNBQVM7QUFBQSxjQUNURyxTQUFTO0FBQUEsY0FDVEUsS0FBSztBQUFBLGNBQ0xxQixXQUFXO0FBQUEsY0FDWEMsUUFBUTtBQUFBLGNBQ1JDLFFBQVFKLGFBQWEsYUFBYUQsSUFBSSxLQUFLO0FBQUEsY0FDM0NNLFlBQVk7QUFBQSxZQUNkO0FBQUEsWUFFQTtBQUFBLHFDQUFDLFNBQUksT0FBTyxFQUFFMUIsU0FBUyxRQUFRMkIsZ0JBQWdCLGlCQUFpQjFCLFlBQVksV0FBVyxHQUNyRjtBQUFBLHVDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUksVUFBVSxVQUFVSSxPQUFPVyxLQUFLLEdBQ2hFbEMsbUJBQVNILFFBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSxZQUFXLE9BQU8sRUFBRTBCLE9BQU8sb0JBQW9CSixVQUFVLFVBQVUsR0FBRztBQUFBO0FBQUEsbUJBQzNFbkIsU0FBUzBDLGFBQWEsS0FBS1osUUFBUSxDQUFDO0FBQUEsa0JBQUU7QUFBQSxxQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxvQkFBbUIsT0FBTyxFQUFFWCxVQUFVLFNBQVMsR0FDM0RsRixvQkFBVStELFNBQVNJLGFBQWEsS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVtQixPQUFPLGtCQUFrQkosVUFBVSxXQUFXTCxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUNsRjtBQUFBLHVDQUFDLFVBQUs7QUFBQTtBQUFBLGtCQUFxQix1QkFBQyxVQUFLLFdBQVUsWUFBWS9FLG9CQUFVK0QsU0FBUzJDLGdCQUFnQixLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRTtBQUFBLHFCQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRztBQUFBLGdCQUNuRyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxrQkFBVW5ELEtBQUtvRDtBQUFBQSxrQkFBWTtBQUFBLGtCQUFRLHVCQUFDLFVBQUssV0FBVSxZQUFZM0csb0JBQVUrRCxTQUFTNkMsV0FBVyxLQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RDtBQUFBLHFCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RztBQUFBLGdCQUMzRzdDLFNBQVM4Qyx3QkFBd0IsUUFDaEMsdUJBQUMsVUFBSztBQUFBO0FBQUEsa0JBQUUsdUJBQUMsVUFBSyxXQUFVLFlBQVk5QyxtQkFBUzhDLHVCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLGtCQUFPO0FBQUEscUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGO0FBQUEsbUJBSjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBTyxFQUFFQyxXQUFXLEdBQUc7QUFBQSxrQkFDdkIsVUFBVWpELGVBQWVrRDtBQUFBQSxrQkFDekIsU0FBUyxDQUFDdkMsTUFBTTtBQUNkQSxzQkFBRXdDLGdCQUFnQjtBQUNsQm5ELG1DQUFlb0QsT0FBT2xELFFBQVE7QUFBQSxrQkFDaEM7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV0E7QUFBQTtBQUFBO0FBQUEsVUEvQ0tBLFNBQVNIO0FBQUFBLFVBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFpREE7QUFBQSxNQUVKLENBQUMsS0F4REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlEQTtBQUFBLE1BRUNKLG9CQUNDLHVCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFMEIsVUFBVSxTQUFTLEdBQUc7QUFBQTtBQUFBLFlBQ3pCMUIsaUJBQWlCSTtBQUFBQSxlQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRTBCLE9BQU8sb0JBQW9CSixVQUFVLFVBQVUsR0FBRyxvREFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQzFCLGlCQUFpQjBELFVBQVVsQjtBQUFBQSxVQUFJLENBQUNtQixTQUMvQix1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFdEMsU0FBUyxRQUFRRSxLQUFLLEVBQUUsR0FDcEM7QUFBQSxxQ0FBQyxVQUFNb0MsZUFBS0MsZUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBLGNBQ3hCLHVCQUFDLFVBQUssT0FBTyxFQUFFbEMsVUFBVSxVQUFVSSxPQUFPLG1CQUFtQixHQUN6RDZCO0FBQUFBLHNCQUFLRSxlQUFlLEtBQUt4QixRQUFRLENBQUM7QUFBQSxnQkFBRTtBQUFBLGdCQUEwQjtBQUFBLGdCQUNoRSx1QkFBQyxVQUFLLFdBQVUsWUFBWXNCLGVBQUtHLGtCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRDtBQUFBLGdCQUFPO0FBQUEsZ0JBQWlCO0FBQUEsZ0JBQ3hFLHVCQUFDLFVBQUssV0FBVSxZQUFZSCxlQUFLSSxnQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEM7QUFBQSxtQkFIaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU87QUFBQSxrQkFDTHJDLFVBQVU7QUFBQSxrQkFDVkksT0FBTzZCLEtBQUtLLGFBQWEsSUFBSSxrQkFBa0I7QUFBQSxnQkFDakQ7QUFBQSxnQkFFQ0wsZUFBS0ssYUFBYSxJQUFJLFdBQVdMLEtBQUtLLFVBQVUsS0FBSztBQUFBO0FBQUEsY0FQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQWpCK0JMLEtBQUtNLFdBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsUUFDRDtBQUFBLFFBQ0FqRSxpQkFBaUIwRCxVQUFVUSxXQUFXLEtBQ3JDLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRXBDLE9BQU8sbUJBQW1CLEdBQUcsK0hBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQ0E7QUFBQSxTQTFHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEdBO0FBQUEsT0E5SUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdKQTtBQUVKO0FBQUMvRCxHQXBNZUQsZUFBYTtBQUFBLFVBQ1AzQixnQkFDQ0csY0FjRUosVUFpQkFELFdBQVc7QUFBQTtBQUFBLEtBakNwQjZCO0FBQWEsSUFBQXFHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiZ2V0U2NlbmFyaW9zIiwic2V0UmV2ZW51ZVRhcmdldCIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwiZm9ybWF0QlJMIiwiUXVlcnlFcnJvciIsInBhcnNlUGN0IiwicmF3IiwidHJpbSIsInVuZGVmaW5lZCIsInZhbHVlIiwiTnVtYmVyIiwicmVwbGFjZSIsImlzRmluaXRlIiwicGFyc2VNb25leSIsImN1cnJlbnRNb250aFZhbHVlIiwibm93IiwiRGF0ZSIsImdldEZ1bGxZZWFyIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsInNjZW5hcmlvVG9uZSIsIlBlc3NpbWlzdGEiLCJOb3JtYWwiLCJPdGltaXN0YSIsIlNjZW5hcmlvc1BhZ2UiLCJfcyIsInF1ZXJ5Q2xpZW50IiwiYnJhbmNoSWQiLCJtb250aFZhbHVlIiwic2V0TW9udGhWYWx1ZSIsInByb2ZpdElucHV0Iiwic2V0UHJvZml0SW5wdXQiLCJwZXNzaW1pc3RpY0lucHV0Iiwic2V0UGVzc2ltaXN0aWNJbnB1dCIsIm5vcm1hbElucHV0Iiwic2V0Tm9ybWFsSW5wdXQiLCJvcHRpbWlzdGljSW5wdXQiLCJzZXRPcHRpbWlzdGljSW5wdXQiLCJzZWxlY3RlZCIsInNldFNlbGVjdGVkIiwiZmVlZGJhY2siLCJzZXRGZWVkYmFjayIsInllYXJTdHIiLCJtb250aFN0ciIsInNwbGl0IiwieWVhciIsIm1vbnRoIiwiZGVzaXJlZFByb2ZpdCIsInNjZW5hcmlvc1F1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicGVzc2ltaXN0aWMiLCJub3JtYWwiLCJvcHRpbWlzdGljIiwiZW5hYmxlZCIsInBsYWNlaG9sZGVyRGF0YSIsInByZXZpb3VzIiwiZGF0YSIsInNlbGVjdGVkU2NlbmFyaW8iLCJzY2VuYXJpb3MiLCJmaW5kIiwicyIsIm5hbWUiLCJ0YXJnZXRNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJzY2VuYXJpbyIsInJlZmVyZW5jZVllYXIiLCJyZWZlcmVuY2VNb250aCIsInRhcmdldEFtb3VudCIsInRhcmdldFJldmVudWUiLCJvblN1Y2Nlc3MiLCJfIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJvbkVycm9yIiwiZSIsIm1lc3NhZ2UiLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsIm1hcmdpbkJvdHRvbSIsImZsZXhXcmFwIiwiZm9udFNpemUiLCJmbGV4IiwidGFyZ2V0Iiwid2lkdGgiLCJjb2xvciIsIm1hcmdpblRvcCIsImdyaWRUZW1wbGF0ZUNvbHVtbnMiLCJpc0Vycm9yIiwiZXJyb3IiLCJmaXhlZENvc3RzIiwiaGlzdG9yaWNhbE1hcmdpblJhdGUiLCJ0b0ZpeGVkIiwiaGlzdG9yaWNhbFJldmVudWUiLCJhdmVyYWdlVGlja2V0IiwibWFwIiwidG9uZSIsImlzU2VsZWN0ZWQiLCJrZXkiLCJ0ZXh0QWxpZ24iLCJjdXJzb3IiLCJib3JkZXIiLCJiYWNrZ3JvdW5kIiwianVzdGlmeUNvbnRlbnQiLCJtYXJnaW5SYXRlIiwiYnJlYWtFdmVuUmV2ZW51ZSIsImRheXNJbk1vbnRoIiwiZGFpbHlUYXJnZXQiLCJlc3RpbWF0ZWRTYWxlc0NvdW50IiwibWluSGVpZ2h0IiwiaXNQZW5kaW5nIiwic3RvcFByb3BhZ2F0aW9uIiwibXV0YXRlIiwic3RvY2tQbGFuIiwiaXRlbSIsInByb2R1Y3ROYW1lIiwicmV2ZW51ZVNoYXJlIiwiZXN0aW1hdGVkVW5pdHMiLCJjdXJyZW50U3RvY2siLCJ1bml0c1RvQnV5IiwicHJvZHVjdElkIiwibGVuZ3RoIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2NlbmFyaW9zUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgZ2V0U2NlbmFyaW9zLCBzZXRSZXZlbnVlVGFyZ2V0IH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHsgZm9ybWF0QlJMIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IFNjZW5hcmlvUmVzcG9uc2UgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcblxyXG5jb25zdCBwYXJzZVBjdCA9IChyYXc6IHN0cmluZyk6IG51bWJlciB8IHVuZGVmaW5lZCA9PiB7XHJcbiAgaWYgKHJhdy50cmltKCkgPT09IFwiXCIpIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgY29uc3QgdmFsdWUgPSBOdW1iZXIocmF3LnJlcGxhY2UoXCIsXCIsIFwiLlwiKSk7XHJcbiAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgJiYgdmFsdWUgPiAwICYmIHZhbHVlIDwgMTAwID8gdmFsdWUgLyAxMDAgOiB1bmRlZmluZWQ7XHJcbn07XHJcblxyXG5jb25zdCBwYXJzZU1vbmV5ID0gKHJhdzogc3RyaW5nKTogbnVtYmVyID0+IHtcclxuICBjb25zdCB2YWx1ZSA9IE51bWJlcihyYXcucmVwbGFjZShcIixcIiwgXCIuXCIpKTtcclxuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHZhbHVlKSAmJiB2YWx1ZSA+PSAwID8gdmFsdWUgOiAwO1xyXG59O1xyXG5cclxuZnVuY3Rpb24gY3VycmVudE1vbnRoVmFsdWUoKTogc3RyaW5nIHtcclxuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gIHJldHVybiBgJHtub3cuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcobm93LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxufVxyXG5cclxuY29uc3Qgc2NlbmFyaW9Ub25lOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gIFBlc3NpbWlzdGE6IFwidmFyKC0tZGFuZ2VyKVwiLFxyXG4gIE5vcm1hbDogXCJ2YXIoLS1hbWJlcilcIixcclxuICBPdGltaXN0YTogXCJ2YXIoLS1vaylcIixcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTY2VuYXJpb3NQYWdlKCkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbbW9udGhWYWx1ZSwgc2V0TW9udGhWYWx1ZV0gPSB1c2VTdGF0ZShjdXJyZW50TW9udGhWYWx1ZSgpKTtcclxuICBjb25zdCBbcHJvZml0SW5wdXQsIHNldFByb2ZpdElucHV0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwZXNzaW1pc3RpY0lucHV0LCBzZXRQZXNzaW1pc3RpY0lucHV0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtub3JtYWxJbnB1dCwgc2V0Tm9ybWFsSW5wdXRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW29wdGltaXN0aWNJbnB1dCwgc2V0T3B0aW1pc3RpY0lucHV0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGU8c3RyaW5nPihcIk5vcm1hbFwiKTtcclxuICBjb25zdCBbZmVlZGJhY2ssIHNldEZlZWRiYWNrXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBbeWVhclN0ciwgbW9udGhTdHJdID0gbW9udGhWYWx1ZS5zcGxpdChcIi1cIik7XHJcbiAgY29uc3QgeWVhciA9IE51bWJlcih5ZWFyU3RyKTtcclxuICBjb25zdCBtb250aCA9IE51bWJlcihtb250aFN0cik7XHJcbiAgY29uc3QgZGVzaXJlZFByb2ZpdCA9IHBhcnNlTW9uZXkocHJvZml0SW5wdXQpO1xyXG5cclxuICBjb25zdCBzY2VuYXJpb3NRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJzY2VuYXJpb3NcIiwgYnJhbmNoSWQsIHllYXIsIG1vbnRoLCBkZXNpcmVkUHJvZml0LFxyXG4gICAgICBwZXNzaW1pc3RpY0lucHV0LCBub3JtYWxJbnB1dCwgb3B0aW1pc3RpY0lucHV0XSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+XHJcbiAgICAgIGdldFNjZW5hcmlvcyhicmFuY2hJZCwgeWVhciwgbW9udGgsIGRlc2lyZWRQcm9maXQsIHtcclxuICAgICAgICBwZXNzaW1pc3RpYzogcGFyc2VQY3QocGVzc2ltaXN0aWNJbnB1dCksXHJcbiAgICAgICAgbm9ybWFsOiBwYXJzZVBjdChub3JtYWxJbnB1dCksXHJcbiAgICAgICAgb3B0aW1pc3RpYzogcGFyc2VQY3Qob3B0aW1pc3RpY0lucHV0KSxcclxuICAgICAgfSksXHJcbiAgICBlbmFibGVkOiBOdW1iZXIuaXNGaW5pdGUoeWVhcikgJiYgTnVtYmVyLmlzRmluaXRlKG1vbnRoKSxcclxuICAgIHBsYWNlaG9sZGVyRGF0YTogKHByZXZpb3VzKSA9PiBwcmV2aW91cyxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZGF0YSA9IHNjZW5hcmlvc1F1ZXJ5LmRhdGE7XHJcbiAgY29uc3Qgc2VsZWN0ZWRTY2VuYXJpbzogU2NlbmFyaW9SZXNwb25zZSB8IHVuZGVmaW5lZCA9XHJcbiAgICBkYXRhPy5zY2VuYXJpb3MuZmluZCgocykgPT4gcy5uYW1lID09PSBzZWxlY3RlZCk7XHJcblxyXG4gIGNvbnN0IHRhcmdldE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKHNjZW5hcmlvOiBTY2VuYXJpb1Jlc3BvbnNlKSA9PlxyXG4gICAgICBzZXRSZXZlbnVlVGFyZ2V0KHtcclxuICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICByZWZlcmVuY2VZZWFyOiB5ZWFyLFxyXG4gICAgICAgIHJlZmVyZW5jZU1vbnRoOiBtb250aCxcclxuICAgICAgICB0YXJnZXRBbW91bnQ6IHNjZW5hcmlvLnRhcmdldFJldmVudWUsXHJcbiAgICAgIH0pLFxyXG4gICAgb25TdWNjZXNzOiAoXywgc2NlbmFyaW8pID0+IHtcclxuICAgICAgc2V0RmVlZGJhY2soYE1ldGEgZG8gbcOqcyBkZWZpbmlkYSBlbSAke2Zvcm1hdEJSTChzY2VuYXJpby50YXJnZXRSZXZlbnVlKX0gKGNlbsOhcmlvICR7c2NlbmFyaW8ubmFtZX0pLmApO1xyXG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImZpbmFuY2VcIl0gfSk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKGUpID0+XHJcbiAgICAgIHNldEZlZWRiYWNrKGUgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGUubWVzc2FnZSA6IFwiRmFsaGEgYW8gZGVmaW5pciBhIG1ldGEuXCIpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMTAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDE0LCBtYXJnaW5Cb3R0b206IDYsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuN3JlbVwiIH19PkNlbsOhcmlvczwvaDI+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSB9fSAvPlxyXG4gICAgICAgIDxpbnB1dCB0eXBlPVwibW9udGhcIiB2YWx1ZT17bW9udGhWYWx1ZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRNb250aFZhbHVlKGUudGFyZ2V0LnZhbHVlKX0gc3R5bGU9e3sgd2lkdGg6IDE5MCB9fSAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC45cmVtXCIsIG1hcmdpblRvcDogMCB9fT5cclxuICAgICAgICBRdWFudG8gcHJlY2lzbyBmYXR1cmFyIChlIHRlciBkZSBlc3RvcXVlKSBwYXJhIHBhZ2FyIHRvZG9zIG9zIGN1c3RvcyDigJRcclxuICAgICAgICBmYXR1cmFtZW50byBuZWNlc3PDoXJpbyA9IChjdXN0b3MgZml4b3MgKyBsdWNybyBkZXNlamFkbykgw7cgbWFyZ2VtIGRlIGNvbnRyaWJ1acOnw6NvLlxyXG4gICAgICA8L3A+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2UgcmlzZS0xXCIgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCwgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCJyZXBlYXQoYXV0by1maXQsIG1pbm1heCgxNjBweCwgMWZyKSlcIiwgbWFyZ2luQm90dG9tOiAxNiB9fT5cclxuICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODJyZW1cIiB9fT5MdWNybyBkZXNlamFkbyAoUiQpPC9zcGFuPlxyXG4gICAgICAgICAgPGlucHV0IGlucHV0TW9kZT1cImRlY2ltYWxcIiBwbGFjZWhvbGRlcj1cIjAgPSBwb250byBkZSBlcXVpbMOtYnJpb1wiIHZhbHVlPXtwcm9maXRJbnB1dH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRQcm9maXRJbnB1dChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWRhbmdlcilcIiwgZm9udFNpemU6IFwiMC44MnJlbVwiIH19Pk1hcmdlbSBwZXNzaW1pc3RhICglKTwvc3Bhbj5cclxuICAgICAgICAgIDxpbnB1dCBpbnB1dE1vZGU9XCJkZWNpbWFsXCIgcGxhY2Vob2xkZXI9XCJhdXRvXCIgdmFsdWU9e3Blc3NpbWlzdGljSW5wdXR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGVzc2ltaXN0aWNJbnB1dChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWFtYmVyKVwiLCBmb250U2l6ZTogXCIwLjgycmVtXCIgfX0+TWFyZ2VtIG5vcm1hbCAoJSk8L3NwYW4+XHJcbiAgICAgICAgICA8aW5wdXQgaW5wdXRNb2RlPVwiZGVjaW1hbFwiIHBsYWNlaG9sZGVyPVwiYXV0byAoaGlzdMOzcmljbylcIiB2YWx1ZT17bm9ybWFsSW5wdXR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm9ybWFsSW5wdXQoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1vaylcIiwgZm9udFNpemU6IFwiMC44MnJlbVwiIH19Pk1hcmdlbSBvdGltaXN0YSAoJSk8L3NwYW4+XHJcbiAgICAgICAgICA8aW5wdXQgaW5wdXRNb2RlPVwiZGVjaW1hbFwiIHBsYWNlaG9sZGVyPVwiYXV0b1wiIHZhbHVlPXtvcHRpbWlzdGljSW5wdXR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0T3B0aW1pc3RpY0lucHV0KGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtzY2VuYXJpb3NRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtzY2VuYXJpb3NRdWVyeS5lcnJvcn0gd2hhdD1cIm9zIGNlbsOhcmlvc1wiIC8+fVxyXG4gICAgICB7ZmVlZGJhY2sgJiYgPHAgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tYW1iZXIpXCIgfX0+e2ZlZWRiYWNrfTwvcD59XHJcblxyXG4gICAgICB7ZGF0YSAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgICBCYXNlIGRvIG3DqnM6IGN1c3RvcyBmaXhvcyB7Zm9ybWF0QlJMKGRhdGEuZml4ZWRDb3N0cyl9XHJcbiAgICAgICAgICAgIHtkYXRhLmhpc3RvcmljYWxNYXJnaW5SYXRlICE9PSBudWxsICYmXHJcbiAgICAgICAgICAgICAgYCDCtyBtYXJnZW0gcmVhbCAkeyhkYXRhLmhpc3RvcmljYWxNYXJnaW5SYXRlICogMTAwKS50b0ZpeGVkKDEpfSVgfVxyXG4gICAgICAgICAgICB7ZGF0YS5oaXN0b3JpY2FsUmV2ZW51ZSAhPT0gbnVsbCAmJiBgIMK3IHJlY2VpdGEgYXTDqSBhZ29yYSAke2Zvcm1hdEJSTChkYXRhLmhpc3RvcmljYWxSZXZlbnVlKX1gfVxyXG4gICAgICAgICAgICB7ZGF0YS5hdmVyYWdlVGlja2V0ICE9PSBudWxsICYmIGAgwrcgdGlja2V0IG3DqWRpbyAke2Zvcm1hdEJSTChkYXRhLmF2ZXJhZ2VUaWNrZXQpfWB9XHJcbiAgICAgICAgICAgIHtkYXRhLmhpc3RvcmljYWxNYXJnaW5SYXRlID09PSBudWxsICYmIFwiIMK3IHNlbSBoaXN0w7NyaWNvIG5vIG3DqnMg4oCUIHVzYW5kbyBtYXJnZW0gcGFkcsOjbyBkZSAzMCVcIn1cclxuICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2UgcmlzZS0yXCIgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwicmVwZWF0KGF1dG8tZml0LCBtaW5tYXgoMjQwcHgsIDFmcikpXCIsIG1hcmdpbkJvdHRvbTogMTYgfX0+XHJcbiAgICAgICAgICAgIHtkYXRhLnNjZW5hcmlvcy5tYXAoKHNjZW5hcmlvKSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgdG9uZSA9IHNjZW5hcmlvVG9uZVtzY2VuYXJpby5uYW1lXSA/PyBcInZhcigtLWluaylcIjtcclxuICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWQgPT09IHNjZW5hcmlvLm5hbWU7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAga2V5PXtzY2VuYXJpby5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICByb2xlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgdGFiSW5kZXg9ezB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKHNjZW5hcmlvLm5hbWUpfVxyXG4gICAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIgfHwgZS5rZXkgPT09IFwiIFwiKSBzZXRTZWxlY3RlZChzY2VuYXJpby5uYW1lKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGlja2V0XCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAxOCxcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImdyaWRcIixcclxuICAgICAgICAgICAgICAgICAgICBnYXA6IDgsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dEFsaWduOiBcImxlZnRcIixcclxuICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogaXNTZWxlY3RlZCA/IGAxcHggc29saWQgJHt0b25lfWAgOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwidmFyKC0tYmctcmFpc2UpXCIsXHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJiYXNlbGluZVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjNyZW1cIiwgY29sb3I6IHRvbmUgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2NlbmFyaW8ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIG1hcmdlbSB7KHNjZW5hcmlvLm1hcmdpblJhdGUgKiAxMDApLnRvRml4ZWQoMSl9JVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9uby1udW0gZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuN3JlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtYXRCUkwoc2NlbmFyaW8udGFyZ2V0UmV2ZW51ZSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5wb250byBkZSBlcXVpbMOtYnJpbzogPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIj57Zm9ybWF0QlJMKHNjZW5hcmlvLmJyZWFrRXZlblJldmVudWUpfTwvc3Bhbj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+cG9yIGRpYSAoe2RhdGEuZGF5c0luTW9udGh9IGRpYXMpOiA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiPntmb3JtYXRCUkwoc2NlbmFyaW8uZGFpbHlUYXJnZXQpfTwvc3Bhbj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAge3NjZW5hcmlvLmVzdGltYXRlZFNhbGVzQ291bnQgIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4omIIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+e3NjZW5hcmlvLmVzdGltYXRlZFNhbGVzQ291bnR9PC9zcGFuPiB2ZW5kYXMgbm8gbcOqczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWluSGVpZ2h0OiA0MCB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt0YXJnZXRNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0YXJnZXRNdXRhdGlvbi5tdXRhdGUoc2NlbmFyaW8pO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBVc2FyIGNvbW8gbWV0YSBkbyBtw6pzXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7c2VsZWN0ZWRTY2VuYXJpbyAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0IHJpc2UgcmlzZS0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtaGVhZFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMnJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICBFc3RvcXVlIG5lY2Vzc8OhcmlvIOKAlCBjZW7DoXJpbyB7c2VsZWN0ZWRTY2VuYXJpby5uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjgycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIGJhc2VhZG8gbm8gbWl4IHJlYWwgZGUgdmVuZGFzIGRvIG3DqnNcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7c2VsZWN0ZWRTY2VuYXJpby5zdG9ja1BsYW4ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBrZXk9e2l0ZW0ucHJvZHVjdElkfT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtLnByb2R1Y3ROYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgeyhpdGVtLnJldmVudWVTaGFyZSAqIDEwMCkudG9GaXhlZCgxKX0lIGRhIHJlY2VpdGEgwrcgcHJlY2lzYSBkZXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+e2l0ZW0uZXN0aW1hdGVkVW5pdHN9PC9zcGFuPiB1biDCtyBlbSBlc3RvcXVle1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIj57aXRlbS5jdXJyZW50U3RvY2t9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibW9uby1udW0gZGlzcGxheVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEuMnJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY29sb3I6IGl0ZW0udW5pdHNUb0J1eSA+IDAgPyBcInZhcigtLWRhbmdlcilcIiA6IFwidmFyKC0tb2spXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnVuaXRzVG9CdXkgPiAwID8gYGNvbXByYXIgJHtpdGVtLnVuaXRzVG9CdXl9YCA6IFwib2tcIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkU2NlbmFyaW8uc3RvY2tQbGFuLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIFNlbSB2ZW5kYXMgY29tIGJhaXhhIGRlIGVzdG9xdWUgbmVzdGUgbcOqcyDigJQgbyBwbGFubyBkZSBjb21wcmEgYXBhcmVjZVxyXG4gICAgICAgICAgICAgICAgICBxdWFuZG8gaG91dmVyIGhpc3TDs3JpY28gZGUgbWl4IGRlIHZlbmRhcy5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9maW5hbmNlL1NjZW5hcmlvc1BhZ2UudHN4In0=