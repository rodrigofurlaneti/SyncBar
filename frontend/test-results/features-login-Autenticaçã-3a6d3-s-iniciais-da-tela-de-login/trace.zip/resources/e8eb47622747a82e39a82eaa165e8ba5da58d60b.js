import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/publicOrdering/PublicOrderPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import Swal from "/node_modules/.vite/deps/sweetalert2.js?v=ca0b4140";
import { addPublicOrderItem, getPublicMenu, getPublicBill, getPublicComandaBill } from "/src/features/publicOrdering/api.ts";
import { ComplementSelectorModal } from "/src/features/orders/ComplementSelectorModal.tsx";
import { PublicOrderModal } from "/src/features/publicOrdering/PublicOrderModal.tsx";
import { PublicOrderCard } from "/src/features/publicOrdering/PublicOrderCard.tsx";
import { ComandaReadingValidation, LinkComandaValidation, needsReadingValidation } from "/src/features/publicOrdering/ComandaReadingValidation.tsx";
import logoImg from "/src/image/logo.png?import";
import bgImg from "/src/image/screenbackground_auth.jpeg?import";
export function PublicOrderPage() {
  _s();
  const { token } = useParams();
  const [sentIds, setSentIds] = useState([]);
  const [error, setError] = useState(null);
  const [selectingItem, setSelectingItem] = useState(null);
  const [activeCategory, setActiveCategory] = useState("Todas");
  const [searchQuery, setSearchQuery] = useState("");
  const [quantities, setQuantities] = useState({});
  const [pendingOrder, setPendingOrder] = useState(null);
  const [destination, setDestination] = useState("mesa");
  const [commandNumber, setCommandNumber] = useState("");
  const [showMyOrders, setShowMyOrders] = useState(false);
  const [validatedComandaCodes, setValidatedComandaCodes] = useState(/* @__PURE__ */ new Set());
  const [linkedComandaCode, setLinkedComandaCode] = useState(null);
  const [orderValidationStep, setOrderValidationStep] = useState("select");
  const [windowWidth, setWindowWidth] = useState(typeof window !== "undefined" ? window.innerWidth : 1200);
  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  const isMobile = windowWidth < 640;
  const isTvOrLarge = windowWidth > 1200;
  const menuQuery = useQuery({
    queryKey: ["public-menu", token],
    queryFn: () => getPublicMenu(token),
    enabled: !!token,
    retry: false
  });
  const addMutation = useMutation({
    mutationFn: ({ productId, complements, quantity = 1, comandaCode }) => {
      return addPublicOrderItem(token, productId, quantity, null, complements, comandaCode);
    },
    onSuccess: (_result, { productId }) => {
      setError(null);
      setSentIds((current) => [...current, productId]);
      setSelectingItem(null);
      setPendingOrder(null);
      setCommandNumber("");
      setOrderValidationStep("select");
      setQuantities((prev) => ({ ...prev, [productId]: 1 }));
      Swal.fire({
        title: "Sucesso!",
        text: "Pedido enviado com sucesso! Só aguardar.",
        icon: "success",
        background: "#1e1e24",
        color: "#ffffff",
        confirmButtonColor: "#f59e0b",
        confirmButtonText: "OK"
      });
    },
    onError: (e) => {
      setError(e instanceof Error ? e.message : "Falha ao enviar o pedido.");
      setOrderValidationStep((step) => step === "submitting" ? "linkComanda" : step);
    }
  });
  const getQty = (productId) => quantities[productId] || 1;
  const setQty = (productId, newQty) => {
    setQuantities((prev) => ({ ...prev, [productId]: Math.max(1, newQty) }));
  };
  const handlePickItem = (item) => {
    const currentQty = getQty(item.id);
    if (item.complementGroups && item.complementGroups.length > 0) {
      setSelectingItem(item);
      return;
    }
    submitOrGateDirectOrder({ productId: item.id, quantity: currentQty });
  };
  const { categoryList, groupedItems, filteredItems } = useMemo(() => {
    if (!menuQuery.data) return { categoryList: [], groupedItems: {}, filteredItems: [] };
    const items = menuQuery.data.items;
    const uniqueCategories = Array.from(new Set(items.map((i) => i.categoryName || "Geral")));
    const cats = ["Todas", ...uniqueCategories];
    let resultItems = items;
    if (activeCategory !== "Todas") {
      resultItems = resultItems.filter((i) => (i.categoryName || "Geral") === activeCategory);
    }
    if (searchQuery) {
      resultItems = resultItems.filter((i) => i.name.toLowerCase().includes(searchQuery.toLowerCase()));
    }
    const grouped = {};
    resultItems.forEach((item) => {
      const catName = item.categoryName || "Geral";
      if (!grouped[catName]) grouped[catName] = [];
      grouped[catName].push(item);
    });
    return { categoryList: cats, groupedItems: grouped, filteredItems: resultItems };
  }, [menuQuery.data, activeCategory, searchQuery]);
  if (!token) return null;
  if (menuQuery.isLoading)
    return /* @__PURE__ */ jsxDEV("main", { style: { padding: 24, textAlign: "center", color: "#a8a8b3", backgroundColor: "#121214", minHeight: "100vh" }, children: "Carregando cardápio…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
      lineNumber: 151,
      columnNumber: 10
    }, this);
  if (menuQuery.isError)
    return /* @__PURE__ */ jsxDEV("main", { style: { padding: 24, textAlign: "center", backgroundColor: "#121214", minHeight: "100vh" }, children: /* @__PURE__ */ jsxDEV("p", { style: { color: "#ef4444" }, children: "Não foi possível carregar o cardápio." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
      lineNumber: 153,
      columnNumber: 109
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
      lineNumber: 153,
      columnNumber: 10
    }, this);
  const menu = menuQuery.data;
  const readingValidation = {
    isCameraInputEnabled: menu.isCameraInputEnabled,
    isBarcodeEnabled: menu.isBarcodeEnabled,
    isQrCodeEnabled: menu.isQrCodeEnabled
  };
  const gridColumns = isMobile ? "1fr" : isTvOrLarge ? "repeat(auto-fill, minmax(380px, 1fr))" : "repeat(auto-fill, minmax(300px, 1fr))";
  const submitPendingOrder = () => {
    if (!pendingOrder) return;
    addMutation.mutate({
      productId: pendingOrder.productId,
      quantity: pendingOrder.quantity,
      complements: pendingOrder.complements,
      // Vai pra conta da comanda (não da mesa) — a mesa fica registrada no pedido
      // pra cozinha/garçom saberem onde entregar. Ver AddPublicOrderItemCommand.
      comandaCode: destination === "comanda" ? commandNumber : void 0
    });
  };
  const handleConfirmPendingOrder = () => {
    if (destination === "comanda" && needsReadingValidation(readingValidation) && !validatedComandaCodes.has(commandNumber)) {
      setOrderValidationStep("validateComanda");
      return;
    }
    submitPendingOrder();
  };
  const submitOrGateDirectOrder = (order) => {
    if (menu.isQrViewEnabled) {
      setPendingOrder(order);
      setDestination("mesa");
      setOrderValidationStep("select");
      return;
    }
    if (readingValidation.isCameraInputEnabled) {
      if (linkedComandaCode) {
        addMutation.mutate({ ...order, comandaCode: linkedComandaCode });
        return;
      }
      setPendingOrder(order);
      setOrderValidationStep("linkComanda");
      return;
    }
    addMutation.mutate(order);
  };
  return /* @__PURE__ */ jsxDEV("main", { style: { backgroundColor: "#121214", minHeight: "100vh", paddingBottom: 100, color: "#e1e1e6", fontFamily: "sans-serif", position: "relative", fontSize: isTvOrLarge ? "1.1rem" : "1rem" }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: isMobile ? "8px 12px" : "12px 24px", backgroundImage: `linear-gradient(rgba(18, 18, 20, 0.85), rgba(18, 18, 20, 0.95)), url(${bgImg})`, backgroundSize: "cover", backgroundPosition: "center", borderBottom: "1px solid #29292e", height: isTvOrLarge ? "100px" : "80px", boxSizing: "border-box" }, children: [
      /* @__PURE__ */ jsxDEV("img", { src: logoImg, alt: "Logotipo SyncBar", style: { height: isTvOrLarge ? 70 : 50, objectFit: "contain", position: "relative", zIndex: 2 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 216,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "right", position: "relative", zIndex: 2 }, children: /* @__PURE__ */ jsxDEV("div", { style: { color: "#ffffff", fontSize: isTvOrLarge ? "1.5rem" : "1.15rem", fontWeight: "600" }, children: [
        "Mesa ",
        /* @__PURE__ */ jsxDEV("span", { style: { color: "#f59e0b" }, children: menu.tableNumber }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
          lineNumber: 219,
          columnNumber: 30
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 218,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 217,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
      lineNumber: 215,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { padding: isMobile ? "0 12px" : "0 24px", maxWidth: isTvOrLarge ? 1400 : 900, margin: "16px auto 0" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", overflowX: "auto", gap: isTvOrLarge ? 32 : 24, paddingBottom: 6, borderBottom: "1px solid #323238" }, children: categoryList.map((cat) => {
        const isActive = activeCategory === cat;
        return /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setActiveCategory(cat),
            style: { background: "none", border: "none", padding: "0 0 10px 0", whiteSpace: "nowrap", fontWeight: isActive ? "bold" : "normal", color: isActive ? "#f59e0b" : "#a8a8b3", borderBottom: isActive ? "2px solid #f59e0b" : "2px solid transparent", cursor: "pointer", fontSize: isTvOrLarge ? "1.2rem" : "0.95rem" },
            children: cat
          },
          cat,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
            lineNumber: 229,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 225,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 16, position: "relative" }, children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Pesquisar um produto...",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            style: { width: "100%", padding: isTvOrLarge ? "18px 20px" : "14px 16px", borderRadius: 8, border: "1px solid #323238", backgroundColor: "#202024", color: "#e1e1e6", outline: "none", fontSize: isTvOrLarge ? "1.1rem" : "0.95rem", boxSizing: "border-box" }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
            lineNumber: 240,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { style: { position: "absolute", right: 16, top: isTvOrLarge ? 18 : 14, color: "#a8a8b3" }, children: "🔍" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
          lineNumber: 247,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 239,
        columnNumber: 17
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { style: { marginTop: 16, textAlign: "center", color: "#ef4444" }, children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 249,
        columnNumber: 27
      }, this),
      activeCategory === "Todas" && !searchQuery ? Object.entries(groupedItems).map(
        ([categoryName, products]) => /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 32 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 16 }, children: /* @__PURE__ */ jsxDEV("h2", { style: { fontSize: isTvOrLarge ? "1.3rem" : "1.05rem", textTransform: "uppercase", letterSpacing: 1, color: "#fff", margin: 0, paddingBottom: 6, borderBottom: "2px solid #f59e0b", display: "inline-block" }, children: categoryName }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
            lineNumber: 254,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
            lineNumber: 253,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 16, gridTemplateColumns: gridColumns }, children: products.map(
            (item) => /* @__PURE__ */ jsxDEV(
              PublicOrderCard,
              {
                item,
                quantity: getQty(item.id),
                isJustSent: sentIds.includes(item.id),
                isPending: addMutation.isPending,
                onQuantityChange: (newQty) => setQty(item.id, newQty),
                onAddItem: () => handlePickItem(item)
              },
              item.id,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
                lineNumber: 258,
                columnNumber: 13
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
            lineNumber: 256,
            columnNumber: 29
          }, this)
        ] }, categoryName, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
          lineNumber: 252,
          columnNumber: 9
        }, this)
      ) : /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 24, display: "grid", gap: 16, gridTemplateColumns: gridColumns }, children: filteredItems.map(
        (item) => /* @__PURE__ */ jsxDEV(
          PublicOrderCard,
          {
            item,
            quantity: getQty(item.id),
            isJustSent: sentIds.includes(item.id),
            isPending: addMutation.isPending,
            onQuantityChange: (newQty) => setQty(item.id, newQty),
            onAddItem: () => handlePickItem(item)
          },
          item.id,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
            lineNumber: 274,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 272,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
      lineNumber: 223,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => setShowMyOrders(true),
        style: { position: "fixed", bottom: isTvOrLarge ? 36 : 24, right: isTvOrLarge ? 36 : 24, zIndex: 50, backgroundColor: "#f59e0b", color: "#121214", border: "none", borderRadius: "50%", width: isTvOrLarge ? 80 : 64, height: isTvOrLarge ? 80 : 64, boxShadow: "0 4px 15px rgba(245, 158, 11, 0.4)", fontSize: isTvOrLarge ? "2.2rem" : "1.8rem", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" },
        "aria-label": "Ver minha conta",
        children: "🧾"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 288,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      PublicOrderModal,
      {
        isOpen: showMyOrders,
        onClose: () => setShowMyOrders(false),
        tableNumber: menu.tableNumber.toString(),
        token,
        isQrViewEnabled: menu.isQrViewEnabled,
        linkedComandaCode,
        readingValidation,
        isComandaValidated: (code) => validatedComandaCodes.has(code),
        onComandaValidated: (code) => setValidatedComandaCodes((prev) => new Set(prev).add(code)),
        onFetchMesaBill: () => getPublicBill(token),
        onFetchComandaBill: (code) => getPublicComandaBill(token, code)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 296,
        columnNumber: 13
      },
      this
    ),
    selectingItem && /* @__PURE__ */ jsxDEV(
      ComplementSelectorModal,
      {
        productName: selectingItem.name,
        groups: selectingItem.complementGroups,
        onCancel: () => setSelectingItem(null),
        submitting: addMutation.isPending,
        confirmLabel: "ADICIONAR",
        onConfirm: (complements) => {
          const productId = selectingItem.id;
          setSelectingItem(null);
          submitOrGateDirectOrder({ productId, quantity: 1, complements });
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 311,
        columnNumber: 7
      },
      this
    ),
    pendingOrder && /* @__PURE__ */ jsxDEV("div", { style: { position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.8)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }, children: /* @__PURE__ */ jsxDEV("div", { style: { backgroundColor: "#1e1e24", padding: 24, borderRadius: 12, width: "100%", maxWidth: 400, border: "1px solid #323238" }, children: orderValidationStep === "validateComanda" ? /* @__PURE__ */ jsxDEV(
      ComandaReadingValidation,
      {
        token,
        comandaCode: commandNumber,
        requirement: readingValidation,
        onValidated: () => {
          setValidatedComandaCodes((prev) => new Set(prev).add(commandNumber));
          setOrderValidationStep("select");
          submitPendingOrder();
        },
        onCancel: () => setOrderValidationStep("select")
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 329,
        columnNumber: 11
      },
      this
    ) : orderValidationStep === "linkComanda" ? /* @__PURE__ */ jsxDEV(
      LinkComandaValidation,
      {
        token,
        requirement: readingValidation,
        onLinked: (code) => {
          setLinkedComandaCode(code);
          if (pendingOrder) {
            setOrderValidationStep("submitting");
            addMutation.mutate({ ...pendingOrder, comandaCode: code });
          } else {
            setOrderValidationStep("select");
          }
        },
        onCancel: () => {
          setPendingOrder(null);
          setOrderValidationStep("select");
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 341,
        columnNumber: 11
      },
      this
    ) : orderValidationStep === "submitting" ? /* @__PURE__ */ jsxDEV("p", { style: { textAlign: "center", color: "#a8a8b3", margin: "24px 0" }, children: "Enviando pedido…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
      lineNumber: 370,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("h3", { style: { marginTop: 0, marginBottom: 24, color: "#fff", fontSize: "1.2rem", textAlign: "center" }, children: "Onde deseja anotar este pedido?" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 373,
        columnNumber: 33
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12, marginBottom: destination === "comanda" ? 16 : 24 }, children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setDestination("mesa"), style: { flex: 1, padding: "14px", borderRadius: 8, border: destination === "mesa" ? "2px solid #f59e0b" : "1px solid #323238", backgroundColor: destination === "mesa" ? "rgba(245, 158, 11, 0.1)" : "transparent", color: destination === "mesa" ? "#f59e0b" : "#a8a8b3", fontWeight: "bold", cursor: "pointer" }, children: "Na Mesa" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
          lineNumber: 375,
          columnNumber: 37
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setDestination("comanda"), style: { flex: 1, padding: "14px", borderRadius: 8, border: destination === "comanda" ? "2px solid #f59e0b" : "1px solid #323238", backgroundColor: destination === "comanda" ? "rgba(245, 158, 11, 0.1)" : "transparent", color: destination === "comanda" ? "#f59e0b" : "#a8a8b3", fontWeight: "bold", cursor: "pointer" }, children: "Na Comanda" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
          lineNumber: 376,
          columnNumber: 37
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 374,
        columnNumber: 33
      }, this),
      destination === "comanda" && /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 24 }, children: [
        /* @__PURE__ */ jsxDEV("label", { style: { display: "block", color: "#a8a8b3", marginBottom: 8, fontSize: "0.9rem" }, children: "Número da Comanda" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
          lineNumber: 380,
          columnNumber: 41
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "text", value: commandNumber, onChange: (e) => setCommandNumber(e.target.value), placeholder: "Ex: 001", autoFocus: true, style: { width: "100%", padding: "14px 16px", borderRadius: 8, border: "1px solid #323238", backgroundColor: "#121214", color: "#fff", fontSize: "1rem", outline: "none", boxSizing: "border-box" } }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
          lineNumber: 381,
          columnNumber: 41
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 379,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12 }, children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => {
          setPendingOrder(null);
          setCommandNumber("");
          setOrderValidationStep("select");
        }, style: { flex: 1, padding: "14px", borderRadius: 8, border: "none", backgroundColor: "#323238", color: "#fff", fontWeight: "bold", cursor: "pointer" }, children: "Cancelar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
          lineNumber: 385,
          columnNumber: 37
        }, this),
        /* @__PURE__ */ jsxDEV("button", { disabled: destination === "comanda" && !commandNumber || addMutation.isPending, onClick: handleConfirmPendingOrder, style: { flex: 1, padding: "14px", borderRadius: 8, border: "none", backgroundColor: "#f59e0b", color: "#121214", fontWeight: "bold", cursor: "pointer" }, children: addMutation.isPending ? "Enviando..." : "Confirmar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
          lineNumber: 386,
          columnNumber: 37
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
        lineNumber: 384,
        columnNumber: 33
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
      lineNumber: 372,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
      lineNumber: 327,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
      lineNumber: 326,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx",
    lineNumber: 213,
    columnNumber: 5
  }, this);
}
_s(PublicOrderPage, "59hR5IJ6G/M64JbLLCme8GvEPHs=", false, function() {
  return [useParams, useQuery, useMutation];
});
_c = PublicOrderPage;
var _c;
$RefreshReg$(_c, "PublicOrderPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUllLFNBNk5hLFVBN05iOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5JZixTQUFTQSxVQUFVQyxTQUFTQyxpQkFBaUI7QUFDN0MsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGFBQWFDLGdCQUFnQjtBQUN0QyxPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLG9CQUFvQkMsZUFBZUMsZUFBZUMsNEJBQTRCO0FBRXZGLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDBCQUEwQkMsdUJBQXVCQyw4QkFBOEI7QUFFeEYsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBUVgsZ0JBQVNDLGtCQUFrQjtBQUFBQyxLQUFBO0FBQzlCLFFBQU0sRUFBRUMsTUFBTSxJQUFJbEIsVUFBNkI7QUFDL0MsUUFBTSxDQUFDbUIsU0FBU0MsVUFBVSxJQUFJdkIsU0FBbUIsRUFBRTtBQUNuRCxRQUFNLENBQUN3QixPQUFPQyxRQUFRLElBQUl6QixTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQzBCLGVBQWVDLGdCQUFnQixJQUFJM0IsU0FBa0MsSUFBSTtBQUNoRixRQUFNLENBQUM0QixnQkFBZ0JDLGlCQUFpQixJQUFJN0IsU0FBaUIsT0FBTztBQUNwRSxRQUFNLENBQUM4QixhQUFhQyxjQUFjLElBQUkvQixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDZ0MsWUFBWUMsYUFBYSxJQUFJakMsU0FBaUMsQ0FBQyxDQUFDO0FBQ3ZFLFFBQU0sQ0FBQ2tDLGNBQWNDLGVBQWUsSUFBSW5DLFNBQThCLElBQUk7QUFDMUUsUUFBTSxDQUFDb0MsYUFBYUMsY0FBYyxJQUFJckMsU0FBNkIsTUFBTTtBQUN6RSxRQUFNLENBQUNzQyxlQUFlQyxnQkFBZ0IsSUFBSXZDLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUN3QyxjQUFjQyxlQUFlLElBQUl6QyxTQUFTLEtBQUs7QUFJdEQsUUFBTSxDQUFDMEMsdUJBQXVCQyx3QkFBd0IsSUFBSTNDLFNBQXNCLG9CQUFJNEMsSUFBSSxDQUFDO0FBTXpGLFFBQU0sQ0FBQ0MsbUJBQW1CQyxvQkFBb0IsSUFBSTlDLFNBQXdCLElBQUk7QUFDOUUsUUFBTSxDQUFDK0MscUJBQXFCQyxzQkFBc0IsSUFBSWhELFNBQXNFLFFBQVE7QUFFcEksUUFBTSxDQUFDaUQsYUFBYUMsY0FBYyxJQUFJbEQsU0FBUyxPQUFPbUQsV0FBVyxjQUFjQSxPQUFPQyxhQUFhLElBQUk7QUFDdkdsRCxZQUFVLE1BQU07QUFDWixVQUFNbUQsZUFBZUEsTUFBTUgsZUFBZUMsT0FBT0MsVUFBVTtBQUMzREQsV0FBT0csaUJBQWlCLFVBQVVELFlBQVk7QUFDOUMsV0FBTyxNQUFNRixPQUFPSSxvQkFBb0IsVUFBVUYsWUFBWTtBQUFBLEVBQ2xFLEdBQUcsRUFBRTtBQUVMLFFBQU1HLFdBQVdQLGNBQWM7QUFDL0IsUUFBTVEsY0FBY1IsY0FBYztBQUVsQyxRQUFNUyxZQUFZckQsU0FBUztBQUFBLElBQ3ZCc0QsVUFBVSxDQUFDLGVBQWV0QyxLQUFLO0FBQUEsSUFDL0J1QyxTQUFTQSxNQUFNcEQsY0FBY2EsS0FBTTtBQUFBLElBQ25Dd0MsU0FBUyxDQUFDLENBQUN4QztBQUFBQSxJQUNYeUMsT0FBTztBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1DLGNBQWMzRCxZQUFZO0FBQUEsSUFDNUI0RCxZQUFZQSxDQUFDLEVBQUVDLFdBQVdDLGFBQWFDLFdBQVcsR0FBR0MsWUFBMEgsTUFBTTtBQUNqTCxhQUFPN0QsbUJBQW1CYyxPQUFRNEMsV0FBV0UsVUFBVSxNQUFNRCxhQUFhRSxXQUFXO0FBQUEsSUFDekY7QUFBQSxJQUNBQyxXQUFXQSxDQUFDQyxTQUFTLEVBQUVMLFVBQVUsTUFBTTtBQUNuQ3hDLGVBQVMsSUFBSTtBQUNiRixpQkFBVyxDQUFDZ0QsWUFBWSxDQUFDLEdBQUdBLFNBQVNOLFNBQVMsQ0FBQztBQUMvQ3RDLHVCQUFpQixJQUFJO0FBQ3JCUSxzQkFBZ0IsSUFBSTtBQUNwQkksdUJBQWlCLEVBQUU7QUFDbkJTLDZCQUF1QixRQUFRO0FBQy9CZixvQkFBYyxDQUFBdUMsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ1AsU0FBUyxHQUFHLEVBQUUsRUFBRTtBQUNuRDNELFdBQUttRSxLQUFLO0FBQUEsUUFDTkMsT0FBTztBQUFBLFFBQ1BDLE1BQU07QUFBQSxRQUNOQyxNQUFNO0FBQUEsUUFDTkMsWUFBWTtBQUFBLFFBQ1pDLE9BQU87QUFBQSxRQUNQQyxvQkFBb0I7QUFBQSxRQUNwQkMsbUJBQW1CO0FBQUEsTUFDdkIsQ0FBQztBQUFBLElBQ0w7QUFBQSxJQUNBQyxTQUFTQSxDQUFDQyxNQUFNO0FBQ1p6RCxlQUFTeUQsYUFBYUMsUUFBUUQsRUFBRUUsVUFBVSwyQkFBMkI7QUFNckVwQyw2QkFBdUIsQ0FBQ3FDLFNBQVVBLFNBQVMsZUFBZSxnQkFBZ0JBLElBQUs7QUFBQSxJQUNuRjtBQUFBLEVBQ0osQ0FBQztBQUVELFFBQU1DLFNBQVNBLENBQUNyQixjQUFzQmpDLFdBQVdpQyxTQUFTLEtBQUs7QUFDL0QsUUFBTXNCLFNBQVNBLENBQUN0QixXQUFtQnVCLFdBQW1CO0FBQ2xEdkQsa0JBQWMsQ0FBQXVDLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNQLFNBQVMsR0FBR3dCLEtBQUtDLElBQUksR0FBR0YsTUFBTSxFQUFFLEVBQUU7QUFBQSxFQUN6RTtBQUVBLFFBQU1HLGlCQUFpQkEsQ0FBQ0MsU0FBMkI7QUFDL0MsVUFBTUMsYUFBYVAsT0FBT00sS0FBS0UsRUFBRTtBQUNqQyxRQUFJRixLQUFLRyxvQkFBb0JILEtBQUtHLGlCQUFpQkMsU0FBUyxHQUFHO0FBQzNEckUsdUJBQWlCaUUsSUFBSTtBQUNyQjtBQUFBLElBQ0o7QUFDQUssNEJBQXdCLEVBQUVoQyxXQUFXMkIsS0FBS0UsSUFBSTNCLFVBQVUwQixXQUFXLENBQUM7QUFBQSxFQUN4RTtBQUVBLFFBQU0sRUFBRUssY0FBY0MsY0FBY0MsY0FBYyxJQUFJbkcsUUFBUSxNQUFNO0FBQ2hFLFFBQUksQ0FBQ3lELFVBQVUyQyxLQUFNLFFBQU8sRUFBRUgsY0FBYyxJQUFJQyxjQUFjLENBQUMsR0FBR0MsZUFBZSxHQUFHO0FBQ3BGLFVBQU1FLFFBQVE1QyxVQUFVMkMsS0FBS0M7QUFDN0IsVUFBTUMsbUJBQW1CQyxNQUFNQyxLQUFLLElBQUk3RCxJQUFJMEQsTUFBTUksSUFBSSxDQUFDQyxNQUFXQSxFQUFFQyxnQkFBZ0IsT0FBTyxDQUFDLENBQUM7QUFDN0YsVUFBTUMsT0FBTyxDQUFDLFNBQVMsR0FBR04sZ0JBQWdCO0FBQzFDLFFBQUlPLGNBQWNSO0FBQ2xCLFFBQUkxRSxtQkFBbUIsU0FBUztBQUM1QmtGLG9CQUFjQSxZQUFZQyxPQUFPLENBQUNKLE9BQVlBLEVBQUVDLGdCQUFnQixhQUFhaEYsY0FBYztBQUFBLElBQy9GO0FBQ0EsUUFBSUUsYUFBYTtBQUNiZ0Ysb0JBQWNBLFlBQVlDLE9BQU8sQ0FBQUosTUFBS0EsRUFBRUssS0FBS0MsWUFBWSxFQUFFQyxTQUFTcEYsWUFBWW1GLFlBQVksQ0FBQyxDQUFDO0FBQUEsSUFDbEc7QUFDQSxVQUFNRSxVQUE4QyxDQUFDO0FBQ3JETCxnQkFBWU0sUUFBUSxDQUFDeEIsU0FBYztBQUMvQixZQUFNeUIsVUFBVXpCLEtBQUtnQixnQkFBZ0I7QUFDckMsVUFBSSxDQUFDTyxRQUFRRSxPQUFPLEVBQUdGLFNBQVFFLE9BQU8sSUFBSTtBQUMxQ0YsY0FBUUUsT0FBTyxFQUFFQyxLQUFLMUIsSUFBSTtBQUFBLElBQzlCLENBQUM7QUFDRCxXQUFPLEVBQUVNLGNBQWNXLE1BQU1WLGNBQWNnQixTQUFTZixlQUFlVSxZQUFZO0FBQUEsRUFDbkYsR0FBRyxDQUFDcEQsVUFBVTJDLE1BQU16RSxnQkFBZ0JFLFdBQVcsQ0FBQztBQUVoRCxNQUFJLENBQUNULE1BQU8sUUFBTztBQUNuQixNQUFJcUMsVUFBVTZEO0FBQ1YsV0FBTyx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsU0FBUyxJQUFJQyxXQUFXLFVBQVUzQyxPQUFPLFdBQVc0QyxpQkFBaUIsV0FBV0MsV0FBVyxRQUFRLEdBQUcsb0NBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUk7QUFDcEosTUFBSWpFLFVBQVVrRTtBQUNWLFdBQU8sdUJBQUMsVUFBSyxPQUFPLEVBQUVKLFNBQVMsSUFBSUMsV0FBVyxVQUFVQyxpQkFBaUIsV0FBV0MsV0FBVyxRQUFRLEdBQUcsaUNBQUMsT0FBRSxPQUFPLEVBQUU3QyxPQUFPLFVBQVUsR0FBRyxxREFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRSxLQUF4SztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRLO0FBQ3ZMLFFBQU0rQyxPQUFPbkUsVUFBVTJDO0FBQ3ZCLFFBQU15QixvQkFBb0I7QUFBQSxJQUN0QkMsc0JBQXNCRixLQUFLRTtBQUFBQSxJQUMzQkMsa0JBQWtCSCxLQUFLRztBQUFBQSxJQUN2QkMsaUJBQWlCSixLQUFLSTtBQUFBQSxFQUMxQjtBQUdBLFFBQU1DLGNBQWMxRSxXQUNkLFFBQ0FDLGNBQ0ksMENBQ0E7QUFFVixRQUFNMEUscUJBQXFCQSxNQUFNO0FBQzdCLFFBQUksQ0FBQ2pHLGFBQWM7QUFDbkI2QixnQkFBWXFFLE9BQU87QUFBQSxNQUNmbkUsV0FBVy9CLGFBQWErQjtBQUFBQSxNQUN4QkUsVUFBVWpDLGFBQWFpQztBQUFBQSxNQUN2QkQsYUFBYWhDLGFBQWFnQztBQUFBQTtBQUFBQTtBQUFBQSxNQUcxQkUsYUFBYWhDLGdCQUFnQixZQUFZRSxnQkFBZ0IrRjtBQUFBQSxJQUM3RCxDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU1DLDRCQUE0QkEsTUFBTTtBQUNwQyxRQUFJbEcsZ0JBQWdCLGFBQWFwQix1QkFBdUI4RyxpQkFBaUIsS0FBSyxDQUFDcEYsc0JBQXNCNkYsSUFBSWpHLGFBQWEsR0FBRztBQUNySFUsNkJBQXVCLGlCQUFpQjtBQUN4QztBQUFBLElBQ0o7QUFDQW1GLHVCQUFtQjtBQUFBLEVBQ3ZCO0FBT0EsUUFBTWxDLDBCQUEwQkEsQ0FBQ3VDLFVBQXdCO0FBQ3JELFFBQUlYLEtBQUtZLGlCQUFpQjtBQUN0QnRHLHNCQUFnQnFHLEtBQUs7QUFDckJuRyxxQkFBZSxNQUFNO0FBQ3JCVyw2QkFBdUIsUUFBUTtBQUMvQjtBQUFBLElBQ0o7QUFDQSxRQUFJOEUsa0JBQWtCQyxzQkFBc0I7QUFDeEMsVUFBSWxGLG1CQUFtQjtBQUNuQmtCLG9CQUFZcUUsT0FBTyxFQUFFLEdBQUdJLE9BQU9wRSxhQUFhdkIsa0JBQWtCLENBQUM7QUFDL0Q7QUFBQSxNQUNKO0FBQ0FWLHNCQUFnQnFHLEtBQUs7QUFDckJ4Riw2QkFBdUIsYUFBYTtBQUNwQztBQUFBLElBQ0o7QUFDQWUsZ0JBQVlxRSxPQUFPSSxLQUFLO0FBQUEsRUFDNUI7QUFFQSxTQUNJLHVCQUFDLFVBQUssT0FBTyxFQUFFZCxpQkFBaUIsV0FBV0MsV0FBVyxTQUFTZSxlQUFlLEtBQUs1RCxPQUFPLFdBQVc2RCxZQUFZLGNBQWNDLFVBQVUsWUFBWUMsVUFBVXBGLGNBQWMsV0FBVyxPQUFPLEdBRTNMO0FBQUEsMkJBQUMsU0FBSSxPQUFPLEVBQUVxRixTQUFTLFFBQVFDLGdCQUFnQixpQkFBaUJDLFlBQVksVUFBVXhCLFNBQVNoRSxXQUFXLGFBQWEsYUFBYXlGLGlCQUFpQix3RUFBd0UvSCxLQUFLLEtBQUtnSSxnQkFBZ0IsU0FBU0Msb0JBQW9CLFVBQVVDLGNBQWMscUJBQXFCQyxRQUFRNUYsY0FBYyxVQUFVLFFBQVE2RixXQUFXLGFBQWEsR0FDN1g7QUFBQSw2QkFBQyxTQUFJLEtBQUtySSxTQUFTLEtBQUksb0JBQW1CLE9BQU8sRUFBRW9JLFFBQVE1RixjQUFjLEtBQUssSUFBSThGLFdBQVcsV0FBV1gsVUFBVSxZQUFZWSxRQUFRLEVBQUUsS0FBeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwSTtBQUFBLE1BQzFJLHVCQUFDLFNBQUksT0FBTyxFQUFFL0IsV0FBVyxTQUFTbUIsVUFBVSxZQUFZWSxRQUFRLEVBQUUsR0FDOUQsaUNBQUMsU0FBSSxPQUFPLEVBQUUxRSxPQUFPLFdBQVcrRCxVQUFVcEYsY0FBYyxXQUFXLFdBQVdnRyxZQUFZLE1BQU0sR0FBRztBQUFBO0FBQUEsUUFDMUYsdUJBQUMsVUFBSyxPQUFPLEVBQUUzRSxPQUFPLFVBQVUsR0FBSStDLGVBQUs2QixlQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsV0FEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFbEMsU0FBU2hFLFdBQVcsV0FBVyxVQUFVbUcsVUFBVWxHLGNBQWMsT0FBTyxLQUFLbUcsUUFBUSxjQUFjLEdBRTdHO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVkLFNBQVMsUUFBUWUsV0FBVyxRQUFRQyxLQUFLckcsY0FBYyxLQUFLLElBQUlpRixlQUFlLEdBQUdVLGNBQWMsb0JBQW9CLEdBQzdIbEQsdUJBQWFRLElBQUksQ0FBQ3FELFFBQWdCO0FBQy9CLGNBQU1DLFdBQVdwSSxtQkFBbUJtSTtBQUNwQyxlQUNJO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFRyxTQUFTLE1BQU1sSSxrQkFBa0JrSSxHQUFHO0FBQUEsWUFDcEMsT0FBTyxFQUFFbEYsWUFBWSxRQUFRb0YsUUFBUSxRQUFRekMsU0FBUyxjQUFjMEMsWUFBWSxVQUFVVCxZQUFZTyxXQUFXLFNBQVMsVUFBVWxGLE9BQU9rRixXQUFXLFlBQVksV0FBV1osY0FBY1ksV0FBVyxzQkFBc0IseUJBQXlCRyxRQUFRLFdBQVd0QixVQUFVcEYsY0FBYyxXQUFXLFVBQVU7QUFBQSxZQUVwVHNHO0FBQUFBO0FBQUFBLFVBSklBO0FBQUFBLFVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsTUFFUixDQUFDLEtBWkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUssV0FBVyxJQUFJeEIsVUFBVSxXQUFXLEdBQzlDO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLE9BQU85RztBQUFBQSxZQUNQLFVBQVUsQ0FBQ29ELE1BQU1uRCxlQUFlbUQsRUFBRW1GLE9BQU9DLEtBQUs7QUFBQSxZQUM5QyxPQUFPLEVBQUVDLE9BQU8sUUFBUS9DLFNBQVMvRCxjQUFjLGNBQWMsYUFBYStHLGNBQWMsR0FBR1AsUUFBUSxxQkFBcUJ2QyxpQkFBaUIsV0FBVzVDLE9BQU8sV0FBVzJGLFNBQVMsUUFBUTVCLFVBQVVwRixjQUFjLFdBQVcsV0FBVzZGLFdBQVcsYUFBYTtBQUFBO0FBQUEsVUFMalE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS21RO0FBQUEsUUFFblEsdUJBQUMsVUFBSyxPQUFPLEVBQUVWLFVBQVUsWUFBWThCLE9BQU8sSUFBSUMsS0FBS2xILGNBQWMsS0FBSyxJQUFJcUIsT0FBTyxVQUFVLEdBQUcsa0JBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0c7QUFBQSxXQVJ0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNDdEQsU0FBUyx1QkFBQyxPQUFFLE9BQU8sRUFBRTRJLFdBQVcsSUFBSTNDLFdBQVcsVUFBVTNDLE9BQU8sVUFBVSxHQUFJdEQsbUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkU7QUFBQSxNQUNwRkksbUJBQW1CLFdBQVcsQ0FBQ0UsY0FDNUI4SSxPQUFPQyxRQUFRMUUsWUFBWSxFQUFFTztBQUFBQSxRQUFJLENBQUMsQ0FBQ0UsY0FBY2tFLFFBQVEsTUFDckQsdUJBQUMsU0FBdUIsT0FBTyxFQUFFVixXQUFXLEdBQUcsR0FDM0M7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRVcsY0FBYyxHQUFHLEdBQzNCLGlDQUFDLFFBQUcsT0FBTyxFQUFFbEMsVUFBVXBGLGNBQWMsV0FBVyxXQUFXdUgsZUFBZSxhQUFhQyxlQUFlLEdBQUduRyxPQUFPLFFBQVE4RSxRQUFRLEdBQUdsQixlQUFlLEdBQUdVLGNBQWMscUJBQXFCTixTQUFTLGVBQWUsR0FBSWxDLDBCQUFwTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpTyxLQURyTztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWtDLFNBQVMsUUFBUWdCLEtBQUssSUFBSW9CLHFCQUFxQmhELFlBQVksR0FDcEU0QyxtQkFBU3BFO0FBQUFBLFlBQUksQ0FBQ2QsU0FDWDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVHO0FBQUEsZ0JBQ0EsVUFBVU4sT0FBT00sS0FBS0UsRUFBRTtBQUFBLGdCQUN4QixZQUFZeEUsUUFBUTRGLFNBQVN0QixLQUFLRSxFQUFFO0FBQUEsZ0JBQ3BDLFdBQVcvQixZQUFZb0g7QUFBQUEsZ0JBQ3ZCLGtCQUFrQixDQUFDM0YsV0FBV0QsT0FBT0ssS0FBS0UsSUFBSU4sTUFBTTtBQUFBLGdCQUNwRCxXQUFXLE1BQU1HLGVBQWVDLElBQUk7QUFBQTtBQUFBLGNBTi9CQSxLQUFLRTtBQUFBQSxjQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPMEM7QUFBQSxVQUU3QyxLQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQWhCTWMsY0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsTUFDSCxJQUVELHVCQUFDLFNBQUksT0FBTyxFQUFFd0QsV0FBVyxJQUFJdEIsU0FBUyxRQUFRZ0IsS0FBSyxJQUFJb0IscUJBQXFCaEQsWUFBWSxHQUNuRjlCLHdCQUFjTTtBQUFBQSxRQUFJLENBQUNkLFNBQ2hCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFRztBQUFBLFlBQ0EsVUFBVU4sT0FBT00sS0FBS0UsRUFBRTtBQUFBLFlBQ3hCLFlBQVl4RSxRQUFRNEYsU0FBU3RCLEtBQUtFLEVBQUU7QUFBQSxZQUNwQyxXQUFXL0IsWUFBWW9IO0FBQUFBLFlBQ3ZCLGtCQUFrQixDQUFDM0YsV0FBV0QsT0FBT0ssS0FBS0UsSUFBSU4sTUFBTTtBQUFBLFlBQ3BELFdBQVcsTUFBTUcsZUFBZUMsSUFBSTtBQUFBO0FBQUEsVUFOL0JBLEtBQUtFO0FBQUFBLFVBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU8wQztBQUFBLE1BRTdDLEtBWEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsU0E3RFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStEQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFNBQVMsTUFBTXJELGdCQUFnQixJQUFJO0FBQUEsUUFDbkMsT0FBTyxFQUFFbUcsVUFBVSxTQUFTd0MsUUFBUTNILGNBQWMsS0FBSyxJQUFJaUgsT0FBT2pILGNBQWMsS0FBSyxJQUFJK0YsUUFBUSxJQUFJOUIsaUJBQWlCLFdBQVc1QyxPQUFPLFdBQVdtRixRQUFRLFFBQVFPLGNBQWMsT0FBT0QsT0FBTzlHLGNBQWMsS0FBSyxJQUFJNEYsUUFBUTVGLGNBQWMsS0FBSyxJQUFJNEgsV0FBVyxzQ0FBc0N4QyxVQUFVcEYsY0FBYyxXQUFXLFVBQVVxRixTQUFTLFFBQVFFLFlBQVksVUFBVUQsZ0JBQWdCLFVBQVVvQixRQUFRLFVBQVU7QUFBQSxRQUN0YSxjQUFXO0FBQUEsUUFBaUI7QUFBQTtBQUFBLE1BSGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUTNIO0FBQUFBLFFBQ1IsU0FBUyxNQUFNQyxnQkFBZ0IsS0FBSztBQUFBLFFBQ3BDLGFBQWFvRixLQUFLNkIsWUFBWTRCLFNBQVM7QUFBQSxRQUN2QztBQUFBLFFBQ0EsaUJBQWlCekQsS0FBS1k7QUFBQUEsUUFDdEI7QUFBQSxRQUNBO0FBQUEsUUFDQSxvQkFBb0IsQ0FBQzhDLFNBQVM3SSxzQkFBc0I2RixJQUFJZ0QsSUFBSTtBQUFBLFFBQzVELG9CQUFvQixDQUFDQSxTQUFTNUkseUJBQXlCLENBQUM2QixTQUFTLElBQUk1QixJQUFJNEIsSUFBSSxFQUFFZ0gsSUFBSUQsSUFBSSxDQUFDO0FBQUEsUUFDeEYsaUJBQWlCLE1BQU05SyxjQUFjWSxLQUFNO0FBQUEsUUFDM0Msb0JBQW9CLENBQUNrSyxTQUFTN0sscUJBQXFCVyxPQUFRa0ssSUFBSTtBQUFBO0FBQUEsTUFYbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV3FFO0FBQUEsSUFHcEU3SixpQkFDRztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csYUFBYUEsY0FBY3NGO0FBQUFBLFFBQzNCLFFBQVF0RixjQUFjcUU7QUFBQUEsUUFDdEIsVUFBVSxNQUFNcEUsaUJBQWlCLElBQUk7QUFBQSxRQUNyQyxZQUFZb0MsWUFBWW9IO0FBQUFBLFFBQ3hCLGNBQWE7QUFBQSxRQUNiLFdBQVcsQ0FBQ2pILGdCQUFnRDtBQUN4RCxnQkFBTUQsWUFBWXZDLGNBQWNvRTtBQUNoQ25FLDJCQUFpQixJQUFJO0FBQ3JCc0Usa0NBQXdCLEVBQUVoQyxXQUFXRSxVQUFVLEdBQUdELFlBQVksQ0FBQztBQUFBLFFBQ25FO0FBQUE7QUFBQSxNQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVVNO0FBQUEsSUFJVGhDLGdCQUNHLHVCQUFDLFNBQUksT0FBTyxFQUFFMEcsVUFBVSxTQUFTNkMsT0FBTyxHQUFHL0QsaUJBQWlCLG1CQUFtQjhCLFFBQVEsTUFBTVYsU0FBUyxRQUFRRSxZQUFZLFVBQVVELGdCQUFnQixVQUFVdkIsU0FBUyxHQUFHLEdBQ3RLLGlDQUFDLFNBQUksT0FBTyxFQUFFRSxpQkFBaUIsV0FBV0YsU0FBUyxJQUFJZ0QsY0FBYyxJQUFJRCxPQUFPLFFBQVFaLFVBQVUsS0FBS00sUUFBUSxvQkFBb0IsR0FDOUhsSCxrQ0FBd0Isb0JBQ3JCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRztBQUFBLFFBQ0EsYUFBYVQ7QUFBQUEsUUFDYixhQUFhd0Y7QUFBQUEsUUFDYixhQUFhLE1BQU07QUFDZm5GLG1DQUF5QixDQUFDNkIsU0FBUyxJQUFJNUIsSUFBSTRCLElBQUksRUFBRWdILElBQUlsSixhQUFhLENBQUM7QUFDbkVVLGlDQUF1QixRQUFRO0FBQy9CbUYsNkJBQW1CO0FBQUEsUUFDdkI7QUFBQSxRQUNBLFVBQVUsTUFBTW5GLHVCQUF1QixRQUFRO0FBQUE7QUFBQSxNQVRuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTcUQsSUFFckRELHdCQUF3QixnQkFDeEI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHO0FBQUEsUUFDQSxhQUFhK0U7QUFBQUEsUUFDYixVQUFVLENBQUN5RCxTQUFTO0FBQ2hCekksK0JBQXFCeUksSUFBSTtBQUN6QixjQUFJckosY0FBYztBQVlkYyxtQ0FBdUIsWUFBWTtBQUNuQ2Usd0JBQVlxRSxPQUFPLEVBQUUsR0FBR2xHLGNBQWNrQyxhQUFhbUgsS0FBSyxDQUFDO0FBQUEsVUFDN0QsT0FBTztBQUNIdkksbUNBQXVCLFFBQVE7QUFBQSxVQUNuQztBQUFBLFFBQ0o7QUFBQSxRQUNBLFVBQVUsTUFBTTtBQUNaYiwwQkFBZ0IsSUFBSTtBQUNwQmEsaUNBQXVCLFFBQVE7QUFBQSxRQUNuQztBQUFBO0FBQUEsTUExQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMEJNLElBRU5ELHdCQUF3QixlQUN4Qix1QkFBQyxPQUFFLE9BQU8sRUFBRTBFLFdBQVcsVUFBVTNDLE9BQU8sV0FBVzhFLFFBQVEsU0FBUyxHQUFHLGdDQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVGLElBRXZGLG1DQUNJO0FBQUEsNkJBQUMsUUFBRyxPQUFPLEVBQUVRLFdBQVcsR0FBR1csY0FBYyxJQUFJakcsT0FBTyxRQUFRK0QsVUFBVSxVQUFVcEIsV0FBVyxTQUFTLEdBQUcsK0NBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0k7QUFBQSxNQUN0SSx1QkFBQyxTQUFJLE9BQU8sRUFBRXFCLFNBQVMsUUFBUWdCLEtBQUssSUFBSWlCLGNBQWMzSSxnQkFBZ0IsWUFBWSxLQUFLLEdBQUcsR0FDdEY7QUFBQSwrQkFBQyxZQUFPLFNBQVMsTUFBTUMsZUFBZSxNQUFNLEdBQUcsT0FBTyxFQUFFcUosTUFBTSxHQUFHbEUsU0FBUyxRQUFRZ0QsY0FBYyxHQUFHUCxRQUFRN0gsZ0JBQWdCLFNBQVMsc0JBQXNCLHFCQUFxQnNGLGlCQUFpQnRGLGdCQUFnQixTQUFTLDRCQUE0QixlQUFlMEMsT0FBTzFDLGdCQUFnQixTQUFTLFlBQVksV0FBV3FILFlBQVksUUFBUVUsUUFBUSxVQUFVLEdBQUcsdUJBQXBXO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMlc7QUFBQSxRQUMzVyx1QkFBQyxZQUFPLFNBQVMsTUFBTTlILGVBQWUsU0FBUyxHQUFHLE9BQU8sRUFBRXFKLE1BQU0sR0FBR2xFLFNBQVMsUUFBUWdELGNBQWMsR0FBR1AsUUFBUTdILGdCQUFnQixZQUFZLHNCQUFzQixxQkFBcUJzRixpQkFBaUJ0RixnQkFBZ0IsWUFBWSw0QkFBNEIsZUFBZTBDLE9BQU8xQyxnQkFBZ0IsWUFBWSxZQUFZLFdBQVdxSCxZQUFZLFFBQVFVLFFBQVEsVUFBVSxHQUFHLDBCQUFoWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBYO0FBQUEsV0FGOVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQy9ILGdCQUFnQixhQUNiLHVCQUFDLFNBQUksT0FBTyxFQUFFMkksY0FBYyxHQUFHLEdBQzNCO0FBQUEsK0JBQUMsV0FBTSxPQUFPLEVBQUVqQyxTQUFTLFNBQVNoRSxPQUFPLFdBQVdpRyxjQUFjLEdBQUdsQyxVQUFVLFNBQVMsR0FBRyxpQ0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RztBQUFBLFFBQzVHLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE9BQU92RyxlQUFlLFVBQVUsQ0FBQzRDLE1BQU0zQyxpQkFBaUIyQyxFQUFFbUYsT0FBT0MsS0FBSyxHQUFHLGFBQVksV0FBVSxXQUFTLE1BQUMsT0FBTyxFQUFFQyxPQUFPLFFBQVEvQyxTQUFTLGFBQWFnRCxjQUFjLEdBQUdQLFFBQVEscUJBQXFCdkMsaUJBQWlCLFdBQVc1QyxPQUFPLFFBQVErRCxVQUFVLFFBQVE0QixTQUFTLFFBQVFuQixXQUFXLGFBQWEsS0FBOVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnVTtBQUFBLFdBRnBVO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUosdUJBQUMsU0FBSSxPQUFPLEVBQUVSLFNBQVMsUUFBUWdCLEtBQUssR0FBRyxHQUNuQztBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNO0FBQUUzSCwwQkFBZ0IsSUFBSTtBQUFHSSwyQkFBaUIsRUFBRTtBQUFHUyxpQ0FBdUIsUUFBUTtBQUFBLFFBQUcsR0FBRyxPQUFPLEVBQUUwSSxNQUFNLEdBQUdsRSxTQUFTLFFBQVFnRCxjQUFjLEdBQUdQLFFBQVEsUUFBUXZDLGlCQUFpQixXQUFXNUMsT0FBTyxRQUFRMkUsWUFBWSxRQUFRVSxRQUFRLFVBQVUsR0FBRyx3QkFBblE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyUTtBQUFBLFFBQzNRLHVCQUFDLFlBQU8sVUFBVy9ILGdCQUFnQixhQUFhLENBQUNFLGlCQUFrQnlCLFlBQVlvSCxXQUFXLFNBQVM3QywyQkFBMkIsT0FBTyxFQUFFb0QsTUFBTSxHQUFHbEUsU0FBUyxRQUFRZ0QsY0FBYyxHQUFHUCxRQUFRLFFBQVF2QyxpQkFBaUIsV0FBVzVDLE9BQU8sV0FBVzJFLFlBQVksUUFBUVUsUUFBUSxVQUFVLEdBQUlwRyxzQkFBWW9ILFlBQVksZ0JBQWdCLGVBQWxVO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOFU7QUFBQSxXQUZsVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkEsS0E3RFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStEQSxLQWhFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUVBO0FBQUEsT0FsTFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9MQTtBQUVSO0FBQUMvSixHQW5XZUQsaUJBQWU7QUFBQSxVQUNUaEIsV0FpQ0FFLFVBT0VELFdBQVc7QUFBQTtBQUFBLEtBekNuQmU7QUFBZSxJQUFBd0s7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNZW1vIiwidXNlRWZmZWN0IiwidXNlUGFyYW1zIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsIlN3YWwiLCJhZGRQdWJsaWNPcmRlckl0ZW0iLCJnZXRQdWJsaWNNZW51IiwiZ2V0UHVibGljQmlsbCIsImdldFB1YmxpY0NvbWFuZGFCaWxsIiwiQ29tcGxlbWVudFNlbGVjdG9yTW9kYWwiLCJQdWJsaWNPcmRlck1vZGFsIiwiUHVibGljT3JkZXJDYXJkIiwiQ29tYW5kYVJlYWRpbmdWYWxpZGF0aW9uIiwiTGlua0NvbWFuZGFWYWxpZGF0aW9uIiwibmVlZHNSZWFkaW5nVmFsaWRhdGlvbiIsImxvZ29JbWciLCJiZ0ltZyIsIlB1YmxpY09yZGVyUGFnZSIsIl9zIiwidG9rZW4iLCJzZW50SWRzIiwic2V0U2VudElkcyIsImVycm9yIiwic2V0RXJyb3IiLCJzZWxlY3RpbmdJdGVtIiwic2V0U2VsZWN0aW5nSXRlbSIsImFjdGl2ZUNhdGVnb3J5Iiwic2V0QWN0aXZlQ2F0ZWdvcnkiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5IiwicXVhbnRpdGllcyIsInNldFF1YW50aXRpZXMiLCJwZW5kaW5nT3JkZXIiLCJzZXRQZW5kaW5nT3JkZXIiLCJkZXN0aW5hdGlvbiIsInNldERlc3RpbmF0aW9uIiwiY29tbWFuZE51bWJlciIsInNldENvbW1hbmROdW1iZXIiLCJzaG93TXlPcmRlcnMiLCJzZXRTaG93TXlPcmRlcnMiLCJ2YWxpZGF0ZWRDb21hbmRhQ29kZXMiLCJzZXRWYWxpZGF0ZWRDb21hbmRhQ29kZXMiLCJTZXQiLCJsaW5rZWRDb21hbmRhQ29kZSIsInNldExpbmtlZENvbWFuZGFDb2RlIiwib3JkZXJWYWxpZGF0aW9uU3RlcCIsInNldE9yZGVyVmFsaWRhdGlvblN0ZXAiLCJ3aW5kb3dXaWR0aCIsInNldFdpbmRvd1dpZHRoIiwid2luZG93IiwiaW5uZXJXaWR0aCIsImhhbmRsZVJlc2l6ZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiaXNNb2JpbGUiLCJpc1R2T3JMYXJnZSIsIm1lbnVRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImVuYWJsZWQiLCJyZXRyeSIsImFkZE11dGF0aW9uIiwibXV0YXRpb25GbiIsInByb2R1Y3RJZCIsImNvbXBsZW1lbnRzIiwicXVhbnRpdHkiLCJjb21hbmRhQ29kZSIsIm9uU3VjY2VzcyIsIl9yZXN1bHQiLCJjdXJyZW50IiwicHJldiIsImZpcmUiLCJ0aXRsZSIsInRleHQiLCJpY29uIiwiYmFja2dyb3VuZCIsImNvbG9yIiwiY29uZmlybUJ1dHRvbkNvbG9yIiwiY29uZmlybUJ1dHRvblRleHQiLCJvbkVycm9yIiwiZSIsIkVycm9yIiwibWVzc2FnZSIsInN0ZXAiLCJnZXRRdHkiLCJzZXRRdHkiLCJuZXdRdHkiLCJNYXRoIiwibWF4IiwiaGFuZGxlUGlja0l0ZW0iLCJpdGVtIiwiY3VycmVudFF0eSIsImlkIiwiY29tcGxlbWVudEdyb3VwcyIsImxlbmd0aCIsInN1Ym1pdE9yR2F0ZURpcmVjdE9yZGVyIiwiY2F0ZWdvcnlMaXN0IiwiZ3JvdXBlZEl0ZW1zIiwiZmlsdGVyZWRJdGVtcyIsImRhdGEiLCJpdGVtcyIsInVuaXF1ZUNhdGVnb3JpZXMiLCJBcnJheSIsImZyb20iLCJtYXAiLCJpIiwiY2F0ZWdvcnlOYW1lIiwiY2F0cyIsInJlc3VsdEl0ZW1zIiwiZmlsdGVyIiwibmFtZSIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJncm91cGVkIiwiZm9yRWFjaCIsImNhdE5hbWUiLCJwdXNoIiwiaXNMb2FkaW5nIiwicGFkZGluZyIsInRleHRBbGlnbiIsImJhY2tncm91bmRDb2xvciIsIm1pbkhlaWdodCIsImlzRXJyb3IiLCJtZW51IiwicmVhZGluZ1ZhbGlkYXRpb24iLCJpc0NhbWVyYUlucHV0RW5hYmxlZCIsImlzQmFyY29kZUVuYWJsZWQiLCJpc1FyQ29kZUVuYWJsZWQiLCJncmlkQ29sdW1ucyIsInN1Ym1pdFBlbmRpbmdPcmRlciIsIm11dGF0ZSIsInVuZGVmaW5lZCIsImhhbmRsZUNvbmZpcm1QZW5kaW5nT3JkZXIiLCJoYXMiLCJvcmRlciIsImlzUXJWaWV3RW5hYmxlZCIsInBhZGRpbmdCb3R0b20iLCJmb250RmFtaWx5IiwicG9zaXRpb24iLCJmb250U2l6ZSIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImFsaWduSXRlbXMiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJiYWNrZ3JvdW5kU2l6ZSIsImJhY2tncm91bmRQb3NpdGlvbiIsImJvcmRlckJvdHRvbSIsImhlaWdodCIsImJveFNpemluZyIsIm9iamVjdEZpdCIsInpJbmRleCIsImZvbnRXZWlnaHQiLCJ0YWJsZU51bWJlciIsIm1heFdpZHRoIiwibWFyZ2luIiwib3ZlcmZsb3dYIiwiZ2FwIiwiY2F0IiwiaXNBY3RpdmUiLCJib3JkZXIiLCJ3aGl0ZVNwYWNlIiwiY3Vyc29yIiwibWFyZ2luVG9wIiwidGFyZ2V0IiwidmFsdWUiLCJ3aWR0aCIsImJvcmRlclJhZGl1cyIsIm91dGxpbmUiLCJyaWdodCIsInRvcCIsIk9iamVjdCIsImVudHJpZXMiLCJwcm9kdWN0cyIsIm1hcmdpbkJvdHRvbSIsInRleHRUcmFuc2Zvcm0iLCJsZXR0ZXJTcGFjaW5nIiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImlzUGVuZGluZyIsImJvdHRvbSIsImJveFNoYWRvdyIsInRvU3RyaW5nIiwiY29kZSIsImFkZCIsImluc2V0IiwiZmxleCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlB1YmxpY09yZGVyUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZU1lbW8sIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnkgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCBTd2FsIGZyb20gXCJzd2VldGFsZXJ0MlwiO1xyXG5pbXBvcnQgeyBhZGRQdWJsaWNPcmRlckl0ZW0sIGdldFB1YmxpY01lbnUsIGdldFB1YmxpY0JpbGwsIGdldFB1YmxpY0NvbWFuZGFCaWxsIH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB0eXBlIHsgTWVudUl0ZW1SZXNwb25zZSwgT3JkZXJJdGVtQ29tcGxlbWVudFNlbGVjdGlvbiB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgQ29tcGxlbWVudFNlbGVjdG9yTW9kYWwgfSBmcm9tIFwiLi4vb3JkZXJzL0NvbXBsZW1lbnRTZWxlY3Rvck1vZGFsXCI7XHJcbmltcG9ydCB7IFB1YmxpY09yZGVyTW9kYWwgfSBmcm9tIFwiLi9QdWJsaWNPcmRlck1vZGFsXCI7XHJcbmltcG9ydCB7IFB1YmxpY09yZGVyQ2FyZCB9IGZyb20gXCIuL1B1YmxpY09yZGVyQ2FyZFwiO1xyXG5pbXBvcnQgeyBDb21hbmRhUmVhZGluZ1ZhbGlkYXRpb24sIExpbmtDb21hbmRhVmFsaWRhdGlvbiwgbmVlZHNSZWFkaW5nVmFsaWRhdGlvbiB9IGZyb20gXCIuL0NvbWFuZGFSZWFkaW5nVmFsaWRhdGlvblwiO1xyXG4vLyBJbXBvcnRhbmRvIGFzIGltYWdlbnNcclxuaW1wb3J0IGxvZ29JbWcgZnJvbSBcIi4uLy4uL2ltYWdlL2xvZ28ucG5nXCI7XHJcbmltcG9ydCBiZ0ltZyBmcm9tIFwiLi4vLi4vaW1hZ2Uvc2NyZWVuYmFja2dyb3VuZF9hdXRoLmpwZWdcIjtcclxuXHJcbnR5cGUgUGVuZGluZ09yZGVyID0ge1xyXG4gICAgcHJvZHVjdElkOiBudW1iZXI7XHJcbiAgICBxdWFudGl0eTogbnVtYmVyO1xyXG4gICAgY29tcGxlbWVudHM/OiBPcmRlckl0ZW1Db21wbGVtZW50U2VsZWN0aW9uW107XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUHVibGljT3JkZXJQYWdlKCkge1xyXG4gICAgY29uc3QgeyB0b2tlbiB9ID0gdXNlUGFyYW1zPHsgdG9rZW46IHN0cmluZyB9PigpO1xyXG4gICAgY29uc3QgW3NlbnRJZHMsIHNldFNlbnRJZHNdID0gdXNlU3RhdGU8bnVtYmVyW10+KFtdKTtcclxuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbc2VsZWN0aW5nSXRlbSwgc2V0U2VsZWN0aW5nSXRlbV0gPSB1c2VTdGF0ZTxNZW51SXRlbVJlc3BvbnNlIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbYWN0aXZlQ2F0ZWdvcnksIHNldEFjdGl2ZUNhdGVnb3J5XSA9IHVzZVN0YXRlPHN0cmluZz4oXCJUb2Rhc1wiKTtcclxuICAgIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbcXVhbnRpdGllcywgc2V0UXVhbnRpdGllc10gPSB1c2VTdGF0ZTxSZWNvcmQ8bnVtYmVyLCBudW1iZXI+Pih7fSk7XHJcbiAgICBjb25zdCBbcGVuZGluZ09yZGVyLCBzZXRQZW5kaW5nT3JkZXJdID0gdXNlU3RhdGU8UGVuZGluZ09yZGVyIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbZGVzdGluYXRpb24sIHNldERlc3RpbmF0aW9uXSA9IHVzZVN0YXRlPFwibWVzYVwiIHwgXCJjb21hbmRhXCI+KFwibWVzYVwiKTtcclxuICAgIGNvbnN0IFtjb21tYW5kTnVtYmVyLCBzZXRDb21tYW5kTnVtYmVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3Nob3dNeU9yZGVycywgc2V0U2hvd015T3JkZXJzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIC8vIFZhbGlkYcOnw6NvIGRlIGxlaXR1cmEgZGUgY29tYW5kYSAoY8OibWVyYS9jw7NkaWdvIGRlIGJhcnJhcy9RUiBDb2RlKSwgcXVhbmRvIGV4aWdpZGEgcGVsYVxyXG4gICAgLy8gZmlsaWFsIOKAlCBjb21wYXJ0aWxoYWRhIGVudHJlIG8gbW9kYWwgXCJNaW5oYSBDb250YVwiIGUgbyBmbHV4byBkZSBub3ZvIHBlZGlkbzogdW1hIHZlelxyXG4gICAgLy8gdmFsaWRhZG8gdW0gY8OzZGlnbyBkZSBjb21hbmRhIG5lc3RhIHZpc2l0YSwgbsOjbyBwZWRlIGRlIG5vdm8uXHJcbiAgICBjb25zdCBbdmFsaWRhdGVkQ29tYW5kYUNvZGVzLCBzZXRWYWxpZGF0ZWRDb21hbmRhQ29kZXNdID0gdXNlU3RhdGU8U2V0PHN0cmluZz4+KG5ldyBTZXQoKSk7XHJcbiAgICAvLyBDb21hbmRhIHZpbmN1bGFkYSBhbyBwZWRpZG8gZGlyZXRvIHZpYSBjw6JtZXJhL1FSIENvZGUvY8OzZGlnbyBkZSBiYXJyYXMgKGZsdXhvXHJcbiAgICAvLyBcIklzUXJWaWV3RW5hYmxlZCBkZXNsaWdhZG8gKyBJc0NhbWVyYUlucHV0RW5hYmxlZCBsaWdhZG9cIiDigJQgdmVyIExpbmtDb21hbmRhVmFsaWRhdGlvbikuXHJcbiAgICAvLyBVbWEgdmV6IHZpbmN1bGFkYSBuZXN0YSB2aXNpdGEsIG9zIHBlZGlkb3Mgc2VndWludGVzIHbDo28gZGlyZXRvIHByYSBlbGEsIHNlbVxyXG4gICAgLy8gcGVkaXIgZXNjYW5lYW1lbnRvIGRlIG5vdm87IHRhbWLDqW0gdXNhZGEgcG9yIFwiTWluaGEgQ29udGFcIiBwcmEgc2FiZXIgcXVhbCBjb250YVxyXG4gICAgLy8gbW9zdHJhciBuZXNzZSBjZW7DoXJpbyAodmVyIFB1YmxpY09yZGVyTW9kYWwpLlxyXG4gICAgY29uc3QgW2xpbmtlZENvbWFuZGFDb2RlLCBzZXRMaW5rZWRDb21hbmRhQ29kZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFtvcmRlclZhbGlkYXRpb25TdGVwLCBzZXRPcmRlclZhbGlkYXRpb25TdGVwXSA9IHVzZVN0YXRlPFwic2VsZWN0XCIgfCBcInZhbGlkYXRlQ29tYW5kYVwiIHwgXCJsaW5rQ29tYW5kYVwiIHwgXCJzdWJtaXR0aW5nXCI+KFwic2VsZWN0XCIpO1xyXG4gICAgLy8gVmFyacOhdmVpcyBkaW7Dom1pY2FzIGJhc2VhZGFzIG5vIHRhbWFuaG8gZGEgdGVsYSAoUmVzcG9uc2l2aWRhZGUgTXVsdGktdGVsYXMpXHJcbiAgICBjb25zdCBbd2luZG93V2lkdGgsIHNldFdpbmRvd1dpZHRoXSA9IHVzZVN0YXRlKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cuaW5uZXJXaWR0aCA6IDEyMDApO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBoYW5kbGVSZXNpemUgPSAoKSA9PiBzZXRXaW5kb3dXaWR0aCh3aW5kb3cuaW5uZXJXaWR0aCk7XHJcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgaGFuZGxlUmVzaXplKTtcclxuICAgICAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgaGFuZGxlUmVzaXplKTtcclxuICAgIH0sIFtdKTtcclxuICAgIC8vIERlZmluacOnw6NvIGRpbsOibWljYSBkZSBlc2NhbGEgY29tIGJhc2UgbmEgbGFyZ3VyYSBkYSB0ZWxhXHJcbiAgICBjb25zdCBpc01vYmlsZSA9IHdpbmRvd1dpZHRoIDwgNjQwO1xyXG4gICAgY29uc3QgaXNUdk9yTGFyZ2UgPSB3aW5kb3dXaWR0aCA+IDEyMDA7XHJcblxyXG4gICAgY29uc3QgbWVudVF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgICAgIHF1ZXJ5S2V5OiBbXCJwdWJsaWMtbWVudVwiLCB0b2tlbl0sXHJcbiAgICAgICAgcXVlcnlGbjogKCkgPT4gZ2V0UHVibGljTWVudSh0b2tlbiEpLFxyXG4gICAgICAgIGVuYWJsZWQ6ICEhdG9rZW4sXHJcbiAgICAgICAgcmV0cnk6IGZhbHNlLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgYWRkTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKHsgcHJvZHVjdElkLCBjb21wbGVtZW50cywgcXVhbnRpdHkgPSAxLCBjb21hbmRhQ29kZSB9OiB7IHByb2R1Y3RJZDogbnVtYmVyOyBjb21wbGVtZW50cz86IE9yZGVySXRlbUNvbXBsZW1lbnRTZWxlY3Rpb25bXTsgcXVhbnRpdHk/OiBudW1iZXI7IGNvbWFuZGFDb2RlPzogc3RyaW5nIH0pID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIGFkZFB1YmxpY09yZGVySXRlbSh0b2tlbiEsIHByb2R1Y3RJZCwgcXVhbnRpdHksIG51bGwsIGNvbXBsZW1lbnRzLCBjb21hbmRhQ29kZSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvblN1Y2Nlc3M6IChfcmVzdWx0LCB7IHByb2R1Y3RJZCB9KSA9PiB7XHJcbiAgICAgICAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICAgICAgICBzZXRTZW50SWRzKChjdXJyZW50KSA9PiBbLi4uY3VycmVudCwgcHJvZHVjdElkXSk7XHJcbiAgICAgICAgICAgIHNldFNlbGVjdGluZ0l0ZW0obnVsbCk7XHJcbiAgICAgICAgICAgIHNldFBlbmRpbmdPcmRlcihudWxsKTtcclxuICAgICAgICAgICAgc2V0Q29tbWFuZE51bWJlcihcIlwiKTtcclxuICAgICAgICAgICAgc2V0T3JkZXJWYWxpZGF0aW9uU3RlcChcInNlbGVjdFwiKTtcclxuICAgICAgICAgICAgc2V0UXVhbnRpdGllcyhwcmV2ID0+ICh7IC4uLnByZXYsIFtwcm9kdWN0SWRdOiAxIH0pKTtcclxuICAgICAgICAgICAgU3dhbC5maXJlKHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBcIlN1Y2Vzc28hXCIsXHJcbiAgICAgICAgICAgICAgICB0ZXh0OiBcIlBlZGlkbyBlbnZpYWRvIGNvbSBzdWNlc3NvISBTw7MgYWd1YXJkYXIuXCIsXHJcbiAgICAgICAgICAgICAgICBpY29uOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiIzFlMWUyNFwiLFxyXG4gICAgICAgICAgICAgICAgY29sb3I6IFwiI2ZmZmZmZlwiLFxyXG4gICAgICAgICAgICAgICAgY29uZmlybUJ1dHRvbkNvbG9yOiBcIiNmNTllMGJcIixcclxuICAgICAgICAgICAgICAgIGNvbmZpcm1CdXR0b25UZXh0OiBcIk9LXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogKGUpID0+IHtcclxuICAgICAgICAgICAgc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogXCJGYWxoYSBhbyBlbnZpYXIgbyBwZWRpZG8uXCIpO1xyXG4gICAgICAgICAgICAvLyBTZSBhIGZhbGhhIGFjb250ZWNldSBubyBlbnZpbyBhdXRvbcOhdGljbyBxdWUgYWNvbnRlY2UgbG9nbyBkZXBvaXMgZGVcclxuICAgICAgICAgICAgLy8gdmluY3VsYXIgYSBjb21hbmRhICh2ZXIgTGlua0NvbWFuZGFWYWxpZGF0aW9uLm9uTGlua2VkKSwgdm9sdGEgcHJhIHRlbGFcclxuICAgICAgICAgICAgLy8gZGUgdsOtbmN1bG8gZW0gdmV6IGRlIGRlaXhhciBvIG1vZGFsIHByZXNvIG5vIGVzdGFkbyBpbnRlcm1lZGnDoXJpb1xyXG4gICAgICAgICAgICAvLyBcInN1Ym1pdHRpbmdcIiAoc2VtIGlzc28sIG8gcGVuZGluZ09yZGVyIHNvbWUgcXVhbmRvIGEgY29tYW5kYSBmb3JcclxuICAgICAgICAgICAgLy8gdmluY3VsYWRhIGRlIG5vdm8sIG1hcyBhdMOpIGzDoSBhIHRlbGEgZmljYXJpYSBcInRyYXZhZGFcIikuXHJcbiAgICAgICAgICAgIHNldE9yZGVyVmFsaWRhdGlvblN0ZXAoKHN0ZXApID0+IChzdGVwID09PSBcInN1Ym1pdHRpbmdcIiA/IFwibGlua0NvbWFuZGFcIiA6IHN0ZXApKTtcclxuICAgICAgICB9LFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgZ2V0UXR5ID0gKHByb2R1Y3RJZDogbnVtYmVyKSA9PiBxdWFudGl0aWVzW3Byb2R1Y3RJZF0gfHwgMTtcclxuICAgIGNvbnN0IHNldFF0eSA9IChwcm9kdWN0SWQ6IG51bWJlciwgbmV3UXR5OiBudW1iZXIpID0+IHtcclxuICAgICAgICBzZXRRdWFudGl0aWVzKHByZXYgPT4gKHsgLi4ucHJldiwgW3Byb2R1Y3RJZF06IE1hdGgubWF4KDEsIG5ld1F0eSkgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVQaWNrSXRlbSA9IChpdGVtOiBNZW51SXRlbVJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgY29uc3QgY3VycmVudFF0eSA9IGdldFF0eShpdGVtLmlkKTtcclxuICAgICAgICBpZiAoaXRlbS5jb21wbGVtZW50R3JvdXBzICYmIGl0ZW0uY29tcGxlbWVudEdyb3Vwcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHNldFNlbGVjdGluZ0l0ZW0oaXRlbSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgc3VibWl0T3JHYXRlRGlyZWN0T3JkZXIoeyBwcm9kdWN0SWQ6IGl0ZW0uaWQsIHF1YW50aXR5OiBjdXJyZW50UXR5IH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCB7IGNhdGVnb3J5TGlzdCwgZ3JvdXBlZEl0ZW1zLCBmaWx0ZXJlZEl0ZW1zIH0gPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBpZiAoIW1lbnVRdWVyeS5kYXRhKSByZXR1cm4geyBjYXRlZ29yeUxpc3Q6IFtdLCBncm91cGVkSXRlbXM6IHt9LCBmaWx0ZXJlZEl0ZW1zOiBbXSB9O1xyXG4gICAgICAgIGNvbnN0IGl0ZW1zID0gbWVudVF1ZXJ5LmRhdGEuaXRlbXM7XHJcbiAgICAgICAgY29uc3QgdW5pcXVlQ2F0ZWdvcmllcyA9IEFycmF5LmZyb20obmV3IFNldChpdGVtcy5tYXAoKGk6IGFueSkgPT4gaS5jYXRlZ29yeU5hbWUgfHwgXCJHZXJhbFwiKSkpO1xyXG4gICAgICAgIGNvbnN0IGNhdHMgPSBbXCJUb2Rhc1wiLCAuLi51bmlxdWVDYXRlZ29yaWVzXTtcclxuICAgICAgICBsZXQgcmVzdWx0SXRlbXMgPSBpdGVtcztcclxuICAgICAgICBpZiAoYWN0aXZlQ2F0ZWdvcnkgIT09IFwiVG9kYXNcIikge1xyXG4gICAgICAgICAgICByZXN1bHRJdGVtcyA9IHJlc3VsdEl0ZW1zLmZpbHRlcigoaTogYW55KSA9PiAoaS5jYXRlZ29yeU5hbWUgfHwgXCJHZXJhbFwiKSA9PT0gYWN0aXZlQ2F0ZWdvcnkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoc2VhcmNoUXVlcnkpIHtcclxuICAgICAgICAgICAgcmVzdWx0SXRlbXMgPSByZXN1bHRJdGVtcy5maWx0ZXIoaSA9PiBpLm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGdyb3VwZWQ6IFJlY29yZDxzdHJpbmcsIE1lbnVJdGVtUmVzcG9uc2VbXT4gPSB7fTtcclxuICAgICAgICByZXN1bHRJdGVtcy5mb3JFYWNoKChpdGVtOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY2F0TmFtZSA9IGl0ZW0uY2F0ZWdvcnlOYW1lIHx8IFwiR2VyYWxcIjtcclxuICAgICAgICAgICAgaWYgKCFncm91cGVkW2NhdE5hbWVdKSBncm91cGVkW2NhdE5hbWVdID0gW107XHJcbiAgICAgICAgICAgIGdyb3VwZWRbY2F0TmFtZV0ucHVzaChpdGVtKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4geyBjYXRlZ29yeUxpc3Q6IGNhdHMsIGdyb3VwZWRJdGVtczogZ3JvdXBlZCwgZmlsdGVyZWRJdGVtczogcmVzdWx0SXRlbXMgfTtcclxuICAgIH0sIFttZW51UXVlcnkuZGF0YSwgYWN0aXZlQ2F0ZWdvcnksIHNlYXJjaFF1ZXJ5XSk7XHJcblxyXG4gICAgaWYgKCF0b2tlbikgcmV0dXJuIG51bGw7XHJcbiAgICBpZiAobWVudVF1ZXJ5LmlzTG9hZGluZylcclxuICAgICAgICByZXR1cm4gPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjQsIHRleHRBbGlnbjogXCJjZW50ZXJcIiwgY29sb3I6IFwiI2E4YThiM1wiLCBiYWNrZ3JvdW5kQ29sb3I6IFwiIzEyMTIxNFwiLCBtaW5IZWlnaHQ6IFwiMTAwdmhcIiB9fT5DYXJyZWdhbmRvIGNhcmTDoXBpb+KApjwvbWFpbj47XHJcbiAgICBpZiAobWVudVF1ZXJ5LmlzRXJyb3IpXHJcbiAgICAgICAgcmV0dXJuIDxtYWluIHN0eWxlPXt7IHBhZGRpbmc6IDI0LCB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIGJhY2tncm91bmRDb2xvcjogXCIjMTIxMjE0XCIsIG1pbkhlaWdodDogXCIxMDB2aFwiIH19PjxwIHN0eWxlPXt7IGNvbG9yOiBcIiNlZjQ0NDRcIiB9fT5Ow6NvIGZvaSBwb3Nzw612ZWwgY2FycmVnYXIgbyBjYXJkw6FwaW8uPC9wPjwvbWFpbj47XHJcbiAgICBjb25zdCBtZW51ID0gbWVudVF1ZXJ5LmRhdGEhO1xyXG4gICAgY29uc3QgcmVhZGluZ1ZhbGlkYXRpb24gPSB7XHJcbiAgICAgICAgaXNDYW1lcmFJbnB1dEVuYWJsZWQ6IG1lbnUuaXNDYW1lcmFJbnB1dEVuYWJsZWQsXHJcbiAgICAgICAgaXNCYXJjb2RlRW5hYmxlZDogbWVudS5pc0JhcmNvZGVFbmFibGVkLFxyXG4gICAgICAgIGlzUXJDb2RlRW5hYmxlZDogbWVudS5pc1FyQ29kZUVuYWJsZWQsXHJcbiAgICB9O1xyXG5cclxuICAgIC8vIEdyaWQgcmVzcG9uc2l2byBkaW7Dom1pY286IDEgY29sdW5hIG5vIGNlbHVsYXIsIDIgZW0gdGFibGV0cywgMyBvdSA0IGVtIFRWcy9UZWxhcyBncmFuZGVzXHJcbiAgICBjb25zdCBncmlkQ29sdW1ucyA9IGlzTW9iaWxlXHJcbiAgICAgICAgPyBcIjFmclwiXHJcbiAgICAgICAgOiBpc1R2T3JMYXJnZVxyXG4gICAgICAgICAgICA/IFwicmVwZWF0KGF1dG8tZmlsbCwgbWlubWF4KDM4MHB4LCAxZnIpKVwiXHJcbiAgICAgICAgICAgIDogXCJyZXBlYXQoYXV0by1maWxsLCBtaW5tYXgoMzAwcHgsIDFmcikpXCI7XHJcblxyXG4gICAgY29uc3Qgc3VibWl0UGVuZGluZ09yZGVyID0gKCkgPT4ge1xyXG4gICAgICAgIGlmICghcGVuZGluZ09yZGVyKSByZXR1cm47XHJcbiAgICAgICAgYWRkTXV0YXRpb24ubXV0YXRlKHtcclxuICAgICAgICAgICAgcHJvZHVjdElkOiBwZW5kaW5nT3JkZXIucHJvZHVjdElkLFxyXG4gICAgICAgICAgICBxdWFudGl0eTogcGVuZGluZ09yZGVyLnF1YW50aXR5LFxyXG4gICAgICAgICAgICBjb21wbGVtZW50czogcGVuZGluZ09yZGVyLmNvbXBsZW1lbnRzLFxyXG4gICAgICAgICAgICAvLyBWYWkgcHJhIGNvbnRhIGRhIGNvbWFuZGEgKG7Do28gZGEgbWVzYSkg4oCUIGEgbWVzYSBmaWNhIHJlZ2lzdHJhZGEgbm8gcGVkaWRvXHJcbiAgICAgICAgICAgIC8vIHByYSBjb3ppbmhhL2dhcsOnb20gc2FiZXJlbSBvbmRlIGVudHJlZ2FyLiBWZXIgQWRkUHVibGljT3JkZXJJdGVtQ29tbWFuZC5cclxuICAgICAgICAgICAgY29tYW5kYUNvZGU6IGRlc3RpbmF0aW9uID09PSBcImNvbWFuZGFcIiA/IGNvbW1hbmROdW1iZXIgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNvbmZpcm1QZW5kaW5nT3JkZXIgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKGRlc3RpbmF0aW9uID09PSBcImNvbWFuZGFcIiAmJiBuZWVkc1JlYWRpbmdWYWxpZGF0aW9uKHJlYWRpbmdWYWxpZGF0aW9uKSAmJiAhdmFsaWRhdGVkQ29tYW5kYUNvZGVzLmhhcyhjb21tYW5kTnVtYmVyKSkge1xyXG4gICAgICAgICAgICBzZXRPcmRlclZhbGlkYXRpb25TdGVwKFwidmFsaWRhdGVDb21hbmRhXCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN1Ym1pdFBlbmRpbmdPcmRlcigpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBQb250byDDum5pY28gZGUgZW50cmFkYSBwcmEgXCJQZWRpclwiOiBkZWNpZGUgZW50cmUgYWJyaXIgbyBzZWxldG9yIE1lc2EvQ29tYW5kYVxyXG4gICAgLy8gKFZpc3VhbGl6YcOnw6NvIGRvIENsaWVudGUgbGlnYWRhKSwgdmluY3VsYXIgbyBwZWRpZG8gYSB1bWEgY29tYW5kYSB2aWFcclxuICAgIC8vIGPDom1lcmEvUVIgQ29kZS9jw7NkaWdvIGRlIGJhcnJhcyAoZGVzbGlnYWRhICsgY8OibWVyYSBsaWdhZGEg4oCUIG8gcGVkaWRvIHZhaSBwcmFcclxuICAgIC8vIGNvbnRhIGRhIGNvbWFuZGEsIG51bmNhIGRhIG1lc2E7IHZlciBMaW5rQ29tYW5kYVZhbGlkYXRpb24vRmFzZSA3KSwgb3VcclxuICAgIC8vIHNpbXBsZXNtZW50ZSBlbnZpYXIgbyBwZWRpZG8gZGlyZXRvIHByYSBtZXNhIChkZXNsaWdhZGEsIHNlbSBuZW5odW1hIGV4aWfDqm5jaWEpLlxyXG4gICAgY29uc3Qgc3VibWl0T3JHYXRlRGlyZWN0T3JkZXIgPSAob3JkZXI6IFBlbmRpbmdPcmRlcikgPT4ge1xyXG4gICAgICAgIGlmIChtZW51LmlzUXJWaWV3RW5hYmxlZCkge1xyXG4gICAgICAgICAgICBzZXRQZW5kaW5nT3JkZXIob3JkZXIpO1xyXG4gICAgICAgICAgICBzZXREZXN0aW5hdGlvbihcIm1lc2FcIik7XHJcbiAgICAgICAgICAgIHNldE9yZGVyVmFsaWRhdGlvblN0ZXAoXCJzZWxlY3RcIik7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHJlYWRpbmdWYWxpZGF0aW9uLmlzQ2FtZXJhSW5wdXRFbmFibGVkKSB7XHJcbiAgICAgICAgICAgIGlmIChsaW5rZWRDb21hbmRhQ29kZSkge1xyXG4gICAgICAgICAgICAgICAgYWRkTXV0YXRpb24ubXV0YXRlKHsgLi4ub3JkZXIsIGNvbWFuZGFDb2RlOiBsaW5rZWRDb21hbmRhQ29kZSB9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzZXRQZW5kaW5nT3JkZXIob3JkZXIpO1xyXG4gICAgICAgICAgICBzZXRPcmRlclZhbGlkYXRpb25TdGVwKFwibGlua0NvbWFuZGFcIik7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgYWRkTXV0YXRpb24ubXV0YXRlKG9yZGVyKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8bWFpbiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwiIzEyMTIxNFwiLCBtaW5IZWlnaHQ6IFwiMTAwdmhcIiwgcGFkZGluZ0JvdHRvbTogMTAwLCBjb2xvcjogXCIjZTFlMWU2XCIsIGZvbnRGYW1pbHk6IFwic2Fucy1zZXJpZlwiLCBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLCBmb250U2l6ZTogaXNUdk9yTGFyZ2UgPyBcIjEuMXJlbVwiIDogXCIxcmVtXCIgfX0+XHJcbiAgICAgICAgICAgIHsvKiBDYWJlw6dhbGhvICovfVxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIHBhZGRpbmc6IGlzTW9iaWxlID8gXCI4cHggMTJweFwiIDogXCIxMnB4IDI0cHhcIiwgYmFja2dyb3VuZEltYWdlOiBgbGluZWFyLWdyYWRpZW50KHJnYmEoMTgsIDE4LCAyMCwgMC44NSksIHJnYmEoMTgsIDE4LCAyMCwgMC45NSkpLCB1cmwoJHtiZ0ltZ30pYCwgYmFja2dyb3VuZFNpemU6IFwiY292ZXJcIiwgYmFja2dyb3VuZFBvc2l0aW9uOiBcImNlbnRlclwiLCBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkICMyOTI5MmVcIiwgaGVpZ2h0OiBpc1R2T3JMYXJnZSA/IFwiMTAwcHhcIiA6IFwiODBweFwiLCBib3hTaXppbmc6IFwiYm9yZGVyLWJveFwiIH19PlxyXG4gICAgICAgICAgICAgICAgPGltZyBzcmM9e2xvZ29JbWd9IGFsdD1cIkxvZ290aXBvIFN5bmNCYXJcIiBzdHlsZT17eyBoZWlnaHQ6IGlzVHZPckxhcmdlID8gNzAgOiA1MCwgb2JqZWN0Rml0OiBcImNvbnRhaW5cIiwgcG9zaXRpb246IFwicmVsYXRpdmVcIiwgekluZGV4OiAyIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHRleHRBbGlnbjogXCJyaWdodFwiLCBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLCB6SW5kZXg6IDIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBjb2xvcjogXCIjZmZmZmZmXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS41cmVtXCIgOiBcIjEuMTVyZW1cIiwgZm9udFdlaWdodDogXCI2MDBcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTWVzYSA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCIjZjU5ZTBiXCIgfX0+e21lbnUudGFibGVOdW1iZXJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6IGlzTW9iaWxlID8gXCIwIDEycHhcIiA6IFwiMCAyNHB4XCIsIG1heFdpZHRoOiBpc1R2T3JMYXJnZSA/IDE0MDAgOiA5MDAsIG1hcmdpbjogXCIxNnB4IGF1dG8gMFwiIH19PlxyXG4gICAgICAgICAgICAgICAgey8qIEFiYXMgZGUgQ2F0ZWdvcmlhICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgb3ZlcmZsb3dYOiBcImF1dG9cIiwgZ2FwOiBpc1R2T3JMYXJnZSA/IDMyIDogMjQsIHBhZGRpbmdCb3R0b206IDYsIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgIzMyMzIzOFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeUxpc3QubWFwKChjYXQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGFjdGl2ZUNhdGVnb3J5ID09PSBjYXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjYXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlQ2F0ZWdvcnkoY2F0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcIm5vbmVcIiwgYm9yZGVyOiBcIm5vbmVcIiwgcGFkZGluZzogXCIwIDAgMTBweCAwXCIsIHdoaXRlU3BhY2U6IFwibm93cmFwXCIsIGZvbnRXZWlnaHQ6IGlzQWN0aXZlID8gXCJib2xkXCIgOiBcIm5vcm1hbFwiLCBjb2xvcjogaXNBY3RpdmUgPyBcIiNmNTllMGJcIiA6IFwiI2E4YThiM1wiLCBib3JkZXJCb3R0b206IGlzQWN0aXZlID8gXCIycHggc29saWQgI2Y1OWUwYlwiIDogXCIycHggc29saWQgdHJhbnNwYXJlbnRcIiwgY3Vyc29yOiBcInBvaW50ZXJcIiwgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIxLjJyZW1cIiA6IFwiMC45NXJlbVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogMTYsIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQZXNxdWlzYXIgdW0gcHJvZHV0by4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgcGFkZGluZzogaXNUdk9yTGFyZ2UgPyBcIjE4cHggMjBweFwiIDogXCIxNHB4IDE2cHhcIiwgYm9yZGVyUmFkaXVzOiA4LCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiwgYmFja2dyb3VuZENvbG9yOiBcIiMyMDIwMjRcIiwgY29sb3I6IFwiI2UxZTFlNlwiLCBvdXRsaW5lOiBcIm5vbmVcIiwgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIxLjFyZW1cIiA6IFwiMC45NXJlbVwiLCBib3hTaXppbmc6IFwiYm9yZGVyLWJveFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCByaWdodDogMTYsIHRvcDogaXNUdk9yTGFyZ2UgPyAxOCA6IDE0LCBjb2xvcjogXCIjYThhOGIzXCIgfX0+8J+UjTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge2Vycm9yICYmIDxwIHN0eWxlPXt7IG1hcmdpblRvcDogMTYsIHRleHRBbGlnbjogXCJjZW50ZXJcIiwgY29sb3I6IFwiI2VmNDQ0NFwiIH19PntlcnJvcn08L3A+fVxyXG4gICAgICAgICAgICAgICAge2FjdGl2ZUNhdGVnb3J5ID09PSBcIlRvZGFzXCIgJiYgIXNlYXJjaFF1ZXJ5ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIE9iamVjdC5lbnRyaWVzKGdyb3VwZWRJdGVtcykubWFwKChbY2F0ZWdvcnlOYW1lLCBwcm9kdWN0c10pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2NhdGVnb3J5TmFtZX0gc3R5bGU9e3sgbWFyZ2luVG9wOiAzMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAxNiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgc3R5bGU9e3sgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIxLjNyZW1cIiA6IFwiMS4wNXJlbVwiLCB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLCBsZXR0ZXJTcGFjaW5nOiAxLCBjb2xvcjogXCIjZmZmXCIsIG1hcmdpbjogMCwgcGFkZGluZ0JvdHRvbTogNiwgYm9yZGVyQm90dG9tOiBcIjJweCBzb2xpZCAjZjU5ZTBiXCIsIGRpc3BsYXk6IFwiaW5saW5lLWJsb2NrXCIgfX0+e2NhdGVnb3J5TmFtZX08L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE2LCBncmlkVGVtcGxhdGVDb2x1bW5zOiBncmlkQ29sdW1ucyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdHMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQdWJsaWNPcmRlckNhcmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW09e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWFudGl0eT17Z2V0UXR5KGl0ZW0uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNKdXN0U2VudD17c2VudElkcy5pbmNsdWRlcyhpdGVtLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzUGVuZGluZz17YWRkTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25RdWFudGl0eUNoYW5nZT17KG5ld1F0eSkgPT4gc2V0UXR5KGl0ZW0uaWQsIG5ld1F0eSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkFkZEl0ZW09eygpID0+IGhhbmRsZVBpY2tJdGVtKGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAyNCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTYsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IGdyaWRDb2x1bW5zIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRJdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQdWJsaWNPcmRlckNhcmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbT17aXRlbX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWFudGl0eT17Z2V0UXR5KGl0ZW0uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzSnVzdFNlbnQ9e3NlbnRJZHMuaW5jbHVkZXMoaXRlbS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNQZW5kaW5nPXthZGRNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25RdWFudGl0eUNoYW5nZT17KG5ld1F0eSkgPT4gc2V0UXR5KGl0ZW0uaWQsIG5ld1F0eSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25BZGRJdGVtPXsoKSA9PiBoYW5kbGVQaWNrSXRlbShpdGVtKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsvKiBCb3TDo28gRmx1dHVhbnRlIGRlIENvbnRhICovfVxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TXlPcmRlcnModHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBwb3NpdGlvbjogXCJmaXhlZFwiLCBib3R0b206IGlzVHZPckxhcmdlID8gMzYgOiAyNCwgcmlnaHQ6IGlzVHZPckxhcmdlID8gMzYgOiAyNCwgekluZGV4OiA1MCwgYmFja2dyb3VuZENvbG9yOiBcIiNmNTllMGJcIiwgY29sb3I6IFwiIzEyMTIxNFwiLCBib3JkZXI6IFwibm9uZVwiLCBib3JkZXJSYWRpdXM6IFwiNTAlXCIsIHdpZHRoOiBpc1R2T3JMYXJnZSA/IDgwIDogNjQsIGhlaWdodDogaXNUdk9yTGFyZ2UgPyA4MCA6IDY0LCBib3hTaGFkb3c6IFwiMCA0cHggMTVweCByZ2JhKDI0NSwgMTU4LCAxMSwgMC40KVwiLCBmb250U2l6ZTogaXNUdk9yTGFyZ2UgPyBcIjIuMnJlbVwiIDogXCIxLjhyZW1cIiwgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLCBjdXJzb3I6IFwicG9pbnRlclwiIH19XHJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiVmVyIG1pbmhhIGNvbnRhXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAg8J+nvlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgey8qIE1vZGFsIGRlIENvbnN1bHRhIGRlIENvbnRhICovfVxyXG4gICAgICAgICAgICA8UHVibGljT3JkZXJNb2RhbFxyXG4gICAgICAgICAgICAgICAgaXNPcGVuPXtzaG93TXlPcmRlcnN9XHJcbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TXlPcmRlcnMoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgdGFibGVOdW1iZXI9e21lbnUudGFibGVOdW1iZXIudG9TdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgIHRva2VuPXt0b2tlbn1cclxuICAgICAgICAgICAgICAgIGlzUXJWaWV3RW5hYmxlZD17bWVudS5pc1FyVmlld0VuYWJsZWR9XHJcbiAgICAgICAgICAgICAgICBsaW5rZWRDb21hbmRhQ29kZT17bGlua2VkQ29tYW5kYUNvZGV9XHJcbiAgICAgICAgICAgICAgICByZWFkaW5nVmFsaWRhdGlvbj17cmVhZGluZ1ZhbGlkYXRpb259XHJcbiAgICAgICAgICAgICAgICBpc0NvbWFuZGFWYWxpZGF0ZWQ9eyhjb2RlKSA9PiB2YWxpZGF0ZWRDb21hbmRhQ29kZXMuaGFzKGNvZGUpfVxyXG4gICAgICAgICAgICAgICAgb25Db21hbmRhVmFsaWRhdGVkPXsoY29kZSkgPT4gc2V0VmFsaWRhdGVkQ29tYW5kYUNvZGVzKChwcmV2KSA9PiBuZXcgU2V0KHByZXYpLmFkZChjb2RlKSl9XHJcbiAgICAgICAgICAgICAgICBvbkZldGNoTWVzYUJpbGw9eygpID0+IGdldFB1YmxpY0JpbGwodG9rZW4hKX1cclxuICAgICAgICAgICAgICAgIG9uRmV0Y2hDb21hbmRhQmlsbD17KGNvZGUpID0+IGdldFB1YmxpY0NvbWFuZGFCaWxsKHRva2VuISwgY29kZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIHsvKiBNb2RhbCBkZSBDb21wbGVtZW50b3MgKi99XHJcbiAgICAgICAgICAgIHtzZWxlY3RpbmdJdGVtICYmIChcclxuICAgICAgICAgICAgICAgIDxDb21wbGVtZW50U2VsZWN0b3JNb2RhbFxyXG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3ROYW1lPXtzZWxlY3RpbmdJdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBzPXtzZWxlY3RpbmdJdGVtLmNvbXBsZW1lbnRHcm91cHN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DYW5jZWw9eygpID0+IHNldFNlbGVjdGluZ0l0ZW0obnVsbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgc3VibWl0dGluZz17YWRkTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbD1cIkFESUNJT05BUlwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25Db25maXJtPXsoY29tcGxlbWVudHM6IE9yZGVySXRlbUNvbXBsZW1lbnRTZWxlY3Rpb25bXSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwcm9kdWN0SWQgPSBzZWxlY3RpbmdJdGVtLmlkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RpbmdJdGVtKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJtaXRPckdhdGVEaXJlY3RPcmRlcih7IHByb2R1Y3RJZCwgcXVhbnRpdHk6IDEsIGNvbXBsZW1lbnRzIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7LyogTW9kYWwgZGUgRXNjb2xoYSBkZSBEZXN0aW5vIChNZXNhIG91IENvbWFuZGEpIHBhcmEgbyBQZWRpZG8gKi99XHJcbiAgICAgICAgICAgIHtwZW5kaW5nT3JkZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogXCJmaXhlZFwiLCBpbnNldDogMCwgYmFja2dyb3VuZENvbG9yOiBcInJnYmEoMCwwLDAsMC44KVwiLCB6SW5kZXg6IDk5OTksIGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIiwgcGFkZGluZzogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwiIzFlMWUyNFwiLCBwYWRkaW5nOiAyNCwgYm9yZGVyUmFkaXVzOiAxMiwgd2lkdGg6IFwiMTAwJVwiLCBtYXhXaWR0aDogNDAwLCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge29yZGVyVmFsaWRhdGlvblN0ZXAgPT09IFwidmFsaWRhdGVDb21hbmRhXCIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29tYW5kYVJlYWRpbmdWYWxpZGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9rZW49e3Rva2VufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbWFuZGFDb2RlPXtjb21tYW5kTnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVtZW50PXtyZWFkaW5nVmFsaWRhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblZhbGlkYXRlZD17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWYWxpZGF0ZWRDb21hbmRhQ29kZXMoKHByZXYpID0+IG5ldyBTZXQocHJldikuYWRkKGNvbW1hbmROdW1iZXIpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0T3JkZXJWYWxpZGF0aW9uU3RlcChcInNlbGVjdFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VibWl0UGVuZGluZ09yZGVyKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0T3JkZXJWYWxpZGF0aW9uU3RlcChcInNlbGVjdFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiBvcmRlclZhbGlkYXRpb25TdGVwID09PSBcImxpbmtDb21hbmRhXCIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua0NvbWFuZGFWYWxpZGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9rZW49e3Rva2VufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVtZW50PXtyZWFkaW5nVmFsaWRhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkxpbmtlZD17KGNvZGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TGlua2VkQ29tYW5kYUNvZGUoY29kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwZW5kaW5nT3JkZXIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE7Do28gdm9sdGEgcHJhIFwic2VsZWN0XCIgYXF1aTogZXNzZSDDqSBvIGVzdGFkb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gXCJuZXV0cm9cIiBxdWUgdGFtYsOpbSByZW5kZXJpemEgbyBzZWxldG9yIG1hbnVhbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTWVzYS9Db21hbmRhIG1haXMgYWJhaXhvIOKAlCBjb21vIGFkZE11dGF0aW9uIGFpbmRhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBlc3TDoSBlbSB2b28gKGFzc8OtbmNyb25vKSBlIG8gbW9kYWwgc8OzIGZlY2hhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBxdWFuZG8gZWxlIHJlc29sdmUgKG9uU3VjY2VzcyBsaW1wYSBwZW5kaW5nT3JkZXIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdW0gXCJzZWxlY3RcIiBwcmVtYXR1cm8gYXF1aSBmYXppYSBvIHNlbGV0b3IgTWVzYS9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIENvbWFuZGEgKHF1ZSBzw7MgZGV2aWEgZXhpc3RpciBjb20gSXNRclZpZXdFbmFibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsaWdhZG8pIGFwYXJlY2VyIGRlIHJlbGFuY2Ug4oCUIG91IGZpY2FyIHByZXNvIOKAlCBsb2dvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkZXBvaXMgZGUgdW0gZXNjYW5lYW1lbnRvIGJlbS1zdWNlZGlkbywgbWVzbW8gY29tXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJc1FyVmlld0VuYWJsZWQgZGVzbGlnYWRvLiBcInN1Ym1pdHRpbmdcIiBtb3N0cmEgdW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGluZGljYWRvciBuZXV0cm8gYXTDqSBhIG11dGF0aW9uIHRlcm1pbmFyLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0T3JkZXJWYWxpZGF0aW9uU3RlcChcInN1Ym1pdHRpbmdcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRNdXRhdGlvbi5tdXRhdGUoeyAuLi5wZW5kaW5nT3JkZXIsIGNvbWFuZGFDb2RlOiBjb2RlIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0T3JkZXJWYWxpZGF0aW9uU3RlcChcInNlbGVjdFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DYW5jZWw9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGVuZGluZ09yZGVyKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRPcmRlclZhbGlkYXRpb25TdGVwKFwic2VsZWN0XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogb3JkZXJWYWxpZGF0aW9uU3RlcCA9PT0gXCJzdWJtaXR0aW5nXCIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIGNvbG9yOiBcIiNhOGE4YjNcIiwgbWFyZ2luOiBcIjI0cHggMFwiIH19PkVudmlhbmRvIHBlZGlkb+KApjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIHN0eWxlPXt7IG1hcmdpblRvcDogMCwgbWFyZ2luQm90dG9tOiAyNCwgY29sb3I6IFwiI2ZmZlwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiwgdGV4dEFsaWduOiBcImNlbnRlclwiIH19Pk9uZGUgZGVzZWphIGFub3RhciBlc3RlIHBlZGlkbz88L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTIsIG1hcmdpbkJvdHRvbTogZGVzdGluYXRpb24gPT09IFwiY29tYW5kYVwiID8gMTYgOiAyNCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXREZXN0aW5hdGlvbihcIm1lc2FcIil9IHN0eWxlPXt7IGZsZXg6IDEsIHBhZGRpbmc6IFwiMTRweFwiLCBib3JkZXJSYWRpdXM6IDgsIGJvcmRlcjogZGVzdGluYXRpb24gPT09IFwibWVzYVwiID8gXCIycHggc29saWQgI2Y1OWUwYlwiIDogXCIxcHggc29saWQgIzMyMzIzOFwiLCBiYWNrZ3JvdW5kQ29sb3I6IGRlc3RpbmF0aW9uID09PSBcIm1lc2FcIiA/IFwicmdiYSgyNDUsIDE1OCwgMTEsIDAuMSlcIiA6IFwidHJhbnNwYXJlbnRcIiwgY29sb3I6IGRlc3RpbmF0aW9uID09PSBcIm1lc2FcIiA/IFwiI2Y1OWUwYlwiIDogXCIjYThhOGIzXCIsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBjdXJzb3I6IFwicG9pbnRlclwiIH19Pk5hIE1lc2E8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXREZXN0aW5hdGlvbihcImNvbWFuZGFcIil9IHN0eWxlPXt7IGZsZXg6IDEsIHBhZGRpbmc6IFwiMTRweFwiLCBib3JkZXJSYWRpdXM6IDgsIGJvcmRlcjogZGVzdGluYXRpb24gPT09IFwiY29tYW5kYVwiID8gXCIycHggc29saWQgI2Y1OWUwYlwiIDogXCIxcHggc29saWQgIzMyMzIzOFwiLCBiYWNrZ3JvdW5kQ29sb3I6IGRlc3RpbmF0aW9uID09PSBcImNvbWFuZGFcIiA/IFwicmdiYSgyNDUsIDE1OCwgMTEsIDAuMSlcIiA6IFwidHJhbnNwYXJlbnRcIiwgY29sb3I6IGRlc3RpbmF0aW9uID09PSBcImNvbWFuZGFcIiA/IFwiI2Y1OWUwYlwiIDogXCIjYThhOGIzXCIsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBjdXJzb3I6IFwicG9pbnRlclwiIH19Pk5hIENvbWFuZGE8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGVzdGluYXRpb24gPT09IFwiY29tYW5kYVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDI0IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiYmxvY2tcIiwgY29sb3I6IFwiI2E4YThiM1wiLCBtYXJnaW5Cb3R0b206IDgsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19Pk7Dum1lcm8gZGEgQ29tYW5kYTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17Y29tbWFuZE51bWJlcn0gb25DaGFuZ2U9eyhlKSA9PiBzZXRDb21tYW5kTnVtYmVyKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFeDogMDAxXCIgYXV0b0ZvY3VzIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgcGFkZGluZzogXCIxNHB4IDE2cHhcIiwgYm9yZGVyUmFkaXVzOiA4LCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiwgYmFja2dyb3VuZENvbG9yOiBcIiMxMjEyMTRcIiwgY29sb3I6IFwiI2ZmZlwiLCBmb250U2l6ZTogXCIxcmVtXCIsIG91dGxpbmU6IFwibm9uZVwiLCBib3hTaXppbmc6IFwiYm9yZGVyLWJveFwiIH19IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7IHNldFBlbmRpbmdPcmRlcihudWxsKTsgc2V0Q29tbWFuZE51bWJlcihcIlwiKTsgc2V0T3JkZXJWYWxpZGF0aW9uU3RlcChcInNlbGVjdFwiKTsgfX0gc3R5bGU9e3sgZmxleDogMSwgcGFkZGluZzogXCIxNHB4XCIsIGJvcmRlclJhZGl1czogOCwgYm9yZGVyOiBcIm5vbmVcIiwgYmFja2dyb3VuZENvbG9yOiBcIiMzMjMyMzhcIiwgY29sb3I6IFwiI2ZmZlwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgY3Vyc29yOiBcInBvaW50ZXJcIiB9fT5DYW5jZWxhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGRpc2FibGVkPXsoZGVzdGluYXRpb24gPT09IFwiY29tYW5kYVwiICYmICFjb21tYW5kTnVtYmVyKSB8fCBhZGRNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9e2hhbmRsZUNvbmZpcm1QZW5kaW5nT3JkZXJ9IHN0eWxlPXt7IGZsZXg6IDEsIHBhZGRpbmc6IFwiMTRweFwiLCBib3JkZXJSYWRpdXM6IDgsIGJvcmRlcjogXCJub25lXCIsIGJhY2tncm91bmRDb2xvcjogXCIjZjU5ZTBiXCIsIGNvbG9yOiBcIiMxMjEyMTRcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGN1cnNvcjogXCJwb2ludGVyXCIgfX0+e2FkZE11dGF0aW9uLmlzUGVuZGluZyA/IFwiRW52aWFuZG8uLi5cIiA6IFwiQ29uZmlybWFyXCJ9PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3B1YmxpY09yZGVyaW5nL1B1YmxpY09yZGVyUGFnZS50c3gifQ==