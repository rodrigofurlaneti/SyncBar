import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DashboardCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const TREND_META = {
  up: { color: "#4caf50", arrow: "↑" },
  down: { color: "#f44336", arrow: "↓" },
  neutral: { color: "#999", arrow: "→" }
};
export function DashboardCard({
  title,
  value,
  icon,
  subtitle,
  trend,
  status = "info",
  onClick,
  loading = false,
  children
}) {
  const statusColors = {
    success: { bg: "#e8f5e9", border: "#4caf50", text: "#1b5e20", icon: "✓" },
    warning: { bg: "#fff3e0", border: "#f57c00", text: "#e65100", icon: "⚠" },
    error: { bg: "#ffebee", border: "#f44336", text: "#b71c1c", icon: "✕" },
    info: { bg: "#e3f2fd", border: "#2196f3", text: "#0d47a1", icon: "ℹ" }
  };
  const colors = statusColors[status];
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      onClick,
      onKeyDown: onClick ? (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClick();
        }
      } : void 0,
      role: onClick ? "button" : void 0,
      tabIndex: onClick ? 0 : void 0,
      style: {
        padding: 16,
        borderRadius: 8,
        background: colors.bg,
        border: `2px solid ${colors.border}`,
        cursor: onClick ? "pointer" : "default",
        transition: onClick ? "transform 0.2s, box-shadow 0.2s" : "none",
        display: "flex",
        flexDirection: "column",
        gap: 12
      },
      onMouseEnter: (e) => {
        if (onClick) {
          e.currentTarget.style.transform = "translateY(-4px)";
          e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.1)";
        }
      },
      onMouseLeave: (e) => {
        if (onClick) {
          e.currentTarget.style.transform = "translateY(0)";
          e.currentTarget.style.boxShadow = "none";
        }
      },
      children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start" }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.75rem", fontWeight: 600, color: colors.text, margin: 0, opacity: 0.8 }, children: title }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
              lineNumber: 101,
              columnNumber: 11
            }, this),
            subtitle && /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.7rem", color: colors.text, margin: "4px 0 0", opacity: 0.6 }, children: subtitle }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
              lineNumber: 105,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
            lineNumber: 100,
            columnNumber: 9
          }, this),
          icon && /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.5rem" }, children: icon }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
            lineNumber: 110,
            columnNumber: 18
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
          lineNumber: 99,
          columnNumber: 7
        }, this),
        loading ? /* @__PURE__ */ jsxDEV("div", { style: { height: 24, background: "rgba(255,255,255,0.3)", borderRadius: 4 } }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
          lineNumber: 114,
          columnNumber: 7
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          value && /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                fontSize: "1.5rem",
                fontWeight: 700,
                color: colors.text,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis"
              },
              children: value
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
              lineNumber: 118,
              columnNumber: 9
            },
            this
          ),
          trend && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 4 }, children: /* @__PURE__ */ jsxDEV(
            "span",
            {
              style: {
                fontSize: "0.85rem",
                color: TREND_META[trend.direction].color
              },
              children: [
                TREND_META[trend.direction].arrow,
                trend.percentage.toFixed(1),
                "%"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
              lineNumber: 134,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
            lineNumber: 133,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
          lineNumber: 116,
          columnNumber: 7
        }, this),
        children
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx",
      lineNumber: 61,
      columnNumber: 5
    },
    this
  );
}
_c = DashboardCard;
var _c;
$RefreshReg$(_c, "DashboardCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/DashboardCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUZVLFNBZUYsVUFmRTs7Ozs7Ozs7Ozs7Ozs7OztBQS9FVixNQUFNQSxhQUFrRjtBQUFBLEVBQ3RGQyxJQUFJLEVBQUVDLE9BQU8sV0FBV0MsT0FBTyxJQUFJO0FBQUEsRUFDbkNDLE1BQU0sRUFBRUYsT0FBTyxXQUFXQyxPQUFPLElBQUk7QUFBQSxFQUNyQ0UsU0FBUyxFQUFFSCxPQUFPLFFBQVFDLE9BQU8sSUFBSTtBQUN2QztBQWNPLGdCQUFTRyxjQUFjO0FBQUEsRUFDNUJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFNBQVM7QUFBQSxFQUNUQztBQUFBQSxFQUNBQyxVQUFVO0FBQUEsRUFDVkM7QUFDa0IsR0FBRztBQUNyQixRQUFNQyxlQUFlO0FBQUEsSUFDbkJDLFNBQVMsRUFBRUMsSUFBSSxXQUFXQyxRQUFRLFdBQVdDLE1BQU0sV0FBV1gsTUFBTSxJQUFJO0FBQUEsSUFDeEVZLFNBQVMsRUFBRUgsSUFBSSxXQUFXQyxRQUFRLFdBQVdDLE1BQU0sV0FBV1gsTUFBTSxJQUFJO0FBQUEsSUFDeEVhLE9BQU8sRUFBRUosSUFBSSxXQUFXQyxRQUFRLFdBQVdDLE1BQU0sV0FBV1gsTUFBTSxJQUFJO0FBQUEsSUFDdEVjLE1BQU0sRUFBRUwsSUFBSSxXQUFXQyxRQUFRLFdBQVdDLE1BQU0sV0FBV1gsTUFBTSxJQUFJO0FBQUEsRUFDdkU7QUFFQSxRQUFNZSxTQUFTUixhQUFhSixNQUFNO0FBRWxDLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUNFQyxVQUNJLENBQUNZLE1BQU07QUFDTCxZQUFJQSxFQUFFQyxRQUFRLFdBQVdELEVBQUVDLFFBQVEsS0FBSztBQUN0Q0QsWUFBRUUsZUFBZTtBQUNqQmQsa0JBQVE7QUFBQSxRQUNWO0FBQUEsTUFDRixJQUNBZTtBQUFBQSxNQUVOLE1BQU1mLFVBQVUsV0FBV2U7QUFBQUEsTUFDM0IsVUFBVWYsVUFBVSxJQUFJZTtBQUFBQSxNQUN4QixPQUFPO0FBQUEsUUFDTEMsU0FBUztBQUFBLFFBQ1RDLGNBQWM7QUFBQSxRQUNkQyxZQUFZUCxPQUFPTjtBQUFBQSxRQUNuQkMsUUFBUSxhQUFhSyxPQUFPTCxNQUFNO0FBQUEsUUFDbENhLFFBQVFuQixVQUFVLFlBQVk7QUFBQSxRQUM5Qm9CLFlBQVlwQixVQUFVLG9DQUFvQztBQUFBLFFBQzFEcUIsU0FBUztBQUFBLFFBQ1RDLGVBQWU7QUFBQSxRQUNmQyxLQUFLO0FBQUEsTUFDUDtBQUFBLE1BQ0EsY0FBYyxDQUFDWCxNQUFNO0FBQ25CLFlBQUlaLFNBQVM7QUFDWCxVQUFDWSxFQUFFWSxjQUE4QkMsTUFBTUMsWUFBWTtBQUNuRCxVQUFDZCxFQUFFWSxjQUE4QkMsTUFBTUUsWUFBWTtBQUFBLFFBQ3JEO0FBQUEsTUFDRjtBQUFBLE1BQ0EsY0FBYyxDQUFDZixNQUFNO0FBQ25CLFlBQUlaLFNBQVM7QUFDWCxVQUFDWSxFQUFFWSxjQUE4QkMsTUFBTUMsWUFBWTtBQUNuRCxVQUFDZCxFQUFFWSxjQUE4QkMsTUFBTUUsWUFBWTtBQUFBLFFBQ3JEO0FBQUEsTUFDRjtBQUFBLE1BRUE7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRU4sU0FBUyxRQUFRTyxnQkFBZ0IsaUJBQWlCQyxZQUFZLGFBQWEsR0FDdkY7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxPQUFPLEVBQUVDLFVBQVUsV0FBV0MsWUFBWSxLQUFLMUMsT0FBT3NCLE9BQU9KLE1BQU15QixRQUFRLEdBQUdDLFNBQVMsSUFBSSxHQUMzRnZDLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNDRyxZQUNDLHVCQUFDLE9BQUUsT0FBTyxFQUFFaUMsVUFBVSxVQUFVekMsT0FBT3NCLE9BQU9KLE1BQU15QixRQUFRLFdBQVdDLFNBQVMsSUFBSSxHQUNqRnBDLHNCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUNDRCxRQUFRLHVCQUFDLFNBQUksT0FBTyxFQUFFa0MsVUFBVSxTQUFTLEdBQUlsQyxrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxhQVhyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVDSyxVQUNDLHVCQUFDLFNBQUksT0FBTyxFQUFFaUMsUUFBUSxJQUFJaEIsWUFBWSx5QkFBeUJELGNBQWMsRUFBRSxLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGLElBRWpGLG1DQUNHdEI7QUFBQUEsbUJBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU87QUFBQSxnQkFDTG1DLFVBQVU7QUFBQSxnQkFDVkMsWUFBWTtBQUFBLGdCQUNaMUMsT0FBT3NCLE9BQU9KO0FBQUFBLGdCQUNkNEIsWUFBWTtBQUFBLGdCQUNaQyxVQUFVO0FBQUEsZ0JBQ1ZDLGNBQWM7QUFBQSxjQUNoQjtBQUFBLGNBRUMxQztBQUFBQTtBQUFBQSxZQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdBO0FBQUEsVUFHREcsU0FDQyx1QkFBQyxTQUFJLE9BQU8sRUFBRXVCLFNBQVMsUUFBUVEsWUFBWSxVQUFVTixLQUFLLEVBQUUsR0FDMUQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU87QUFBQSxnQkFDTE8sVUFBVTtBQUFBLGdCQUNWekMsT0FBT0YsV0FBV1csTUFBTXdDLFNBQVMsRUFBRWpEO0FBQUFBLGNBQ3JDO0FBQUEsY0FFQ0Y7QUFBQUEsMkJBQVdXLE1BQU13QyxTQUFTLEVBQUVoRDtBQUFBQSxnQkFDNUJRLE1BQU15QyxXQUFXQyxRQUFRLENBQUM7QUFBQSxnQkFBRTtBQUFBO0FBQUE7QUFBQSxZQVAvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBO0FBQUEsUUFHRHRDO0FBQUFBO0FBQUFBO0FBQUFBLElBdkZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXdGQTtBQUVKO0FBQUN1QyxLQS9HZWhEO0FBQWEsSUFBQWdEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlRSRU5EX01FVEEiLCJ1cCIsImNvbG9yIiwiYXJyb3ciLCJkb3duIiwibmV1dHJhbCIsIkRhc2hib2FyZENhcmQiLCJ0aXRsZSIsInZhbHVlIiwiaWNvbiIsInN1YnRpdGxlIiwidHJlbmQiLCJzdGF0dXMiLCJvbkNsaWNrIiwibG9hZGluZyIsImNoaWxkcmVuIiwic3RhdHVzQ29sb3JzIiwic3VjY2VzcyIsImJnIiwiYm9yZGVyIiwidGV4dCIsIndhcm5pbmciLCJlcnJvciIsImluZm8iLCJjb2xvcnMiLCJlIiwia2V5IiwicHJldmVudERlZmF1bHQiLCJ1bmRlZmluZWQiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwiYmFja2dyb3VuZCIsImN1cnNvciIsInRyYW5zaXRpb24iLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsImN1cnJlbnRUYXJnZXQiLCJzdHlsZSIsInRyYW5zZm9ybSIsImJveFNoYWRvdyIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsIm1hcmdpbiIsIm9wYWNpdHkiLCJoZWlnaHQiLCJ3aGl0ZVNwYWNlIiwib3ZlcmZsb3ciLCJ0ZXh0T3ZlcmZsb3ciLCJkaXJlY3Rpb24iLCJwZXJjZW50YWdlIiwidG9GaXhlZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkRhc2hib2FyZENhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5jb25zdCBUUkVORF9NRVRBOiBSZWNvcmQ8XCJ1cFwiIHwgXCJkb3duXCIgfCBcIm5ldXRyYWxcIiwgeyBjb2xvcjogc3RyaW5nOyBhcnJvdzogc3RyaW5nIH0+ID0ge1xyXG4gIHVwOiB7IGNvbG9yOiBcIiM0Y2FmNTBcIiwgYXJyb3c6IFwi4oaRXCIgfSxcclxuICBkb3duOiB7IGNvbG9yOiBcIiNmNDQzMzZcIiwgYXJyb3c6IFwi4oaTXCIgfSxcclxuICBuZXV0cmFsOiB7IGNvbG9yOiBcIiM5OTlcIiwgYXJyb3c6IFwi4oaSXCIgfSxcclxufTtcclxuXHJcbmludGVyZmFjZSBEYXNoYm9hcmRDYXJkUHJvcHMge1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgdmFsdWU/OiBSZWFjdE5vZGU7XHJcbiAgaWNvbj86IFJlYWN0Tm9kZTtcclxuICBzdWJ0aXRsZT86IHN0cmluZztcclxuICB0cmVuZD86IHsgZGlyZWN0aW9uOiBcInVwXCIgfCBcImRvd25cIiB8IFwibmV1dHJhbFwiOyBwZXJjZW50YWdlOiBudW1iZXIgfTtcclxuICBzdGF0dXM/OiBcInN1Y2Nlc3NcIiB8IFwid2FybmluZ1wiIHwgXCJlcnJvclwiIHwgXCJpbmZvXCI7XHJcbiAgb25DbGljaz86ICgpID0+IHZvaWQ7XHJcbiAgbG9hZGluZz86IGJvb2xlYW47XHJcbiAgY2hpbGRyZW4/OiBSZWFjdE5vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBEYXNoYm9hcmRDYXJkKHtcclxuICB0aXRsZSxcclxuICB2YWx1ZSxcclxuICBpY29uLFxyXG4gIHN1YnRpdGxlLFxyXG4gIHRyZW5kLFxyXG4gIHN0YXR1cyA9IFwiaW5mb1wiLFxyXG4gIG9uQ2xpY2ssXHJcbiAgbG9hZGluZyA9IGZhbHNlLFxyXG4gIGNoaWxkcmVuLFxyXG59OiBEYXNoYm9hcmRDYXJkUHJvcHMpIHtcclxuICBjb25zdCBzdGF0dXNDb2xvcnMgPSB7XHJcbiAgICBzdWNjZXNzOiB7IGJnOiBcIiNlOGY1ZTlcIiwgYm9yZGVyOiBcIiM0Y2FmNTBcIiwgdGV4dDogXCIjMWI1ZTIwXCIsIGljb246IFwi4pyTXCIgfSxcclxuICAgIHdhcm5pbmc6IHsgYmc6IFwiI2ZmZjNlMFwiLCBib3JkZXI6IFwiI2Y1N2MwMFwiLCB0ZXh0OiBcIiNlNjUxMDBcIiwgaWNvbjogXCLimqBcIiB9LFxyXG4gICAgZXJyb3I6IHsgYmc6IFwiI2ZmZWJlZVwiLCBib3JkZXI6IFwiI2Y0NDMzNlwiLCB0ZXh0OiBcIiNiNzFjMWNcIiwgaWNvbjogXCLinJVcIiB9LFxyXG4gICAgaW5mbzogeyBiZzogXCIjZTNmMmZkXCIsIGJvcmRlcjogXCIjMjE5NmYzXCIsIHRleHQ6IFwiIzBkNDdhMVwiLCBpY29uOiBcIuKEuVwiIH0sXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sb3JzID0gc3RhdHVzQ29sb3JzW3N0YXR1c107XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XHJcbiAgICAgIG9uS2V5RG93bj17XHJcbiAgICAgICAgb25DbGlja1xyXG4gICAgICAgICAgPyAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiIHx8IGUua2V5ID09PSBcIiBcIikge1xyXG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgb25DbGljaygpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgfVxyXG4gICAgICByb2xlPXtvbkNsaWNrID8gXCJidXR0b25cIiA6IHVuZGVmaW5lZH1cclxuICAgICAgdGFiSW5kZXg9e29uQ2xpY2sgPyAwIDogdW5kZWZpbmVkfVxyXG4gICAgICBzdHlsZT17e1xyXG4gICAgICAgIHBhZGRpbmc6IDE2LFxyXG4gICAgICAgIGJvcmRlclJhZGl1czogOCxcclxuICAgICAgICBiYWNrZ3JvdW5kOiBjb2xvcnMuYmcsXHJcbiAgICAgICAgYm9yZGVyOiBgMnB4IHNvbGlkICR7Y29sb3JzLmJvcmRlcn1gLFxyXG4gICAgICAgIGN1cnNvcjogb25DbGljayA/IFwicG9pbnRlclwiIDogXCJkZWZhdWx0XCIsXHJcbiAgICAgICAgdHJhbnNpdGlvbjogb25DbGljayA/IFwidHJhbnNmb3JtIDAuMnMsIGJveC1zaGFkb3cgMC4yc1wiIDogXCJub25lXCIsXHJcbiAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICAgICAgICBnYXA6IDEyLFxyXG4gICAgICB9fVxyXG4gICAgICBvbk1vdXNlRW50ZXI9eyhlKSA9PiB7XHJcbiAgICAgICAgaWYgKG9uQ2xpY2spIHtcclxuICAgICAgICAgIChlLmN1cnJlbnRUYXJnZXQgYXMgSFRNTEVsZW1lbnQpLnN0eWxlLnRyYW5zZm9ybSA9IFwidHJhbnNsYXRlWSgtNHB4KVwiO1xyXG4gICAgICAgICAgKGUuY3VycmVudFRhcmdldCBhcyBIVE1MRWxlbWVudCkuc3R5bGUuYm94U2hhZG93ID0gXCIwIDRweCAxMnB4IHJnYmEoMCwwLDAsMC4xKVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgfX1cclxuICAgICAgb25Nb3VzZUxlYXZlPXsoZSkgPT4ge1xyXG4gICAgICAgIGlmIChvbkNsaWNrKSB7XHJcbiAgICAgICAgICAoZS5jdXJyZW50VGFyZ2V0IGFzIEhUTUxFbGVtZW50KS5zdHlsZS50cmFuc2Zvcm0gPSBcInRyYW5zbGF0ZVkoMClcIjtcclxuICAgICAgICAgIChlLmN1cnJlbnRUYXJnZXQgYXMgSFRNTEVsZW1lbnQpLnN0eWxlLmJveFNoYWRvdyA9IFwibm9uZVwiO1xyXG4gICAgICAgIH1cclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBhbGlnbkl0ZW1zOiBcImZsZXgtc3RhcnRcIiB9fT5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6IFwiMC43NXJlbVwiLCBmb250V2VpZ2h0OiA2MDAsIGNvbG9yOiBjb2xvcnMudGV4dCwgbWFyZ2luOiAwLCBvcGFjaXR5OiAwLjggfX0+XHJcbiAgICAgICAgICAgIHt0aXRsZX1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIHtzdWJ0aXRsZSAmJiAoXHJcbiAgICAgICAgICAgIDxwIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuN3JlbVwiLCBjb2xvcjogY29sb3JzLnRleHQsIG1hcmdpbjogXCI0cHggMCAwXCIsIG9wYWNpdHk6IDAuNiB9fT5cclxuICAgICAgICAgICAgICB7c3VidGl0bGV9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge2ljb24gJiYgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjVyZW1cIiB9fT57aWNvbn08L2Rpdj59XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBoZWlnaHQ6IDI0LCBiYWNrZ3JvdW5kOiBcInJnYmEoMjU1LDI1NSwyNTUsMC4zKVwiLCBib3JkZXJSYWRpdXM6IDQgfX0gLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAge3ZhbHVlICYmIChcclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxLjVyZW1cIixcclxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDcwMCxcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMudGV4dCxcclxuICAgICAgICAgICAgICAgIHdoaXRlU3BhY2U6IFwibm93cmFwXCIsXHJcbiAgICAgICAgICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcclxuICAgICAgICAgICAgICAgIHRleHRPdmVyZmxvdzogXCJlbGxpcHNpc1wiLFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7dmFsdWV9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7dHJlbmQgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjAuODVyZW1cIixcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IFRSRU5EX01FVEFbdHJlbmQuZGlyZWN0aW9uXS5jb2xvcixcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge1RSRU5EX01FVEFbdHJlbmQuZGlyZWN0aW9uXS5hcnJvd31cclxuICAgICAgICAgICAgICAgIHt0cmVuZC5wZXJjZW50YWdlLnRvRml4ZWQoMSl9JVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9EYXNoYm9hcmRDYXJkLnRzeCJ9