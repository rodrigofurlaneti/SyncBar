import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PageHeader.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function PageHeader({ title, subtitle, actions, breadcrumb }) {
  return /* @__PURE__ */ jsxDEV("header", { style: { marginBottom: 24, display: "grid", gap: 16 }, children: [
    breadcrumb && breadcrumb.length > 0 && /* @__PURE__ */ jsxDEV("nav", { style: { fontSize: "0.85rem" }, children: breadcrumb.map(
      (crumb, idx) => /* @__PURE__ */ jsxDEV("span", { children: [
        idx > 0 && /* @__PURE__ */ jsxDEV("span", { style: { margin: "0 8px", color: "var(--ink-faint)" }, children: "/" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx",
          lineNumber: 36,
          columnNumber: 27
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: crumb.href, style: { color: "var(--ink)", textDecoration: "none" }, children: crumb.label }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx",
          lineNumber: 37,
          columnNumber: 15
        }, this)
      ] }, idx, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
      /* @__PURE__ */ jsxDEV("h1", { style: { fontSize: "2rem", fontWeight: 600, margin: 0 }, children: title }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx",
        lineNumber: 46,
        columnNumber: 9
      }, this),
      subtitle && /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.95rem", color: "var(--ink-faint)", margin: 0 }, children: subtitle }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx",
        lineNumber: 48,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    actions && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12, justifyContent: "flex-end" }, children: actions }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx",
      lineNumber: 55,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx",
    lineNumber: 31,
    columnNumber: 5
  }, this);
}
_c = PageHeader;
var _c;
$RefreshReg$(_c, "PageHeader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/PageHeader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0IwQjs7Ozs7Ozs7Ozs7Ozs7OztBQVBuQixnQkFBU0EsV0FBVyxFQUFFQyxPQUFPQyxVQUFVQyxTQUFTQyxXQUE0QixHQUFHO0FBQ3BGLFNBQ0UsdUJBQUMsWUFBTyxPQUFPLEVBQUVDLGNBQWMsSUFBSUMsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDekRIO0FBQUFBLGtCQUFjQSxXQUFXSSxTQUFTLEtBQ2pDLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxVQUFVLFVBQVUsR0FDL0JMLHFCQUFXTTtBQUFBQSxNQUFJLENBQUNDLE9BQU9DLFFBQ3RCLHVCQUFDLFVBQ0VBO0FBQUFBLGNBQU0sS0FBSyx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsUUFBUSxTQUFTQyxPQUFPLG1CQUFtQixHQUFHLGlCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThEO0FBQUEsUUFDMUUsdUJBQUMsT0FBRSxNQUFNSCxNQUFNSSxNQUFNLE9BQU8sRUFBRUQsT0FBTyxjQUFjRSxnQkFBZ0IsT0FBTyxHQUN2RUwsZ0JBQU1NLFNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKU0wsS0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxJQUNELEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFHRix1QkFBQyxTQUFJLE9BQU8sRUFBRU4sU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSw2QkFBQyxRQUFHLE9BQU8sRUFBRUUsVUFBVSxRQUFRUyxZQUFZLEtBQUtMLFFBQVEsRUFBRSxHQUFJWixtQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRTtBQUFBLE1BQ25FQyxZQUNDLHVCQUFDLE9BQUUsT0FBTyxFQUFFTyxVQUFVLFdBQVdLLE9BQU8sb0JBQW9CRCxRQUFRLEVBQUUsR0FDbkVYLHNCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQ0MsV0FDQyx1QkFBQyxTQUFJLE9BQU8sRUFBRUcsU0FBUyxRQUFRQyxLQUFLLElBQUlZLGdCQUFnQixXQUFXLEdBQ2hFaEIscUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQTtBQUVKO0FBQUNpQixLQWhDZXBCO0FBQVUsSUFBQW9CO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlBhZ2VIZWFkZXIiLCJ0aXRsZSIsInN1YnRpdGxlIiwiYWN0aW9ucyIsImJyZWFkY3J1bWIiLCJtYXJnaW5Cb3R0b20iLCJkaXNwbGF5IiwiZ2FwIiwibGVuZ3RoIiwiZm9udFNpemUiLCJtYXAiLCJjcnVtYiIsImlkeCIsIm1hcmdpbiIsImNvbG9yIiwiaHJlZiIsInRleHREZWNvcmF0aW9uIiwibGFiZWwiLCJmb250V2VpZ2h0IiwianVzdGlmeUNvbnRlbnQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYWdlSGVhZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmludGVyZmFjZSBQYWdlSGVhZGVyUHJvcHMge1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgc3VidGl0bGU/OiBzdHJpbmc7XHJcbiAgYWN0aW9ucz86IFJlYWN0Tm9kZTtcclxuICBicmVhZGNydW1iPzogQXJyYXk8eyBsYWJlbDogc3RyaW5nOyBocmVmOiBzdHJpbmcgfT47XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBQYWdlSGVhZGVyKHsgdGl0bGUsIHN1YnRpdGxlLCBhY3Rpb25zLCBicmVhZGNydW1iIH06IFBhZ2VIZWFkZXJQcm9wcykge1xyXG4gIHJldHVybiAoXHJcbiAgICA8aGVhZGVyIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMjQsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE2IH19PlxyXG4gICAgICB7YnJlYWRjcnVtYiAmJiBicmVhZGNydW1iLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgIDxuYXYgc3R5bGU9e3sgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAge2JyZWFkY3J1bWIubWFwKChjcnVtYiwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgIDxzcGFuIGtleT17aWR4fT5cclxuICAgICAgICAgICAgICB7aWR4ID4gMCAmJiA8c3BhbiBzdHlsZT17eyBtYXJnaW46IFwiMCA4cHhcIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19Pi88L3NwYW4+fVxyXG4gICAgICAgICAgICAgIDxhIGhyZWY9e2NydW1iLmhyZWZ9IHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluaylcIiwgdGV4dERlY29yYXRpb246IFwibm9uZVwiIH19PlxyXG4gICAgICAgICAgICAgICAge2NydW1iLmxhYmVsfVxyXG4gICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9uYXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgPGgxIHN0eWxlPXt7IGZvbnRTaXplOiBcIjJyZW1cIiwgZm9udFdlaWdodDogNjAwLCBtYXJnaW46IDAgfX0+e3RpdGxlfTwvaDE+XHJcbiAgICAgICAge3N1YnRpdGxlICYmIChcclxuICAgICAgICAgIDxwIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOTVyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBtYXJnaW46IDAgfX0+XHJcbiAgICAgICAgICAgIHtzdWJ0aXRsZX1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHthY3Rpb25zICYmIChcclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEyLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAge2FjdGlvbnN9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2hlYWRlcj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1BhZ2VIZWFkZXIudHN4In0=