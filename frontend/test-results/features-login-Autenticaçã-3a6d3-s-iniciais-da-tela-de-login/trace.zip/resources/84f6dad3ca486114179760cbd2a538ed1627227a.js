import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/DeliveryBoardPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getOpenOrdersByBranch, getOrder, updateItemStatus } from "/src/features/orders/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useToast } from "/src/ui/Toast.tsx";
import { ApiError } from "/src/lib/apiClient.ts";
import { OrderDrawer } from "/src/features/orders/OrderDrawer.tsx";
import { OpenDeliveryOrderDialog } from "/src/features/orders/OpenDeliveryOrderDialog.tsx";
import { OrderItemStatus, OrderStatus, OrderType, formatBRL } from "/src/lib/types.ts";
import bagImg from "/src/image/bag.png?import";
import doorbellImg from "/src/image/doorbell.png?import";
import packageImg from "/src/image/package.png?import";
import positionImg from "/src/image/position.png?import";
import bagcheckImg from "/src/image/bagcheck.png?import";
import calendarImg from "/src/image/calendar.png?import";
import motorcycleImg from "/src/image/motorcycle.jpeg?import";
import screenBgImg from "/src/image/screenbackground.jpeg?import";
const VIEW_MODE_KEY = "syncbar:delivery-view-mode";
const ON_ROUTE_KEY = "syncbar:delivery-on-route";
const GHOST_LIMIT = 40;
const CHANNEL_FILTER_LABELS = {
  todos: "Todos",
  delivery: "Delivery",
  retirada: "Retirada"
};
function loadViewMode() {
  try {
    return localStorage.getItem(VIEW_MODE_KEY) === "completo" ? "completo" : "simples";
  } catch {
    return "simples";
  }
}
function loadOnRoute() {
  try {
    const stored = localStorage.getItem(ON_ROUTE_KEY);
    return stored ? new Set(JSON.parse(stored)) : /* @__PURE__ */ new Set();
  } catch {
    return /* @__PURE__ */ new Set();
  }
}
function persistOnRoute(ids) {
  try {
    localStorage.setItem(ON_ROUTE_KEY, JSON.stringify([...ids]));
  } catch {
  }
}
const isDeliveryBoardOrder = (order) => order.diningTableId === null && order.comandaId === null;
const getChannel = (order) => order.orderTypeId === OrderType.Delivery ? "delivery" : "retirada";
const READY_ITEM_STATUSES = /* @__PURE__ */ new Set([OrderItemStatus.Pronto, OrderItemStatus.Entregue]);
function deriveStage(order, onRoute) {
  if (order.orderStatusId === OrderStatus.Cancelado) return "cancelado";
  if (order.orderStatusId === OrderStatus.Pago) return "entregue";
  const activeItems = order.items.filter((i) => i.orderItemStatusId !== OrderItemStatus.Cancelado);
  const allReady = activeItems.length > 0 && activeItems.every((i) => READY_ITEM_STATUSES.has(i.orderItemStatusId));
  const anyStarted = activeItems.some((i) => i.orderItemStatusId >= OrderItemStatus.EnviadoCozinha);
  if (order.orderStatusId === OrderStatus.AguardandoPagamento || allReady)
    return onRoute.has(order.id) ? "rota" : "aguardando";
  if (anyStarted) return "cozinha";
  return "novo";
}
function elapsedLabel(openedAt) {
  const opened = new Date(openedAt).getTime();
  const minutes = Math.max(0, Math.round((Date.now() - opened) / 6e4));
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h${String(minutes % 60).padStart(2, "0")}`;
}
const illustrationStyle = { height: 140, objectFit: "contain" };
const FULL_COLUMNS = [
  {
    id: "novo",
    label: "NOVOS PEDIDOS",
    hint: "Aguardando aceite",
    themeColor: "#FF6B00",
    icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", style: { width: 20, height: 20 }, children: [
      /* @__PURE__ */ jsxDEV("path", { d: "M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 116,
        columnNumber: 163
      }, this),
      /* @__PURE__ */ jsxDEV("line", { x1: "3", y1: "6", x2: "21", y2: "6" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 116,
        columnNumber: 231
      }, this),
      /* @__PURE__ */ jsxDEV("path", { d: "M16 10a4 4 0 0 1-8 0" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 116,
        columnNumber: 273
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 116,
      columnNumber: 9
    }, this),
    emptyIllustration: /* @__PURE__ */ jsxDEV("img", { src: bagImg, alt: "Novos Pedidos", style: illustrationStyle }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 117,
      columnNumber: 22
    }, this)
  },
  {
    id: "cozinha",
    label: "COZINHA",
    hint: "Aguardando preparo",
    themeColor: "#FF8A00",
    icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", style: { width: 20, height: 20 }, children: /* @__PURE__ */ jsxDEV("path", { d: "M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 121,
      columnNumber: 163
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 121,
      columnNumber: 9
    }, this),
    emptyIllustration: /* @__PURE__ */ jsxDEV("img", { src: doorbellImg, alt: "Cozinha", style: illustrationStyle }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 122,
      columnNumber: 22
    }, this)
  },
  {
    id: "aguardando",
    label: "AGUARDANDO ENTREGA",
    hint: "Separação e conferência",
    themeColor: "#FF5500",
    icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", style: { width: 20, height: 20 }, children: [
      /* @__PURE__ */ jsxDEV("line", { x1: "16.5", y1: "9.4", x2: "7.5", y2: "4.21" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 126,
        columnNumber: 163
      }, this),
      /* @__PURE__ */ jsxDEV("path", { d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 126,
        columnNumber: 214
      }, this),
      /* @__PURE__ */ jsxDEV("polyline", { points: "3.27 6.96 12 12.01 20.73 6.96" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 126,
        columnNumber: 353
      }, this),
      /* @__PURE__ */ jsxDEV("line", { x1: "12", y1: "22.08", x2: "12", y2: "12" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 126,
        columnNumber: 413
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 126,
      columnNumber: 9
    }, this),
    emptyIllustration: /* @__PURE__ */ jsxDEV("img", { src: packageImg, alt: "Aguardando Entrega", style: illustrationStyle }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 127,
      columnNumber: 22
    }, this)
  },
  {
    id: "rota",
    label: "SAIU PARA ENTREGA",
    hint: "Pedidos em rota",
    themeColor: "#FFB800",
    icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", style: { width: 20, height: 20 }, children: [
      /* @__PURE__ */ jsxDEV("path", { d: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 131,
        columnNumber: 163
      }, this),
      /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "10", r: "3" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 131,
        columnNumber: 227
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 131,
      columnNumber: 9
    }, this),
    emptyIllustration: /* @__PURE__ */ jsxDEV("img", { src: positionImg, alt: "Em Rota", style: illustrationStyle }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 132,
      columnNumber: 22
    }, this)
  },
  {
    id: "entregue",
    label: "ENTREGUE",
    hint: "Última hora",
    themeColor: "#F5C344",
    icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", style: { width: 20, height: 20 }, children: /* @__PURE__ */ jsxDEV("polyline", { points: "20 6 9 17 4 12" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 136,
      columnNumber: 163
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 136,
      columnNumber: 9
    }, this),
    emptyIllustration: /* @__PURE__ */ jsxDEV("img", { src: bagcheckImg, alt: "Entregue", style: illustrationStyle }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 137,
      columnNumber: 22
    }, this)
  },
  {
    id: "agendamento",
    label: "AGENDAMENTO",
    hint: "Em breve",
    themeColor: "#B0B0B0",
    placeholder: true,
    icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", style: { width: 20, height: 20 }, children: [
      /* @__PURE__ */ jsxDEV("rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", ry: "2" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 141,
        columnNumber: 163
      }, this),
      /* @__PURE__ */ jsxDEV("line", { x1: "16", y1: "2", x2: "16", y2: "6" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 141,
        columnNumber: 225
      }, this),
      /* @__PURE__ */ jsxDEV("line", { x1: "8", y1: "2", x2: "8", y2: "6" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 141,
        columnNumber: 268
      }, this),
      /* @__PURE__ */ jsxDEV("line", { x1: "3", y1: "10", x2: "21", y2: "10" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 141,
        columnNumber: 309
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 141,
      columnNumber: 9
    }, this),
    emptyIllustration: /* @__PURE__ */ jsxDEV("img", { src: calendarImg, alt: "Agendamento", style: illustrationStyle }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 142,
      columnNumber: 22
    }, this)
  }
];
const SIMPLE_COLUMNS = FULL_COLUMNS.filter(_c = (c) => c.id !== "agendamento" && c.id !== "cancelado");
_c2 = SIMPLE_COLUMNS;
function OrderCard({ order, stage, dense, onOpen, onSendToKitchen, onMarkReady, onMarkOnRoute, busy }) {
  const customerName = order.customerName?.trim() || `Pedido #${order.id}`;
  const channelLabel = getChannel(order) === "delivery" ? "DELIVERY" : "RETIRADA";
  const stop = (fn) => (e) => {
    e.stopPropagation();
    fn();
  };
  return /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onOpen, style: {
    background: "#fff",
    border: "1px solid #EFEFEF",
    borderRadius: 12,
    padding: 16,
    width: "100%",
    textAlign: "left",
    cursor: "pointer",
    display: "flex",
    flexDirection: "column",
    gap: 12,
    boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
    transition: "transform 0.1s"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 800, fontSize: "1.1rem", color: "#1A1A1A" }, children: [
        "#",
        order.id
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 162,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.75rem", fontWeight: 700, padding: "4px 8px", borderRadius: 6, background: "#F5F5F5", color: "#555", display: "flex", alignItems: "center", gap: 4 }, children: [
        channelLabel === "DELIVERY" ? "🛵" : "🏬",
        " ",
        channelLabel
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 163,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 161,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: 4 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 700, color: "#1A1A1A", fontSize: "0.95rem" }, children: customerName }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 169,
        columnNumber: 17
      }, this),
      !dense && order.deliveryAddress && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "#777", lineHeight: 1.3 }, children: order.deliveryAddress }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 171,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 168,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", fontSize: "0.85rem", color: "#555", borderTop: "1px dashed #EEE", paddingTop: 12 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: [
        "R$ ",
        formatBRL(order.totalAmount).replace("R$", "").trim()
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 176,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: [
        order.items.length,
        " ",
        order.items.length === 1 ? "item" : "itens"
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 177,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 175,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "#888", display: "flex", justifyContent: "space-between" }, children: /* @__PURE__ */ jsxDEV("span", { children: [
      "aberto há ",
      elapsedLabel(order.openedAt)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 181,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 180,
      columnNumber: 13
    }, this),
    stage === "novo" && /* @__PURE__ */ jsxDEV("button", { onClick: stop(onSendToKitchen), disabled: busy, style: btnActionStyle, children: busy ? "Enviando…" : "Enviar p/ cozinha" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 184,
      columnNumber: 34
    }, this),
    stage === "cozinha" && /* @__PURE__ */ jsxDEV("button", { onClick: stop(onMarkReady), disabled: busy, style: btnActionStyle, children: busy ? "Atualizando…" : "Pronto p/ saída" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 185,
      columnNumber: 37
    }, this),
    stage === "aguardando" && /* @__PURE__ */ jsxDEV("button", { onClick: stop(onMarkOnRoute), disabled: busy, style: btnActionStyle, children: "Saiu para entrega" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 186,
      columnNumber: 40
    }, this),
    stage === "rota" && /* @__PURE__ */ jsxDEV("button", { onClick: stop(onOpen), disabled: busy, style: btnActionStyle, children: "Confirmar entrega" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 187,
      columnNumber: 34
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
    lineNumber: 156,
    columnNumber: 5
  }, this);
}
_c3 = OrderCard;
const btnActionStyle = {
  width: "100%",
  padding: "10px",
  borderRadius: 8,
  border: "none",
  background: "linear-gradient(90deg, #FF7B00 0%, #FF5500 100%)",
  color: "#fff",
  fontWeight: 700,
  cursor: "pointer",
  marginTop: 4,
  fontSize: "0.9rem"
};
export function DeliveryBoardPage() {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { branchId, employeeId } = useAuthStore();
  const [viewMode, setViewMode] = useState(loadViewMode);
  const [channelFilter, setChannelFilter] = useState("todos");
  const [search, setSearch] = useState("");
  const [onRoute, setOnRoute] = useState(loadOnRoute);
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [openingNew, setOpeningNew] = useState(false);
  const [pendingOrderId, setPendingOrderId] = useState(null);
  const [ghosts, setGhosts] = useState(/* @__PURE__ */ new Map());
  const knownRef = useRef(/* @__PURE__ */ new Map());
  const fetchingRef = useRef(/* @__PURE__ */ new Set());
  useEffect(() => {
    localStorage.setItem(VIEW_MODE_KEY, viewMode);
  }, [viewMode]);
  useEffect(() => {
    const previousTitle = document.title;
    document.title = "Ding.food — Delivery";
    return () => {
      document.title = previousTitle;
    };
  }, []);
  const ordersQuery = useQuery({
    queryKey: ["orders", "open", branchId],
    queryFn: () => getOpenOrdersByBranch(branchId),
    refetchInterval: 15e3
  });
  useEffect(() => {
    if (!ordersQuery.data) return;
    const boardOrders2 = ordersQuery.data.filter(isDeliveryBoardOrder);
    const currentIds = new Set(boardOrders2.map((o) => o.id));
    const vanished = [];
    for (const id of knownRef.current.keys()) {
      if (!currentIds.has(id)) vanished.push(id);
    }
    for (const order of boardOrders2) knownRef.current.set(order.id, order);
    vanished.forEach((id) => {
      if (fetchingRef.current.has(id)) return;
      fetchingRef.current.add(id);
      knownRef.current.delete(id);
      getOrder(id).then((finalOrder) => {
        setGhosts((prev) => {
          const next = new Map(prev);
          next.set(id, finalOrder);
          while (next.size > GHOST_LIMIT) {
            const oldest = next.keys().next().value;
            if (oldest === void 0) break;
            next.delete(oldest);
          }
          return next;
        });
        setOnRoute((prevRoute) => {
          if (!prevRoute.has(id)) return prevRoute;
          const next = new Set(prevRoute);
          next.delete(id);
          persistOnRoute(next);
          return next;
        });
      }).catch(() => {
      }).finally(() => fetchingRef.current.delete(id));
    });
  }, [ordersQuery.data]);
  const boardOrders = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const order of ghosts.values()) if (isDeliveryBoardOrder(order)) map.set(order.id, order);
    for (const order of ordersQuery.data ?? []) if (isDeliveryBoardOrder(order)) map.set(order.id, order);
    return [...map.values()];
  }, [ordersQuery.data, ghosts]);
  const filteredOrders = useMemo(() => {
    const term = search.trim().toLowerCase();
    return boardOrders.filter((order) => {
      if (channelFilter !== "todos" && getChannel(order) !== channelFilter) return false;
      if (term === "") return true;
      const haystack = [String(order.id), order.customerName ?? "", order.deliveryAddress ?? "", order.customerPhone ?? ""].join(" ").toLowerCase();
      return haystack.includes(term);
    });
  }, [boardOrders, channelFilter, search]);
  const ordersByStage = useMemo(() => {
    const map = { novo: [], cozinha: [], aguardando: [], rota: [], entregue: [], cancelado: [] };
    for (const order of filteredOrders) map[deriveStage(order, onRoute)].push(order);
    for (const list of Object.values(map)) list.sort((a, b) => a.id - b.id);
    return map;
  }, [filteredOrders, onRoute]);
  const dashboardMetrics = useMemo(() => {
    const activeOrders = boardOrders.filter((o) => o.orderStatusId !== OrderStatus.Cancelado);
    const total = activeOrders.length;
    const entregues = ordersByStage.entregue.length;
    const andamento = total - entregues;
    let sumMinutes = 0;
    activeOrders.forEach((o) => {
      const opened = new Date(o.openedAt).getTime();
      sumMinutes += Math.max(0, (Date.now() - opened) / 6e4);
    });
    const avgTime = total > 0 ? Math.round(sumMinutes / total) : 0;
    return { total, avgTime, entregues, andamento, agendados: 0 };
  }, [boardOrders, ordersByStage]);
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["orders"] });
  const onErr = (fallback) => (error) => toast.error(error instanceof ApiError ? error.message : fallback);
  const sendToKitchen = useMutation({
    mutationFn: async (order) => {
      const pending = order.items.filter((i) => i.orderItemStatusId === OrderItemStatus.Lancado);
      await Promise.all(pending.map((i) => updateItemStatus(order.id, i.id, OrderItemStatus.EnviadoCozinha, employeeId)));
    },
    onSuccess: (_data, order) => {
      toast.success(`Pedido #${order.id} p/ cozinha.`);
      setPendingOrderId(null);
      refresh();
    },
    onError: (e) => {
      onErr("Falha ao enviar.")(e);
      setPendingOrderId(null);
    }
  });
  const markReady = useMutation({
    mutationFn: async (order) => {
      const pending = order.items.filter((i) => i.orderItemStatusId !== OrderItemStatus.Cancelado && !READY_ITEM_STATUSES.has(i.orderItemStatusId));
      await Promise.all(pending.map((i) => updateItemStatus(order.id, i.id, OrderItemStatus.Pronto, employeeId)));
    },
    onSuccess: (_data, order) => {
      toast.success(`Pedido #${order.id} pronto.`);
      setPendingOrderId(null);
      refresh();
    },
    onError: (e) => {
      onErr("Falha ao marcar.")(e);
      setPendingOrderId(null);
    }
  });
  const handleSendToKitchen = (o) => {
    setPendingOrderId(o.id);
    sendToKitchen.mutate(o);
  };
  const handleMarkReady = (o) => {
    setPendingOrderId(o.id);
    markReady.mutate(o);
  };
  const handleMarkOnRoute = (o) => {
    setOnRoute((prev) => {
      const next = new Set(prev).add(o.id);
      persistOnRoute(next);
      return next;
    });
  };
  const columns = viewMode === "completo" ? FULL_COLUMNS : SIMPLE_COLUMNS;
  const dense = viewMode === "simples";
  return /* @__PURE__ */ jsxDEV("div", { style: {
    backgroundImage: `url(${screenBgImg})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundColor: "#FDF8F4",
    minHeight: "100vh",
    padding: "32px 40px",
    fontFamily: "system-ui, -apple-system, sans-serif",
    display: "flex",
    flexDirection: "column"
  }, children: [
    /* @__PURE__ */ jsxDEV("header", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 32 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("img", { src: motorcycleImg, alt: "Moto de Delivery", style: { width: "clamp(44px, 5vw, 72px)", height: "auto", objectFit: "contain", mixBlendMode: "multiply" } }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 350,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 349,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { style: { fontSize: "2.4rem", fontWeight: 900, color: "#1A1A1A", margin: 0, textTransform: "uppercase", letterSpacing: "-1px" }, children: "Delivery" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 353,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "#777", fontSize: "0.95rem" }, children: "Movimente cada pedido pelas etapas até a entrega" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 354,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 352,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 348,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 24, alignItems: "center" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", background: "#fff", borderRadius: 8, padding: 4, border: "1px solid #EAEAEA", boxShadow: "0 2px 4px rgba(0,0,0,0.02)" }, children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setViewMode("simples"),
              style: { padding: "8px 16px", borderRadius: 6, border: "none", fontWeight: 600, cursor: "pointer", background: viewMode === "simples" ? "#fff" : "transparent", color: viewMode === "simples" ? "#1A1A1A" : "#888", boxShadow: viewMode === "simples" ? "0 2px 8px rgba(0,0,0,0.1)" : "none" },
              children: "Simples"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
              lineNumber: 360,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setViewMode("completo"),
              style: { padding: "8px 16px", borderRadius: 6, border: "none", fontWeight: 600, cursor: "pointer", background: viewMode === "completo" ? "#FF6B00" : "transparent", color: viewMode === "completo" ? "#fff" : "#888", boxShadow: viewMode === "completo" ? "0 2px 8px rgba(255,107,0,0.4)" : "none" },
              children: "Completo"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
              lineNumber: 364,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 359,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setOpeningNew(true), style: { background: "linear-gradient(90deg, #FF7B00 0%, #FF5500 100%)", color: "#fff", border: "none", padding: "12px 24px", borderRadius: 8, fontWeight: 700, fontSize: "1rem", cursor: "pointer", boxShadow: "0 4px 12px rgba(255, 85, 0, 0.3)" }, children: "+ Novo pedido" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 370,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 358,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 347,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 16, marginBottom: 24, alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: ["todos", "delivery", "retirada"].map(
        (c) => /* @__PURE__ */ jsxDEV("button", { onClick: () => setChannelFilter(c), style: {
          padding: "10px 20px",
          borderRadius: 8,
          border: c === channelFilter ? "none" : "1px solid #EAEAEA",
          background: c === channelFilter ? "#FF6B00" : "#fff",
          color: c === channelFilter ? "#fff" : "#555",
          fontWeight: 700,
          cursor: "pointer",
          boxShadow: c === channelFilter ? "0 4px 12px rgba(255,107,0,0.2)" : "0 2px 4px rgba(0,0,0,0.02)"
        }, children: CHANNEL_FILTER_LABELS[c] }, c, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 380,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 378,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { position: "relative", flex: 1, maxWidth: 400 }, children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            placeholder: "Buscar pedido, cliente ou endereço...",
            value: search,
            onChange: (e) => setSearch(e.target.value),
            style: { width: "100%", padding: "12px 16px 12px 40px", borderRadius: 8, border: "1px solid #EAEAEA", background: "#fff", color: "#1A1A1A", fontSize: "0.95rem", boxShadow: "0 2px 4px rgba(0,0,0,0.02)", outline: "none" }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 391,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("svg", { style: { position: "absolute", left: 14, top: 12, width: 18, color: "#999" }, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
          /* @__PURE__ */ jsxDEV("circle", { cx: "11", cy: "11", r: "8" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 399,
            columnNumber: 219
          }, this),
          /* @__PURE__ */ jsxDEV("line", { x1: "21", y1: "21", x2: "16.65", y2: "16.65" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 399,
            columnNumber: 258
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 399,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 390,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { marginLeft: "auto", display: "flex", alignItems: "center", gap: 12, background: "#fff", padding: "8px 16px", borderRadius: 8, border: "1px solid #EAEAEA", fontSize: "0.85rem", color: "#666" }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", alignItems: "center", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("svg", { style: { width: 14 }, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { d: "M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.59-9.21l-5.45-5.45" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 403,
            columnNumber: 182
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 403,
            columnNumber: 85
          }, this),
          " Atualizar em 15s"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 403,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { width: 1, height: 12, background: "#DDD" } }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 404,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", alignItems: "center", gap: 6 }, children: [
          "Atualizado agora há 15s ",
          /* @__PURE__ */ jsxDEV("span", { style: { width: 8, height: 8, background: "#4CAF50", borderRadius: "50%" } }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 405,
            columnNumber: 109
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 405,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 402,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 377,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 16, flex: 1, overflowX: "auto", paddingBottom: 24, minHeight: 400 }, children: columns.map((col) => {
      const items = col.id === "agendamento" ? [] : ordersByStage[col.id] || [];
      return /* @__PURE__ */ jsxDEV("div", { style: { minWidth: 260, width: "16.6%", background: "#fff", borderRadius: 16, padding: "16px", display: "flex", flexDirection: "column", border: "1px solid #EFEFEF", boxShadow: "0 4px 12px rgba(0,0,0,0.02)" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12, marginBottom: 20 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { background: col.themeColor, color: "#fff", width: 42, height: 42, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 4px 10px ${col.themeColor}40` }, children: col.icon }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 418,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 800, fontSize: "0.85rem", color: "#1A1A1A", lineHeight: 1.2 }, children: col.label }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
                lineNumber: 423,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { background: `${col.themeColor}15`, color: col.themeColor, fontWeight: 800, padding: "2px 8px", borderRadius: 12, fontSize: "0.8rem" }, children: items.length }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
                lineNumber: 424,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
              lineNumber: 422,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.75rem", color: "#888", display: "block", marginTop: 2 }, children: col.hint }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
              lineNumber: 428,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 421,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 417,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: 12, flex: 1, overflowY: "auto", position: "relative" }, children: col.placeholder ? /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", padding: 20 }, children: [
          col.emptyIllustration,
          /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", color: "#999", fontSize: "0.85rem", marginTop: 24 }, children: "Agendamento de pedidos existe no SyncBar Delivery, reservado para quando essa funcionalidade for liberada." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 437,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { background: "#F5F5F5", padding: "6px 12px", borderRadius: 12, fontWeight: 600, color: "#888", marginTop: 16, fontSize: "0.8rem" }, children: "Em breve" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 440,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 435,
          columnNumber: 17
        }, this) : items.length === 0 ? /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", opacity: 0.8, marginTop: 40 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 24 }, children: col.emptyIllustration }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 444,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { color: "#BBB", fontSize: "1rem", fontWeight: 600 }, children: "Sem pedidos" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
            lineNumber: 447,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 443,
          columnNumber: 17
        }, this) : items.map(
          (order) => /* @__PURE__ */ jsxDEV(
            OrderCard,
            {
              order,
              stage: col.id,
              dense,
              busy: pendingOrderId === order.id,
              onOpen: () => setSelectedOrderId(order.id),
              onSendToKitchen: () => handleSendToKitchen(order),
              onMarkReady: () => handleMarkReady(order),
              onMarkOnRoute: () => handleMarkOnRoute(order)
            },
            order.id,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
              lineNumber: 451,
              columnNumber: 17
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 433,
          columnNumber: 29
        }, this)
      ] }, col.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 414,
        columnNumber: 13
      }, this);
    }) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 410,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { background: "#111", borderRadius: 16, padding: "24px 40px", display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "auto", boxShadow: "0 10px 40px rgba(255, 107, 0, 0.15)", borderBottom: "4px solid #FF6B00" }, children: [
      /* @__PURE__ */ jsxDEV(DashboardMetric, { icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", style: { width: 24 }, children: [
        /* @__PURE__ */ jsxDEV("path", { d: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 466,
          columnNumber: 137
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "7", r: "4" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 466,
          columnNumber: 196
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 466,
        columnNumber: 40
      }, this), label: "Total de pedidos", value: dashboardMetrics.total, sub: "hoje" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 466,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { width: 1, height: 40, background: "#333" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 467,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(DashboardMetric, { icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", style: { width: 24 }, children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "10" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 468,
          columnNumber: 137
        }, this),
        /* @__PURE__ */ jsxDEV("polyline", { points: "12 6 12 12 16 14" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 468,
          columnNumber: 177
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 468,
        columnNumber: 40
      }, this), label: "Tempo médio", value: dashboardMetrics.avgTime, sub: "min" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 468,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { width: 1, height: 40, background: "#333" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 469,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(DashboardMetric, { icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", style: { width: 24 }, children: [
        /* @__PURE__ */ jsxDEV("path", { d: "M22 11.08V12a10 10 0 1 1-5.93-9.14" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 470,
          columnNumber: 137
        }, this),
        /* @__PURE__ */ jsxDEV("polyline", { points: "22 4 12 14.01 9 11.01" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 470,
          columnNumber: 189
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 470,
        columnNumber: 40
      }, this), label: "Entregues", value: dashboardMetrics.entregues, sub: "hoje" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 470,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { width: 1, height: 40, background: "#333" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 471,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(DashboardMetric, { icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", style: { width: 24 }, children: [
        /* @__PURE__ */ jsxDEV("polyline", { points: "23 4 23 10 17 10" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 472,
          columnNumber: 137
        }, this),
        /* @__PURE__ */ jsxDEV("polyline", { points: "1 20 1 14 7 14" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 472,
          columnNumber: 184
        }, this),
        /* @__PURE__ */ jsxDEV("path", { d: "M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 472,
          columnNumber: 229
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 472,
        columnNumber: 40
      }, this), label: "Em andamento", value: dashboardMetrics.andamento, sub: "agora" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 472,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { width: 1, height: 40, background: "#333" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 473,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(DashboardMetric, { icon: /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", style: { width: 24 }, children: [
        /* @__PURE__ */ jsxDEV("rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", ry: "2" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 474,
          columnNumber: 137
        }, this),
        /* @__PURE__ */ jsxDEV("line", { x1: "16", y1: "2", x2: "16", y2: "6" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 474,
          columnNumber: 199
        }, this),
        /* @__PURE__ */ jsxDEV("line", { x1: "8", y1: "2", x2: "8", y2: "6" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 474,
          columnNumber: 242
        }, this),
        /* @__PURE__ */ jsxDEV("line", { x1: "3", y1: "10", x2: "21", y2: "10" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 474,
          columnNumber: 283
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 474,
        columnNumber: 40
      }, this), label: "Agendados", value: dashboardMetrics.agendados, sub: "próximos dias" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 474,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 465,
      columnNumber: 13
    }, this),
    selectedOrderId !== null && /* @__PURE__ */ jsxDEV(OrderDrawer, { orderId: selectedOrderId, onClose: () => {
      setSelectedOrderId(null);
      refresh();
    } }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 477,
      columnNumber: 42
    }, this),
    openingNew && /* @__PURE__ */ jsxDEV(OpenDeliveryOrderDialog, { onClose: () => setOpeningNew(false), onOpened: (orderId) => {
      setOpeningNew(false);
      refresh();
      setSelectedOrderId(orderId);
    } }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 478,
      columnNumber: 28
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
    lineNumber: 334,
    columnNumber: 5
  }, this);
}
_s(DeliveryBoardPage, "hFPs8Z22XXWn1K6Eewh3YQlGV4M=", false, function() {
  return [useQueryClient, useToast, useAuthStore, useQuery, useMutation, useMutation];
});
_c4 = DeliveryBoardPage;
function DashboardMetric({ icon, label, value, sub }) {
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 16 }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { color: "#FF6B00", border: "1.5px solid #FF6B00", borderRadius: 12, width: 48, height: 48, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(255, 107, 0, 0.1)" }, children: icon }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 486,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column" }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "#888", fontWeight: 500 }, children: label }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 488,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "baseline", gap: 6 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "1.8rem", fontWeight: 800, color: "#fff", lineHeight: 1.1 }, children: value > 0 ? value : "--" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 490,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "#888" }, children: sub }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
          lineNumber: 491,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
        lineNumber: 489,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
      lineNumber: 487,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx",
    lineNumber: 485,
    columnNumber: 5
  }, this);
}
_c5 = DashboardMetric;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "SIMPLE_COLUMNS$FULL_COLUMNS.filter");
$RefreshReg$(_c2, "SIMPLE_COLUMNS");
$RefreshReg$(_c3, "OrderCard");
$RefreshReg$(_c4, "DeliveryBoardPage");
$RefreshReg$(_c5, "DashboardMetric");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/DeliveryBoardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0d3Szs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFoR3ZLLFNBQWdCQSxXQUFXQyxTQUFTQyxRQUFRQyxnQkFBZ0I7QUFDN0QsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLHVCQUF1QkMsVUFBVUMsd0JBQXdCO0FBQ2xFLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQywrQkFBK0I7QUFDeEMsU0FBU0MsaUJBQWlCQyxhQUFhQyxXQUFXQyxpQkFBaUI7QUFLbkUsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxpQkFBaUI7QUFPeEIsTUFBTUMsZ0JBQWdCO0FBQ3RCLE1BQU1DLGVBQWU7QUFDckIsTUFBTUMsY0FBYztBQUVwQixNQUFNQyx3QkFBdUQ7QUFBQSxFQUN6REMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFBQSxFQUNWQyxVQUFVO0FBQ2Q7QUFHQSxTQUFTQyxlQUF5QjtBQUM5QixNQUFJO0FBQUUsV0FBT0MsYUFBYUMsUUFBUVQsYUFBYSxNQUFNLGFBQWEsYUFBYTtBQUFBLEVBQVcsUUFDcEY7QUFBRSxXQUFPO0FBQUEsRUFBVztBQUM5QjtBQUVBLFNBQVNVLGNBQTJCO0FBQ2hDLE1BQUk7QUFDQSxVQUFNQyxTQUFTSCxhQUFhQyxRQUFRUixZQUFZO0FBQ2hELFdBQU9VLFNBQVMsSUFBSUMsSUFBSUMsS0FBS0MsTUFBTUgsTUFBTSxDQUFhLElBQUksb0JBQUlDLElBQUk7QUFBQSxFQUN0RSxRQUFRO0FBQUUsV0FBTyxvQkFBSUEsSUFBSTtBQUFBLEVBQUc7QUFDaEM7QUFFQSxTQUFTRyxlQUFlQyxLQUFrQjtBQUN0QyxNQUFJO0FBQUVSLGlCQUFhUyxRQUFRaEIsY0FBY1ksS0FBS0ssVUFBVSxDQUFDLEdBQUdGLEdBQUcsQ0FBQyxDQUFDO0FBQUEsRUFBRyxRQUFRO0FBQUEsRUFBRTtBQUNsRjtBQUVBLE1BQU1HLHVCQUF1QkEsQ0FBQ0MsVUFBeUJBLE1BQU1DLGtCQUFrQixRQUFRRCxNQUFNRSxjQUFjO0FBQzNHLE1BQU1DLGFBQWFBLENBQUNILFVBQWtEQSxNQUFNSSxnQkFBZ0JsQyxVQUFVbUMsV0FBVyxhQUFhO0FBQzlILE1BQU1DLHNCQUFzQixvQkFBSWQsSUFBWSxDQUFDeEIsZ0JBQWdCdUMsUUFBUXZDLGdCQUFnQndDLFFBQVEsQ0FBQztBQUU5RixTQUFTQyxZQUFZVCxPQUFzQlUsU0FBNkI7QUFDcEUsTUFBSVYsTUFBTVcsa0JBQWtCMUMsWUFBWTJDLFVBQVcsUUFBTztBQUMxRCxNQUFJWixNQUFNVyxrQkFBa0IxQyxZQUFZNEMsS0FBTSxRQUFPO0FBRXJELFFBQU1DLGNBQWNkLE1BQU1lLE1BQU1DLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsc0JBQXNCbEQsZ0JBQWdCNEMsU0FBUztBQUMvRixRQUFNTyxXQUFXTCxZQUFZTSxTQUFTLEtBQUtOLFlBQVlPLE1BQU0sQ0FBQ0osTUFBTVgsb0JBQW9CZ0IsSUFBSUwsRUFBRUMsaUJBQWlCLENBQUM7QUFDaEgsUUFBTUssYUFBYVQsWUFBWVUsS0FBSyxDQUFDUCxNQUFNQSxFQUFFQyxxQkFBcUJsRCxnQkFBZ0J5RCxjQUFjO0FBRWhHLE1BQUl6QixNQUFNVyxrQkFBa0IxQyxZQUFZeUQsdUJBQXVCUDtBQUMzRCxXQUFPVCxRQUFRWSxJQUFJdEIsTUFBTTJCLEVBQUUsSUFBSSxTQUFTO0FBQzVDLE1BQUlKLFdBQVksUUFBTztBQUN2QixTQUFPO0FBQ1g7QUFFQSxTQUFTSyxhQUFhQyxVQUEwQjtBQUM1QyxRQUFNQyxTQUFTLElBQUlDLEtBQUtGLFFBQVEsRUFBRUcsUUFBUTtBQUMxQyxRQUFNQyxVQUFVQyxLQUFLQyxJQUFJLEdBQUdELEtBQUtFLE9BQU9MLEtBQUtNLElBQUksSUFBSVAsVUFBVSxHQUFNLENBQUM7QUFDdEUsTUFBSUcsVUFBVSxHQUFJLFFBQU8sR0FBR0EsT0FBTztBQUNuQyxRQUFNSyxRQUFRSixLQUFLSyxNQUFNTixVQUFVLEVBQUU7QUFDckMsU0FBTyxHQUFHSyxLQUFLLElBQUlFLE9BQU9QLFVBQVUsRUFBRSxFQUFFUSxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQzVEO0FBYUEsTUFBTUMsb0JBQW9CLEVBQUVDLFFBQVEsS0FBS0MsV0FBVyxVQUFtQjtBQUV2RSxNQUFNQyxlQUE0QjtBQUFBLEVBQzlCO0FBQUEsSUFDSWxCLElBQUk7QUFBQSxJQUFRbUIsT0FBTztBQUFBLElBQWlCQyxNQUFNO0FBQUEsSUFBcUJDLFlBQVk7QUFBQSxJQUMzRUMsTUFBTSx1QkFBQyxTQUFJLFNBQVEsYUFBWSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxhQUFZLEtBQUksZUFBYyxTQUFRLGdCQUFlLFNBQVEsT0FBTyxFQUFFQyxPQUFPLElBQUlQLFFBQVEsR0FBRyxHQUFHO0FBQUEsNkJBQUMsVUFBSyxHQUFFLHdEQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxNQUFPLHVCQUFDLFVBQUssSUFBRyxLQUFJLElBQUcsS0FBSSxJQUFHLE1BQUssSUFBRyxPQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DO0FBQUEsTUFBTyx1QkFBQyxVQUFLLEdBQUUsMEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLFNBQXZTO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOFM7QUFBQSxJQUNwVFEsbUJBQW1CLHVCQUFDLFNBQUksS0FBSy9FLFFBQVEsS0FBSSxpQkFBZ0IsT0FBT3NFLHFCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStEO0FBQUEsRUFDdEY7QUFBQSxFQUNBO0FBQUEsSUFDSWYsSUFBSTtBQUFBLElBQVdtQixPQUFPO0FBQUEsSUFBV0MsTUFBTTtBQUFBLElBQXNCQyxZQUFZO0FBQUEsSUFDekVDLE1BQU0sdUJBQUMsU0FBSSxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLGVBQWMsU0FBUSxnQkFBZSxTQUFRLE9BQU8sRUFBRUMsT0FBTyxJQUFJUCxRQUFRLEdBQUcsR0FBRyxpQ0FBQyxVQUFLLEdBQUUsK0RBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRSxLQUE5TjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFPO0FBQUEsSUFDM09RLG1CQUFtQix1QkFBQyxTQUFJLEtBQUs5RSxhQUFhLEtBQUksV0FBVSxPQUFPcUUscUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEQ7QUFBQSxFQUNyRjtBQUFBLEVBQ0E7QUFBQSxJQUNJZixJQUFJO0FBQUEsSUFBY21CLE9BQU87QUFBQSxJQUFzQkMsTUFBTTtBQUFBLElBQTJCQyxZQUFZO0FBQUEsSUFDNUZDLE1BQU0sdUJBQUMsU0FBSSxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLGVBQWMsU0FBUSxnQkFBZSxTQUFRLE9BQU8sRUFBRUMsT0FBTyxJQUFJUCxRQUFRLEdBQUcsR0FBRztBQUFBLDZCQUFDLFVBQUssSUFBRyxRQUFPLElBQUcsT0FBTSxJQUFHLE9BQU0sSUFBRyxVQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRDO0FBQUEsTUFBTyx1QkFBQyxVQUFLLEdBQUUsK0hBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvSTtBQUFBLE1BQU8sdUJBQUMsY0FBUyxRQUFPLG1DQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsTUFBVyx1QkFBQyxVQUFLLElBQUcsTUFBSyxJQUFHLFNBQVEsSUFBRyxNQUFLLElBQUcsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBQTdiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb2M7QUFBQSxJQUMxY1EsbUJBQW1CLHVCQUFDLFNBQUksS0FBSzdFLFlBQVksS0FBSSxzQkFBcUIsT0FBT29FLHFCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdFO0FBQUEsRUFDL0Y7QUFBQSxFQUNBO0FBQUEsSUFDSWYsSUFBSTtBQUFBLElBQVFtQixPQUFPO0FBQUEsSUFBcUJDLE1BQU07QUFBQSxJQUFtQkMsWUFBWTtBQUFBLElBQzdFQyxNQUFNLHVCQUFDLFNBQUksU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxPQUFPLEVBQUVDLE9BQU8sSUFBSVAsUUFBUSxHQUFHLEdBQUc7QUFBQSw2QkFBQyxVQUFLLEdBQUUsb0RBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RDtBQUFBLE1BQU8sdUJBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxNQUFLLEdBQUUsT0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QjtBQUFBLFNBQXhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaVE7QUFBQSxJQUN2UVEsbUJBQW1CLHVCQUFDLFNBQUksS0FBSzVFLGFBQWEsS0FBSSxXQUFVLE9BQU9tRSxxQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RDtBQUFBLEVBQ3JGO0FBQUEsRUFDQTtBQUFBLElBQ0lmLElBQUk7QUFBQSxJQUFZbUIsT0FBTztBQUFBLElBQVlDLE1BQU07QUFBQSxJQUFlQyxZQUFZO0FBQUEsSUFDcEVDLE1BQU0sdUJBQUMsU0FBSSxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLGVBQWMsU0FBUSxnQkFBZSxTQUFRLE9BQU8sRUFBRUMsT0FBTyxJQUFJUCxRQUFRLEdBQUcsR0FBRyxpQ0FBQyxjQUFTLFFBQU8sb0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0MsS0FBNUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1TTtBQUFBLElBQzdNUSxtQkFBbUIsdUJBQUMsU0FBSSxLQUFLM0UsYUFBYSxLQUFJLFlBQVcsT0FBT2tFLHFCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStEO0FBQUEsRUFDdEY7QUFBQSxFQUNBO0FBQUEsSUFDSWYsSUFBSTtBQUFBLElBQWVtQixPQUFPO0FBQUEsSUFBZUMsTUFBTTtBQUFBLElBQVlDLFlBQVk7QUFBQSxJQUFXSSxhQUFhO0FBQUEsSUFDL0ZILE1BQU0sdUJBQUMsU0FBSSxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLGVBQWMsU0FBUSxnQkFBZSxTQUFRLE9BQU8sRUFBRUMsT0FBTyxJQUFJUCxRQUFRLEdBQUcsR0FBRztBQUFBLDZCQUFDLFVBQUssR0FBRSxLQUFJLEdBQUUsS0FBSSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxJQUFHLE9BQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxNQUFPLHVCQUFDLFVBQUssSUFBRyxNQUFLLElBQUcsS0FBSSxJQUFHLE1BQUssSUFBRyxPQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DO0FBQUEsTUFBTyx1QkFBQyxVQUFLLElBQUcsS0FBSSxJQUFHLEtBQUksSUFBRyxLQUFJLElBQUcsT0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQU8sdUJBQUMsVUFBSyxJQUFHLEtBQUksSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLFFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxTQUFqVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdWO0FBQUEsSUFDOVZRLG1CQUFtQix1QkFBQyxTQUFJLEtBQUsxRSxhQUFhLEtBQUksZUFBYyxPQUFPaUUscUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0U7QUFBQSxFQUN6RjtBQUFDO0FBR0wsTUFBTVcsaUJBQWlCUixhQUFhN0IsT0FBTXNDLEtBQUNBLENBQUFDLE1BQUtBLEVBQUU1QixPQUFPLGlCQUFpQjRCLEVBQUU1QixPQUFPLFdBQVc7QUFFOUY2QixNQUZNSDtBQUdOLFNBQVNJLFVBQVUsRUFBRXpELE9BQU8wRCxPQUFPQyxPQUFPQyxRQUFRQyxpQkFBaUJDLGFBQWFDLGVBQWVDLEtBQVUsR0FBRztBQUN4RyxRQUFNQyxlQUFlakUsTUFBTWlFLGNBQWNDLEtBQUssS0FBSyxXQUFXbEUsTUFBTTJCLEVBQUU7QUFDdEUsUUFBTXdDLGVBQWVoRSxXQUFXSCxLQUFLLE1BQU0sYUFBYSxhQUFhO0FBRXJFLFFBQU1vRSxPQUFPQSxDQUFDQyxPQUFtQixDQUFDQyxNQUF3QjtBQUFFQSxNQUFFQyxnQkFBZ0I7QUFBR0YsT0FBRztBQUFBLEVBQUc7QUFFdkYsU0FDSSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTVCxRQUFRLE9BQU87QUFBQSxJQUMxQ1ksWUFBWTtBQUFBLElBQVFDLFFBQVE7QUFBQSxJQUFxQkMsY0FBYztBQUFBLElBQUlDLFNBQVM7QUFBQSxJQUFJekIsT0FBTztBQUFBLElBQ3ZGMEIsV0FBVztBQUFBLElBQVFDLFFBQVE7QUFBQSxJQUFXQyxTQUFTO0FBQUEsSUFBUUMsZUFBZTtBQUFBLElBQVVDLEtBQUs7QUFBQSxJQUNyRkMsV0FBVztBQUFBLElBQThCQyxZQUFZO0FBQUEsRUFDekQsR0FDSTtBQUFBLDJCQUFDLFNBQUksT0FBTyxFQUFFSixTQUFTLFFBQVFLLGdCQUFnQixpQkFBaUJDLFlBQVksU0FBUyxHQUNqRjtBQUFBLDZCQUFDLFVBQUssT0FBTyxFQUFFQyxZQUFZLEtBQUtDLFVBQVUsVUFBVUMsT0FBTyxVQUFVLEdBQUc7QUFBQTtBQUFBLFFBQUV2RixNQUFNMkI7QUFBQUEsV0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLE1BQ25GLHVCQUFDLFVBQUssT0FBTyxFQUFFMkQsVUFBVSxXQUFXRCxZQUFZLEtBQUtWLFNBQVMsV0FBV0QsY0FBYyxHQUFHRixZQUFZLFdBQVdlLE9BQU8sUUFBUVQsU0FBUyxRQUFRTSxZQUFZLFVBQVVKLEtBQUssRUFBRSxHQUN6S2I7QUFBQUEseUJBQWlCLGFBQWEsT0FBTztBQUFBLFFBQUs7QUFBQSxRQUFFQTtBQUFBQSxXQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVXLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLEVBQUUsR0FDM0Q7QUFBQSw2QkFBQyxVQUFLLE9BQU8sRUFBRUssWUFBWSxLQUFLRSxPQUFPLFdBQVdELFVBQVUsVUFBVSxHQUFJckIsMEJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUY7QUFBQSxNQUN0RixDQUFDTixTQUFTM0QsTUFBTXdGLG1CQUNiLHVCQUFDLFVBQUssT0FBTyxFQUFFRixVQUFVLFVBQVVDLE9BQU8sUUFBUUUsWUFBWSxJQUFJLEdBQUl6RixnQkFBTXdGLG1CQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRGO0FBQUEsU0FIcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVYsU0FBUyxRQUFRSyxnQkFBZ0IsaUJBQWlCRyxVQUFVLFdBQVdDLE9BQU8sUUFBUUcsV0FBVyxtQkFBbUJDLFlBQVksR0FBRyxHQUM3STtBQUFBLDZCQUFDLFVBQUssT0FBTyxFQUFFTixZQUFZLElBQUksR0FBRztBQUFBO0FBQUEsUUFBSWxILFVBQVU2QixNQUFNNEYsV0FBVyxFQUFFQyxRQUFRLE1BQU0sRUFBRSxFQUFFM0IsS0FBSztBQUFBLFdBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEY7QUFBQSxNQUM1Rix1QkFBQyxVQUFNbEU7QUFBQUEsY0FBTWUsTUFBTUs7QUFBQUEsUUFBTztBQUFBLFFBQUVwQixNQUFNZSxNQUFNSyxXQUFXLElBQUksU0FBUztBQUFBLFdBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0U7QUFBQSxTQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFa0UsVUFBVSxXQUFXQyxPQUFPLFFBQVFULFNBQVMsUUFBUUssZ0JBQWdCLGdCQUFnQixHQUMvRixpQ0FBQyxVQUFLO0FBQUE7QUFBQSxNQUFXdkQsYUFBYTVCLE1BQU02QixRQUFRO0FBQUEsU0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QyxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVDNkIsVUFBVSxVQUFVLHVCQUFDLFlBQU8sU0FBU1UsS0FBS1AsZUFBZSxHQUFHLFVBQVVHLE1BQU0sT0FBTzhCLGdCQUFpQjlCLGlCQUFPLGNBQWMsdUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUg7QUFBQSxJQUM3SU4sVUFBVSxhQUFhLHVCQUFDLFlBQU8sU0FBU1UsS0FBS04sV0FBVyxHQUFHLFVBQVVFLE1BQU0sT0FBTzhCLGdCQUFpQjlCLGlCQUFPLGlCQUFpQixxQkFBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzSDtBQUFBLElBQzdJTixVQUFVLGdCQUFnQix1QkFBQyxZQUFPLFNBQVNVLEtBQUtMLGFBQWEsR0FBRyxVQUFVQyxNQUFNLE9BQU84QixnQkFBZ0IsaUNBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEY7QUFBQSxJQUN4SHBDLFVBQVUsVUFBVSx1QkFBQyxZQUFPLFNBQVNVLEtBQUtSLE1BQU0sR0FBRyxVQUFVSSxNQUFNLE9BQU84QixnQkFBZ0IsaUNBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUY7QUFBQSxPQS9CaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdDQTtBQUVSO0FBQUNDLE1BekNRdEM7QUEyQ1QsTUFBTXFDLGlCQUFzQztBQUFBLEVBQ3hDNUMsT0FBTztBQUFBLEVBQVF5QixTQUFTO0FBQUEsRUFBUUQsY0FBYztBQUFBLEVBQUdELFFBQVE7QUFBQSxFQUFRRCxZQUFZO0FBQUEsRUFDN0VlLE9BQU87QUFBQSxFQUFRRixZQUFZO0FBQUEsRUFBS1IsUUFBUTtBQUFBLEVBQVdtQixXQUFXO0FBQUEsRUFBR1YsVUFBVTtBQUMvRTtBQUdPLGdCQUFTVyxvQkFBb0I7QUFBQUMsS0FBQTtBQUNoQyxRQUFNQyxjQUFjNUksZUFBZTtBQUNuQyxRQUFNNkksUUFBUXhJLFNBQVM7QUFDdkIsUUFBTSxFQUFFeUksVUFBVUMsV0FBVyxJQUFJM0ksYUFBYTtBQUU5QyxRQUFNLENBQUM0SSxVQUFVQyxXQUFXLElBQUlwSixTQUFtQitCLFlBQVk7QUFDL0QsUUFBTSxDQUFDc0gsZUFBZUMsZ0JBQWdCLElBQUl0SixTQUF3QixPQUFPO0FBQ3pFLFFBQU0sQ0FBQ3VKLFFBQVFDLFNBQVMsSUFBSXhKLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNzRCxTQUFTbUcsVUFBVSxJQUFJekosU0FBc0JrQyxXQUFXO0FBQy9ELFFBQU0sQ0FBQ3dILGlCQUFpQkMsa0JBQWtCLElBQUkzSixTQUF3QixJQUFJO0FBQzFFLFFBQU0sQ0FBQzRKLFlBQVlDLGFBQWEsSUFBSTdKLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUM4SixnQkFBZ0JDLGlCQUFpQixJQUFJL0osU0FBd0IsSUFBSTtBQUN4RSxRQUFNLENBQUNnSyxRQUFRQyxTQUFTLElBQUlqSyxTQUFxQyxvQkFBSWtLLElBQUksQ0FBQztBQUMxRSxRQUFNQyxXQUFXcEssT0FBbUMsb0JBQUltSyxJQUFJLENBQUM7QUFDN0QsUUFBTUUsY0FBY3JLLE9BQW9CLG9CQUFJcUMsSUFBSSxDQUFDO0FBRWpEdkMsWUFBVSxNQUFNO0FBQUVtQyxpQkFBYVMsUUFBUWpCLGVBQWUySCxRQUFRO0FBQUEsRUFBRyxHQUFHLENBQUNBLFFBQVEsQ0FBQztBQUU5RXRKLFlBQVUsTUFBTTtBQUNaLFVBQU13SyxnQkFBZ0JDLFNBQVNDO0FBQy9CRCxhQUFTQyxRQUFRO0FBQ2pCLFdBQU8sTUFBTTtBQUFFRCxlQUFTQyxRQUFRRjtBQUFBQSxJQUFlO0FBQUEsRUFDbkQsR0FBRyxFQUFFO0FBRUwsUUFBTUcsY0FBY3RLLFNBQVM7QUFBQSxJQUN6QnVLLFVBQVUsQ0FBQyxVQUFVLFFBQVF4QixRQUFRO0FBQUEsSUFDckN5QixTQUFTQSxNQUFNdEssc0JBQXNCNkksUUFBUTtBQUFBLElBQzdDMEIsaUJBQWlCO0FBQUEsRUFDckIsQ0FBQztBQUVEOUssWUFBVSxNQUFNO0FBQ1osUUFBSSxDQUFDMkssWUFBWUksS0FBTTtBQUN2QixVQUFNQyxlQUFjTCxZQUFZSSxLQUFLaEgsT0FBT2pCLG9CQUFvQjtBQUNoRSxVQUFNbUksYUFBYSxJQUFJMUksSUFBSXlJLGFBQVlFLElBQUksQ0FBQ0MsTUFBTUEsRUFBRXpHLEVBQUUsQ0FBQztBQUN2RCxVQUFNMEcsV0FBcUI7QUFFM0IsZUFBVzFHLE1BQU00RixTQUFTZSxRQUFRQyxLQUFLLEdBQUc7QUFDdEMsVUFBSSxDQUFDTCxXQUFXNUcsSUFBSUssRUFBRSxFQUFHMEcsVUFBU0csS0FBSzdHLEVBQUU7QUFBQSxJQUM3QztBQUNBLGVBQVczQixTQUFTaUksYUFBYVYsVUFBU2UsUUFBUUcsSUFBSXpJLE1BQU0yQixJQUFJM0IsS0FBSztBQUVyRXFJLGFBQVNLLFFBQVEsQ0FBQy9HLE9BQU87QUFDckIsVUFBSTZGLFlBQVljLFFBQVFoSCxJQUFJSyxFQUFFLEVBQUc7QUFDakM2RixrQkFBWWMsUUFBUUssSUFBSWhILEVBQUU7QUFDMUI0RixlQUFTZSxRQUFRTSxPQUFPakgsRUFBRTtBQUMxQmxFLGVBQVNrRSxFQUFFLEVBQUVrSCxLQUFLLENBQUNDLGVBQWU7QUFDOUJ6QixrQkFBVSxDQUFDMEIsU0FBUztBQUNoQixnQkFBTUMsT0FBTyxJQUFJMUIsSUFBSXlCLElBQUk7QUFDekJDLGVBQUtQLElBQUk5RyxJQUFJbUgsVUFBVTtBQUN2QixpQkFBT0UsS0FBS0MsT0FBT25LLGFBQWE7QUFDNUIsa0JBQU1vSyxTQUFTRixLQUFLVCxLQUFLLEVBQUVTLEtBQUssRUFBRUc7QUFDbEMsZ0JBQUlELFdBQVdFLE9BQVc7QUFDMUJKLGlCQUFLSixPQUFPTSxNQUFNO0FBQUEsVUFDdEI7QUFDQSxpQkFBT0Y7QUFBQUEsUUFDWCxDQUFDO0FBQ0RuQyxtQkFBVyxDQUFDd0MsY0FBYztBQUN0QixjQUFJLENBQUNBLFVBQVUvSCxJQUFJSyxFQUFFLEVBQUcsUUFBTzBIO0FBQy9CLGdCQUFNTCxPQUFPLElBQUl4SixJQUFJNkosU0FBUztBQUM5QkwsZUFBS0osT0FBT2pILEVBQUU7QUFDZGhDLHlCQUFlcUosSUFBSTtBQUNuQixpQkFBT0E7QUFBQUEsUUFDWCxDQUFDO0FBQUEsTUFDTCxDQUFDLEVBQUVNLE1BQU0sTUFBTTtBQUFBLE1BQUUsQ0FBQyxFQUFFQyxRQUFRLE1BQU0vQixZQUFZYyxRQUFRTSxPQUFPakgsRUFBRSxDQUFDO0FBQUEsSUFDcEUsQ0FBQztBQUFBLEVBQ0wsR0FBRyxDQUFDaUcsWUFBWUksSUFBSSxDQUFDO0FBRXJCLFFBQU1DLGNBQWMvSyxRQUFRLE1BQU07QUFDOUIsVUFBTWlMLE1BQU0sb0JBQUliLElBQTJCO0FBQzNDLGVBQVd0SCxTQUFTb0gsT0FBT29DLE9BQU8sRUFBRyxLQUFJekoscUJBQXFCQyxLQUFLLEVBQUdtSSxLQUFJTSxJQUFJekksTUFBTTJCLElBQUkzQixLQUFLO0FBQzdGLGVBQVdBLFNBQVM0SCxZQUFZSSxRQUFRLEdBQUksS0FBSWpJLHFCQUFxQkMsS0FBSyxFQUFHbUksS0FBSU0sSUFBSXpJLE1BQU0yQixJQUFJM0IsS0FBSztBQUNwRyxXQUFPLENBQUMsR0FBR21JLElBQUlxQixPQUFPLENBQUM7QUFBQSxFQUMzQixHQUFHLENBQUM1QixZQUFZSSxNQUFNWixNQUFNLENBQUM7QUFFN0IsUUFBTXFDLGlCQUFpQnZNLFFBQVEsTUFBTTtBQUNqQyxVQUFNd00sT0FBTy9DLE9BQU96QyxLQUFLLEVBQUV5RixZQUFZO0FBQ3ZDLFdBQU8xQixZQUFZakgsT0FBTyxDQUFDaEIsVUFBVTtBQUNqQyxVQUFJeUcsa0JBQWtCLFdBQVd0RyxXQUFXSCxLQUFLLE1BQU15RyxjQUFlLFFBQU87QUFDN0UsVUFBSWlELFNBQVMsR0FBSSxRQUFPO0FBQ3hCLFlBQU1FLFdBQVcsQ0FBQ3BILE9BQU94QyxNQUFNMkIsRUFBRSxHQUFHM0IsTUFBTWlFLGdCQUFnQixJQUFJakUsTUFBTXdGLG1CQUFtQixJQUFJeEYsTUFBTTZKLGlCQUFpQixFQUFFLEVBQUVDLEtBQUssR0FBRyxFQUFFSCxZQUFZO0FBQzVJLGFBQU9DLFNBQVNHLFNBQVNMLElBQUk7QUFBQSxJQUNqQyxDQUFDO0FBQUEsRUFDTCxHQUFHLENBQUN6QixhQUFheEIsZUFBZUUsTUFBTSxDQUFDO0FBRXZDLFFBQU1xRCxnQkFBZ0I5TSxRQUFRLE1BQU07QUFDaEMsVUFBTWlMLE1BQXNDLEVBQUU4QixNQUFNLElBQUlDLFNBQVMsSUFBSUMsWUFBWSxJQUFJQyxNQUFNLElBQUlDLFVBQVUsSUFBSUMsV0FBVyxHQUFHO0FBQzNILGVBQVd0SyxTQUFTeUosZUFBZ0J0QixLQUFJMUgsWUFBWVQsT0FBT1UsT0FBTyxDQUFDLEVBQUU4SCxLQUFLeEksS0FBSztBQUMvRSxlQUFXdUssUUFBUUMsT0FBT2hCLE9BQU9yQixHQUFHLEVBQUdvQyxNQUFLRSxLQUFLLENBQUNDLEdBQUdDLE1BQU1ELEVBQUUvSSxLQUFLZ0osRUFBRWhKLEVBQUU7QUFDdEUsV0FBT3dHO0FBQUFBLEVBQ1gsR0FBRyxDQUFDc0IsZ0JBQWdCL0ksT0FBTyxDQUFDO0FBRTVCLFFBQU1rSyxtQkFBbUIxTixRQUFRLE1BQU07QUFDbkMsVUFBTTJOLGVBQWU1QyxZQUFZakgsT0FBTyxDQUFBb0gsTUFBS0EsRUFBRXpILGtCQUFrQjFDLFlBQVkyQyxTQUFTO0FBQ3RGLFVBQU1rSyxRQUFRRCxhQUFheko7QUFDM0IsVUFBTTJKLFlBQVlmLGNBQWNLLFNBQVNqSjtBQUN6QyxVQUFNNEosWUFBWUYsUUFBUUM7QUFFMUIsUUFBSUUsYUFBYTtBQUNqQkosaUJBQWFuQyxRQUFRLENBQUFOLE1BQUs7QUFDdEIsWUFBTXRHLFNBQVMsSUFBSUMsS0FBS3FHLEVBQUV2RyxRQUFRLEVBQUVHLFFBQVE7QUFDNUNpSixvQkFBYy9JLEtBQUtDLElBQUksSUFBSUosS0FBS00sSUFBSSxJQUFJUCxVQUFVLEdBQUs7QUFBQSxJQUMzRCxDQUFDO0FBQ0QsVUFBTW9KLFVBQVVKLFFBQVEsSUFBSTVJLEtBQUtFLE1BQU02SSxhQUFhSCxLQUFLLElBQUk7QUFFN0QsV0FBTyxFQUFFQSxPQUFPSSxTQUFTSCxXQUFXQyxXQUFXRyxXQUFXLEVBQUU7QUFBQSxFQUNoRSxHQUFHLENBQUNsRCxhQUFhK0IsYUFBYSxDQUFDO0FBRS9CLFFBQU1vQixVQUFVQSxNQUFNLEtBQUtqRixZQUFZa0Ysa0JBQWtCLEVBQUV4RCxVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDakYsUUFBTXlELFFBQVFBLENBQUNDLGFBQXFCLENBQUNDLFVBQW1CcEYsTUFBTW9GLE1BQU1BLGlCQUFpQjNOLFdBQVcyTixNQUFNQyxVQUFVRixRQUFRO0FBRXhILFFBQU1HLGdCQUFnQnJPLFlBQVk7QUFBQSxJQUM5QnNPLFlBQVksT0FBTzNMLFVBQXlCO0FBQ3hDLFlBQU00TCxVQUFVNUwsTUFBTWUsTUFBTUMsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxzQkFBc0JsRCxnQkFBZ0I2TixPQUFPO0FBQ3pGLFlBQU1DLFFBQVFDLElBQUlILFFBQVF6RCxJQUFJLENBQUNsSCxNQUFNdkQsaUJBQWlCc0MsTUFBTTJCLElBQUlWLEVBQUVVLElBQUkzRCxnQkFBZ0J5RCxnQkFBZ0I2RSxVQUFVLENBQUMsQ0FBQztBQUFBLElBQ3RIO0FBQUEsSUFDQTBGLFdBQVdBLENBQUNDLE9BQU9qTSxVQUFVO0FBQUVvRyxZQUFNOEYsUUFBUSxXQUFXbE0sTUFBTTJCLEVBQUUsY0FBYztBQUFHd0Ysd0JBQWtCLElBQUk7QUFBR2lFLGNBQVE7QUFBQSxJQUFHO0FBQUEsSUFDckhlLFNBQVNBLENBQUM3SCxNQUFNO0FBQUVnSCxZQUFNLGtCQUFrQixFQUFFaEgsQ0FBQztBQUFHNkMsd0JBQWtCLElBQUk7QUFBQSxJQUFHO0FBQUEsRUFDN0UsQ0FBQztBQUVELFFBQU1pRixZQUFZL08sWUFBWTtBQUFBLElBQzFCc08sWUFBWSxPQUFPM0wsVUFBeUI7QUFDeEMsWUFBTTRMLFVBQVU1TCxNQUFNZSxNQUFNQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLHNCQUFzQmxELGdCQUFnQjRDLGFBQWEsQ0FBQ04sb0JBQW9CZ0IsSUFBSUwsRUFBRUMsaUJBQWlCLENBQUM7QUFDNUksWUFBTTRLLFFBQVFDLElBQUlILFFBQVF6RCxJQUFJLENBQUNsSCxNQUFNdkQsaUJBQWlCc0MsTUFBTTJCLElBQUlWLEVBQUVVLElBQUkzRCxnQkFBZ0J1QyxRQUFRK0YsVUFBVSxDQUFDLENBQUM7QUFBQSxJQUM5RztBQUFBLElBQ0EwRixXQUFXQSxDQUFDQyxPQUFPak0sVUFBVTtBQUFFb0csWUFBTThGLFFBQVEsV0FBV2xNLE1BQU0yQixFQUFFLFVBQVU7QUFBR3dGLHdCQUFrQixJQUFJO0FBQUdpRSxjQUFRO0FBQUEsSUFBRztBQUFBLElBQ2pIZSxTQUFTQSxDQUFDN0gsTUFBTTtBQUFFZ0gsWUFBTSxrQkFBa0IsRUFBRWhILENBQUM7QUFBRzZDLHdCQUFrQixJQUFJO0FBQUEsSUFBRztBQUFBLEVBQzdFLENBQUM7QUFFRCxRQUFNa0Ysc0JBQXNCQSxDQUFDakUsTUFBcUI7QUFBRWpCLHNCQUFrQmlCLEVBQUV6RyxFQUFFO0FBQUcrSixrQkFBY1ksT0FBT2xFLENBQUM7QUFBQSxFQUFHO0FBQ3RHLFFBQU1tRSxrQkFBa0JBLENBQUNuRSxNQUFxQjtBQUFFakIsc0JBQWtCaUIsRUFBRXpHLEVBQUU7QUFBR3lLLGNBQVVFLE9BQU9sRSxDQUFDO0FBQUEsRUFBRztBQUM5RixRQUFNb0Usb0JBQW9CQSxDQUFDcEUsTUFBcUI7QUFBRXZCLGVBQVcsQ0FBQ2tDLFNBQVM7QUFBRSxZQUFNQyxPQUFPLElBQUl4SixJQUFJdUosSUFBSSxFQUFFSixJQUFJUCxFQUFFekcsRUFBRTtBQUFHaEMscUJBQWVxSixJQUFJO0FBQUcsYUFBT0E7QUFBQUEsSUFBTSxDQUFDO0FBQUEsRUFBRztBQUV0SixRQUFNeUQsVUFBVWxHLGFBQWEsYUFBYTFELGVBQWVRO0FBQ3pELFFBQU1NLFFBQVE0QyxhQUFhO0FBRTNCLFNBQ0ksdUJBQUMsU0FBSSxPQUFPO0FBQUEsSUFDUm1HLGlCQUFpQixPQUFPL04sV0FBVztBQUFBLElBQ25DZ08sZ0JBQWdCO0FBQUEsSUFDaEJDLG9CQUFvQjtBQUFBLElBQ3BCQyxpQkFBaUI7QUFBQSxJQUNqQkMsV0FBVztBQUFBLElBQ1huSSxTQUFTO0FBQUEsSUFDVG9JLFlBQVk7QUFBQSxJQUNaakksU0FBUztBQUFBLElBQ1RDLGVBQWU7QUFBQSxFQUNuQixHQUdJO0FBQUEsMkJBQUMsWUFBTyxPQUFPLEVBQUVELFNBQVMsUUFBUUssZ0JBQWdCLGlCQUFpQkMsWUFBWSxVQUFVNEgsY0FBYyxHQUFHLEdBQ3RHO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVsSSxTQUFTLFFBQVFNLFlBQVksVUFBVUosS0FBSyxHQUFHLEdBQ3pEO0FBQUEsK0JBQUMsU0FDRyxpQ0FBQyxTQUFJLEtBQUt0RyxlQUFlLEtBQUksb0JBQW1CLE9BQU8sRUFBRXdFLE9BQU8sMEJBQTBCUCxRQUFRLFFBQVFDLFdBQVcsV0FBV3FLLGNBQWMsV0FBVyxLQUF6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJKLEtBRC9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFFBQUcsT0FBTyxFQUFFM0gsVUFBVSxVQUFVRCxZQUFZLEtBQUtFLE9BQU8sV0FBVzJILFFBQVEsR0FBR0MsZUFBZSxhQUFhQyxlQUFlLE9BQU8sR0FBRyx3QkFBcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEk7QUFBQSxVQUM1SSx1QkFBQyxVQUFLLE9BQU8sRUFBRTdILE9BQU8sUUFBUUQsVUFBVSxVQUFVLEdBQUcsZ0VBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFHO0FBQUEsYUFGekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFUixTQUFTLFFBQVFFLEtBQUssSUFBSUksWUFBWSxTQUFTLEdBQ3pEO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVOLFNBQVMsUUFBUU4sWUFBWSxRQUFRRSxjQUFjLEdBQUdDLFNBQVMsR0FBR0YsUUFBUSxxQkFBcUJRLFdBQVcsNkJBQTZCLEdBQ2pKO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVMsTUFBTXVCLFlBQVksU0FBUztBQUFBLGNBQ3BDLE9BQU8sRUFBRTdCLFNBQVMsWUFBWUQsY0FBYyxHQUFHRCxRQUFRLFFBQVFZLFlBQVksS0FBS1IsUUFBUSxXQUFXTCxZQUFZK0IsYUFBYSxZQUFZLFNBQVMsZUFBZWhCLE9BQU9nQixhQUFhLFlBQVksWUFBWSxRQUFRdEIsV0FBV3NCLGFBQWEsWUFBWSw4QkFBOEIsT0FBTztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBRm5TO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdRO0FBQUEsVUFDUjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csU0FBUyxNQUFNQyxZQUFZLFVBQVU7QUFBQSxjQUNyQyxPQUFPLEVBQUU3QixTQUFTLFlBQVlELGNBQWMsR0FBR0QsUUFBUSxRQUFRWSxZQUFZLEtBQUtSLFFBQVEsV0FBV0wsWUFBWStCLGFBQWEsYUFBYSxZQUFZLGVBQWVoQixPQUFPZ0IsYUFBYSxhQUFhLFNBQVMsUUFBUXRCLFdBQVdzQixhQUFhLGFBQWEsa0NBQWtDLE9BQU87QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUYxUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHUztBQUFBLGFBUmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1VLGNBQWMsSUFBSSxHQUFHLE9BQU8sRUFBRXpDLFlBQVksb0RBQW9EZSxPQUFPLFFBQVFkLFFBQVEsUUFBUUUsU0FBUyxhQUFhRCxjQUFjLEdBQUdXLFlBQVksS0FBS0MsVUFBVSxRQUFRVCxRQUFRLFdBQVdJLFdBQVcsbUNBQW1DLEdBQUcsNkJBQWhUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVILFNBQVMsUUFBUUUsS0FBSyxJQUFJZ0ksY0FBYyxJQUFJNUgsWUFBWSxTQUFTLEdBQzNFO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVOLFNBQVMsUUFBUUUsS0FBSyxFQUFFLEdBQ2hDLFdBQUMsU0FBUyxZQUFZLFVBQVUsRUFBc0JtRDtBQUFBQSxRQUFJLENBQUM1RSxNQUN6RCx1QkFBQyxZQUFlLFNBQVMsTUFBTW1ELGlCQUFpQm5ELENBQUMsR0FBRyxPQUFPO0FBQUEsVUFDdkRvQixTQUFTO0FBQUEsVUFBYUQsY0FBYztBQUFBLFVBQUdELFFBQVFsQixNQUFNa0QsZ0JBQWdCLFNBQVM7QUFBQSxVQUM5RWpDLFlBQVlqQixNQUFNa0QsZ0JBQWdCLFlBQVk7QUFBQSxVQUFRbEIsT0FBT2hDLE1BQU1rRCxnQkFBZ0IsU0FBUztBQUFBLFVBQzVGcEIsWUFBWTtBQUFBLFVBQUtSLFFBQVE7QUFBQSxVQUFXSSxXQUFXMUIsTUFBTWtELGdCQUFnQixtQ0FBbUM7QUFBQSxRQUM1RyxHQUNLMUgsZ0NBQXNCd0UsQ0FBQyxLQUxmQSxHQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLE1BQ0gsS0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFOEosVUFBVSxZQUFZQyxNQUFNLEdBQUdDLFVBQVUsSUFBSSxHQUN2RDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxhQUFZO0FBQUEsWUFDWixPQUFPNUc7QUFBQUEsWUFBUSxVQUFVLENBQUNyQyxNQUFNc0MsVUFBVXRDLEVBQUVrSixPQUFPckUsS0FBSztBQUFBLFlBSXhELE9BQU8sRUFBRWpHLE9BQU8sUUFBUXlCLFNBQVMsdUJBQXVCRCxjQUFjLEdBQUdELFFBQVEscUJBQXFCRCxZQUFZLFFBQVFlLE9BQU8sV0FBV0QsVUFBVSxXQUFXTCxXQUFXLDhCQUE4QndJLFNBQVMsT0FBTztBQUFBO0FBQUEsVUFOOU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTWdPO0FBQUEsUUFFaE8sdUJBQUMsU0FBSSxPQUFPLEVBQUVKLFVBQVUsWUFBWUssTUFBTSxJQUFJQyxLQUFLLElBQUl6SyxPQUFPLElBQUlxQyxPQUFPLE9BQU8sR0FBRyxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLGVBQWMsU0FBUSxnQkFBZSxTQUFRO0FBQUEsaUNBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxNQUFLLEdBQUUsT0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEI7QUFBQSxVQUFTLHVCQUFDLFVBQUssSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLFNBQVEsSUFBRyxXQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QztBQUFBLGFBQXpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ1M7QUFBQSxXQVRwUztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFcUksWUFBWSxRQUFROUksU0FBUyxRQUFRTSxZQUFZLFVBQVVKLEtBQUssSUFBSVIsWUFBWSxRQUFRRyxTQUFTLFlBQVlELGNBQWMsR0FBR0QsUUFBUSxxQkFBcUJhLFVBQVUsV0FBV0MsT0FBTyxPQUFPLEdBQ3hNO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVULFNBQVMsUUFBUU0sWUFBWSxVQUFVSixLQUFLLEVBQUUsR0FBRztBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFOUIsT0FBTyxHQUFHLEdBQUcsU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxpQ0FBQyxVQUFLLEdBQUUsOERBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0UsS0FBbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0s7QUFBQSxVQUFNO0FBQUEsYUFBNU87QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2UDtBQUFBLFFBQzdQLHVCQUFDLFVBQUssT0FBTyxFQUFFQSxPQUFPLEdBQUdQLFFBQVEsSUFBSTZCLFlBQVksT0FBTyxLQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0QsdUJBQUMsVUFBSyxPQUFPLEVBQUVNLFNBQVMsUUFBUU0sWUFBWSxVQUFVSixLQUFLLEVBQUUsR0FBRztBQUFBO0FBQUEsVUFBd0IsdUJBQUMsVUFBSyxPQUFPLEVBQUU5QixPQUFPLEdBQUdQLFFBQVEsR0FBRzZCLFlBQVksV0FBV0UsY0FBYyxNQUFNLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtGO0FBQUEsYUFBMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpTDtBQUFBLFdBSHJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFSSxTQUFTLFFBQVFFLEtBQUssSUFBSXNJLE1BQU0sR0FBR08sV0FBVyxRQUFRQyxlQUFlLElBQUloQixXQUFXLElBQUksR0FDakdMLGtCQUFRdEUsSUFBSSxDQUFDNEYsUUFBUTtBQUNsQixZQUFNaE4sUUFBUWdOLElBQUlwTSxPQUFPLGdCQUFnQixLQUFLcUksY0FBYytELElBQUlwTSxFQUFXLEtBQUs7QUFDaEYsYUFDSSx1QkFBQyxTQUFpQixPQUFPLEVBQUVxTSxVQUFVLEtBQUs5SyxPQUFPLFNBQVNzQixZQUFZLFFBQVFFLGNBQWMsSUFBSUMsU0FBUyxRQUFRRyxTQUFTLFFBQVFDLGVBQWUsVUFBVU4sUUFBUSxxQkFBcUJRLFdBQVcsOEJBQThCLEdBRzdOO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVILFNBQVMsUUFBUUUsS0FBSyxJQUFJZ0ksY0FBYyxHQUFHLEdBQ3JEO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUV4SSxZQUFZdUosSUFBSS9LLFlBQVl1QyxPQUFPLFFBQVFyQyxPQUFPLElBQUlQLFFBQVEsSUFBSStCLGNBQWMsSUFBSUksU0FBUyxRQUFRTSxZQUFZLFVBQVVELGdCQUFnQixVQUFVRixXQUFXLGNBQWM4SSxJQUFJL0ssVUFBVSxLQUFLLEdBQzFNK0ssY0FBSTlLLFFBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVxSyxNQUFNLEVBQUUsR0FDbEI7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRXhJLFNBQVMsUUFBUUssZ0JBQWdCLGlCQUFpQkMsWUFBWSxhQUFhLEdBQ3JGO0FBQUEscUNBQUMsVUFBSyxPQUFPLEVBQUVDLFlBQVksS0FBS0MsVUFBVSxXQUFXQyxPQUFPLFdBQVdFLFlBQVksSUFBSSxHQUFJc0ksY0FBSWpMLFNBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFHO0FBQUEsY0FDckcsdUJBQUMsVUFBSyxPQUFPLEVBQUUwQixZQUFZLEdBQUd1SixJQUFJL0ssVUFBVSxNQUFNdUMsT0FBT3dJLElBQUkvSyxZQUFZcUMsWUFBWSxLQUFLVixTQUFTLFdBQVdELGNBQWMsSUFBSVksVUFBVSxTQUFTLEdBQzlJdkUsZ0JBQU1LLFVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFa0UsVUFBVSxXQUFXQyxPQUFPLFFBQVFULFNBQVMsU0FBU2tCLFdBQVcsRUFBRSxHQUFJK0gsY0FBSWhMLFFBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStGO0FBQUEsZUFQbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRStCLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLElBQUlzSSxNQUFNLEdBQUdXLFdBQVcsUUFBUVosVUFBVSxXQUFXLEdBQzdHVSxjQUFJM0ssY0FDRCx1QkFBQyxTQUFJLE9BQU8sRUFBRTBCLFNBQVMsUUFBUUMsZUFBZSxVQUFVSyxZQUFZLFVBQVVELGdCQUFnQixVQUFVeEMsUUFBUSxRQUFRZ0MsU0FBUyxHQUFHLEdBQy9Ib0o7QUFBQUEsY0FBSTVLO0FBQUFBLFVBQ0wsdUJBQUMsU0FBSSxPQUFPLEVBQUV5QixXQUFXLFVBQVVXLE9BQU8sUUFBUUQsVUFBVSxXQUFXVSxXQUFXLEdBQUcsR0FBRywwSEFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUV4QixZQUFZLFdBQVdHLFNBQVMsWUFBWUQsY0FBYyxJQUFJVyxZQUFZLEtBQUtFLE9BQU8sUUFBUVMsV0FBVyxJQUFJVixVQUFVLFNBQVMsR0FBRyx3QkFBbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEo7QUFBQSxhQUw5SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsSUFDQXZFLE1BQU1LLFdBQVcsSUFDakIsdUJBQUMsU0FBSSxPQUFPLEVBQUUwRCxTQUFTLFFBQVFDLGVBQWUsVUFBVUssWUFBWSxVQUFVRCxnQkFBZ0IsVUFBVXhDLFFBQVEsUUFBUXVMLFNBQVMsS0FBS2xJLFdBQVcsR0FBRyxHQUNoSjtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFZ0gsY0FBYyxHQUFHLEdBQzFCZSxjQUFJNUsscUJBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVvQyxPQUFPLFFBQVFELFVBQVUsUUFBUUQsWUFBWSxJQUFJLEdBQUcsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsYUFKakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLElBRUF0RSxNQUFNb0g7QUFBQUEsVUFBSSxDQUFDbkksVUFDUDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ2tCO0FBQUEsY0FBYyxPQUFPK04sSUFBSXBNO0FBQUFBLGNBQWE7QUFBQSxjQUFjLE1BQU11RixtQkFBbUJsSCxNQUFNMkI7QUFBQUEsY0FDbEcsUUFBUSxNQUFNb0YsbUJBQW1CL0csTUFBTTJCLEVBQUU7QUFBQSxjQUFHLGlCQUFpQixNQUFNMEssb0JBQW9Cck0sS0FBSztBQUFBLGNBQzVGLGFBQWEsTUFBTXVNLGdCQUFnQnZNLEtBQUs7QUFBQSxjQUFHLGVBQWUsTUFBTXdNLGtCQUFrQnhNLEtBQUs7QUFBQTtBQUFBLFlBRmxGQSxNQUFNMkI7QUFBQUEsWUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzZGO0FBQUEsUUFFaEcsS0F2QlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFdBNUNNb00sSUFBSXBNLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZDQTtBQUFBLElBRVIsQ0FBQyxLQW5ETDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0RBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRTZDLFlBQVksUUFBUUUsY0FBYyxJQUFJQyxTQUFTLGFBQWFHLFNBQVMsUUFBUUssZ0JBQWdCLGlCQUFpQkMsWUFBWSxVQUFVWSxXQUFXLFFBQVFmLFdBQVcsdUNBQXVDa0osY0FBYyxvQkFBb0IsR0FDclA7QUFBQSw2QkFBQyxtQkFBZ0IsTUFBTSx1QkFBQyxTQUFJLFNBQVEsYUFBWSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxhQUFZLEtBQUksT0FBTyxFQUFFakwsT0FBTyxHQUFHLEdBQUc7QUFBQSwrQkFBQyxVQUFLLEdBQUUsK0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQU8sdUJBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxLQUFJLEdBQUUsT0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QjtBQUFBLFdBQXpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa00sR0FBUSxPQUFNLG9CQUFtQixPQUFPMEgsaUJBQWlCRSxPQUFPLEtBQUksVUFBN1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtUztBQUFBLE1BQ25TLHVCQUFDLFNBQUksT0FBTyxFQUFFNUgsT0FBTyxHQUFHUCxRQUFRLElBQUk2QixZQUFZLE9BQU8sS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRDtBQUFBLE1BQzFELHVCQUFDLG1CQUFnQixNQUFNLHVCQUFDLFNBQUksU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxPQUFPLEVBQUV0QixPQUFPLEdBQUcsR0FBRztBQUFBLCtCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsTUFBSyxHQUFFLFFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxRQUFTLHVCQUFDLGNBQVMsUUFBTyxzQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBLFdBQTdLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0wsR0FBUSxPQUFNLGVBQWMsT0FBTzBILGlCQUFpQk0sU0FBUyxLQUFJLFNBQWhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcVI7QUFBQSxNQUNyUix1QkFBQyxTQUFJLE9BQU8sRUFBRWhJLE9BQU8sR0FBR1AsUUFBUSxJQUFJNkIsWUFBWSxPQUFPLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxNQUMxRCx1QkFBQyxtQkFBZ0IsTUFBTSx1QkFBQyxTQUFJLFNBQVEsYUFBWSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxhQUFZLEtBQUksT0FBTyxFQUFFdEIsT0FBTyxHQUFHLEdBQUc7QUFBQSwrQkFBQyxVQUFLLEdBQUUsd0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFFBQU8sdUJBQUMsY0FBUyxRQUFPLDJCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUEsV0FBOUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5TSxHQUFRLE9BQU0sYUFBWSxPQUFPMEgsaUJBQWlCRyxXQUFXLEtBQUksVUFBalM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1UztBQUFBLE1BQ3ZTLHVCQUFDLFNBQUksT0FBTyxFQUFFN0gsT0FBTyxHQUFHUCxRQUFRLElBQUk2QixZQUFZLE9BQU8sS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRDtBQUFBLE1BQzFELHVCQUFDLG1CQUFnQixNQUFNLHVCQUFDLFNBQUksU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxPQUFPLEVBQUV0QixPQUFPLEdBQUcsR0FBRztBQUFBLCtCQUFDLGNBQVMsUUFBTyxzQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBLFFBQVcsdUJBQUMsY0FBUyxRQUFPLG9CQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFBVyx1QkFBQyxVQUFLLEdBQUUsMEVBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFdBQTVRO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbVIsR0FBUSxPQUFNLGdCQUFlLE9BQU8wSCxpQkFBaUJJLFdBQVcsS0FBSSxXQUE5VztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFYO0FBQUEsTUFDclgsdUJBQUMsU0FBSSxPQUFPLEVBQUU5SCxPQUFPLEdBQUdQLFFBQVEsSUFBSTZCLFlBQVksT0FBTyxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsTUFDMUQsdUJBQUMsbUJBQWdCLE1BQU0sdUJBQUMsU0FBSSxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLE9BQU8sRUFBRXRCLE9BQU8sR0FBRyxHQUFHO0FBQUEsK0JBQUMsVUFBSyxHQUFFLEtBQUksR0FBRSxLQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssSUFBRyxLQUFJLElBQUcsT0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQU8sdUJBQUMsVUFBSyxJQUFHLE1BQUssSUFBRyxLQUFJLElBQUcsTUFBSyxJQUFHLE9BQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUFPLHVCQUFDLFVBQUssSUFBRyxLQUFJLElBQUcsS0FBSSxJQUFHLEtBQUksSUFBRyxPQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFBTyx1QkFBQyxVQUFLLElBQUcsS0FBSSxJQUFHLE1BQUssSUFBRyxNQUFLLElBQUcsUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFdBQXhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK1IsR0FBUSxPQUFNLGFBQVksT0FBTzBILGlCQUFpQk8sV0FBVyxLQUFJLG1CQUF2WDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNZO0FBQUEsU0FUMVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQ3JFLG9CQUFvQixRQUFRLHVCQUFDLGVBQVksU0FBU0EsaUJBQWlCLFNBQVMsTUFBTTtBQUFFQyx5QkFBbUIsSUFBSTtBQUFHcUUsY0FBUTtBQUFBLElBQUcsS0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRjtBQUFBLElBQzNIcEUsY0FBYyx1QkFBQywyQkFBd0IsU0FBUyxNQUFNQyxjQUFjLEtBQUssR0FBRyxVQUFVLENBQUNtSCxZQUFZO0FBQUVuSCxvQkFBYyxLQUFLO0FBQUdtRSxjQUFRO0FBQUdyRSx5QkFBbUJxSCxPQUFPO0FBQUEsSUFBRyxLQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVKO0FBQUEsT0FoSjFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpSkE7QUFFUjtBQUFDbEksR0EzUmVELG1CQUFpQjtBQUFBLFVBQ1QxSSxnQkFDTkssVUFDbUJELGNBcUJiTCxVQXNGRUQsYUFTSkEsV0FBVztBQUFBO0FBQUEsTUF2SGpCNEk7QUE2UmhCLFNBQVNvSSxnQkFBZ0IsRUFBRXBMLE1BQU1ILE9BQU9xRyxPQUFPbUYsSUFBMEUsR0FBRztBQUN4SCxTQUNJLHVCQUFDLFNBQUksT0FBTyxFQUFFeEosU0FBUyxRQUFRTSxZQUFZLFVBQVVKLEtBQUssR0FBRyxHQUN6RDtBQUFBLDJCQUFDLFNBQUksT0FBTyxFQUFFTyxPQUFPLFdBQVdkLFFBQVEsdUJBQXVCQyxjQUFjLElBQUl4QixPQUFPLElBQUlQLFFBQVEsSUFBSW1DLFNBQVMsUUFBUU0sWUFBWSxVQUFVRCxnQkFBZ0IsVUFBVVgsWUFBWSx5QkFBeUIsR0FBSXZCLGtCQUFsTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVOO0FBQUEsSUFDdk4sdUJBQUMsU0FBSSxPQUFPLEVBQUU2QixTQUFTLFFBQVFDLGVBQWUsU0FBUyxHQUNuRDtBQUFBLDZCQUFDLFVBQUssT0FBTyxFQUFFTyxVQUFVLFdBQVdDLE9BQU8sUUFBUUYsWUFBWSxJQUFJLEdBQUl2QyxtQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RTtBQUFBLE1BQzdFLHVCQUFDLFNBQUksT0FBTyxFQUFFZ0MsU0FBUyxRQUFRTSxZQUFZLFlBQVlKLEtBQUssRUFBRSxHQUMxRDtBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFTSxVQUFVLFVBQVVELFlBQVksS0FBS0UsT0FBTyxRQUFRRSxZQUFZLElBQUksR0FBSTBELGtCQUFRLElBQUlBLFFBQVEsUUFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnSDtBQUFBLFFBQ2hILHVCQUFDLFVBQUssT0FBTyxFQUFFN0QsVUFBVSxVQUFVQyxPQUFPLE9BQU8sR0FBSStJLGlCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsV0FGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVSO0FBQUNDLE1BYlFGO0FBQWUsSUFBQS9LLElBQUFFLEtBQUF1QyxLQUFBeUksS0FBQUQ7QUFBQSxhQUFBakwsSUFBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBdUMsS0FBQTtBQUFBLGFBQUF5SSxLQUFBO0FBQUEsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsImdldE9wZW5PcmRlcnNCeUJyYW5jaCIsImdldE9yZGVyIiwidXBkYXRlSXRlbVN0YXR1cyIsInVzZUF1dGhTdG9yZSIsInVzZVRvYXN0IiwiQXBpRXJyb3IiLCJPcmRlckRyYXdlciIsIk9wZW5EZWxpdmVyeU9yZGVyRGlhbG9nIiwiT3JkZXJJdGVtU3RhdHVzIiwiT3JkZXJTdGF0dXMiLCJPcmRlclR5cGUiLCJmb3JtYXRCUkwiLCJiYWdJbWciLCJkb29yYmVsbEltZyIsInBhY2thZ2VJbWciLCJwb3NpdGlvbkltZyIsImJhZ2NoZWNrSW1nIiwiY2FsZW5kYXJJbWciLCJtb3RvcmN5Y2xlSW1nIiwic2NyZWVuQmdJbWciLCJWSUVXX01PREVfS0VZIiwiT05fUk9VVEVfS0VZIiwiR0hPU1RfTElNSVQiLCJDSEFOTkVMX0ZJTFRFUl9MQUJFTFMiLCJ0b2RvcyIsImRlbGl2ZXJ5IiwicmV0aXJhZGEiLCJsb2FkVmlld01vZGUiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwibG9hZE9uUm91dGUiLCJzdG9yZWQiLCJTZXQiLCJKU09OIiwicGFyc2UiLCJwZXJzaXN0T25Sb3V0ZSIsImlkcyIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJpc0RlbGl2ZXJ5Qm9hcmRPcmRlciIsIm9yZGVyIiwiZGluaW5nVGFibGVJZCIsImNvbWFuZGFJZCIsImdldENoYW5uZWwiLCJvcmRlclR5cGVJZCIsIkRlbGl2ZXJ5IiwiUkVBRFlfSVRFTV9TVEFUVVNFUyIsIlByb250byIsIkVudHJlZ3VlIiwiZGVyaXZlU3RhZ2UiLCJvblJvdXRlIiwib3JkZXJTdGF0dXNJZCIsIkNhbmNlbGFkbyIsIlBhZ28iLCJhY3RpdmVJdGVtcyIsIml0ZW1zIiwiZmlsdGVyIiwiaSIsIm9yZGVySXRlbVN0YXR1c0lkIiwiYWxsUmVhZHkiLCJsZW5ndGgiLCJldmVyeSIsImhhcyIsImFueVN0YXJ0ZWQiLCJzb21lIiwiRW52aWFkb0NvemluaGEiLCJBZ3VhcmRhbmRvUGFnYW1lbnRvIiwiaWQiLCJlbGFwc2VkTGFiZWwiLCJvcGVuZWRBdCIsIm9wZW5lZCIsIkRhdGUiLCJnZXRUaW1lIiwibWludXRlcyIsIk1hdGgiLCJtYXgiLCJyb3VuZCIsIm5vdyIsImhvdXJzIiwiZmxvb3IiLCJTdHJpbmciLCJwYWRTdGFydCIsImlsbHVzdHJhdGlvblN0eWxlIiwiaGVpZ2h0Iiwib2JqZWN0Rml0IiwiRlVMTF9DT0xVTU5TIiwibGFiZWwiLCJoaW50IiwidGhlbWVDb2xvciIsImljb24iLCJ3aWR0aCIsImVtcHR5SWxsdXN0cmF0aW9uIiwicGxhY2Vob2xkZXIiLCJTSU1QTEVfQ09MVU1OUyIsIl9jIiwiYyIsIl9jMiIsIk9yZGVyQ2FyZCIsInN0YWdlIiwiZGVuc2UiLCJvbk9wZW4iLCJvblNlbmRUb0tpdGNoZW4iLCJvbk1hcmtSZWFkeSIsIm9uTWFya09uUm91dGUiLCJidXN5IiwiY3VzdG9tZXJOYW1lIiwidHJpbSIsImNoYW5uZWxMYWJlbCIsInN0b3AiLCJmbiIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsInRleHRBbGlnbiIsImN1cnNvciIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwiYm94U2hhZG93IiwidHJhbnNpdGlvbiIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsImNvbG9yIiwiZGVsaXZlcnlBZGRyZXNzIiwibGluZUhlaWdodCIsImJvcmRlclRvcCIsInBhZGRpbmdUb3AiLCJ0b3RhbEFtb3VudCIsInJlcGxhY2UiLCJidG5BY3Rpb25TdHlsZSIsIl9jMyIsIm1hcmdpblRvcCIsIkRlbGl2ZXJ5Qm9hcmRQYWdlIiwiX3MiLCJxdWVyeUNsaWVudCIsInRvYXN0IiwiYnJhbmNoSWQiLCJlbXBsb3llZUlkIiwidmlld01vZGUiLCJzZXRWaWV3TW9kZSIsImNoYW5uZWxGaWx0ZXIiLCJzZXRDaGFubmVsRmlsdGVyIiwic2VhcmNoIiwic2V0U2VhcmNoIiwic2V0T25Sb3V0ZSIsInNlbGVjdGVkT3JkZXJJZCIsInNldFNlbGVjdGVkT3JkZXJJZCIsIm9wZW5pbmdOZXciLCJzZXRPcGVuaW5nTmV3IiwicGVuZGluZ09yZGVySWQiLCJzZXRQZW5kaW5nT3JkZXJJZCIsImdob3N0cyIsInNldEdob3N0cyIsIk1hcCIsImtub3duUmVmIiwiZmV0Y2hpbmdSZWYiLCJwcmV2aW91c1RpdGxlIiwiZG9jdW1lbnQiLCJ0aXRsZSIsIm9yZGVyc1F1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicmVmZXRjaEludGVydmFsIiwiZGF0YSIsImJvYXJkT3JkZXJzIiwiY3VycmVudElkcyIsIm1hcCIsIm8iLCJ2YW5pc2hlZCIsImN1cnJlbnQiLCJrZXlzIiwicHVzaCIsInNldCIsImZvckVhY2giLCJhZGQiLCJkZWxldGUiLCJ0aGVuIiwiZmluYWxPcmRlciIsInByZXYiLCJuZXh0Iiwic2l6ZSIsIm9sZGVzdCIsInZhbHVlIiwidW5kZWZpbmVkIiwicHJldlJvdXRlIiwiY2F0Y2giLCJmaW5hbGx5IiwidmFsdWVzIiwiZmlsdGVyZWRPcmRlcnMiLCJ0ZXJtIiwidG9Mb3dlckNhc2UiLCJoYXlzdGFjayIsImN1c3RvbWVyUGhvbmUiLCJqb2luIiwiaW5jbHVkZXMiLCJvcmRlcnNCeVN0YWdlIiwibm92byIsImNvemluaGEiLCJhZ3VhcmRhbmRvIiwicm90YSIsImVudHJlZ3VlIiwiY2FuY2VsYWRvIiwibGlzdCIsIk9iamVjdCIsInNvcnQiLCJhIiwiYiIsImRhc2hib2FyZE1ldHJpY3MiLCJhY3RpdmVPcmRlcnMiLCJ0b3RhbCIsImVudHJlZ3VlcyIsImFuZGFtZW50byIsInN1bU1pbnV0ZXMiLCJhdmdUaW1lIiwiYWdlbmRhZG9zIiwicmVmcmVzaCIsImludmFsaWRhdGVRdWVyaWVzIiwib25FcnIiLCJmYWxsYmFjayIsImVycm9yIiwibWVzc2FnZSIsInNlbmRUb0tpdGNoZW4iLCJtdXRhdGlvbkZuIiwicGVuZGluZyIsIkxhbmNhZG8iLCJQcm9taXNlIiwiYWxsIiwib25TdWNjZXNzIiwiX2RhdGEiLCJzdWNjZXNzIiwib25FcnJvciIsIm1hcmtSZWFkeSIsImhhbmRsZVNlbmRUb0tpdGNoZW4iLCJtdXRhdGUiLCJoYW5kbGVNYXJrUmVhZHkiLCJoYW5kbGVNYXJrT25Sb3V0ZSIsImNvbHVtbnMiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJiYWNrZ3JvdW5kU2l6ZSIsImJhY2tncm91bmRQb3NpdGlvbiIsImJhY2tncm91bmRDb2xvciIsIm1pbkhlaWdodCIsImZvbnRGYW1pbHkiLCJtYXJnaW5Cb3R0b20iLCJtaXhCbGVuZE1vZGUiLCJtYXJnaW4iLCJ0ZXh0VHJhbnNmb3JtIiwibGV0dGVyU3BhY2luZyIsInBvc2l0aW9uIiwiZmxleCIsIm1heFdpZHRoIiwidGFyZ2V0Iiwib3V0bGluZSIsImxlZnQiLCJ0b3AiLCJtYXJnaW5MZWZ0Iiwib3ZlcmZsb3dYIiwicGFkZGluZ0JvdHRvbSIsImNvbCIsIm1pbldpZHRoIiwib3ZlcmZsb3dZIiwib3BhY2l0eSIsImJvcmRlckJvdHRvbSIsIm9yZGVySWQiLCJEYXNoYm9hcmRNZXRyaWMiLCJzdWIiLCJfYzUiLCJfYzQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGVsaXZlcnlCb2FyZFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgZ2V0T3Blbk9yZGVyc0J5QnJhbmNoLCBnZXRPcmRlciwgdXBkYXRlSXRlbVN0YXR1cyB9IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi8uLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IE9yZGVyRHJhd2VyIH0gZnJvbSBcIi4vT3JkZXJEcmF3ZXJcIjtcclxuaW1wb3J0IHsgT3BlbkRlbGl2ZXJ5T3JkZXJEaWFsb2cgfSBmcm9tIFwiLi9PcGVuRGVsaXZlcnlPcmRlckRpYWxvZ1wiO1xyXG5pbXBvcnQgeyBPcmRlckl0ZW1TdGF0dXMsIE9yZGVyU3RhdHVzLCBPcmRlclR5cGUsIGZvcm1hdEJSTCB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHR5cGUgeyBPcmRlclJlc3BvbnNlIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5cclxuLy8gLS0tIElNUE9SVEHDh8ODTyBEQVMgSU1BR0VOUyAtLS1cclxuLy8gQWp1c3RlIG8gY2FtaW5obyBcIi4uLy4uL2ltYWdlL1wiIGNvbmZvcm1lIGEgbG9jYWxpemHDp8OjbyBleGF0YSBkZXN0ZSBhcnF1aXZvIGRlbnRybyBkZSBcInNyY1wiXHJcbmltcG9ydCBiYWdJbWcgZnJvbSBcIi4uLy4uL2ltYWdlL2JhZy5wbmdcIjtcclxuaW1wb3J0IGRvb3JiZWxsSW1nIGZyb20gXCIuLi8uLi9pbWFnZS9kb29yYmVsbC5wbmdcIjtcclxuaW1wb3J0IHBhY2thZ2VJbWcgZnJvbSBcIi4uLy4uL2ltYWdlL3BhY2thZ2UucG5nXCI7XHJcbmltcG9ydCBwb3NpdGlvbkltZyBmcm9tIFwiLi4vLi4vaW1hZ2UvcG9zaXRpb24ucG5nXCI7XHJcbmltcG9ydCBiYWdjaGVja0ltZyBmcm9tIFwiLi4vLi4vaW1hZ2UvYmFnY2hlY2sucG5nXCI7XHJcbmltcG9ydCBjYWxlbmRhckltZyBmcm9tIFwiLi4vLi4vaW1hZ2UvY2FsZW5kYXIucG5nXCI7XHJcbmltcG9ydCBtb3RvcmN5Y2xlSW1nIGZyb20gXCIuLi8uLi9pbWFnZS9tb3RvcmN5Y2xlLmpwZWdcIjtcclxuaW1wb3J0IHNjcmVlbkJnSW1nIGZyb20gXCIuLi8uLi9pbWFnZS9zY3JlZW5iYWNrZ3JvdW5kLmpwZWdcIjtcclxuXHJcbi8vIC0tLSBUSVBBR0VOUyBFIENPTlNUQU5URVMgLS0tXHJcbnR5cGUgU3RhZ2UgPSBcIm5vdm9cIiB8IFwiY296aW5oYVwiIHwgXCJhZ3VhcmRhbmRvXCIgfCBcInJvdGFcIiB8IFwiZW50cmVndWVcIiB8IFwiY2FuY2VsYWRvXCI7XHJcbnR5cGUgVmlld01vZGUgPSBcInNpbXBsZXNcIiB8IFwiY29tcGxldG9cIjtcclxudHlwZSBDaGFubmVsRmlsdGVyID0gXCJ0b2Rvc1wiIHwgXCJkZWxpdmVyeVwiIHwgXCJyZXRpcmFkYVwiO1xyXG5cclxuY29uc3QgVklFV19NT0RFX0tFWSA9IFwic3luY2JhcjpkZWxpdmVyeS12aWV3LW1vZGVcIjtcclxuY29uc3QgT05fUk9VVEVfS0VZID0gXCJzeW5jYmFyOmRlbGl2ZXJ5LW9uLXJvdXRlXCI7XHJcbmNvbnN0IEdIT1NUX0xJTUlUID0gNDA7XHJcblxyXG5jb25zdCBDSEFOTkVMX0ZJTFRFUl9MQUJFTFM6IFJlY29yZDxDaGFubmVsRmlsdGVyLCBzdHJpbmc+ID0ge1xyXG4gICAgdG9kb3M6IFwiVG9kb3NcIixcclxuICAgIGRlbGl2ZXJ5OiBcIkRlbGl2ZXJ5XCIsXHJcbiAgICByZXRpcmFkYTogXCJSZXRpcmFkYVwiLFxyXG59O1xyXG5cclxuLy8gLS0tIEZVTsOHw5VFUyBVVElMSVTDgVJJQVMgLS0tXHJcbmZ1bmN0aW9uIGxvYWRWaWV3TW9kZSgpOiBWaWV3TW9kZSB7XHJcbiAgICB0cnkgeyByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oVklFV19NT0RFX0tFWSkgPT09IFwiY29tcGxldG9cIiA/IFwiY29tcGxldG9cIiA6IFwic2ltcGxlc1wiOyB9XHJcbiAgICBjYXRjaCB7IHJldHVybiBcInNpbXBsZXNcIjsgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBsb2FkT25Sb3V0ZSgpOiBTZXQ8bnVtYmVyPiB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHN0b3JlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKE9OX1JPVVRFX0tFWSk7XHJcbiAgICAgICAgcmV0dXJuIHN0b3JlZCA/IG5ldyBTZXQoSlNPTi5wYXJzZShzdG9yZWQpIGFzIG51bWJlcltdKSA6IG5ldyBTZXQoKTtcclxuICAgIH0gY2F0Y2ggeyByZXR1cm4gbmV3IFNldCgpOyB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBlcnNpc3RPblJvdXRlKGlkczogU2V0PG51bWJlcj4pIHtcclxuICAgIHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKE9OX1JPVVRFX0tFWSwgSlNPTi5zdHJpbmdpZnkoWy4uLmlkc10pKTsgfSBjYXRjaCB7IH1cclxufVxyXG5cclxuY29uc3QgaXNEZWxpdmVyeUJvYXJkT3JkZXIgPSAob3JkZXI6IE9yZGVyUmVzcG9uc2UpID0+IG9yZGVyLmRpbmluZ1RhYmxlSWQgPT09IG51bGwgJiYgb3JkZXIuY29tYW5kYUlkID09PSBudWxsO1xyXG5jb25zdCBnZXRDaGFubmVsID0gKG9yZGVyOiBPcmRlclJlc3BvbnNlKTogXCJkZWxpdmVyeVwiIHwgXCJyZXRpcmFkYVwiID0+IG9yZGVyLm9yZGVyVHlwZUlkID09PSBPcmRlclR5cGUuRGVsaXZlcnkgPyBcImRlbGl2ZXJ5XCIgOiBcInJldGlyYWRhXCI7XHJcbmNvbnN0IFJFQURZX0lURU1fU1RBVFVTRVMgPSBuZXcgU2V0PG51bWJlcj4oW09yZGVySXRlbVN0YXR1cy5Qcm9udG8sIE9yZGVySXRlbVN0YXR1cy5FbnRyZWd1ZV0pO1xyXG5cclxuZnVuY3Rpb24gZGVyaXZlU3RhZ2Uob3JkZXI6IE9yZGVyUmVzcG9uc2UsIG9uUm91dGU6IFNldDxudW1iZXI+KTogU3RhZ2Uge1xyXG4gICAgaWYgKG9yZGVyLm9yZGVyU3RhdHVzSWQgPT09IE9yZGVyU3RhdHVzLkNhbmNlbGFkbykgcmV0dXJuIFwiY2FuY2VsYWRvXCI7XHJcbiAgICBpZiAob3JkZXIub3JkZXJTdGF0dXNJZCA9PT0gT3JkZXJTdGF0dXMuUGFnbykgcmV0dXJuIFwiZW50cmVndWVcIjtcclxuXHJcbiAgICBjb25zdCBhY3RpdmVJdGVtcyA9IG9yZGVyLml0ZW1zLmZpbHRlcigoaSkgPT4gaS5vcmRlckl0ZW1TdGF0dXNJZCAhPT0gT3JkZXJJdGVtU3RhdHVzLkNhbmNlbGFkbyk7XHJcbiAgICBjb25zdCBhbGxSZWFkeSA9IGFjdGl2ZUl0ZW1zLmxlbmd0aCA+IDAgJiYgYWN0aXZlSXRlbXMuZXZlcnkoKGkpID0+IFJFQURZX0lURU1fU1RBVFVTRVMuaGFzKGkub3JkZXJJdGVtU3RhdHVzSWQpKTtcclxuICAgIGNvbnN0IGFueVN0YXJ0ZWQgPSBhY3RpdmVJdGVtcy5zb21lKChpKSA9PiBpLm9yZGVySXRlbVN0YXR1c0lkID49IE9yZGVySXRlbVN0YXR1cy5FbnZpYWRvQ296aW5oYSk7XHJcblxyXG4gICAgaWYgKG9yZGVyLm9yZGVyU3RhdHVzSWQgPT09IE9yZGVyU3RhdHVzLkFndWFyZGFuZG9QYWdhbWVudG8gfHwgYWxsUmVhZHkpXHJcbiAgICAgICAgcmV0dXJuIG9uUm91dGUuaGFzKG9yZGVyLmlkKSA/IFwicm90YVwiIDogXCJhZ3VhcmRhbmRvXCI7XHJcbiAgICBpZiAoYW55U3RhcnRlZCkgcmV0dXJuIFwiY296aW5oYVwiO1xyXG4gICAgcmV0dXJuIFwibm92b1wiO1xyXG59XHJcblxyXG5mdW5jdGlvbiBlbGFwc2VkTGFiZWwob3BlbmVkQXQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBvcGVuZWQgPSBuZXcgRGF0ZShvcGVuZWRBdCkuZ2V0VGltZSgpO1xyXG4gICAgY29uc3QgbWludXRlcyA9IE1hdGgubWF4KDAsIE1hdGgucm91bmQoKERhdGUubm93KCkgLSBvcGVuZWQpIC8gNjBfMDAwKSk7XHJcbiAgICBpZiAobWludXRlcyA8IDYwKSByZXR1cm4gYCR7bWludXRlc30gbWluYDtcclxuICAgIGNvbnN0IGhvdXJzID0gTWF0aC5mbG9vcihtaW51dGVzIC8gNjApO1xyXG4gICAgcmV0dXJuIGAke2hvdXJzfWgke1N0cmluZyhtaW51dGVzICUgNjApLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG59XHJcblxyXG4vLyAtLS0gREVGSU5Jw4fDg08gREUgQ09MVU5BUyAtLS1cclxuaW50ZXJmYWNlIENvbHVtbkRlZiB7XHJcbiAgICBpZDogU3RhZ2UgfCBcImFnZW5kYW1lbnRvXCI7XHJcbiAgICBsYWJlbDogc3RyaW5nO1xyXG4gICAgaGludDogc3RyaW5nO1xyXG4gICAgaWNvbjogUmVhY3QuUmVhY3ROb2RlO1xyXG4gICAgZW1wdHlJbGx1c3RyYXRpb246IFJlYWN0LlJlYWN0Tm9kZTtcclxuICAgIHRoZW1lQ29sb3I6IHN0cmluZztcclxuICAgIHBsYWNlaG9sZGVyPzogYm9vbGVhbjtcclxufVxyXG5cclxuY29uc3QgaWxsdXN0cmF0aW9uU3R5bGUgPSB7IGhlaWdodDogMTQwLCBvYmplY3RGaXQ6IFwiY29udGFpblwiIGFzIGNvbnN0IH07XHJcblxyXG5jb25zdCBGVUxMX0NPTFVNTlM6IENvbHVtbkRlZltdID0gW1xyXG4gICAge1xyXG4gICAgICAgIGlkOiBcIm5vdm9cIiwgbGFiZWw6IFwiTk9WT1MgUEVESURPU1wiLCBoaW50OiBcIkFndWFyZGFuZG8gYWNlaXRlXCIsIHRoZW1lQ29sb3I6IFwiI0ZGNkIwMFwiLFxyXG4gICAgICAgIGljb246IDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0eWxlPXt7IHdpZHRoOiAyMCwgaGVpZ2h0OiAyMCB9fT48cGF0aCBkPVwiTTYgMkwzIDZ2MTRhMiAyIDAgMCAwIDIgMmgxNGEyIDIgMCAwIDAgMi0yVjZsLTMtNHpcIj48L3BhdGg+PGxpbmUgeDE9XCIzXCIgeTE9XCI2XCIgeDI9XCIyMVwiIHkyPVwiNlwiPjwvbGluZT48cGF0aCBkPVwiTTE2IDEwYTQgNCAwIDAgMS04IDBcIj48L3BhdGg+PC9zdmc+LFxyXG4gICAgICAgIGVtcHR5SWxsdXN0cmF0aW9uOiA8aW1nIHNyYz17YmFnSW1nfSBhbHQ9XCJOb3ZvcyBQZWRpZG9zXCIgc3R5bGU9e2lsbHVzdHJhdGlvblN0eWxlfSAvPlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBpZDogXCJjb3ppbmhhXCIsIGxhYmVsOiBcIkNPWklOSEFcIiwgaGludDogXCJBZ3VhcmRhbmRvIHByZXBhcm9cIiwgdGhlbWVDb2xvcjogXCIjRkY4QTAwXCIsXHJcbiAgICAgICAgaWNvbjogPHN2ZyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3R5bGU9e3sgd2lkdGg6IDIwLCBoZWlnaHQ6IDIwIH19PjxwYXRoIGQ9XCJNMTIgMnYyME0xNyA1SDkuNWEzLjUgMy41IDAgMCAwIDAgN2g1YTMuNSAzLjUgMCAwIDEgMCA3SDZcIj48L3BhdGg+PC9zdmc+LFxyXG4gICAgICAgIGVtcHR5SWxsdXN0cmF0aW9uOiA8aW1nIHNyYz17ZG9vcmJlbGxJbWd9IGFsdD1cIkNvemluaGFcIiBzdHlsZT17aWxsdXN0cmF0aW9uU3R5bGV9IC8+XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIGlkOiBcImFndWFyZGFuZG9cIiwgbGFiZWw6IFwiQUdVQVJEQU5ETyBFTlRSRUdBXCIsIGhpbnQ6IFwiU2VwYXJhw6fDo28gZSBjb25mZXLDqm5jaWFcIiwgdGhlbWVDb2xvcjogXCIjRkY1NTAwXCIsXHJcbiAgICAgICAgaWNvbjogPHN2ZyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3R5bGU9e3sgd2lkdGg6IDIwLCBoZWlnaHQ6IDIwIH19PjxsaW5lIHgxPVwiMTYuNVwiIHkxPVwiOS40XCIgeDI9XCI3LjVcIiB5Mj1cIjQuMjFcIj48L2xpbmU+PHBhdGggZD1cIk0yMSAxNlY4YTIgMiAwIDAgMC0xLTEuNzNsLTctNGEyIDIgMCAwIDAtMiAwbC03IDRBMiAyIDAgMCAwIDMgOHY4YTIgMiAwIDAgMCAxIDEuNzNsNyA0YTIgMiAwIDAgMCAyIDBsNy00QTIgMiAwIDAgMCAyMSAxNnpcIj48L3BhdGg+PHBvbHlsaW5lIHBvaW50cz1cIjMuMjcgNi45NiAxMiAxMi4wMSAyMC43MyA2Ljk2XCI+PC9wb2x5bGluZT48bGluZSB4MT1cIjEyXCIgeTE9XCIyMi4wOFwiIHgyPVwiMTJcIiB5Mj1cIjEyXCI+PC9saW5lPjwvc3ZnPixcclxuICAgICAgICBlbXB0eUlsbHVzdHJhdGlvbjogPGltZyBzcmM9e3BhY2thZ2VJbWd9IGFsdD1cIkFndWFyZGFuZG8gRW50cmVnYVwiIHN0eWxlPXtpbGx1c3RyYXRpb25TdHlsZX0gLz5cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgaWQ6IFwicm90YVwiLCBsYWJlbDogXCJTQUlVIFBBUkEgRU5UUkVHQVwiLCBoaW50OiBcIlBlZGlkb3MgZW0gcm90YVwiLCB0aGVtZUNvbG9yOiBcIiNGRkI4MDBcIixcclxuICAgICAgICBpY29uOiA8c3ZnIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHlsZT17eyB3aWR0aDogMjAsIGhlaWdodDogMjAgfX0+PHBhdGggZD1cIk0yMSAxMGMwIDctOSAxMy05IDEzcy05LTYtOS0xM2E5IDkgMCAwIDEgMTggMHpcIj48L3BhdGg+PGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMFwiIHI9XCIzXCI+PC9jaXJjbGU+PC9zdmc+LFxyXG4gICAgICAgIGVtcHR5SWxsdXN0cmF0aW9uOiA8aW1nIHNyYz17cG9zaXRpb25JbWd9IGFsdD1cIkVtIFJvdGFcIiBzdHlsZT17aWxsdXN0cmF0aW9uU3R5bGV9IC8+XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIGlkOiBcImVudHJlZ3VlXCIsIGxhYmVsOiBcIkVOVFJFR1VFXCIsIGhpbnQ6IFwiw5psdGltYSBob3JhXCIsIHRoZW1lQ29sb3I6IFwiI0Y1QzM0NFwiLFxyXG4gICAgICAgIGljb246IDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0eWxlPXt7IHdpZHRoOiAyMCwgaGVpZ2h0OiAyMCB9fT48cG9seWxpbmUgcG9pbnRzPVwiMjAgNiA5IDE3IDQgMTJcIj48L3BvbHlsaW5lPjwvc3ZnPixcclxuICAgICAgICBlbXB0eUlsbHVzdHJhdGlvbjogPGltZyBzcmM9e2JhZ2NoZWNrSW1nfSBhbHQ9XCJFbnRyZWd1ZVwiIHN0eWxlPXtpbGx1c3RyYXRpb25TdHlsZX0gLz5cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgaWQ6IFwiYWdlbmRhbWVudG9cIiwgbGFiZWw6IFwiQUdFTkRBTUVOVE9cIiwgaGludDogXCJFbSBicmV2ZVwiLCB0aGVtZUNvbG9yOiBcIiNCMEIwQjBcIiwgcGxhY2Vob2xkZXI6IHRydWUsXHJcbiAgICAgICAgaWNvbjogPHN2ZyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3R5bGU9e3sgd2lkdGg6IDIwLCBoZWlnaHQ6IDIwIH19PjxyZWN0IHg9XCIzXCIgeT1cIjRcIiB3aWR0aD1cIjE4XCIgaGVpZ2h0PVwiMThcIiByeD1cIjJcIiByeT1cIjJcIj48L3JlY3Q+PGxpbmUgeDE9XCIxNlwiIHkxPVwiMlwiIHgyPVwiMTZcIiB5Mj1cIjZcIj48L2xpbmU+PGxpbmUgeDE9XCI4XCIgeTE9XCIyXCIgeDI9XCI4XCIgeTI9XCI2XCI+PC9saW5lPjxsaW5lIHgxPVwiM1wiIHkxPVwiMTBcIiB4Mj1cIjIxXCIgeTI9XCIxMFwiPjwvbGluZT48L3N2Zz4sXHJcbiAgICAgICAgZW1wdHlJbGx1c3RyYXRpb246IDxpbWcgc3JjPXtjYWxlbmRhckltZ30gYWx0PVwiQWdlbmRhbWVudG9cIiBzdHlsZT17aWxsdXN0cmF0aW9uU3R5bGV9IC8+XHJcbiAgICB9LFxyXG5dO1xyXG5cclxuY29uc3QgU0lNUExFX0NPTFVNTlMgPSBGVUxMX0NPTFVNTlMuZmlsdGVyKGMgPT4gYy5pZCAhPT0gXCJhZ2VuZGFtZW50b1wiICYmIGMuaWQgIT09IFwiY2FuY2VsYWRvXCIpO1xyXG5cclxuLy8gLS0tIENPTVBPTkVOVEVTIFZJU1VBSVMgLS0tXHJcbmZ1bmN0aW9uIE9yZGVyQ2FyZCh7IG9yZGVyLCBzdGFnZSwgZGVuc2UsIG9uT3Blbiwgb25TZW5kVG9LaXRjaGVuLCBvbk1hcmtSZWFkeSwgb25NYXJrT25Sb3V0ZSwgYnVzeSB9OiBhbnkpIHtcclxuICAgIGNvbnN0IGN1c3RvbWVyTmFtZSA9IG9yZGVyLmN1c3RvbWVyTmFtZT8udHJpbSgpIHx8IGBQZWRpZG8gIyR7b3JkZXIuaWR9YDtcclxuICAgIGNvbnN0IGNoYW5uZWxMYWJlbCA9IGdldENoYW5uZWwob3JkZXIpID09PSBcImRlbGl2ZXJ5XCIgPyBcIkRFTElWRVJZXCIgOiBcIlJFVElSQURBXCI7XHJcblxyXG4gICAgY29uc3Qgc3RvcCA9IChmbjogKCkgPT4gdm9pZCkgPT4gKGU6IFJlYWN0Lk1vdXNlRXZlbnQpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgZm4oKTsgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uT3Blbn0gc3R5bGU9e3tcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogXCIjZmZmXCIsIGJvcmRlcjogXCIxcHggc29saWQgI0VGRUZFRlwiLCBib3JkZXJSYWRpdXM6IDEyLCBwYWRkaW5nOiAxNiwgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgICAgICAgICB0ZXh0QWxpZ246IFwibGVmdFwiLCBjdXJzb3I6IFwicG9pbnRlclwiLCBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgZ2FwOiAxMixcclxuICAgICAgICAgICAgYm94U2hhZG93OiBcIjAgMnB4IDhweCByZ2JhKDAsMCwwLDAuMDQpXCIsIHRyYW5zaXRpb246IFwidHJhbnNmb3JtIDAuMXNcIlxyXG4gICAgICAgIH19PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA4MDAsIGZvbnRTaXplOiBcIjEuMXJlbVwiLCBjb2xvcjogXCIjMUExQTFBXCIgfX0+I3tvcmRlci5pZH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjc1cmVtXCIsIGZvbnRXZWlnaHQ6IDcwMCwgcGFkZGluZzogXCI0cHggOHB4XCIsIGJvcmRlclJhZGl1czogNiwgYmFja2dyb3VuZDogXCIjRjVGNUY1XCIsIGNvbG9yOiBcIiM1NTVcIiwgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7Y2hhbm5lbExhYmVsID09PSBcIkRFTElWRVJZXCIgPyBcIvCfm7VcIiA6IFwi8J+PrFwifSB7Y2hhbm5lbExhYmVsfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDcwMCwgY29sb3I6IFwiIzFBMUExQVwiLCBmb250U2l6ZTogXCIwLjk1cmVtXCIgfX0+e2N1c3RvbWVyTmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB7IWRlbnNlICYmIG9yZGVyLmRlbGl2ZXJ5QWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44cmVtXCIsIGNvbG9yOiBcIiM3NzdcIiwgbGluZUhlaWdodDogMS4zIH19PntvcmRlci5kZWxpdmVyeUFkZHJlc3N9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwiIzU1NVwiLCBib3JkZXJUb3A6IFwiMXB4IGRhc2hlZCAjRUVFXCIsIHBhZGRpbmdUb3A6IDEyIH19PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19PlIkIHtmb3JtYXRCUkwob3JkZXIudG90YWxBbW91bnQpLnJlcGxhY2UoJ1IkJywgJycpLnRyaW0oKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj57b3JkZXIuaXRlbXMubGVuZ3RofSB7b3JkZXIuaXRlbXMubGVuZ3RoID09PSAxID8gXCJpdGVtXCIgOiBcIml0ZW5zXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IFwiMC43NXJlbVwiLCBjb2xvcjogXCIjODg4XCIsIGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5hYmVydG8gaMOhIHtlbGFwc2VkTGFiZWwob3JkZXIub3BlbmVkQXQpfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7c3RhZ2UgPT09IFwibm92b1wiICYmIDxidXR0b24gb25DbGljaz17c3RvcChvblNlbmRUb0tpdGNoZW4pfSBkaXNhYmxlZD17YnVzeX0gc3R5bGU9e2J0bkFjdGlvblN0eWxlfT57YnVzeSA/IFwiRW52aWFuZG/igKZcIiA6IFwiRW52aWFyIHAvIGNvemluaGFcIn08L2J1dHRvbj59XHJcbiAgICAgICAgICAgIHtzdGFnZSA9PT0gXCJjb3ppbmhhXCIgJiYgPGJ1dHRvbiBvbkNsaWNrPXtzdG9wKG9uTWFya1JlYWR5KX0gZGlzYWJsZWQ9e2J1c3l9IHN0eWxlPXtidG5BY3Rpb25TdHlsZX0+e2J1c3kgPyBcIkF0dWFsaXphbmRv4oCmXCIgOiBcIlByb250byBwLyBzYcOtZGFcIn08L2J1dHRvbj59XHJcbiAgICAgICAgICAgIHtzdGFnZSA9PT0gXCJhZ3VhcmRhbmRvXCIgJiYgPGJ1dHRvbiBvbkNsaWNrPXtzdG9wKG9uTWFya09uUm91dGUpfSBkaXNhYmxlZD17YnVzeX0gc3R5bGU9e2J0bkFjdGlvblN0eWxlfT5TYWl1IHBhcmEgZW50cmVnYTwvYnV0dG9uPn1cclxuICAgICAgICAgICAge3N0YWdlID09PSBcInJvdGFcIiAmJiA8YnV0dG9uIG9uQ2xpY2s9e3N0b3Aob25PcGVuKX0gZGlzYWJsZWQ9e2J1c3l9IHN0eWxlPXtidG5BY3Rpb25TdHlsZX0+Q29uZmlybWFyIGVudHJlZ2E8L2J1dHRvbj59XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICApO1xyXG59XHJcblxyXG5jb25zdCBidG5BY3Rpb25TdHlsZTogUmVhY3QuQ1NTUHJvcGVydGllcyA9IHtcclxuICAgIHdpZHRoOiBcIjEwMCVcIiwgcGFkZGluZzogXCIxMHB4XCIsIGJvcmRlclJhZGl1czogOCwgYm9yZGVyOiBcIm5vbmVcIiwgYmFja2dyb3VuZDogXCJsaW5lYXItZ3JhZGllbnQoOTBkZWcsICNGRjdCMDAgMCUsICNGRjU1MDAgMTAwJSlcIixcclxuICAgIGNvbG9yOiBcIiNmZmZcIiwgZm9udFdlaWdodDogNzAwLCBjdXJzb3I6IFwicG9pbnRlclwiLCBtYXJnaW5Ub3A6IDQsIGZvbnRTaXplOiBcIjAuOXJlbVwiXHJcbn07XHJcblxyXG4vLyAtLS0gUMOBR0lOQSBQUklOQ0lQQUwgLS0tXHJcbmV4cG9ydCBmdW5jdGlvbiBEZWxpdmVyeUJvYXJkUGFnZSgpIHtcclxuICAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICAgIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICAgIGNvbnN0IHsgYnJhbmNoSWQsIGVtcGxveWVlSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG5cclxuICAgIGNvbnN0IFt2aWV3TW9kZSwgc2V0Vmlld01vZGVdID0gdXNlU3RhdGU8Vmlld01vZGU+KGxvYWRWaWV3TW9kZSk7XHJcbiAgICBjb25zdCBbY2hhbm5lbEZpbHRlciwgc2V0Q2hhbm5lbEZpbHRlcl0gPSB1c2VTdGF0ZTxDaGFubmVsRmlsdGVyPihcInRvZG9zXCIpO1xyXG4gICAgY29uc3QgW3NlYXJjaCwgc2V0U2VhcmNoXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW29uUm91dGUsIHNldE9uUm91dGVdID0gdXNlU3RhdGU8U2V0PG51bWJlcj4+KGxvYWRPblJvdXRlKTtcclxuICAgIGNvbnN0IFtzZWxlY3RlZE9yZGVySWQsIHNldFNlbGVjdGVkT3JkZXJJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFtvcGVuaW5nTmV3LCBzZXRPcGVuaW5nTmV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtwZW5kaW5nT3JkZXJJZCwgc2V0UGVuZGluZ09yZGVySWRdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbZ2hvc3RzLCBzZXRHaG9zdHNdID0gdXNlU3RhdGU8TWFwPG51bWJlciwgT3JkZXJSZXNwb25zZT4+KG5ldyBNYXAoKSk7XHJcbiAgICBjb25zdCBrbm93blJlZiA9IHVzZVJlZjxNYXA8bnVtYmVyLCBPcmRlclJlc3BvbnNlPj4obmV3IE1hcCgpKTtcclxuICAgIGNvbnN0IGZldGNoaW5nUmVmID0gdXNlUmVmPFNldDxudW1iZXI+PihuZXcgU2V0KCkpO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKFZJRVdfTU9ERV9LRVksIHZpZXdNb2RlKTsgfSwgW3ZpZXdNb2RlXSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBwcmV2aW91c1RpdGxlID0gZG9jdW1lbnQudGl0bGU7XHJcbiAgICAgICAgZG9jdW1lbnQudGl0bGUgPSBcIkRpbmcuZm9vZCDigJQgRGVsaXZlcnlcIjtcclxuICAgICAgICByZXR1cm4gKCkgPT4geyBkb2N1bWVudC50aXRsZSA9IHByZXZpb3VzVGl0bGU7IH07XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgY29uc3Qgb3JkZXJzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcIm9yZGVyc1wiLCBcIm9wZW5cIiwgYnJhbmNoSWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldE9wZW5PcmRlcnNCeUJyYW5jaChicmFuY2hJZCksXHJcbiAgICAgICAgcmVmZXRjaEludGVydmFsOiAxNV8wMDAsXHJcbiAgICB9KTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGlmICghb3JkZXJzUXVlcnkuZGF0YSkgcmV0dXJuO1xyXG4gICAgICAgIGNvbnN0IGJvYXJkT3JkZXJzID0gb3JkZXJzUXVlcnkuZGF0YS5maWx0ZXIoaXNEZWxpdmVyeUJvYXJkT3JkZXIpO1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRJZHMgPSBuZXcgU2V0KGJvYXJkT3JkZXJzLm1hcCgobykgPT4gby5pZCkpO1xyXG4gICAgICAgIGNvbnN0IHZhbmlzaGVkOiBudW1iZXJbXSA9IFtdO1xyXG5cclxuICAgICAgICBmb3IgKGNvbnN0IGlkIG9mIGtub3duUmVmLmN1cnJlbnQua2V5cygpKSB7XHJcbiAgICAgICAgICAgIGlmICghY3VycmVudElkcy5oYXMoaWQpKSB2YW5pc2hlZC5wdXNoKGlkKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChjb25zdCBvcmRlciBvZiBib2FyZE9yZGVycykga25vd25SZWYuY3VycmVudC5zZXQob3JkZXIuaWQsIG9yZGVyKTtcclxuXHJcbiAgICAgICAgdmFuaXNoZWQuZm9yRWFjaCgoaWQpID0+IHtcclxuICAgICAgICAgICAgaWYgKGZldGNoaW5nUmVmLmN1cnJlbnQuaGFzKGlkKSkgcmV0dXJuO1xyXG4gICAgICAgICAgICBmZXRjaGluZ1JlZi5jdXJyZW50LmFkZChpZCk7XHJcbiAgICAgICAgICAgIGtub3duUmVmLmN1cnJlbnQuZGVsZXRlKGlkKTtcclxuICAgICAgICAgICAgZ2V0T3JkZXIoaWQpLnRoZW4oKGZpbmFsT3JkZXIpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldEdob3N0cygocHJldikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5leHQgPSBuZXcgTWFwKHByZXYpO1xyXG4gICAgICAgICAgICAgICAgICAgIG5leHQuc2V0KGlkLCBmaW5hbE9yZGVyKTtcclxuICAgICAgICAgICAgICAgICAgICB3aGlsZSAobmV4dC5zaXplID4gR0hPU1RfTElNSVQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgb2xkZXN0ID0gbmV4dC5rZXlzKCkubmV4dCgpLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAob2xkZXN0ID09PSB1bmRlZmluZWQpIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuZXh0LmRlbGV0ZShvbGRlc3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV4dDtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgc2V0T25Sb3V0ZSgocHJldlJvdXRlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFwcmV2Um91dGUuaGFzKGlkKSkgcmV0dXJuIHByZXZSb3V0ZTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2Um91dGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIG5leHQuZGVsZXRlKGlkKTtcclxuICAgICAgICAgICAgICAgICAgICBwZXJzaXN0T25Sb3V0ZShuZXh0KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV4dDtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KS5jYXRjaCgoKSA9PiB7IH0pLmZpbmFsbHkoKCkgPT4gZmV0Y2hpbmdSZWYuY3VycmVudC5kZWxldGUoaWQpKTtcclxuICAgICAgICB9KTtcclxuICAgIH0sIFtvcmRlcnNRdWVyeS5kYXRhXSk7XHJcblxyXG4gICAgY29uc3QgYm9hcmRPcmRlcnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBjb25zdCBtYXAgPSBuZXcgTWFwPG51bWJlciwgT3JkZXJSZXNwb25zZT4oKTtcclxuICAgICAgICBmb3IgKGNvbnN0IG9yZGVyIG9mIGdob3N0cy52YWx1ZXMoKSkgaWYgKGlzRGVsaXZlcnlCb2FyZE9yZGVyKG9yZGVyKSkgbWFwLnNldChvcmRlci5pZCwgb3JkZXIpO1xyXG4gICAgICAgIGZvciAoY29uc3Qgb3JkZXIgb2Ygb3JkZXJzUXVlcnkuZGF0YSA/PyBbXSkgaWYgKGlzRGVsaXZlcnlCb2FyZE9yZGVyKG9yZGVyKSkgbWFwLnNldChvcmRlci5pZCwgb3JkZXIpO1xyXG4gICAgICAgIHJldHVybiBbLi4ubWFwLnZhbHVlcygpXTtcclxuICAgIH0sIFtvcmRlcnNRdWVyeS5kYXRhLCBnaG9zdHNdKTtcclxuXHJcbiAgICBjb25zdCBmaWx0ZXJlZE9yZGVycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRlcm0gPSBzZWFyY2gudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgcmV0dXJuIGJvYXJkT3JkZXJzLmZpbHRlcigob3JkZXIpID0+IHtcclxuICAgICAgICAgICAgaWYgKGNoYW5uZWxGaWx0ZXIgIT09IFwidG9kb3NcIiAmJiBnZXRDaGFubmVsKG9yZGVyKSAhPT0gY2hhbm5lbEZpbHRlcikgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICBpZiAodGVybSA9PT0gXCJcIikgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgIGNvbnN0IGhheXN0YWNrID0gW1N0cmluZyhvcmRlci5pZCksIG9yZGVyLmN1c3RvbWVyTmFtZSA/PyBcIlwiLCBvcmRlci5kZWxpdmVyeUFkZHJlc3MgPz8gXCJcIiwgb3JkZXIuY3VzdG9tZXJQaG9uZSA/PyBcIlwiXS5qb2luKFwiIFwiKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgICAgICByZXR1cm4gaGF5c3RhY2suaW5jbHVkZXModGVybSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9LCBbYm9hcmRPcmRlcnMsIGNoYW5uZWxGaWx0ZXIsIHNlYXJjaF0pO1xyXG5cclxuICAgIGNvbnN0IG9yZGVyc0J5U3RhZ2UgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBjb25zdCBtYXA6IFJlY29yZDxTdGFnZSwgT3JkZXJSZXNwb25zZVtdPiA9IHsgbm92bzogW10sIGNvemluaGE6IFtdLCBhZ3VhcmRhbmRvOiBbXSwgcm90YTogW10sIGVudHJlZ3VlOiBbXSwgY2FuY2VsYWRvOiBbXSB9O1xyXG4gICAgICAgIGZvciAoY29uc3Qgb3JkZXIgb2YgZmlsdGVyZWRPcmRlcnMpIG1hcFtkZXJpdmVTdGFnZShvcmRlciwgb25Sb3V0ZSldLnB1c2gob3JkZXIpO1xyXG4gICAgICAgIGZvciAoY29uc3QgbGlzdCBvZiBPYmplY3QudmFsdWVzKG1hcCkpIGxpc3Quc29ydCgoYSwgYikgPT4gYS5pZCAtIGIuaWQpO1xyXG4gICAgICAgIHJldHVybiBtYXA7XHJcbiAgICB9LCBbZmlsdGVyZWRPcmRlcnMsIG9uUm91dGVdKTtcclxuXHJcbiAgICBjb25zdCBkYXNoYm9hcmRNZXRyaWNzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYWN0aXZlT3JkZXJzID0gYm9hcmRPcmRlcnMuZmlsdGVyKG8gPT4gby5vcmRlclN0YXR1c0lkICE9PSBPcmRlclN0YXR1cy5DYW5jZWxhZG8pO1xyXG4gICAgICAgIGNvbnN0IHRvdGFsID0gYWN0aXZlT3JkZXJzLmxlbmd0aDtcclxuICAgICAgICBjb25zdCBlbnRyZWd1ZXMgPSBvcmRlcnNCeVN0YWdlLmVudHJlZ3VlLmxlbmd0aDtcclxuICAgICAgICBjb25zdCBhbmRhbWVudG8gPSB0b3RhbCAtIGVudHJlZ3VlcztcclxuXHJcbiAgICAgICAgbGV0IHN1bU1pbnV0ZXMgPSAwO1xyXG4gICAgICAgIGFjdGl2ZU9yZGVycy5mb3JFYWNoKG8gPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBvcGVuZWQgPSBuZXcgRGF0ZShvLm9wZW5lZEF0KS5nZXRUaW1lKCk7XHJcbiAgICAgICAgICAgIHN1bU1pbnV0ZXMgKz0gTWF0aC5tYXgoMCwgKERhdGUubm93KCkgLSBvcGVuZWQpIC8gNjAwMDApO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnN0IGF2Z1RpbWUgPSB0b3RhbCA+IDAgPyBNYXRoLnJvdW5kKHN1bU1pbnV0ZXMgLyB0b3RhbCkgOiAwO1xyXG5cclxuICAgICAgICByZXR1cm4geyB0b3RhbCwgYXZnVGltZSwgZW50cmVndWVzLCBhbmRhbWVudG8sIGFnZW5kYWRvczogMCB9O1xyXG4gICAgfSwgW2JvYXJkT3JkZXJzLCBvcmRlcnNCeVN0YWdlXSk7XHJcblxyXG4gICAgY29uc3QgcmVmcmVzaCA9ICgpID0+IHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wib3JkZXJzXCJdIH0pO1xyXG4gICAgY29uc3Qgb25FcnIgPSAoZmFsbGJhY2s6IHN0cmluZykgPT4gKGVycm9yOiB1bmtub3duKSA9PiB0b2FzdC5lcnJvcihlcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyb3IubWVzc2FnZSA6IGZhbGxiYWNrKTtcclxuXHJcbiAgICBjb25zdCBzZW5kVG9LaXRjaGVuID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46IGFzeW5jIChvcmRlcjogT3JkZXJSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBwZW5kaW5nID0gb3JkZXIuaXRlbXMuZmlsdGVyKChpKSA9PiBpLm9yZGVySXRlbVN0YXR1c0lkID09PSBPcmRlckl0ZW1TdGF0dXMuTGFuY2Fkbyk7XHJcbiAgICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKHBlbmRpbmcubWFwKChpKSA9PiB1cGRhdGVJdGVtU3RhdHVzKG9yZGVyLmlkLCBpLmlkLCBPcmRlckl0ZW1TdGF0dXMuRW52aWFkb0NvemluaGEsIGVtcGxveWVlSWQpKSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvblN1Y2Nlc3M6IChfZGF0YSwgb3JkZXIpID0+IHsgdG9hc3Quc3VjY2VzcyhgUGVkaWRvICMke29yZGVyLmlkfSBwLyBjb3ppbmhhLmApOyBzZXRQZW5kaW5nT3JkZXJJZChudWxsKTsgcmVmcmVzaCgpOyB9LFxyXG4gICAgICAgIG9uRXJyb3I6IChlKSA9PiB7IG9uRXJyKFwiRmFsaGEgYW8gZW52aWFyLlwiKShlKTsgc2V0UGVuZGluZ09yZGVySWQobnVsbCk7IH0sXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBtYXJrUmVhZHkgPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogYXN5bmMgKG9yZGVyOiBPcmRlclJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHBlbmRpbmcgPSBvcmRlci5pdGVtcy5maWx0ZXIoKGkpID0+IGkub3JkZXJJdGVtU3RhdHVzSWQgIT09IE9yZGVySXRlbVN0YXR1cy5DYW5jZWxhZG8gJiYgIVJFQURZX0lURU1fU1RBVFVTRVMuaGFzKGkub3JkZXJJdGVtU3RhdHVzSWQpKTtcclxuICAgICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwocGVuZGluZy5tYXAoKGkpID0+IHVwZGF0ZUl0ZW1TdGF0dXMob3JkZXIuaWQsIGkuaWQsIE9yZGVySXRlbVN0YXR1cy5Qcm9udG8sIGVtcGxveWVlSWQpKSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvblN1Y2Nlc3M6IChfZGF0YSwgb3JkZXIpID0+IHsgdG9hc3Quc3VjY2VzcyhgUGVkaWRvICMke29yZGVyLmlkfSBwcm9udG8uYCk7IHNldFBlbmRpbmdPcmRlcklkKG51bGwpOyByZWZyZXNoKCk7IH0sXHJcbiAgICAgICAgb25FcnJvcjogKGUpID0+IHsgb25FcnIoXCJGYWxoYSBhbyBtYXJjYXIuXCIpKGUpOyBzZXRQZW5kaW5nT3JkZXJJZChudWxsKTsgfSxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVNlbmRUb0tpdGNoZW4gPSAobzogT3JkZXJSZXNwb25zZSkgPT4geyBzZXRQZW5kaW5nT3JkZXJJZChvLmlkKTsgc2VuZFRvS2l0Y2hlbi5tdXRhdGUobyk7IH07XHJcbiAgICBjb25zdCBoYW5kbGVNYXJrUmVhZHkgPSAobzogT3JkZXJSZXNwb25zZSkgPT4geyBzZXRQZW5kaW5nT3JkZXJJZChvLmlkKTsgbWFya1JlYWR5Lm11dGF0ZShvKTsgfTtcclxuICAgIGNvbnN0IGhhbmRsZU1hcmtPblJvdXRlID0gKG86IE9yZGVyUmVzcG9uc2UpID0+IHsgc2V0T25Sb3V0ZSgocHJldikgPT4geyBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2KS5hZGQoby5pZCk7IHBlcnNpc3RPblJvdXRlKG5leHQpOyByZXR1cm4gbmV4dDsgfSk7IH07XHJcblxyXG4gICAgY29uc3QgY29sdW1ucyA9IHZpZXdNb2RlID09PSBcImNvbXBsZXRvXCIgPyBGVUxMX0NPTFVNTlMgOiBTSU1QTEVfQ09MVU1OUztcclxuICAgIGNvbnN0IGRlbnNlID0gdmlld01vZGUgPT09IFwic2ltcGxlc1wiO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBzdHlsZT17e1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6IGB1cmwoJHtzY3JlZW5CZ0ltZ30pYCxcclxuICAgICAgICAgICAgYmFja2dyb3VuZFNpemU6IFwiY292ZXJcIixcclxuICAgICAgICAgICAgYmFja2dyb3VuZFBvc2l0aW9uOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI0ZERjhGNFwiLFxyXG4gICAgICAgICAgICBtaW5IZWlnaHQ6IFwiMTAwdmhcIixcclxuICAgICAgICAgICAgcGFkZGluZzogXCIzMnB4IDQwcHhcIixcclxuICAgICAgICAgICAgZm9udEZhbWlseTogXCJzeXN0ZW0tdWksIC1hcHBsZS1zeXN0ZW0sIHNhbnMtc2VyaWZcIixcclxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCJcclxuICAgICAgICB9fT5cclxuXHJcbiAgICAgICAgICAgIHsvKiBIRUFERVIgVE9QICovfVxyXG4gICAgICAgICAgICA8aGVhZGVyIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIG1hcmdpbkJvdHRvbTogMzIgfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDE2IH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXttb3RvcmN5Y2xlSW1nfSBhbHQ9XCJNb3RvIGRlIERlbGl2ZXJ5XCIgc3R5bGU9e3sgd2lkdGg6IFwiY2xhbXAoNDRweCwgNXZ3LCA3MnB4KVwiLCBoZWlnaHQ6IFwiYXV0b1wiLCBvYmplY3RGaXQ6IFwiY29udGFpblwiLCBtaXhCbGVuZE1vZGU6IFwibXVsdGlwbHlcIiB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBzdHlsZT17eyBmb250U2l6ZTogXCIyLjRyZW1cIiwgZm9udFdlaWdodDogOTAwLCBjb2xvcjogXCIjMUExQTFBXCIsIG1hcmdpbjogMCwgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIiwgbGV0dGVyU3BhY2luZzogXCItMXB4XCIgfX0+RGVsaXZlcnk8L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCIjNzc3XCIsIGZvbnRTaXplOiBcIjAuOTVyZW1cIiB9fT5Nb3ZpbWVudGUgY2FkYSBwZWRpZG8gcGVsYXMgZXRhcGFzIGF0w6kgYSBlbnRyZWdhPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAyNCwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBiYWNrZ3JvdW5kOiBcIiNmZmZcIiwgYm9yZGVyUmFkaXVzOiA4LCBwYWRkaW5nOiA0LCBib3JkZXI6IFwiMXB4IHNvbGlkICNFQUVBRUFcIiwgYm94U2hhZG93OiBcIjAgMnB4IDRweCByZ2JhKDAsMCwwLDAuMDIpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdNb2RlKFwic2ltcGxlc1wiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiOHB4IDE2cHhcIiwgYm9yZGVyUmFkaXVzOiA2LCBib3JkZXI6IFwibm9uZVwiLCBmb250V2VpZ2h0OiA2MDAsIGN1cnNvcjogXCJwb2ludGVyXCIsIGJhY2tncm91bmQ6IHZpZXdNb2RlID09PSBcInNpbXBsZXNcIiA/IFwiI2ZmZlwiIDogXCJ0cmFuc3BhcmVudFwiLCBjb2xvcjogdmlld01vZGUgPT09IFwic2ltcGxlc1wiID8gXCIjMUExQTFBXCIgOiBcIiM4ODhcIiwgYm94U2hhZG93OiB2aWV3TW9kZSA9PT0gXCJzaW1wbGVzXCIgPyBcIjAgMnB4IDhweCByZ2JhKDAsMCwwLDAuMSlcIiA6IFwibm9uZVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5TaW1wbGVzPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdNb2RlKFwiY29tcGxldG9cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjhweCAxNnB4XCIsIGJvcmRlclJhZGl1czogNiwgYm9yZGVyOiBcIm5vbmVcIiwgZm9udFdlaWdodDogNjAwLCBjdXJzb3I6IFwicG9pbnRlclwiLCBiYWNrZ3JvdW5kOiB2aWV3TW9kZSA9PT0gXCJjb21wbGV0b1wiID8gXCIjRkY2QjAwXCIgOiBcInRyYW5zcGFyZW50XCIsIGNvbG9yOiB2aWV3TW9kZSA9PT0gXCJjb21wbGV0b1wiID8gXCIjZmZmXCIgOiBcIiM4ODhcIiwgYm94U2hhZG93OiB2aWV3TW9kZSA9PT0gXCJjb21wbGV0b1wiID8gXCIwIDJweCA4cHggcmdiYSgyNTUsMTA3LDAsMC40KVwiIDogXCJub25lXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPkNvbXBsZXRvPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldE9wZW5pbmdOZXcodHJ1ZSl9IHN0eWxlPXt7IGJhY2tncm91bmQ6IFwibGluZWFyLWdyYWRpZW50KDkwZGVnLCAjRkY3QjAwIDAlLCAjRkY1NTAwIDEwMCUpXCIsIGNvbG9yOiBcIiNmZmZcIiwgYm9yZGVyOiBcIm5vbmVcIiwgcGFkZGluZzogXCIxMnB4IDI0cHhcIiwgYm9yZGVyUmFkaXVzOiA4LCBmb250V2VpZ2h0OiA3MDAsIGZvbnRTaXplOiBcIjFyZW1cIiwgY3Vyc29yOiBcInBvaW50ZXJcIiwgYm94U2hhZG93OiBcIjAgNHB4IDEycHggcmdiYSgyNTUsIDg1LCAwLCAwLjMpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICsgTm92byBwZWRpZG9cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBGSUxUUk9TIEUgQlVTQ0EgKi99XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTYsIG1hcmdpbkJvdHRvbTogMjQsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgeyhbXCJ0b2Rvc1wiLCBcImRlbGl2ZXJ5XCIsIFwicmV0aXJhZGFcIl0gYXMgQ2hhbm5lbEZpbHRlcltdKS5tYXAoKGMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2N9IG9uQ2xpY2s9eygpID0+IHNldENoYW5uZWxGaWx0ZXIoYyl9IHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjEwcHggMjBweFwiLCBib3JkZXJSYWRpdXM6IDgsIGJvcmRlcjogYyA9PT0gY2hhbm5lbEZpbHRlciA/IFwibm9uZVwiIDogXCIxcHggc29saWQgI0VBRUFFQVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogYyA9PT0gY2hhbm5lbEZpbHRlciA/IFwiI0ZGNkIwMFwiIDogXCIjZmZmXCIsIGNvbG9yOiBjID09PSBjaGFubmVsRmlsdGVyID8gXCIjZmZmXCIgOiBcIiM1NTVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDcwMCwgY3Vyc29yOiBcInBvaW50ZXJcIiwgYm94U2hhZG93OiBjID09PSBjaGFubmVsRmlsdGVyID8gXCIwIDRweCAxMnB4IHJnYmEoMjU1LDEwNywwLDAuMilcIiA6IFwiMCAycHggNHB4IHJnYmEoMCwwLDAsMC4wMilcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtDSEFOTkVMX0ZJTFRFUl9MQUJFTFNbY119XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLCBmbGV4OiAxLCBtYXhXaWR0aDogNDAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJ1c2NhciBwZWRpZG8sIGNsaWVudGUgb3UgZW5kZXJlw6dvLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2goZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvKiBBY2hhZG86IGVzdGUgYm9hcmQgdXNhIGNvcmVzIGZpeGFzIChsaWdodCkgZW0gdmV6IGRhcyB2YXJpw6F2ZWlzIGRlIHRlbWEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcyBvIGlucHV0IG7Do28gdGluaGEgXCJjb2xvclwiIOKAlCBoZXJkYXZhIG8gdGV4dG8gY2xhcm8gZG8gdGVtYSBlc2N1cm9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgKC0taW5rKSwgZmljYW5kbyBpbGVnw612ZWwgZW0gY2ltYSBkbyBmdW5kbyBicmFuY28gI2ZmZiBkZXN0ZSBjYW1wby4gKi9cclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiLCBwYWRkaW5nOiBcIjEycHggMTZweCAxMnB4IDQwcHhcIiwgYm9yZGVyUmFkaXVzOiA4LCBib3JkZXI6IFwiMXB4IHNvbGlkICNFQUVBRUFcIiwgYmFja2dyb3VuZDogXCIjZmZmXCIsIGNvbG9yOiBcIiMxQTFBMUFcIiwgZm9udFNpemU6IFwiMC45NXJlbVwiLCBib3hTaGFkb3c6IFwiMCAycHggNHB4IHJnYmEoMCwwLDAsMC4wMilcIiwgb3V0bGluZTogXCJub25lXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgc3R5bGU9e3sgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgbGVmdDogMTQsIHRvcDogMTIsIHdpZHRoOiAxOCwgY29sb3I6IFwiIzk5OVwiIH19IHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIj48Y2lyY2xlIGN4PVwiMTFcIiBjeT1cIjExXCIgcj1cIjhcIj48L2NpcmNsZT48bGluZSB4MT1cIjIxXCIgeTE9XCIyMVwiIHgyPVwiMTYuNjVcIiB5Mj1cIjE2LjY1XCI+PC9saW5lPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5MZWZ0OiBcImF1dG9cIiwgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGdhcDogMTIsIGJhY2tncm91bmQ6IFwiI2ZmZlwiLCBwYWRkaW5nOiBcIjhweCAxNnB4XCIsIGJvcmRlclJhZGl1czogOCwgYm9yZGVyOiBcIjFweCBzb2xpZCAjRUFFQUVBXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwiIzY2NlwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDYgfX0+PHN2ZyBzdHlsZT17eyB3aWR0aDogMTQgfX0gdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCI+PHBhdGggZD1cIk0yMS41IDJ2NmgtNk0yMS4zNCAxNS41N2ExMCAxMCAwIDEgMS0uNTktOS4yMWwtNS40NS01LjQ1XCIgLz48L3N2Zz4gQXR1YWxpemFyIGVtIDE1czwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyB3aWR0aDogMSwgaGVpZ2h0OiAxMiwgYmFja2dyb3VuZDogXCIjREREXCIgfX0+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDYgfX0+QXR1YWxpemFkbyBhZ29yYSBow6EgMTVzIDxzcGFuIHN0eWxlPXt7IHdpZHRoOiA4LCBoZWlnaHQ6IDgsIGJhY2tncm91bmQ6IFwiIzRDQUY1MFwiLCBib3JkZXJSYWRpdXM6IFwiNTAlXCIgfX0+PC9zcGFuPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBLQU5CQU4gQk9BUkQgKi99XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTYsIGZsZXg6IDEsIG92ZXJmbG93WDogXCJhdXRvXCIsIHBhZGRpbmdCb3R0b206IDI0LCBtaW5IZWlnaHQ6IDQwMCB9fT5cclxuICAgICAgICAgICAgICAgIHtjb2x1bW5zLm1hcCgoY29sKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXRlbXMgPSBjb2wuaWQgPT09IFwiYWdlbmRhbWVudG9cIiA/IFtdIDogb3JkZXJzQnlTdGFnZVtjb2wuaWQgYXMgU3RhZ2VdIHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjb2wuaWR9IHN0eWxlPXt7IG1pbldpZHRoOiAyNjAsIHdpZHRoOiBcIjE2LjYlXCIsIGJhY2tncm91bmQ6IFwiI2ZmZlwiLCBib3JkZXJSYWRpdXM6IDE2LCBwYWRkaW5nOiBcIjE2cHhcIiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGJvcmRlcjogXCIxcHggc29saWQgI0VGRUZFRlwiLCBib3hTaGFkb3c6IFwiMCA0cHggMTJweCByZ2JhKDAsMCwwLDAuMDIpXCIgfX0+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEhlYWRlciBkYSBDb2x1bmEgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEyLCBtYXJnaW5Cb3R0b206IDIwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogY29sLnRoZW1lQ29sb3IsIGNvbG9yOiBcIiNmZmZcIiwgd2lkdGg6IDQyLCBoZWlnaHQ6IDQyLCBib3JkZXJSYWRpdXM6IDEwLCBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsIGJveFNoYWRvdzogYDAgNHB4IDEwcHggJHtjb2wudGhlbWVDb2xvcn00MGAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb2wuaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJmbGV4LXN0YXJ0XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA4MDAsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwiIzFBMUExQVwiLCBsaW5lSGVpZ2h0OiAxLjIgfX0+e2NvbC5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBiYWNrZ3JvdW5kOiBgJHtjb2wudGhlbWVDb2xvcn0xNWAsIGNvbG9yOiBjb2wudGhlbWVDb2xvciwgZm9udFdlaWdodDogODAwLCBwYWRkaW5nOiBcIjJweCA4cHhcIiwgYm9yZGVyUmFkaXVzOiAxMiwgZm9udFNpemU6IFwiMC44cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW1zLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuNzVyZW1cIiwgY29sb3I6IFwiIzg4OFwiLCBkaXNwbGF5OiBcImJsb2NrXCIsIG1hcmdpblRvcDogMiB9fT57Y29sLmhpbnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENvcnBvIGRhIENvbHVuYSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogMTIsIGZsZXg6IDEsIG92ZXJmbG93WTogXCJhdXRvXCIsIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbC5wbGFjZWhvbGRlciA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsIGhlaWdodDogXCIxMDAlXCIsIHBhZGRpbmc6IDIwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbC5lbXB0eUlsbHVzdHJhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiLCBjb2xvcjogXCIjOTk5XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgbWFyZ2luVG9wOiAyNCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZ2VuZGFtZW50byBkZSBwZWRpZG9zIGV4aXN0ZSBubyBTeW5jQmFyIERlbGl2ZXJ5LCByZXNlcnZhZG8gcGFyYSBxdWFuZG8gZXNzYSBmdW5jaW9uYWxpZGFkZSBmb3IgbGliZXJhZGEuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwiI0Y1RjVGNVwiLCBwYWRkaW5nOiBcIjZweCAxMnB4XCIsIGJvcmRlclJhZGl1czogMTIsIGZvbnRXZWlnaHQ6IDYwMCwgY29sb3I6IFwiIzg4OFwiLCBtYXJnaW5Ub3A6IDE2LCBmb250U2l6ZTogXCIwLjhyZW1cIiB9fT5FbSBicmV2ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IGl0ZW1zLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsIGhlaWdodDogXCIxMDAlXCIsIG9wYWNpdHk6IDAuOCwgbWFyZ2luVG9wOiA0MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAyNCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29sLmVtcHR5SWxsdXN0cmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGNvbG9yOiBcIiNCQkJcIiwgZm9udFNpemU6IFwiMXJlbVwiLCBmb250V2VpZ2h0OiA2MDAgfX0+U2VtIHBlZGlkb3M8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXMubWFwKChvcmRlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9yZGVyQ2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17b3JkZXIuaWR9IG9yZGVyPXtvcmRlcn0gc3RhZ2U9e2NvbC5pZCBhcyBTdGFnZX0gZGVuc2U9e2RlbnNlfSBidXN5PXtwZW5kaW5nT3JkZXJJZCA9PT0gb3JkZXIuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25PcGVuPXsoKSA9PiBzZXRTZWxlY3RlZE9yZGVySWQob3JkZXIuaWQpfSBvblNlbmRUb0tpdGNoZW49eygpID0+IGhhbmRsZVNlbmRUb0tpdGNoZW4ob3JkZXIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uTWFya1JlYWR5PXsoKSA9PiBoYW5kbGVNYXJrUmVhZHkob3JkZXIpfSBvbk1hcmtPblJvdXRlPXsoKSA9PiBoYW5kbGVNYXJrT25Sb3V0ZShvcmRlcil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBEQVNIQk9BUkQgSU5GRVJJT1IgKi99XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogXCIjMTExXCIsIGJvcmRlclJhZGl1czogMTYsIHBhZGRpbmc6IFwiMjRweCA0MHB4XCIsIGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIG1hcmdpblRvcDogXCJhdXRvXCIsIGJveFNoYWRvdzogXCIwIDEwcHggNDBweCByZ2JhKDI1NSwgMTA3LCAwLCAwLjE1KVwiLCBib3JkZXJCb3R0b206IFwiNHB4IHNvbGlkICNGRjZCMDBcIiB9fT5cclxuICAgICAgICAgICAgICAgIDxEYXNoYm9hcmRNZXRyaWMgaWNvbj17PHN2ZyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHlsZT17eyB3aWR0aDogMjQgfX0+PHBhdGggZD1cIk0yMCAyMXYtMmE0IDQgMCAwIDAtNC00SDhhNCA0IDAgMCAwLTQgNHYyXCI+PC9wYXRoPjxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiN1wiIHI9XCI0XCI+PC9jaXJjbGU+PC9zdmc+fSBsYWJlbD1cIlRvdGFsIGRlIHBlZGlkb3NcIiB2YWx1ZT17ZGFzaGJvYXJkTWV0cmljcy50b3RhbH0gc3ViPVwiaG9qZVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiAxLCBoZWlnaHQ6IDQwLCBiYWNrZ3JvdW5kOiBcIiMzMzNcIiB9fT48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxEYXNoYm9hcmRNZXRyaWMgaWNvbj17PHN2ZyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHlsZT17eyB3aWR0aDogMjQgfX0+PGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIxMFwiPjwvY2lyY2xlPjxwb2x5bGluZSBwb2ludHM9XCIxMiA2IDEyIDEyIDE2IDE0XCI+PC9wb2x5bGluZT48L3N2Zz59IGxhYmVsPVwiVGVtcG8gbcOpZGlvXCIgdmFsdWU9e2Rhc2hib2FyZE1ldHJpY3MuYXZnVGltZX0gc3ViPVwibWluXCIgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IDEsIGhlaWdodDogNDAsIGJhY2tncm91bmQ6IFwiIzMzM1wiIH19PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPERhc2hib2FyZE1ldHJpYyBpY29uPXs8c3ZnIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0eWxlPXt7IHdpZHRoOiAyNCB9fT48cGF0aCBkPVwiTTIyIDExLjA4VjEyYTEwIDEwIDAgMSAxLTUuOTMtOS4xNFwiPjwvcGF0aD48cG9seWxpbmUgcG9pbnRzPVwiMjIgNCAxMiAxNC4wMSA5IDExLjAxXCI+PC9wb2x5bGluZT48L3N2Zz59IGxhYmVsPVwiRW50cmVndWVzXCIgdmFsdWU9e2Rhc2hib2FyZE1ldHJpY3MuZW50cmVndWVzfSBzdWI9XCJob2plXCIgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IDEsIGhlaWdodDogNDAsIGJhY2tncm91bmQ6IFwiIzMzM1wiIH19PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPERhc2hib2FyZE1ldHJpYyBpY29uPXs8c3ZnIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0eWxlPXt7IHdpZHRoOiAyNCB9fT48cG9seWxpbmUgcG9pbnRzPVwiMjMgNCAyMyAxMCAxNyAxMFwiPjwvcG9seWxpbmU+PHBvbHlsaW5lIHBvaW50cz1cIjEgMjAgMSAxNCA3IDE0XCI+PC9wb2x5bGluZT48cGF0aCBkPVwiTTMuNTEgOWE5IDkgMCAwIDEgMTQuODUtMy4zNkwyMyAxME0xIDE0bDQuNjQgNC4zNkE5IDkgMCAwIDAgMjAuNDkgMTVcIj48L3BhdGg+PC9zdmc+fSBsYWJlbD1cIkVtIGFuZGFtZW50b1wiIHZhbHVlPXtkYXNoYm9hcmRNZXRyaWNzLmFuZGFtZW50b30gc3ViPVwiYWdvcmFcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB3aWR0aDogMSwgaGVpZ2h0OiA0MCwgYmFja2dyb3VuZDogXCIjMzMzXCIgfX0+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8RGFzaGJvYXJkTWV0cmljIGljb249ezxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3R5bGU9e3sgd2lkdGg6IDI0IH19PjxyZWN0IHg9XCIzXCIgeT1cIjRcIiB3aWR0aD1cIjE4XCIgaGVpZ2h0PVwiMThcIiByeD1cIjJcIiByeT1cIjJcIj48L3JlY3Q+PGxpbmUgeDE9XCIxNlwiIHkxPVwiMlwiIHgyPVwiMTZcIiB5Mj1cIjZcIj48L2xpbmU+PGxpbmUgeDE9XCI4XCIgeTE9XCIyXCIgeDI9XCI4XCIgeTI9XCI2XCI+PC9saW5lPjxsaW5lIHgxPVwiM1wiIHkxPVwiMTBcIiB4Mj1cIjIxXCIgeTI9XCIxMFwiPjwvbGluZT48L3N2Zz59IGxhYmVsPVwiQWdlbmRhZG9zXCIgdmFsdWU9e2Rhc2hib2FyZE1ldHJpY3MuYWdlbmRhZG9zfSBzdWI9XCJwcsOzeGltb3MgZGlhc1wiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge3NlbGVjdGVkT3JkZXJJZCAhPT0gbnVsbCAmJiA8T3JkZXJEcmF3ZXIgb3JkZXJJZD17c2VsZWN0ZWRPcmRlcklkfSBvbkNsb3NlPXsoKSA9PiB7IHNldFNlbGVjdGVkT3JkZXJJZChudWxsKTsgcmVmcmVzaCgpOyB9fSAvPn1cclxuICAgICAgICAgICAge29wZW5pbmdOZXcgJiYgPE9wZW5EZWxpdmVyeU9yZGVyRGlhbG9nIG9uQ2xvc2U9eygpID0+IHNldE9wZW5pbmdOZXcoZmFsc2UpfSBvbk9wZW5lZD17KG9yZGVySWQpID0+IHsgc2V0T3BlbmluZ05ldyhmYWxzZSk7IHJlZnJlc2goKTsgc2V0U2VsZWN0ZWRPcmRlcklkKG9yZGVySWQpOyB9fSAvPn1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIERhc2hib2FyZE1ldHJpYyh7IGljb24sIGxhYmVsLCB2YWx1ZSwgc3ViIH06IHsgaWNvbjogUmVhY3QuUmVhY3ROb2RlLCBsYWJlbDogc3RyaW5nLCB2YWx1ZTogbnVtYmVyLCBzdWI6IHN0cmluZyB9KSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGdhcDogMTYgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgY29sb3I6IFwiI0ZGNkIwMFwiLCBib3JkZXI6IFwiMS41cHggc29saWQgI0ZGNkIwMFwiLCBib3JkZXJSYWRpdXM6IDEyLCB3aWR0aDogNDgsIGhlaWdodDogNDgsIGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIiwgYmFja2dyb3VuZDogXCJyZ2JhKDI1NSwgMTA3LCAwLCAwLjEpXCIgfX0+e2ljb259PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGNvbG9yOiBcIiM4ODhcIiwgZm9udFdlaWdodDogNTAwIH19PntsYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImJhc2VsaW5lXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjhyZW1cIiwgZm9udFdlaWdodDogODAwLCBjb2xvcjogXCIjZmZmXCIsIGxpbmVIZWlnaHQ6IDEuMSB9fT57dmFsdWUgPiAwID8gdmFsdWUgOiBcIi0tXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCIjODg4XCIgfX0+e3N1Yn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL29yZGVycy9EZWxpdmVyeUJvYXJkUGFnZS50c3gifQ==