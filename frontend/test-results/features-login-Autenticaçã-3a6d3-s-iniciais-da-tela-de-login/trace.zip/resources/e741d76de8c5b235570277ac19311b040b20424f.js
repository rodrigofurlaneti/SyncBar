import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/finance/FinancePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { useDialog } from "/src/ui/Dialog.tsx";
import {
  createOperatingCost,
  deactivateOperatingCost,
  getBillingSummary,
  setRevenueTarget
} from "/src/features/finance/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { CostType, costTypeLabel, formatBRL } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
const parseNum = (raw) => {
  if (raw.trim() === "") return null;
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) && value > 0 ? value : null;
};
function currentMonthValue() {
  const now = /* @__PURE__ */ new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}
function Card({ label, value, tone }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "ticket",
      style: { padding: "14px 18px", display: "grid", gap: 4, minWidth: 0 },
      children: [
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            style: {
              fontFamily: "var(--font-cond)",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              fontSize: "0.78rem",
              color: "var(--ink-faint)"
            },
            children: label
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
            lineNumber: 52,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "mono-num display", style: { fontSize: "1.6rem", color: tone ?? "var(--ink)" }, children: value }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 63,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
      lineNumber: 48,
      columnNumber: 5
    },
    this
  );
}
_c = Card;
export function FinancePage() {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const { branchId } = useAuthStore();
  const [monthValue, setMonthValue] = useState(currentMonthValue());
  const [description, setDescription] = useState("");
  const [costTypeId, setCostTypeId] = useState(CostType.Fixo);
  const [amount, setAmount] = useState("");
  const [targetInput, setTargetInput] = useState("");
  const [error, setError] = useState(null);
  const [yearStr, monthStr] = monthValue.split("-");
  const year = Number(yearStr);
  const month = Number(monthStr);
  const summaryQuery = useQuery({
    queryKey: ["finance", branchId, year, month],
    queryFn: () => getBillingSummary(branchId, year, month),
    enabled: Number.isFinite(year) && Number.isFinite(month)
  });
  const summary = summaryQuery.data;
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["finance"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const costMutation = useMutation({
    mutationFn: () => createOperatingCost({
      branchId,
      costTypeId,
      description: description.trim(),
      amount: parseNum(amount) ?? 0,
      referenceYear: year,
      referenceMonth: month
    }),
    onSuccess: () => {
      setError(null);
      setDescription("");
      setAmount("");
      refresh();
    },
    onError: onApiError
  });
  const removeCostMutation = useMutation({
    mutationFn: (id) => deactivateOperatingCost(id),
    onSuccess: refresh,
    onError: onApiError
  });
  const targetMutation = useMutation({
    mutationFn: () => setRevenueTarget({
      branchId,
      referenceYear: year,
      referenceMonth: month,
      targetAmount: parseNum(targetInput) ?? 0
    }),
    onSuccess: () => {
      setError(null);
      setTargetInput("");
      refresh();
    },
    onError: onApiError
  });
  const maxDaily = useMemo(
    () => Math.max(1, ...(summary?.dailyRevenue ?? []).map((d) => d.amount)),
    [summary?.dailyRevenue]
  );
  const attainment = summary?.targetAttainmentRate ?? null;
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "center", gap: 14, marginBottom: 16, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Faturamento" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
        lineNumber: 147,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
        lineNumber: 148,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "month",
          value: monthValue,
          onChange: (e) => setMonthValue(e.target.value),
          style: { width: 190 }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 149,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
      lineNumber: 146,
      columnNumber: 7
    }, this),
    summaryQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: summaryQuery.error, what: "o resumo do mês" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
      lineNumber: 157,
      columnNumber: 32
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
      lineNumber: 158,
      columnNumber: 17
    }, this),
    summaryQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 5, rowHeight: 70 }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
      lineNumber: 160,
      columnNumber: 34
    }, this),
    summary && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "rise rise-1",
          style: { display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", marginBottom: 16 },
          children: [
            /* @__PURE__ */ jsxDEV(Card, { label: `Receita (${summary.salesCount} vendas)`, value: formatBRL(summary.revenue), tone: "var(--amber)" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 168,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Card, { label: "CMV (produtos vendidos)", value: formatBRL(summary.costOfGoodsSold) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 169,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Card, { label: "Custos fixos", value: formatBRL(summary.fixedCosts) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 170,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Card, { label: "Custos variáveis", value: formatBRL(summary.variableCosts) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 171,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              Card,
              {
                label: "Resultado",
                value: formatBRL(summary.netResult),
                tone: summary.netResult >= 0 ? "var(--ok)" : "var(--danger)"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
                lineNumber: 172,
                columnNumber: 13
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 164,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ticket rise rise-2", style: { padding: 18, display: "grid", gap: 10, marginBottom: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Meta do mês" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
            lineNumber: 181,
            columnNumber: 15
          }, this),
          summary.targetAmount !== null ? /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--ink-dim)" }, children: [
            formatBRL(summary.revenue),
            " de ",
            formatBRL(summary.targetAmount),
            attainment !== null && /* @__PURE__ */ jsxDEV("strong", { style: { color: attainment >= 1 ? "var(--ok)" : "var(--amber)", marginLeft: 8 }, children: [
              (attainment * 100).toFixed(1),
              "%"
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 186,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
            lineNumber: 183,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "nenhuma meta definida" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
            lineNumber: 192,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 180,
          columnNumber: 13
        }, this),
        summary.targetAmount !== null && /* @__PURE__ */ jsxDEV("div", { style: { background: "var(--bg-press)", borderRadius: 999, height: 14, overflow: "hidden" }, children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            style: {
              width: `${Math.min(100, (attainment ?? 0) * 100)}%`,
              height: "100%",
              background: (attainment ?? 0) >= 1 ? "var(--ok)" : "var(--amber)",
              borderRadius: 999,
              transition: "width 300ms ease"
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
            lineNumber: 198,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 197,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, maxWidth: 420 }, children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              placeholder: summary.targetAmount !== null ? "Nova meta (R$)" : "Definir meta (R$)",
              inputMode: "decimal",
              value: targetInput,
              onChange: (e) => setTargetInput(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 211,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost",
              disabled: parseNum(targetInput) === null || targetMutation.isPending,
              onClick: () => targetMutation.mutate(),
              children: "Salvar meta"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 217,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 210,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
        lineNumber: 179,
        columnNumber: 11
      }, this),
      summary.dailyRevenue.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket rise rise-2", style: { padding: 18, marginBottom: 16 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Receita por dia" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 230,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "flex-end", gap: 4, height: 120, marginTop: 12 }, children: summary.dailyRevenue.map(
          (d) => /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, display: "grid", gap: 4, justifyItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                title: `Dia ${d.day}: ${formatBRL(d.amount)}`,
                style: {
                  width: "100%",
                  maxWidth: 34,
                  height: `${Math.max(4, d.amount / maxDaily * 100)}px`,
                  background: "var(--amber)",
                  borderRadius: "4px 4px 0 0",
                  opacity: 0.9
                }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
                lineNumber: 234,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { fontSize: "0.7rem", color: "var(--ink-faint)" }, children: d.day }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 245,
              columnNumber: 21
            }, this)
          ] }, d.day, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
            lineNumber: 233,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 231,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
        lineNumber: 229,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ticket rise rise-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Custos do mês" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
            lineNumber: 256,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
            "total ",
            formatBRL(summary.fixedCosts + summary.variableCosts)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
            lineNumber: 257,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 255,
          columnNumber: 13
        }, this),
        summary.costs.map(
          (cost) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
              /* @__PURE__ */ jsxDEV("span", { children: cost.description }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
                lineNumber: 265,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: costTypeLabel[cost.costTypeId] }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
                lineNumber: 266,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 264,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, alignItems: "center" }, children: [
              /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(cost.amount) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
                lineNumber: 271,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "btn-danger",
                  "aria-label": `Remover custo ${cost.description}`,
                  title: "Remover custo",
                  style: { minHeight: 44, padding: "0 10px", fontSize: "0.85rem" },
                  disabled: removeCostMutation.isPending,
                  onClick: async () => {
                    if (await dialog.confirm({
                      title: "Remover custo",
                      message: `Remover o custo "${cost.description}"?`,
                      confirmLabel: "Remover",
                      danger: true
                    }))
                      removeCostMutation.mutate(cost.id);
                  },
                  children: "✕"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
                  lineNumber: 272,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 270,
              columnNumber: 17
            }, this)
          ] }, cost.id, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
            lineNumber: 263,
            columnNumber: 11
          }, this)
        ),
        summary.costs.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-faint)" }, children: "Nenhum custo lançado neste mês." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 297,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { gap: 8, flexWrap: "wrap" }, children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              placeholder: "Descrição (ex.: Aluguel)",
              style: { flex: 2, minWidth: 160 },
              value: description,
              onChange: (e) => setDescription(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 303,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              style: { flex: 1, minWidth: 110, width: "auto" },
              value: costTypeId,
              onChange: (e) => setCostTypeId(Number(e.target.value)),
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: CostType.Fixo, children: "Fixo" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
                  lineNumber: 314,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: CostType.Variavel, children: "Variável" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
                  lineNumber: 315,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 309,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              placeholder: "Valor (R$)",
              inputMode: "decimal",
              style: { flex: 1, minWidth: 110 },
              value: amount,
              onChange: (e) => setAmount(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 317,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-primary",
              disabled: description.trim() === "" || parseNum(amount) === null || costMutation.isPending,
              onClick: () => costMutation.mutate(),
              children: "+ Lançar custo"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
              lineNumber: 324,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
          lineNumber: 302,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
        lineNumber: 254,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
      lineNumber: 163,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx",
    lineNumber: 145,
    columnNumber: 5
  }, this);
}
_s(FinancePage, "oEKwUfYfpz+FIMGBAu7RK7UiAgc=", false, function() {
  return [useQueryClient, useDialog, useAuthStore, useQuery, useMutation, useMutation, useMutation];
});
_c2 = FinancePage;
var _c, _c2;
$RefreshReg$(_c, "Card");
$RefreshReg$(_c2, "FinancePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/finance/FinancePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NNLFNBK0dFLFVBL0dGOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhDTixTQUFTQSxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLGlCQUFpQjtBQUMxQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFVBQVVDLGVBQWVDLGlCQUFpQjtBQUNuRCxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBRTdCLE1BQU1DLFdBQVdBLENBQUNDLFFBQStCO0FBQy9DLE1BQUlBLElBQUlDLEtBQUssTUFBTSxHQUFJLFFBQU87QUFDOUIsUUFBTUMsUUFBUUMsT0FBT0gsSUFBSUksUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUMxQyxTQUFPRCxPQUFPRSxTQUFTSCxLQUFLLEtBQUtBLFFBQVEsSUFBSUEsUUFBUTtBQUN2RDtBQUVBLFNBQVNJLG9CQUE0QjtBQUNuQyxRQUFNQyxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFNBQU8sR0FBR0QsSUFBSUUsWUFBWSxDQUFDLElBQUlDLE9BQU9ILElBQUlJLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDNUU7QUFFQSxTQUFTQyxLQUFLLEVBQUVDLE9BQU9aLE9BQU9hLEtBQXNELEdBQUc7QUFDckYsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVTtBQUFBLE1BQ1YsT0FBTyxFQUFFQyxTQUFTLGFBQWFDLFNBQVMsUUFBUUMsS0FBSyxHQUFHQyxVQUFVLEVBQUU7QUFBQSxNQUVwRTtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPO0FBQUEsY0FDTEMsWUFBWTtBQUFBLGNBQ1pDLGVBQWU7QUFBQSxjQUNmQyxlQUFlO0FBQUEsY0FDZkMsVUFBVTtBQUFBLGNBQ1ZDLE9BQU87QUFBQSxZQUNUO0FBQUEsWUFFQ1Y7QUFBQUE7QUFBQUEsVUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQixPQUFPLEVBQUVTLFVBQVUsVUFBVUMsT0FBT1QsUUFBUSxhQUFhLEdBQ3pGYixtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBO0FBQUEsSUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBa0JBO0FBRUo7QUFBQ3VCLEtBdEJRWjtBQXdCRixnQkFBU2EsY0FBYztBQUFBQyxLQUFBO0FBQzVCLFFBQU1DLGNBQWMxQyxlQUFlO0FBQ25DLFFBQU0yQyxTQUFTMUMsVUFBVTtBQUN6QixRQUFNLEVBQUUyQyxTQUFTLElBQUl0QyxhQUFhO0FBQ2xDLFFBQU0sQ0FBQ3VDLFlBQVlDLGFBQWEsSUFBSWpELFNBQVN1QixrQkFBa0IsQ0FBQztBQUNoRSxRQUFNLENBQUMyQixhQUFhQyxjQUFjLElBQUluRCxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDb0QsWUFBWUMsYUFBYSxJQUFJckQsU0FBaUJXLFNBQVMyQyxJQUFJO0FBQ2xFLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJeEQsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3lELGFBQWFDLGNBQWMsSUFBSTFELFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUMyRCxPQUFPQyxRQUFRLElBQUk1RCxTQUF3QixJQUFJO0FBRXRELFFBQU0sQ0FBQzZELFNBQVNDLFFBQVEsSUFBSWQsV0FBV2UsTUFBTSxHQUFHO0FBQ2hELFFBQU1DLE9BQU81QyxPQUFPeUMsT0FBTztBQUMzQixRQUFNSSxRQUFRN0MsT0FBTzBDLFFBQVE7QUFFN0IsUUFBTUksZUFBZWhFLFNBQVM7QUFBQSxJQUM1QmlFLFVBQVUsQ0FBQyxXQUFXcEIsVUFBVWlCLE1BQU1DLEtBQUs7QUFBQSxJQUMzQ0csU0FBU0EsTUFBTTdELGtCQUFrQndDLFVBQVVpQixNQUFNQyxLQUFLO0FBQUEsSUFDdERJLFNBQVNqRCxPQUFPRSxTQUFTMEMsSUFBSSxLQUFLNUMsT0FBT0UsU0FBUzJDLEtBQUs7QUFBQSxFQUN6RCxDQUFDO0FBRUQsUUFBTUssVUFBVUosYUFBYUs7QUFDN0IsUUFBTUMsVUFBVUEsTUFBTSxLQUFLM0IsWUFBWTRCLGtCQUFrQixFQUFFTixVQUFVLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDbEYsUUFBTU8sYUFBYUEsQ0FBQ0MsTUFDbEJmLFNBQVNlLGFBQWFqRSxXQUFXaUUsRUFBRUMsVUFBVSxrQkFBa0I7QUFFakUsUUFBTUMsZUFBZTVFLFlBQVk7QUFBQSxJQUMvQjZFLFlBQVlBLE1BQ1Z6RSxvQkFBb0I7QUFBQSxNQUNsQjBDO0FBQUFBLE1BQ0FLO0FBQUFBLE1BQ0FGLGFBQWFBLFlBQVloQyxLQUFLO0FBQUEsTUFDOUJxQyxRQUFRdkMsU0FBU3VDLE1BQU0sS0FBSztBQUFBLE1BQzVCd0IsZUFBZWY7QUFBQUEsTUFDZmdCLGdCQUFnQmY7QUFBQUEsSUFDbEIsQ0FBQztBQUFBLElBQ0hnQixXQUFXQSxNQUFNO0FBQ2ZyQixlQUFTLElBQUk7QUFDYlQscUJBQWUsRUFBRTtBQUNqQkssZ0JBQVUsRUFBRTtBQUNaZ0IsY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBVSxTQUFTUjtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNUyxxQkFBcUJsRixZQUFZO0FBQUEsSUFDckM2RSxZQUFZQSxDQUFDTSxPQUFlOUUsd0JBQXdCOEUsRUFBRTtBQUFBLElBQ3RESCxXQUFXVDtBQUFBQSxJQUNYVSxTQUFTUjtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNVyxpQkFBaUJwRixZQUFZO0FBQUEsSUFDakM2RSxZQUFZQSxNQUNWdEUsaUJBQWlCO0FBQUEsTUFDZnVDO0FBQUFBLE1BQ0FnQyxlQUFlZjtBQUFBQSxNQUNmZ0IsZ0JBQWdCZjtBQUFBQSxNQUNoQnFCLGNBQWN0RSxTQUFTeUMsV0FBVyxLQUFLO0FBQUEsSUFDekMsQ0FBQztBQUFBLElBQ0h3QixXQUFXQSxNQUFNO0FBQ2ZyQixlQUFTLElBQUk7QUFDYkYscUJBQWUsRUFBRTtBQUNqQmMsY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBVSxTQUFTUjtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNYSxXQUFXeEY7QUFBQUEsSUFDZixNQUFNeUYsS0FBS0MsSUFBSSxHQUFHLElBQUluQixTQUFTb0IsZ0JBQWdCLElBQUlDLElBQUksQ0FBQ0MsTUFBTUEsRUFBRXJDLE1BQU0sQ0FBQztBQUFBLElBQ3ZFLENBQUNlLFNBQVNvQixZQUFZO0FBQUEsRUFDeEI7QUFFQSxRQUFNRyxhQUFhdkIsU0FBU3dCLHdCQUF3QjtBQUVwRCxTQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFN0QsU0FBUyxJQUFJOEQsVUFBVSxNQUFNQyxRQUFRLFNBQVMsR0FDM0Q7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUU5RCxTQUFTLFFBQVErRCxZQUFZLFVBQVU5RCxLQUFLLElBQUkrRCxjQUFjLElBQUlDLFVBQVUsT0FBTyxHQUNoSDtBQUFBLDZCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRTNELFVBQVUsU0FBUyxHQUFHLDJCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsTUFDbEUsdUJBQUMsVUFBSyxPQUFPLEVBQUU0RCxNQUFNLEVBQUUsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPcEQ7QUFBQUEsVUFDUCxVQUFVLENBQUMyQixNQUFNMUIsY0FBYzBCLEVBQUUwQixPQUFPbEYsS0FBSztBQUFBLFVBQzdDLE9BQU8sRUFBRW1GLE9BQU8sSUFBSTtBQUFBO0FBQUEsUUFKdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXdCO0FBQUEsU0FQMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQ3BDLGFBQWFxQyxXQUFXLHVCQUFDLGNBQVcsT0FBT3JDLGFBQWFQLE9BQU8sTUFBSyxxQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RDtBQUFBLElBQ3JGQSxTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLElBRTFDTyxhQUFhc0MsYUFBYSx1QkFBQyxnQkFBYSxNQUFNLEdBQUcsV0FBVyxNQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFFL0RsQyxXQUNDLG1DQUNFO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLE9BQU8sRUFBRXBDLFNBQVMsUUFBUUMsS0FBSyxJQUFJc0UscUJBQXFCLHdDQUF3Q1AsY0FBYyxHQUFHO0FBQUEsVUFFakg7QUFBQSxtQ0FBQyxRQUFLLE9BQU8sWUFBWTVCLFFBQVFvQyxVQUFVLFlBQVksT0FBTzdGLFVBQVV5RCxRQUFRcUMsT0FBTyxHQUFHLE1BQUssa0JBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZHO0FBQUEsWUFDN0csdUJBQUMsUUFBSyxPQUFNLDJCQUEwQixPQUFPOUYsVUFBVXlELFFBQVFzQyxlQUFlLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsWUFDaEYsdUJBQUMsUUFBSyxPQUFNLGdCQUFlLE9BQU8vRixVQUFVeUQsUUFBUXVDLFVBQVUsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxRQUFLLE9BQU0sb0JBQW1CLE9BQU9oRyxVQUFVeUQsUUFBUXdDLGFBQWEsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTixPQUFPakcsVUFBVXlELFFBQVF5QyxTQUFTO0FBQUEsZ0JBQ2xDLE1BQU16QyxRQUFReUMsYUFBYSxJQUFJLGNBQWM7QUFBQTtBQUFBLGNBSC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUcrRDtBQUFBO0FBQUE7QUFBQSxRQVhqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFhQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUU5RSxTQUFTLElBQUlDLFNBQVMsUUFBUUMsS0FBSyxJQUFJK0QsY0FBYyxHQUFHLEdBQ25HO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVoRSxTQUFTLFFBQVE4RSxnQkFBZ0IsaUJBQWlCZixZQUFZLFlBQVlFLFVBQVUsUUFBUWhFLEtBQUssRUFBRSxHQUMvRztBQUFBLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUssVUFBVSxTQUFTLEdBQUcsMkJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDbkU4QixRQUFRZ0IsaUJBQWlCLE9BQ3hCLHVCQUFDLFVBQUssV0FBVSxZQUFXLE9BQU8sRUFBRTdDLE9BQU8saUJBQWlCLEdBQ3pENUI7QUFBQUEsc0JBQVV5RCxRQUFRcUMsT0FBTztBQUFBLFlBQUU7QUFBQSxZQUFLOUYsVUFBVXlELFFBQVFnQixZQUFZO0FBQUEsWUFDOURPLGVBQWUsUUFDZCx1QkFBQyxZQUFPLE9BQU8sRUFBRXBELE9BQU9vRCxjQUFjLElBQUksY0FBYyxnQkFBZ0JvQixZQUFZLEVBQUUsR0FDbEZwQjtBQUFBQSw0QkFBYSxLQUFLcUIsUUFBUSxDQUFDO0FBQUEsY0FBRTtBQUFBLGlCQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BLElBRUEsdUJBQUMsVUFBSyxPQUFPLEVBQUV6RSxPQUFPLG1CQUFtQixHQUFHLHFDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRTtBQUFBLGFBWnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBRUM2QixRQUFRZ0IsaUJBQWlCLFFBQ3hCLHVCQUFDLFNBQUksT0FBTyxFQUFFNkIsWUFBWSxtQkFBbUJDLGNBQWMsS0FBS0MsUUFBUSxJQUFJQyxVQUFVLFNBQVMsR0FDN0Y7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU87QUFBQSxjQUNMaEIsT0FBTyxHQUFHZCxLQUFLK0IsSUFBSSxNQUFNMUIsY0FBYyxLQUFLLEdBQUcsQ0FBQztBQUFBLGNBQ2hEd0IsUUFBUTtBQUFBLGNBQ1JGLGFBQWF0QixjQUFjLE1BQU0sSUFBSSxjQUFjO0FBQUEsY0FDbkR1QixjQUFjO0FBQUEsY0FDZEksWUFBWTtBQUFBLFlBQ2Q7QUFBQTtBQUFBLFVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0ksS0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdGLHVCQUFDLFNBQUksT0FBTyxFQUFFdEYsU0FBUyxRQUFRQyxLQUFLLEdBQUc0RCxVQUFVLElBQUksR0FDbkQ7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBYXpCLFFBQVFnQixpQkFBaUIsT0FBTyxtQkFBbUI7QUFBQSxjQUNoRSxXQUFVO0FBQUEsY0FDVixPQUFPN0I7QUFBQUEsY0FDUCxVQUFVLENBQUNrQixNQUFNakIsZUFBZWlCLEVBQUUwQixPQUFPbEYsS0FBSztBQUFBO0FBQUEsWUFKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSWtEO0FBQUEsVUFFbEQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLFVBQVVILFNBQVN5QyxXQUFXLE1BQU0sUUFBUTRCLGVBQWVvQztBQUFBQSxjQUMzRCxTQUFTLE1BQU1wQyxlQUFlcUMsT0FBTztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0NBO0FBQUEsTUFFQ3BELFFBQVFvQixhQUFhaUMsU0FBUyxLQUM3Qix1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRTFGLFNBQVMsSUFBSWlFLGNBQWMsR0FBRyxHQUN6RTtBQUFBLCtCQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRTFELFVBQVUsU0FBUyxHQUFHLCtCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsUUFDeEUsdUJBQUMsU0FBSSxPQUFPLEVBQUVOLFNBQVMsUUFBUStELFlBQVksWUFBWTlELEtBQUssR0FBR2tGLFFBQVEsS0FBS08sV0FBVyxHQUFHLEdBQ3ZGdEQsa0JBQVFvQixhQUFhQztBQUFBQSxVQUFJLENBQUNDLE1BQ3pCLHVCQUFDLFNBQWdCLE9BQU8sRUFBRVEsTUFBTSxHQUFHbEUsU0FBUyxRQUFRQyxLQUFLLEdBQUcwRixjQUFjLFNBQVMsR0FDakY7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU8sT0FBT2pDLEVBQUVrQyxHQUFHLEtBQUtqSCxVQUFVK0UsRUFBRXJDLE1BQU0sQ0FBQztBQUFBLGdCQUMzQyxPQUFPO0FBQUEsa0JBQ0wrQyxPQUFPO0FBQUEsa0JBQ1BQLFVBQVU7QUFBQSxrQkFDVnNCLFFBQVEsR0FBRzdCLEtBQUtDLElBQUksR0FBSUcsRUFBRXJDLFNBQVNnQyxXQUFZLEdBQUcsQ0FBQztBQUFBLGtCQUNuRDRCLFlBQVk7QUFBQSxrQkFDWkMsY0FBYztBQUFBLGtCQUNkVyxTQUFTO0FBQUEsZ0JBQ1g7QUFBQTtBQUFBLGNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0k7QUFBQSxZQUVKLHVCQUFDLFVBQUssV0FBVSxZQUFXLE9BQU8sRUFBRXZGLFVBQVUsVUFBVUMsT0FBTyxtQkFBbUIsR0FDL0VtRCxZQUFFa0MsT0FETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFkUWxDLEVBQUVrQyxLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxRQUNELEtBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxXQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRXRGLFVBQVUsU0FBUyxHQUFHLDZCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLFVBQ3RFLHVCQUFDLFVBQUssV0FBVSxZQUFXLE9BQU8sRUFBRUMsT0FBTyxvQkFBb0JELFVBQVUsVUFBVSxHQUFHO0FBQUE7QUFBQSxZQUM3RTNCLFVBQVV5RCxRQUFRdUMsYUFBYXZDLFFBQVF3QyxhQUFhO0FBQUEsZUFEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQ3hDLFFBQVEwRCxNQUFNckM7QUFBQUEsVUFBSSxDQUFDc0MsU0FDbEIsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRS9GLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEscUNBQUMsVUFBTThGLGVBQUsvRSxlQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdCO0FBQUEsY0FDeEIsdUJBQUMsVUFBSyxPQUFPLEVBQUVWLFVBQVUsVUFBVUMsT0FBTyxtQkFBbUIsR0FDMUQ3Qix3QkFBY3FILEtBQUs3RSxVQUFVLEtBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWxCLFNBQVMsUUFBUUMsS0FBSyxHQUFHOEQsWUFBWSxTQUFTLEdBQzFEO0FBQUEscUNBQUMsVUFBSyxXQUFVLFlBQVlwRixvQkFBVW9ILEtBQUsxRSxNQUFNLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsY0FDbkQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixjQUFZLGlCQUFpQjBFLEtBQUsvRSxXQUFXO0FBQUEsa0JBQzdDLE9BQU07QUFBQSxrQkFDTixPQUFPLEVBQUVnRixXQUFXLElBQUlqRyxTQUFTLFVBQVVPLFVBQVUsVUFBVTtBQUFBLGtCQUMvRCxVQUFVMkMsbUJBQW1Cc0M7QUFBQUEsa0JBQzdCLFNBQVMsWUFBWTtBQUNuQix3QkFDRSxNQUFNM0UsT0FBT3FGLFFBQVE7QUFBQSxzQkFDbkJDLE9BQU87QUFBQSxzQkFDUHhELFNBQVMsb0JBQW9CcUQsS0FBSy9FLFdBQVc7QUFBQSxzQkFDN0NtRixjQUFjO0FBQUEsc0JBQ2RDLFFBQVE7QUFBQSxvQkFDVixDQUFDO0FBRURuRCx5Q0FBbUJ1QyxPQUFPTyxLQUFLN0MsRUFBRTtBQUFBLGtCQUNyQztBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBb0JBO0FBQUEsaUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUJBO0FBQUEsZUE5QitCNkMsS0FBSzdDLElBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBO0FBQUEsUUFDRDtBQUFBLFFBQ0FkLFFBQVEwRCxNQUFNTCxXQUFXLEtBQ3hCLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRWxGLE9BQU8sbUJBQW1CLEdBQUcsK0NBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFTixLQUFLLEdBQUdnRSxVQUFVLE9BQU8sR0FDNUQ7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBWTtBQUFBLGNBQ1osT0FBTyxFQUFFQyxNQUFNLEdBQUdoRSxVQUFVLElBQUk7QUFBQSxjQUNoQyxPQUFPYztBQUFBQSxjQUNQLFVBQVUsQ0FBQ3lCLE1BQU14QixlQUFld0IsRUFBRTBCLE9BQU9sRixLQUFLO0FBQUE7QUFBQSxZQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJa0Q7QUFBQSxVQUVsRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTyxFQUFFaUYsTUFBTSxHQUFHaEUsVUFBVSxLQUFLa0UsT0FBTyxPQUFPO0FBQUEsY0FDL0MsT0FBT2xEO0FBQUFBLGNBQ1AsVUFBVSxDQUFDdUIsTUFBTXRCLGNBQWNqQyxPQUFPdUQsRUFBRTBCLE9BQU9sRixLQUFLLENBQUM7QUFBQSxjQUVyRDtBQUFBLHVDQUFDLFlBQU8sT0FBT1IsU0FBUzJDLE1BQU0sb0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtDO0FBQUEsZ0JBQ2xDLHVCQUFDLFlBQU8sT0FBTzNDLFNBQVM0SCxVQUFVLHdCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBO0FBQUE7QUFBQSxZQU41QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRW5DLE1BQU0sR0FBR2hFLFVBQVUsSUFBSTtBQUFBLGNBQ2hDLE9BQU9tQjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ29CLE1BQU1uQixVQUFVbUIsRUFBRTBCLE9BQU9sRixLQUFLO0FBQUE7QUFBQSxZQUwzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLNkM7QUFBQSxVQUU3QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsVUFBVStCLFlBQVloQyxLQUFLLE1BQU0sTUFBTUYsU0FBU3VDLE1BQU0sTUFBTSxRQUFRc0IsYUFBYTRDO0FBQUFBLGNBQ2pGLFNBQVMsTUFBTTVDLGFBQWE2QyxPQUFPO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUEsV0E5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStFQTtBQUFBLFNBMUtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyS0E7QUFBQSxPQTdMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0xBO0FBRUo7QUFBQzlFLEdBNVFlRCxhQUFXO0FBQUEsVUFDTHhDLGdCQUNMQyxXQUNNSyxjQVlBUCxVQVdBRCxhQW1CTUEsYUFNSkEsV0FBVztBQUFBO0FBQUEsTUFuRHBCMEM7QUFBVyxJQUFBRCxJQUFBOEY7QUFBQSxhQUFBOUYsSUFBQTtBQUFBLGFBQUE4RixLQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwidXNlRGlhbG9nIiwiY3JlYXRlT3BlcmF0aW5nQ29zdCIsImRlYWN0aXZhdGVPcGVyYXRpbmdDb3N0IiwiZ2V0QmlsbGluZ1N1bW1hcnkiLCJzZXRSZXZlbnVlVGFyZ2V0IiwidXNlQXV0aFN0b3JlIiwiQXBpRXJyb3IiLCJDb3N0VHlwZSIsImNvc3RUeXBlTGFiZWwiLCJmb3JtYXRCUkwiLCJRdWVyeUVycm9yIiwiU2tlbGV0b25MaXN0IiwicGFyc2VOdW0iLCJyYXciLCJ0cmltIiwidmFsdWUiLCJOdW1iZXIiLCJyZXBsYWNlIiwiaXNGaW5pdGUiLCJjdXJyZW50TW9udGhWYWx1ZSIsIm5vdyIsIkRhdGUiLCJnZXRGdWxsWWVhciIsIlN0cmluZyIsImdldE1vbnRoIiwicGFkU3RhcnQiLCJDYXJkIiwibGFiZWwiLCJ0b25lIiwicGFkZGluZyIsImRpc3BsYXkiLCJnYXAiLCJtaW5XaWR0aCIsImZvbnRGYW1pbHkiLCJ0ZXh0VHJhbnNmb3JtIiwibGV0dGVyU3BhY2luZyIsImZvbnRTaXplIiwiY29sb3IiLCJfYyIsIkZpbmFuY2VQYWdlIiwiX3MiLCJxdWVyeUNsaWVudCIsImRpYWxvZyIsImJyYW5jaElkIiwibW9udGhWYWx1ZSIsInNldE1vbnRoVmFsdWUiLCJkZXNjcmlwdGlvbiIsInNldERlc2NyaXB0aW9uIiwiY29zdFR5cGVJZCIsInNldENvc3RUeXBlSWQiLCJGaXhvIiwiYW1vdW50Iiwic2V0QW1vdW50IiwidGFyZ2V0SW5wdXQiLCJzZXRUYXJnZXRJbnB1dCIsImVycm9yIiwic2V0RXJyb3IiLCJ5ZWFyU3RyIiwibW9udGhTdHIiLCJzcGxpdCIsInllYXIiLCJtb250aCIsInN1bW1hcnlRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImVuYWJsZWQiLCJzdW1tYXJ5IiwiZGF0YSIsInJlZnJlc2giLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uQXBpRXJyb3IiLCJlIiwibWVzc2FnZSIsImNvc3RNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJyZWZlcmVuY2VZZWFyIiwicmVmZXJlbmNlTW9udGgiLCJvblN1Y2Nlc3MiLCJvbkVycm9yIiwicmVtb3ZlQ29zdE11dGF0aW9uIiwiaWQiLCJ0YXJnZXRNdXRhdGlvbiIsInRhcmdldEFtb3VudCIsIm1heERhaWx5IiwiTWF0aCIsIm1heCIsImRhaWx5UmV2ZW51ZSIsIm1hcCIsImQiLCJhdHRhaW5tZW50IiwidGFyZ2V0QXR0YWlubWVudFJhdGUiLCJtYXhXaWR0aCIsIm1hcmdpbiIsImFsaWduSXRlbXMiLCJtYXJnaW5Cb3R0b20iLCJmbGV4V3JhcCIsImZsZXgiLCJ0YXJnZXQiLCJ3aWR0aCIsImlzRXJyb3IiLCJpc0xvYWRpbmciLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwic2FsZXNDb3VudCIsInJldmVudWUiLCJjb3N0T2ZHb29kc1NvbGQiLCJmaXhlZENvc3RzIiwidmFyaWFibGVDb3N0cyIsIm5ldFJlc3VsdCIsImp1c3RpZnlDb250ZW50IiwibWFyZ2luTGVmdCIsInRvRml4ZWQiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyUmFkaXVzIiwiaGVpZ2h0Iiwib3ZlcmZsb3ciLCJtaW4iLCJ0cmFuc2l0aW9uIiwiaXNQZW5kaW5nIiwibXV0YXRlIiwibGVuZ3RoIiwibWFyZ2luVG9wIiwianVzdGlmeUl0ZW1zIiwiZGF5Iiwib3BhY2l0eSIsImNvc3RzIiwiY29zdCIsIm1pbkhlaWdodCIsImNvbmZpcm0iLCJ0aXRsZSIsImNvbmZpcm1MYWJlbCIsImRhbmdlciIsIlZhcmlhdmVsIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkZpbmFuY2VQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyB1c2VEaWFsb2cgfSBmcm9tIFwiLi4vLi4vdWkvRGlhbG9nXCI7XHJcbmltcG9ydCB7XHJcbiAgY3JlYXRlT3BlcmF0aW5nQ29zdCxcclxuICBkZWFjdGl2YXRlT3BlcmF0aW5nQ29zdCxcclxuICBnZXRCaWxsaW5nU3VtbWFyeSxcclxuICBzZXRSZXZlbnVlVGFyZ2V0LFxyXG59IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IENvc3RUeXBlLCBjb3N0VHlwZUxhYmVsLCBmb3JtYXRCUkwgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcbmltcG9ydCB7IFNrZWxldG9uTGlzdCB9IGZyb20gXCIuLi8uLi91aS9Ta2VsZXRvblwiO1xyXG5cclxuY29uc3QgcGFyc2VOdW0gPSAocmF3OiBzdHJpbmcpOiBudW1iZXIgfCBudWxsID0+IHtcclxuICBpZiAocmF3LnRyaW0oKSA9PT0gXCJcIikgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgdmFsdWUgPSBOdW1iZXIocmF3LnJlcGxhY2UoXCIsXCIsIFwiLlwiKSk7XHJcbiAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgJiYgdmFsdWUgPiAwID8gdmFsdWUgOiBudWxsO1xyXG59O1xyXG5cclxuZnVuY3Rpb24gY3VycmVudE1vbnRoVmFsdWUoKTogc3RyaW5nIHtcclxuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gIHJldHVybiBgJHtub3cuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcobm93LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxufVxyXG5cclxuZnVuY3Rpb24gQ2FyZCh7IGxhYmVsLCB2YWx1ZSwgdG9uZSB9OiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBzdHJpbmc7IHRvbmU/OiBzdHJpbmcgfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzTmFtZT1cInRpY2tldFwiXHJcbiAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMTRweCAxOHB4XCIsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIG1pbldpZHRoOiAwIH19XHJcbiAgICA+XHJcbiAgICAgIDxzcGFuXHJcbiAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1jb25kKVwiLFxyXG4gICAgICAgICAgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIixcclxuICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wOGVtXCIsXHJcbiAgICAgICAgICBmb250U2l6ZTogXCIwLjc4cmVtXCIsXHJcbiAgICAgICAgICBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIHtsYWJlbH1cclxuICAgICAgPC9zcGFuPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bSBkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS42cmVtXCIsIGNvbG9yOiB0b25lID8/IFwidmFyKC0taW5rKVwiIH19PlxyXG4gICAgICAgIHt2YWx1ZX1cclxuICAgICAgPC9zcGFuPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEZpbmFuY2VQYWdlKCkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCBkaWFsb2cgPSB1c2VEaWFsb2coKTtcclxuICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbbW9udGhWYWx1ZSwgc2V0TW9udGhWYWx1ZV0gPSB1c2VTdGF0ZShjdXJyZW50TW9udGhWYWx1ZSgpKTtcclxuICBjb25zdCBbZGVzY3JpcHRpb24sIHNldERlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjb3N0VHlwZUlkLCBzZXRDb3N0VHlwZUlkXSA9IHVzZVN0YXRlPG51bWJlcj4oQ29zdFR5cGUuRml4byk7XHJcbiAgY29uc3QgW2Ftb3VudCwgc2V0QW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0YXJnZXRJbnB1dCwgc2V0VGFyZ2V0SW5wdXRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3QgW3llYXJTdHIsIG1vbnRoU3RyXSA9IG1vbnRoVmFsdWUuc3BsaXQoXCItXCIpO1xyXG4gIGNvbnN0IHllYXIgPSBOdW1iZXIoeWVhclN0cik7XHJcbiAgY29uc3QgbW9udGggPSBOdW1iZXIobW9udGhTdHIpO1xyXG5cclxuICBjb25zdCBzdW1tYXJ5UXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiZmluYW5jZVwiLCBicmFuY2hJZCwgeWVhciwgbW9udGhdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0QmlsbGluZ1N1bW1hcnkoYnJhbmNoSWQsIHllYXIsIG1vbnRoKSxcclxuICAgIGVuYWJsZWQ6IE51bWJlci5pc0Zpbml0ZSh5ZWFyKSAmJiBOdW1iZXIuaXNGaW5pdGUobW9udGgpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBzdW1tYXJ5ID0gc3VtbWFyeVF1ZXJ5LmRhdGE7XHJcbiAgY29uc3QgcmVmcmVzaCA9ICgpID0+IHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiZmluYW5jZVwiXSB9KTtcclxuICBjb25zdCBvbkFwaUVycm9yID0gKGU6IHVua25vd24pID0+XHJcbiAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIk9wZXJhw6fDo28gZmFsaG91LlwiKTtcclxuXHJcbiAgY29uc3QgY29zdE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgY3JlYXRlT3BlcmF0aW5nQ29zdCh7XHJcbiAgICAgICAgYnJhbmNoSWQsXHJcbiAgICAgICAgY29zdFR5cGVJZCxcclxuICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24udHJpbSgpLFxyXG4gICAgICAgIGFtb3VudDogcGFyc2VOdW0oYW1vdW50KSA/PyAwLFxyXG4gICAgICAgIHJlZmVyZW5jZVllYXI6IHllYXIsXHJcbiAgICAgICAgcmVmZXJlbmNlTW9udGg6IG1vbnRoLFxyXG4gICAgICB9KSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgc2V0RGVzY3JpcHRpb24oXCJcIik7XHJcbiAgICAgIHNldEFtb3VudChcIlwiKTtcclxuICAgICAgcmVmcmVzaCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJlbW92ZUNvc3RNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46IChpZDogbnVtYmVyKSA9PiBkZWFjdGl2YXRlT3BlcmF0aW5nQ29zdChpZCksXHJcbiAgICBvblN1Y2Nlc3M6IHJlZnJlc2gsXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB0YXJnZXRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIHNldFJldmVudWVUYXJnZXQoe1xyXG4gICAgICAgIGJyYW5jaElkLFxyXG4gICAgICAgIHJlZmVyZW5jZVllYXI6IHllYXIsXHJcbiAgICAgICAgcmVmZXJlbmNlTW9udGg6IG1vbnRoLFxyXG4gICAgICAgIHRhcmdldEFtb3VudDogcGFyc2VOdW0odGFyZ2V0SW5wdXQpID8/IDAsXHJcbiAgICAgIH0pLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICBzZXRUYXJnZXRJbnB1dChcIlwiKTtcclxuICAgICAgcmVmcmVzaCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IG1heERhaWx5ID0gdXNlTWVtbyhcclxuICAgICgpID0+IE1hdGgubWF4KDEsIC4uLihzdW1tYXJ5Py5kYWlseVJldmVudWUgPz8gW10pLm1hcCgoZCkgPT4gZC5hbW91bnQpKSxcclxuICAgIFtzdW1tYXJ5Py5kYWlseVJldmVudWVdLFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGF0dGFpbm1lbnQgPSBzdW1tYXJ5Py50YXJnZXRBdHRhaW5tZW50UmF0ZSA/PyBudWxsO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMTAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDE0LCBtYXJnaW5Cb3R0b206IDE2LCBmbGV4V3JhcDogXCJ3cmFwXCIgfX0+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjdyZW1cIiB9fT5GYXR1cmFtZW50bzwvaDI+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSB9fSAvPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuICAgICAgICAgIHZhbHVlPXttb250aFZhbHVlfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNb250aFZhbHVlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAxOTAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtzdW1tYXJ5UXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17c3VtbWFyeVF1ZXJ5LmVycm9yfSB3aGF0PVwibyByZXN1bW8gZG8gbcOqc1wiIC8+fVxyXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAge3N1bW1hcnlRdWVyeS5pc0xvYWRpbmcgJiYgPFNrZWxldG9uTGlzdCByb3dzPXs1fSByb3dIZWlnaHQ9ezcwfSAvPn1cclxuXHJcbiAgICAgIHtzdW1tYXJ5ICYmIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMVwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyLCBncmlkVGVtcGxhdGVDb2x1bW5zOiBcInJlcGVhdChhdXRvLWZpdCwgbWlubWF4KDE3MHB4LCAxZnIpKVwiLCBtYXJnaW5Cb3R0b206IDE2IH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxDYXJkIGxhYmVsPXtgUmVjZWl0YSAoJHtzdW1tYXJ5LnNhbGVzQ291bnR9IHZlbmRhcylgfSB2YWx1ZT17Zm9ybWF0QlJMKHN1bW1hcnkucmV2ZW51ZSl9IHRvbmU9XCJ2YXIoLS1hbWJlcilcIiAvPlxyXG4gICAgICAgICAgICA8Q2FyZCBsYWJlbD1cIkNNViAocHJvZHV0b3MgdmVuZGlkb3MpXCIgdmFsdWU9e2Zvcm1hdEJSTChzdW1tYXJ5LmNvc3RPZkdvb2RzU29sZCl9IC8+XHJcbiAgICAgICAgICAgIDxDYXJkIGxhYmVsPVwiQ3VzdG9zIGZpeG9zXCIgdmFsdWU9e2Zvcm1hdEJSTChzdW1tYXJ5LmZpeGVkQ29zdHMpfSAvPlxyXG4gICAgICAgICAgICA8Q2FyZCBsYWJlbD1cIkN1c3RvcyB2YXJpw6F2ZWlzXCIgdmFsdWU9e2Zvcm1hdEJSTChzdW1tYXJ5LnZhcmlhYmxlQ29zdHMpfSAvPlxyXG4gICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiUmVzdWx0YWRvXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybWF0QlJMKHN1bW1hcnkubmV0UmVzdWx0KX1cclxuICAgICAgICAgICAgICB0b25lPXtzdW1tYXJ5Lm5ldFJlc3VsdCA+PSAwID8gXCJ2YXIoLS1vaylcIiA6IFwidmFyKC0tZGFuZ2VyKVwifVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTJcIiBzdHlsZT17eyBwYWRkaW5nOiAxOCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAsIG1hcmdpbkJvdHRvbTogMTYgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJiYXNlbGluZVwiLCBmbGV4V3JhcDogXCJ3cmFwXCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+TWV0YSBkbyBtw6pzPC9zcGFuPlxyXG4gICAgICAgICAgICAgIHtzdW1tYXJ5LnRhcmdldEFtb3VudCAhPT0gbnVsbCA/IChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdEJSTChzdW1tYXJ5LnJldmVudWUpfSBkZSB7Zm9ybWF0QlJMKHN1bW1hcnkudGFyZ2V0QW1vdW50KX1cclxuICAgICAgICAgICAgICAgICAge2F0dGFpbm1lbnQgIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgc3R5bGU9e3sgY29sb3I6IGF0dGFpbm1lbnQgPj0gMSA/IFwidmFyKC0tb2spXCIgOiBcInZhcigtLWFtYmVyKVwiLCBtYXJnaW5MZWZ0OiA4IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgeyhhdHRhaW5tZW50ICogMTAwKS50b0ZpeGVkKDEpfSVcclxuICAgICAgICAgICAgICAgICAgICA8L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19Pm5lbmh1bWEgbWV0YSBkZWZpbmlkYTwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtzdW1tYXJ5LnRhcmdldEFtb3VudCAhPT0gbnVsbCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcInZhcigtLWJnLXByZXNzKVwiLCBib3JkZXJSYWRpdXM6IDk5OSwgaGVpZ2h0OiAxNCwgb3ZlcmZsb3c6IFwiaGlkZGVuXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IGAke01hdGgubWluKDEwMCwgKGF0dGFpbm1lbnQgPz8gMCkgKiAxMDApfSVgLFxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogKGF0dGFpbm1lbnQgPz8gMCkgPj0gMSA/IFwidmFyKC0tb2spXCIgOiBcInZhcigtLWFtYmVyKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogOTk5LFxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IFwid2lkdGggMzAwbXMgZWFzZVwiLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogOCwgbWF4V2lkdGg6IDQyMCB9fT5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtzdW1tYXJ5LnRhcmdldEFtb3VudCAhPT0gbnVsbCA/IFwiTm92YSBtZXRhIChSJClcIiA6IFwiRGVmaW5pciBtZXRhIChSJClcIn1cclxuICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3RhcmdldElucHV0fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUYXJnZXRJbnB1dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFyc2VOdW0odGFyZ2V0SW5wdXQpID09PSBudWxsIHx8IHRhcmdldE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRhcmdldE11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFNhbHZhciBtZXRhXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge3N1bW1hcnkuZGFpbHlSZXZlbnVlLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldCByaXNlIHJpc2UtMlwiIHN0eWxlPXt7IHBhZGRpbmc6IDE4LCBtYXJnaW5Cb3R0b206IDE2IH19PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5SZWNlaXRhIHBvciBkaWE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJmbGV4LWVuZFwiLCBnYXA6IDQsIGhlaWdodDogMTIwLCBtYXJnaW5Ub3A6IDEyIH19PlxyXG4gICAgICAgICAgICAgICAge3N1bW1hcnkuZGFpbHlSZXZlbnVlLm1hcCgoZCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5kYXl9IHN0eWxlPXt7IGZsZXg6IDEsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIGp1c3RpZnlJdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YERpYSAke2QuZGF5fTogJHtmb3JtYXRCUkwoZC5hbW91bnQpfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heFdpZHRoOiAzNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBgJHtNYXRoLm1heCg0LCAoZC5hbW91bnQgLyBtYXhEYWlseSkgKiAxMDApfXB4YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1hbWJlcilcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjRweCA0cHggMCAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuOSxcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuN3JlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZC5kYXl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtaGVhZFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5DdXN0b3MgZG8gbcOqczwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgdG90YWwge2Zvcm1hdEJSTChzdW1tYXJ5LmZpeGVkQ29zdHMgKyBzdW1tYXJ5LnZhcmlhYmxlQ29zdHMpfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7c3VtbWFyeS5jb3N0cy5tYXAoKGNvc3QpID0+IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBrZXk9e2Nvc3QuaWR9PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj57Y29zdC5kZXNjcmlwdGlvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAge2Nvc3RUeXBlTGFiZWxbY29zdC5jb3N0VHlwZUlkXX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDgsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+e2Zvcm1hdEJSTChjb3N0LmFtb3VudCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFJlbW92ZXIgY3VzdG8gJHtjb3N0LmRlc2NyaXB0aW9ufWB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZW1vdmVyIGN1c3RvXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTBweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVtb3ZlQ29zdE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJSZW1vdmVyIGN1c3RvXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYFJlbW92ZXIgbyBjdXN0byBcIiR7Y29zdC5kZXNjcmlwdGlvbn1cIj9gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJSZW1vdmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGFuZ2VyOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZW1vdmVDb3N0TXV0YXRpb24ubXV0YXRlKGNvc3QuaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICDinJVcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIHtzdW1tYXJ5LmNvc3RzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgTmVuaHVtIGN1c3RvIGxhbsOnYWRvIG5lc3RlIG3DqnMuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBzdHlsZT17eyBnYXA6IDgsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3Jpw6fDo28gKGV4LjogQWx1Z3VlbClcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgZmxleDogMiwgbWluV2lkdGg6IDE2MCB9fVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREZXNjcmlwdGlvbihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTEwLCB3aWR0aDogXCJhdXRvXCIgfX1cclxuICAgICAgICAgICAgICAgIHZhbHVlPXtjb3N0VHlwZUlkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb3N0VHlwZUlkKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9e0Nvc3RUeXBlLkZpeG99PkZpeG88L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9e0Nvc3RUeXBlLlZhcmlhdmVsfT5WYXJpw6F2ZWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVmFsb3IgKFIkKVwiXHJcbiAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxMTAgfX1cclxuICAgICAgICAgICAgICAgIHZhbHVlPXthbW91bnR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFtb3VudChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkZXNjcmlwdGlvbi50cmltKCkgPT09IFwiXCIgfHwgcGFyc2VOdW0oYW1vdW50KSA9PT0gbnVsbCB8fCBjb3N0TXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY29zdE11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICsgTGFuw6dhciBjdXN0b1xyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2ZpbmFuY2UvRmluYW5jZVBhZ2UudHN4In0=