import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/modals/WaiterOpenTableModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { openOrder } from "/src/features/orders/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
export function WaiterOpenTableModal({ table, onClose, onOpened }) {
  _s();
  const { branchId, employeeId } = useAuthStore();
  const [guestCount, setGuestCount] = useState(2);
  const mutation = useMutation({
    mutationFn: () => openOrder({
      branchId,
      diningTableId: table.id,
      comandaId: null,
      employeeId: employeeId ?? 1,
      guestCount,
      notes: null
    }),
    onSuccess: (orderId) => onOpened(orderId)
  });
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "modal-backdrop is-center",
      onMouseDown: (e) => {
        if (e.target === e.currentTarget) onClose();
      },
      style: { position: "absolute" },
      children: /* @__PURE__ */ jsxDEV("div", { className: "modal-panel is-center", style: { width: "90%", maxWidth: "360px", padding: "24px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "modal-head", style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.25rem", fontWeight: "800", textTransform: "uppercase" }, children: [
            "Abrir Mesa ",
            table.number
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
            lineNumber: 60,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost btn-icon", onClick: onClose, "aria-label": "Fechar", children: "✕" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
            lineNumber: 63,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
          lineNumber: 59,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: "8px", marginBottom: "24px", textAlign: "left" }, children: [
          /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.9rem", fontWeight: "600", color: "var(--ink-dim)" }, children: "Pessoas na mesa" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
            lineNumber: 69,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              min: 1,
              value: guestCount,
              onChange: (e) => setGuestCount(Number(e.target.value)),
              autoFocus: true,
              style: {
                padding: "12px",
                borderRadius: "8px",
                border: "1px solid var(--border)",
                backgroundColor: "var(--bg-raise, #f3f4f6)",
                color: "var(--ink)",
                width: "100%",
                fontSize: "1rem"
              }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
              lineNumber: 72,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
          lineNumber: 68,
          columnNumber: 17
        }, this),
        mutation.isError && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--w-warn, #ef4444)", fontSize: "0.85rem", marginBottom: "16px", fontWeight: "500", textAlign: "left" }, children: mutation.error instanceof ApiError ? mutation.error.message : "Falha ao abrir mesa." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
          lineNumber: 91,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "12px", justifyContent: "flex-end" }, children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost",
              onClick: onClose,
              style: { padding: "10px 16px", borderRadius: "8px", fontWeight: "600" },
              children: "Voltar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
              lineNumber: 97,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "waiter-cta",
              onClick: () => mutation.mutate(),
              disabled: mutation.isPending,
              style: { margin: 0, padding: "10px 20px", borderRadius: "8px", fontWeight: "700" },
              children: mutation.isPending ? "Abrindo…" : "Abrir mesa"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
              lineNumber: 105,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
          lineNumber: 96,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
        lineNumber: 58,
        columnNumber: 13
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx",
      lineNumber: 51,
      columnNumber: 5
    },
    this
  );
}
_s(WaiterOpenTableModal, "gDQQREdMOqzaXM4Xee3FfE7m9uo=", false, function() {
  return [useAuthStore, useMutation];
});
_c = WaiterOpenTableModal;
var _c;
$RefreshReg$(_c, "WaiterOpenTableModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenTableModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4Q25CLFNBQVNBLGdCQUFnQjtBQUMxQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFTbEIsZ0JBQVNDLHFCQUFxQixFQUFFQyxPQUFPQyxTQUFTQyxTQUFvQyxHQUFHO0FBQUFDLEtBQUE7QUFDMUYsUUFBTSxFQUFFQyxVQUFVQyxXQUFXLElBQUlSLGFBQWE7QUFDOUMsUUFBTSxDQUFDUyxZQUFZQyxhQUFhLElBQUliLFNBQWlCLENBQUM7QUFFdEQsUUFBTWMsV0FBV2IsWUFBWTtBQUFBLElBQ3pCYyxZQUFZQSxNQUNSYixVQUFVO0FBQUEsTUFDTlE7QUFBQUEsTUFDQU0sZUFBZVYsTUFBTVc7QUFBQUEsTUFDckJDLFdBQVc7QUFBQSxNQUNYUCxZQUFZQSxjQUFjO0FBQUEsTUFDMUJDO0FBQUFBLE1BQ0FPLE9BQU87QUFBQSxJQUNYLENBQUM7QUFBQSxJQUNMQyxXQUFXQSxDQUFDQyxZQUFZYixTQUFTYSxPQUFPO0FBQUEsRUFDNUMsQ0FBQztBQUVELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFdBQVU7QUFBQSxNQUNWLGFBQWEsQ0FBQ0MsTUFBTTtBQUNoQixZQUFJQSxFQUFFQyxXQUFXRCxFQUFFRSxjQUFlakIsU0FBUTtBQUFBLE1BQzlDO0FBQUEsTUFDQSxPQUFPLEVBQUVrQixVQUFVLFdBQVc7QUFBQSxNQUU5QixpQ0FBQyxTQUFJLFdBQVUseUJBQXdCLE9BQU8sRUFBRUMsT0FBTyxPQUFPQyxVQUFVLFNBQVNDLFNBQVMsT0FBTyxHQUM3RjtBQUFBLCtCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxnQkFBZ0IsaUJBQWlCQyxZQUFZLFVBQVVDLGNBQWMsT0FBTyxHQUM5SDtBQUFBLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxXQUFXQyxZQUFZLE9BQU9DLGVBQWUsWUFBWSxHQUFHO0FBQUE7QUFBQSxZQUN6RjdCLE1BQU04QjtBQUFBQSxlQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHNCQUFxQixTQUFTN0IsU0FBUyxjQUFXLFVBQVMsaUJBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVzQixTQUFTLFFBQVFRLEtBQUssT0FBT0wsY0FBYyxRQUFRTSxXQUFXLE9BQU8sR0FDL0U7QUFBQSxpQ0FBQyxXQUFNLE9BQU8sRUFBRUwsVUFBVSxVQUFVQyxZQUFZLE9BQU9LLE9BQU8saUJBQWlCLEdBQUcsK0JBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxLQUFLO0FBQUEsY0FDTCxPQUFPM0I7QUFBQUEsY0FDUCxVQUFVLENBQUNVLE1BQU1ULGNBQWMyQixPQUFPbEIsRUFBRUMsT0FBT2tCLEtBQUssQ0FBQztBQUFBLGNBQ3JEO0FBQUEsY0FDQSxPQUFPO0FBQUEsZ0JBQ0hiLFNBQVM7QUFBQSxnQkFDVGMsY0FBYztBQUFBLGdCQUNkQyxRQUFRO0FBQUEsZ0JBQ1JDLGlCQUFpQjtBQUFBLGdCQUNqQkwsT0FBTztBQUFBLGdCQUNQYixPQUFPO0FBQUEsZ0JBQ1BPLFVBQVU7QUFBQSxjQUNkO0FBQUE7QUFBQSxZQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNNO0FBQUEsYUFsQlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBRUNuQixTQUFTK0IsV0FDTix1QkFBQyxPQUFFLE9BQU8sRUFBRU4sT0FBTywwQkFBMEJOLFVBQVUsV0FBV0QsY0FBYyxRQUFRRSxZQUFZLE9BQU9JLFdBQVcsT0FBTyxHQUN4SHhCLG1CQUFTZ0MsaUJBQWlCMUMsV0FBV1UsU0FBU2dDLE1BQU1DLFVBQVUsMEJBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0osdUJBQUMsU0FBSSxPQUFPLEVBQUVsQixTQUFTLFFBQVFRLEtBQUssUUFBUVAsZ0JBQWdCLFdBQVcsR0FDbkU7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBU3ZCO0FBQUFBLGNBQ1QsT0FBTyxFQUFFcUIsU0FBUyxhQUFhYyxjQUFjLE9BQU9SLFlBQVksTUFBTTtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSjVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNcEIsU0FBU2tDLE9BQU87QUFBQSxjQUMvQixVQUFVbEMsU0FBU21DO0FBQUFBLGNBQ25CLE9BQU8sRUFBRUMsUUFBUSxHQUFHdEIsU0FBUyxhQUFhYyxjQUFjLE9BQU9SLFlBQVksTUFBTTtBQUFBLGNBRWhGcEIsbUJBQVNtQyxZQUFZLGFBQWE7QUFBQTtBQUFBLFlBUHZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFdBeERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5REE7QUFBQTtBQUFBLElBaEVKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWlFQTtBQUVSO0FBQUN4QyxHQXJGZUosc0JBQW9CO0FBQUEsVUFDQ0YsY0FHaEJGLFdBQVc7QUFBQTtBQUFBLEtBSmhCSTtBQUFvQixJQUFBOEM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsIm9wZW5PcmRlciIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwiV2FpdGVyT3BlblRhYmxlTW9kYWwiLCJ0YWJsZSIsIm9uQ2xvc2UiLCJvbk9wZW5lZCIsIl9zIiwiYnJhbmNoSWQiLCJlbXBsb3llZUlkIiwiZ3Vlc3RDb3VudCIsInNldEd1ZXN0Q291bnQiLCJtdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJkaW5pbmdUYWJsZUlkIiwiaWQiLCJjb21hbmRhSWQiLCJub3RlcyIsIm9uU3VjY2VzcyIsIm9yZGVySWQiLCJlIiwidGFyZ2V0IiwiY3VycmVudFRhcmdldCIsInBvc2l0aW9uIiwid2lkdGgiLCJtYXhXaWR0aCIsInBhZGRpbmciLCJkaXNwbGF5IiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwibWFyZ2luQm90dG9tIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwidGV4dFRyYW5zZm9ybSIsIm51bWJlciIsImdhcCIsInRleHRBbGlnbiIsImNvbG9yIiwiTnVtYmVyIiwidmFsdWUiLCJib3JkZXJSYWRpdXMiLCJib3JkZXIiLCJiYWNrZ3JvdW5kQ29sb3IiLCJpc0Vycm9yIiwiZXJyb3IiLCJtZXNzYWdlIiwibXV0YXRlIiwiaXNQZW5kaW5nIiwibWFyZ2luIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiV2FpdGVyT3BlblRhYmxlTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyBvcGVuT3JkZXIgfSBmcm9tIFwiLi4vLi4vLi4vb3JkZXJzL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi8uLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB0eXBlIHsgVGFibGVSZXNwb25zZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9saWIvdHlwZXNcIjtcclxuXHJcbmludGVyZmFjZSBXYWl0ZXJPcGVuVGFibGVNb2RhbFByb3BzIHtcclxuICAgIHRhYmxlOiBUYWJsZVJlc3BvbnNlO1xyXG4gICAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxuICAgIG9uT3BlbmVkOiAob3JkZXJJZDogbnVtYmVyKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gV2FpdGVyT3BlblRhYmxlTW9kYWwoeyB0YWJsZSwgb25DbG9zZSwgb25PcGVuZWQgfTogV2FpdGVyT3BlblRhYmxlTW9kYWxQcm9wcykge1xyXG4gICAgY29uc3QgeyBicmFuY2hJZCwgZW1wbG95ZWVJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgICBjb25zdCBbZ3Vlc3RDb3VudCwgc2V0R3Vlc3RDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDIpO1xyXG5cclxuICAgIGNvbnN0IG11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgICAgICAgIG9wZW5PcmRlcih7XHJcbiAgICAgICAgICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICAgICAgICAgIGRpbmluZ1RhYmxlSWQ6IHRhYmxlLmlkLFxyXG4gICAgICAgICAgICAgICAgY29tYW5kYUlkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgZW1wbG95ZWVJZDogZW1wbG95ZWVJZCA/PyAxLFxyXG4gICAgICAgICAgICAgICAgZ3Vlc3RDb3VudCxcclxuICAgICAgICAgICAgICAgIG5vdGVzOiBudWxsLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICBvblN1Y2Nlc3M6IChvcmRlcklkKSA9PiBvbk9wZW5lZChvcmRlcklkKSxcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtb2RhbC1iYWNrZHJvcCBpcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICBvbk1vdXNlRG93bj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChlLnRhcmdldCA9PT0gZS5jdXJyZW50VGFyZ2V0KSBvbkNsb3NlKCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHBvc2l0aW9uOiBcImFic29sdXRlXCIgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtcGFuZWwgaXMtY2VudGVyXCIgc3R5bGU9e3sgd2lkdGg6IFwiOTAlXCIsIG1heFdpZHRoOiBcIjM2MHB4XCIsIHBhZGRpbmc6IFwiMjRweFwiIH19PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1oZWFkXCIgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgbWFyZ2luQm90dG9tOiBcIjIwcHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4yNXJlbVwiLCBmb250V2VpZ2h0OiBcIjgwMFwiLCB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBYnJpciBNZXNhIHt0YWJsZS5udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1naG9zdCBidG4taWNvblwiIG9uQ2xpY2s9e29uQ2xvc2V9IGFyaWEtbGFiZWw9XCJGZWNoYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAg4pyVXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IFwiOHB4XCIsIG1hcmdpbkJvdHRvbTogXCIyNHB4XCIsIHRleHRBbGlnbjogXCJsZWZ0XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOXJlbVwiLCBmb250V2VpZ2h0OiBcIjYwMFwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQZXNzb2FzIG5hIG1lc2FcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWluPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3Vlc3RDb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRHdWVzdENvdW50KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMTJweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjhweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwidmFyKC0tYmctcmFpc2UsICNmM2Y0ZjYpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCJ2YXIoLS1pbmspXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxcmVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge211dGF0aW9uLmlzRXJyb3IgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLXctd2FybiwgI2VmNDQ0NClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiLCBtYXJnaW5Cb3R0b206IFwiMTZweFwiLCBmb250V2VpZ2h0OiBcIjUwMFwiLCB0ZXh0QWxpZ246IFwibGVmdFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bXV0YXRpb24uZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvciA/IG11dGF0aW9uLmVycm9yLm1lc3NhZ2UgOiBcIkZhbGhhIGFvIGFicmlyIG1lc2EuXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IFwiMTJweFwiLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMTBweCAxNnB4XCIsIGJvcmRlclJhZGl1czogXCI4cHhcIiwgZm9udFdlaWdodDogXCI2MDBcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVm9sdGFyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwid2FpdGVyLWN0YVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW46IDAsIHBhZGRpbmc6IFwiMTBweCAyMHB4XCIsIGJvcmRlclJhZGl1czogXCI4cHhcIiwgZm9udFdlaWdodDogXCI3MDBcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge211dGF0aW9uLmlzUGVuZGluZyA/IFwiQWJyaW5kb+KAplwiIDogXCJBYnJpciBtZXNhXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3dhaXRlci9jb21wb25lbnRzL21vZGFscy9XYWl0ZXJPcGVuVGFibGVNb2RhbC50c3gifQ==