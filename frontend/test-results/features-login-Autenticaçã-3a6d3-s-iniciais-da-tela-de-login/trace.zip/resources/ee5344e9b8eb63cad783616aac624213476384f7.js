import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/comandas/OpenComandaDialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { openOrder } from "/src/features/orders/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { Overlay } from "/src/features/orders/Overlay.tsx";
export function OpenComandaDialog({ comanda, onClose, onOpened }) {
  _s();
  const { branchId, employeeId } = useAuthStore();
  const [customerName, setCustomerName] = useState("");
  const mutation = useMutation({
    mutationFn: () => openOrder({
      branchId,
      diningTableId: null,
      comandaId: comanda.id,
      employeeId: employeeId ?? 1,
      guestCount: 1,
      notes: customerName.trim() === "" ? null : `Cliente: ${customerName.trim()}`
    }),
    onSuccess: (orderId) => onOpened(orderId)
  });
  return /* @__PURE__ */ jsxDEV(Overlay, { title: `Abrir comanda ${comanda.code}`, onClose, children: [
    /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Nome do cliente" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          value: customerName,
          onChange: (e) => setCustomerName(e.target.value),
          autoFocus: true,
          placeholder: "ex.: João"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx",
          lineNumber: 55,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    mutation.isError && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: mutation.error instanceof ApiError ? mutation.error.message : "Falha ao abrir comanda." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx",
      lineNumber: 64,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          onClick: () => mutation.mutate(),
          disabled: mutation.isPending,
          children: mutation.isPending ? "Abrindo…" : "Abrir comanda"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx",
          lineNumber: 73,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx",
      lineNumber: 69,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s(OpenComandaDialog, "hbKjSomKQ09271folK43PQZrFuE=", false, function() {
  return [useAuthStore, useMutation];
});
_c = OpenComandaDialog;
var _c;
$RefreshReg$(_c, "OpenComandaDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/comandas/OpenComandaDialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQWxDUCxTQUFTQSxnQkFBZ0I7QUFDMUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLGVBQWU7QUFRakIsZ0JBQVNDLGtCQUFrQixFQUFFQyxTQUFTQyxTQUFTQyxTQUFnQixHQUFHO0FBQUFDLEtBQUE7QUFDdkUsUUFBTSxFQUFFQyxVQUFVQyxXQUFXLElBQUlULGFBQWE7QUFDOUMsUUFBTSxDQUFDVSxjQUFjQyxlQUFlLElBQUlkLFNBQVMsRUFBRTtBQUVuRCxRQUFNZSxXQUFXZCxZQUFZO0FBQUEsSUFDM0JlLFlBQVlBLE1BQ1ZkLFVBQVU7QUFBQSxNQUNSUztBQUFBQSxNQUNBTSxlQUFlO0FBQUEsTUFDZkMsV0FBV1gsUUFBUVk7QUFBQUEsTUFDbkJQLFlBQVlBLGNBQWM7QUFBQSxNQUMxQlEsWUFBWTtBQUFBLE1BQ1pDLE9BQU9SLGFBQWFTLEtBQUssTUFBTSxLQUFLLE9BQU8sWUFBWVQsYUFBYVMsS0FBSyxDQUFDO0FBQUEsSUFDNUUsQ0FBQztBQUFBLElBQ0hDLFdBQVdBLENBQUNDLFlBQVlmLFNBQVNlLE9BQU87QUFBQSxFQUMxQyxDQUFDO0FBRUQsU0FDRSx1QkFBQyxXQUFRLE9BQU8saUJBQWlCakIsUUFBUWtCLElBQUksSUFBSSxTQUMvQztBQUFBLDJCQUFDLFdBQU0sT0FBTyxFQUFFQyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUN0QztBQUFBLDZCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGtCQUFrQkMsVUFBVSxTQUFTLEdBQUcsK0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkU7QUFBQSxNQUM3RTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBT2hCO0FBQUFBLFVBQ1AsVUFBVSxDQUFDaUIsTUFBTWhCLGdCQUFnQmdCLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxVQUMvQztBQUFBLFVBQ0EsYUFBWTtBQUFBO0FBQUEsUUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJeUI7QUFBQSxTQU4zQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUVDakIsU0FBU2tCLFdBQ1IsdUJBQUMsT0FBRSxXQUFVLGNBQ1ZsQixtQkFBU21CLGlCQUFpQjlCLFdBQVdXLFNBQVNtQixNQUFNQyxVQUFVLDZCQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdGLHVCQUFDLFNBQUksT0FBTyxFQUFFVCxTQUFTLFFBQVFDLEtBQUssSUFBSVMsZ0JBQWdCLFdBQVcsR0FDakU7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGFBQVksU0FBUzVCLFNBQVMsc0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTU8sU0FBU3NCLE9BQU87QUFBQSxVQUMvQixVQUFVdEIsU0FBU3VCO0FBQUFBLFVBRWxCdkIsbUJBQVN1QixZQUFZLGFBQWE7QUFBQTtBQUFBLFFBTnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEJBO0FBRUo7QUFBQzVCLEdBbERlSixtQkFBaUI7QUFBQSxVQUNFSCxjQUdoQkYsV0FBVztBQUFBO0FBQUEsS0FKZEs7QUFBaUIsSUFBQWlDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJvcGVuT3JkZXIiLCJ1c2VBdXRoU3RvcmUiLCJBcGlFcnJvciIsIk92ZXJsYXkiLCJPcGVuQ29tYW5kYURpYWxvZyIsImNvbWFuZGEiLCJvbkNsb3NlIiwib25PcGVuZWQiLCJfcyIsImJyYW5jaElkIiwiZW1wbG95ZWVJZCIsImN1c3RvbWVyTmFtZSIsInNldEN1c3RvbWVyTmFtZSIsIm11dGF0aW9uIiwibXV0YXRpb25GbiIsImRpbmluZ1RhYmxlSWQiLCJjb21hbmRhSWQiLCJpZCIsImd1ZXN0Q291bnQiLCJub3RlcyIsInRyaW0iLCJvblN1Y2Nlc3MiLCJvcmRlcklkIiwiY29kZSIsImRpc3BsYXkiLCJnYXAiLCJjb2xvciIsImZvbnRTaXplIiwiZSIsInRhcmdldCIsInZhbHVlIiwiaXNFcnJvciIsImVycm9yIiwibWVzc2FnZSIsImp1c3RpZnlDb250ZW50IiwibXV0YXRlIiwiaXNQZW5kaW5nIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT3BlbkNvbWFuZGFEaWFsb2cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyBvcGVuT3JkZXIgfSBmcm9tIFwiLi4vb3JkZXJzL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB0eXBlIHsgQ29tYW5kYVJlc3BvbnNlIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgeyBPdmVybGF5IH0gZnJvbSBcIi4uL29yZGVycy9PdmVybGF5XCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gIGNvbWFuZGE6IENvbWFuZGFSZXNwb25zZTtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIG9uT3BlbmVkOiAob3JkZXJJZDogbnVtYmVyKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gT3BlbkNvbWFuZGFEaWFsb2coeyBjb21hbmRhLCBvbkNsb3NlLCBvbk9wZW5lZCB9OiBQcm9wcykge1xyXG4gIGNvbnN0IHsgYnJhbmNoSWQsIGVtcGxveWVlSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IFtjdXN0b21lck5hbWUsIHNldEN1c3RvbWVyTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICBvcGVuT3JkZXIoe1xyXG4gICAgICAgIGJyYW5jaElkLFxyXG4gICAgICAgIGRpbmluZ1RhYmxlSWQ6IG51bGwsXHJcbiAgICAgICAgY29tYW5kYUlkOiBjb21hbmRhLmlkLFxyXG4gICAgICAgIGVtcGxveWVlSWQ6IGVtcGxveWVlSWQgPz8gMSxcclxuICAgICAgICBndWVzdENvdW50OiAxLFxyXG4gICAgICAgIG5vdGVzOiBjdXN0b21lck5hbWUudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IGBDbGllbnRlOiAke2N1c3RvbWVyTmFtZS50cmltKCl9YCxcclxuICAgICAgfSksXHJcbiAgICBvblN1Y2Nlc3M6IChvcmRlcklkKSA9PiBvbk9wZW5lZChvcmRlcklkKSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxPdmVybGF5IHRpdGxlPXtgQWJyaXIgY29tYW5kYSAke2NvbWFuZGEuY29kZX1gfSBvbkNsb3NlPXtvbkNsb3NlfT5cclxuICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDYgfX0+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+Tm9tZSBkbyBjbGllbnRlPC9zcGFuPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgdmFsdWU9e2N1c3RvbWVyTmFtZX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q3VzdG9tZXJOYW1lKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJleC46IEpvw6NvXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAge211dGF0aW9uLmlzRXJyb3IgJiYgKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj5cclxuICAgICAgICAgIHttdXRhdGlvbi5lcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yID8gbXV0YXRpb24uZXJyb3IubWVzc2FnZSA6IFwiRmFsaGEgYW8gYWJyaXIgY29tYW5kYS5cIn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEwLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgVm9sdGFyXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBtdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgIGRpc2FibGVkPXttdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge211dGF0aW9uLmlzUGVuZGluZyA/IFwiQWJyaW5kb+KAplwiIDogXCJBYnJpciBjb21hbmRhXCJ9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9PdmVybGF5PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2NvbWFuZGFzL09wZW5Db21hbmRhRGlhbG9nLnRzeCJ9