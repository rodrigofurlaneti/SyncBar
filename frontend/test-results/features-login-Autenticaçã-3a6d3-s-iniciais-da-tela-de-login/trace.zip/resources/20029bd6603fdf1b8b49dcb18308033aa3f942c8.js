import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/WaiterHeader.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useThemeStore } from "/src/stores/themeStore.ts";
import { firstNameFrom, initialsFrom } from "/src/features/waiter/utils.ts";
export function WaiterHeader({ userName, readyItemsCount, onBellClick }) {
  _s();
  const { theme, toggleTheme } = useThemeStore();
  return /* @__PURE__ */ jsxDEV("header", { className: "waiter-header", children: /* @__PURE__ */ jsxDEV("div", { className: "waiter-header-top", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "waiter-avatar", "aria-hidden": "true", children: initialsFrom(userName) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
      lineNumber: 35,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "waiter-greeting", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "waiter-greeting-hello", children: [
        "Olá, ",
        firstNameFrom(userName),
        " 👋"
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
        lineNumber: 37,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "waiter-online-chip", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "waiter-online-dot" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
          lineNumber: 39,
          columnNumber: 25
        }, this),
        " Garçom Online"
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
        lineNumber: 38,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
      lineNumber: 36,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "waiter-spacer" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
      lineNumber: 42,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "button", className: "waiter-icon-btn", onClick: toggleTheme, children: theme === "dark" ? "☀" : "🌙" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
      lineNumber: 43,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "button", className: "waiter-icon-btn waiter-bell", onClick: onBellClick, children: [
      "🔔",
      readyItemsCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "waiter-bell-badge", children: readyItemsCount }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
        lineNumber: 48,
        columnNumber: 45
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
      lineNumber: 46,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
    lineNumber: 34,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx",
    lineNumber: 33,
    columnNumber: 5
  }, this);
}
_s(WaiterHeader, "5OFuo0o4IK2hN8Z0pM8WRN1qXJc=", false, function() {
  return [useThemeStore];
});
_c = WaiterHeader;
var _c;
$RefreshReg$(_c, "WaiterHeader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/WaiterHeader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZWdCOzs7Ozs7Ozs7Ozs7Ozs7OztBQWZmLFNBQVNBLHFCQUFxQjtBQUMvQixTQUFTQyxlQUFlQyxvQkFBb0I7QUFRckMsZ0JBQVNDLGFBQWEsRUFBRUMsVUFBVUMsaUJBQWlCQyxZQUErQixHQUFHO0FBQUFDLEtBQUE7QUFDeEYsUUFBTSxFQUFFQyxPQUFPQyxZQUFZLElBQUlULGNBQWM7QUFFN0MsU0FDSSx1QkFBQyxZQUFPLFdBQVUsaUJBQ2QsaUNBQUMsU0FBSSxXQUFVLHFCQUNYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlCQUFnQixlQUFZLFFBQVFFLHVCQUFhRSxRQUFRLEtBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEU7QUFBQSxJQUMxRSx1QkFBQyxTQUFJLFdBQVUsbUJBQ1g7QUFBQSw2QkFBQyxVQUFLLFdBQVUseUJBQXdCO0FBQUE7QUFBQSxRQUFNSCxjQUFjRyxRQUFRO0FBQUEsUUFBRTtBQUFBLFdBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUN6RSx1QkFBQyxVQUFLLFdBQVUsc0JBQ1o7QUFBQSwrQkFBQyxVQUFLLFdBQVUsdUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxRQUFHO0FBQUEsV0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLFVBQUssV0FBVSxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQjtBQUFBLElBQy9CLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsbUJBQWtCLFNBQVNLLGFBQ3RERCxvQkFBVSxTQUFTLE1BQU0sUUFEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLCtCQUE4QixTQUFTRixhQUFhO0FBQUE7QUFBQSxNQUUvRUQsa0JBQWtCLEtBQUssdUJBQUMsVUFBSyxXQUFVLHFCQUFxQkEsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxTQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkEsS0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVSO0FBQUNFLEdBeEJlSixjQUFZO0FBQUEsVUFDT0gsYUFBYTtBQUFBO0FBQUEsS0FEaENHO0FBQVksSUFBQU87QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlVGhlbWVTdG9yZSIsImZpcnN0TmFtZUZyb20iLCJpbml0aWFsc0Zyb20iLCJXYWl0ZXJIZWFkZXIiLCJ1c2VyTmFtZSIsInJlYWR5SXRlbXNDb3VudCIsIm9uQmVsbENsaWNrIiwiX3MiLCJ0aGVtZSIsInRvZ2dsZVRoZW1lIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiV2FpdGVySGVhZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VUaGVtZVN0b3JlIH0gZnJvbSBcIi4uLy4uLy4uL3N0b3Jlcy90aGVtZVN0b3JlXCI7XHJcbmltcG9ydCB7IGZpcnN0TmFtZUZyb20sIGluaXRpYWxzRnJvbSB9IGZyb20gXCIuLi91dGlsc1wiO1xyXG5cclxuaW50ZXJmYWNlIFdhaXRlckhlYWRlclByb3BzIHtcclxuICAgIHVzZXJOYW1lOiBzdHJpbmcgfCBudWxsO1xyXG4gICAgcmVhZHlJdGVtc0NvdW50OiBudW1iZXI7XHJcbiAgICBvbkJlbGxDbGljazogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFdhaXRlckhlYWRlcih7IHVzZXJOYW1lLCByZWFkeUl0ZW1zQ291bnQsIG9uQmVsbENsaWNrIH06IFdhaXRlckhlYWRlclByb3BzKSB7XHJcbiAgICBjb25zdCB7IHRoZW1lLCB0b2dnbGVUaGVtZSB9ID0gdXNlVGhlbWVTdG9yZSgpO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJ3YWl0ZXItaGVhZGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2FpdGVyLWhlYWRlci10b3BcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2FpdGVyLWF2YXRhclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPntpbml0aWFsc0Zyb20odXNlck5hbWUpfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3YWl0ZXItZ3JlZXRpbmdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3YWl0ZXItZ3JlZXRpbmctaGVsbG9cIj5PbMOhLCB7Zmlyc3ROYW1lRnJvbSh1c2VyTmFtZSl9IPCfkYs8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLW9ubGluZS1jaGlwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIndhaXRlci1vbmxpbmUtZG90XCIgLz4gR2Fyw6dvbSBPbmxpbmVcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIndhaXRlci1zcGFjZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwid2FpdGVyLWljb24tYnRuXCIgb25DbGljaz17dG9nZ2xlVGhlbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHt0aGVtZSA9PT0gXCJkYXJrXCIgPyBcIuKYgFwiIDogXCLwn4yZXCJ9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cIndhaXRlci1pY29uLWJ0biB3YWl0ZXItYmVsbFwiIG9uQ2xpY2s9e29uQmVsbENsaWNrfT5cclxuICAgICAgICAgICAgICAgICAgICDwn5SUXHJcbiAgICAgICAgICAgICAgICAgICAge3JlYWR5SXRlbXNDb3VudCA+IDAgJiYgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLWJlbGwtYmFkZ2VcIj57cmVhZHlJdGVtc0NvdW50fTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9oZWFkZXI+XHJcbiAgICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3dhaXRlci9jb21wb25lbnRzL1dhaXRlckhlYWRlci50c3gifQ==