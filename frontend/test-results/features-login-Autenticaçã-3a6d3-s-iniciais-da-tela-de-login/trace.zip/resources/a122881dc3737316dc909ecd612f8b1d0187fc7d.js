import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/tabs/TabPedidos.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { formatBRL } from "/src/lib/types.ts";
import { deriveOrderBadge, badgeToneVar, orderLabel, elapsedLabel } from "/src/features/waiter/utils.ts";
export function TabPedidos({ myOrders, tablesById, comandasById, onOrderClick }) {
  return /* @__PURE__ */ jsxDEV("section", { className: "waiter-section", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "waiter-section-title", style: { marginBottom: 16 }, children: "Histórico de Pedidos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
      lineNumber: 35,
      columnNumber: 13
    }, this),
    myOrders.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "waiter-empty", children: "Nenhum pedido registrado na sua praça no momento." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
      lineNumber: 38,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "waiter-order-list", children: myOrders.map((order) => {
      const badge = deriveOrderBadge(order);
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "waiter-order-row",
          onClick: () => onOrderClick(order.id),
          style: {
            // Utiliza --bg-elevated para adaptar a cor de fundo ao tema (escuro/claro)
            backgroundColor: "var(--bg-elevated, var(--surface, #ffffff))",
            borderRadius: "10px",
            padding: "14px",
            marginBottom: "10px",
            // Adapta a borda também usando --line
            border: "1px solid var(--line, var(--border, #e5e7eb))",
            width: "100%",
            textAlign: "left",
            cursor: "pointer",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center"
          },
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "waiter-order-info", style: { display: "grid", gap: "4px" }, children: [
              /* @__PURE__ */ jsxDEV("span", { className: "waiter-order-title", style: { fontWeight: "700", fontSize: "1.05rem", color: "var(--ink)" }, children: orderLabel(order, tablesById, comandasById) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
                lineNumber: 66,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "waiter-order-meta", style: { fontSize: "0.85rem", color: "var(--ink-dim)" }, children: [
                order.items.length,
                " ",
                order.items.length === 1 ? "item" : "itens",
                " · Total: ",
                /* @__PURE__ */ jsxDEV("strong", { children: formatBRL(order.totalAmount) }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
                  lineNumber: 70,
                  columnNumber: 117
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
                lineNumber: 69,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.75rem", color: "var(--ink-faint)" }, children: [
                "Aberto ",
                elapsedLabel(order.openedAt)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
                lineNumber: 72,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
              lineNumber: 65,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: "waiter-order-badge",
                style: {
                  "--w-badge": badgeToneVar[badge.tone],
                  backgroundColor: badge.tone === "ready" ? "#dcfce7" : badge.tone === "preparing" ? "#dbeafe" : "#fef3c7",
                  color: badge.tone === "ready" ? "#15803d" : badge.tone === "preparing" ? "#1d4ed8" : "#b45309",
                  padding: "4px 10px",
                  borderRadius: "20px",
                  fontSize: "0.75rem",
                  fontWeight: "700"
                },
                children: badge.label
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
                lineNumber: 77,
                columnNumber: 33
              },
              this
            )
          ]
        },
        order.id,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
          lineNumber: 44,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
      lineNumber: 40,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
}
_c = TabPedidos;
var _c;
$RefreshReg$(_c, "TabPedidos");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabPedidos.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkWixTQUFTQSxpQkFBaUI7QUFFMUIsU0FBU0Msa0JBQWtCQyxjQUFjQyxZQUFZQyxvQkFBb0I7QUFTbEUsZ0JBQVNDLFdBQVcsRUFBRUMsVUFBVUMsWUFBWUMsY0FBY0MsYUFBOEIsR0FBRztBQUM5RixTQUNJLHVCQUFDLGFBQVEsV0FBVSxrQkFDZjtBQUFBLDJCQUFDLFFBQUcsV0FBVSx3QkFBdUIsT0FBTyxFQUFFQyxjQUFjLEdBQUcsR0FBRyxvQ0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRjtBQUFBLElBRXJGSixTQUFTSyxXQUFXLElBQ2pCLHVCQUFDLE9BQUUsV0FBVSxnQkFBZSxpRUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RSxJQUU3RSx1QkFBQyxTQUFJLFdBQVUscUJBQ1ZMLG1CQUFTTSxJQUFJLENBQUNDLFVBQVU7QUFDckIsWUFBTUMsUUFBUWIsaUJBQWlCWSxLQUFLO0FBQ3BDLGFBQ0k7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVHLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTUosYUFBYUksTUFBTUUsRUFBRTtBQUFBLFVBQ3BDLE9BQU87QUFBQTtBQUFBLFlBRUhDLGlCQUFpQjtBQUFBLFlBQ2pCQyxjQUFjO0FBQUEsWUFDZEMsU0FBUztBQUFBLFlBQ1RSLGNBQWM7QUFBQTtBQUFBLFlBRWRTLFFBQVE7QUFBQSxZQUNSQyxPQUFPO0FBQUEsWUFDUEMsV0FBVztBQUFBLFlBQ1hDLFFBQVE7QUFBQSxZQUNSQyxTQUFTO0FBQUEsWUFDVEMsZ0JBQWdCO0FBQUEsWUFDaEJDLFlBQVk7QUFBQSxVQUNoQjtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxVQUFLLFdBQVUscUJBQW9CLE9BQU8sRUFBRUYsU0FBUyxRQUFRRyxLQUFLLE1BQU0sR0FDckU7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUMsWUFBWSxPQUFPQyxVQUFVLFdBQVdDLE9BQU8sYUFBYSxHQUNyRzFCLHFCQUFXVSxPQUFPTixZQUFZQyxZQUFZLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSxxQkFBb0IsT0FBTyxFQUFFb0IsVUFBVSxXQUFXQyxPQUFPLGlCQUFpQixHQUNyRmhCO0FBQUFBLHNCQUFNaUIsTUFBTW5CO0FBQUFBLGdCQUFPO0FBQUEsZ0JBQUVFLE1BQU1pQixNQUFNbkIsV0FBVyxJQUFJLFNBQVM7QUFBQSxnQkFBUTtBQUFBLGdCQUFVLHVCQUFDLFlBQVFYLG9CQUFVYSxNQUFNa0IsV0FBVyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLG1CQUR0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUgsVUFBVSxXQUFXQyxPQUFPLG1CQUFtQixHQUFHO0FBQUE7QUFBQSxnQkFDckR6QixhQUFhUyxNQUFNbUIsUUFBUTtBQUFBLG1CQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTztBQUFBLGtCQUNILGFBQWE5QixhQUFhWSxNQUFNbUIsSUFBSTtBQUFBLGtCQUNwQ2pCLGlCQUFpQkYsTUFBTW1CLFNBQVMsVUFBVSxZQUFZbkIsTUFBTW1CLFNBQVMsY0FBYyxZQUFZO0FBQUEsa0JBQy9GSixPQUFPZixNQUFNbUIsU0FBUyxVQUFVLFlBQVluQixNQUFNbUIsU0FBUyxjQUFjLFlBQVk7QUFBQSxrQkFDckZmLFNBQVM7QUFBQSxrQkFDVEQsY0FBYztBQUFBLGtCQUNkVyxVQUFVO0FBQUEsa0JBQ1ZELFlBQVk7QUFBQSxnQkFDaEI7QUFBQSxnQkFFQ2IsZ0JBQU1vQjtBQUFBQTtBQUFBQSxjQVpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWFBO0FBQUE7QUFBQTtBQUFBLFFBN0NLckIsTUFBTUU7QUFBQUEsUUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BK0NBO0FBQUEsSUFFUixDQUFDLEtBckRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzREE7QUFBQSxPQTVEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOERBO0FBRVI7QUFBQ29CLEtBbEVlOUI7QUFBVSxJQUFBOEI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiZm9ybWF0QlJMIiwiZGVyaXZlT3JkZXJCYWRnZSIsImJhZGdlVG9uZVZhciIsIm9yZGVyTGFiZWwiLCJlbGFwc2VkTGFiZWwiLCJUYWJQZWRpZG9zIiwibXlPcmRlcnMiLCJ0YWJsZXNCeUlkIiwiY29tYW5kYXNCeUlkIiwib25PcmRlckNsaWNrIiwibWFyZ2luQm90dG9tIiwibGVuZ3RoIiwibWFwIiwib3JkZXIiLCJiYWRnZSIsImlkIiwiYmFja2dyb3VuZENvbG9yIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsImJvcmRlciIsIndpZHRoIiwidGV4dEFsaWduIiwiY3Vyc29yIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImdhcCIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsImNvbG9yIiwiaXRlbXMiLCJ0b3RhbEFtb3VudCIsIm9wZW5lZEF0IiwidG9uZSIsImxhYmVsIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGFiUGVkaWRvcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHR5cGUgeyBDU1NQcm9wZXJ0aWVzIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IGZvcm1hdEJSTCB9IGZyb20gXCIuLi8uLi8uLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHR5cGUgeyBPcmRlclJlc3BvbnNlLCBUYWJsZVJlc3BvbnNlLCBDb21hbmRhUmVzcG9uc2UgfSBmcm9tIFwiLi4vLi4vLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB7IGRlcml2ZU9yZGVyQmFkZ2UsIGJhZGdlVG9uZVZhciwgb3JkZXJMYWJlbCwgZWxhcHNlZExhYmVsIH0gZnJvbSBcIi4uLy4uL3V0aWxzXCI7XHJcblxyXG5pbnRlcmZhY2UgVGFiUGVkaWRvc1Byb3BzIHtcclxuICAgIG15T3JkZXJzOiBPcmRlclJlc3BvbnNlW107XHJcbiAgICB0YWJsZXNCeUlkOiBNYXA8bnVtYmVyLCBUYWJsZVJlc3BvbnNlPjtcclxuICAgIGNvbWFuZGFzQnlJZDogTWFwPG51bWJlciwgQ29tYW5kYVJlc3BvbnNlPjtcclxuICAgIG9uT3JkZXJDbGljazogKG9yZGVySWQ6IG51bWJlcikgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFRhYlBlZGlkb3MoeyBteU9yZGVycywgdGFibGVzQnlJZCwgY29tYW5kYXNCeUlkLCBvbk9yZGVyQ2xpY2sgfTogVGFiUGVkaWRvc1Byb3BzKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIndhaXRlci1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ3YWl0ZXItc2VjdGlvbi10aXRsZVwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMTYgfX0+SGlzdMOzcmljbyBkZSBQZWRpZG9zPC9oMj5cclxuXHJcbiAgICAgICAgICAgIHtteU9yZGVycy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ3YWl0ZXItZW1wdHlcIj5OZW5odW0gcGVkaWRvIHJlZ2lzdHJhZG8gbmEgc3VhIHByYcOnYSBubyBtb21lbnRvLjwvcD5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2FpdGVyLW9yZGVyLWxpc3RcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bXlPcmRlcnMubWFwKChvcmRlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBiYWRnZSA9IGRlcml2ZU9yZGVyQmFkZ2Uob3JkZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17b3JkZXIuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwid2FpdGVyLW9yZGVyLXJvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcmRlckNsaWNrKG9yZGVyLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBVdGlsaXphIC0tYmctZWxldmF0ZWQgcGFyYSBhZGFwdGFyIGEgY29yIGRlIGZ1bmRvIGFvIHRlbWEgKGVzY3Vyby9jbGFybylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcInZhcigtLWJnLWVsZXZhdGVkLCB2YXIoLS1zdXJmYWNlLCAjZmZmZmZmKSlcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjEwcHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIxNHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogXCIxMHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFkYXB0YSBhIGJvcmRhIHRhbWLDqW0gdXNhbmRvIC0tbGluZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHZhcigtLWxpbmUsIHZhcigtLWJvcmRlciwgI2U1ZTdlYikpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dEFsaWduOiBcImxlZnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLW9yZGVyLWluZm9cIiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiBcIjRweFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3YWl0ZXItb3JkZXItdGl0bGVcIiBzdHlsZT17eyBmb250V2VpZ2h0OiBcIjcwMFwiLCBmb250U2l6ZTogXCIxLjA1cmVtXCIsIGNvbG9yOiBcInZhcigtLWluaylcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcmRlckxhYmVsKG9yZGVyLCB0YWJsZXNCeUlkLCBjb21hbmRhc0J5SWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIndhaXRlci1vcmRlci1tZXRhXCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMC44NXJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29yZGVyLml0ZW1zLmxlbmd0aH0ge29yZGVyLml0ZW1zLmxlbmd0aCA9PT0gMSA/IFwiaXRlbVwiIDogXCJpdGVuc1wifSDCtyBUb3RhbDogPHN0cm9uZz57Zm9ybWF0QlJMKG9yZGVyLnRvdGFsQW1vdW50KX08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjc1cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFiZXJ0byB7ZWxhcHNlZExhYmVsKG9yZGVyLm9wZW5lZEF0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwid2FpdGVyLW9yZGVyLWJhZGdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiLS13LWJhZGdlXCI6IGJhZGdlVG9uZVZhcltiYWRnZS50b25lXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogYmFkZ2UudG9uZSA9PT0gXCJyZWFkeVwiID8gXCIjZGNmY2U3XCIgOiBiYWRnZS50b25lID09PSBcInByZXBhcmluZ1wiID8gXCIjZGJlYWZlXCIgOiBcIiNmZWYzYzdcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBiYWRnZS50b25lID09PSBcInJlYWR5XCIgPyBcIiMxNTgwM2RcIiA6IGJhZGdlLnRvbmUgPT09IFwicHJlcGFyaW5nXCIgPyBcIiMxZDRlZDhcIiA6IFwiI2I0NTMwOVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCI0cHggMTBweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjIwcHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjAuNzVyZW1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IFwiNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBhcyBDU1NQcm9wZXJ0aWVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JhZGdlLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy93YWl0ZXIvY29tcG9uZW50cy90YWJzL1RhYlBlZGlkb3MudHN4In0=