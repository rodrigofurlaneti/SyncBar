import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Button.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Button.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const variantClass = {
  primary: "btn-primary",
  ghost: "btn-ghost",
  danger: "btn-danger"
};
export function Button({
  variant = "ghost",
  size = "md",
  loading = false,
  block = false,
  iconOnly = false,
  disabled,
  className = "",
  children,
  type = "button",
  ...rest
}) {
  const classes = [
    variantClass[variant],
    size === "sm" ? "btn-sm" : "",
    iconOnly ? "btn-icon" : "",
    block ? "btn-block" : "",
    loading ? "btn-loading" : "",
    className
  ].filter(Boolean).join(" ");
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type,
      className: classes,
      disabled: disabled || loading,
      "aria-busy": loading,
      ...rest,
      children
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Button.tsx",
      lineNumber: 70,
      columnNumber: 5
    },
    this
  );
}
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RJOzs7Ozs7Ozs7Ozs7Ozs7O0FBOUJKLE1BQU1BLGVBQXdDO0FBQUEsRUFDNUNDLFNBQVM7QUFBQSxFQUNUQyxPQUFPO0FBQUEsRUFDUEMsUUFBUTtBQUNWO0FBRU8sZ0JBQVNDLE9BQU87QUFBQSxFQUNyQkMsVUFBVTtBQUFBLEVBQ1ZDLE9BQU87QUFBQSxFQUNQQyxVQUFVO0FBQUEsRUFDVkMsUUFBUTtBQUFBLEVBQ1JDLFdBQVc7QUFBQSxFQUNYQztBQUFBQSxFQUNBQyxZQUFZO0FBQUEsRUFDWkM7QUFBQUEsRUFDQUMsT0FBTztBQUFBLEVBQ1AsR0FBR0M7QUFDUSxHQUFHO0FBQ2QsUUFBTUMsVUFBVTtBQUFBLElBQ2RmLGFBQWFLLE9BQU87QUFBQSxJQUNwQkMsU0FBUyxPQUFPLFdBQVc7QUFBQSxJQUMzQkcsV0FBVyxhQUFhO0FBQUEsSUFDeEJELFFBQVEsY0FBYztBQUFBLElBQ3RCRCxVQUFVLGdCQUFnQjtBQUFBLElBQzFCSTtBQUFBQSxFQUFTLEVBRVJLLE9BQU9DLE9BQU8sRUFDZEMsS0FBSyxHQUFHO0FBRVgsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdIO0FBQUFBLE1BQ1gsVUFBVUwsWUFBWUg7QUFBQUEsTUFDdEIsYUFBV0E7QUFBQUEsTUFDWCxHQUFJTztBQUFBQSxNQUVIRjtBQUFBQTtBQUFBQSxJQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFBO0FBRUo7QUFBQ08sS0FsQ2VmO0FBQU0sSUFBQWU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidmFyaWFudENsYXNzIiwicHJpbWFyeSIsImdob3N0IiwiZGFuZ2VyIiwiQnV0dG9uIiwidmFyaWFudCIsInNpemUiLCJsb2FkaW5nIiwiYmxvY2siLCJpY29uT25seSIsImRpc2FibGVkIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJ0eXBlIiwicmVzdCIsImNsYXNzZXMiLCJmaWx0ZXIiLCJCb29sZWFuIiwiam9pbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJ1dHRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBCdXR0b25IVE1MQXR0cmlidXRlcywgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG50eXBlIFZhcmlhbnQgPSBcInByaW1hcnlcIiB8IFwiZ2hvc3RcIiB8IFwiZGFuZ2VyXCI7XHJcbnR5cGUgU2l6ZSA9IFwibWRcIiB8IFwic21cIjtcclxuXHJcbmludGVyZmFjZSBCYXNlUHJvcHMgZXh0ZW5kcyBPbWl0PEJ1dHRvbkhUTUxBdHRyaWJ1dGVzPEhUTUxCdXR0b25FbGVtZW50PiwgXCJjbGFzc05hbWVcIj4ge1xyXG4gIHZhcmlhbnQ/OiBWYXJpYW50O1xyXG4gIHNpemU/OiBTaXplO1xyXG4gIGxvYWRpbmc/OiBib29sZWFuO1xyXG4gIGJsb2NrPzogYm9vbGVhbjtcclxuICBjbGFzc05hbWU/OiBzdHJpbmc7XHJcbn1cclxuXHJcbi8vIGljb25Pbmx5IGV4aWdlIGFyaWEtbGFiZWwg4oCUIGdhcmFudGlkbyBwZWxvIHRpcG8uXHJcbnR5cGUgSWNvblByb3BzID1cclxuICB8IHsgaWNvbk9ubHk6IHRydWU7IFwiYXJpYS1sYWJlbFwiOiBzdHJpbmc7IGNoaWxkcmVuOiBSZWFjdE5vZGUgfVxyXG4gIHwgeyBpY29uT25seT86IGZhbHNlOyBjaGlsZHJlbjogUmVhY3ROb2RlIH07XHJcblxyXG5leHBvcnQgdHlwZSBCdXR0b25Qcm9wcyA9IEJhc2VQcm9wcyAmIEljb25Qcm9wcztcclxuXHJcbmNvbnN0IHZhcmlhbnRDbGFzczogUmVjb3JkPFZhcmlhbnQsIHN0cmluZz4gPSB7XHJcbiAgcHJpbWFyeTogXCJidG4tcHJpbWFyeVwiLFxyXG4gIGdob3N0OiBcImJ0bi1naG9zdFwiLFxyXG4gIGRhbmdlcjogXCJidG4tZGFuZ2VyXCIsXHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQnV0dG9uKHtcclxuICB2YXJpYW50ID0gXCJnaG9zdFwiLFxyXG4gIHNpemUgPSBcIm1kXCIsXHJcbiAgbG9hZGluZyA9IGZhbHNlLFxyXG4gIGJsb2NrID0gZmFsc2UsXHJcbiAgaWNvbk9ubHkgPSBmYWxzZSxcclxuICBkaXNhYmxlZCxcclxuICBjbGFzc05hbWUgPSBcIlwiLFxyXG4gIGNoaWxkcmVuLFxyXG4gIHR5cGUgPSBcImJ1dHRvblwiLFxyXG4gIC4uLnJlc3RcclxufTogQnV0dG9uUHJvcHMpIHtcclxuICBjb25zdCBjbGFzc2VzID0gW1xyXG4gICAgdmFyaWFudENsYXNzW3ZhcmlhbnRdLFxyXG4gICAgc2l6ZSA9PT0gXCJzbVwiID8gXCJidG4tc21cIiA6IFwiXCIsXHJcbiAgICBpY29uT25seSA/IFwiYnRuLWljb25cIiA6IFwiXCIsXHJcbiAgICBibG9jayA/IFwiYnRuLWJsb2NrXCIgOiBcIlwiLFxyXG4gICAgbG9hZGluZyA/IFwiYnRuLWxvYWRpbmdcIiA6IFwiXCIsXHJcbiAgICBjbGFzc05hbWUsXHJcbiAgXVxyXG4gICAgLmZpbHRlcihCb29sZWFuKVxyXG4gICAgLmpvaW4oXCIgXCIpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGJ1dHRvblxyXG4gICAgICB0eXBlPXt0eXBlfVxyXG4gICAgICBjbGFzc05hbWU9e2NsYXNzZXN9XHJcbiAgICAgIGRpc2FibGVkPXtkaXNhYmxlZCB8fCBsb2FkaW5nfVxyXG4gICAgICBhcmlhLWJ1c3k9e2xvYWRpbmd9XHJcbiAgICAgIHsuLi5yZXN0fVxyXG4gICAgPlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L2J1dHRvbj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy91aS9CdXR0b24udHN4In0=