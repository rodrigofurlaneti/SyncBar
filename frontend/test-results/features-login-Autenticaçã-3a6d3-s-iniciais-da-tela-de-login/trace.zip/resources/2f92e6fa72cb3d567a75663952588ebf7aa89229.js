import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/OpenOrderDialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { openOrder } from "/src/features/orders/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { Overlay } from "/src/features/orders/Overlay.tsx";
export function OpenOrderDialog({ table, onClose, onOpened }) {
  _s();
  const { branchId, employeeId } = useAuthStore();
  const [guestCount, setGuestCount] = useState(2);
  const mutation = useMutation({
    mutationFn: () => openOrder({
      branchId,
      diningTableId: table.id,
      comandaId: null,
      employeeId: employeeId ?? 1,
      guestCount,
      notes: null
    }),
    onSuccess: (orderId) => onOpened(orderId)
  });
  return /* @__PURE__ */ jsxDEV(Overlay, { onClose, title: `Abrir mesa ${table.number}`, children: [
    /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Pessoas na mesa" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "number",
          min: 1,
          value: guestCount,
          onChange: (e) => setGuestCount(Number(e.target.value))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx",
          lineNumber: 55,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    mutation.isError && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: mutation.error instanceof ApiError ? mutation.error.message : "Falha ao abrir pedido." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx",
      lineNumber: 64,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          onClick: () => mutation.mutate(),
          disabled: mutation.isPending,
          children: mutation.isPending ? "Abrindo…" : "Abrir pedido"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx",
          lineNumber: 73,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx",
      lineNumber: 69,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s(OpenOrderDialog, "gDQQREdMOqzaXM4Xee3FfE7m9uo=", false, function() {
  return [useAuthStore, useMutation];
});
_c = OpenOrderDialog;
var _c;
$RefreshReg$(_c, "OpenOrderDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenOrderDialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQWxDUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLGVBQWU7QUFRakIsZ0JBQVNDLGdCQUFnQixFQUFFQyxPQUFPQyxTQUFTQyxTQUFnQixHQUFHO0FBQUFDLEtBQUE7QUFDbkUsUUFBTSxFQUFFQyxVQUFVQyxXQUFXLElBQUlULGFBQWE7QUFDOUMsUUFBTSxDQUFDVSxZQUFZQyxhQUFhLElBQUlkLFNBQWlCLENBQUM7QUFFdEQsUUFBTWUsV0FBV2QsWUFBWTtBQUFBLElBQzNCZSxZQUFZQSxNQUNWZCxVQUFVO0FBQUEsTUFDUlM7QUFBQUEsTUFDQU0sZUFBZVYsTUFBTVc7QUFBQUEsTUFDckJDLFdBQVc7QUFBQSxNQUNYUCxZQUFZQSxjQUFjO0FBQUEsTUFDMUJDO0FBQUFBLE1BQ0FPLE9BQU87QUFBQSxJQUNULENBQUM7QUFBQSxJQUNIQyxXQUFXQSxDQUFDQyxZQUFZYixTQUFTYSxPQUFPO0FBQUEsRUFDMUMsQ0FBQztBQUVELFNBQ0UsdUJBQUMsV0FBUSxTQUFrQixPQUFPLGNBQWNmLE1BQU1nQixNQUFNLElBQzFEO0FBQUEsMkJBQUMsV0FBTSxPQUFPLEVBQUVDLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsNkJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCQyxVQUFVLFNBQVMsR0FBRywrQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RTtBQUFBLE1BQzdFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxLQUFLO0FBQUEsVUFDTCxPQUFPZDtBQUFBQSxVQUNQLFVBQVUsQ0FBQ2UsTUFBTWQsY0FBY2UsT0FBT0QsRUFBRUUsT0FBT0MsS0FBSyxDQUFDO0FBQUE7QUFBQSxRQUp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJeUQ7QUFBQSxTQU4zRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUVDaEIsU0FBU2lCLFdBQ1IsdUJBQUMsT0FBRSxXQUFVLGNBQ1ZqQixtQkFBU2tCLGlCQUFpQjdCLFdBQVdXLFNBQVNrQixNQUFNQyxVQUFVLDRCQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdGLHVCQUFDLFNBQUksT0FBTyxFQUFFVixTQUFTLFFBQVFDLEtBQUssSUFBSVUsZ0JBQWdCLFdBQVcsR0FDakU7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGFBQVksU0FBUzNCLFNBQVMsc0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTU8sU0FBU3FCLE9BQU87QUFBQSxVQUMvQixVQUFVckIsU0FBU3NCO0FBQUFBLFVBRWxCdEIsbUJBQVNzQixZQUFZLGFBQWE7QUFBQTtBQUFBLFFBTnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEJBO0FBRUo7QUFBQzNCLEdBbERlSixpQkFBZTtBQUFBLFVBQ0lILGNBR2hCRixXQUFXO0FBQUE7QUFBQSxLQUpkSztBQUFlLElBQUFnQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwib3Blbk9yZGVyIiwidXNlQXV0aFN0b3JlIiwiQXBpRXJyb3IiLCJPdmVybGF5IiwiT3Blbk9yZGVyRGlhbG9nIiwidGFibGUiLCJvbkNsb3NlIiwib25PcGVuZWQiLCJfcyIsImJyYW5jaElkIiwiZW1wbG95ZWVJZCIsImd1ZXN0Q291bnQiLCJzZXRHdWVzdENvdW50IiwibXV0YXRpb24iLCJtdXRhdGlvbkZuIiwiZGluaW5nVGFibGVJZCIsImlkIiwiY29tYW5kYUlkIiwibm90ZXMiLCJvblN1Y2Nlc3MiLCJvcmRlcklkIiwibnVtYmVyIiwiZGlzcGxheSIsImdhcCIsImNvbG9yIiwiZm9udFNpemUiLCJlIiwiTnVtYmVyIiwidGFyZ2V0IiwidmFsdWUiLCJpc0Vycm9yIiwiZXJyb3IiLCJtZXNzYWdlIiwianVzdGlmeUNvbnRlbnQiLCJtdXRhdGUiLCJpc1BlbmRpbmciLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJPcGVuT3JkZXJEaWFsb2cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyBvcGVuT3JkZXIgfSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tIFwiLi4vLi4vbGliL2FwaUNsaWVudFwiO1xyXG5pbXBvcnQgdHlwZSB7IFRhYmxlUmVzcG9uc2UgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB7IE92ZXJsYXkgfSBmcm9tIFwiLi9PdmVybGF5XCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gIHRhYmxlOiBUYWJsZVJlc3BvbnNlO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25PcGVuZWQ6IChvcmRlcklkOiBudW1iZXIpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBPcGVuT3JkZXJEaWFsb2coeyB0YWJsZSwgb25DbG9zZSwgb25PcGVuZWQgfTogUHJvcHMpIHtcclxuICBjb25zdCB7IGJyYW5jaElkLCBlbXBsb3llZUlkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbZ3Vlc3RDb3VudCwgc2V0R3Vlc3RDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDIpO1xyXG5cclxuICBjb25zdCBtdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIG9wZW5PcmRlcih7XHJcbiAgICAgICAgYnJhbmNoSWQsXHJcbiAgICAgICAgZGluaW5nVGFibGVJZDogdGFibGUuaWQsXHJcbiAgICAgICAgY29tYW5kYUlkOiBudWxsLFxyXG4gICAgICAgIGVtcGxveWVlSWQ6IGVtcGxveWVlSWQgPz8gMSxcclxuICAgICAgICBndWVzdENvdW50LFxyXG4gICAgICAgIG5vdGVzOiBudWxsLFxyXG4gICAgICB9KSxcclxuICAgIG9uU3VjY2VzczogKG9yZGVySWQpID0+IG9uT3BlbmVkKG9yZGVySWQpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE92ZXJsYXkgb25DbG9zZT17b25DbG9zZX0gdGl0bGU9e2BBYnJpciBtZXNhICR7dGFibGUubnVtYmVyfWB9PlxyXG4gICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5QZXNzb2FzIG5hIG1lc2E8L3NwYW4+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgIG1pbj17MX1cclxuICAgICAgICAgIHZhbHVlPXtndWVzdENvdW50fVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRHdWVzdENvdW50KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICB7bXV0YXRpb24uaXNFcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPlxyXG4gICAgICAgICAge211dGF0aW9uLmVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBtdXRhdGlvbi5lcnJvci5tZXNzYWdlIDogXCJGYWxoYSBhbyBhYnJpciBwZWRpZG8uXCJ9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgIFZvbHRhclxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gbXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICBkaXNhYmxlZD17bXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHttdXRhdGlvbi5pc1BlbmRpbmcgPyBcIkFicmluZG/igKZcIiA6IFwiQWJyaXIgcGVkaWRvXCJ9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9PdmVybGF5PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL29yZGVycy9PcGVuT3JkZXJEaWFsb2cudHN4In0=