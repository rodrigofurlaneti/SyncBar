import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/stock/StockPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getStockByBranch, getStockLedger, registerStockMovement, setStockLimits } from "/src/features/stock/api.ts";
import { getMenu } from "/src/features/catalog/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import {
  manualStockMovementTypes,
  stockMovementIsInflow,
  stockMovementTypeLabel
} from "/src/lib/types.ts";
import { InventoryOverlay } from "/src/features/stock/InventoryOverlay.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { Button } from "/src/ui/Button.tsx";
import { TextField, SelectField } from "/src/ui/Field.tsx";
import { useToast } from "/src/ui/Toast.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
const parseNum = (raw) => {
  if (raw.trim() === "") return null;
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) ? value : null;
};
export function StockPage() {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { branchId, companyId, employeeId } = useAuthStore();
  const [movementOpen, setMovementOpen] = useState(false);
  const [inventoryOpen, setInventoryOpen] = useState(false);
  const [ledgerItem, setLedgerItem] = useState(null);
  const [limitsItem, setLimitsItem] = useState(null);
  const [productId, setProductId] = useState("");
  const [typeId, setTypeId] = useState(1);
  const [quantity, setQuantity] = useState("");
  const [unitCost, setUnitCost] = useState("");
  const [documentNumber, setDocumentNumber] = useState("");
  const [notes, setNotes] = useState("");
  const [minQ, setMinQ] = useState("");
  const [maxQ, setMaxQ] = useState("");
  const [error, setError] = useState(null);
  const stockQuery = useQuery({
    queryKey: ["stock", branchId],
    queryFn: () => getStockByBranch(branchId)
  });
  const menuQuery = useQuery({
    queryKey: ["menu", companyId],
    queryFn: () => getMenu(companyId ?? 1)
  });
  const ledgerQuery = useQuery({
    queryKey: ["stock", "ledger", ledgerItem?.id],
    queryFn: () => getStockLedger(ledgerItem.id),
    enabled: ledgerItem !== null
  });
  const productName = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const p of menuQuery.data ?? []) map.set(p.id, p.name);
    return map;
  }, [menuQuery.data]);
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["stock"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const movementMutation = useMutation({
    mutationFn: () => registerStockMovement({
      branchId,
      productId: Number(productId),
      stockMovementTypeId: typeId,
      employeeId: employeeId ?? 1,
      quantity: parseNum(quantity) ?? 0,
      unitCost: parseNum(unitCost),
      documentNumber: documentNumber.trim() === "" ? null : documentNumber.trim(),
      notes: notes.trim() === "" ? null : notes.trim()
    }),
    onSuccess: () => {
      setError(null);
      setMovementOpen(false);
      setQuantity("");
      setUnitCost("");
      setDocumentNumber("");
      setNotes("");
      refresh();
      toast.success("Movimento registrado.");
    },
    onError: onApiError
  });
  const limitsMutation = useMutation({
    mutationFn: () => setStockLimits(limitsItem.id, parseNum(minQ) ?? 0, parseNum(maxQ)),
    onSuccess: () => {
      setError(null);
      setLimitsItem(null);
      refresh();
      toast.success("Limites atualizados.");
    },
    onError: onApiError
  });
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto", position: "relative" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 16 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Estoque" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 128,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "saldo por produto · linhas em vermelho estão abaixo do mínimo" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 129,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 132,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", onClick: () => setInventoryOpen(true), children: "Inventário" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 133,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: () => {
        setError(null);
        setMovementOpen(true);
      }, children: "+ Lançar movimento" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 136,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
      lineNumber: 127,
      columnNumber: 13
    }, this),
    error && !movementOpen && limitsItem === null && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
      lineNumber: 141,
      columnNumber: 63
    }, this),
    stockQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: stockQuery.error, what: "o estoque" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
      lineNumber: 142,
      columnNumber: 36
    }, this),
    menuQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: menuQuery.error, what: "os produtos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
      lineNumber: 143,
      columnNumber: 35
    }, this),
    stockQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 6, rowHeight: 58 }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
      lineNumber: 145,
      columnNumber: 38
    }, this),
    !stockQuery.isLoading && stockQuery.data?.length === 0 && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: "📦",
        title: "Nenhum item de estoque",
        description: "Lance uma entrada (compra, ajuste ou inventário) para começar a controlar o saldo.",
        action: /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: () => {
          setError(null);
          setMovementOpen(true);
        }, children: "+ Lançar movimento" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 153,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 148,
        columnNumber: 7
      },
      this
    ),
    !stockQuery.isLoading && (stockQuery.data?.length ?? 0) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket rise rise-1", children: (stockQuery.data ?? []).map(
      (item) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: item.isBelowMinimum ? "var(--danger)" : "var(--ink)" }, children: productName.get(item.productId) ?? `Produto ${item.productId}` }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 165,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
            "mínimo ",
            item.minimumQuantity,
            item.maximumQuantity !== null ? ` · máximo ${item.maximumQuantity}` : ""
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 168,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 164,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: "mono-num display",
              style: { fontSize: "1.5rem", color: item.isBelowMinimum ? "var(--danger)" : "var(--amber)" },
              children: item.currentQuantity
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
              lineNumber: 173,
              columnNumber: 33
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost",
              style: { minHeight: 44, padding: "0 12px", fontSize: "0.85rem" },
              onClick: () => setLedgerItem(item),
              children: "Extrato"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
              lineNumber: 179,
              columnNumber: 33
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost",
              style: { minHeight: 44, padding: "0 12px", fontSize: "0.85rem" },
              onClick: () => {
                setError(null);
                setLimitsItem(item);
                setMinQ(String(item.minimumQuantity));
                setMaxQ(item.maximumQuantity === null ? "" : String(item.maximumQuantity));
              },
              children: "Limites"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
              lineNumber: 187,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 172,
          columnNumber: 29
        }, this)
      ] }, item.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 163,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
      lineNumber: 161,
      columnNumber: 7
    }, this),
    inventoryOpen && /* @__PURE__ */ jsxDEV(
      InventoryOverlay,
      {
        items: stockQuery.data ?? [],
        productName,
        onClose: () => setInventoryOpen(false),
        onDone: refresh
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 207,
        columnNumber: 7
      },
      this
    ),
    movementOpen && /* @__PURE__ */ jsxDEV(Modal, { title: "Lançar movimento", onClose: () => setMovementOpen(false), variant: "center", wide: true, children: [
      /* @__PURE__ */ jsxDEV(SelectField, { label: "Produto", value: productId, onChange: (e) => setProductId(e.target.value), autoFocus: true, children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione…" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 218,
          columnNumber: 25
        }, this),
        (menuQuery.data ?? []).map(
          (p) => /* @__PURE__ */ jsxDEV("option", { value: p.id, children: p.name }, p.id, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 220,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 217,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 200 }, children: /* @__PURE__ */ jsxDEV(SelectField, { label: "Tipo", value: typeId, onChange: (e) => setTypeId(Number(e.target.value)), children: manualStockMovementTypes.map(
          (id) => /* @__PURE__ */ jsxDEV("option", { value: id, children: [
            stockMovementTypeLabel[id],
            " ",
            stockMovementIsInflow[id] ? "(+)" : "(−)"
          ] }, id, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 228,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 226,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 225,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Quantidade",
            inputMode: "decimal",
            value: quantity,
            onChange: (e) => setQuantity(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 235,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 234,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 224,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Custo unit. (R$)",
            inputMode: "decimal",
            value: unitCost,
            onChange: (e) => setUnitCost(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 246,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 245,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Documento (NF)",
            value: documentNumber,
            onChange: (e) => setDocumentNumber(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 254,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 253,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 244,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Observações", value: notes, onChange: (e) => setNotes(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 262,
        columnNumber: 21
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 264,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          loading: movementMutation.isPending,
          disabled: productId === "" || (parseNum(quantity) ?? 0) <= 0,
          onClick: () => movementMutation.mutate(),
          children: "Registrar"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 266,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
      lineNumber: 216,
      columnNumber: 7
    }, this),
    ledgerItem !== null && /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: `Extrato — ${productName.get(ledgerItem.productId) ?? `produto ${ledgerItem.productId}`}`,
        onClose: () => setLedgerItem(null),
        variant: "center",
        wide: true,
        children: [
          ledgerQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 4, rowHeight: 48 }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 285,
            columnNumber: 47
          }, this),
          !ledgerQuery.isLoading && (ledgerQuery.data?.length ?? 0) === 0 && /* @__PURE__ */ jsxDEV(EmptyState, { icon: "🧾", title: "Sem movimentos", description: "Este produto ainda não teve entradas ou saídas registradas." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 287,
            columnNumber: 9
          }, this),
          !ledgerQuery.isLoading && (ledgerQuery.data?.length ?? 0) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { display: "grid", gap: 8 }, children: (ledgerQuery.data ?? []).map((movement) => {
            const inflow = stockMovementIsInflow[movement.stockMovementTypeId];
            return /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
                /* @__PURE__ */ jsxDEV("span", { children: stockMovementTypeLabel[movement.stockMovementTypeId] }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
                  lineNumber: 296,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
                  new Date(movement.movedAt).toLocaleString("pt-BR"),
                  movement.documentNumber ? ` · ${movement.documentNumber}` : "",
                  movement.notes ? ` · ${movement.notes}` : ""
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
                  lineNumber: 297,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
                lineNumber: 295,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: inflow ? "var(--ok)" : "var(--danger)" }, children: [
                inflow ? "+" : "−",
                movement.quantity
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
                lineNumber: 303,
                columnNumber: 41
              }, this)
            ] }, movement.id, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
              lineNumber: 294,
              columnNumber: 15
            }, this);
          }) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
            lineNumber: 290,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 279,
        columnNumber: 7
      },
      this
    ),
    limitsItem !== null && /* @__PURE__ */ jsxDEV(Modal, { title: "Limites de estoque", onClose: () => setLimitsItem(null), variant: "center", children: [
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Quantidade mínima",
          inputMode: "decimal",
          value: minQ,
          onChange: (e) => setMinQ(e.target.value),
          autoFocus: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 316,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Quantidade máxima (opcional)",
          inputMode: "decimal",
          value: maxQ,
          onChange: (e) => setMaxQ(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
          lineNumber: 323,
          columnNumber: 21
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 330,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", block: true, loading: limitsMutation.isPending, onClick: () => limitsMutation.mutate(), children: "Salvar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
        lineNumber: 332,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
      lineNumber: 315,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx",
    lineNumber: 126,
    columnNumber: 5
  }, this);
}
_s(StockPage, "+EPmcmEIO3UWfRo6kfNyI7ACWBA=", false, function() {
  return [useQueryClient, useToast, useAuthStore, useQuery, useQuery, useQuery, useMutation, useMutation];
});
_c = StockPage;
var _c;
$RefreshReg$(_c, "StockPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/StockPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEdnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1R2YsU0FBU0EsU0FBU0MsZ0JBQWdCO0FBQ25DLFNBQVNDLGFBQWFDLFVBQVVDLHNCQUFzQjtBQUN0RCxTQUFTQyxrQkFBa0JDLGdCQUFnQkMsdUJBQXVCQyxzQkFBc0I7QUFDeEYsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCO0FBQUEsRUFDSUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDRztBQUVQLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUU3QixNQUFNQyxXQUFXQSxDQUFDQyxRQUErQjtBQUM3QyxNQUFJQSxJQUFJQyxLQUFLLE1BQU0sR0FBSSxRQUFPO0FBQzlCLFFBQU1DLFFBQVFDLE9BQU9ILElBQUlJLFFBQVEsS0FBSyxHQUFHLENBQUM7QUFDMUMsU0FBT0QsT0FBT0UsU0FBU0gsS0FBSyxJQUFJQSxRQUFRO0FBQzVDO0FBRU8sZ0JBQVNJLFlBQVk7QUFBQUMsS0FBQTtBQUN4QixRQUFNQyxjQUFjN0IsZUFBZTtBQUNuQyxRQUFNOEIsUUFBUWIsU0FBUztBQUN2QixRQUFNLEVBQUVjLFVBQVVDLFdBQVdDLFdBQVcsSUFBSTNCLGFBQWE7QUFDekQsUUFBTSxDQUFDNEIsY0FBY0MsZUFBZSxJQUFJdEMsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ3VDLGVBQWVDLGdCQUFnQixJQUFJeEMsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3lDLFlBQVlDLGFBQWEsSUFBSTFDLFNBQW1DLElBQUk7QUFDM0UsUUFBTSxDQUFDMkMsWUFBWUMsYUFBYSxJQUFJNUMsU0FBbUMsSUFBSTtBQUMzRSxRQUFNLENBQUM2QyxXQUFXQyxZQUFZLElBQUk5QyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDK0MsUUFBUUMsU0FBUyxJQUFJaEQsU0FBaUIsQ0FBQztBQUM5QyxRQUFNLENBQUNpRCxVQUFVQyxXQUFXLElBQUlsRCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDbUQsVUFBVUMsV0FBVyxJQUFJcEQsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3FELGdCQUFnQkMsaUJBQWlCLElBQUl0RCxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDdUQsT0FBT0MsUUFBUSxJQUFJeEQsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3lELE1BQU1DLE9BQU8sSUFBSTFELFNBQVMsRUFBRTtBQUNuQyxRQUFNLENBQUMyRCxNQUFNQyxPQUFPLElBQUk1RCxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDNkQsT0FBT0MsUUFBUSxJQUFJOUQsU0FBd0IsSUFBSTtBQUV0RCxRQUFNK0QsYUFBYTdELFNBQVM7QUFBQSxJQUN4QjhELFVBQVUsQ0FBQyxTQUFTOUIsUUFBUTtBQUFBLElBQzVCK0IsU0FBU0EsTUFBTTdELGlCQUFpQjhCLFFBQVE7QUFBQSxFQUM1QyxDQUFDO0FBRUQsUUFBTWdDLFlBQVloRSxTQUFTO0FBQUEsSUFDdkI4RCxVQUFVLENBQUMsUUFBUTdCLFNBQVM7QUFBQSxJQUM1QjhCLFNBQVNBLE1BQU16RCxRQUFRMkIsYUFBYSxDQUFDO0FBQUEsRUFDekMsQ0FBQztBQUVELFFBQU1nQyxjQUFjakUsU0FBUztBQUFBLElBQ3pCOEQsVUFBVSxDQUFDLFNBQVMsVUFBVXZCLFlBQVkyQixFQUFFO0FBQUEsSUFDNUNILFNBQVNBLE1BQU01RCxlQUFlb0MsV0FBWTJCLEVBQUU7QUFBQSxJQUM1Q0MsU0FBUzVCLGVBQWU7QUFBQSxFQUM1QixDQUFDO0FBRUQsUUFBTTZCLGNBQWN2RSxRQUFRLE1BQU07QUFDOUIsVUFBTXdFLE1BQU0sb0JBQUlDLElBQW9CO0FBQ3BDLGVBQVdDLEtBQUtQLFVBQVVRLFFBQVEsR0FBSUgsS0FBSUksSUFBSUYsRUFBRUwsSUFBSUssRUFBRUcsSUFBSTtBQUMxRCxXQUFPTDtBQUFBQSxFQUNYLEdBQUcsQ0FBQ0wsVUFBVVEsSUFBSSxDQUFDO0FBRW5CLFFBQU1HLFVBQVVBLE1BQU0sS0FBSzdDLFlBQVk4QyxrQkFBa0IsRUFBRWQsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBRWhGLFFBQU1lLGFBQWFBLENBQUNDLE1BQ2hCbEIsU0FBU2tCLGFBQWF0RSxXQUFXc0UsRUFBRUMsVUFBVSxrQkFBa0I7QUFFbkUsUUFBTUMsbUJBQW1CakYsWUFBWTtBQUFBLElBQ2pDa0YsWUFBWUEsTUFDUjdFLHNCQUFzQjtBQUFBLE1BQ2xCNEI7QUFBQUEsTUFDQVcsV0FBV2xCLE9BQU9rQixTQUFTO0FBQUEsTUFDM0J1QyxxQkFBcUJyQztBQUFBQSxNQUNyQlgsWUFBWUEsY0FBYztBQUFBLE1BQzFCYSxVQUFVMUIsU0FBUzBCLFFBQVEsS0FBSztBQUFBLE1BQ2hDRSxVQUFVNUIsU0FBUzRCLFFBQVE7QUFBQSxNQUMzQkUsZ0JBQWdCQSxlQUFlNUIsS0FBSyxNQUFNLEtBQUssT0FBTzRCLGVBQWU1QixLQUFLO0FBQUEsTUFDMUU4QixPQUFPQSxNQUFNOUIsS0FBSyxNQUFNLEtBQUssT0FBTzhCLE1BQU05QixLQUFLO0FBQUEsSUFDbkQsQ0FBQztBQUFBLElBQ0w0RCxXQUFXQSxNQUFNO0FBQ2J2QixlQUFTLElBQUk7QUFDYnhCLHNCQUFnQixLQUFLO0FBQ3JCWSxrQkFBWSxFQUFFO0FBQUdFLGtCQUFZLEVBQUU7QUFBR0Usd0JBQWtCLEVBQUU7QUFBR0UsZUFBUyxFQUFFO0FBQ3BFcUIsY0FBUTtBQUNSNUMsWUFBTXFELFFBQVEsdUJBQXVCO0FBQUEsSUFDekM7QUFBQSxJQUNBQyxTQUFTUjtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNUyxpQkFBaUJ2RixZQUFZO0FBQUEsSUFDL0JrRixZQUFZQSxNQUFNNUUsZUFBZW9DLFdBQVl5QixJQUFJN0MsU0FBU2tDLElBQUksS0FBSyxHQUFHbEMsU0FBU29DLElBQUksQ0FBQztBQUFBLElBQ3BGMEIsV0FBV0EsTUFBTTtBQUNidkIsZUFBUyxJQUFJO0FBQ2JsQixvQkFBYyxJQUFJO0FBQ2xCaUMsY0FBUTtBQUNSNUMsWUFBTXFELFFBQVEsc0JBQXNCO0FBQUEsSUFDeEM7QUFBQSxJQUNBQyxTQUFTUjtBQUFBQSxFQUNiLENBQUM7QUFFRCxTQUNJLHVCQUFDLFVBQUssT0FBTyxFQUFFVSxTQUFTLElBQUlDLFVBQVUsTUFBTUMsUUFBUSxVQUFVQyxVQUFVLFdBQVcsR0FDL0U7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVDLFNBQVMsUUFBUUMsWUFBWSxZQUFZQyxLQUFLLElBQUlDLGNBQWMsR0FBRyxHQUM5RjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxTQUFTLEdBQUcsdUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEQ7QUFBQSxNQUM5RCx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxvQkFBb0JELFVBQVUsU0FBUyxHQUFHLDZFQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFRSxNQUFNLEVBQUUsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsYUFBWSxTQUFTLE1BQU0zRCxpQkFBaUIsSUFBSSxHQUFHLDBCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsZUFBYyxTQUFTLE1BQU07QUFBRXNCLGlCQUFTLElBQUk7QUFBR3hCLHdCQUFnQixJQUFJO0FBQUEsTUFBRyxHQUFHLGtDQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBRUN1QixTQUFTLENBQUN4QixnQkFBZ0JNLGVBQWUsUUFBUSx1QkFBQyxPQUFFLFdBQVUsY0FBY2tCLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDbEZFLFdBQVdxQyxXQUFXLHVCQUFDLGNBQVcsT0FBT3JDLFdBQVdGLE9BQU8sTUFBSyxlQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFEO0FBQUEsSUFDM0VLLFVBQVVrQyxXQUFXLHVCQUFDLGNBQVcsT0FBT2xDLFVBQVVMLE9BQU8sTUFBSyxpQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLElBRTNFRSxXQUFXc0MsYUFBYSx1QkFBQyxnQkFBYSxNQUFNLEdBQUcsV0FBVyxNQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFFN0QsQ0FBQ3RDLFdBQVdzQyxhQUFhdEMsV0FBV1csTUFBTTRCLFdBQVcsS0FDbEQ7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQUs7QUFBQSxRQUNMLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLFFBQ0ksdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxlQUFjLFNBQVMsTUFBTTtBQUFFeEMsbUJBQVMsSUFBSTtBQUFHeEIsMEJBQWdCLElBQUk7QUFBQSxRQUFHLEdBQUcsa0NBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUFQUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRSztBQUFBLElBSVIsQ0FBQ3lCLFdBQVdzQyxjQUFjdEMsV0FBV1csTUFBTTRCLFVBQVUsS0FBSyxLQUN2RCx1QkFBQyxTQUFJLFdBQVUsc0JBQ1R2QyxzQkFBV1csUUFBUSxJQUFJSDtBQUFBQSxNQUFJLENBQUNnQyxTQUMxQix1QkFBQyxTQUFJLFdBQVUsY0FDWDtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFVixTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUNsQztBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFRyxPQUFPSyxLQUFLQyxpQkFBaUIsa0JBQWtCLGFBQWEsR0FDdEVsQyxzQkFBWW1DLElBQUlGLEtBQUsxRCxTQUFTLEtBQUssV0FBVzBELEtBQUsxRCxTQUFTLE1BRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFb0QsVUFBVSxVQUFVQyxPQUFPLG1CQUFtQixHQUFHO0FBQUE7QUFBQSxZQUNwREssS0FBS0c7QUFBQUEsWUFBaUJILEtBQUtJLG9CQUFvQixPQUFPLGFBQWFKLEtBQUtJLGVBQWUsS0FBSztBQUFBLGVBRHhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVkLFNBQVMsUUFBUUUsS0FBSyxHQUFHRCxZQUFZLFNBQVMsR0FDeEQ7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFRyxVQUFVLFVBQVVDLE9BQU9LLEtBQUtDLGlCQUFpQixrQkFBa0IsZUFBZTtBQUFBLGNBRTFGRCxlQUFLSztBQUFBQTtBQUFBQSxZQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFQyxXQUFXLElBQUlwQixTQUFTLFVBQVVRLFVBQVUsVUFBVTtBQUFBLGNBQy9ELFNBQVMsTUFBTXZELGNBQWM2RCxJQUFJO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixPQUFPLEVBQUVNLFdBQVcsSUFBSXBCLFNBQVMsVUFBVVEsVUFBVSxVQUFVO0FBQUEsY0FDL0QsU0FBUyxNQUFNO0FBQ1huQyx5QkFBUyxJQUFJO0FBQ2JsQiw4QkFBYzJELElBQUk7QUFDbEI3Qyx3QkFBUW9ELE9BQU9QLEtBQUtHLGVBQWUsQ0FBQztBQUNwQzlDLHdCQUFRMkMsS0FBS0ksb0JBQW9CLE9BQU8sS0FBS0csT0FBT1AsS0FBS0ksZUFBZSxDQUFDO0FBQUEsY0FDN0U7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQVROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBO0FBQUEsYUEzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRCQTtBQUFBLFdBckM2QkosS0FBS25DLElBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxJQUNILEtBekNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQ0E7QUFBQSxJQUdIN0IsaUJBQ0c7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE9BQU93QixXQUFXVyxRQUFRO0FBQUEsUUFDMUI7QUFBQSxRQUNBLFNBQVMsTUFBTWxDLGlCQUFpQixLQUFLO0FBQUEsUUFDckMsUUFBUXFDO0FBQUFBO0FBQUFBLE1BSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSW9CO0FBQUEsSUFJdkJ4QyxnQkFDRyx1QkFBQyxTQUFNLE9BQU0sb0JBQW1CLFNBQVMsTUFBTUMsZ0JBQWdCLEtBQUssR0FBRyxTQUFRLFVBQVMsTUFBSSxNQUN4RjtBQUFBLDZCQUFDLGVBQVksT0FBTSxXQUFVLE9BQU9PLFdBQVcsVUFBVSxDQUFDbUMsTUFBTWxDLGFBQWFrQyxFQUFFK0IsT0FBT3JGLEtBQUssR0FBRyxXQUFTLE1BQ25HO0FBQUEsK0JBQUMsWUFBTyxPQUFNLElBQUcsMEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxTQUN6QndDLFVBQVVRLFFBQVEsSUFBSUg7QUFBQUEsVUFBSSxDQUFDRSxNQUN6Qix1QkFBQyxZQUFrQixPQUFPQSxFQUFFTCxJQUFLSyxZQUFFRyxRQUF0QkgsRUFBRUwsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QztBQUFBLFFBQzNDO0FBQUEsV0FKTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFK0IsTUFBTSxHQUFHYSxVQUFVLElBQUksR0FDakMsaUNBQUMsZUFBWSxPQUFNLFFBQU8sT0FBT2pFLFFBQVEsVUFBVSxDQUFDaUMsTUFBTWhDLFVBQVVyQixPQUFPcUQsRUFBRStCLE9BQU9yRixLQUFLLENBQUMsR0FDckZmLG1DQUF5QjREO0FBQUFBLFVBQUksQ0FBQ0gsT0FDM0IsdUJBQUMsWUFBZ0IsT0FBT0EsSUFDbkJ2RDtBQUFBQSxtQ0FBdUJ1RCxFQUFFO0FBQUEsWUFBRTtBQUFBLFlBQUV4RCxzQkFBc0J3RCxFQUFFLElBQUksUUFBUTtBQUFBLGVBRHpEQSxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUNILEtBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRStCLE1BQU0sR0FBR2EsVUFBVSxJQUFJLEdBQ2pDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxPQUFNO0FBQUEsWUFDTixXQUFVO0FBQUEsWUFDVixPQUFPL0Q7QUFBQUEsWUFDUCxVQUFVLENBQUMrQixNQUFNOUIsWUFBWThCLEVBQUUrQixPQUFPckYsS0FBSztBQUFBO0FBQUEsVUFKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWlELEtBTHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFeUUsTUFBTSxHQUFHYSxVQUFVLElBQUksR0FDakM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE9BQU07QUFBQSxZQUNOLFdBQVU7QUFBQSxZQUNWLE9BQU83RDtBQUFBQSxZQUNQLFVBQVUsQ0FBQzZCLE1BQU01QixZQUFZNEIsRUFBRStCLE9BQU9yRixLQUFLO0FBQUE7QUFBQSxVQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJaUQsS0FMckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXlFLE1BQU0sR0FBR2EsVUFBVSxJQUFJLEdBQ2pDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxPQUFNO0FBQUEsWUFDTixPQUFPM0Q7QUFBQUEsWUFDUCxVQUFVLENBQUMyQixNQUFNMUIsa0JBQWtCMEIsRUFBRStCLE9BQU9yRixLQUFLO0FBQUE7QUFBQSxVQUhyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHdUQsS0FKM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsV0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFFQSx1QkFBQyxhQUFVLE9BQU0sZUFBYyxPQUFPNkIsT0FBTyxVQUFVLENBQUN5QixNQUFNeEIsU0FBU3dCLEVBQUUrQixPQUFPckYsS0FBSyxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVGO0FBQUEsTUFFdEZtQyxTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BRTNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxTQUFRO0FBQUEsVUFDUjtBQUFBLFVBQ0EsU0FBU3FCLGlCQUFpQitCO0FBQUFBLFVBQzFCLFVBQVVwRSxjQUFjLE9BQU90QixTQUFTMEIsUUFBUSxLQUFLLE1BQU07QUFBQSxVQUMzRCxTQUFTLE1BQU1pQyxpQkFBaUJnQyxPQUFPO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFMN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxTQTFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkRBO0FBQUEsSUFHSHpFLGVBQWUsUUFDWjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csT0FBTyxhQUFhNkIsWUFBWW1DLElBQUloRSxXQUFXSSxTQUFTLEtBQUssV0FBV0osV0FBV0ksU0FBUyxFQUFFO0FBQUEsUUFDOUYsU0FBUyxNQUFNSCxjQUFjLElBQUk7QUFBQSxRQUNqQyxTQUFRO0FBQUEsUUFDUixNQUFJO0FBQUEsUUFFSHlCO0FBQUFBLHNCQUFZa0MsYUFBYSx1QkFBQyxnQkFBYSxNQUFNLEdBQUcsV0FBVyxNQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBLFVBQzlELENBQUNsQyxZQUFZa0MsY0FBY2xDLFlBQVlPLE1BQU00QixVQUFVLE9BQU8sS0FDM0QsdUJBQUMsY0FBVyxNQUFLLE1BQUssT0FBTSxrQkFBaUIsYUFBWSxpRUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0g7QUFBQSxVQUV6SCxDQUFDbkMsWUFBWWtDLGNBQWNsQyxZQUFZTyxNQUFNNEIsVUFBVSxLQUFLLEtBQ3pELHVCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRVQsU0FBUyxRQUFRRSxLQUFLLEVBQUUsR0FDbkQ1Qix1QkFBWU8sUUFBUSxJQUFJSCxJQUFJLENBQUM0QyxhQUFhO0FBQ3hDLGtCQUFNQyxTQUFTeEcsc0JBQXNCdUcsU0FBUy9CLG1CQUFtQjtBQUNqRSxtQkFDSSx1QkFBQyxTQUFJLFdBQVUsY0FDWDtBQUFBLHFDQUFDLFNBQUksT0FBTyxFQUFFUyxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUNsQztBQUFBLHVDQUFDLFVBQU1sRixpQ0FBdUJzRyxTQUFTL0IsbUJBQW1CLEtBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTREO0FBQUEsZ0JBQzVELHVCQUFDLFVBQUssT0FBTyxFQUFFYSxVQUFVLFVBQVVDLE9BQU8sbUJBQW1CLEdBQ3hEO0FBQUEsc0JBQUltQixLQUFLRixTQUFTRyxPQUFPLEVBQUVDLGVBQWUsT0FBTztBQUFBLGtCQUNqREosU0FBUzlELGlCQUFpQixNQUFNOEQsU0FBUzlELGNBQWMsS0FBSztBQUFBLGtCQUM1RDhELFNBQVM1RCxRQUFRLE1BQU00RCxTQUFTNUQsS0FBSyxLQUFLO0FBQUEscUJBSC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsWUFBVyxPQUFPLEVBQUUyQyxPQUFPa0IsU0FBUyxjQUFjLGdCQUFnQixHQUM3RUE7QUFBQUEseUJBQVMsTUFBTTtBQUFBLGdCQUFLRCxTQUFTbEU7QUFBQUEsbUJBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFYNkJrRSxTQUFTL0MsSUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFVBRVIsQ0FBQyxLQWxCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBO0FBQUE7QUFBQSxNQTlCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnQ0E7QUFBQSxJQUdIekIsZUFBZSxRQUNaLHVCQUFDLFNBQU0sT0FBTSxzQkFBcUIsU0FBUyxNQUFNQyxjQUFjLElBQUksR0FBRyxTQUFRLFVBQzFFO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE9BQU07QUFBQSxVQUNOLFdBQVU7QUFBQSxVQUNWLE9BQU9hO0FBQUFBLFVBQ1AsVUFBVSxDQUFDdUIsTUFBTXRCLFFBQVFzQixFQUFFK0IsT0FBT3JGLEtBQUs7QUFBQSxVQUN2QyxXQUFTO0FBQUE7QUFBQSxRQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUthO0FBQUEsTUFFYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csT0FBTTtBQUFBLFVBQ04sV0FBVTtBQUFBLFVBQ1YsT0FBT2lDO0FBQUFBLFVBQ1AsVUFBVSxDQUFDcUIsTUFBTXBCLFFBQVFvQixFQUFFK0IsT0FBT3JGLEtBQUs7QUFBQTtBQUFBLFFBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUk2QztBQUFBLE1BRzVDbUMsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUUzQyx1QkFBQyxVQUFPLFNBQVEsV0FBVSxPQUFLLE1BQUMsU0FBUzJCLGVBQWV5QixXQUFXLFNBQVMsTUFBTXpCLGVBQWUwQixPQUFPLEdBQUcsc0JBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxPQWpOUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbU5BO0FBRVI7QUFBQ25GLEdBcFNlRCxXQUFTO0FBQUEsVUFDRDNCLGdCQUNOaUIsVUFDOEJYLGNBZXpCUCxVQUtEQSxVQUtFQSxVQWlCS0QsYUFzQkZBLFdBQVc7QUFBQTtBQUFBLEtBbkV0QjZCO0FBQVMsSUFBQTBGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsImdldFN0b2NrQnlCcmFuY2giLCJnZXRTdG9ja0xlZGdlciIsInJlZ2lzdGVyU3RvY2tNb3ZlbWVudCIsInNldFN0b2NrTGltaXRzIiwiZ2V0TWVudSIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwibWFudWFsU3RvY2tNb3ZlbWVudFR5cGVzIiwic3RvY2tNb3ZlbWVudElzSW5mbG93Iiwic3RvY2tNb3ZlbWVudFR5cGVMYWJlbCIsIkludmVudG9yeU92ZXJsYXkiLCJRdWVyeUVycm9yIiwiTW9kYWwiLCJCdXR0b24iLCJUZXh0RmllbGQiLCJTZWxlY3RGaWVsZCIsInVzZVRvYXN0IiwiRW1wdHlTdGF0ZSIsIlNrZWxldG9uTGlzdCIsInBhcnNlTnVtIiwicmF3IiwidHJpbSIsInZhbHVlIiwiTnVtYmVyIiwicmVwbGFjZSIsImlzRmluaXRlIiwiU3RvY2tQYWdlIiwiX3MiLCJxdWVyeUNsaWVudCIsInRvYXN0IiwiYnJhbmNoSWQiLCJjb21wYW55SWQiLCJlbXBsb3llZUlkIiwibW92ZW1lbnRPcGVuIiwic2V0TW92ZW1lbnRPcGVuIiwiaW52ZW50b3J5T3BlbiIsInNldEludmVudG9yeU9wZW4iLCJsZWRnZXJJdGVtIiwic2V0TGVkZ2VySXRlbSIsImxpbWl0c0l0ZW0iLCJzZXRMaW1pdHNJdGVtIiwicHJvZHVjdElkIiwic2V0UHJvZHVjdElkIiwidHlwZUlkIiwic2V0VHlwZUlkIiwicXVhbnRpdHkiLCJzZXRRdWFudGl0eSIsInVuaXRDb3N0Iiwic2V0VW5pdENvc3QiLCJkb2N1bWVudE51bWJlciIsInNldERvY3VtZW50TnVtYmVyIiwibm90ZXMiLCJzZXROb3RlcyIsIm1pblEiLCJzZXRNaW5RIiwibWF4USIsInNldE1heFEiLCJlcnJvciIsInNldEVycm9yIiwic3RvY2tRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsIm1lbnVRdWVyeSIsImxlZGdlclF1ZXJ5IiwiaWQiLCJlbmFibGVkIiwicHJvZHVjdE5hbWUiLCJtYXAiLCJNYXAiLCJwIiwiZGF0YSIsInNldCIsIm5hbWUiLCJyZWZyZXNoIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJvbkFwaUVycm9yIiwiZSIsIm1lc3NhZ2UiLCJtb3ZlbWVudE11dGF0aW9uIiwibXV0YXRpb25GbiIsInN0b2NrTW92ZW1lbnRUeXBlSWQiLCJvblN1Y2Nlc3MiLCJzdWNjZXNzIiwib25FcnJvciIsImxpbWl0c011dGF0aW9uIiwicGFkZGluZyIsIm1heFdpZHRoIiwibWFyZ2luIiwicG9zaXRpb24iLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsIm1hcmdpbkJvdHRvbSIsImZvbnRTaXplIiwiY29sb3IiLCJmbGV4IiwiaXNFcnJvciIsImlzTG9hZGluZyIsImxlbmd0aCIsIml0ZW0iLCJpc0JlbG93TWluaW11bSIsImdldCIsIm1pbmltdW1RdWFudGl0eSIsIm1heGltdW1RdWFudGl0eSIsImN1cnJlbnRRdWFudGl0eSIsIm1pbkhlaWdodCIsIlN0cmluZyIsInRhcmdldCIsIm1pbldpZHRoIiwiaXNQZW5kaW5nIiwibXV0YXRlIiwibW92ZW1lbnQiLCJpbmZsb3ciLCJEYXRlIiwibW92ZWRBdCIsInRvTG9jYWxlU3RyaW5nIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU3RvY2tQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyBnZXRTdG9ja0J5QnJhbmNoLCBnZXRTdG9ja0xlZGdlciwgcmVnaXN0ZXJTdG9ja01vdmVtZW50LCBzZXRTdG9ja0xpbWl0cyB9IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyBnZXRNZW51IH0gZnJvbSBcIi4uL2NhdGFsb2cvYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHtcclxuICAgIG1hbnVhbFN0b2NrTW92ZW1lbnRUeXBlcyxcclxuICAgIHN0b2NrTW92ZW1lbnRJc0luZmxvdyxcclxuICAgIHN0b2NrTW92ZW1lbnRUeXBlTGFiZWwsXHJcbn0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IFN0b2NrSXRlbVJlc3BvbnNlIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgeyBJbnZlbnRvcnlPdmVybGF5IH0gZnJvbSBcIi4vSW52ZW50b3J5T3ZlcmxheVwiO1xyXG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xyXG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gXCIuLi8uLi91aS9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IFRleHRGaWVsZCwgU2VsZWN0RmllbGQgfSBmcm9tIFwiLi4vLi4vdWkvRmllbGRcIjtcclxuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vLi4vdWkvVG9hc3RcIjtcclxuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCIuLi8uLi91aS9FbXB0eVN0YXRlXCI7XHJcbmltcG9ydCB7IFNrZWxldG9uTGlzdCB9IGZyb20gXCIuLi8uLi91aS9Ta2VsZXRvblwiO1xyXG5cclxuY29uc3QgcGFyc2VOdW0gPSAocmF3OiBzdHJpbmcpOiBudW1iZXIgfCBudWxsID0+IHtcclxuICAgIGlmIChyYXcudHJpbSgpID09PSBcIlwiKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IHZhbHVlID0gTnVtYmVyKHJhdy5yZXBsYWNlKFwiLFwiLCBcIi5cIikpO1xyXG4gICAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgPyB2YWx1ZSA6IG51bGw7XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RvY2tQYWdlKCkge1xyXG4gICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gICAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG4gICAgY29uc3QgeyBicmFuY2hJZCwgY29tcGFueUlkLCBlbXBsb3llZUlkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICAgIGNvbnN0IFttb3ZlbWVudE9wZW4sIHNldE1vdmVtZW50T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbaW52ZW50b3J5T3Blbiwgc2V0SW52ZW50b3J5T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbbGVkZ2VySXRlbSwgc2V0TGVkZ2VySXRlbV0gPSB1c2VTdGF0ZTxTdG9ja0l0ZW1SZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgW2xpbWl0c0l0ZW0sIHNldExpbWl0c0l0ZW1dID0gdXNlU3RhdGU8U3RvY2tJdGVtUmVzcG9uc2UgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFtwcm9kdWN0SWQsIHNldFByb2R1Y3RJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFt0eXBlSWQsIHNldFR5cGVJZF0gPSB1c2VTdGF0ZTxudW1iZXI+KDEpO1xyXG4gICAgY29uc3QgW3F1YW50aXR5LCBzZXRRdWFudGl0eV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFt1bml0Q29zdCwgc2V0VW5pdENvc3RdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbZG9jdW1lbnROdW1iZXIsIHNldERvY3VtZW50TnVtYmVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW25vdGVzLCBzZXROb3Rlc10gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFttaW5RLCBzZXRNaW5RXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW21heFEsIHNldE1heFFdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICAgIGNvbnN0IHN0b2NrUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcInN0b2NrXCIsIGJyYW5jaElkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRTdG9ja0J5QnJhbmNoKGJyYW5jaElkKSxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IG1lbnVRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgICAgICBxdWVyeUtleTogW1wibWVudVwiLCBjb21wYW55SWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldE1lbnUoY29tcGFueUlkID8/IDEpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgbGVkZ2VyUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcInN0b2NrXCIsIFwibGVkZ2VyXCIsIGxlZGdlckl0ZW0/LmlkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRTdG9ja0xlZGdlcihsZWRnZXJJdGVtIS5pZCksXHJcbiAgICAgICAgZW5hYmxlZDogbGVkZ2VySXRlbSAhPT0gbnVsbCxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHByb2R1Y3ROYW1lID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgbWFwID0gbmV3IE1hcDxudW1iZXIsIHN0cmluZz4oKTtcclxuICAgICAgICBmb3IgKGNvbnN0IHAgb2YgbWVudVF1ZXJ5LmRhdGEgPz8gW10pIG1hcC5zZXQocC5pZCwgcC5uYW1lKTtcclxuICAgICAgICByZXR1cm4gbWFwO1xyXG4gICAgfSwgW21lbnVRdWVyeS5kYXRhXSk7XHJcblxyXG4gICAgY29uc3QgcmVmcmVzaCA9ICgpID0+IHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wic3RvY2tcIl0gfSk7XHJcblxyXG4gICAgY29uc3Qgb25BcGlFcnJvciA9IChlOiB1bmtub3duKSA9PlxyXG4gICAgICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGUubWVzc2FnZSA6IFwiT3BlcmHDp8OjbyBmYWxob3UuXCIpO1xyXG5cclxuICAgIGNvbnN0IG1vdmVtZW50TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgICAgICAgcmVnaXN0ZXJTdG9ja01vdmVtZW50KHtcclxuICAgICAgICAgICAgICAgIGJyYW5jaElkLFxyXG4gICAgICAgICAgICAgICAgcHJvZHVjdElkOiBOdW1iZXIocHJvZHVjdElkKSxcclxuICAgICAgICAgICAgICAgIHN0b2NrTW92ZW1lbnRUeXBlSWQ6IHR5cGVJZCxcclxuICAgICAgICAgICAgICAgIGVtcGxveWVlSWQ6IGVtcGxveWVlSWQgPz8gMSxcclxuICAgICAgICAgICAgICAgIHF1YW50aXR5OiBwYXJzZU51bShxdWFudGl0eSkgPz8gMCxcclxuICAgICAgICAgICAgICAgIHVuaXRDb3N0OiBwYXJzZU51bSh1bml0Q29zdCksXHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudE51bWJlcjogZG9jdW1lbnROdW1iZXIudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IGRvY3VtZW50TnVtYmVyLnRyaW0oKSxcclxuICAgICAgICAgICAgICAgIG5vdGVzOiBub3Rlcy50cmltKCkgPT09IFwiXCIgPyBudWxsIDogbm90ZXMudHJpbSgpLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgICAgICAgIHNldE1vdmVtZW50T3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldFF1YW50aXR5KFwiXCIpOyBzZXRVbml0Q29zdChcIlwiKTsgc2V0RG9jdW1lbnROdW1iZXIoXCJcIik7IHNldE5vdGVzKFwiXCIpO1xyXG4gICAgICAgICAgICByZWZyZXNoKCk7XHJcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJNb3ZpbWVudG8gcmVnaXN0cmFkby5cIik7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgbGltaXRzTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKCkgPT4gc2V0U3RvY2tMaW1pdHMobGltaXRzSXRlbSEuaWQsIHBhcnNlTnVtKG1pblEpID8/IDAsIHBhcnNlTnVtKG1heFEpKSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgICAgICAgIHNldExpbWl0c0l0ZW0obnVsbCk7XHJcbiAgICAgICAgICAgIHJlZnJlc2goKTtcclxuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIkxpbWl0ZXMgYXR1YWxpemFkb3MuXCIpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMTAwLCBtYXJnaW46IFwiMCBhdXRvXCIsIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImJhc2VsaW5lXCIsIGdhcDogMTQsIG1hcmdpbkJvdHRvbTogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuN3JlbVwiIH19PkVzdG9xdWU8L2gyPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICBzYWxkbyBwb3IgcHJvZHV0byDCtyBsaW5oYXMgZW0gdmVybWVsaG8gZXN0w6NvIGFiYWl4byBkbyBtw61uaW1vXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRJbnZlbnRvcnlPcGVuKHRydWUpfT5cclxuICAgICAgICAgICAgICAgICAgICBJbnZlbnTDoXJpb1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RXJyb3IobnVsbCk7IHNldE1vdmVtZW50T3Blbih0cnVlKTsgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgKyBMYW7Dp2FyIG1vdmltZW50b1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge2Vycm9yICYmICFtb3ZlbWVudE9wZW4gJiYgbGltaXRzSXRlbSA9PT0gbnVsbCAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgICAgICAgIHtzdG9ja1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e3N0b2NrUXVlcnkuZXJyb3J9IHdoYXQ9XCJvIGVzdG9xdWVcIiAvPn1cclxuICAgICAgICAgICAge21lbnVRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXttZW51UXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBwcm9kdXRvc1wiIC8+fVxyXG5cclxuICAgICAgICAgICAge3N0b2NrUXVlcnkuaXNMb2FkaW5nICYmIDxTa2VsZXRvbkxpc3Qgcm93cz17Nn0gcm93SGVpZ2h0PXs1OH0gLz59XHJcblxyXG4gICAgICAgICAgICB7IXN0b2NrUXVlcnkuaXNMb2FkaW5nICYmIHN0b2NrUXVlcnkuZGF0YT8ubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbj1cIvCfk6ZcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTmVuaHVtIGl0ZW0gZGUgZXN0b3F1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb249XCJMYW5jZSB1bWEgZW50cmFkYSAoY29tcHJhLCBhanVzdGUgb3UgaW52ZW50w6FyaW8pIHBhcmEgY29tZcOnYXIgYSBjb250cm9sYXIgbyBzYWxkby5cIlxyXG4gICAgICAgICAgICAgICAgICAgIGFjdGlvbj17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgb25DbGljaz17KCkgPT4geyBzZXRFcnJvcihudWxsKTsgc2V0TW92ZW1lbnRPcGVuKHRydWUpOyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICsgTGFuw6dhciBtb3ZpbWVudG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHshc3RvY2tRdWVyeS5pc0xvYWRpbmcgJiYgKHN0b2NrUXVlcnkuZGF0YT8ubGVuZ3RoID8/IDApID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldCByaXNlIHJpc2UtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsoc3RvY2tRdWVyeS5kYXRhID8/IFtdKS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIga2V5PXtpdGVtLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogaXRlbS5pc0JlbG93TWluaW11bSA/IFwidmFyKC0tZGFuZ2VyKVwiIDogXCJ2YXIoLS1pbmspXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0TmFtZS5nZXQoaXRlbS5wcm9kdWN0SWQpID8/IGBQcm9kdXRvICR7aXRlbS5wcm9kdWN0SWR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbcOtbmltbyB7aXRlbS5taW5pbXVtUXVhbnRpdHl9e2l0ZW0ubWF4aW11bVF1YW50aXR5ICE9PSBudWxsID8gYCDCtyBtw6F4aW1vICR7aXRlbS5tYXhpbXVtUXVhbnRpdHl9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDgsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibW9uby1udW0gZGlzcGxheVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuNXJlbVwiLCBjb2xvcjogaXRlbS5pc0JlbG93TWluaW11bSA/IFwidmFyKC0tZGFuZ2VyKVwiIDogXCJ2YXIoLS1hbWJlcilcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY3VycmVudFF1YW50aXR5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTJweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TGVkZ2VySXRlbShpdGVtKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEV4dHJhdG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTJweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRMaW1pdHNJdGVtKGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TWluUShTdHJpbmcoaXRlbS5taW5pbXVtUXVhbnRpdHkpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE1heFEoaXRlbS5tYXhpbXVtUXVhbnRpdHkgPT09IG51bGwgPyBcIlwiIDogU3RyaW5nKGl0ZW0ubWF4aW11bVF1YW50aXR5KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMaW1pdGVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtpbnZlbnRvcnlPcGVuICYmIChcclxuICAgICAgICAgICAgICAgIDxJbnZlbnRvcnlPdmVybGF5XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbXM9e3N0b2NrUXVlcnkuZGF0YSA/PyBbXX1cclxuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0TmFtZT17cHJvZHVjdE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SW52ZW50b3J5T3BlbihmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25Eb25lPXtyZWZyZXNofVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHttb3ZlbWVudE9wZW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgPE1vZGFsIHRpdGxlPVwiTGFuw6dhciBtb3ZpbWVudG9cIiBvbkNsb3NlPXsoKSA9PiBzZXRNb3ZlbWVudE9wZW4oZmFsc2UpfSB2YXJpYW50PVwiY2VudGVyXCIgd2lkZT5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0RmllbGQgbGFiZWw9XCJQcm9kdXRvXCIgdmFsdWU9e3Byb2R1Y3RJZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRQcm9kdWN0SWQoZS50YXJnZXQudmFsdWUpfSBhdXRvRm9jdXM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2lvbmXigKY8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgeyhtZW51UXVlcnkuZGF0YSA/PyBbXSkubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17cC5pZH0gdmFsdWU9e3AuaWR9PntwLm5hbWV9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0RmllbGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDIwMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RGaWVsZCBsYWJlbD1cIlRpcG9cIiB2YWx1ZT17dHlwZUlkfSBvbkNoYW5nZT17KGUpID0+IHNldFR5cGVJZChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge21hbnVhbFN0b2NrTW92ZW1lbnRUeXBlcy5tYXAoKGlkKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtpZH0gdmFsdWU9e2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdG9ja01vdmVtZW50VHlwZUxhYmVsW2lkXX0ge3N0b2NrTW92ZW1lbnRJc0luZmxvd1tpZF0gPyBcIigrKVwiIDogXCIo4oiSKVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJRdWFudGlkYWRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cXVhbnRpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRRdWFudGl0eShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTYwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ3VzdG8gdW5pdC4gKFIkKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VuaXRDb3N0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VW5pdENvc3QoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkRvY3VtZW50byAoTkYpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZG9jdW1lbnROdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREb2N1bWVudE51bWJlcihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk9ic2VydmHDp8O1ZXNcIiB2YWx1ZT17bm90ZXN9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm90ZXMoZS50YXJnZXQudmFsdWUpfSAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17bW92ZW1lbnRNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwcm9kdWN0SWQgPT09IFwiXCIgfHwgKHBhcnNlTnVtKHF1YW50aXR5KSA/PyAwKSA8PSAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBtb3ZlbWVudE11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUmVnaXN0cmFyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge2xlZGdlckl0ZW0gIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2BFeHRyYXRvIOKAlCAke3Byb2R1Y3ROYW1lLmdldChsZWRnZXJJdGVtLnByb2R1Y3RJZCkgPz8gYHByb2R1dG8gJHtsZWRnZXJJdGVtLnByb2R1Y3RJZH1gfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TGVkZ2VySXRlbShudWxsKX1cclxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICB3aWRlXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2xlZGdlclF1ZXJ5LmlzTG9hZGluZyAmJiA8U2tlbGV0b25MaXN0IHJvd3M9ezR9IHJvd0hlaWdodD17NDh9IC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIHshbGVkZ2VyUXVlcnkuaXNMb2FkaW5nICYmIChsZWRnZXJRdWVyeS5kYXRhPy5sZW5ndGggPz8gMCkgPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RW1wdHlTdGF0ZSBpY29uPVwi8J+nvlwiIHRpdGxlPVwiU2VtIG1vdmltZW50b3NcIiBkZXNjcmlwdGlvbj1cIkVzdGUgcHJvZHV0byBhaW5kYSBuw6NvIHRldmUgZW50cmFkYXMgb3Ugc2HDrWRhcyByZWdpc3RyYWRhcy5cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgeyFsZWRnZXJRdWVyeS5pc0xvYWRpbmcgJiYgKGxlZGdlclF1ZXJ5LmRhdGE/Lmxlbmd0aCA/PyAwKSA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGxlZGdlclF1ZXJ5LmRhdGEgPz8gW10pLm1hcCgobW92ZW1lbnQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpbmZsb3cgPSBzdG9ja01vdmVtZW50SXNJbmZsb3dbbW92ZW1lbnQuc3RvY2tNb3ZlbWVudFR5cGVJZF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIga2V5PXttb3ZlbWVudC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3N0b2NrTW92ZW1lbnRUeXBlTGFiZWxbbW92ZW1lbnQuc3RvY2tNb3ZlbWVudFR5cGVJZF19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShtb3ZlbWVudC5tb3ZlZEF0KS50b0xvY2FsZVN0cmluZyhcInB0LUJSXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bW92ZW1lbnQuZG9jdW1lbnROdW1iZXIgPyBgIMK3ICR7bW92ZW1lbnQuZG9jdW1lbnROdW1iZXJ9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttb3ZlbWVudC5ub3RlcyA/IGAgwrcgJHttb3ZlbWVudC5ub3Rlc31gIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCIgc3R5bGU9e3sgY29sb3I6IGluZmxvdyA/IFwidmFyKC0tb2spXCIgOiBcInZhcigtLWRhbmdlcilcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aW5mbG93ID8gXCIrXCIgOiBcIuKIklwifXttb3ZlbWVudC5xdWFudGl0eX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtsaW1pdHNJdGVtICE9PSBudWxsICYmIChcclxuICAgICAgICAgICAgICAgIDxNb2RhbCB0aXRsZT1cIkxpbWl0ZXMgZGUgZXN0b3F1ZVwiIG9uQ2xvc2U9eygpID0+IHNldExpbWl0c0l0ZW0obnVsbCl9IHZhcmlhbnQ9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUXVhbnRpZGFkZSBtw61uaW1hXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttaW5RfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1pblEoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJRdWFudGlkYWRlIG3DoXhpbWEgKG9wY2lvbmFsKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bWF4UX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNYXhRKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgYmxvY2sgbG9hZGluZz17bGltaXRzTXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBsaW1pdHNNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNhbHZhclxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8L21haW4+XHJcbiAgICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3N0b2NrL1N0b2NrUGFnZS50c3gifQ==