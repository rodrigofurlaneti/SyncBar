import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodDashboardPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getIFoodMerchantStatus, getIFoodOrders, getIFoodFinancialSummary, getIFoodReviews } from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { Button } from "/src/ui/Button.tsx";
import { DashboardCard } from "/src/components/DashboardCard.tsx";
import { StatsGrid } from "/src/components/StatsGrid.tsx";
import { MetricsRow } from "/src/components/MetricsRow.tsx";
import {
  formatOrderStatus,
  formatMerchantAvailability,
  formatCurrency,
  calculateOrderMetrics,
  formatTime
} from "/src/utils/ifoodFormattersEnhanced.ts";
const REVIEWS_PAGE_SIZE = 50;
const ORDER_TYPE_LABELS = {
  DELIVERY: "🚗 Delivery",
  TAKEOUT: "🛍️ Retirada"
};
export function IFoodDashboardPage() {
  _s();
  const { branchId } = useAuthStore();
  const statusQuery = useQuery({
    queryKey: ["integrations", "ifood", "dashboard", "status", branchId],
    queryFn: () => getIFoodMerchantStatus(branchId),
    refetchInterval: 3e4,
    // Fase 20 (2026-08-24): sem isso, o retry padrão do TanStack Query (3 tentativas com
    // backoff) transformava uma única falha em várias chamadas reais ao iFood em rajada —
    // o próximo poll de 30s já tenta de novo, não precisa de retry automático aqui.
    retry: false
  });
  const ordersQuery = useQuery({
    queryKey: ["integrations", "ifood", "dashboard", "orders", branchId],
    queryFn: () => getIFoodOrders(branchId),
    refetchInterval: 15e3
  });
  const financialQuery = useQuery({
    queryKey: ["integrations", "ifood", "dashboard", "financial", branchId],
    queryFn: () => getIFoodFinancialSummary(branchId),
    refetchInterval: 6e4
  });
  const reviewsQuery = useQuery({
    queryKey: ["integrations", "ifood", "dashboard", "reviews", branchId],
    queryFn: () => getIFoodReviews(branchId, { pageSize: REVIEWS_PAGE_SIZE }),
    refetchInterval: 6e4
  });
  const isLoading = statusQuery.isLoading || ordersQuery.isLoading;
  const isError = statusQuery.isError || ordersQuery.isError;
  const merchantStatus = statusQuery.data;
  const orders = ordersQuery.data || [];
  const financial = financialQuery.data;
  const reviews = reviewsQuery.data?.reviews ?? [];
  const metrics = calculateOrderMetrics(orders);
  const statusDisplay = merchantStatus ? formatMerchantAvailability(merchantStatus.available, merchantStatus.operationState) : null;
  const scoredReviews = reviews.filter((r) => r.score !== null);
  const avgRating = scoredReviews.length > 0 ? (scoredReviews.reduce((sum, r) => sum + (r.score ?? 0), 0) / scoredReviews.length).toFixed(1) : "—";
  const respondedReviews = reviews.filter((r) => !!r.reply).length;
  const primaryError = statusQuery.isError ? statusQuery.error : ordersQuery.error;
  const errorMessage = isError ? primaryError : null;
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1400, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "Dashboard iFood",
        subtitle: "Visão centralizada de performance, pedidos e operação",
        breadcrumb: [{ label: "Integrações", href: "/integracoes/ifood" }],
        actions: /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            onClick: () => {
              statusQuery.refetch();
              ordersQuery.refetch();
              financialQuery.refetch();
              reviewsQuery.refetch();
            },
            disabled: isLoading,
            children: [
              "🔄 ",
              isLoading ? "Atualizando..." : "Atualizar agora"
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 108,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
        lineNumber: 103,
        columnNumber: 7
      },
      this
    ),
    statusDisplay && /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          padding: 16,
          borderRadius: 8,
          background: statusDisplay.bg,
          border: `2px solid ${statusDisplay.color}`,
          marginBottom: 24,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center"
        },
        children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12, alignItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "2rem" }, children: statusDisplay.icon }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 138,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.9rem", color: statusDisplay.color, margin: "0 0 4px", fontWeight: 600 }, children: "Estado da Operação" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                lineNumber: 140,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { style: { fontSize: "1.5rem", margin: 0, color: statusDisplay.color }, children: statusDisplay.label }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                lineNumber: 143,
                columnNumber: 15
              }, this),
              merchantStatus?.operationState && /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.8rem", color: "var(--ink-faint)", margin: "4px 0 0" }, children: merchantStatus.operationState }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                lineNumber: 147,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 139,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 137,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/status", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "Ver detalhes →" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 154,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 153,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
        lineNumber: 125,
        columnNumber: 7
      },
      this
    ),
    errorMessage && /* @__PURE__ */ jsxDEV(QueryError, { error: errorMessage, what: "as informações do dashboard" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    !isLoading && !isError && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 32 }, children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "1rem", fontWeight: 700, marginBottom: 12 }, children: "Resumo de Pedidos" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 167,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(StatsGrid, { columns: 4, children: [
          /* @__PURE__ */ jsxDEV(
            DashboardCard,
            {
              title: "Total de Pedidos",
              value: metrics.total,
              icon: "📦",
              status: "info",
              subtitle: "Pedidos sincronizados"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 169,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(DashboardCard, { title: "Entregues", value: metrics.delivered, status: "success", icon: "✓" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 176,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            DashboardCard,
            {
              title: "Em Progresso",
              value: metrics.inProgress,
              status: "warning",
              icon: "⏳"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 177,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DashboardCard,
            {
              title: "Cancelados",
              value: metrics.cancelled,
              status: "error",
              icon: "✕"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 183,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 168,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
        lineNumber: 166,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 32, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 12 }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16 }, children: [
          /* @__PURE__ */ jsxDEV("h4", { style: { fontSize: "0.9rem", fontWeight: 600, margin: "0 0 12px" }, children: "📊 Pedidos por Tipo" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 195,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            MetricsRow,
            {
              metric: "Delivery",
              value: metrics.deliveryOrders,
              icon: "🚗"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 198,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            MetricsRow,
            {
              metric: "Retirada",
              value: metrics.takeoutOrders,
              icon: "🛍️"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 203,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            MetricsRow,
            {
              metric: "Consumo no Local",
              value: metrics.dineInOrders,
              icon: "🍽️"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 208,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 194,
          columnNumber: 13
        }, this),
        financial && /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16 }, children: [
          /* @__PURE__ */ jsxDEV("h4", { style: { fontSize: "0.9rem", fontWeight: 600, margin: "0 0 12px" }, children: "💰 Financeiro" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 218,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            MetricsRow,
            {
              metric: "Eventos com repasse",
              value: formatCurrency(financial.totalFinancialEventsWithTransferImpact)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 221,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(MetricsRow, { metric: "Repasses recebidos", value: formatCurrency(financial.totalSettlements) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 225,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            MetricsRow,
            {
              metric: "Divergência",
              value: financial.hasDiscrepancy ? formatCurrency(financial.discrepancyAmount) : "—"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 226,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 217,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16 }, children: [
          /* @__PURE__ */ jsxDEV("h4", { style: { fontSize: "0.9rem", fontWeight: 600, margin: "0 0 12px" }, children: "⭐ Avaliações" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 235,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            MetricsRow,
            {
              metric: "Rating Médio",
              value: avgRating,
              icon: "⭐"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 238,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            MetricsRow,
            {
              metric: "Total de Reviews",
              value: reviews.length
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 243,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            MetricsRow,
            {
              metric: "Respondidas",
              value: respondedReviews,
              unit: `de ${reviews.length}`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 247,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 234,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
        lineNumber: 193,
        columnNumber: 11
      }, this),
      orders.length > 0 && /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 32 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }, children: [
          /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "1rem", fontWeight: 700, margin: 0 }, children: "Pedidos Abertos" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 259,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/pedidos", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "Ver todos →" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 263,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 262,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 258,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 0, overflow: "hidden" }, children: /* @__PURE__ */ jsxDEV("table", { style: { width: "100%", borderCollapse: "collapse" }, children: [
          /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { style: { borderBottom: "1px solid var(--border)", background: "var(--surface-2)" }, children: [
            /* @__PURE__ */ jsxDEV("th", { style: { padding: 12, textAlign: "left", fontSize: "0.85rem", fontWeight: 600 }, children: "Pedido" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 271,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("th", { style: { padding: 12, textAlign: "left", fontSize: "0.85rem", fontWeight: 600 }, children: "Status" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 274,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("th", { style: { padding: 12, textAlign: "left", fontSize: "0.85rem", fontWeight: 600 }, children: "Tipo" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 277,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("th", { style: { padding: 12, textAlign: "right", fontSize: "0.85rem", fontWeight: 600 }, children: "Valor" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 280,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("th", { style: { padding: 12, textAlign: "left", fontSize: "0.85rem", fontWeight: 600 }, children: "Horário" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
              lineNumber: 283,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 270,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 269,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { children: orders.slice(0, 5).map((order) => {
            const statusInfo = formatOrderStatus(order.status);
            return /* @__PURE__ */ jsxDEV(
              "tr",
              {
                style: { borderBottom: "1px solid var(--border)" },
                children: [
                  /* @__PURE__ */ jsxDEV("td", { style: { padding: 12, fontSize: "0.9rem", fontWeight: 600 }, children: order.displayId || order.ifoodOrderId }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                    lineNumber: 296,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { style: { padding: 12 }, children: /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      style: {
                        fontSize: "0.8rem",
                        padding: "4px 8px",
                        borderRadius: 4,
                        background: statusInfo.color + "20",
                        color: statusInfo.color,
                        fontWeight: 600
                      },
                      children: [
                        statusInfo.icon,
                        " ",
                        statusInfo.label
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                      lineNumber: 300,
                      columnNumber: 29
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                    lineNumber: 299,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { style: { padding: 12, fontSize: "0.9rem" }, children: ORDER_TYPE_LABELS[order.ifoodOrderType] ?? "🍽️ Local" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                    lineNumber: 313,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { style: { padding: 12, textAlign: "right", fontSize: "0.9rem", fontWeight: 600 }, children: formatCurrency(order.totalAmount) }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                    lineNumber: 316,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { style: { padding: 12, fontSize: "0.85rem", color: "var(--ink-faint)" }, children: formatTime(order.createdAt) }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                    lineNumber: 319,
                    columnNumber: 27
                  }, this)
                ]
              },
              order.id,
              true,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
                lineNumber: 292,
                columnNumber: 21
              },
              this
            );
          }) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 288,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 268,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 267,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
        lineNumber: 257,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 32 }, children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "1rem", fontWeight: 700, marginBottom: 12 }, children: "Acesso Rápido" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 333,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 12 }, children: [
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/status", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", style: { width: "100%", justifyContent: "flex-start" }, children: "🔍 Status & Validações" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 336,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 335,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/pedidos", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", style: { width: "100%", justifyContent: "flex-start" }, children: "📦 Gerenciar Pedidos" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 341,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 340,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/financeiro/relatorios", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", style: { width: "100%", justifyContent: "flex-start" }, children: "💰 Financeiro Detalhado" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 346,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 345,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/avaliacoes", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", style: { width: "100%", justifyContent: "flex-start" }, children: "⭐ Respostas de Avaliações" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 351,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 350,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/logistica", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", style: { width: "100%", justifyContent: "flex-start" }, children: "🚗 Status de Entregas" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 356,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 355,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/indicadores", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", style: { width: "100%", justifyContent: "flex-start" }, children: "📊 Indicadores Analytics" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 361,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
            lineNumber: 360,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
          lineNumber: 334,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
        lineNumber: 332,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
      lineNumber: 164,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx",
    lineNumber: 101,
    columnNumber: 5
  }, this);
}
_s(IFoodDashboardPage, "dn87AhDD1jFukBZpO+YCY1YPxhA=", false, function() {
  return [useAuthStore, useQuery, useQuery, useQuery, useQuery];
});
_c = IFoodDashboardPage;
var _c;
$RefreshReg$(_c, "IFoodDashboardPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodDashboardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0ZVLFNBd0RGLFVBeERFOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhGVCxTQUFTQSxZQUFZO0FBQ3RCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx3QkFBd0JDLGdCQUFnQkMsMEJBQTBCQyx1QkFBdUI7QUFDbEcsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGtCQUFrQjtBQUMzQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQyxvQkFBb0I7QUFFMUIsTUFBTUMsb0JBQTRDO0FBQUEsRUFDaERDLFVBQVU7QUFBQSxFQUNWQyxTQUFTO0FBQ1g7QUFFTyxnQkFBU0MscUJBQXFCO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxFQUFFQyxTQUFTLElBQUlsQixhQUFhO0FBR2xDLFFBQU1tQixjQUFjeEIsU0FBUztBQUFBLElBQzNCeUIsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGFBQWEsVUFBVUYsUUFBUTtBQUFBLElBQ25FRyxTQUFTQSxNQUFNekIsdUJBQXVCc0IsUUFBUTtBQUFBLElBQzlDSSxpQkFBaUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlqQkMsT0FBTztBQUFBLEVBQ1QsQ0FBQztBQUVELFFBQU1DLGNBQWM3QixTQUFTO0FBQUEsSUFDM0J5QixVQUFVLENBQUMsZ0JBQWdCLFNBQVMsYUFBYSxVQUFVRixRQUFRO0FBQUEsSUFDbkVHLFNBQVNBLE1BQU14QixlQUFlcUIsUUFBUTtBQUFBLElBQ3RDSSxpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTUcsaUJBQWlCOUIsU0FBUztBQUFBLElBQzlCeUIsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGFBQWEsYUFBYUYsUUFBUTtBQUFBLElBQ3RFRyxTQUFTQSxNQUFNdkIseUJBQXlCb0IsUUFBUTtBQUFBLElBQ2hESSxpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTUksZUFBZS9CLFNBQVM7QUFBQSxJQUM1QnlCLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxhQUFhLFdBQVdGLFFBQVE7QUFBQSxJQUNwRUcsU0FBU0EsTUFBTXRCLGdCQUFnQm1CLFVBQVUsRUFBRVMsVUFBVWYsa0JBQWtCLENBQUM7QUFBQSxJQUN4RVUsaUJBQWlCO0FBQUEsRUFDbkIsQ0FBQztBQUVELFFBQU1NLFlBQVlULFlBQVlTLGFBQWFKLFlBQVlJO0FBQ3ZELFFBQU1DLFVBQVVWLFlBQVlVLFdBQVdMLFlBQVlLO0FBRW5ELFFBQU1DLGlCQUFpQlgsWUFBWVk7QUFDbkMsUUFBTUMsU0FBU1IsWUFBWU8sUUFBUTtBQUNuQyxRQUFNRSxZQUFZUixlQUFlTTtBQUNqQyxRQUFNRyxVQUFVUixhQUFhSyxNQUFNRyxXQUFXO0FBRTlDLFFBQU1DLFVBQVV6QixzQkFBc0JzQixNQUFNO0FBQzVDLFFBQU1JLGdCQUFnQk4saUJBQWlCdEIsMkJBQTJCc0IsZUFBZU8sV0FBV1AsZUFBZVEsY0FBYyxJQUFJO0FBSTdILFFBQU1DLGdCQUFnQkwsUUFBUU0sT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxVQUFVLElBQUk7QUFDNUQsUUFBTUMsWUFDSkosY0FBY0ssU0FBUyxLQUNsQkwsY0FBY00sT0FBTyxDQUFDQyxLQUFLTCxNQUFNSyxPQUFPTCxFQUFFQyxTQUFTLElBQUksQ0FBQyxJQUFJSCxjQUFjSyxRQUFRRyxRQUFRLENBQUMsSUFDNUY7QUFDTixRQUFNQyxtQkFBbUJkLFFBQVFNLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDLENBQUNBLEVBQUVRLEtBQUssRUFBRUw7QUFFMUQsUUFBTU0sZUFBZS9CLFlBQVlVLFVBQVVWLFlBQVlnQyxRQUFRM0IsWUFBWTJCO0FBQzNFLFFBQU1DLGVBQWV2QixVQUFVcUIsZUFBZTtBQUU5QyxTQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFRyxTQUFTLElBQUlDLFVBQVUsTUFBTUMsUUFBUSxTQUFTLEdBRTNEO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLFVBQVM7QUFBQSxRQUNULFlBQVksQ0FBQyxFQUFFQyxPQUFPLGVBQWVDLE1BQU0scUJBQXFCLENBQUM7QUFBQSxRQUNqRSxTQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixTQUFTLE1BQU07QUFDYnRDLDBCQUFZdUMsUUFBUTtBQUNwQmxDLDBCQUFZa0MsUUFBUTtBQUNwQmpDLDZCQUFlaUMsUUFBUTtBQUN2QmhDLDJCQUFhZ0MsUUFBUTtBQUFBLFlBQ3ZCO0FBQUEsWUFDQSxVQUFVOUI7QUFBQUEsWUFBVTtBQUFBO0FBQUEsY0FFaEJBLFlBQVksbUJBQW1CO0FBQUE7QUFBQTtBQUFBLFVBVnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdBO0FBQUE7QUFBQSxNQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFpQkc7QUFBQSxJQUlGUSxpQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFVBQ0xpQixTQUFTO0FBQUEsVUFDVE0sY0FBYztBQUFBLFVBQ2RDLFlBQVl4QixjQUFjeUI7QUFBQUEsVUFDMUJDLFFBQVEsYUFBYTFCLGNBQWMyQixLQUFLO0FBQUEsVUFDeENDLGNBQWM7QUFBQSxVQUNkQyxTQUFTO0FBQUEsVUFDVEMsZ0JBQWdCO0FBQUEsVUFDaEJDLFlBQVk7QUFBQSxRQUNkO0FBQUEsUUFFQTtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFRixTQUFTLFFBQVFHLEtBQUssSUFBSUQsWUFBWSxTQUFTLEdBQzNEO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUVFLFVBQVUsT0FBTyxHQUFJakMsd0JBQWNrQyxRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLFlBQ3RELHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLE9BQU8sRUFBRUQsVUFBVSxVQUFVTixPQUFPM0IsY0FBYzJCLE9BQU9SLFFBQVEsV0FBV2dCLFlBQVksSUFBSSxHQUFHLGtDQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLE9BQU8sRUFBRUYsVUFBVSxVQUFVZCxRQUFRLEdBQUdRLE9BQU8zQixjQUFjMkIsTUFBTSxHQUNwRTNCLHdCQUFjb0IsU0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0MxQixnQkFBZ0JRLGtCQUNmLHVCQUFDLE9BQUUsT0FBTyxFQUFFK0IsVUFBVSxVQUFVTixPQUFPLG9CQUFvQlIsUUFBUSxVQUFVLEdBQzFFekIseUJBQWVRLGtCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLGVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBQ0EsdUJBQUMsUUFBSyxJQUFHLDZCQUE0QixPQUFPLEVBQUVrQyxnQkFBZ0IsT0FBTyxHQUNuRSxpQ0FBQyxVQUFPLFNBQVEsU0FBUSw4QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBO0FBQUE7QUFBQSxNQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUErQkE7QUFBQSxJQUdEcEIsZ0JBQ0MsdUJBQUMsY0FBVyxPQUFPQSxjQUFjLE1BQUssaUNBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUU7QUFBQSxJQUdwRSxDQUFDeEIsYUFBYSxDQUFDQyxXQUNkLG1DQUVFO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVtQyxjQUFjLEdBQUcsR0FDN0I7QUFBQSwrQkFBQyxRQUFHLE9BQU8sRUFBRUssVUFBVSxRQUFRRSxZQUFZLEtBQUtQLGNBQWMsR0FBRyxHQUFHLGlDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFGO0FBQUEsUUFDckYsdUJBQUMsYUFBVSxTQUFTLEdBQ2xCO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU83QixRQUFRc0M7QUFBQUEsY0FDZixNQUFLO0FBQUEsY0FDTCxRQUFPO0FBQUEsY0FDUCxVQUFTO0FBQUE7QUFBQSxZQUxYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtrQztBQUFBLFVBRWxDLHVCQUFDLGlCQUFjLE9BQU0sYUFBWSxPQUFPdEMsUUFBUXVDLFdBQVcsUUFBTyxXQUFVLE1BQUssT0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUNwRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBT3ZDLFFBQVF3QztBQUFBQSxjQUNmLFFBQU87QUFBQSxjQUNQLE1BQUs7QUFBQTtBQUFBLFlBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSVU7QUFBQSxVQUVWO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPeEMsUUFBUXlDO0FBQUFBLGNBQ2YsUUFBTztBQUFBLGNBQ1AsTUFBSztBQUFBO0FBQUEsWUFKUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJVTtBQUFBLGFBbkJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxXQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVosY0FBYyxJQUFJQyxTQUFTLFFBQVFZLHFCQUFxQix3Q0FBd0NULEtBQUssR0FBRyxHQUNwSDtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRWYsU0FBUyxHQUFHLEdBQ3pDO0FBQUEsaUNBQUMsUUFBRyxPQUFPLEVBQUVnQixVQUFVLFVBQVVFLFlBQVksS0FBS2hCLFFBQVEsV0FBVyxHQUFHLG1DQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsUUFBTztBQUFBLGNBQ1AsT0FBT3BCLFFBQVEyQztBQUFBQSxjQUNmLE1BQUs7QUFBQTtBQUFBLFlBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBR1c7QUFBQSxVQUVYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxRQUFPO0FBQUEsY0FDUCxPQUFPM0MsUUFBUTRDO0FBQUFBLGNBQ2YsTUFBSztBQUFBO0FBQUEsWUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHWTtBQUFBLFVBRVo7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFFBQU87QUFBQSxjQUNQLE9BQU81QyxRQUFRNkM7QUFBQUEsY0FDZixNQUFLO0FBQUE7QUFBQSxZQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdZO0FBQUEsYUFqQmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBR0MvQyxhQUNDLHVCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRW9CLFNBQVMsR0FBRyxHQUN6QztBQUFBLGlDQUFDLFFBQUcsT0FBTyxFQUFFZ0IsVUFBVSxVQUFVRSxZQUFZLEtBQUtoQixRQUFRLFdBQVcsR0FBRyw2QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFFBQU87QUFBQSxjQUNQLE9BQU85QyxlQUFld0IsVUFBVWdELHNDQUFzQztBQUFBO0FBQUEsWUFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRTBFO0FBQUEsVUFFMUUsdUJBQUMsY0FBVyxRQUFPLHNCQUFxQixPQUFPeEUsZUFBZXdCLFVBQVVpRCxnQkFBZ0IsS0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEY7QUFBQSxVQUMxRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsUUFBTztBQUFBLGNBQ1AsT0FBT2pELFVBQVVrRCxpQkFBaUIxRSxlQUFld0IsVUFBVW1ELGlCQUFpQixJQUFJO0FBQUE7QUFBQSxZQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFc0Y7QUFBQSxhQVh4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUlGLHVCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRS9CLFNBQVMsR0FBRyxHQUN6QztBQUFBLGlDQUFDLFFBQUcsT0FBTyxFQUFFZ0IsVUFBVSxVQUFVRSxZQUFZLEtBQUtoQixRQUFRLFdBQVcsR0FBRyw0QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFFBQU87QUFBQSxjQUNQLE9BQU9aO0FBQUFBLGNBQ1AsTUFBSztBQUFBO0FBQUEsWUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHVTtBQUFBLFVBRVY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFFBQU87QUFBQSxjQUNQLE9BQU9ULFFBQVFVO0FBQUFBO0FBQUFBLFlBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUV3QjtBQUFBLFVBRXhCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxRQUFPO0FBQUEsY0FDUCxPQUFPSTtBQUFBQSxjQUNQLE1BQU0sTUFBTWQsUUFBUVUsTUFBTTtBQUFBO0FBQUEsWUFINUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRytCO0FBQUEsYUFoQmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxXQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNERBO0FBQUEsTUFHQ1osT0FBT1ksU0FBUyxLQUNmLHVCQUFDLFNBQUksT0FBTyxFQUFFb0IsY0FBYyxHQUFHLEdBQzdCO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVDLFNBQVMsUUFBUUMsZ0JBQWdCLGlCQUFpQkMsWUFBWSxVQUFVSCxjQUFjLEdBQUcsR0FDckc7QUFBQSxpQ0FBQyxRQUFHLE9BQU8sRUFBRUssVUFBVSxRQUFRRSxZQUFZLEtBQUtoQixRQUFRLEVBQUUsR0FBRywrQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBSyxJQUFHLDhCQUE2QixPQUFPLEVBQUVpQixnQkFBZ0IsT0FBTyxHQUNwRSxpQ0FBQyxVQUFPLFNBQVEsU0FBUSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVuQixTQUFTLEdBQUdnQyxVQUFVLFNBQVMsR0FDNUQsaUNBQUMsV0FBTSxPQUFPLEVBQUVDLE9BQU8sUUFBUUMsZ0JBQWdCLFdBQVcsR0FDeEQ7QUFBQSxpQ0FBQyxXQUNDLGlDQUFDLFFBQUcsT0FBTyxFQUFFQyxjQUFjLDJCQUEyQjVCLFlBQVksbUJBQW1CLEdBQ25GO0FBQUEsbUNBQUMsUUFBRyxPQUFPLEVBQUVQLFNBQVMsSUFBSW9DLFdBQVcsUUFBUXBCLFVBQVUsV0FBV0UsWUFBWSxJQUFJLEdBQUcsc0JBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsT0FBTyxFQUFFbEIsU0FBUyxJQUFJb0MsV0FBVyxRQUFRcEIsVUFBVSxXQUFXRSxZQUFZLElBQUksR0FBRyxzQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxPQUFPLEVBQUVsQixTQUFTLElBQUlvQyxXQUFXLFFBQVFwQixVQUFVLFdBQVdFLFlBQVksSUFBSSxHQUFHLG9CQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLE9BQU8sRUFBRWxCLFNBQVMsSUFBSW9DLFdBQVcsU0FBU3BCLFVBQVUsV0FBV0UsWUFBWSxJQUFJLEdBQUcscUJBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsT0FBTyxFQUFFbEIsU0FBUyxJQUFJb0MsV0FBVyxRQUFRcEIsVUFBVSxXQUFXRSxZQUFZLElBQUksR0FBRyx1QkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUNBLHVCQUFDLFdBQ0V2QyxpQkFBTzBELE1BQU0sR0FBRyxDQUFDLEVBQUVDLElBQUksQ0FBQ0MsVUFBVTtBQUNqQyxrQkFBTUMsYUFBYXRGLGtCQUFrQnFGLE1BQU1FLE1BQU07QUFDakQsbUJBQ0U7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxPQUFPLEVBQUVOLGNBQWMsMEJBQTBCO0FBQUEsZ0JBRWpEO0FBQUEseUNBQUMsUUFBRyxPQUFPLEVBQUVuQyxTQUFTLElBQUlnQixVQUFVLFVBQVVFLFlBQVksSUFBSSxHQUMzRHFCLGdCQUFNRyxhQUFhSCxNQUFNSSxnQkFENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsT0FBTyxFQUFFM0MsU0FBUyxHQUFHLEdBQ3ZCO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU87QUFBQSx3QkFDTGdCLFVBQVU7QUFBQSx3QkFDVmhCLFNBQVM7QUFBQSx3QkFDVE0sY0FBYztBQUFBLHdCQUNkQyxZQUFZaUMsV0FBVzlCLFFBQVE7QUFBQSx3QkFDL0JBLE9BQU84QixXQUFXOUI7QUFBQUEsd0JBQ2xCUSxZQUFZO0FBQUEsc0JBQ2Q7QUFBQSxzQkFFQ3NCO0FBQUFBLG1DQUFXdkI7QUFBQUEsd0JBQUs7QUFBQSx3QkFBRXVCLFdBQVdyQztBQUFBQTtBQUFBQTtBQUFBQSxvQkFWaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFhQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsT0FBTyxFQUFFSCxTQUFTLElBQUlnQixVQUFVLFNBQVMsR0FDMUN4RCw0QkFBa0IrRSxNQUFNSyxjQUFjLEtBQUssZUFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsT0FBTyxFQUFFNUMsU0FBUyxJQUFJb0MsV0FBVyxTQUFTcEIsVUFBVSxVQUFVRSxZQUFZLElBQUksR0FDL0U5RCx5QkFBZW1GLE1BQU1NLFdBQVcsS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsT0FBTyxFQUFFN0MsU0FBUyxJQUFJZ0IsVUFBVSxXQUFXTixPQUFPLG1CQUFtQixHQUN0RXBELHFCQUFXaUYsTUFBTU8sU0FBUyxLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUE7QUFBQTtBQUFBLGNBNUJLUCxNQUFNUTtBQUFBQSxjQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE4QkE7QUFBQSxVQUVKLENBQUMsS0FwQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0E7QUFBQSxhQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMERBLEtBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0REE7QUFBQSxXQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUVBO0FBQUEsTUFJRix1QkFBQyxTQUFJLE9BQU8sRUFBRXBDLGNBQWMsR0FBRyxHQUM3QjtBQUFBLCtCQUFDLFFBQUcsT0FBTyxFQUFFSyxVQUFVLFFBQVFFLFlBQVksS0FBS1AsY0FBYyxHQUFHLEdBQUcsNkJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUY7QUFBQSxRQUNqRix1QkFBQyxTQUFJLE9BQU8sRUFBRUMsU0FBUyxRQUFRWSxxQkFBcUIsd0NBQXdDVCxLQUFLLEdBQUcsR0FDbEc7QUFBQSxpQ0FBQyxRQUFLLElBQUcsNkJBQTRCLE9BQU8sRUFBRUksZ0JBQWdCLE9BQU8sR0FDbkUsaUNBQUMsVUFBTyxTQUFRLFNBQVEsT0FBTyxFQUFFYyxPQUFPLFFBQVFwQixnQkFBZ0IsYUFBYSxHQUFHLHNDQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsUUFBSyxJQUFHLDhCQUE2QixPQUFPLEVBQUVNLGdCQUFnQixPQUFPLEdBQ3BFLGlDQUFDLFVBQU8sU0FBUSxTQUFRLE9BQU8sRUFBRWMsT0FBTyxRQUFRcEIsZ0JBQWdCLGFBQWEsR0FBRyxvQ0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLFFBQUssSUFBRyw0Q0FBMkMsT0FBTyxFQUFFTSxnQkFBZ0IsT0FBTyxHQUNsRixpQ0FBQyxVQUFPLFNBQVEsU0FBUSxPQUFPLEVBQUVjLE9BQU8sUUFBUXBCLGdCQUFnQixhQUFhLEdBQUcsdUNBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxRQUFLLElBQUcsaUNBQWdDLE9BQU8sRUFBRU0sZ0JBQWdCLE9BQU8sR0FDdkUsaUNBQUMsVUFBTyxTQUFRLFNBQVEsT0FBTyxFQUFFYyxPQUFPLFFBQVFwQixnQkFBZ0IsYUFBYSxHQUFHLHlDQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsUUFBSyxJQUFHLGdDQUErQixPQUFPLEVBQUVNLGdCQUFnQixPQUFPLEdBQ3RFLGlDQUFDLFVBQU8sU0FBUSxTQUFRLE9BQU8sRUFBRWMsT0FBTyxRQUFRcEIsZ0JBQWdCLGFBQWEsR0FBRyxxQ0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLFFBQUssSUFBRyxrQ0FBaUMsT0FBTyxFQUFFTSxnQkFBZ0IsT0FBTyxHQUN4RSxpQ0FBQyxVQUFPLFNBQVEsU0FBUSxPQUFPLEVBQUVjLE9BQU8sUUFBUXBCLGdCQUFnQixhQUFhLEdBQUcsd0NBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQTtBQUFBLFdBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQ0E7QUFBQSxTQTFNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMk1BO0FBQUEsT0ExUUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRRQTtBQUVKO0FBQUNqRCxHQXRVZUQsb0JBQWtCO0FBQUEsVUFDWGhCLGNBR0RMLFVBVUFBLFVBTUdBLFVBTUZBLFFBQVE7QUFBQTtBQUFBLEtBMUJmcUI7QUFBa0IsSUFBQXFGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkxpbmsiLCJ1c2VRdWVyeSIsImdldElGb29kTWVyY2hhbnRTdGF0dXMiLCJnZXRJRm9vZE9yZGVycyIsImdldElGb29kRmluYW5jaWFsU3VtbWFyeSIsImdldElGb29kUmV2aWV3cyIsInVzZUF1dGhTdG9yZSIsIlBhZ2VIZWFkZXIiLCJRdWVyeUVycm9yIiwiQnV0dG9uIiwiRGFzaGJvYXJkQ2FyZCIsIlN0YXRzR3JpZCIsIk1ldHJpY3NSb3ciLCJmb3JtYXRPcmRlclN0YXR1cyIsImZvcm1hdE1lcmNoYW50QXZhaWxhYmlsaXR5IiwiZm9ybWF0Q3VycmVuY3kiLCJjYWxjdWxhdGVPcmRlck1ldHJpY3MiLCJmb3JtYXRUaW1lIiwiUkVWSUVXU19QQUdFX1NJWkUiLCJPUkRFUl9UWVBFX0xBQkVMUyIsIkRFTElWRVJZIiwiVEFLRU9VVCIsIklGb29kRGFzaGJvYXJkUGFnZSIsIl9zIiwiYnJhbmNoSWQiLCJzdGF0dXNRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInJlZmV0Y2hJbnRlcnZhbCIsInJldHJ5Iiwib3JkZXJzUXVlcnkiLCJmaW5hbmNpYWxRdWVyeSIsInJldmlld3NRdWVyeSIsInBhZ2VTaXplIiwiaXNMb2FkaW5nIiwiaXNFcnJvciIsIm1lcmNoYW50U3RhdHVzIiwiZGF0YSIsIm9yZGVycyIsImZpbmFuY2lhbCIsInJldmlld3MiLCJtZXRyaWNzIiwic3RhdHVzRGlzcGxheSIsImF2YWlsYWJsZSIsIm9wZXJhdGlvblN0YXRlIiwic2NvcmVkUmV2aWV3cyIsImZpbHRlciIsInIiLCJzY29yZSIsImF2Z1JhdGluZyIsImxlbmd0aCIsInJlZHVjZSIsInN1bSIsInRvRml4ZWQiLCJyZXNwb25kZWRSZXZpZXdzIiwicmVwbHkiLCJwcmltYXJ5RXJyb3IiLCJlcnJvciIsImVycm9yTWVzc2FnZSIsInBhZGRpbmciLCJtYXhXaWR0aCIsIm1hcmdpbiIsImxhYmVsIiwiaHJlZiIsInJlZmV0Y2giLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kIiwiYmciLCJib3JkZXIiLCJjb2xvciIsIm1hcmdpbkJvdHRvbSIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImFsaWduSXRlbXMiLCJnYXAiLCJmb250U2l6ZSIsImljb24iLCJmb250V2VpZ2h0IiwidGV4dERlY29yYXRpb24iLCJ0b3RhbCIsImRlbGl2ZXJlZCIsImluUHJvZ3Jlc3MiLCJjYW5jZWxsZWQiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwiZGVsaXZlcnlPcmRlcnMiLCJ0YWtlb3V0T3JkZXJzIiwiZGluZUluT3JkZXJzIiwidG90YWxGaW5hbmNpYWxFdmVudHNXaXRoVHJhbnNmZXJJbXBhY3QiLCJ0b3RhbFNldHRsZW1lbnRzIiwiaGFzRGlzY3JlcGFuY3kiLCJkaXNjcmVwYW5jeUFtb3VudCIsIm92ZXJmbG93Iiwid2lkdGgiLCJib3JkZXJDb2xsYXBzZSIsImJvcmRlckJvdHRvbSIsInRleHRBbGlnbiIsInNsaWNlIiwibWFwIiwib3JkZXIiLCJzdGF0dXNJbmZvIiwic3RhdHVzIiwiZGlzcGxheUlkIiwiaWZvb2RPcmRlcklkIiwiaWZvb2RPcmRlclR5cGUiLCJ0b3RhbEFtb3VudCIsImNyZWF0ZWRBdCIsImlkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSUZvb2REYXNoYm9hcmRQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IGdldElGb29kTWVyY2hhbnRTdGF0dXMsIGdldElGb29kT3JkZXJzLCBnZXRJRm9vZEZpbmFuY2lhbFN1bW1hcnksIGdldElGb29kUmV2aWV3cyB9IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBQYWdlSGVhZGVyIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUGFnZUhlYWRlclwiO1xyXG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IERhc2hib2FyZENhcmQgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9EYXNoYm9hcmRDYXJkXCI7XHJcbmltcG9ydCB7IFN0YXRzR3JpZCB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1N0YXRzR3JpZFwiO1xyXG5pbXBvcnQgeyBNZXRyaWNzUm93IH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvTWV0cmljc1Jvd1wiO1xyXG5pbXBvcnQge1xyXG4gIGZvcm1hdE9yZGVyU3RhdHVzLFxyXG4gIGZvcm1hdE1lcmNoYW50QXZhaWxhYmlsaXR5LFxyXG4gIGZvcm1hdEN1cnJlbmN5LFxyXG4gIGNhbGN1bGF0ZU9yZGVyTWV0cmljcyxcclxuICBmb3JtYXRUaW1lLFxyXG59IGZyb20gXCIuLi8uLi91dGlscy9pZm9vZEZvcm1hdHRlcnNFbmhhbmNlZFwiO1xyXG5cclxuY29uc3QgUkVWSUVXU19QQUdFX1NJWkUgPSA1MDtcclxuXHJcbmNvbnN0IE9SREVSX1RZUEVfTEFCRUxTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gIERFTElWRVJZOiBcIvCfmpcgRGVsaXZlcnlcIixcclxuICBUQUtFT1VUOiBcIvCfm43vuI8gUmV0aXJhZGFcIixcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJRm9vZERhc2hib2FyZFBhZ2UoKSB7XHJcbiAgY29uc3QgeyBicmFuY2hJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcblxyXG4gIC8vIFF1ZXJpZXMgZW0gcGFyYWxlbG9cclxuICBjb25zdCBzdGF0dXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImRhc2hib2FyZFwiLCBcInN0YXR1c1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZE1lcmNoYW50U3RhdHVzKGJyYW5jaElkKSxcclxuICAgIHJlZmV0Y2hJbnRlcnZhbDogMzAwMDAsXHJcbiAgICAvLyBGYXNlIDIwICgyMDI2LTA4LTI0KTogc2VtIGlzc28sIG8gcmV0cnkgcGFkcsOjbyBkbyBUYW5TdGFjayBRdWVyeSAoMyB0ZW50YXRpdmFzIGNvbVxyXG4gICAgLy8gYmFja29mZikgdHJhbnNmb3JtYXZhIHVtYSDDum5pY2EgZmFsaGEgZW0gdsOhcmlhcyBjaGFtYWRhcyByZWFpcyBhbyBpRm9vZCBlbSByYWphZGEg4oCUXHJcbiAgICAvLyBvIHByw7N4aW1vIHBvbGwgZGUgMzBzIGrDoSB0ZW50YSBkZSBub3ZvLCBuw6NvIHByZWNpc2EgZGUgcmV0cnkgYXV0b23DoXRpY28gYXF1aS5cclxuICAgIHJldHJ5OiBmYWxzZSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgb3JkZXJzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJkYXNoYm9hcmRcIiwgXCJvcmRlcnNcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RPcmRlcnMoYnJhbmNoSWQpLFxyXG4gICAgcmVmZXRjaEludGVydmFsOiAxNTAwMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZmluYW5jaWFsUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJkYXNoYm9hcmRcIiwgXCJmaW5hbmNpYWxcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RGaW5hbmNpYWxTdW1tYXJ5KGJyYW5jaElkKSxcclxuICAgIHJlZmV0Y2hJbnRlcnZhbDogNjAwMDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJldmlld3NRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImRhc2hib2FyZFwiLCBcInJldmlld3NcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RSZXZpZXdzKGJyYW5jaElkLCB7IHBhZ2VTaXplOiBSRVZJRVdTX1BBR0VfU0laRSB9KSxcclxuICAgIHJlZmV0Y2hJbnRlcnZhbDogNjAwMDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGlzTG9hZGluZyA9IHN0YXR1c1F1ZXJ5LmlzTG9hZGluZyB8fCBvcmRlcnNRdWVyeS5pc0xvYWRpbmc7XHJcbiAgY29uc3QgaXNFcnJvciA9IHN0YXR1c1F1ZXJ5LmlzRXJyb3IgfHwgb3JkZXJzUXVlcnkuaXNFcnJvcjtcclxuXHJcbiAgY29uc3QgbWVyY2hhbnRTdGF0dXMgPSBzdGF0dXNRdWVyeS5kYXRhO1xyXG4gIGNvbnN0IG9yZGVycyA9IG9yZGVyc1F1ZXJ5LmRhdGEgfHwgW107XHJcbiAgY29uc3QgZmluYW5jaWFsID0gZmluYW5jaWFsUXVlcnkuZGF0YTtcclxuICBjb25zdCByZXZpZXdzID0gcmV2aWV3c1F1ZXJ5LmRhdGE/LnJldmlld3MgPz8gW107XHJcblxyXG4gIGNvbnN0IG1ldHJpY3MgPSBjYWxjdWxhdGVPcmRlck1ldHJpY3Mob3JkZXJzKTtcclxuICBjb25zdCBzdGF0dXNEaXNwbGF5ID0gbWVyY2hhbnRTdGF0dXMgPyBmb3JtYXRNZXJjaGFudEF2YWlsYWJpbGl0eShtZXJjaGFudFN0YXR1cy5hdmFpbGFibGUsIG1lcmNoYW50U3RhdHVzLm9wZXJhdGlvblN0YXRlKSA6IG51bGw7XHJcblxyXG4gIC8vIEVzdGF0w61zdGljYXMgZGUgcmV2aWV3cyDigJQgYSBsaXN0YSBkbyBpRm9vZCBuw6NvIHRyYXogdW0gZXN0YWRvIGRlIHJlc3Bvc3RhOyBcInJlc3BvbmRpZGFcIiDDqVxyXG4gIC8vIHNpbXBsZXNtZW50ZSBhIGF2YWxpYcOnw6NvIHF1ZSBqw6EgdGVtIGByZXBseWAgcHJlZW5jaGlkby5cclxuICBjb25zdCBzY29yZWRSZXZpZXdzID0gcmV2aWV3cy5maWx0ZXIoKHIpID0+IHIuc2NvcmUgIT09IG51bGwpO1xyXG4gIGNvbnN0IGF2Z1JhdGluZyA9XHJcbiAgICBzY29yZWRSZXZpZXdzLmxlbmd0aCA+IDBcclxuICAgICAgPyAoc2NvcmVkUmV2aWV3cy5yZWR1Y2UoKHN1bSwgcikgPT4gc3VtICsgKHIuc2NvcmUgPz8gMCksIDApIC8gc2NvcmVkUmV2aWV3cy5sZW5ndGgpLnRvRml4ZWQoMSlcclxuICAgICAgOiBcIuKAlFwiO1xyXG4gIGNvbnN0IHJlc3BvbmRlZFJldmlld3MgPSByZXZpZXdzLmZpbHRlcigocikgPT4gISFyLnJlcGx5KS5sZW5ndGg7XHJcblxyXG4gIGNvbnN0IHByaW1hcnlFcnJvciA9IHN0YXR1c1F1ZXJ5LmlzRXJyb3IgPyBzdGF0dXNRdWVyeS5lcnJvciA6IG9yZGVyc1F1ZXJ5LmVycm9yO1xyXG4gIGNvbnN0IGVycm9yTWVzc2FnZSA9IGlzRXJyb3IgPyBwcmltYXJ5RXJyb3IgOiBudWxsO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxNDAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgIDxQYWdlSGVhZGVyXHJcbiAgICAgICAgdGl0bGU9XCJEYXNoYm9hcmQgaUZvb2RcIlxyXG4gICAgICAgIHN1YnRpdGxlPVwiVmlzw6NvIGNlbnRyYWxpemFkYSBkZSBwZXJmb3JtYW5jZSwgcGVkaWRvcyBlIG9wZXJhw6fDo29cIlxyXG4gICAgICAgIGJyZWFkY3J1bWI9e1t7IGxhYmVsOiBcIkludGVncmHDp8O1ZXNcIiwgaHJlZjogXCIvaW50ZWdyYWNvZXMvaWZvb2RcIiB9XX1cclxuICAgICAgICBhY3Rpb25zPXtcclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHN0YXR1c1F1ZXJ5LnJlZmV0Y2goKTtcclxuICAgICAgICAgICAgICBvcmRlcnNRdWVyeS5yZWZldGNoKCk7XHJcbiAgICAgICAgICAgICAgZmluYW5jaWFsUXVlcnkucmVmZXRjaCgpO1xyXG4gICAgICAgICAgICAgIHJldmlld3NRdWVyeS5yZWZldGNoKCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIPCflIQge2lzTG9hZGluZyA/IFwiQXR1YWxpemFuZG8uLi5cIiA6IFwiQXR1YWxpemFyIGFnb3JhXCJ9XHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICB9XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICB7LyogU3RhdHVzIGRlIGRpc3BvbmliaWxpZGFkZSAqL31cclxuICAgICAge3N0YXR1c0Rpc3BsYXkgJiYgKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDE2LFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IDgsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHN0YXR1c0Rpc3BsYXkuYmcsXHJcbiAgICAgICAgICAgIGJvcmRlcjogYDJweCBzb2xpZCAke3N0YXR1c0Rpc3BsYXkuY29sb3J9YCxcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAyNCxcclxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIixcclxuICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogXCIycmVtXCIgfX0+e3N0YXR1c0Rpc3BsYXkuaWNvbn08L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiwgY29sb3I6IHN0YXR1c0Rpc3BsYXkuY29sb3IsIG1hcmdpbjogXCIwIDAgNHB4XCIsIGZvbnRXZWlnaHQ6IDYwMCB9fT5cclxuICAgICAgICAgICAgICAgIEVzdGFkbyBkYSBPcGVyYcOnw6NvXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxoMiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjVyZW1cIiwgbWFyZ2luOiAwLCBjb2xvcjogc3RhdHVzRGlzcGxheS5jb2xvciB9fT5cclxuICAgICAgICAgICAgICAgIHtzdGF0dXNEaXNwbGF5LmxhYmVsfVxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAge21lcmNoYW50U3RhdHVzPy5vcGVyYXRpb25TdGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBtYXJnaW46IFwiNHB4IDAgMFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICB7bWVyY2hhbnRTdGF0dXMub3BlcmF0aW9uU3RhdGV9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxMaW5rIHRvPVwiL2ludGVncmFjb2VzL2lmb29kL3N0YXR1c1wiIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiB9fT5cclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIj5WZXIgZGV0YWxoZXMg4oaSPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7ZXJyb3JNZXNzYWdlICYmIChcclxuICAgICAgICA8UXVlcnlFcnJvciBlcnJvcj17ZXJyb3JNZXNzYWdlfSB3aGF0PVwiYXMgaW5mb3JtYcOnw7VlcyBkbyBkYXNoYm9hcmRcIiAvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgeyFpc0xvYWRpbmcgJiYgIWlzRXJyb3IgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICB7LyogU2XDp8OjbyAxOiBNw6l0cmljYXMgUHJpbmNpcGFpcyAqL31cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAzMiB9fT5cclxuICAgICAgICAgICAgPGgzIHN0eWxlPXt7IGZvbnRTaXplOiBcIjFyZW1cIiwgZm9udFdlaWdodDogNzAwLCBtYXJnaW5Cb3R0b206IDEyIH19PlJlc3VtbyBkZSBQZWRpZG9zPC9oMz5cclxuICAgICAgICAgICAgPFN0YXRzR3JpZCBjb2x1bW5zPXs0fT5cclxuICAgICAgICAgICAgICA8RGFzaGJvYXJkQ2FyZFxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJUb3RhbCBkZSBQZWRpZG9zXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXttZXRyaWNzLnRvdGFsfVxyXG4gICAgICAgICAgICAgICAgaWNvbj1cIvCfk6ZcIlxyXG4gICAgICAgICAgICAgICAgc3RhdHVzPVwiaW5mb1wiXHJcbiAgICAgICAgICAgICAgICBzdWJ0aXRsZT1cIlBlZGlkb3Mgc2luY3Jvbml6YWRvc1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8RGFzaGJvYXJkQ2FyZCB0aXRsZT1cIkVudHJlZ3Vlc1wiIHZhbHVlPXttZXRyaWNzLmRlbGl2ZXJlZH0gc3RhdHVzPVwic3VjY2Vzc1wiIGljb249XCLinJNcIiAvPlxyXG4gICAgICAgICAgICAgIDxEYXNoYm9hcmRDYXJkXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkVtIFByb2dyZXNzb1wiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bWV0cmljcy5pblByb2dyZXNzfVxyXG4gICAgICAgICAgICAgICAgc3RhdHVzPVwid2FybmluZ1wiXHJcbiAgICAgICAgICAgICAgICBpY29uPVwi4o+zXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxEYXNoYm9hcmRDYXJkXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkNhbmNlbGFkb3NcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e21ldHJpY3MuY2FuY2VsbGVkfVxyXG4gICAgICAgICAgICAgICAgc3RhdHVzPVwiZXJyb3JcIlxyXG4gICAgICAgICAgICAgICAgaWNvbj1cIuKclVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9TdGF0c0dyaWQ+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU2XDp8OjbyAyOiBCcmVha2Rvd24gcG9yIFRpcG8gZGUgT3BlcmHDp8OjbyAqL31cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAzMiwgZGlzcGxheTogXCJncmlkXCIsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwicmVwZWF0KGF1dG8tZml0LCBtaW5tYXgoMjgwcHgsIDFmcikpXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2IH19PlxyXG4gICAgICAgICAgICAgIDxoNCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiwgZm9udFdlaWdodDogNjAwLCBtYXJnaW46IFwiMCAwIDEycHhcIiB9fT5cclxuICAgICAgICAgICAgICAgIPCfk4ogUGVkaWRvcyBwb3IgVGlwb1xyXG4gICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgPE1ldHJpY3NSb3dcclxuICAgICAgICAgICAgICAgIG1ldHJpYz1cIkRlbGl2ZXJ5XCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXttZXRyaWNzLmRlbGl2ZXJ5T3JkZXJzfVxyXG4gICAgICAgICAgICAgICAgaWNvbj1cIvCfmpdcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPE1ldHJpY3NSb3dcclxuICAgICAgICAgICAgICAgIG1ldHJpYz1cIlJldGlyYWRhXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXttZXRyaWNzLnRha2VvdXRPcmRlcnN9XHJcbiAgICAgICAgICAgICAgICBpY29uPVwi8J+bje+4j1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8TWV0cmljc1Jvd1xyXG4gICAgICAgICAgICAgICAgbWV0cmljPVwiQ29uc3VtbyBubyBMb2NhbFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bWV0cmljcy5kaW5lSW5PcmRlcnN9XHJcbiAgICAgICAgICAgICAgICBpY29uPVwi8J+Nve+4j1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRmluYW5jZWlybyAqL31cclxuICAgICAgICAgICAge2ZpbmFuY2lhbCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICA8aDQgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCwgbWFyZ2luOiBcIjAgMCAxMnB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIPCfkrAgRmluYW5jZWlyb1xyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIDxNZXRyaWNzUm93XHJcbiAgICAgICAgICAgICAgICAgIG1ldHJpYz1cIkV2ZW50b3MgY29tIHJlcGFzc2VcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybWF0Q3VycmVuY3koZmluYW5jaWFsLnRvdGFsRmluYW5jaWFsRXZlbnRzV2l0aFRyYW5zZmVySW1wYWN0KX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8TWV0cmljc1JvdyBtZXRyaWM9XCJSZXBhc3NlcyByZWNlYmlkb3NcIiB2YWx1ZT17Zm9ybWF0Q3VycmVuY3koZmluYW5jaWFsLnRvdGFsU2V0dGxlbWVudHMpfSAvPlxyXG4gICAgICAgICAgICAgICAgPE1ldHJpY3NSb3dcclxuICAgICAgICAgICAgICAgICAgbWV0cmljPVwiRGl2ZXJnw6puY2lhXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbmFuY2lhbC5oYXNEaXNjcmVwYW5jeSA/IGZvcm1hdEN1cnJlbmN5KGZpbmFuY2lhbC5kaXNjcmVwYW5jeUFtb3VudCkgOiBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBSZXZpZXdzICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNiB9fT5cclxuICAgICAgICAgICAgICA8aDQgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCwgbWFyZ2luOiBcIjAgMCAxMnB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICDirZAgQXZhbGlhw6fDtWVzXHJcbiAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICA8TWV0cmljc1Jvd1xyXG4gICAgICAgICAgICAgICAgbWV0cmljPVwiUmF0aW5nIE3DqWRpb1wiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YXZnUmF0aW5nfVxyXG4gICAgICAgICAgICAgICAgaWNvbj1cIuKtkFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8TWV0cmljc1Jvd1xyXG4gICAgICAgICAgICAgICAgbWV0cmljPVwiVG90YWwgZGUgUmV2aWV3c1wiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cmV2aWV3cy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8TWV0cmljc1Jvd1xyXG4gICAgICAgICAgICAgICAgbWV0cmljPVwiUmVzcG9uZGlkYXNcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3Jlc3BvbmRlZFJldmlld3N9XHJcbiAgICAgICAgICAgICAgICB1bml0PXtgZGUgJHtyZXZpZXdzLmxlbmd0aH1gfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFNlw6fDo28gMzogUGVkaWRvcyBSZWNlbnRlcyAqL31cclxuICAgICAgICAgIHtvcmRlcnMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAzMiB9fT5cclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIG1hcmdpbkJvdHRvbTogMTIgfX0+XHJcbiAgICAgICAgICAgICAgICA8aDMgc3R5bGU9e3sgZm9udFNpemU6IFwiMXJlbVwiLCBmb250V2VpZ2h0OiA3MDAsIG1hcmdpbjogMCB9fT5cclxuICAgICAgICAgICAgICAgICAgUGVkaWRvcyBBYmVydG9zXHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPExpbmsgdG89XCIvaW50ZWdyYWNvZXMvaWZvb2QvcGVkaWRvc1wiIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIj5WZXIgdG9kb3Mg4oaSPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6IDAsIG92ZXJmbG93OiBcImhpZGRlblwiIH19PlxyXG4gICAgICAgICAgICAgICAgPHRhYmxlIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgYm9yZGVyQ29sbGFwc2U6IFwiY29sbGFwc2VcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ciBzdHlsZT17eyBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkIHZhcigtLWJvcmRlcilcIiwgYmFja2dyb3VuZDogXCJ2YXIoLS1zdXJmYWNlLTIpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGggc3R5bGU9e3sgcGFkZGluZzogMTIsIHRleHRBbGlnbjogXCJsZWZ0XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgZm9udFdlaWdodDogNjAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQZWRpZG9cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGggc3R5bGU9e3sgcGFkZGluZzogMTIsIHRleHRBbGlnbjogXCJsZWZ0XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgZm9udFdlaWdodDogNjAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTdGF0dXNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGggc3R5bGU9e3sgcGFkZGluZzogMTIsIHRleHRBbGlnbjogXCJsZWZ0XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgZm9udFdlaWdodDogNjAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUaXBvXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoIHN0eWxlPXt7IHBhZGRpbmc6IDEyLCB0ZXh0QWxpZ246IFwicmlnaHRcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiLCBmb250V2VpZ2h0OiA2MDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFZhbG9yXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoIHN0eWxlPXt7IHBhZGRpbmc6IDEyLCB0ZXh0QWxpZ246IFwibGVmdFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgSG9yw6FyaW9cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIHtvcmRlcnMuc2xpY2UoMCwgNSkubWFwKChvcmRlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3RhdHVzSW5mbyA9IGZvcm1hdE9yZGVyU3RhdHVzKG9yZGVyLnN0YXR1cyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e29yZGVyLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgdmFyKC0tYm9yZGVyKVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgc3R5bGU9e3sgcGFkZGluZzogMTIsIGZvbnRTaXplOiBcIjAuOXJlbVwiLCBmb250V2VpZ2h0OiA2MDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3JkZXIuZGlzcGxheUlkIHx8IG9yZGVyLmlmb29kT3JkZXJJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT17eyBwYWRkaW5nOiAxMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC44cmVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCI0cHggOHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHN0YXR1c0luZm8uY29sb3IgKyBcIjIwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHN0YXR1c0luZm8uY29sb3IsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNjAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzSW5mby5pY29ufSB7c3RhdHVzSW5mby5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT17eyBwYWRkaW5nOiAxMiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7T1JERVJfVFlQRV9MQUJFTFNbb3JkZXIuaWZvb2RPcmRlclR5cGVdID8/IFwi8J+Nve+4jyBMb2NhbFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt7IHBhZGRpbmc6IDEyLCB0ZXh0QWxpZ246IFwicmlnaHRcIiwgZm9udFNpemU6IFwiMC45cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShvcmRlci50b3RhbEFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgc3R5bGU9e3sgcGFkZGluZzogMTIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFRpbWUob3JkZXIuY3JlYXRlZEF0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogU2XDp8OjbyA0OiBMaW5rcyBSw6FwaWRvcyAqL31cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAzMiB9fT5cclxuICAgICAgICAgICAgPGgzIHN0eWxlPXt7IGZvbnRTaXplOiBcIjFyZW1cIiwgZm9udFdlaWdodDogNzAwLCBtYXJnaW5Cb3R0b206IDEyIH19PkFjZXNzbyBSw6FwaWRvPC9oMz5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCJyZXBlYXQoYXV0by1maXQsIG1pbm1heCgyMDBweCwgMWZyKSlcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICAgICAgICA8TGluayB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZC9zdGF0dXNcIiBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1zdGFydFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICDwn5SNIFN0YXR1cyAmIFZhbGlkYcOnw7Vlc1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2ludGVncmFjb2VzL2lmb29kL3BlZGlkb3NcIiBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1zdGFydFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICDwn5OmIEdlcmVuY2lhciBQZWRpZG9zXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPExpbmsgdG89XCIvaW50ZWdyYWNvZXMvaWZvb2QvZmluYW5jZWlyby9yZWxhdG9yaW9zXCIgc3R5bGU9e3sgdGV4dERlY29yYXRpb246IFwibm9uZVwiIH19PlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtc3RhcnRcIiB9fT5cclxuICAgICAgICAgICAgICAgICAg8J+SsCBGaW5hbmNlaXJvIERldGFsaGFkb1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2ludGVncmFjb2VzL2lmb29kL2F2YWxpYWNvZXNcIiBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1zdGFydFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICDirZAgUmVzcG9zdGFzIGRlIEF2YWxpYcOnw7Vlc1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2ludGVncmFjb2VzL2lmb29kL2xvZ2lzdGljYVwiIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiB9fT5cclxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LXN0YXJ0XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIPCfmpcgU3RhdHVzIGRlIEVudHJlZ2FzXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPExpbmsgdG89XCIvaW50ZWdyYWNvZXMvaWZvb2QvaW5kaWNhZG9yZXNcIiBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1zdGFydFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICDwn5OKIEluZGljYWRvcmVzIEFuYWx5dGljc1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2ludGVncmF0aW9ucy9JRm9vZERhc2hib2FyZFBhZ2UudHN4In0=