import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodStatusDetailedPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getIFoodMerchantStatus, getIFoodMerchantStatusByOperation } from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { Button } from "/src/ui/Button.tsx";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { Tabs } from "/src/components/Tabs.tsx";
import { Alert } from "/src/components/Alert.tsx";
import { DashboardCard } from "/src/components/DashboardCard.tsx";
import { formatMerchantAvailability, formatValidationState } from "/src/utils/ifoodFormattersEnhanced.ts";
const OPERATION_LABELS = {
  DELIVERY: "🚗 Delivery",
  TAKEOUT: "🛍️ Retirada",
  DINE_IN: "🍽️ Consumo no local"
};
function formatOperationLabel(operation) {
  return OPERATION_LABELS[operation] ?? operation;
}
function getOperationButtonStyle(op, selectedOperation) {
  const isSelected = selectedOperation === op;
  return {
    padding: 12,
    borderRadius: 8,
    border: isSelected ? "2px solid var(--accent)" : "1px solid var(--border)",
    background: isSelected ? "var(--surface-2)" : "var(--surface-1)",
    cursor: "pointer",
    fontSize: "0.95rem",
    fontWeight: isSelected ? 700 : 500,
    transition: "all 0.2s"
  };
}
function ValidationSummaryBadges({
  errorCount,
  warningCount,
  color
}) {
  if (errorCount === 0 && warningCount === 0) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12 }, children: [
    errorCount > 0 && /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          padding: 12,
          borderRadius: 6,
          background: "rgba(0,0,0,0.1)",
          borderLeft: "3px solid #ef4444"
        },
        children: /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.85rem", margin: 0, fontWeight: 600, color }, children: [
          "✕ ",
          errorCount,
          " Erro",
          errorCount > 1 ? "s" : ""
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
          lineNumber: 98,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 90,
        columnNumber: 7
      },
      this
    ),
    warningCount > 0 && /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          padding: 12,
          borderRadius: 6,
          background: "rgba(0,0,0,0.1)",
          borderLeft: "3px solid #f59e0b"
        },
        children: /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.85rem", margin: 0, fontWeight: 600, color }, children: [
          "⚠ ",
          warningCount,
          " Aviso",
          warningCount > 1 ? "s" : ""
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
          lineNumber: 112,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 104,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
    lineNumber: 88,
    columnNumber: 5
  }, this);
}
_c = ValidationSummaryBadges;
function StatusHeaderCard({
  operationState,
  statusDisplay,
  errorCount,
  warningCount
}) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      style: {
        padding: 24,
        borderRadius: 8,
        background: statusDisplay.bg,
        border: `3px solid ${statusDisplay.color}`,
        marginBottom: 24,
        display: "grid",
        gap: 16
      },
      children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 16, alignItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "3rem" }, children: statusDisplay.icon }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
              lineNumber: 147,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "p",
                {
                  style: {
                    fontSize: "0.9rem",
                    color: statusDisplay.color,
                    margin: "0 0 4px",
                    fontWeight: 600,
                    opacity: 0.8
                  },
                  children: "ESTADO GERAL"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
                  lineNumber: 149,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("h1", { style: { fontSize: "2.2rem", margin: 0, color: statusDisplay.color, fontWeight: 800 }, children: statusDisplay.label }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
                lineNumber: 160,
                columnNumber: 13
              }, this),
              operationState && /* @__PURE__ */ jsxDEV(
                "p",
                {
                  style: {
                    fontSize: "0.95rem",
                    color: statusDisplay.color,
                    margin: "8px 0 0",
                    opacity: 0.9,
                    fontWeight: 500
                  },
                  children: operationState
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
                  lineNumber: 164,
                  columnNumber: 13
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
              lineNumber: 148,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
            lineNumber: 146,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "⏸️ Gerenciar interrupções" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
            lineNumber: 182,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
            lineNumber: 181,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
          lineNumber: 145,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(ValidationSummaryBadges, { errorCount, warningCount, color: statusDisplay.color }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
          lineNumber: 186,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 134,
      columnNumber: 5
    },
    this
  );
}
_c2 = StatusHeaderCard;
function GeneralValidationsTab({ validations }) {
  if (validations.length === 0) {
    return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12, marginTop: 16 }, children: /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 32, textAlign: "center" }, children: /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "1.1rem", fontWeight: 600, color: "var(--ink-faint)", margin: 0 }, children: "✓ Tudo certo! Nenhuma validação pendente." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 197,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 196,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 195,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12, marginTop: 16 }, children: validations.map((validation) => {
    const display = formatValidationState(validation.state);
    return /* @__PURE__ */ jsxDEV(
      Alert,
      {
        variant: display.severity,
        title: validation.id,
        message: /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, marginBottom: 4 }, children: [
            display.icon,
            " ",
            display.label
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
            lineNumber: 216,
            columnNumber: 17
          }, this),
          validation.message && /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.9rem", marginTop: 8, opacity: 0.9 }, children: validation.message }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
            lineNumber: 220,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
          lineNumber: 215,
          columnNumber: 13
        }, this)
      },
      validation.id,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 210,
        columnNumber: 11
      },
      this
    );
  }) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
    lineNumber: 206,
    columnNumber: 5
  }, this);
}
_c3 = GeneralValidationsTab;
function OperationButtons({
  operations,
  selectedOperation,
  onSelect
}) {
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 12, marginBottom: 24 }, children: operations.map(
    (op) => /* @__PURE__ */ jsxDEV("button", { onClick: () => onSelect(op), style: getOperationButtonStyle(op, selectedOperation), children: formatOperationLabel(op) }, op, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 246,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
    lineNumber: 244,
    columnNumber: 5
  }, this);
}
_c4 = OperationButtons;
function OperationValidationsList({
  validations,
  operationLabel
}) {
  if (validations.length === 0) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16 }, children: [
    /* @__PURE__ */ jsxDEV("h4", { style: { fontSize: "0.95rem", fontWeight: 700, margin: "0 0 12px" }, children: [
      "Validações - ",
      operationLabel
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 268,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: validations.map((v) => {
      const display = formatValidationState(v.state);
      return /* @__PURE__ */ jsxDEV(
        Alert,
        {
          variant: display.severity,
          title: v.id,
          message: /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600 }, children: [
              display.icon,
              " ",
              display.label
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
              lineNumber: 281,
              columnNumber: 19
            }, this),
            v.message && /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", marginTop: 4 }, children: v.message }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
              lineNumber: 285,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
            lineNumber: 280,
            columnNumber: 15
          }, this)
        },
        v.id,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
          lineNumber: 275,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 271,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
    lineNumber: 267,
    columnNumber: 5
  }, this);
}
_c5 = OperationValidationsList;
function OperationStatusDetails({
  isLoading,
  isError,
  error,
  operationData,
  selectedOperation
}) {
  if (isLoading) {
    return /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", padding: "20px" }, children: /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)" }, children: "Carregando detalhes da operação..." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 316,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 315,
      columnNumber: 7
    }, this);
  }
  if (isError) {
    return /* @__PURE__ */ jsxDEV(QueryError, { error, what: `status da operação ${selectedOperation}` }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 322,
      columnNumber: 12
    }, this);
  }
  if (!operationData) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 16 }, children: [
    /* @__PURE__ */ jsxDEV(
      DashboardCard,
      {
        title: `${formatOperationLabel(selectedOperation)} - Status`,
        value: operationData.available ? "Disponível" : "Indisponível",
        status: operationData.available ? "success" : "error",
        icon: operationData.available ? "✓" : "✕",
        subtitle: operationData.state || "—"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 332,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      OperationValidationsList,
      {
        validations: operationData.validations ?? [],
        operationLabel: formatOperationLabel(selectedOperation)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 341,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
    lineNumber: 330,
    columnNumber: 5
  }, this);
}
_c6 = OperationStatusDetails;
function OperationsTab({
  availableOperations,
  selectedOperation,
  onSelectOperation,
  operationStatusQuery,
  operationData
}) {
  return /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 16 }, children: [
    /* @__PURE__ */ jsxDEV(
      OperationButtons,
      {
        operations: availableOperations,
        selectedOperation,
        onSelect: onSelectOperation
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 365,
        columnNumber: 7
      },
      this
    ),
    selectedOperation && /* @__PURE__ */ jsxDEV(
      OperationStatusDetails,
      {
        isLoading: operationStatusQuery.isLoading,
        isError: operationStatusQuery.isError,
        error: operationStatusQuery.error,
        operationData,
        selectedOperation
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 372,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
    lineNumber: 364,
    columnNumber: 5
  }, this);
}
_c7 = OperationsTab;
export function IFoodStatusDetailedPage() {
  _s();
  const { branchId } = useAuthStore();
  const [activeTab, setActiveTab] = useState("geral");
  const [selectedOperation, setSelectedOperation] = useState(null);
  const statusQuery = useQuery({
    queryKey: ["integrations", "ifood", "status-detailed", branchId],
    queryFn: () => getIFoodMerchantStatus(branchId),
    refetchInterval: 3e4
  });
  const operationStatusQuery = useQuery({
    queryKey: ["integrations", "ifood", "status-by-operation", branchId, selectedOperation],
    queryFn: () => getIFoodMerchantStatusByOperation(branchId, selectedOperation),
    enabled: !!selectedOperation
  });
  const data = statusQuery.data;
  const operationData = operationStatusQuery.data;
  if (statusQuery.isLoading) {
    return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1200, margin: "0 auto" }, children: [
      /* @__PURE__ */ jsxDEV(
        PageHeader,
        {
          title: "Status & Disponibilidade",
          subtitle: "Detalhes completos e operações por tipo",
          breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
          lineNumber: 407,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", padding: "40px 20px" }, children: /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)" }, children: "Carregando informações de status..." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 413,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 412,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 406,
      columnNumber: 7
    }, this);
  }
  if (statusQuery.isError) {
    return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1200, margin: "0 auto" }, children: [
      /* @__PURE__ */ jsxDEV(
        PageHeader,
        {
          title: "Status & Disponibilidade",
          subtitle: "Detalhes completos e operações por tipo",
          breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
          lineNumber: 422,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(QueryError, { error: statusQuery.error, what: "o status detalhado" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 427,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 421,
      columnNumber: 7
    }, this);
  }
  if (!data) {
    return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1200, margin: "0 auto" }, children: [
      /* @__PURE__ */ jsxDEV(
        PageHeader,
        {
          title: "Status & Disponibilidade",
          subtitle: "Detalhes completos e operações por tipo",
          breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
          lineNumber: 435,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(EmptyState, { title: "Sem status", description: "Não foi possível obter informações de status da loja." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 440,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
      lineNumber: 434,
      columnNumber: 7
    }, this);
  }
  const statusDisplay = formatMerchantAvailability(data.available, data.operationState);
  const validations = data.validations || [];
  const errorValidations = validations.filter((v) => formatValidationState(v.state).severity === "error");
  const warningValidations = validations.filter((v) => formatValidationState(v.state).severity === "warning");
  const availableOperations = ["DELIVERY", "TAKEOUT", "DINE_IN"];
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1200, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "Status & Disponibilidade",
        subtitle: "Detalhes completos e operações por tipo",
        breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }],
        actions: /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            onClick: () => statusQuery.refetch(),
            disabled: statusQuery.isRefetching,
            children: [
              "🔄 ",
              statusQuery.isRefetching ? "Atualizando..." : "Atualizar agora"
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
            lineNumber: 463,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 458,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      StatusHeaderCard,
      {
        operationState: data.operationState,
        statusDisplay,
        errorCount: errorValidations.length,
        warningCount: warningValidations.length
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 474,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Tabs,
      {
        tabs: [
          { id: "geral", label: "Validações Gerais", badge: validations.length },
          { id: "operacoes", label: "Por Operação", badge: availableOperations.length }
        ],
        activeTab,
        onTabChange: setActiveTab,
        children: [
          activeTab === "geral" && /* @__PURE__ */ jsxDEV(GeneralValidationsTab, { validations }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
            lineNumber: 491,
            columnNumber: 35
          }, this),
          activeTab === "operacoes" && /* @__PURE__ */ jsxDEV(
            OperationsTab,
            {
              availableOperations,
              selectedOperation,
              onSelectOperation: setSelectedOperation,
              operationStatusQuery: {
                isLoading: operationStatusQuery.isLoading,
                isError: operationStatusQuery.isError,
                error: operationStatusQuery.error
              },
              operationData
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
              lineNumber: 495,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 482,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          marginTop: 32,
          padding: 16,
          borderRadius: 8,
          background: "var(--surface-2)",
          display: "grid",
          gap: 12
        },
        children: [
          /* @__PURE__ */ jsxDEV("p", { style: { margin: "0 0 8px", fontSize: "0.9rem", fontWeight: 600 }, children: "Outras operações" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
            lineNumber: 520,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
                gap: 8
              },
              children: [
                /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/pedidos", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", style: { width: "100%" }, children: "📦 Gerenciar Pedidos" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
                  lineNumber: 531,
                  columnNumber: 13
                }, this) }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
                  lineNumber: 530,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/financeiro/relatorios", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", style: { width: "100%" }, children: "💰 Financeiro" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
                  lineNumber: 536,
                  columnNumber: 13
                }, this) }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
                  lineNumber: 535,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/avaliacoes", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", style: { width: "100%" }, children: "⭐ Avaliações" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
                  lineNumber: 541,
                  columnNumber: 13
                }, this) }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
                  lineNumber: 540,
                  columnNumber: 11
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
              lineNumber: 523,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
        lineNumber: 510,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx",
    lineNumber: 457,
    columnNumber: 5
  }, this);
}
_s(IFoodStatusDetailedPage, "HXOGvRypEbSVfOZhCyXAIVVVXAs=", false, function() {
  return [useAuthStore, useQuery, useQuery];
});
_c8 = IFoodStatusDetailedPage;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
$RefreshReg$(_c, "ValidationSummaryBadges");
$RefreshReg$(_c2, "StatusHeaderCard");
$RefreshReg$(_c3, "GeneralValidationsTab");
$RefreshReg$(_c4, "OperationButtons");
$RefreshReg$(_c5, "OperationValidationsList");
$RefreshReg$(_c6, "OperationStatusDetails");
$RefreshReg$(_c7, "OperationsTab");
$RefreshReg$(_c8, "IFoodStatusDetailedPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodStatusDetailedPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEVVLFNBc0xNLFVBdExOOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdFVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msd0JBQXdCQyx5Q0FBeUM7QUFDMUUsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyw0QkFBNEJDLDZCQUE2QjtBQUVsRSxNQUFNQyxtQkFBMkM7QUFBQSxFQUMvQ0MsVUFBVTtBQUFBLEVBQ1ZDLFNBQVM7QUFBQSxFQUNUQyxTQUFTO0FBQ1g7QUFnQkEsU0FBU0MscUJBQXFCQyxXQUEyQjtBQUN2RCxTQUFPTCxpQkFBaUJLLFNBQVMsS0FBS0E7QUFDeEM7QUFFQSxTQUFTQyx3QkFBd0JDLElBQVlDLG1CQUFpRDtBQUM1RixRQUFNQyxhQUFhRCxzQkFBc0JEO0FBQ3pDLFNBQU87QUFBQSxJQUNMRyxTQUFTO0FBQUEsSUFDVEMsY0FBYztBQUFBLElBQ2RDLFFBQVFILGFBQWEsNEJBQTRCO0FBQUEsSUFDakRJLFlBQVlKLGFBQWEscUJBQXFCO0FBQUEsSUFDOUNLLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsWUFBWVAsYUFBYSxNQUFNO0FBQUEsSUFDL0JRLFlBQVk7QUFBQSxFQUNkO0FBQ0Y7QUFHQSxTQUFTQyx3QkFBd0I7QUFBQSxFQUMvQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFLRixHQUFHO0FBQ0QsTUFBSUYsZUFBZSxLQUFLQyxpQkFBaUIsR0FBRztBQUMxQyxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUVFLFNBQVMsUUFBUUMscUJBQXFCLHdDQUF3Q0MsS0FBSyxHQUFHLEdBQ2pHTDtBQUFBQSxpQkFBYSxLQUNaO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPO0FBQUEsVUFDTFQsU0FBUztBQUFBLFVBQ1RDLGNBQWM7QUFBQSxVQUNkRSxZQUFZO0FBQUEsVUFDWlksWUFBWTtBQUFBLFFBQ2Q7QUFBQSxRQUVBLGlDQUFDLE9BQUUsT0FBTyxFQUFFVixVQUFVLFdBQVdXLFFBQVEsR0FBR1YsWUFBWSxLQUFLSyxNQUFNLEdBQUc7QUFBQTtBQUFBLFVBQ2pFRjtBQUFBQSxVQUFXO0FBQUEsVUFBTUEsYUFBYSxJQUFJLE1BQU07QUFBQSxhQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBLE1BVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV0E7QUFBQSxJQUVEQyxlQUFlLEtBQ2Q7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU87QUFBQSxVQUNMVixTQUFTO0FBQUEsVUFDVEMsY0FBYztBQUFBLFVBQ2RFLFlBQVk7QUFBQSxVQUNaWSxZQUFZO0FBQUEsUUFDZDtBQUFBLFFBRUEsaUNBQUMsT0FBRSxPQUFPLEVBQUVWLFVBQVUsV0FBV1csUUFBUSxHQUFHVixZQUFZLEtBQUtLLE1BQU0sR0FBRztBQUFBO0FBQUEsVUFDakVEO0FBQUFBLFVBQWE7QUFBQSxVQUFPQSxlQUFlLElBQUksTUFBTTtBQUFBLGFBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFXQTtBQUFBLE9BM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkE7QUFFSjtBQUVBTyxLQS9DU1Q7QUFnRFQsU0FBU1UsaUJBQWlCO0FBQUEsRUFDeEJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FYO0FBQUFBLEVBQ0FDO0FBTUYsR0FBRztBQUNELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE9BQU87QUFBQSxRQUNMVixTQUFTO0FBQUEsUUFDVEMsY0FBYztBQUFBLFFBQ2RFLFlBQVlpQixjQUFjQztBQUFBQSxRQUMxQm5CLFFBQVEsYUFBYWtCLGNBQWNULEtBQUs7QUFBQSxRQUN4Q1csY0FBYztBQUFBLFFBQ2RWLFNBQVM7QUFBQSxRQUNURSxLQUFLO0FBQUEsTUFDUDtBQUFBLE1BRUE7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRUYsU0FBUyxRQUFRVyxnQkFBZ0IsaUJBQWlCQyxZQUFZLGFBQWEsR0FDdkY7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRVosU0FBUyxRQUFRRSxLQUFLLElBQUlVLFlBQVksU0FBUyxHQUMzRDtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFbkIsVUFBVSxPQUFPLEdBQUllLHdCQUFjSyxRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLFlBQ3RELHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPO0FBQUEsb0JBQ0xwQixVQUFVO0FBQUEsb0JBQ1ZNLE9BQU9TLGNBQWNUO0FBQUFBLG9CQUNyQkssUUFBUTtBQUFBLG9CQUNSVixZQUFZO0FBQUEsb0JBQ1pvQixTQUFTO0FBQUEsa0JBQ1g7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsT0FBTyxFQUFFckIsVUFBVSxVQUFVVyxRQUFRLEdBQUdMLE9BQU9TLGNBQWNULE9BQU9MLFlBQVksSUFBSSxHQUNyRmMsd0JBQWNPLFNBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNDUixrQkFDQztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPO0FBQUEsb0JBQ0xkLFVBQVU7QUFBQSxvQkFDVk0sT0FBT1MsY0FBY1Q7QUFBQUEsb0JBQ3JCSyxRQUFRO0FBQUEsb0JBQ1JVLFNBQVM7QUFBQSxvQkFDVHBCLFlBQVk7QUFBQSxrQkFDZDtBQUFBLGtCQUVDYTtBQUFBQTtBQUFBQSxnQkFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FVQTtBQUFBLGlCQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLGVBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBO0FBQUEsVUFJQSx1QkFBQyxRQUFLLElBQUcsc0JBQXFCLE9BQU8sRUFBRVMsZ0JBQWdCLE9BQU8sR0FDNUQsaUNBQUMsVUFBTyxTQUFRLFNBQVEseUNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlELEtBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUNBO0FBQUEsUUFFQSx1QkFBQywyQkFBd0IsWUFBd0IsY0FBNEIsT0FBT1IsY0FBY1QsU0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RztBQUFBO0FBQUE7QUFBQSxJQXBEMUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBcURBO0FBRUo7QUFFQWtCLE1BckVTWDtBQXNFVCxTQUFTWSxzQkFBc0IsRUFBRUMsWUFBK0MsR0FBRztBQUNqRixNQUFJQSxZQUFZQyxXQUFXLEdBQUc7QUFDNUIsV0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRXBCLFNBQVMsUUFBUUUsS0FBSyxJQUFJbUIsV0FBVyxHQUFHLEdBQ3BELGlDQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRWpDLFNBQVMsSUFBSWtDLFdBQVcsU0FBUyxHQUM5RCxpQ0FBQyxPQUFFLE9BQU8sRUFBRTdCLFVBQVUsVUFBVUMsWUFBWSxLQUFLSyxPQUFPLG9CQUFvQkssUUFBUSxFQUFFLEdBQUcseURBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFSixTQUFTLFFBQVFFLEtBQUssSUFBSW1CLFdBQVcsR0FBRyxHQUNuREYsc0JBQVlJLElBQUksQ0FBQ0MsZUFBZTtBQUMvQixVQUFNeEIsVUFBVXZCLHNCQUFzQitDLFdBQVdDLEtBQUs7QUFDdEQsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBRUMsU0FBU3pCLFFBQVEwQjtBQUFBQSxRQUNqQixPQUFPRixXQUFXRztBQUFBQSxRQUNsQixTQUNFLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRWpDLFlBQVksS0FBS2dCLGNBQWMsRUFBRSxHQUM1Q1Y7QUFBQUEsb0JBQVFhO0FBQUFBLFlBQUs7QUFBQSxZQUFFYixRQUFRZTtBQUFBQSxlQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ1MsV0FBV0ksV0FDVix1QkFBQyxTQUFJLE9BQU8sRUFBRW5DLFVBQVUsVUFBVTRCLFdBQVcsR0FBR1AsU0FBUyxJQUFJLEdBQzFEVSxxQkFBV0ksV0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQTtBQUFBLE1BYkdKLFdBQVdHO0FBQUFBLE1BRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFlRztBQUFBLEVBR1AsQ0FBQyxLQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFFQUUsTUF6Q1NYO0FBMENULFNBQVNZLGlCQUFpQjtBQUFBLEVBQ3hCQztBQUFBQSxFQUNBN0M7QUFBQUEsRUFDQThDO0FBS0YsR0FBRztBQUNELFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUVoQyxTQUFTLFFBQVFDLHFCQUFxQix3Q0FBd0NDLEtBQUssSUFBSVEsY0FBYyxHQUFHLEdBQ25IcUIscUJBQVdSO0FBQUFBLElBQUksQ0FBQ3RDLE9BQ2YsdUJBQUMsWUFBZ0IsU0FBUyxNQUFNK0MsU0FBUy9DLEVBQUUsR0FBRyxPQUFPRCx3QkFBd0JDLElBQUlDLGlCQUFpQixHQUMvRkosK0JBQXFCRyxFQUFFLEtBRGJBLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVKO0FBRUFnRCxNQXBCU0g7QUFxQlQsU0FBU0kseUJBQXlCO0FBQUEsRUFDaENmO0FBQUFBLEVBQ0FnQjtBQUlGLEdBQUc7QUFDRCxNQUFJaEIsWUFBWUMsV0FBVyxHQUFHO0FBQzVCLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVoQyxTQUFTLEdBQUcsR0FDekM7QUFBQSwyQkFBQyxRQUFHLE9BQU8sRUFBRUssVUFBVSxXQUFXQyxZQUFZLEtBQUtVLFFBQVEsV0FBVyxHQUFHO0FBQUE7QUFBQSxNQUN6RCtCO0FBQUFBLFNBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVuQyxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUNuQ2lCLHNCQUFZSSxJQUFJLENBQUNhLE1BQU07QUFDdEIsWUFBTXBDLFVBQVV2QixzQkFBc0IyRCxFQUFFWCxLQUFLO0FBQzdDLGFBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFNBQVN6QixRQUFRMEI7QUFBQUEsVUFDakIsT0FBT1UsRUFBRVQ7QUFBQUEsVUFDVCxTQUNFLG1DQUNFO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUVqQyxZQUFZLElBQUksR0FDM0JNO0FBQUFBLHNCQUFRYTtBQUFBQSxjQUFLO0FBQUEsY0FBRWIsUUFBUWU7QUFBQUEsaUJBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNDcUIsRUFBRVIsV0FDRCx1QkFBQyxTQUFJLE9BQU8sRUFBRW5DLFVBQVUsV0FBVzRCLFdBQVcsRUFBRSxHQUM3Q2UsWUFBRVIsV0FETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUE7QUFBQSxRQWJHUSxFQUFFVDtBQUFBQSxRQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFlRztBQUFBLElBR1AsQ0FBQyxLQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsT0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQTtBQUVKO0FBRUFVLE1BNUNTSDtBQTZDVCxTQUFTSSx1QkFBdUI7QUFBQSxFQUM5QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQXhEO0FBT0YsR0FBRztBQUNELE1BQUlxRCxXQUFXO0FBQ2IsV0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRWpCLFdBQVcsVUFBVWxDLFNBQVMsT0FBTyxHQUNqRCxpQ0FBQyxPQUFFLE9BQU8sRUFBRVcsT0FBTyxtQkFBbUIsR0FBRyxrREFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRSxLQUQ3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsTUFBSXlDLFNBQVM7QUFDWCxXQUFPLHVCQUFDLGNBQVcsT0FBYyxNQUFNLHNCQUFzQnRELGlCQUFpQixNQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBFO0FBQUEsRUFDbkY7QUFFQSxNQUFJLENBQUN3RCxlQUFlO0FBQ2xCLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRTFDLFNBQVMsUUFBUUUsS0FBSyxHQUFHLEdBRXJDO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU8sR0FBR3BCLHFCQUFxQkksaUJBQWlCLENBQUM7QUFBQSxRQUNqRCxPQUFPd0QsY0FBY0MsWUFBWSxlQUFlO0FBQUEsUUFDaEQsUUFBUUQsY0FBY0MsWUFBWSxZQUFZO0FBQUEsUUFDOUMsTUFBTUQsY0FBY0MsWUFBWSxNQUFNO0FBQUEsUUFDdEMsVUFBVUQsY0FBY2pCLFNBQVM7QUFBQTtBQUFBLE1BTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUt1QztBQUFBLElBSXZDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxhQUFhaUIsY0FBY3ZCLGVBQWU7QUFBQSxRQUMxQyxnQkFBZ0JyQyxxQkFBcUJJLGlCQUFpQjtBQUFBO0FBQUEsTUFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRTBEO0FBQUEsT0FiNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBO0FBRUo7QUFFQTBELE1BakRTTjtBQWtEVCxTQUFTTyxjQUFjO0FBQUEsRUFDckJDO0FBQUFBLEVBQ0E1RDtBQUFBQSxFQUNBNkQ7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQU47QUFPRixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRXJCLFdBQVcsR0FBRyxHQUMxQjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxZQUFZeUI7QUFBQUEsUUFDWjtBQUFBLFFBQ0EsVUFBVUM7QUFBQUE7QUFBQUEsTUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHOEI7QUFBQSxJQUc3QjdELHFCQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXOEQscUJBQXFCVDtBQUFBQSxRQUNoQyxTQUFTUyxxQkFBcUJSO0FBQUFBLFFBQzlCLE9BQU9RLHFCQUFxQlA7QUFBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUE7QUFBQSxNQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUt1QztBQUFBLE9BYjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFDUSxNQWhDUUo7QUFrQ0YsZ0JBQVNLLDBCQUEwQjtBQUFBQyxLQUFBO0FBQ3hDLFFBQU0sRUFBRUMsU0FBUyxJQUFJcEYsYUFBYTtBQUNsQyxRQUFNLENBQUNxRixXQUFXQyxZQUFZLElBQUkzRixTQUFTLE9BQU87QUFDbEQsUUFBTSxDQUFDdUIsbUJBQW1CcUUsb0JBQW9CLElBQUk1RixTQUF3QixJQUFJO0FBRTlFLFFBQU02RixjQUFjM0YsU0FBUztBQUFBLElBQzNCNEYsVUFBVSxDQUFDLGdCQUFnQixTQUFTLG1CQUFtQkwsUUFBUTtBQUFBLElBQy9ETSxTQUFTQSxNQUFNNUYsdUJBQXVCc0YsUUFBUTtBQUFBLElBQzlDTyxpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTVgsdUJBQXVCbkYsU0FBUztBQUFBLElBQ3BDNEYsVUFBVSxDQUFDLGdCQUFnQixTQUFTLHVCQUF1QkwsVUFBVWxFLGlCQUFpQjtBQUFBLElBQ3RGd0UsU0FBU0EsTUFBTTNGLGtDQUFrQ3FGLFVBQVVsRSxpQkFBa0I7QUFBQSxJQUM3RTBFLFNBQVMsQ0FBQyxDQUFDMUU7QUFBQUEsRUFDYixDQUFDO0FBRUQsUUFBTTJFLE9BQU9MLFlBQVlLO0FBQ3pCLFFBQU1uQixnQkFBZ0JNLHFCQUFxQmE7QUFFM0MsTUFBSUwsWUFBWWpCLFdBQVc7QUFDekIsV0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRW5ELFNBQVMsSUFBSTBFLFVBQVUsTUFBTTFELFFBQVEsU0FBUyxHQUMzRDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixVQUFTO0FBQUEsVUFDVCxZQUFZLENBQUMsRUFBRVcsT0FBTyxTQUFTZ0QsTUFBTSxxQkFBcUIsQ0FBQztBQUFBO0FBQUEsUUFIN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRytEO0FBQUEsTUFFL0QsdUJBQUMsU0FBSSxPQUFPLEVBQUV6QyxXQUFXLFVBQVVsQyxTQUFTLFlBQVksR0FDdEQsaUNBQUMsT0FBRSxPQUFPLEVBQUVXLE9BQU8sbUJBQW1CLEdBQUcsbURBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEUsS0FEOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxFQUVKO0FBRUEsTUFBSXlELFlBQVloQixTQUFTO0FBQ3ZCLFdBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUVwRCxTQUFTLElBQUkwRSxVQUFVLE1BQU0xRCxRQUFRLFNBQVMsR0FDM0Q7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sVUFBUztBQUFBLFVBQ1QsWUFBWSxDQUFDLEVBQUVXLE9BQU8sU0FBU2dELE1BQU0scUJBQXFCLENBQUM7QUFBQTtBQUFBLFFBSDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUcrRDtBQUFBLE1BRS9ELHVCQUFDLGNBQVcsT0FBT1AsWUFBWWYsT0FBTyxNQUFLLHdCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsU0FOakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsRUFFSjtBQUVBLE1BQUksQ0FBQ29CLE1BQU07QUFDVCxXQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFekUsU0FBUyxJQUFJMEUsVUFBVSxNQUFNMUQsUUFBUSxTQUFTLEdBQzNEO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLFVBQVM7QUFBQSxVQUNULFlBQVksQ0FBQyxFQUFFVyxPQUFPLFNBQVNnRCxNQUFNLHFCQUFxQixDQUFDO0FBQUE7QUFBQSxRQUg3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHK0Q7QUFBQSxNQUUvRCx1QkFBQyxjQUFXLE9BQU0sY0FBYSxhQUFZLDJEQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtHO0FBQUEsU0FOcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsRUFFSjtBQUVBLFFBQU12RCxnQkFBZ0JoQywyQkFBMkJxRixLQUFLbEIsV0FBV2tCLEtBQUt0RCxjQUFjO0FBQ3BGLFFBQU1ZLGNBQWMwQyxLQUFLMUMsZUFBZTtBQUd4QyxRQUFNNkMsbUJBQW1CN0MsWUFBWThDLE9BQU8sQ0FBQzdCLE1BQU0zRCxzQkFBc0IyRCxFQUFFWCxLQUFLLEVBQUVDLGFBQWEsT0FBTztBQUN0RyxRQUFNd0MscUJBQXFCL0MsWUFBWThDLE9BQU8sQ0FBQzdCLE1BQU0zRCxzQkFBc0IyRCxFQUFFWCxLQUFLLEVBQUVDLGFBQWEsU0FBUztBQUkxRyxRQUFNb0Isc0JBQXNCLENBQUMsWUFBWSxXQUFXLFNBQVM7QUFFN0QsU0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRTFELFNBQVMsSUFBSTBFLFVBQVUsTUFBTTFELFFBQVEsU0FBUyxHQUMzRDtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixVQUFTO0FBQUEsUUFDVCxZQUFZLENBQUMsRUFBRVcsT0FBTyxTQUFTZ0QsTUFBTSxxQkFBcUIsQ0FBQztBQUFBLFFBQzNELFNBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLFNBQVMsTUFBTVAsWUFBWVcsUUFBUTtBQUFBLFlBQ25DLFVBQVVYLFlBQVlZO0FBQUFBLFlBQWE7QUFBQTtBQUFBLGNBRS9CWixZQUFZWSxlQUFlLG1CQUFtQjtBQUFBO0FBQUE7QUFBQSxVQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBO0FBQUEsTUFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZRztBQUFBLElBSUg7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLGdCQUFnQlAsS0FBS3REO0FBQUFBLFFBQ3JCO0FBQUEsUUFDQSxZQUFZeUQsaUJBQWlCNUM7QUFBQUEsUUFDN0IsY0FBYzhDLG1CQUFtQjlDO0FBQUFBO0FBQUFBLE1BSm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUkwQztBQUFBLElBSTFDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNO0FBQUEsVUFDSixFQUFFTyxJQUFJLFNBQVNaLE9BQU8scUJBQXFCc0QsT0FBT2xELFlBQVlDLE9BQU87QUFBQSxVQUNyRSxFQUFFTyxJQUFJLGFBQWFaLE9BQU8sZ0JBQWdCc0QsT0FBT3ZCLG9CQUFvQjFCLE9BQU87QUFBQSxRQUFDO0FBQUEsUUFFL0U7QUFBQSxRQUNBLGFBQWFrQztBQUFBQSxRQUdaRDtBQUFBQSx3QkFBYyxXQUFXLHVCQUFDLHlCQUFzQixlQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBR3pFQSxjQUFjLGVBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQTtBQUFBLGNBQ0EsbUJBQW1CRTtBQUFBQSxjQUNuQixzQkFBc0I7QUFBQSxnQkFDcEJoQixXQUFXUyxxQkFBcUJUO0FBQUFBLGdCQUNoQ0MsU0FBU1EscUJBQXFCUjtBQUFBQSxnQkFDOUJDLE9BQU9PLHFCQUFxQlA7QUFBQUEsY0FDOUI7QUFBQSxjQUNBO0FBQUE7QUFBQSxZQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVMrQjtBQUFBO0FBQUE7QUFBQSxNQXRCbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBeUJBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFVBQ0xwQixXQUFXO0FBQUEsVUFDWGpDLFNBQVM7QUFBQSxVQUNUQyxjQUFjO0FBQUEsVUFDZEUsWUFBWTtBQUFBLFVBQ1pTLFNBQVM7QUFBQSxVQUNURSxLQUFLO0FBQUEsUUFDUDtBQUFBLFFBRUE7QUFBQSxpQ0FBQyxPQUFFLE9BQU8sRUFBRUUsUUFBUSxXQUFXWCxVQUFVLFVBQVVDLFlBQVksSUFBSSxHQUFHLGdDQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTztBQUFBLGdCQUNMTSxTQUFTO0FBQUEsZ0JBQ1RDLHFCQUFxQjtBQUFBLGdCQUNyQkMsS0FBSztBQUFBLGNBQ1A7QUFBQSxjQUVBO0FBQUEsdUNBQUMsUUFBSyxJQUFHLDhCQUE2QixPQUFPLEVBQUVjLGdCQUFnQixPQUFPLEdBQ3BFLGlDQUFDLFVBQU8sU0FBUSxTQUFRLE9BQU8sRUFBRXNELE9BQU8sT0FBTyxHQUFHLG9DQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUssSUFBRyw0Q0FBMkMsT0FBTyxFQUFFdEQsZ0JBQWdCLE9BQU8sR0FDbEYsaUNBQUMsVUFBTyxTQUFRLFNBQVEsT0FBTyxFQUFFc0QsT0FBTyxPQUFPLEdBQUcsNkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBSyxJQUFHLGlDQUFnQyxPQUFPLEVBQUV0RCxnQkFBZ0IsT0FBTyxHQUN2RSxpQ0FBQyxVQUFPLFNBQVEsU0FBUSxPQUFPLEVBQUVzRCxPQUFPLE9BQU8sR0FBRyw0QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQTtBQUFBO0FBQUEsWUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBc0JBO0FBQUE7QUFBQTtBQUFBLE1BbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW9DQTtBQUFBLE9BekZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwRkE7QUFFSjtBQUFDbkIsR0FyS2VELHlCQUF1QjtBQUFBLFVBQ2hCbEYsY0FJREgsVUFNU0EsUUFBUTtBQUFBO0FBQUEsTUFYdkJxRjtBQUF1QixJQUFBN0MsSUFBQVksS0FBQVksS0FBQUksS0FBQUksS0FBQU8sS0FBQUssS0FBQXNCO0FBQUEsYUFBQWxFLElBQUE7QUFBQSxhQUFBWSxLQUFBO0FBQUEsYUFBQVksS0FBQTtBQUFBLGFBQUFJLEtBQUE7QUFBQSxhQUFBSSxLQUFBO0FBQUEsYUFBQU8sS0FBQTtBQUFBLGFBQUFLLEtBQUE7QUFBQSxhQUFBc0IsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZVF1ZXJ5IiwiZ2V0SUZvb2RNZXJjaGFudFN0YXR1cyIsImdldElGb29kTWVyY2hhbnRTdGF0dXNCeU9wZXJhdGlvbiIsInVzZUF1dGhTdG9yZSIsIkJ1dHRvbiIsIlBhZ2VIZWFkZXIiLCJRdWVyeUVycm9yIiwiRW1wdHlTdGF0ZSIsIlRhYnMiLCJBbGVydCIsIkRhc2hib2FyZENhcmQiLCJmb3JtYXRNZXJjaGFudEF2YWlsYWJpbGl0eSIsImZvcm1hdFZhbGlkYXRpb25TdGF0ZSIsIk9QRVJBVElPTl9MQUJFTFMiLCJERUxJVkVSWSIsIlRBS0VPVVQiLCJESU5FX0lOIiwiZm9ybWF0T3BlcmF0aW9uTGFiZWwiLCJvcGVyYXRpb24iLCJnZXRPcGVyYXRpb25CdXR0b25TdHlsZSIsIm9wIiwic2VsZWN0ZWRPcGVyYXRpb24iLCJpc1NlbGVjdGVkIiwicGFkZGluZyIsImJvcmRlclJhZGl1cyIsImJvcmRlciIsImJhY2tncm91bmQiLCJjdXJzb3IiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJ0cmFuc2l0aW9uIiwiVmFsaWRhdGlvblN1bW1hcnlCYWRnZXMiLCJlcnJvckNvdW50Iiwid2FybmluZ0NvdW50IiwiY29sb3IiLCJkaXNwbGF5IiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImdhcCIsImJvcmRlckxlZnQiLCJtYXJnaW4iLCJfYyIsIlN0YXR1c0hlYWRlckNhcmQiLCJvcGVyYXRpb25TdGF0ZSIsInN0YXR1c0Rpc3BsYXkiLCJiZyIsIm1hcmdpbkJvdHRvbSIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImljb24iLCJvcGFjaXR5IiwibGFiZWwiLCJ0ZXh0RGVjb3JhdGlvbiIsIl9jMiIsIkdlbmVyYWxWYWxpZGF0aW9uc1RhYiIsInZhbGlkYXRpb25zIiwibGVuZ3RoIiwibWFyZ2luVG9wIiwidGV4dEFsaWduIiwibWFwIiwidmFsaWRhdGlvbiIsInN0YXRlIiwic2V2ZXJpdHkiLCJpZCIsIm1lc3NhZ2UiLCJfYzMiLCJPcGVyYXRpb25CdXR0b25zIiwib3BlcmF0aW9ucyIsIm9uU2VsZWN0IiwiX2M0IiwiT3BlcmF0aW9uVmFsaWRhdGlvbnNMaXN0Iiwib3BlcmF0aW9uTGFiZWwiLCJ2IiwiX2M1IiwiT3BlcmF0aW9uU3RhdHVzRGV0YWlscyIsImlzTG9hZGluZyIsImlzRXJyb3IiLCJlcnJvciIsIm9wZXJhdGlvbkRhdGEiLCJhdmFpbGFibGUiLCJfYzYiLCJPcGVyYXRpb25zVGFiIiwiYXZhaWxhYmxlT3BlcmF0aW9ucyIsIm9uU2VsZWN0T3BlcmF0aW9uIiwib3BlcmF0aW9uU3RhdHVzUXVlcnkiLCJfYzciLCJJRm9vZFN0YXR1c0RldGFpbGVkUGFnZSIsIl9zIiwiYnJhbmNoSWQiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJzZXRTZWxlY3RlZE9wZXJhdGlvbiIsInN0YXR1c1F1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicmVmZXRjaEludGVydmFsIiwiZW5hYmxlZCIsImRhdGEiLCJtYXhXaWR0aCIsImhyZWYiLCJlcnJvclZhbGlkYXRpb25zIiwiZmlsdGVyIiwid2FybmluZ1ZhbGlkYXRpb25zIiwicmVmZXRjaCIsImlzUmVmZXRjaGluZyIsImJhZGdlIiwid2lkdGgiLCJfYzgiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSUZvb2RTdGF0dXNEZXRhaWxlZFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQ1NTUHJvcGVydGllcyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IGdldElGb29kTWVyY2hhbnRTdGF0dXMsIGdldElGb29kTWVyY2hhbnRTdGF0dXNCeU9wZXJhdGlvbiB9IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9QYWdlSGVhZGVyXCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcbmltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tIFwiLi4vLi4vdWkvRW1wdHlTdGF0ZVwiO1xyXG5pbXBvcnQgeyBUYWJzIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvVGFic1wiO1xyXG5pbXBvcnQgeyBBbGVydCB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0FsZXJ0XCI7XHJcbmltcG9ydCB7IERhc2hib2FyZENhcmQgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9EYXNoYm9hcmRDYXJkXCI7XHJcbmltcG9ydCB7IGZvcm1hdE1lcmNoYW50QXZhaWxhYmlsaXR5LCBmb3JtYXRWYWxpZGF0aW9uU3RhdGUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvaWZvb2RGb3JtYXR0ZXJzRW5oYW5jZWRcIjtcclxuXHJcbmNvbnN0IE9QRVJBVElPTl9MQUJFTFM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XHJcbiAgREVMSVZFUlk6IFwi8J+alyBEZWxpdmVyeVwiLFxyXG4gIFRBS0VPVVQ6IFwi8J+bje+4jyBSZXRpcmFkYVwiLFxyXG4gIERJTkVfSU46IFwi8J+Nve+4jyBDb25zdW1vIG5vIGxvY2FsXCIsXHJcbn07XHJcblxyXG50eXBlIFN0YXR1c0Rpc3BsYXkgPSBSZXR1cm5UeXBlPHR5cGVvZiBmb3JtYXRNZXJjaGFudEF2YWlsYWJpbGl0eT47XHJcblxyXG50eXBlIFZhbGlkYXRpb25JdGVtID0ge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgc3RhdGU6IHN0cmluZztcclxuICBtZXNzYWdlPzogc3RyaW5nIHwgbnVsbDtcclxufTtcclxuXHJcbnR5cGUgT3BlcmF0aW9uU3RhdHVzRGF0YSA9IHtcclxuICBhdmFpbGFibGU6IGJvb2xlYW47XHJcbiAgc3RhdGU/OiBzdHJpbmcgfCBudWxsO1xyXG4gIHZhbGlkYXRpb25zPzogVmFsaWRhdGlvbkl0ZW1bXSB8IG51bGw7XHJcbn07XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRPcGVyYXRpb25MYWJlbChvcGVyYXRpb246IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIE9QRVJBVElPTl9MQUJFTFNbb3BlcmF0aW9uXSA/PyBvcGVyYXRpb247XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldE9wZXJhdGlvbkJ1dHRvblN0eWxlKG9wOiBzdHJpbmcsIHNlbGVjdGVkT3BlcmF0aW9uOiBzdHJpbmcgfCBudWxsKTogQ1NTUHJvcGVydGllcyB7XHJcbiAgY29uc3QgaXNTZWxlY3RlZCA9IHNlbGVjdGVkT3BlcmF0aW9uID09PSBvcDtcclxuICByZXR1cm4ge1xyXG4gICAgcGFkZGluZzogMTIsXHJcbiAgICBib3JkZXJSYWRpdXM6IDgsXHJcbiAgICBib3JkZXI6IGlzU2VsZWN0ZWQgPyBcIjJweCBzb2xpZCB2YXIoLS1hY2NlbnQpXCIgOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsXHJcbiAgICBiYWNrZ3JvdW5kOiBpc1NlbGVjdGVkID8gXCJ2YXIoLS1zdXJmYWNlLTIpXCIgOiBcInZhcigtLXN1cmZhY2UtMSlcIixcclxuICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXHJcbiAgICBmb250U2l6ZTogXCIwLjk1cmVtXCIsXHJcbiAgICBmb250V2VpZ2h0OiBpc1NlbGVjdGVkID8gNzAwIDogNTAwLFxyXG4gICAgdHJhbnNpdGlvbjogXCJhbGwgMC4yc1wiLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIFJlc3VtbyAoYmFkZ2VzKSBkZSBlcnJvcy9hdmlzb3MgZXhpYmlkbyBubyBjYXJkIHByaW5jaXBhbCBkZSBzdGF0dXMuXHJcbmZ1bmN0aW9uIFZhbGlkYXRpb25TdW1tYXJ5QmFkZ2VzKHtcclxuICBlcnJvckNvdW50LFxyXG4gIHdhcm5pbmdDb3VudCxcclxuICBjb2xvcixcclxufToge1xyXG4gIGVycm9yQ291bnQ6IG51bWJlcjtcclxuICB3YXJuaW5nQ291bnQ6IG51bWJlcjtcclxuICBjb2xvcjogc3RyaW5nO1xyXG59KSB7XHJcbiAgaWYgKGVycm9yQ291bnQgPT09IDAgJiYgd2FybmluZ0NvdW50ID09PSAwKSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBncmlkVGVtcGxhdGVDb2x1bW5zOiBcInJlcGVhdChhdXRvLWZpdCwgbWlubWF4KDE4MHB4LCAxZnIpKVwiLCBnYXA6IDEyIH19PlxyXG4gICAgICB7ZXJyb3JDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEyLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IDYsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSgwLDAsMCwwLjEpXCIsXHJcbiAgICAgICAgICAgIGJvcmRlckxlZnQ6IFwiM3B4IHNvbGlkICNlZjQ0NDRcIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6IFwiMC44NXJlbVwiLCBtYXJnaW46IDAsIGZvbnRXZWlnaHQ6IDYwMCwgY29sb3IgfX0+XHJcbiAgICAgICAgICAgIOKclSB7ZXJyb3JDb3VudH0gRXJyb3tlcnJvckNvdW50ID4gMSA/IFwic1wiIDogXCJcIn1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAge3dhcm5pbmdDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEyLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IDYsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSgwLDAsMCwwLjEpXCIsXHJcbiAgICAgICAgICAgIGJvcmRlckxlZnQ6IFwiM3B4IHNvbGlkICNmNTllMGJcIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6IFwiMC44NXJlbVwiLCBtYXJnaW46IDAsIGZvbnRXZWlnaHQ6IDYwMCwgY29sb3IgfX0+XHJcbiAgICAgICAgICAgIOKaoCB7d2FybmluZ0NvdW50fSBBdmlzb3t3YXJuaW5nQ291bnQgPiAxID8gXCJzXCIgOiBcIlwifVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuLy8gQ2FyZCBwcmluY2lwYWwgY29tIG8gZXN0YWRvIGdlcmFsIGRhIGxvamEgbm8gaUZvb2QuXHJcbmZ1bmN0aW9uIFN0YXR1c0hlYWRlckNhcmQoe1xyXG4gIG9wZXJhdGlvblN0YXRlLFxyXG4gIHN0YXR1c0Rpc3BsYXksXHJcbiAgZXJyb3JDb3VudCxcclxuICB3YXJuaW5nQ291bnQsXHJcbn06IHtcclxuICBvcGVyYXRpb25TdGF0ZT86IHN0cmluZyB8IG51bGw7XHJcbiAgc3RhdHVzRGlzcGxheTogU3RhdHVzRGlzcGxheTtcclxuICBlcnJvckNvdW50OiBudW1iZXI7XHJcbiAgd2FybmluZ0NvdW50OiBudW1iZXI7XHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBzdHlsZT17e1xyXG4gICAgICAgIHBhZGRpbmc6IDI0LFxyXG4gICAgICAgIGJvcmRlclJhZGl1czogOCxcclxuICAgICAgICBiYWNrZ3JvdW5kOiBzdGF0dXNEaXNwbGF5LmJnLFxyXG4gICAgICAgIGJvcmRlcjogYDNweCBzb2xpZCAke3N0YXR1c0Rpc3BsYXkuY29sb3J9YCxcclxuICAgICAgICBtYXJnaW5Cb3R0b206IDI0LFxyXG4gICAgICAgIGRpc3BsYXk6IFwiZ3JpZFwiLFxyXG4gICAgICAgIGdhcDogMTYsXHJcbiAgICAgIH19XHJcbiAgICA+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJmbGV4LXN0YXJ0XCIgfX0+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxNiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IFwiM3JlbVwiIH19PntzdGF0dXNEaXNwbGF5Lmljb259PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIwLjlyZW1cIixcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBzdGF0dXNEaXNwbGF5LmNvbG9yLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiBcIjAgMCA0cHhcIixcclxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDYwMCxcclxuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuOCxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgRVNUQURPIEdFUkFMXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPGgxIHN0eWxlPXt7IGZvbnRTaXplOiBcIjIuMnJlbVwiLCBtYXJnaW46IDAsIGNvbG9yOiBzdGF0dXNEaXNwbGF5LmNvbG9yLCBmb250V2VpZ2h0OiA4MDAgfX0+XHJcbiAgICAgICAgICAgICAge3N0YXR1c0Rpc3BsYXkubGFiZWx9XHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIHtvcGVyYXRpb25TdGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjAuOTVyZW1cIixcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IHN0YXR1c0Rpc3BsYXkuY29sb3IsXHJcbiAgICAgICAgICAgICAgICAgIG1hcmdpbjogXCI4cHggMCAwXCIsXHJcbiAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuOSxcclxuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNTAwLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7b3BlcmF0aW9uU3RhdGV9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBBIEFQSSBkbyBpRm9vZCBuw6NvIHRlbSBsaWdhL2Rlc2xpZ2EgZGUgZGlzcG9uaWJpbGlkYWRlOiBwYXVzYXIgYSBsb2phIMOpIGNyaWFyIHVtYVxyXG4gICAgICAgICAgICBpbnRlcnJ1cMOnw6NvLCBnZXJlbmNpYWRhIG5hIHRlbGEgZGEgaW50ZWdyYcOnw6NvLiAqL31cclxuICAgICAgICA8TGluayB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZFwiIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiB9fT5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCI+4o+477iPIEdlcmVuY2lhciBpbnRlcnJ1cMOnw7VlczwvQnV0dG9uPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8VmFsaWRhdGlvblN1bW1hcnlCYWRnZXMgZXJyb3JDb3VudD17ZXJyb3JDb3VudH0gd2FybmluZ0NvdW50PXt3YXJuaW5nQ291bnR9IGNvbG9yPXtzdGF0dXNEaXNwbGF5LmNvbG9yfSAvPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuLy8gQUJBIDE6IGxpc3RhIGRlIHZhbGlkYcOnw7VlcyBnZXJhaXMgZGEgbG9qYS5cclxuZnVuY3Rpb24gR2VuZXJhbFZhbGlkYXRpb25zVGFiKHsgdmFsaWRhdGlvbnMgfTogeyB2YWxpZGF0aW9uczogVmFsaWRhdGlvbkl0ZW1bXSB9KSB7XHJcbiAgaWYgKHZhbGlkYXRpb25zLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiwgbWFyZ2luVG9wOiAxNiB9fT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAzMiwgdGV4dEFsaWduOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4xcmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBtYXJnaW46IDAgfX0+XHJcbiAgICAgICAgICAgIOKckyBUdWRvIGNlcnRvISBOZW5odW1hIHZhbGlkYcOnw6NvIHBlbmRlbnRlLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiwgbWFyZ2luVG9wOiAxNiB9fT5cclxuICAgICAge3ZhbGlkYXRpb25zLm1hcCgodmFsaWRhdGlvbikgPT4ge1xyXG4gICAgICAgIGNvbnN0IGRpc3BsYXkgPSBmb3JtYXRWYWxpZGF0aW9uU3RhdGUodmFsaWRhdGlvbi5zdGF0ZSk7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxBbGVydFxyXG4gICAgICAgICAgICBrZXk9e3ZhbGlkYXRpb24uaWR9XHJcbiAgICAgICAgICAgIHZhcmlhbnQ9e2Rpc3BsYXkuc2V2ZXJpdHl9XHJcbiAgICAgICAgICAgIHRpdGxlPXt2YWxpZGF0aW9uLmlkfVxyXG4gICAgICAgICAgICBtZXNzYWdlPXtcclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAsIG1hcmdpbkJvdHRvbTogNCB9fT5cclxuICAgICAgICAgICAgICAgICAge2Rpc3BsYXkuaWNvbn0ge2Rpc3BsYXkubGFiZWx9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHt2YWxpZGF0aW9uLm1lc3NhZ2UgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOXJlbVwiLCBtYXJnaW5Ub3A6IDgsIG9wYWNpdHk6IDAuOSB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7dmFsaWRhdGlvbi5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKTtcclxuICAgICAgfSl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG4vLyBHcmFkZSBkZSBib3TDtWVzIGRlIHNlbGXDp8OjbyBkZSBvcGVyYcOnw6NvIChEZWxpdmVyeS9SZXRpcmFkYS9Db25zdW1vIGxvY2FsKS5cclxuZnVuY3Rpb24gT3BlcmF0aW9uQnV0dG9ucyh7XHJcbiAgb3BlcmF0aW9ucyxcclxuICBzZWxlY3RlZE9wZXJhdGlvbixcclxuICBvblNlbGVjdCxcclxufToge1xyXG4gIG9wZXJhdGlvbnM6IHN0cmluZ1tdO1xyXG4gIHNlbGVjdGVkT3BlcmF0aW9uOiBzdHJpbmcgfCBudWxsO1xyXG4gIG9uU2VsZWN0OiAob3BlcmF0aW9uOiBzdHJpbmcpID0+IHZvaWQ7XHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCJyZXBlYXQoYXV0by1maXQsIG1pbm1heCgyMDBweCwgMWZyKSlcIiwgZ2FwOiAxMiwgbWFyZ2luQm90dG9tOiAyNCB9fT5cclxuICAgICAge29wZXJhdGlvbnMubWFwKChvcCkgPT4gKFxyXG4gICAgICAgIDxidXR0b24ga2V5PXtvcH0gb25DbGljaz17KCkgPT4gb25TZWxlY3Qob3ApfSBzdHlsZT17Z2V0T3BlcmF0aW9uQnV0dG9uU3R5bGUob3AsIHNlbGVjdGVkT3BlcmF0aW9uKX0+XHJcbiAgICAgICAgICB7Zm9ybWF0T3BlcmF0aW9uTGFiZWwob3ApfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICApKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbi8vIExpc3RhIGRlIHZhbGlkYcOnw7VlcyBlc3BlY8OtZmljYXMgZGUgdW1hIG9wZXJhw6fDo28gc2VsZWNpb25hZGEuXHJcbmZ1bmN0aW9uIE9wZXJhdGlvblZhbGlkYXRpb25zTGlzdCh7XHJcbiAgdmFsaWRhdGlvbnMsXHJcbiAgb3BlcmF0aW9uTGFiZWwsXHJcbn06IHtcclxuICB2YWxpZGF0aW9uczogVmFsaWRhdGlvbkl0ZW1bXTtcclxuICBvcGVyYXRpb25MYWJlbDogc3RyaW5nO1xyXG59KSB7XHJcbiAgaWYgKHZhbGlkYXRpb25zLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogMTYgfX0+XHJcbiAgICAgIDxoNCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjk1cmVtXCIsIGZvbnRXZWlnaHQ6IDcwMCwgbWFyZ2luOiBcIjAgMCAxMnB4XCIgfX0+XHJcbiAgICAgICAgVmFsaWRhw6fDtWVzIC0ge29wZXJhdGlvbkxhYmVsfVxyXG4gICAgICA8L2g0PlxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAge3ZhbGlkYXRpb25zLm1hcCgodikgPT4ge1xyXG4gICAgICAgICAgY29uc3QgZGlzcGxheSA9IGZvcm1hdFZhbGlkYXRpb25TdGF0ZSh2LnN0YXRlKTtcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxBbGVydFxyXG4gICAgICAgICAgICAgIGtleT17di5pZH1cclxuICAgICAgICAgICAgICB2YXJpYW50PXtkaXNwbGF5LnNldmVyaXR5fVxyXG4gICAgICAgICAgICAgIHRpdGxlPXt2LmlkfVxyXG4gICAgICAgICAgICAgIG1lc3NhZ2U9e1xyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAge2Rpc3BsYXkuaWNvbn0ge2Rpc3BsYXkubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICB7di5tZXNzYWdlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODVyZW1cIiwgbWFyZ2luVG9wOiA0IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3YubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuLy8gRGV0YWxoZXMgKHN0YXR1cyArIHZhbGlkYcOnw7VlcykgZGEgb3BlcmHDp8OjbyBzZWxlY2lvbmFkYSwgY29icmluZG8gbG9hZGluZy9lcnJvL2RhZG9zLlxyXG5mdW5jdGlvbiBPcGVyYXRpb25TdGF0dXNEZXRhaWxzKHtcclxuICBpc0xvYWRpbmcsXHJcbiAgaXNFcnJvcixcclxuICBlcnJvcixcclxuICBvcGVyYXRpb25EYXRhLFxyXG4gIHNlbGVjdGVkT3BlcmF0aW9uLFxyXG59OiB7XHJcbiAgaXNMb2FkaW5nOiBib29sZWFuO1xyXG4gIGlzRXJyb3I6IGJvb2xlYW47XHJcbiAgZXJyb3I6IHVua25vd247XHJcbiAgb3BlcmF0aW9uRGF0YTogT3BlcmF0aW9uU3RhdHVzRGF0YSB8IHVuZGVmaW5lZDtcclxuICBzZWxlY3RlZE9wZXJhdGlvbjogc3RyaW5nO1xyXG59KSB7XHJcbiAgaWYgKGlzTG9hZGluZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIHBhZGRpbmc6IFwiMjBweFwiIH19PlxyXG4gICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5DYXJyZWdhbmRvIGRldGFsaGVzIGRhIG9wZXJhw6fDo28uLi48L3A+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChpc0Vycm9yKSB7XHJcbiAgICByZXR1cm4gPFF1ZXJ5RXJyb3IgZXJyb3I9e2Vycm9yfSB3aGF0PXtgc3RhdHVzIGRhIG9wZXJhw6fDo28gJHtzZWxlY3RlZE9wZXJhdGlvbn1gfSAvPjtcclxuICB9XHJcblxyXG4gIGlmICghb3BlcmF0aW9uRGF0YSkge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxNiB9fT5cclxuICAgICAgey8qIENhcmQgZGUgU3RhdHVzICovfVxyXG4gICAgICA8RGFzaGJvYXJkQ2FyZFxyXG4gICAgICAgIHRpdGxlPXtgJHtmb3JtYXRPcGVyYXRpb25MYWJlbChzZWxlY3RlZE9wZXJhdGlvbil9IC0gU3RhdHVzYH1cclxuICAgICAgICB2YWx1ZT17b3BlcmF0aW9uRGF0YS5hdmFpbGFibGUgPyBcIkRpc3BvbsOtdmVsXCIgOiBcIkluZGlzcG9uw612ZWxcIn1cclxuICAgICAgICBzdGF0dXM9e29wZXJhdGlvbkRhdGEuYXZhaWxhYmxlID8gXCJzdWNjZXNzXCIgOiBcImVycm9yXCJ9XHJcbiAgICAgICAgaWNvbj17b3BlcmF0aW9uRGF0YS5hdmFpbGFibGUgPyBcIuKck1wiIDogXCLinJVcIn1cclxuICAgICAgICBzdWJ0aXRsZT17b3BlcmF0aW9uRGF0YS5zdGF0ZSB8fCBcIuKAlFwifVxyXG4gICAgICAvPlxyXG5cclxuICAgICAgey8qIFZhbGlkYcOnw7VlcyBkYSBPcGVyYcOnw6NvICovfVxyXG4gICAgICA8T3BlcmF0aW9uVmFsaWRhdGlvbnNMaXN0XHJcbiAgICAgICAgdmFsaWRhdGlvbnM9e29wZXJhdGlvbkRhdGEudmFsaWRhdGlvbnMgPz8gW119XHJcbiAgICAgICAgb3BlcmF0aW9uTGFiZWw9e2Zvcm1hdE9wZXJhdGlvbkxhYmVsKHNlbGVjdGVkT3BlcmF0aW9uKX1cclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbi8vIEFCQSAyOiBzZWxlw6fDo28gZGUgb3BlcmHDp8OjbyArIGRldGFsaGVzIGRhIG9wZXJhw6fDo28gZXNjb2xoaWRhLlxyXG5mdW5jdGlvbiBPcGVyYXRpb25zVGFiKHtcclxuICBhdmFpbGFibGVPcGVyYXRpb25zLFxyXG4gIHNlbGVjdGVkT3BlcmF0aW9uLFxyXG4gIG9uU2VsZWN0T3BlcmF0aW9uLFxyXG4gIG9wZXJhdGlvblN0YXR1c1F1ZXJ5LFxyXG4gIG9wZXJhdGlvbkRhdGEsXHJcbn06IHtcclxuICBhdmFpbGFibGVPcGVyYXRpb25zOiBzdHJpbmdbXTtcclxuICBzZWxlY3RlZE9wZXJhdGlvbjogc3RyaW5nIHwgbnVsbDtcclxuICBvblNlbGVjdE9wZXJhdGlvbjogKG9wZXJhdGlvbjogc3RyaW5nKSA9PiB2b2lkO1xyXG4gIG9wZXJhdGlvblN0YXR1c1F1ZXJ5OiB7IGlzTG9hZGluZzogYm9vbGVhbjsgaXNFcnJvcjogYm9vbGVhbjsgZXJyb3I6IHVua25vd24gfTtcclxuICBvcGVyYXRpb25EYXRhOiBPcGVyYXRpb25TdGF0dXNEYXRhIHwgdW5kZWZpbmVkO1xyXG59KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAxNiB9fT5cclxuICAgICAgPE9wZXJhdGlvbkJ1dHRvbnNcclxuICAgICAgICBvcGVyYXRpb25zPXthdmFpbGFibGVPcGVyYXRpb25zfVxyXG4gICAgICAgIHNlbGVjdGVkT3BlcmF0aW9uPXtzZWxlY3RlZE9wZXJhdGlvbn1cclxuICAgICAgICBvblNlbGVjdD17b25TZWxlY3RPcGVyYXRpb259XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICB7c2VsZWN0ZWRPcGVyYXRpb24gJiYgKFxyXG4gICAgICAgIDxPcGVyYXRpb25TdGF0dXNEZXRhaWxzXHJcbiAgICAgICAgICBpc0xvYWRpbmc9e29wZXJhdGlvblN0YXR1c1F1ZXJ5LmlzTG9hZGluZ31cclxuICAgICAgICAgIGlzRXJyb3I9e29wZXJhdGlvblN0YXR1c1F1ZXJ5LmlzRXJyb3J9XHJcbiAgICAgICAgICBlcnJvcj17b3BlcmF0aW9uU3RhdHVzUXVlcnkuZXJyb3J9XHJcbiAgICAgICAgICBvcGVyYXRpb25EYXRhPXtvcGVyYXRpb25EYXRhfVxyXG4gICAgICAgICAgc2VsZWN0ZWRPcGVyYXRpb249e3NlbGVjdGVkT3BlcmF0aW9ufVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gSUZvb2RTdGF0dXNEZXRhaWxlZFBhZ2UoKSB7XHJcbiAgY29uc3QgeyBicmFuY2hJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwiZ2VyYWxcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkT3BlcmF0aW9uLCBzZXRTZWxlY3RlZE9wZXJhdGlvbl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3Qgc3RhdHVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJzdGF0dXMtZGV0YWlsZWRcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RNZXJjaGFudFN0YXR1cyhicmFuY2hJZCksXHJcbiAgICByZWZldGNoSW50ZXJ2YWw6IDMwMDAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBvcGVyYXRpb25TdGF0dXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcInN0YXR1cy1ieS1vcGVyYXRpb25cIiwgYnJhbmNoSWQsIHNlbGVjdGVkT3BlcmF0aW9uXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldElGb29kTWVyY2hhbnRTdGF0dXNCeU9wZXJhdGlvbihicmFuY2hJZCwgc2VsZWN0ZWRPcGVyYXRpb24hKSxcclxuICAgIGVuYWJsZWQ6ICEhc2VsZWN0ZWRPcGVyYXRpb24sXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGRhdGEgPSBzdGF0dXNRdWVyeS5kYXRhO1xyXG4gIGNvbnN0IG9wZXJhdGlvbkRhdGEgPSBvcGVyYXRpb25TdGF0dXNRdWVyeS5kYXRhO1xyXG5cclxuICBpZiAoc3RhdHVzUXVlcnkuaXNMb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDEyMDAsIG1hcmdpbjogXCIwIGF1dG9cIiB9fT5cclxuICAgICAgICA8UGFnZUhlYWRlclxyXG4gICAgICAgICAgdGl0bGU9XCJTdGF0dXMgJiBEaXNwb25pYmlsaWRhZGVcIlxyXG4gICAgICAgICAgc3VidGl0bGU9XCJEZXRhbGhlcyBjb21wbGV0b3MgZSBvcGVyYcOnw7VlcyBwb3IgdGlwb1wiXHJcbiAgICAgICAgICBicmVhZGNydW1iPXtbeyBsYWJlbDogXCJpRm9vZFwiLCBocmVmOiBcIi9pbnRlZ3JhY29lcy9pZm9vZFwiIH1dfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIHBhZGRpbmc6IFwiNDBweCAyMHB4XCIgfX0+XHJcbiAgICAgICAgICA8cCBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+Q2FycmVnYW5kbyBpbmZvcm1hw6fDtWVzIGRlIHN0YXR1cy4uLjwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9tYWluPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChzdGF0dXNRdWVyeS5pc0Vycm9yKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDEyMDAsIG1hcmdpbjogXCIwIGF1dG9cIiB9fT5cclxuICAgICAgICA8UGFnZUhlYWRlclxyXG4gICAgICAgICAgdGl0bGU9XCJTdGF0dXMgJiBEaXNwb25pYmlsaWRhZGVcIlxyXG4gICAgICAgICAgc3VidGl0bGU9XCJEZXRhbGhlcyBjb21wbGV0b3MgZSBvcGVyYcOnw7VlcyBwb3IgdGlwb1wiXHJcbiAgICAgICAgICBicmVhZGNydW1iPXtbeyBsYWJlbDogXCJpRm9vZFwiLCBocmVmOiBcIi9pbnRlZ3JhY29lcy9pZm9vZFwiIH1dfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFF1ZXJ5RXJyb3IgZXJyb3I9e3N0YXR1c1F1ZXJ5LmVycm9yfSB3aGF0PVwibyBzdGF0dXMgZGV0YWxoYWRvXCIgLz5cclxuICAgICAgPC9tYWluPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmICghZGF0YSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMjAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgICAgPFBhZ2VIZWFkZXJcclxuICAgICAgICAgIHRpdGxlPVwiU3RhdHVzICYgRGlzcG9uaWJpbGlkYWRlXCJcclxuICAgICAgICAgIHN1YnRpdGxlPVwiRGV0YWxoZXMgY29tcGxldG9zIGUgb3BlcmHDp8O1ZXMgcG9yIHRpcG9cIlxyXG4gICAgICAgICAgYnJlYWRjcnVtYj17W3sgbGFiZWw6IFwiaUZvb2RcIiwgaHJlZjogXCIvaW50ZWdyYWNvZXMvaWZvb2RcIiB9XX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxFbXB0eVN0YXRlIHRpdGxlPVwiU2VtIHN0YXR1c1wiIGRlc2NyaXB0aW9uPVwiTsOjbyBmb2kgcG9zc8OtdmVsIG9idGVyIGluZm9ybWHDp8O1ZXMgZGUgc3RhdHVzIGRhIGxvamEuXCIgLz5cclxuICAgICAgPC9tYWluPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHN0YXR1c0Rpc3BsYXkgPSBmb3JtYXRNZXJjaGFudEF2YWlsYWJpbGl0eShkYXRhLmF2YWlsYWJsZSwgZGF0YS5vcGVyYXRpb25TdGF0ZSk7XHJcbiAgY29uc3QgdmFsaWRhdGlvbnMgPSBkYXRhLnZhbGlkYXRpb25zIHx8IFtdO1xyXG4gIC8vIE8gYHN0YXRlYCBkZSBjYWRhIHZhbGlkYcOnw6NvIHZlbSBicnV0byBkbyBpRm9vZCAodm9jYWJ1bMOhcmlvIG7Do28gZG9jdW1lbnRhZG8pIOKAlCBhIHNldmVyaWRhZGVcclxuICAvLyDDqSByZXNvbHZpZGEgcG9yIGZvcm1hdFZhbGlkYXRpb25TdGF0ZSwgcXVlIGNvYnJlIGFzIGdyYWZpYXMgY29uaGVjaWRhcy5cclxuICBjb25zdCBlcnJvclZhbGlkYXRpb25zID0gdmFsaWRhdGlvbnMuZmlsdGVyKCh2KSA9PiBmb3JtYXRWYWxpZGF0aW9uU3RhdGUodi5zdGF0ZSkuc2V2ZXJpdHkgPT09IFwiZXJyb3JcIik7XHJcbiAgY29uc3Qgd2FybmluZ1ZhbGlkYXRpb25zID0gdmFsaWRhdGlvbnMuZmlsdGVyKCh2KSA9PiBmb3JtYXRWYWxpZGF0aW9uU3RhdGUodi5zdGF0ZSkuc2V2ZXJpdHkgPT09IFwid2FybmluZ1wiKTtcclxuXHJcbiAgLy8gTyBpRm9vZCBuw6NvIGV4cMO1ZSBhIGxpc3RhIGRlIG9wZXJhw6fDtWVzIGhhYmlsaXRhZGFzIGRhIGxvamE7IG8gZW5kcG9pbnQgZGUgc3RhdHVzIHBvclxyXG4gIC8vIG9wZXJhw6fDo28gw6kgY29uc3VsdGFkbyBzb2IgZGVtYW5kYSBwYXJhIGNhZGEgdW1hIGRhcyBvcGVyYcOnw7VlcyBwb3Nzw612ZWlzLlxyXG4gIGNvbnN0IGF2YWlsYWJsZU9wZXJhdGlvbnMgPSBbXCJERUxJVkVSWVwiLCBcIlRBS0VPVVRcIiwgXCJESU5FX0lOXCJdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMjAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxQYWdlSGVhZGVyXHJcbiAgICAgICAgdGl0bGU9XCJTdGF0dXMgJiBEaXNwb25pYmlsaWRhZGVcIlxyXG4gICAgICAgIHN1YnRpdGxlPVwiRGV0YWxoZXMgY29tcGxldG9zIGUgb3BlcmHDp8O1ZXMgcG9yIHRpcG9cIlxyXG4gICAgICAgIGJyZWFkY3J1bWI9e1t7IGxhYmVsOiBcImlGb29kXCIsIGhyZWY6IFwiL2ludGVncmFjb2VzL2lmb29kXCIgfV19XHJcbiAgICAgICAgYWN0aW9ucz17XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0YXR1c1F1ZXJ5LnJlZmV0Y2goKX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e3N0YXR1c1F1ZXJ5LmlzUmVmZXRjaGluZ31cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAg8J+UhCB7c3RhdHVzUXVlcnkuaXNSZWZldGNoaW5nID8gXCJBdHVhbGl6YW5kby4uLlwiIDogXCJBdHVhbGl6YXIgYWdvcmFcIn1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIH1cclxuICAgICAgLz5cclxuXHJcbiAgICAgIHsvKiBDYXJkIFByaW5jaXBhbCBkZSBTdGF0dXMgKi99XHJcbiAgICAgIDxTdGF0dXNIZWFkZXJDYXJkXHJcbiAgICAgICAgb3BlcmF0aW9uU3RhdGU9e2RhdGEub3BlcmF0aW9uU3RhdGV9XHJcbiAgICAgICAgc3RhdHVzRGlzcGxheT17c3RhdHVzRGlzcGxheX1cclxuICAgICAgICBlcnJvckNvdW50PXtlcnJvclZhbGlkYXRpb25zLmxlbmd0aH1cclxuICAgICAgICB3YXJuaW5nQ291bnQ9e3dhcm5pbmdWYWxpZGF0aW9ucy5sZW5ndGh9XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICB7LyogQWJhczogVmFsaWRhw6fDtWVzIEdlcmFpcyB2cyBQb3IgT3BlcmHDp8OjbyAqL31cclxuICAgICAgPFRhYnNcclxuICAgICAgICB0YWJzPXtbXHJcbiAgICAgICAgICB7IGlkOiBcImdlcmFsXCIsIGxhYmVsOiBcIlZhbGlkYcOnw7VlcyBHZXJhaXNcIiwgYmFkZ2U6IHZhbGlkYXRpb25zLmxlbmd0aCB9LFxyXG4gICAgICAgICAgeyBpZDogXCJvcGVyYWNvZXNcIiwgbGFiZWw6IFwiUG9yIE9wZXJhw6fDo29cIiwgYmFkZ2U6IGF2YWlsYWJsZU9wZXJhdGlvbnMubGVuZ3RoIH0sXHJcbiAgICAgICAgXX1cclxuICAgICAgICBhY3RpdmVUYWI9e2FjdGl2ZVRhYn1cclxuICAgICAgICBvblRhYkNoYW5nZT17c2V0QWN0aXZlVGFifVxyXG4gICAgICA+XHJcbiAgICAgICAgey8qIEFCQSAxOiBWYWxpZGHDp8O1ZXMgR2VyYWlzICovfVxyXG4gICAgICAgIHthY3RpdmVUYWIgPT09IFwiZ2VyYWxcIiAmJiA8R2VuZXJhbFZhbGlkYXRpb25zVGFiIHZhbGlkYXRpb25zPXt2YWxpZGF0aW9uc30gLz59XHJcblxyXG4gICAgICAgIHsvKiBBQkEgMjogUG9yIE9wZXJhw6fDo28gKi99XHJcbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJvcGVyYWNvZXNcIiAmJiAoXHJcbiAgICAgICAgICA8T3BlcmF0aW9uc1RhYlxyXG4gICAgICAgICAgICBhdmFpbGFibGVPcGVyYXRpb25zPXthdmFpbGFibGVPcGVyYXRpb25zfVxyXG4gICAgICAgICAgICBzZWxlY3RlZE9wZXJhdGlvbj17c2VsZWN0ZWRPcGVyYXRpb259XHJcbiAgICAgICAgICAgIG9uU2VsZWN0T3BlcmF0aW9uPXtzZXRTZWxlY3RlZE9wZXJhdGlvbn1cclxuICAgICAgICAgICAgb3BlcmF0aW9uU3RhdHVzUXVlcnk9e3tcclxuICAgICAgICAgICAgICBpc0xvYWRpbmc6IG9wZXJhdGlvblN0YXR1c1F1ZXJ5LmlzTG9hZGluZyxcclxuICAgICAgICAgICAgICBpc0Vycm9yOiBvcGVyYXRpb25TdGF0dXNRdWVyeS5pc0Vycm9yLFxyXG4gICAgICAgICAgICAgIGVycm9yOiBvcGVyYXRpb25TdGF0dXNRdWVyeS5lcnJvcixcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgb3BlcmF0aW9uRGF0YT17b3BlcmF0aW9uRGF0YX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9UYWJzPlxyXG5cclxuICAgICAgey8qIEZvb3RlciBjb20gYcOnw7VlcyAqL31cclxuICAgICAgPGRpdlxyXG4gICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICBtYXJnaW5Ub3A6IDMyLFxyXG4gICAgICAgICAgcGFkZGluZzogMTYsXHJcbiAgICAgICAgICBib3JkZXJSYWRpdXM6IDgsXHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLXN1cmZhY2UtMilcIixcclxuICAgICAgICAgIGRpc3BsYXk6IFwiZ3JpZFwiLFxyXG4gICAgICAgICAgZ2FwOiAxMixcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luOiBcIjAgMCA4cHhcIiwgZm9udFNpemU6IFwiMC45cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCB9fT5cclxuICAgICAgICAgIE91dHJhcyBvcGVyYcOnw7Vlc1xyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBcImdyaWRcIixcclxuICAgICAgICAgICAgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCJyZXBlYXQoYXV0by1maXQsIG1pbm1heCgxODBweCwgMWZyKSlcIixcclxuICAgICAgICAgICAgZ2FwOiA4LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8TGluayB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZC9wZWRpZG9zXCIgc3R5bGU9e3sgdGV4dERlY29yYXRpb246IFwibm9uZVwiIH19PlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fT5cclxuICAgICAgICAgICAgICDwn5OmIEdlcmVuY2lhciBQZWRpZG9zXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPExpbmsgdG89XCIvaW50ZWdyYWNvZXMvaWZvb2QvZmluYW5jZWlyby9yZWxhdG9yaW9zXCIgc3R5bGU9e3sgdGV4dERlY29yYXRpb246IFwibm9uZVwiIH19PlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fT5cclxuICAgICAgICAgICAgICDwn5KwIEZpbmFuY2Vpcm9cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8TGluayB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZC9hdmFsaWFjb2VzXCIgc3R5bGU9e3sgdGV4dERlY29yYXRpb246IFwibm9uZVwiIH19PlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fT5cclxuICAgICAgICAgICAgICDirZAgQXZhbGlhw6fDtWVzXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9pbnRlZ3JhdGlvbnMvSUZvb2RTdGF0dXNEZXRhaWxlZFBhZ2UudHN4In0=