import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Field.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useId = __vite__cjsImport3_react["useId"];
export function Field({ label, hint, error, children }) {
  _s();
  const id = useId();
  let describedBy;
  if (error) {
    describedBy = `${id}-err`;
  } else if (hint) {
    describedBy = `${id}-hint`;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
    /* @__PURE__ */ jsxDEV("label", { className: "field-label", htmlFor: id, children: label }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    children({ id, "aria-invalid": error ? true : void 0, "aria-describedby": describedBy }),
    hint && !error && /* @__PURE__ */ jsxDEV("span", { className: "field-hint", id: `${id}-hint`, children: hint }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("span", { className: "field-error", id: `${id}-err`, children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx",
      lineNumber: 55,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx",
    lineNumber: 44,
    columnNumber: 5
  }, this);
}
_s(Field, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=");
_c = Field;
export function TextField({
  label,
  hint,
  error,
  ...rest
}) {
  return /* @__PURE__ */ jsxDEV(Field, { label, hint, error, children: (a11y) => /* @__PURE__ */ jsxDEV("input", { ...a11y, ...rest }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx",
    lineNumber: 72,
    columnNumber: 18
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx",
    lineNumber: 71,
    columnNumber: 5
  }, this);
}
_c2 = TextField;
export function SelectField({
  label,
  hint,
  error,
  children,
  ...rest
}) {
  return /* @__PURE__ */ jsxDEV(Field, { label, hint, error, children: (a11y) => /* @__PURE__ */ jsxDEV("select", { ...a11y, ...rest, children }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx",
    lineNumber: 92,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx",
    lineNumber: 90,
    columnNumber: 5
  }, this);
}
_c3 = SelectField;
var _c, _c2, _c3;
$RefreshReg$(_c, "Field");
$RefreshReg$(_c2, "TextField");
$RefreshReg$(_c3, "SelectField");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Field.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCTixTQUFTQSxhQUFhO0FBZWYsZ0JBQVNDLE1BQU0sRUFBRUMsT0FBT0MsTUFBTUMsT0FBT0MsU0FBeUIsR0FBRztBQUFBQyxLQUFBO0FBQ3RFLFFBQU1DLEtBQUtQLE1BQU07QUFDakIsTUFBSVE7QUFDSixNQUFJSixPQUFPO0FBQ1RJLGtCQUFjLEdBQUdELEVBQUU7QUFBQSxFQUNyQixXQUFXSixNQUFNO0FBQ2ZLLGtCQUFjLEdBQUdELEVBQUU7QUFBQSxFQUNyQjtBQUNBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQkFBQyxXQUFNLFdBQVUsZUFBYyxTQUFTQSxJQUNyQ0wsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ0csU0FBUyxFQUFFRSxJQUFJLGdCQUFnQkgsUUFBUSxPQUFPSyxRQUFXLG9CQUFvQkQsWUFBWSxDQUFDO0FBQUEsSUFDMUZMLFFBQVEsQ0FBQ0MsU0FDUix1QkFBQyxVQUFLLFdBQVUsY0FBYSxJQUFJLEdBQUdHLEVBQUUsU0FDbkNKLGtCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRURDLFNBQ0MsdUJBQUMsVUFBSyxXQUFVLGVBQWMsSUFBSSxHQUFHRyxFQUFFLFFBQ3BDSCxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQTtBQUVKO0FBRUFFLEdBNUJnQkwsT0FBSztBQUFBLEtBQUxBO0FBNkJULGdCQUFTUyxVQUFVO0FBQUEsRUFDeEJSO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0EsR0FBR087QUFDOEYsR0FBRztBQUNwRyxTQUNFLHVCQUFDLFNBQU0sT0FBYyxNQUFZLE9BQzlCLFdBQUNDLFNBQVMsdUJBQUMsV0FBTSxHQUFJQSxNQUFNLEdBQUlELFFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEIsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFFQUUsTUFiZ0JIO0FBY1QsZ0JBQVNJLFlBQVk7QUFBQSxFQUMxQlo7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQSxHQUFHTTtBQUtxQyxHQUFHO0FBQzNDLFNBQ0UsdUJBQUMsU0FBTSxPQUFjLE1BQVksT0FDOUIsV0FBQ0MsU0FDQSx1QkFBQyxZQUFPLEdBQUlBLE1BQU0sR0FBSUQsTUFDbkJOLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ1UsTUFwQmVEO0FBQVcsSUFBQUUsSUFBQUgsS0FBQUU7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUgsS0FBQTtBQUFBLGFBQUFFLEtBQUEiLCJuYW1lcyI6WyJ1c2VJZCIsIkZpZWxkIiwibGFiZWwiLCJoaW50IiwiZXJyb3IiLCJjaGlsZHJlbiIsIl9zIiwiaWQiLCJkZXNjcmliZWRCeSIsInVuZGVmaW5lZCIsIlRleHRGaWVsZCIsInJlc3QiLCJhMTF5IiwiX2MyIiwiU2VsZWN0RmllbGQiLCJfYzMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGaWVsZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlSWQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHR5cGUge1xyXG4gIElucHV0SFRNTEF0dHJpYnV0ZXMsXHJcbiAgUmVhY3ROb2RlLFxyXG4gIFNlbGVjdEhUTUxBdHRyaWJ1dGVzLFxyXG59IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW50ZXJmYWNlIEZpZWxkV3JhcFByb3BzIHtcclxuICBsYWJlbDogUmVhY3ROb2RlO1xyXG4gIGhpbnQ/OiBSZWFjdE5vZGU7XHJcbiAgZXJyb3I/OiBSZWFjdE5vZGU7XHJcbiAgY2hpbGRyZW46IChwcm9wczogeyBpZDogc3RyaW5nOyBcImFyaWEtaW52YWxpZFwiPzogYm9vbGVhbjsgXCJhcmlhLWRlc2NyaWJlZGJ5XCI/OiBzdHJpbmcgfSkgPT4gUmVhY3ROb2RlO1xyXG59XHJcblxyXG4vKiogUsOzdHVsbyBwZXJzaXN0ZW50ZSArIGVycm8vaGludCBhY2Vzc8OtdmVpcyAoaHRtbEZvci9hcmlhLWRlc2NyaWJlZGJ5KS4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIEZpZWxkKHsgbGFiZWwsIGhpbnQsIGVycm9yLCBjaGlsZHJlbiB9OiBGaWVsZFdyYXBQcm9wcykge1xyXG4gIGNvbnN0IGlkID0gdXNlSWQoKTtcclxuICBsZXQgZGVzY3JpYmVkQnk6IHN0cmluZyB8IHVuZGVmaW5lZDtcclxuICBpZiAoZXJyb3IpIHtcclxuICAgIGRlc2NyaWJlZEJ5ID0gYCR7aWR9LWVycmA7XHJcbiAgfSBlbHNlIGlmIChoaW50KSB7XHJcbiAgICBkZXNjcmliZWRCeSA9IGAke2lkfS1oaW50YDtcclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmllbGRcIj5cclxuICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkLWxhYmVsXCIgaHRtbEZvcj17aWR9PlxyXG4gICAgICAgIHtsYWJlbH1cclxuICAgICAgPC9sYWJlbD5cclxuICAgICAge2NoaWxkcmVuKHsgaWQsIFwiYXJpYS1pbnZhbGlkXCI6IGVycm9yID8gdHJ1ZSA6IHVuZGVmaW5lZCwgXCJhcmlhLWRlc2NyaWJlZGJ5XCI6IGRlc2NyaWJlZEJ5IH0pfVxyXG4gICAgICB7aGludCAmJiAhZXJyb3IgJiYgKFxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZpZWxkLWhpbnRcIiBpZD17YCR7aWR9LWhpbnRgfT5cclxuICAgICAgICAgIHtoaW50fVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKX1cclxuICAgICAge2Vycm9yICYmIChcclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiIGlkPXtgJHtpZH0tZXJyYH0+XHJcbiAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuLyoqIElucHV0IGNvbSByw7N0dWxvIOKAlCBhdGFsaG8gcGFyYSBvIGNhc28gY29tdW0uICovXHJcbmV4cG9ydCBmdW5jdGlvbiBUZXh0RmllbGQoe1xyXG4gIGxhYmVsLFxyXG4gIGhpbnQsXHJcbiAgZXJyb3IsXHJcbiAgLi4ucmVzdFxyXG59OiB7IGxhYmVsOiBSZWFjdE5vZGU7IGhpbnQ/OiBSZWFjdE5vZGU7IGVycm9yPzogUmVhY3ROb2RlIH0gJiBJbnB1dEhUTUxBdHRyaWJ1dGVzPEhUTUxJbnB1dEVsZW1lbnQ+KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxGaWVsZCBsYWJlbD17bGFiZWx9IGhpbnQ9e2hpbnR9IGVycm9yPXtlcnJvcn0+XHJcbiAgICAgIHsoYTExeSkgPT4gPGlucHV0IHsuLi5hMTF5fSB7Li4ucmVzdH0gLz59XHJcbiAgICA8L0ZpZWxkPlxyXG4gICk7XHJcbn1cclxuXHJcbi8qKiBTZWxlY3QgY29tIHLDs3R1bG8uICovXHJcbmV4cG9ydCBmdW5jdGlvbiBTZWxlY3RGaWVsZCh7XHJcbiAgbGFiZWwsXHJcbiAgaGludCxcclxuICBlcnJvcixcclxuICBjaGlsZHJlbixcclxuICAuLi5yZXN0XHJcbn06IHtcclxuICBsYWJlbDogUmVhY3ROb2RlO1xyXG4gIGhpbnQ/OiBSZWFjdE5vZGU7XHJcbiAgZXJyb3I/OiBSZWFjdE5vZGU7XHJcbn0gJiBTZWxlY3RIVE1MQXR0cmlidXRlczxIVE1MU2VsZWN0RWxlbWVudD4pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPEZpZWxkIGxhYmVsPXtsYWJlbH0gaGludD17aGludH0gZXJyb3I9e2Vycm9yfT5cclxuICAgICAgeyhhMTF5KSA9PiAoXHJcbiAgICAgICAgPHNlbGVjdCB7Li4uYTExeX0gey4uLnJlc3R9PlxyXG4gICAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICApfVxyXG4gICAgPC9GaWVsZD5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy91aS9GaWVsZC50c3gifQ==