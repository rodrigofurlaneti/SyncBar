import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getIFoodOrderKpis } from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { Button } from "/src/ui/Button.tsx";
import { DashboardCard } from "/src/components/DashboardCard.tsx";
import { TextField } from "/src/ui/Field.tsx";
function parseBucket(bucket, index) {
  let parsed;
  try {
    parsed = JSON.parse(bucket);
  } catch {
    return null;
  }
  if (typeof parsed !== "object" || parsed === null) return null;
  const record = parsed;
  const label = typeof record.label === "string" ? record.label : `Métrica ${index + 1}`;
  const value = typeof record.value === "string" || typeof record.value === "number" ? record.value : "—";
  const trend = typeof record.trend === "number" ? record.trend : void 0;
  return { label, value, trend };
}
export function IFoodAnalyticsEnhancedPage() {
  _s();
  const { branchId } = useAuthStore();
  const [periodStart, setPeriodStart] = useState(() => {
    const d = /* @__PURE__ */ new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().split("T")[0];
  });
  const [periodEnd, setPeriodEnd] = useState((/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
  const kpisQuery = useQuery({
    queryKey: ["integrations", "ifood", "analytics", "kpis", branchId, periodStart, periodEnd],
    queryFn: () => getIFoodOrderKpis(branchId, { periodStart, periodEnd, page: 1 })
  });
  const data = kpisQuery.data;
  const kpis = (data?.buckets ?? []).map((bucket, idx) => parseBucket(bucket, idx)).filter((kpi) => kpi !== null);
  if (kpisQuery.isLoading) {
    return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1200, margin: "0 auto" }, children: [
      /* @__PURE__ */ jsxDEV(
        PageHeader,
        {
          title: "Analytics & Indicadores",
          subtitle: "KPIs e performance da loja",
          breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
          lineNumber: 79,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", padding: "40px 20px" }, children: /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)" }, children: "Carregando indicadores..." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 85,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 84,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this);
  }
  if (kpisQuery.isError) {
    return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1200, margin: "0 auto" }, children: [
      /* @__PURE__ */ jsxDEV(
        PageHeader,
        {
          title: "Analytics & Indicadores",
          subtitle: "KPIs e performance da loja",
          breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
          lineNumber: 94,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(QueryError, { error: kpisQuery.error, what: "os indicadores analytics" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 99,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 93,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1200, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "Analytics & Indicadores",
        subtitle: "KPIs e performance da loja no iFood",
        breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }],
        actions: /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            onClick: () => kpisQuery.refetch(),
            disabled: kpisQuery.isRefetching,
            children: [
              "🔄 ",
              kpisQuery.isRefetching ? "Atualizando..." : "Atualizar agora"
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
            lineNumber: 111,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 106,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, marginBottom: 20, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Data Inicial",
          type: "date",
          value: periodStart,
          onChange: (e) => setPeriodStart(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
          lineNumber: 123,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Data Final",
          type: "date",
          value: periodEnd,
          onChange: (e) => setPeriodEnd(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
          lineNumber: 129,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "flex-end" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => kpisQuery.refetch(), style: { width: "100%" }, children: "Filtrar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 136,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 135,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 122,
      columnNumber: 7
    }, this),
    kpis.length > 0 ? /* @__PURE__ */ jsxDEV("div", { style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
      gap: 12,
      marginBottom: 24
    }, children: kpis.map((kpi, idx) => {
      const trendDirection = kpi.trend && kpi.trend > 0 ? "up" : "down";
      return /* @__PURE__ */ jsxDEV(
        DashboardCard,
        {
          title: kpi.label,
          value: kpi.value,
          icon: "📊",
          status: "info",
          trend: kpi.trend ? { direction: trendDirection, percentage: Math.abs(kpi.trend) } : void 0
        },
        idx,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
          lineNumber: 153,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 144,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        title: "Sem dados",
        description: "Nenhum KPI disponível para o período selecionado. O iFood Analytics pode estar processando dados."
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 165,
        columnNumber: 7
      },
      this
    ),
    data?.buckets && data.buckets.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, marginBottom: 20 }, children: [
      /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "0.9rem", fontWeight: 700, margin: "0 0 12px" }, children: "📋 Dados Brutos (JSON)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 174,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: data.buckets.map(
        (bucket, idx) => /* @__PURE__ */ jsxDEV(
          "pre",
          {
            style: {
              padding: 12,
              background: "var(--surface-2)",
              borderRadius: 4,
              fontSize: "0.8rem",
              overflow: "auto",
              margin: 0,
              maxHeight: "200px"
            },
            children: (() => {
              try {
                return JSON.stringify(JSON.parse(bucket), null, 2);
              } catch {
                return bucket;
              }
            })()
          },
          idx,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
            lineNumber: 179,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 177,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 173,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, background: "#fff3e0", borderLeft: "3px solid #f57c00" }, children: /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.9rem", margin: 0, lineHeight: 1.6 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "⚠️ Nota sobre Analytics:" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
        lineNumber: 207,
        columnNumber: 11
      }, this),
      ' Os dados do módulo Analytics do iFood retornam JSON bruto de "buckets" agregados. A estrutura exata dos dados depende de seus filtros de agregação no backend. Consulte a documentação completa para entender o shape de cada métrica.'
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 206,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 205,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 32 }, children: /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "← Voltar ao iFood" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 216,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 215,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
      lineNumber: 214,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx",
    lineNumber: 105,
    columnNumber: 5
  }, this);
}
_s(IFoodAnalyticsEnhancedPage, "yvCq778PoQUIqBR4arZSEu4DrUw=", false, function() {
  return [useAuthStore, useQuery];
});
_c = IFoodAnalyticsEnhancedPage;
var _c;
$RefreshReg$(_c, "IFoodAnalyticsEnhancedPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodAnalyticsEnhancedPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRROzs7Ozs7Ozs7Ozs7Ozs7OztBQTNEUCxTQUFTQSxnQkFBZ0I7QUFDMUIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxpQkFBaUI7QUFVMUIsU0FBU0MsWUFBWUMsUUFBZ0JDLE9BQStCO0FBQ2xFLE1BQUlDO0FBQ0osTUFBSTtBQUNGQSxhQUFTQyxLQUFLQyxNQUFNSixNQUFNO0FBQUEsRUFDNUIsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxPQUFPRSxXQUFXLFlBQVlBLFdBQVcsS0FBTSxRQUFPO0FBQzFELFFBQU1HLFNBQVNIO0FBQ2YsUUFBTUksUUFBUSxPQUFPRCxPQUFPQyxVQUFVLFdBQVdELE9BQU9DLFFBQVEsV0FBV0wsUUFBUSxDQUFDO0FBQ3BGLFFBQU1NLFFBQ0osT0FBT0YsT0FBT0UsVUFBVSxZQUFZLE9BQU9GLE9BQU9FLFVBQVUsV0FBV0YsT0FBT0UsUUFBUTtBQUN4RixRQUFNQyxRQUFRLE9BQU9ILE9BQU9HLFVBQVUsV0FBV0gsT0FBT0csUUFBUUM7QUFDaEUsU0FBTyxFQUFFSCxPQUFPQyxPQUFPQyxNQUFNO0FBQy9CO0FBRU8sZ0JBQVNFLDZCQUE2QjtBQUFBQyxLQUFBO0FBQzNDLFFBQU0sRUFBRUMsU0FBUyxJQUFJcEIsYUFBYTtBQUNsQyxRQUFNLENBQUNxQixhQUFhQyxjQUFjLElBQUkxQixTQUFTLE1BQU07QUFDbkQsVUFBTTJCLElBQUksb0JBQUlDLEtBQUs7QUFDbkJELE1BQUVFLFFBQVFGLEVBQUVHLFFBQVEsSUFBSSxFQUFFO0FBQzFCLFdBQU9ILEVBQUVJLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3JDLENBQUM7QUFDRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSWxDLFVBQVMsb0JBQUk0QixLQUFLLEdBQUVHLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBRWpGLFFBQU1HLFlBQVlqQyxTQUFTO0FBQUEsSUFDekJrQyxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsYUFBYSxRQUFRWixVQUFVQyxhQUFhUSxTQUFTO0FBQUEsSUFDekZJLFNBQVNBLE1BQU1sQyxrQkFBa0JxQixVQUFVLEVBQUVDLGFBQWFRLFdBQVdLLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDaEYsQ0FBQztBQUVELFFBQU1DLE9BQU9KLFVBQVVJO0FBRXZCLFFBQU1DLFFBQVFELE1BQU1FLFdBQVcsSUFDNUJDLElBQUksQ0FBQzlCLFFBQVErQixRQUFRaEMsWUFBWUMsUUFBUStCLEdBQUcsQ0FBQyxFQUM3Q0MsT0FBTyxDQUFDQyxRQUF3QkEsUUFBUSxJQUFJO0FBRS9DLE1BQUlWLFVBQVVXLFdBQVc7QUFDdkIsV0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsU0FBUyxJQUFJQyxVQUFVLE1BQU1DLFFBQVEsU0FBUyxHQUMzRDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixVQUFTO0FBQUEsVUFDVCxZQUFZLENBQUMsRUFBRS9CLE9BQU8sU0FBU2dDLE1BQU0scUJBQXFCLENBQUM7QUFBQTtBQUFBLFFBSDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUcrRDtBQUFBLE1BRS9ELHVCQUFDLFNBQUksT0FBTyxFQUFFQyxXQUFXLFVBQVVKLFNBQVMsWUFBWSxHQUN0RCxpQ0FBQyxPQUFFLE9BQU8sRUFBRUssT0FBTyxtQkFBbUIsR0FBRyx5Q0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRSxLQURwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLEVBRUo7QUFFQSxNQUFJakIsVUFBVWtCLFNBQVM7QUFDckIsV0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRU4sU0FBUyxJQUFJQyxVQUFVLE1BQU1DLFFBQVEsU0FBUyxHQUMzRDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixVQUFTO0FBQUEsVUFDVCxZQUFZLENBQUMsRUFBRS9CLE9BQU8sU0FBU2dDLE1BQU0scUJBQXFCLENBQUM7QUFBQTtBQUFBLFFBSDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUcrRDtBQUFBLE1BRS9ELHVCQUFDLGNBQVcsT0FBT2YsVUFBVW1CLE9BQU8sTUFBSyw4QkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLFNBTnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFUCxTQUFTLElBQUlDLFVBQVUsTUFBTUMsUUFBUSxTQUFTLEdBQzNEO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLFVBQVM7QUFBQSxRQUNULFlBQVksQ0FBQyxFQUFFL0IsT0FBTyxTQUFTZ0MsTUFBTSxxQkFBcUIsQ0FBQztBQUFBLFFBQzNELFNBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLFNBQVMsTUFBTWYsVUFBVW9CLFFBQVE7QUFBQSxZQUNqQyxVQUFVcEIsVUFBVXFCO0FBQUFBLFlBQWE7QUFBQTtBQUFBLGNBRTdCckIsVUFBVXFCLGVBQWUsbUJBQW1CO0FBQUE7QUFBQTtBQUFBLFVBTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUE7QUFBQSxNQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVlHO0FBQUEsSUFJSCx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVULFNBQVMsSUFBSVUsY0FBYyxJQUFJQyxTQUFTLFFBQVFDLHFCQUFxQix3Q0FBd0NDLEtBQUssR0FBRyxHQUNsSjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixNQUFLO0FBQUEsVUFDTCxPQUFPbkM7QUFBQUEsVUFDUCxVQUFVLENBQUNvQyxNQUFNbkMsZUFBZW1DLEVBQUVDLE9BQU8zQyxLQUFLO0FBQUE7QUFBQSxRQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJa0Q7QUFBQSxNQUVsRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sTUFBSztBQUFBLFVBQ0wsT0FBT2M7QUFBQUEsVUFDUCxVQUFVLENBQUM0QixNQUFNM0IsYUFBYTJCLEVBQUVDLE9BQU8zQyxLQUFLO0FBQUE7QUFBQSxRQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJZ0Q7QUFBQSxNQUVoRCx1QkFBQyxTQUFJLE9BQU8sRUFBRXVDLFNBQVMsUUFBUUssWUFBWSxXQUFXLEdBQ3BELGlDQUFDLFVBQU8sU0FBUSxXQUFVLFNBQVMsTUFBTTVCLFVBQVVvQixRQUFRLEdBQUcsT0FBTyxFQUFFUyxPQUFPLE9BQU8sR0FBRyx1QkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLElBR0N4QixLQUFLeUIsU0FBUyxJQUNiLHVCQUFDLFNBQUksT0FBTztBQUFBLE1BQ1ZQLFNBQVM7QUFBQSxNQUNUQyxxQkFBcUI7QUFBQSxNQUNyQkMsS0FBSztBQUFBLE1BQ0xILGNBQWM7QUFBQSxJQUNoQixHQUNHakIsZUFBS0UsSUFBSSxDQUFDRyxLQUFLRixRQUFRO0FBQ3RCLFlBQU11QixpQkFBaUJyQixJQUFJekIsU0FBU3lCLElBQUl6QixRQUFRLElBQUksT0FBTztBQUMzRCxhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxPQUFPeUIsSUFBSTNCO0FBQUFBLFVBQ1gsT0FBTzJCLElBQUkxQjtBQUFBQSxVQUNYLE1BQUs7QUFBQSxVQUNMLFFBQU87QUFBQSxVQUNQLE9BQU8wQixJQUFJekIsUUFBUSxFQUFFK0MsV0FBV0QsZ0JBQWdCRSxZQUFZQyxLQUFLQyxJQUFJekIsSUFBSXpCLEtBQUssRUFBRSxJQUFJQztBQUFBQTtBQUFBQSxRQUwvRXNCO0FBQUFBLFFBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1nRztBQUFBLElBR3BHLENBQUMsS0FsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixhQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVpSDtBQUFBLElBS2xISixNQUFNRSxXQUFXRixLQUFLRSxRQUFRd0IsU0FBUyxLQUN0Qyx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVsQixTQUFTLElBQUlVLGNBQWMsR0FBRyxHQUMzRDtBQUFBLDZCQUFDLFFBQUcsT0FBTyxFQUFFYyxVQUFVLFVBQVVDLFlBQVksS0FBS3ZCLFFBQVEsV0FBVyxHQUFHLHNDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFUyxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUNuQ3JCLGVBQUtFLFFBQVFDO0FBQUFBLFFBQUksQ0FBQzlCLFFBQVErQixRQUN6QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsT0FBTztBQUFBLGNBQ0xJLFNBQVM7QUFBQSxjQUNUMEIsWUFBWTtBQUFBLGNBQ1pDLGNBQWM7QUFBQSxjQUNkSCxVQUFVO0FBQUEsY0FDVkksVUFBVTtBQUFBLGNBQ1YxQixRQUFRO0FBQUEsY0FDUjJCLFdBQVc7QUFBQSxZQUNiO0FBQUEsWUFFRSxpQkFBTTtBQUNOLGtCQUFJO0FBQ0YsdUJBQU83RCxLQUFLOEQsVUFBVTlELEtBQUtDLE1BQU1KLE1BQU0sR0FBRyxNQUFNLENBQUM7QUFBQSxjQUNuRCxRQUFRO0FBQ04sdUJBQU9BO0FBQUFBLGNBQ1Q7QUFBQSxZQUNGLEdBQUc7QUFBQTtBQUFBLFVBakJFK0I7QUFBQUEsVUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUJBO0FBQUEsTUFDRCxLQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBO0FBQUEsU0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQTtBQUFBLElBSUYsdUJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFSSxTQUFTLElBQUkwQixZQUFZLFdBQVdLLFlBQVksb0JBQW9CLEdBQ2pHLGlDQUFDLE9BQUUsT0FBTyxFQUFFUCxVQUFVLFVBQVV0QixRQUFRLEdBQUc4QixZQUFZLElBQUksR0FDekQ7QUFBQSw2QkFBQyxZQUFPLHdDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQSxNQUFTO0FBQUEsU0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsV0FBVyxHQUFHLEdBQzFCLGlDQUFDLFFBQUssSUFBRyxzQkFBcUIsT0FBTyxFQUFFQyxnQkFBZ0IsT0FBTyxHQUM1RCxpQ0FBQyxVQUFPLFNBQVEsU0FBUSxpQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQWpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0hBO0FBRUo7QUFBQzFELEdBcktlRCw0QkFBMEI7QUFBQSxVQUNuQmxCLGNBUUhGLFFBQVE7QUFBQTtBQUFBLEtBVFpvQjtBQUEwQixJQUFBNEQ7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJMaW5rIiwidXNlUXVlcnkiLCJnZXRJRm9vZE9yZGVyS3BpcyIsInVzZUF1dGhTdG9yZSIsIlBhZ2VIZWFkZXIiLCJRdWVyeUVycm9yIiwiRW1wdHlTdGF0ZSIsIkJ1dHRvbiIsIkRhc2hib2FyZENhcmQiLCJUZXh0RmllbGQiLCJwYXJzZUJ1Y2tldCIsImJ1Y2tldCIsImluZGV4IiwicGFyc2VkIiwiSlNPTiIsInBhcnNlIiwicmVjb3JkIiwibGFiZWwiLCJ2YWx1ZSIsInRyZW5kIiwidW5kZWZpbmVkIiwiSUZvb2RBbmFseXRpY3NFbmhhbmNlZFBhZ2UiLCJfcyIsImJyYW5jaElkIiwicGVyaW9kU3RhcnQiLCJzZXRQZXJpb2RTdGFydCIsImQiLCJEYXRlIiwic2V0RGF0ZSIsImdldERhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwicGVyaW9kRW5kIiwic2V0UGVyaW9kRW5kIiwia3Bpc1F1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicGFnZSIsImRhdGEiLCJrcGlzIiwiYnVja2V0cyIsIm1hcCIsImlkeCIsImZpbHRlciIsImtwaSIsImlzTG9hZGluZyIsInBhZGRpbmciLCJtYXhXaWR0aCIsIm1hcmdpbiIsImhyZWYiLCJ0ZXh0QWxpZ24iLCJjb2xvciIsImlzRXJyb3IiLCJlcnJvciIsInJlZmV0Y2giLCJpc1JlZmV0Y2hpbmciLCJtYXJnaW5Cb3R0b20iLCJkaXNwbGF5IiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImdhcCIsImUiLCJ0YXJnZXQiLCJhbGlnbkl0ZW1zIiwid2lkdGgiLCJsZW5ndGgiLCJ0cmVuZERpcmVjdGlvbiIsImRpcmVjdGlvbiIsInBlcmNlbnRhZ2UiLCJNYXRoIiwiYWJzIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwiYmFja2dyb3VuZCIsImJvcmRlclJhZGl1cyIsIm92ZXJmbG93IiwibWF4SGVpZ2h0Iiwic3RyaW5naWZ5IiwiYm9yZGVyTGVmdCIsImxpbmVIZWlnaHQiLCJtYXJnaW5Ub3AiLCJ0ZXh0RGVjb3JhdGlvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIklGb29kQW5hbHl0aWNzRW5oYW5jZWRQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IGdldElGb29kT3JkZXJLcGlzIH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9QYWdlSGVhZGVyXCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcbmltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tIFwiLi4vLi4vdWkvRW1wdHlTdGF0ZVwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IERhc2hib2FyZENhcmQgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9EYXNoYm9hcmRDYXJkXCI7XHJcbmltcG9ydCB7IFRleHRGaWVsZCB9IGZyb20gXCIuLi8uLi91aS9GaWVsZFwiO1xyXG5cclxuaW50ZXJmYWNlIEtwaURhdGEge1xyXG4gIGxhYmVsOiBzdHJpbmc7XHJcbiAgdmFsdWU6IG51bWJlciB8IHN0cmluZztcclxuICB0cmVuZD86IG51bWJlcjtcclxufVxyXG5cclxuLy8gQ2FkYSBidWNrZXQgw6kgSlNPTiBicnV0byBkbyBpRm9vZCBBbmFseXRpY3MgZSBuw6NvIHRlbSBzY2hlbWEgZ2FyYW50aWRvOiB1bSBidWNrZXQgbWFsZm9ybWFkb1xyXG4vLyBuw6NvIHBvZGUgZGVycnViYXIgb3MgZGVtYWlzLCBlbnTDo28gbyBwYXJzZSDDqSBmZWl0byBidWNrZXQgYSBidWNrZXQuXHJcbmZ1bmN0aW9uIHBhcnNlQnVja2V0KGJ1Y2tldDogc3RyaW5nLCBpbmRleDogbnVtYmVyKTogS3BpRGF0YSB8IG51bGwge1xyXG4gIGxldCBwYXJzZWQ6IHVua25vd247XHJcbiAgdHJ5IHtcclxuICAgIHBhcnNlZCA9IEpTT04ucGFyc2UoYnVja2V0KTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuICBpZiAodHlwZW9mIHBhcnNlZCAhPT0gXCJvYmplY3RcIiB8fCBwYXJzZWQgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IHJlY29yZCA9IHBhcnNlZCBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICBjb25zdCBsYWJlbCA9IHR5cGVvZiByZWNvcmQubGFiZWwgPT09IFwic3RyaW5nXCIgPyByZWNvcmQubGFiZWwgOiBgTcOpdHJpY2EgJHtpbmRleCArIDF9YDtcclxuICBjb25zdCB2YWx1ZSA9XHJcbiAgICB0eXBlb2YgcmVjb3JkLnZhbHVlID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiByZWNvcmQudmFsdWUgPT09IFwibnVtYmVyXCIgPyByZWNvcmQudmFsdWUgOiBcIuKAlFwiO1xyXG4gIGNvbnN0IHRyZW5kID0gdHlwZW9mIHJlY29yZC50cmVuZCA9PT0gXCJudW1iZXJcIiA/IHJlY29yZC50cmVuZCA6IHVuZGVmaW5lZDtcclxuICByZXR1cm4geyBsYWJlbCwgdmFsdWUsIHRyZW5kIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJRm9vZEFuYWx5dGljc0VuaGFuY2VkUGFnZSgpIHtcclxuICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbcGVyaW9kU3RhcnQsIHNldFBlcmlvZFN0YXJ0XSA9IHVzZVN0YXRlKCgpID0+IHtcclxuICAgIGNvbnN0IGQgPSBuZXcgRGF0ZSgpO1xyXG4gICAgZC5zZXREYXRlKGQuZ2V0RGF0ZSgpIC0gMzApO1xyXG4gICAgcmV0dXJuIGQudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgfSk7XHJcbiAgY29uc3QgW3BlcmlvZEVuZCwgc2V0UGVyaW9kRW5kXSA9IHVzZVN0YXRlKG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0pO1xyXG5cclxuICBjb25zdCBrcGlzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJhbmFseXRpY3NcIiwgXCJrcGlzXCIsIGJyYW5jaElkLCBwZXJpb2RTdGFydCwgcGVyaW9kRW5kXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldElGb29kT3JkZXJLcGlzKGJyYW5jaElkLCB7IHBlcmlvZFN0YXJ0LCBwZXJpb2RFbmQsIHBhZ2U6IDEgfSksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGRhdGEgPSBrcGlzUXVlcnkuZGF0YTtcclxuXHJcbiAgY29uc3Qga3BpcyA9IChkYXRhPy5idWNrZXRzID8/IFtdKVxyXG4gICAgLm1hcCgoYnVja2V0LCBpZHgpID0+IHBhcnNlQnVja2V0KGJ1Y2tldCwgaWR4KSlcclxuICAgIC5maWx0ZXIoKGtwaSk6IGtwaSBpcyBLcGlEYXRhID0+IGtwaSAhPT0gbnVsbCk7XHJcblxyXG4gIGlmIChrcGlzUXVlcnkuaXNMb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDEyMDAsIG1hcmdpbjogXCIwIGF1dG9cIiB9fT5cclxuICAgICAgICA8UGFnZUhlYWRlclxyXG4gICAgICAgICAgdGl0bGU9XCJBbmFseXRpY3MgJiBJbmRpY2Fkb3Jlc1wiXHJcbiAgICAgICAgICBzdWJ0aXRsZT1cIktQSXMgZSBwZXJmb3JtYW5jZSBkYSBsb2phXCJcclxuICAgICAgICAgIGJyZWFkY3J1bWI9e1t7IGxhYmVsOiBcImlGb29kXCIsIGhyZWY6IFwiL2ludGVncmFjb2VzL2lmb29kXCIgfV19XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgcGFkZGluZzogXCI0MHB4IDIwcHhcIiB9fT5cclxuICAgICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5DYXJyZWdhbmRvIGluZGljYWRvcmVzLi4uPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L21haW4+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKGtwaXNRdWVyeS5pc0Vycm9yKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDEyMDAsIG1hcmdpbjogXCIwIGF1dG9cIiB9fT5cclxuICAgICAgICA8UGFnZUhlYWRlclxyXG4gICAgICAgICAgdGl0bGU9XCJBbmFseXRpY3MgJiBJbmRpY2Fkb3Jlc1wiXHJcbiAgICAgICAgICBzdWJ0aXRsZT1cIktQSXMgZSBwZXJmb3JtYW5jZSBkYSBsb2phXCJcclxuICAgICAgICAgIGJyZWFkY3J1bWI9e1t7IGxhYmVsOiBcImlGb29kXCIsIGhyZWY6IFwiL2ludGVncmFjb2VzL2lmb29kXCIgfV19XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8UXVlcnlFcnJvciBlcnJvcj17a3Bpc1F1ZXJ5LmVycm9yfSB3aGF0PVwib3MgaW5kaWNhZG9yZXMgYW5hbHl0aWNzXCIgLz5cclxuICAgICAgPC9tYWluPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDEyMDAsIG1hcmdpbjogXCIwIGF1dG9cIiB9fT5cclxuICAgICAgPFBhZ2VIZWFkZXJcclxuICAgICAgICB0aXRsZT1cIkFuYWx5dGljcyAmIEluZGljYWRvcmVzXCJcclxuICAgICAgICBzdWJ0aXRsZT1cIktQSXMgZSBwZXJmb3JtYW5jZSBkYSBsb2phIG5vIGlGb29kXCJcclxuICAgICAgICBicmVhZGNydW1iPXtbeyBsYWJlbDogXCJpRm9vZFwiLCBocmVmOiBcIi9pbnRlZ3JhY29lcy9pZm9vZFwiIH1dfVxyXG4gICAgICAgIGFjdGlvbnM9e1xyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBrcGlzUXVlcnkucmVmZXRjaCgpfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17a3Bpc1F1ZXJ5LmlzUmVmZXRjaGluZ31cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAg8J+UhCB7a3Bpc1F1ZXJ5LmlzUmVmZXRjaGluZyA/IFwiQXR1YWxpemFuZG8uLi5cIiA6IFwiQXR1YWxpemFyIGFnb3JhXCJ9XHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICB9XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICB7LyogRmlsdHJvcyBkZSBQZXLDrW9kbyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogMTYsIG1hcmdpbkJvdHRvbTogMjAsIGRpc3BsYXk6IFwiZ3JpZFwiLCBncmlkVGVtcGxhdGVDb2x1bW5zOiBcInJlcGVhdChhdXRvLWZpdCwgbWlubWF4KDE1MHB4LCAxZnIpKVwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgIGxhYmVsPVwiRGF0YSBJbmljaWFsXCJcclxuICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgIHZhbHVlPXtwZXJpb2RTdGFydH1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGVyaW9kU3RhcnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgbGFiZWw9XCJEYXRhIEZpbmFsXCJcclxuICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgIHZhbHVlPXtwZXJpb2RFbmR9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBlcmlvZEVuZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgb25DbGljaz17KCkgPT4ga3Bpc1F1ZXJ5LnJlZmV0Y2goKX0gc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19PlxyXG4gICAgICAgICAgICBGaWx0cmFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogS1BJcyAqL31cclxuICAgICAge2twaXMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICA8ZGl2IHN0eWxlPXt7XHJcbiAgICAgICAgICBkaXNwbGF5OiBcImdyaWRcIixcclxuICAgICAgICAgIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwicmVwZWF0KGF1dG8tZml0LCBtaW5tYXgoMjUwcHgsIDFmcikpXCIsXHJcbiAgICAgICAgICBnYXA6IDEyLFxyXG4gICAgICAgICAgbWFyZ2luQm90dG9tOiAyNCxcclxuICAgICAgICB9fT5cclxuICAgICAgICAgIHtrcGlzLm1hcCgoa3BpLCBpZHgpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgdHJlbmREaXJlY3Rpb24gPSBrcGkudHJlbmQgJiYga3BpLnRyZW5kID4gMCA/IFwidXBcIiA6IFwiZG93blwiO1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxEYXNoYm9hcmRDYXJkXHJcbiAgICAgICAgICAgICAgICBrZXk9e2lkeH1cclxuICAgICAgICAgICAgICAgIHRpdGxlPXtrcGkubGFiZWx9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17a3BpLnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgaWNvbj1cIvCfk4pcIlxyXG4gICAgICAgICAgICAgICAgc3RhdHVzPVwiaW5mb1wiXHJcbiAgICAgICAgICAgICAgICB0cmVuZD17a3BpLnRyZW5kID8geyBkaXJlY3Rpb246IHRyZW5kRGlyZWN0aW9uLCBwZXJjZW50YWdlOiBNYXRoLmFicyhrcGkudHJlbmQpIH0gOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICB0aXRsZT1cIlNlbSBkYWRvc1wiXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbj1cIk5lbmh1bSBLUEkgZGlzcG9uw612ZWwgcGFyYSBvIHBlcsOtb2RvIHNlbGVjaW9uYWRvLiBPIGlGb29kIEFuYWx5dGljcyBwb2RlIGVzdGFyIHByb2Nlc3NhbmRvIGRhZG9zLlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBKU09OIEJydXRvIHBhcmEgRGVidWcvRXhwb3J0YcOnw6NvICovfVxyXG4gICAgICB7ZGF0YT8uYnVja2V0cyAmJiBkYXRhLmJ1Y2tldHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogMTYsIG1hcmdpbkJvdHRvbTogMjAgfX0+XHJcbiAgICAgICAgICA8aDMgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45cmVtXCIsIGZvbnRXZWlnaHQ6IDcwMCwgbWFyZ2luOiBcIjAgMCAxMnB4XCIgfX0+XHJcbiAgICAgICAgICAgIPCfk4sgRGFkb3MgQnJ1dG9zIChKU09OKVxyXG4gICAgICAgICAgPC9oMz5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAge2RhdGEuYnVja2V0cy5tYXAoKGJ1Y2tldCwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgPHByZVxyXG4gICAgICAgICAgICAgICAga2V5PXtpZHh9XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICBwYWRkaW5nOiAxMixcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1zdXJmYWNlLTIpXCIsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogNCxcclxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC44cmVtXCIsXHJcbiAgICAgICAgICAgICAgICAgIG92ZXJmbG93OiBcImF1dG9cIixcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgICBtYXhIZWlnaHQ6IFwiMjAwcHhcIixcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgeygoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KEpTT04ucGFyc2UoYnVja2V0KSwgbnVsbCwgMik7XHJcbiAgICAgICAgICAgICAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBidWNrZXQ7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pKCl9XHJcbiAgICAgICAgICAgICAgPC9wcmU+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogTm90YXMgc29icmUgQW5hbHl0aWNzICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNiwgYmFja2dyb3VuZDogXCIjZmZmM2UwXCIsIGJvcmRlckxlZnQ6IFwiM3B4IHNvbGlkICNmNTdjMDBcIiB9fT5cclxuICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiwgbWFyZ2luOiAwLCBsaW5lSGVpZ2h0OiAxLjYgfX0+XHJcbiAgICAgICAgICA8c3Ryb25nPuKaoO+4jyBOb3RhIHNvYnJlIEFuYWx5dGljczo8L3N0cm9uZz4gT3MgZGFkb3MgZG8gbcOzZHVsbyBBbmFseXRpY3MgZG8gaUZvb2QgcmV0b3JuYW0gSlNPTiBicnV0byBkZSBcImJ1Y2tldHNcIiBhZ3JlZ2Fkb3MuXHJcbiAgICAgICAgICBBIGVzdHJ1dHVyYSBleGF0YSBkb3MgZGFkb3MgZGVwZW5kZSBkZSBzZXVzIGZpbHRyb3MgZGUgYWdyZWdhw6fDo28gbm8gYmFja2VuZC4gQ29uc3VsdGUgYSBkb2N1bWVudGHDp8OjbyBjb21wbGV0YSBwYXJhXHJcbiAgICAgICAgICBlbnRlbmRlciBvIHNoYXBlIGRlIGNhZGEgbcOpdHJpY2EuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBGb290ZXIgKi99XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAzMiB9fT5cclxuICAgICAgICA8TGluayB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZFwiIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiB9fT5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCI+4oaQIFZvbHRhciBhbyBpRm9vZDwvQnV0dG9uPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvaW50ZWdyYXRpb25zL0lGb29kQW5hbHl0aWNzRW5oYW5jZWRQYWdlLnRzeCJ9