import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/promotions/PromotionsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { useDialog } from "/src/ui/Dialog.tsx";
import { createPromotion, deactivatePromotion, getPromotionsByBranch } from "/src/features/promotions/api.ts";
import { getMenu } from "/src/features/catalog/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { PromotionType, dayOfWeekLabel, hhmmToMinutes, minutesToHHmm, promotionBadge } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { Overlay } from "/src/features/orders/Overlay.tsx";
export function PromotionsPage() {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const { branchId, companyId } = useAuthStore();
  const [creating, setCreating] = useState(false);
  const [productId, setProductId] = useState("");
  const [name, setName] = useState("");
  const [dayOfWeek, setDayOfWeek] = useState(3);
  const [startTime, setStartTime] = useState("16:00");
  const [endTime, setEndTime] = useState("20:00");
  const [typeId, setTypeId] = useState(PromotionType.EmDobro);
  const [discountPct, setDiscountPct] = useState("25");
  const [error, setError] = useState(null);
  const promotionsQuery = useQuery({
    queryKey: ["promotions", branchId],
    queryFn: () => getPromotionsByBranch(branchId)
  });
  const menuQuery = useQuery({
    queryKey: ["menu", companyId],
    queryFn: () => getMenu(companyId ?? 1)
  });
  const productName = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const p of menuQuery.data ?? []) map.set(p.id, p.name);
    return map;
  }, [menuQuery.data]);
  const byDay = useMemo(() => {
    const groups = /* @__PURE__ */ new Map();
    for (const promo of promotionsQuery.data ?? []) {
      const list = groups.get(promo.dayOfWeek) ?? [];
      groups.set(promo.dayOfWeek, [...list ?? [], promo]);
    }
    return groups;
  }, [promotionsQuery.data]);
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["promotions"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const startMin = hhmmToMinutes(startTime);
  const endMin = hhmmToMinutes(endTime);
  const windowValid = startMin !== null && endMin !== null && startMin < endMin;
  const pct = Number(discountPct.replace(",", "."));
  const discountValid = typeId !== PromotionType.Desconto || Number.isFinite(pct) && pct > 0 && pct < 100;
  const createMutation = useMutation({
    mutationFn: () => createPromotion({
      branchId,
      productId: Number(productId),
      name: name.trim(),
      dayOfWeek,
      startMinuteOfDay: startMin ?? 0,
      endMinuteOfDay: endMin ?? 0,
      promotionTypeId: typeId,
      discountRate: typeId === PromotionType.Desconto ? pct / 100 : null
    }),
    onSuccess: () => {
      setError(null);
      setCreating(false);
      setName("");
      setProductId("");
      refresh();
    },
    onError: onApiError
  });
  const removeMutation = useMutation({
    mutationFn: (id) => deactivatePromotion(id),
    onSuccess: refresh,
    onError: onApiError
  });
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 6, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Promoções" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 111,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "em dobro: o cliente paga 1 e leva 2 — vale só para pedidos dentro da janela" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 115,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: () => {
        setError(null);
        setCreating(true);
      }, children: "+ Nova promoção" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 116,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    promotionsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: promotionsQuery.error, what: "as promoções" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
      lineNumber: 121,
      columnNumber: 35
    }, this),
    error && !creating && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
      lineNumber: 122,
      columnNumber: 30
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rise rise-1", style: { display: "grid", gap: 12, marginTop: 12 }, children: [
      [1, 2, 3, 4, 5, 6, 0].map((day) => {
        const promos = byDay.get(day) ?? [];
        if (promos.length === 0) return null;
        return /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem", color: "var(--amber)" }, children: dayOfWeekLabel[day] }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 131,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 130,
            columnNumber: 15
          }, this),
          promos.map(
            (promo) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
                /* @__PURE__ */ jsxDEV("span", { children: [
                  promo.name,
                  /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      style: {
                        marginLeft: 8,
                        fontFamily: "var(--font-cond)",
                        fontSize: "0.68rem",
                        letterSpacing: "0.08em",
                        color: "var(--amber-ink)",
                        background: "var(--amber)",
                        borderRadius: 4,
                        padding: "2px 6px",
                        fontWeight: 700
                      },
                      children: promotionBadge(promo)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
                      lineNumber: 140,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
                  lineNumber: 138,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
                  productName.get(promo.productId) ?? `Produto ${promo.productId}`,
                  " · das",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: minutesToHHmm(promo.startMinuteOfDay) }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
                    lineNumber: 158,
                    columnNumber: 23
                  }, this),
                  " às",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: minutesToHHmm(promo.endMinuteOfDay) }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
                    lineNumber: 159,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
                  lineNumber: 156,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
                lineNumber: 137,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "btn-danger",
                  style: { minHeight: 44, padding: "0 10px", fontSize: "0.85rem" },
                  disabled: removeMutation.isPending,
                  onClick: async () => {
                    if (await dialog.confirm({
                      title: "Encerrar promoção",
                      message: `Encerrar a promoção "${promo.name}"?`,
                      confirmLabel: "Encerrar",
                      danger: true
                    }))
                      removeMutation.mutate(promo.id);
                  },
                  children: "Encerrar"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
                  lineNumber: 162,
                  columnNumber: 19
                },
                this
              )
            ] }, promo.id, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
              lineNumber: 136,
              columnNumber: 15
            }, this)
          )
        ] }, day, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 129,
          columnNumber: 13
        }, this);
      }),
      (promotionsQuery.data ?? []).length === 0 && !promotionsQuery.isLoading && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)" }, children: "Nenhuma promoção programada." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 187,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
      lineNumber: 124,
      columnNumber: 7
    }, this),
    creating && /* @__PURE__ */ jsxDEV(Overlay, { title: "Nova promoção em dobro", onClose: () => setCreating(false), children: [
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Nome" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 194,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("input", { placeholder: "ex.: Quarta da caipirinha", value: name, onChange: (e) => setName(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 195,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 193,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Produto" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 198,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("select", { value: productId, onChange: (e) => setProductId(e.target.value), children: [
          /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione…" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 200,
            columnNumber: 15
          }, this),
          (menuQuery.data ?? []).map(
            (p) => /* @__PURE__ */ jsxDEV("option", { value: p.id, children: p.name }, p.id, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
              lineNumber: 202,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 199,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 197,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8, gridTemplateColumns: "1fr 1fr" }, children: [
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Tipo" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 208,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("select", { value: typeId, onChange: (e) => setTypeId(Number(e.target.value)), children: [
            /* @__PURE__ */ jsxDEV("option", { value: PromotionType.EmDobro, children: "Em dobro (paga 1 leva 2)" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
              lineNumber: 210,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: PromotionType.Desconto, children: "Desconto %" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
              lineNumber: 211,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 209,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 207,
          columnNumber: 13
        }, this),
        typeId === PromotionType.Desconto ? /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Desconto (%)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 216,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { inputMode: "decimal", value: discountPct, onChange: (e) => setDiscountPct(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 217,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 215,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 220,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 206,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8, gridTemplateColumns: "1.2fr 1fr 1fr" }, children: [
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Dia da semana" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 225,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("select", { value: dayOfWeek, onChange: (e) => setDayOfWeek(Number(e.target.value)), children: [1, 2, 3, 4, 5, 6, 0].map(
            (d) => /* @__PURE__ */ jsxDEV("option", { value: d, children: dayOfWeekLabel[d] }, d, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
              lineNumber: 228,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 226,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 224,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Início" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 233,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "time", value: startTime, onChange: (e) => setStartTime(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 234,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 232,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Fim" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 237,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "time", value: endTime, onChange: (e) => setEndTime(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
            lineNumber: 238,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 236,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 223,
        columnNumber: 11
      }, this),
      !windowValid && (startTime !== "" || endTime !== "") && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)", fontSize: "0.85rem", margin: 0 }, children: "O horário inicial precisa ser antes do final." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 242,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
        lineNumber: 246,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          disabled: name.trim() === "" || productId === "" || !windowValid || !discountValid || createMutation.isPending,
          onClick: () => createMutation.mutate(),
          children: createMutation.isPending ? "Criando…" : "Criar promoção"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
          lineNumber: 247,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
      lineNumber: 192,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx",
    lineNumber: 109,
    columnNumber: 5
  }, this);
}
_s(PromotionsPage, "RG092ly3HSY6dUdFQIEf//kyp0A=", false, function() {
  return [useQueryClient, useDialog, useAuthStore, useQuery, useQuery, useMutation, useMutation];
});
_c = PromotionsPage;
var _c;
$RefreshReg$(_c, "PromotionsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/promotions/PromotionsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkZROzs7Ozs7Ozs7Ozs7Ozs7OztBQTNGUixTQUFTQSxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxpQkFBaUJDLHFCQUFxQkMsNkJBQTZCO0FBQzVFLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlQyxnQkFBZ0JDLGVBQWVDLGVBQWVDLHNCQUFzQjtBQUM1RixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsZUFBZTtBQUVqQixnQkFBU0MsaUJBQWlCO0FBQUFDLEtBQUE7QUFDL0IsUUFBTUMsY0FBY2pCLGVBQWU7QUFDbkMsUUFBTWtCLFNBQVNqQixVQUFVO0FBQ3pCLFFBQU0sRUFBRWtCLFVBQVVDLFVBQVUsSUFBSWQsYUFBYTtBQUM3QyxRQUFNLENBQUNlLFVBQVVDLFdBQVcsSUFBSXpCLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUMwQixXQUFXQyxZQUFZLElBQUkzQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDNEIsTUFBTUMsT0FBTyxJQUFJN0IsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQzhCLFdBQVdDLFlBQVksSUFBSS9CLFNBQVMsQ0FBQztBQUM1QyxRQUFNLENBQUNnQyxXQUFXQyxZQUFZLElBQUlqQyxTQUFTLE9BQU87QUFDbEQsUUFBTSxDQUFDa0MsU0FBU0MsVUFBVSxJQUFJbkMsU0FBUyxPQUFPO0FBQzlDLFFBQU0sQ0FBQ29DLFFBQVFDLFNBQVMsSUFBSXJDLFNBQWlCVyxjQUFjMkIsT0FBTztBQUNsRSxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSXhDLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUN5QyxPQUFPQyxRQUFRLElBQUkxQyxTQUF3QixJQUFJO0FBRXRELFFBQU0yQyxrQkFBa0J6QyxTQUFTO0FBQUEsSUFDL0IwQyxVQUFVLENBQUMsY0FBY3RCLFFBQVE7QUFBQSxJQUNqQ3VCLFNBQVNBLE1BQU10QyxzQkFBc0JlLFFBQVE7QUFBQSxFQUMvQyxDQUFDO0FBRUQsUUFBTXdCLFlBQVk1QyxTQUFTO0FBQUEsSUFDekIwQyxVQUFVLENBQUMsUUFBUXJCLFNBQVM7QUFBQSxJQUM1QnNCLFNBQVNBLE1BQU1yQyxRQUFRZSxhQUFhLENBQUM7QUFBQSxFQUN2QyxDQUFDO0FBRUQsUUFBTXdCLGNBQWNoRCxRQUFRLE1BQU07QUFDaEMsVUFBTWlELE1BQU0sb0JBQUlDLElBQW9CO0FBQ3BDLGVBQVdDLEtBQUtKLFVBQVVLLFFBQVEsR0FBSUgsS0FBSUksSUFBSUYsRUFBRUcsSUFBSUgsRUFBRXRCLElBQUk7QUFDMUQsV0FBT29CO0FBQUFBLEVBQ1QsR0FBRyxDQUFDRixVQUFVSyxJQUFJLENBQUM7QUFFbkIsUUFBTUcsUUFBUXZELFFBQVEsTUFBTTtBQUMxQixVQUFNd0QsU0FBUyxvQkFBSU4sSUFBeUM7QUFDNUQsZUFBV08sU0FBU2IsZ0JBQWdCUSxRQUFRLElBQUk7QUFDOUMsWUFBTU0sT0FBT0YsT0FBT0csSUFBSUYsTUFBTTFCLFNBQVMsS0FBSztBQUM1Q3lCLGFBQU9ILElBQUlJLE1BQU0xQixXQUFXLENBQUMsR0FBSTJCLFFBQVEsSUFBS0QsS0FBSyxDQUFDO0FBQUEsSUFDdEQ7QUFDQSxXQUFPRDtBQUFBQSxFQUNULEdBQUcsQ0FBQ1osZ0JBQWdCUSxJQUFJLENBQUM7QUFFekIsUUFBTVEsVUFBVUEsTUFBTSxLQUFLdkMsWUFBWXdDLGtCQUFrQixFQUFFaEIsVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3JGLFFBQU1pQixhQUFhQSxDQUFDQyxNQUNsQnBCLFNBQVNvQixhQUFhcEQsV0FBV29ELEVBQUVDLFVBQVUsa0JBQWtCO0FBRWpFLFFBQU1DLFdBQVduRCxjQUFjbUIsU0FBUztBQUN4QyxRQUFNaUMsU0FBU3BELGNBQWNxQixPQUFPO0FBQ3BDLFFBQU1nQyxjQUFjRixhQUFhLFFBQVFDLFdBQVcsUUFBUUQsV0FBV0M7QUFDdkUsUUFBTUUsTUFBTUMsT0FBTzdCLFlBQVk4QixRQUFRLEtBQUssR0FBRyxDQUFDO0FBQ2hELFFBQU1DLGdCQUFnQmxDLFdBQVd6QixjQUFjNEQsWUFBYUgsT0FBT0ksU0FBU0wsR0FBRyxLQUFLQSxNQUFNLEtBQUtBLE1BQU07QUFFckcsUUFBTU0saUJBQWlCeEUsWUFBWTtBQUFBLElBQ2pDeUUsWUFBWUEsTUFDVnJFLGdCQUFnQjtBQUFBLE1BQ2RpQjtBQUFBQSxNQUNBSSxXQUFXMEMsT0FBTzFDLFNBQVM7QUFBQSxNQUMzQkUsTUFBTUEsS0FBSytDLEtBQUs7QUFBQSxNQUNoQjdDO0FBQUFBLE1BQ0E4QyxrQkFBa0JaLFlBQVk7QUFBQSxNQUM5QmEsZ0JBQWdCWixVQUFVO0FBQUEsTUFDMUJhLGlCQUFpQjFDO0FBQUFBLE1BQ2pCMkMsY0FBYzNDLFdBQVd6QixjQUFjNEQsV0FBV0osTUFBTSxNQUFNO0FBQUEsSUFDaEUsQ0FBQztBQUFBLElBQ0hhLFdBQVdBLE1BQU07QUFDZnRDLGVBQVMsSUFBSTtBQUNiakIsa0JBQVksS0FBSztBQUNqQkksY0FBUSxFQUFFO0FBQ1ZGLG1CQUFhLEVBQUU7QUFDZmdDLGNBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQXNCLFNBQVNwQjtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNcUIsaUJBQWlCakYsWUFBWTtBQUFBLElBQ2pDeUUsWUFBWUEsQ0FBQ3JCLE9BQWUvQyxvQkFBb0IrQyxFQUFFO0FBQUEsSUFDbEQyQixXQUFXckI7QUFBQUEsSUFDWHNCLFNBQVNwQjtBQUFBQSxFQUNYLENBQUM7QUFFRCxTQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFc0IsU0FBUyxJQUFJQyxVQUFVLE1BQU1DLFFBQVEsU0FBUyxHQUMzRDtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxZQUFZLFlBQVlDLEtBQUssSUFBSUMsY0FBYyxHQUFHQyxVQUFVLE9BQU8sR0FDakg7QUFBQSw2QkFBQyxRQUFHLFdBQVUsV0FBVSxPQUFPLEVBQUVDLFVBQVUsU0FBUyxHQUFHLHlCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdFO0FBQUEsTUFDaEUsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sb0JBQW9CRCxVQUFVLFNBQVMsR0FBRywyRkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUUsTUFBTSxFQUFFLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGVBQWMsU0FBUyxNQUFNO0FBQUVuRCxpQkFBUyxJQUFJO0FBQUdqQixvQkFBWSxJQUFJO0FBQUEsTUFBRyxHQUFHLCtCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUNrQixnQkFBZ0JtRCxXQUFXLHVCQUFDLGNBQVcsT0FBT25ELGdCQUFnQkYsT0FBTyxNQUFLLGtCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZEO0FBQUEsSUFDeEZBLFNBQVMsQ0FBQ2pCLFlBQVksdUJBQUMsT0FBRSxXQUFVLGNBQWNpQixtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLElBRXhELHVCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU8sRUFBRTZDLFNBQVMsUUFBUUUsS0FBSyxJQUFJTyxXQUFXLEdBQUcsR0FDM0U7QUFBQSxPQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsRUFBRS9DLElBQUksQ0FBQ2dELFFBQVE7QUFDbEMsY0FBTUMsU0FBUzNDLE1BQU1JLElBQUlzQyxHQUFHLEtBQUs7QUFDakMsWUFBSUMsT0FBT0MsV0FBVyxFQUFHLFFBQU87QUFDaEMsZUFDRSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxlQUNiLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRVAsVUFBVSxVQUFVQyxPQUFPLGVBQWUsR0FDMUVoRix5QkFBZW9GLEdBQUcsS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNDQyxPQUFPakQ7QUFBQUEsWUFBSSxDQUFDUSxVQUNYLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsU0FBSSxPQUFPLEVBQUU4QixTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUNwQztBQUFBLHVDQUFDLFVBQ0VoQztBQUFBQSx3QkFBTTVCO0FBQUFBLGtCQUNQO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU87QUFBQSx3QkFDTHVFLFlBQVk7QUFBQSx3QkFDWkMsWUFBWTtBQUFBLHdCQUNaVCxVQUFVO0FBQUEsd0JBQ1ZVLGVBQWU7QUFBQSx3QkFDZlQsT0FBTztBQUFBLHdCQUNQVSxZQUFZO0FBQUEsd0JBQ1pDLGNBQWM7QUFBQSx3QkFDZHBCLFNBQVM7QUFBQSx3QkFDVHFCLFlBQVk7QUFBQSxzQkFDZDtBQUFBLHNCQUVDekYseUJBQWV5QyxLQUFLO0FBQUE7QUFBQSxvQkFidkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWNBO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVtQyxVQUFVLFVBQVVDLE9BQU8sbUJBQW1CLEdBQzFEN0M7QUFBQUEsOEJBQVlXLElBQUlGLE1BQU05QixTQUFTLEtBQUssV0FBVzhCLE1BQU05QixTQUFTO0FBQUEsa0JBQUc7QUFBQSxrQkFBTztBQUFBLGtCQUN6RSx1QkFBQyxVQUFLLFdBQVUsWUFBWVosd0JBQWMwQyxNQUFNb0IsZ0JBQWdCLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtFO0FBQUEsa0JBQU87QUFBQSxrQkFBSTtBQUFBLGtCQUM3RSx1QkFBQyxVQUFLLFdBQVUsWUFBWTlELHdCQUFjMEMsTUFBTXFCLGNBQWMsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0U7QUFBQSxxQkFIbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdCQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixPQUFPLEVBQUU0QixXQUFXLElBQUl0QixTQUFTLFVBQVVRLFVBQVUsVUFBVTtBQUFBLGtCQUMvRCxVQUFVVCxlQUFld0I7QUFBQUEsa0JBQ3pCLFNBQVMsWUFBWTtBQUNuQix3QkFDRSxNQUFNckYsT0FBT3NGLFFBQVE7QUFBQSxzQkFDbkJDLE9BQU87QUFBQSxzQkFDUDdDLFNBQVMsd0JBQXdCUCxNQUFNNUIsSUFBSTtBQUFBLHNCQUMzQ2lGLGNBQWM7QUFBQSxzQkFDZEMsUUFBUTtBQUFBLG9CQUNWLENBQUM7QUFFRDVCLHFDQUFlNkIsT0FBT3ZELE1BQU1ILEVBQUU7QUFBQSxrQkFDbEM7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBa0JBO0FBQUEsaUJBNUMrQkcsTUFBTUgsSUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2Q0E7QUFBQSxVQUNEO0FBQUEsYUFyRDBCMkMsS0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNEQTtBQUFBLE1BRUosQ0FBQztBQUFBLE9BQ0NyRCxnQkFBZ0JRLFFBQVEsSUFBSStDLFdBQVcsS0FBSyxDQUFDdkQsZ0JBQWdCcUUsYUFDN0QsdUJBQUMsT0FBRSxPQUFPLEVBQUVwQixPQUFPLG1CQUFtQixHQUFHLDRDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsU0EvRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpRUE7QUFBQSxJQUVDcEUsWUFDQyx1QkFBQyxXQUFRLE9BQU0sMEJBQXlCLFNBQVMsTUFBTUMsWUFBWSxLQUFLLEdBQ3RFO0FBQUEsNkJBQUMsV0FBTSxPQUFPLEVBQUU2RCxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUN0QztBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFSSxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsb0JBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQSxRQUNuRSx1QkFBQyxXQUFNLGFBQVksNkJBQTRCLE9BQU8vRCxNQUFNLFVBQVUsQ0FBQ2tDLE1BQU1qQyxRQUFRaUMsRUFBRW1ELE9BQU9DLEtBQUssS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRztBQUFBLFdBRnZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsV0FBTSxPQUFPLEVBQUU1QixTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUN0QztBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFSSxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsdUJBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUN0RSx1QkFBQyxZQUFPLE9BQU9qRSxXQUFXLFVBQVUsQ0FBQ29DLE1BQU1uQyxhQUFhbUMsRUFBRW1ELE9BQU9DLEtBQUssR0FDcEU7QUFBQSxpQ0FBQyxZQUFPLE9BQU0sSUFBRywwQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxXQUN6QnBFLFVBQVVLLFFBQVEsSUFBSUg7QUFBQUEsWUFBSSxDQUFDRSxNQUMzQix1QkFBQyxZQUFrQixPQUFPQSxFQUFFRyxJQUFLSCxZQUFFdEIsUUFBdEJzQixFQUFFRyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsVUFDekM7QUFBQSxhQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWlDLFNBQVMsUUFBUUUsS0FBSyxHQUFHMkIscUJBQXFCLFVBQVUsR0FDcEU7QUFBQSwrQkFBQyxXQUFNLE9BQU8sRUFBRTdCLFNBQVMsUUFBUUUsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsaUNBQUMsVUFBSyxPQUFPLEVBQUVJLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBRyxvQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUU7QUFBQSxVQUNuRSx1QkFBQyxZQUFPLE9BQU92RCxRQUFRLFVBQVUsQ0FBQzBCLE1BQU16QixVQUFVK0IsT0FBT04sRUFBRW1ELE9BQU9DLEtBQUssQ0FBQyxHQUN0RTtBQUFBLG1DQUFDLFlBQU8sT0FBT3ZHLGNBQWMyQixTQUFTLHdDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzlELHVCQUFDLFlBQU8sT0FBTzNCLGNBQWM0RCxVQUFVLDBCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLGVBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0NuQyxXQUFXekIsY0FBYzRELFdBQ3hCLHVCQUFDLFdBQU0sT0FBTyxFQUFFZSxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUN0QztBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFSSxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsNEJBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsV0FBTSxXQUFVLFdBQVUsT0FBT3BELGFBQWEsVUFBVSxDQUFDdUIsTUFBTXRCLGVBQWVzQixFQUFFbUQsT0FBT0MsS0FBSyxLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRjtBQUFBLGFBRmpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxJQUVBLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFLO0FBQUEsV0FkVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRTVCLFNBQVMsUUFBUUUsS0FBSyxHQUFHMkIscUJBQXFCLGdCQUFnQixHQUMxRTtBQUFBLCtCQUFDLFdBQU0sT0FBTyxFQUFFN0IsU0FBUyxRQUFRRSxLQUFLLEVBQUUsR0FDdEM7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUksT0FBTyxrQkFBa0JELFVBQVUsVUFBVSxHQUFHLDZCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLFVBQzVFLHVCQUFDLFlBQU8sT0FBTzdELFdBQVcsVUFBVSxDQUFDZ0MsTUFBTS9CLGFBQWFxQyxPQUFPTixFQUFFbUQsT0FBT0MsS0FBSyxDQUFDLEdBQzNFLFdBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxFQUFFbEU7QUFBQUEsWUFBSSxDQUFDb0UsTUFDMUIsdUJBQUMsWUFBZSxPQUFPQSxHQUFJeEcseUJBQWV3RyxDQUFDLEtBQTlCQSxHQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsVUFDOUMsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sT0FBTyxFQUFFOUIsU0FBUyxRQUFRRSxLQUFLLEVBQUUsR0FDdEM7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUksT0FBTyxrQkFBa0JELFVBQVUsVUFBVSxHQUFHLHNCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLFVBQ3JFLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE9BQU8zRCxXQUFXLFVBQVUsQ0FBQzhCLE1BQU03QixhQUFhNkIsRUFBRW1ELE9BQU9DLEtBQUssS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxhQUZyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sT0FBTyxFQUFFNUIsU0FBUyxRQUFRRSxLQUFLLEVBQUUsR0FDdEM7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUksT0FBTyxrQkFBa0JELFVBQVUsVUFBVSxHQUFHLG1CQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRTtBQUFBLFVBQ2xFLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE9BQU96RCxTQUFTLFVBQVUsQ0FBQzRCLE1BQU0zQixXQUFXMkIsRUFBRW1ELE9BQU9DLEtBQUssS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxhQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsTUFDQyxDQUFDaEQsZ0JBQWdCbEMsY0FBYyxNQUFNRSxZQUFZLE9BQ2hELHVCQUFDLE9BQUUsT0FBTyxFQUFFMEQsT0FBTyxvQkFBb0JELFVBQVUsV0FBV04sUUFBUSxFQUFFLEdBQUcsNkRBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUQ1QyxTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQzNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFDVixVQUFVYixLQUFLK0MsS0FBSyxNQUFNLE1BQU1qRCxjQUFjLE1BQU0sQ0FBQ3dDLGVBQWUsQ0FBQ0ksaUJBQWlCRyxlQUFlaUM7QUFBQUEsVUFDckcsU0FBUyxNQUFNakMsZUFBZXNDLE9BQU87QUFBQSxVQUVwQ3RDLHlCQUFlaUMsWUFBWSxhQUFhO0FBQUE7QUFBQSxRQU4zQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErREE7QUFBQSxPQWxKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0pBO0FBRUo7QUFBQ3ZGLEdBcE9lRCxnQkFBYztBQUFBLFVBQ1JmLGdCQUNMQyxXQUNpQkssY0FXUlAsVUFLTkEsVUE4QktELGFBc0JBQSxXQUFXO0FBQUE7QUFBQSxLQXZFcEJpQjtBQUFjLElBQUFtRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJ1c2VEaWFsb2ciLCJjcmVhdGVQcm9tb3Rpb24iLCJkZWFjdGl2YXRlUHJvbW90aW9uIiwiZ2V0UHJvbW90aW9uc0J5QnJhbmNoIiwiZ2V0TWVudSIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwiUHJvbW90aW9uVHlwZSIsImRheU9mV2Vla0xhYmVsIiwiaGhtbVRvTWludXRlcyIsIm1pbnV0ZXNUb0hIbW0iLCJwcm9tb3Rpb25CYWRnZSIsIlF1ZXJ5RXJyb3IiLCJPdmVybGF5IiwiUHJvbW90aW9uc1BhZ2UiLCJfcyIsInF1ZXJ5Q2xpZW50IiwiZGlhbG9nIiwiYnJhbmNoSWQiLCJjb21wYW55SWQiLCJjcmVhdGluZyIsInNldENyZWF0aW5nIiwicHJvZHVjdElkIiwic2V0UHJvZHVjdElkIiwibmFtZSIsInNldE5hbWUiLCJkYXlPZldlZWsiLCJzZXREYXlPZldlZWsiLCJzdGFydFRpbWUiLCJzZXRTdGFydFRpbWUiLCJlbmRUaW1lIiwic2V0RW5kVGltZSIsInR5cGVJZCIsInNldFR5cGVJZCIsIkVtRG9icm8iLCJkaXNjb3VudFBjdCIsInNldERpc2NvdW50UGN0IiwiZXJyb3IiLCJzZXRFcnJvciIsInByb21vdGlvbnNRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsIm1lbnVRdWVyeSIsInByb2R1Y3ROYW1lIiwibWFwIiwiTWFwIiwicCIsImRhdGEiLCJzZXQiLCJpZCIsImJ5RGF5IiwiZ3JvdXBzIiwicHJvbW8iLCJsaXN0IiwiZ2V0IiwicmVmcmVzaCIsImludmFsaWRhdGVRdWVyaWVzIiwib25BcGlFcnJvciIsImUiLCJtZXNzYWdlIiwic3RhcnRNaW4iLCJlbmRNaW4iLCJ3aW5kb3dWYWxpZCIsInBjdCIsIk51bWJlciIsInJlcGxhY2UiLCJkaXNjb3VudFZhbGlkIiwiRGVzY29udG8iLCJpc0Zpbml0ZSIsImNyZWF0ZU11dGF0aW9uIiwibXV0YXRpb25GbiIsInRyaW0iLCJzdGFydE1pbnV0ZU9mRGF5IiwiZW5kTWludXRlT2ZEYXkiLCJwcm9tb3Rpb25UeXBlSWQiLCJkaXNjb3VudFJhdGUiLCJvblN1Y2Nlc3MiLCJvbkVycm9yIiwicmVtb3ZlTXV0YXRpb24iLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsIm1hcmdpbkJvdHRvbSIsImZsZXhXcmFwIiwiZm9udFNpemUiLCJjb2xvciIsImZsZXgiLCJpc0Vycm9yIiwibWFyZ2luVG9wIiwiZGF5IiwicHJvbW9zIiwibGVuZ3RoIiwibWFyZ2luTGVmdCIsImZvbnRGYW1pbHkiLCJsZXR0ZXJTcGFjaW5nIiwiYmFja2dyb3VuZCIsImJvcmRlclJhZGl1cyIsImZvbnRXZWlnaHQiLCJtaW5IZWlnaHQiLCJpc1BlbmRpbmciLCJjb25maXJtIiwidGl0bGUiLCJjb25maXJtTGFiZWwiLCJkYW5nZXIiLCJtdXRhdGUiLCJpc0xvYWRpbmciLCJ0YXJnZXQiLCJ2YWx1ZSIsImdyaWRUZW1wbGF0ZUNvbHVtbnMiLCJkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvbW90aW9uc1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IHVzZURpYWxvZyB9IGZyb20gXCIuLi8uLi91aS9EaWFsb2dcIjtcclxuaW1wb3J0IHsgY3JlYXRlUHJvbW90aW9uLCBkZWFjdGl2YXRlUHJvbW90aW9uLCBnZXRQcm9tb3Rpb25zQnlCcmFuY2ggfSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgZ2V0TWVudSB9IGZyb20gXCIuLi9jYXRhbG9nL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IFByb21vdGlvblR5cGUsIGRheU9mV2Vla0xhYmVsLCBoaG1tVG9NaW51dGVzLCBtaW51dGVzVG9ISG1tLCBwcm9tb3Rpb25CYWRnZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuaW1wb3J0IHsgT3ZlcmxheSB9IGZyb20gXCIuLi9vcmRlcnMvT3ZlcmxheVwiO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFByb21vdGlvbnNQYWdlKCkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCBkaWFsb2cgPSB1c2VEaWFsb2coKTtcclxuICBjb25zdCB7IGJyYW5jaElkLCBjb21wYW55SWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IFtjcmVhdGluZywgc2V0Q3JlYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtwcm9kdWN0SWQsIHNldFByb2R1Y3RJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGF5T2ZXZWVrLCBzZXREYXlPZldlZWtdID0gdXNlU3RhdGUoMyk7XHJcbiAgY29uc3QgW3N0YXJ0VGltZSwgc2V0U3RhcnRUaW1lXSA9IHVzZVN0YXRlKFwiMTY6MDBcIik7XHJcbiAgY29uc3QgW2VuZFRpbWUsIHNldEVuZFRpbWVdID0gdXNlU3RhdGUoXCIyMDowMFwiKTtcclxuICBjb25zdCBbdHlwZUlkLCBzZXRUeXBlSWRdID0gdXNlU3RhdGU8bnVtYmVyPihQcm9tb3Rpb25UeXBlLkVtRG9icm8pO1xyXG4gIGNvbnN0IFtkaXNjb3VudFBjdCwgc2V0RGlzY291bnRQY3RdID0gdXNlU3RhdGUoXCIyNVwiKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBwcm9tb3Rpb25zUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wicHJvbW90aW9uc1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRQcm9tb3Rpb25zQnlCcmFuY2goYnJhbmNoSWQpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBtZW51UXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wibWVudVwiLCBjb21wYW55SWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0TWVudShjb21wYW55SWQgPz8gMSksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHByb2R1Y3ROYW1lID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwPG51bWJlciwgc3RyaW5nPigpO1xyXG4gICAgZm9yIChjb25zdCBwIG9mIG1lbnVRdWVyeS5kYXRhID8/IFtdKSBtYXAuc2V0KHAuaWQsIHAubmFtZSk7XHJcbiAgICByZXR1cm4gbWFwO1xyXG4gIH0sIFttZW51UXVlcnkuZGF0YV0pO1xyXG5cclxuICBjb25zdCBieURheSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZ3JvdXBzID0gbmV3IE1hcDxudW1iZXIsIHR5cGVvZiBwcm9tb3Rpb25zUXVlcnkuZGF0YT4oKTtcclxuICAgIGZvciAoY29uc3QgcHJvbW8gb2YgcHJvbW90aW9uc1F1ZXJ5LmRhdGEgPz8gW10pIHtcclxuICAgICAgY29uc3QgbGlzdCA9IGdyb3Vwcy5nZXQocHJvbW8uZGF5T2ZXZWVrKSA/PyBbXTtcclxuICAgICAgZ3JvdXBzLnNldChwcm9tby5kYXlPZldlZWssIFsuLi4obGlzdCA/PyBbXSksIHByb21vXSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZ3JvdXBzO1xyXG4gIH0sIFtwcm9tb3Rpb25zUXVlcnkuZGF0YV0pO1xyXG5cclxuICBjb25zdCByZWZyZXNoID0gKCkgPT4gdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJwcm9tb3Rpb25zXCJdIH0pO1xyXG4gIGNvbnN0IG9uQXBpRXJyb3IgPSAoZTogdW5rbm93bikgPT5cclxuICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGUubWVzc2FnZSA6IFwiT3BlcmHDp8OjbyBmYWxob3UuXCIpO1xyXG5cclxuICBjb25zdCBzdGFydE1pbiA9IGhobW1Ub01pbnV0ZXMoc3RhcnRUaW1lKTtcclxuICBjb25zdCBlbmRNaW4gPSBoaG1tVG9NaW51dGVzKGVuZFRpbWUpO1xyXG4gIGNvbnN0IHdpbmRvd1ZhbGlkID0gc3RhcnRNaW4gIT09IG51bGwgJiYgZW5kTWluICE9PSBudWxsICYmIHN0YXJ0TWluIDwgZW5kTWluO1xyXG4gIGNvbnN0IHBjdCA9IE51bWJlcihkaXNjb3VudFBjdC5yZXBsYWNlKFwiLFwiLCBcIi5cIikpO1xyXG4gIGNvbnN0IGRpc2NvdW50VmFsaWQgPSB0eXBlSWQgIT09IFByb21vdGlvblR5cGUuRGVzY29udG8gfHwgKE51bWJlci5pc0Zpbml0ZShwY3QpICYmIHBjdCA+IDAgJiYgcGN0IDwgMTAwKTtcclxuXHJcbiAgY29uc3QgY3JlYXRlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICBjcmVhdGVQcm9tb3Rpb24oe1xyXG4gICAgICAgIGJyYW5jaElkLFxyXG4gICAgICAgIHByb2R1Y3RJZDogTnVtYmVyKHByb2R1Y3RJZCksXHJcbiAgICAgICAgbmFtZTogbmFtZS50cmltKCksXHJcbiAgICAgICAgZGF5T2ZXZWVrLFxyXG4gICAgICAgIHN0YXJ0TWludXRlT2ZEYXk6IHN0YXJ0TWluID8/IDAsXHJcbiAgICAgICAgZW5kTWludXRlT2ZEYXk6IGVuZE1pbiA/PyAwLFxyXG4gICAgICAgIHByb21vdGlvblR5cGVJZDogdHlwZUlkLFxyXG4gICAgICAgIGRpc2NvdW50UmF0ZTogdHlwZUlkID09PSBQcm9tb3Rpb25UeXBlLkRlc2NvbnRvID8gcGN0IC8gMTAwIDogbnVsbCxcclxuICAgICAgfSksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgIHNldENyZWF0aW5nKGZhbHNlKTtcclxuICAgICAgc2V0TmFtZShcIlwiKTtcclxuICAgICAgc2V0UHJvZHVjdElkKFwiXCIpO1xyXG4gICAgICByZWZyZXNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcmVtb3ZlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoaWQ6IG51bWJlcikgPT4gZGVhY3RpdmF0ZVByb21vdGlvbihpZCksXHJcbiAgICBvblN1Y2Nlc3M6IHJlZnJlc2gsXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMTAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImJhc2VsaW5lXCIsIGdhcDogMTQsIG1hcmdpbkJvdHRvbTogNiwgZmxleFdyYXA6IFwid3JhcFwiIH19PlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS43cmVtXCIgfX0+UHJvbW/Dp8O1ZXM8L2gyPlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+XHJcbiAgICAgICAgICBlbSBkb2JybzogbyBjbGllbnRlIHBhZ2EgMSBlIGxldmEgMiDigJQgdmFsZSBzw7MgcGFyYSBwZWRpZG9zIGRlbnRybyBkYSBqYW5lbGFcclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSB9fSAvPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgb25DbGljaz17KCkgPT4geyBzZXRFcnJvcihudWxsKTsgc2V0Q3JlYXRpbmcodHJ1ZSk7IH19PlxyXG4gICAgICAgICAgKyBOb3ZhIHByb21vw6fDo29cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7cHJvbW90aW9uc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e3Byb21vdGlvbnNRdWVyeS5lcnJvcn0gd2hhdD1cImFzIHByb21vw6fDtWVzXCIgLz59XHJcbiAgICAgIHtlcnJvciAmJiAhY3JlYXRpbmcgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyLCBtYXJnaW5Ub3A6IDEyIH19PlxyXG4gICAgICAgIHtbMSwgMiwgMywgNCwgNSwgNiwgMF0ubWFwKChkYXkpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHByb21vcyA9IGJ5RGF5LmdldChkYXkpID8/IFtdO1xyXG4gICAgICAgICAgaWYgKHByb21vcy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIiBrZXk9e2RheX0+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtaGVhZFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMnJlbVwiLCBjb2xvcjogXCJ2YXIoLS1hbWJlcilcIiB9fT5cclxuICAgICAgICAgICAgICAgICAge2RheU9mV2Vla0xhYmVsW2RheV19XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge3Byb21vcy5tYXAoKHByb21vKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBrZXk9e3Byb21vLmlkfT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3Byb21vLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbkxlZnQ6IDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseTogXCJ2YXIoLS1mb250LWNvbmQpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC42OHJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wOGVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwidmFyKC0tYW1iZXItaW5rKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwidmFyKC0tYW1iZXIpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMnB4IDZweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDcwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Byb21vdGlvbkJhZGdlKHByb21vKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0TmFtZS5nZXQocHJvbW8ucHJvZHVjdElkKSA/PyBgUHJvZHV0byAke3Byb21vLnByb2R1Y3RJZH1gfSDCtyBkYXN7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiPnttaW51dGVzVG9ISG1tKHByb21vLnN0YXJ0TWludXRlT2ZEYXkpfTwvc3Bhbj4gw6Bze1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIj57bWludXRlc1RvSEhtbShwcm9tby5lbmRNaW51dGVPZkRheSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTBweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVtb3ZlTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgZGlhbG9nLmNvbmZpcm0oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIkVuY2VycmFyIHByb21vw6fDo29cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBgRW5jZXJyYXIgYSBwcm9tb8Onw6NvIFwiJHtwcm9tby5uYW1lfVwiP2AsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uZmlybUxhYmVsOiBcIkVuY2VycmFyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGFuZ2VyOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZW1vdmVNdXRhdGlvbi5tdXRhdGUocHJvbW8uaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBFbmNlcnJhclxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSl9XHJcbiAgICAgICAgeyhwcm9tb3Rpb25zUXVlcnkuZGF0YSA/PyBbXSkubGVuZ3RoID09PSAwICYmICFwcm9tb3Rpb25zUXVlcnkuaXNMb2FkaW5nICYmIChcclxuICAgICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5OZW5odW1hIHByb21vw6fDo28gcHJvZ3JhbWFkYS48L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7Y3JlYXRpbmcgJiYgKFxyXG4gICAgICAgIDxPdmVybGF5IHRpdGxlPVwiTm92YSBwcm9tb8Onw6NvIGVtIGRvYnJvXCIgb25DbG9zZT17KCkgPT4gc2V0Q3JlYXRpbmcoZmFsc2UpfT5cclxuICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+Tm9tZTwvc3Bhbj5cclxuICAgICAgICAgICAgPGlucHV0IHBsYWNlaG9sZGVyPVwiZXguOiBRdWFydGEgZGEgY2FpcGlyaW5oYVwiIHZhbHVlPXtuYW1lfSBvbkNoYW5nZT17KGUpID0+IHNldE5hbWUoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+UHJvZHV0bzwvc3Bhbj5cclxuICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17cHJvZHVjdElkfSBvbkNoYW5nZT17KGUpID0+IHNldFByb2R1Y3RJZChlLnRhcmdldC52YWx1ZSl9PlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2lvbmXigKY8L29wdGlvbj5cclxuICAgICAgICAgICAgICB7KG1lbnVRdWVyeS5kYXRhID8/IFtdKS5tYXAoKHApID0+IChcclxuICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+e3AubmFtZX08L29wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA4LCBncmlkVGVtcGxhdGVDb2x1bW5zOiBcIjFmciAxZnJcIiB9fT5cclxuICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlRpcG88L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17dHlwZUlkfSBvbkNoYW5nZT17KGUpID0+IHNldFR5cGVJZChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX0+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXtQcm9tb3Rpb25UeXBlLkVtRG9icm99PkVtIGRvYnJvIChwYWdhIDEgbGV2YSAyKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17UHJvbW90aW9uVHlwZS5EZXNjb250b30+RGVzY29udG8gJTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICB7dHlwZUlkID09PSBQcm9tb3Rpb25UeXBlLkRlc2NvbnRvID8gKFxyXG4gICAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PkRlc2NvbnRvICglKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dCBpbnB1dE1vZGU9XCJkZWNpbWFsXCIgdmFsdWU9e2Rpc2NvdW50UGN0fSBvbkNoYW5nZT17KGUpID0+IHNldERpc2NvdW50UGN0KGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxzcGFuIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCwgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCIxLjJmciAxZnIgMWZyXCIgfX0+XHJcbiAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5EaWEgZGEgc2VtYW5hPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e2RheU9mV2Vla30gb25DaGFuZ2U9eyhlKSA9PiBzZXREYXlPZldlZWsoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9PlxyXG4gICAgICAgICAgICAgICAge1sxLCAyLCAzLCA0LCA1LCA2LCAwXS5tYXAoKGQpID0+IChcclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2R9IHZhbHVlPXtkfT57ZGF5T2ZXZWVrTGFiZWxbZF19PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19Pkluw61jaW88L3NwYW4+XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0aW1lXCIgdmFsdWU9e3N0YXJ0VGltZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRTdGFydFRpbWUoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+RmltPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGltZVwiIHZhbHVlPXtlbmRUaW1lfSBvbkNoYW5nZT17KGUpID0+IHNldEVuZFRpbWUoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB7IXdpbmRvd1ZhbGlkICYmIChzdGFydFRpbWUgIT09IFwiXCIgfHwgZW5kVGltZSAhPT0gXCJcIikgJiYgKFxyXG4gICAgICAgICAgICA8cCBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgbWFyZ2luOiAwIH19PlxyXG4gICAgICAgICAgICAgIE8gaG9yw6FyaW8gaW5pY2lhbCBwcmVjaXNhIHNlciBhbnRlcyBkbyBmaW5hbC5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtuYW1lLnRyaW0oKSA9PT0gXCJcIiB8fCBwcm9kdWN0SWQgPT09IFwiXCIgfHwgIXdpbmRvd1ZhbGlkIHx8ICFkaXNjb3VudFZhbGlkIHx8IGNyZWF0ZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY3JlYXRlTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtjcmVhdGVNdXRhdGlvbi5pc1BlbmRpbmcgPyBcIkNyaWFuZG/igKZcIiA6IFwiQ3JpYXIgcHJvbW/Dp8Ojb1wifVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9PdmVybGF5PlxyXG4gICAgICApfVxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3Byb21vdGlvbnMvUHJvbW90aW9uc1BhZ2UudHN4In0=