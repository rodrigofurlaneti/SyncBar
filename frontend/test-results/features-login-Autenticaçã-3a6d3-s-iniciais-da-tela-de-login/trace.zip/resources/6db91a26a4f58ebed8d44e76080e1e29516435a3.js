import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/tabs/TabMesas.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { TableStatus, formatBRL } from "/src/lib/types.ts";
export function TabMesas({ activeAreaId, myTables, ordersByTableId, onTableClick }) {
  if (!activeAreaId) return /* @__PURE__ */ jsxDEV("p", { className: "waiter-empty", children: "Nenhuma praça vinculada a você no momento." }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
    lineNumber: 31,
    columnNumber: 29
  }, this);
  if (myTables.length === 0) return /* @__PURE__ */ jsxDEV("p", { className: "waiter-empty", children: "Nenhuma mesa foi configurada nesta praça." }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
    lineNumber: 32,
    columnNumber: 37
  }, this);
  return /* @__PURE__ */ jsxDEV("section", { className: "waiter-section", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "waiter-section-title", style: { marginBottom: 16 }, children: "Minhas Mesas" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
      lineNumber: 36,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "waiter-tables-grid", style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: "14px" }, children: myTables.map((table) => {
      const order = ordersByTableId.get(table.id);
      let leftBorderColor = "var(--w-ok)";
      let statusBg = "color-mix(in srgb, var(--w-ok) 15%, transparent)";
      let statusColor = "var(--w-ok)";
      let statusText = "LIVRE";
      let subText = `${table.capacity ?? 4} lugares`;
      if (table.tableStatusId === TableStatus.Ocupada) {
        leftBorderColor = "var(--w-warn)";
        statusBg = "color-mix(in srgb, var(--w-warn) 15%, transparent)";
        statusColor = "var(--w-warn)";
        statusText = "OCUPADA";
        if (order) subText = `${order.items.length} itens - ${formatBRL(order.totalAmount)}`;
      } else if (table.tableStatusId === TableStatus.EmFechamento) {
        leftBorderColor = "var(--w-info)";
        statusBg = "color-mix(in srgb, var(--w-info) 15%, transparent)";
        statusColor = "var(--w-info)";
        statusText = "FECHANDO";
      }
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onTableClick(table.id, table.tableStatusId),
          style: {
            display: "flex",
            flexDirection: "column",
            alignItems: "stretch",
            backgroundColor: "var(--w-bg-card)",
            borderRadius: "12px",
            border: "1px solid var(--w-line)",
            borderLeft: `6px solid ${leftBorderColor}`,
            padding: "14px 16px",
            cursor: "pointer",
            textAlign: "left",
            minHeight: "88px",
            justifyContent: "center"
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%", marginBottom: "6px" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontFamily: "var(--font-display)", fontSize: "2rem", color: "var(--w-ink)", lineHeight: 1 }, children: table.number }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
                lineNumber: 81,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.65rem", fontWeight: "700", backgroundColor: statusBg, color: statusColor, padding: "4px 8px", borderRadius: "20px", display: "flex", alignItems: "center", gap: "4px", textTransform: "uppercase" }, children: [
                /* @__PURE__ */ jsxDEV("span", { style: { width: "6px", height: "6px", borderRadius: "50%", backgroundColor: statusColor } }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
                  lineNumber: 85,
                  columnNumber: 37
                }, this),
                statusText
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
                lineNumber: 84,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
              lineNumber: 79,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--w-ink-dim)", fontWeight: 500 }, children: subText }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
              lineNumber: 89,
              columnNumber: 29
            }, this)
          ]
        },
        table.id,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
          lineNumber: 61,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
      lineNumber: 37,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx",
    lineNumber: 35,
    columnNumber: 5
  }, this);
}
_c = TabMesas;
var _c;
$RefreshReg$(_c, "TabMesas");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMesas.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVzhCOzs7Ozs7Ozs7Ozs7Ozs7O0FBWDdCLFNBQVNBLGFBQWFDLGlCQUFpQjtBQVVqQyxnQkFBU0MsU0FBUyxFQUFFQyxjQUFjQyxVQUFVQyxpQkFBaUJDLGFBQTRCLEdBQUc7QUFDL0YsTUFBSSxDQUFDSCxhQUFjLFFBQU8sdUJBQUMsT0FBRSxXQUFVLGdCQUFlLDBEQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNFO0FBQ2hHLE1BQUlDLFNBQVNHLFdBQVcsRUFBRyxRQUFPLHVCQUFDLE9BQUUsV0FBVSxnQkFBZSx5REFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxRTtBQUV2RyxTQUNJLHVCQUFDLGFBQVEsV0FBVSxrQkFDZjtBQUFBLDJCQUFDLFFBQUcsV0FBVSx3QkFBdUIsT0FBTyxFQUFFQyxjQUFjLEdBQUcsR0FBRyw0QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RTtBQUFBLElBQzlFLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFQyxTQUFTLFFBQVFDLHFCQUFxQix5Q0FBeUNDLEtBQUssT0FBTyxHQUNuSVAsbUJBQVNRLElBQUksQ0FBQ0MsVUFBVTtBQUNyQixZQUFNQyxRQUFRVCxnQkFBZ0JVLElBQUlGLE1BQU1HLEVBQUU7QUFFMUMsVUFBSUMsa0JBQWtCO0FBQ3RCLFVBQUlDLFdBQVc7QUFDZixVQUFJQyxjQUFjO0FBQ2xCLFVBQUlDLGFBQWE7QUFDakIsVUFBSUMsVUFBVSxHQUFHUixNQUFNUyxZQUFZLENBQUM7QUFFcEMsVUFBSVQsTUFBTVUsa0JBQWtCdkIsWUFBWXdCLFNBQVM7QUFDN0NQLDBCQUFrQjtBQUNsQkMsbUJBQVc7QUFDWEMsc0JBQWM7QUFDZEMscUJBQWE7QUFDYixZQUFJTixNQUFPTyxXQUFVLEdBQUdQLE1BQU1XLE1BQU1sQixNQUFNLFlBQVlOLFVBQVVhLE1BQU1ZLFdBQVcsQ0FBQztBQUFBLE1BQ3RGLFdBQVdiLE1BQU1VLGtCQUFrQnZCLFlBQVkyQixjQUFjO0FBQ3pEViwwQkFBa0I7QUFDbEJDLG1CQUFXO0FBQ1hDLHNCQUFjO0FBQ2RDLHFCQUFhO0FBQUEsTUFDakI7QUFFQSxhQUNJO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFRyxTQUFTLE1BQU1kLGFBQWFPLE1BQU1HLElBQUlILE1BQU1VLGFBQWE7QUFBQSxVQUN6RCxPQUFPO0FBQUEsWUFDSGQsU0FBUztBQUFBLFlBQ1RtQixlQUFlO0FBQUEsWUFDZkMsWUFBWTtBQUFBLFlBQ1pDLGlCQUFpQjtBQUFBLFlBQ2pCQyxjQUFjO0FBQUEsWUFDZEMsUUFBUTtBQUFBLFlBQ1JDLFlBQVksYUFBYWhCLGVBQWU7QUFBQSxZQUN4Q2lCLFNBQVM7QUFBQSxZQUNUQyxRQUFRO0FBQUEsWUFDUkMsV0FBVztBQUFBLFlBQ1hDLFdBQVc7QUFBQSxZQUNYQyxnQkFBZ0I7QUFBQSxVQUNwQjtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRTdCLFNBQVMsUUFBUW9CLFlBQVksVUFBVVMsZ0JBQWdCLGlCQUFpQkMsT0FBTyxRQUFRL0IsY0FBYyxNQUFNLEdBRXJIO0FBQUEscUNBQUMsVUFBSyxPQUFPLEVBQUVnQyxZQUFZLHVCQUF1QkMsVUFBVSxRQUFRQyxPQUFPLGdCQUFnQkMsWUFBWSxFQUFFLEdBQ3BHOUIsZ0JBQU0rQixVQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFSCxVQUFVLFdBQVdJLFlBQVksT0FBT2YsaUJBQWlCWixVQUFVd0IsT0FBT3ZCLGFBQWFlLFNBQVMsV0FBV0gsY0FBYyxRQUFRdEIsU0FBUyxRQUFRb0IsWUFBWSxVQUFVbEIsS0FBSyxPQUFPbUMsZUFBZSxZQUFZLEdBQzFOO0FBQUEsdUNBQUMsVUFBSyxPQUFPLEVBQUVQLE9BQU8sT0FBT1EsUUFBUSxPQUFPaEIsY0FBYyxPQUFPRCxpQkFBaUJYLFlBQVksS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0c7QUFBQSxnQkFDL0ZDO0FBQUFBLG1CQUZMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRXFCLFVBQVUsV0FBV0MsT0FBTyxvQkFBb0JHLFlBQVksSUFBSSxHQUMxRXhCLHFCQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQTtBQUFBO0FBQUEsUUE3QktSLE1BQU1HO0FBQUFBLFFBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQStCQTtBQUFBLElBRVIsQ0FBQyxLQXpETDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsT0E1REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZEQTtBQUVSO0FBQUNnQyxLQXBFZTlDO0FBQVEsSUFBQThDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlRhYmxlU3RhdHVzIiwiZm9ybWF0QlJMIiwiVGFiTWVzYXMiLCJhY3RpdmVBcmVhSWQiLCJteVRhYmxlcyIsIm9yZGVyc0J5VGFibGVJZCIsIm9uVGFibGVDbGljayIsImxlbmd0aCIsIm1hcmdpbkJvdHRvbSIsImRpc3BsYXkiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwiZ2FwIiwibWFwIiwidGFibGUiLCJvcmRlciIsImdldCIsImlkIiwibGVmdEJvcmRlckNvbG9yIiwic3RhdHVzQmciLCJzdGF0dXNDb2xvciIsInN0YXR1c1RleHQiLCJzdWJUZXh0IiwiY2FwYWNpdHkiLCJ0YWJsZVN0YXR1c0lkIiwiT2N1cGFkYSIsIml0ZW1zIiwidG90YWxBbW91bnQiLCJFbUZlY2hhbWVudG8iLCJmbGV4RGlyZWN0aW9uIiwiYWxpZ25JdGVtcyIsImJhY2tncm91bmRDb2xvciIsImJvcmRlclJhZGl1cyIsImJvcmRlciIsImJvcmRlckxlZnQiLCJwYWRkaW5nIiwiY3Vyc29yIiwidGV4dEFsaWduIiwibWluSGVpZ2h0IiwianVzdGlmeUNvbnRlbnQiLCJ3aWR0aCIsImZvbnRGYW1pbHkiLCJmb250U2l6ZSIsImNvbG9yIiwibGluZUhlaWdodCIsIm51bWJlciIsImZvbnRXZWlnaHQiLCJ0ZXh0VHJhbnNmb3JtIiwiaGVpZ2h0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGFiTWVzYXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IFRhYmxlU3RhdHVzLCBmb3JtYXRCUkwgfSBmcm9tIFwiLi4vLi4vLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB0eXBlIHsgVGFibGVSZXNwb25zZSwgT3JkZXJSZXNwb25zZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9saWIvdHlwZXNcIjtcclxuXHJcbmludGVyZmFjZSBUYWJNZXNhc1Byb3BzIHtcclxuICAgIGFjdGl2ZUFyZWFJZDogbnVtYmVyIHwgbnVsbDtcclxuICAgIG15VGFibGVzOiBUYWJsZVJlc3BvbnNlW107XHJcbiAgICBvcmRlcnNCeVRhYmxlSWQ6IE1hcDxudW1iZXIsIE9yZGVyUmVzcG9uc2U+O1xyXG4gICAgb25UYWJsZUNsaWNrOiAodGFibGVJZDogbnVtYmVyLCBzdGF0dXNJZDogbnVtYmVyKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVGFiTWVzYXMoeyBhY3RpdmVBcmVhSWQsIG15VGFibGVzLCBvcmRlcnNCeVRhYmxlSWQsIG9uVGFibGVDbGljayB9OiBUYWJNZXNhc1Byb3BzKSB7XHJcbiAgICBpZiAoIWFjdGl2ZUFyZWFJZCkgcmV0dXJuIDxwIGNsYXNzTmFtZT1cIndhaXRlci1lbXB0eVwiPk5lbmh1bWEgcHJhw6dhIHZpbmN1bGFkYSBhIHZvY8OqIG5vIG1vbWVudG8uPC9wPjtcclxuICAgIGlmIChteVRhYmxlcy5sZW5ndGggPT09IDApIHJldHVybiA8cCBjbGFzc05hbWU9XCJ3YWl0ZXItZW1wdHlcIj5OZW5odW1hIG1lc2EgZm9pIGNvbmZpZ3VyYWRhIG5lc3RhIHByYcOnYS48L3A+O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwid2FpdGVyLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIndhaXRlci1zZWN0aW9uLXRpdGxlXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAxNiB9fT5NaW5oYXMgTWVzYXM8L2gyPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndhaXRlci10YWJsZXMtZ3JpZFwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBncmlkVGVtcGxhdGVDb2x1bW5zOiBcInJlcGVhdChhdXRvLWZpbGwsIG1pbm1heCgxNTBweCwgMWZyKSlcIiwgZ2FwOiBcIjE0cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgIHtteVRhYmxlcy5tYXAoKHRhYmxlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgb3JkZXIgPSBvcmRlcnNCeVRhYmxlSWQuZ2V0KHRhYmxlLmlkKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGxlZnRCb3JkZXJDb2xvciA9IFwidmFyKC0tdy1vaylcIjtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc3RhdHVzQmcgPSBcImNvbG9yLW1peChpbiBzcmdiLCB2YXIoLS13LW9rKSAxNSUsIHRyYW5zcGFyZW50KVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBzdGF0dXNDb2xvciA9IFwidmFyKC0tdy1vaylcIjtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc3RhdHVzVGV4dCA9IFwiTElWUkVcIjtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc3ViVGV4dCA9IGAke3RhYmxlLmNhcGFjaXR5ID8/IDR9IGx1Z2FyZXNgO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGFibGUudGFibGVTdGF0dXNJZCA9PT0gVGFibGVTdGF0dXMuT2N1cGFkYSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0Qm9yZGVyQ29sb3IgPSBcInZhcigtLXctd2FybilcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzQmcgPSBcImNvbG9yLW1peChpbiBzcmdiLCB2YXIoLS13LXdhcm4pIDE1JSwgdHJhbnNwYXJlbnQpXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c0NvbG9yID0gXCJ2YXIoLS13LXdhcm4pXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c1RleHQgPSBcIk9DVVBBREFcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9yZGVyKSBzdWJUZXh0ID0gYCR7b3JkZXIuaXRlbXMubGVuZ3RofSBpdGVucyAtICR7Zm9ybWF0QlJMKG9yZGVyLnRvdGFsQW1vdW50KX1gO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodGFibGUudGFibGVTdGF0dXNJZCA9PT0gVGFibGVTdGF0dXMuRW1GZWNoYW1lbnRvKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlZnRCb3JkZXJDb2xvciA9IFwidmFyKC0tdy1pbmZvKVwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXNCZyA9IFwiY29sb3ItbWl4KGluIHNyZ2IsIHZhcigtLXctaW5mbykgMTUlLCB0cmFuc3BhcmVudClcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzQ29sb3IgPSBcInZhcigtLXctaW5mbylcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzVGV4dCA9IFwiRkVDSEFORE9cIjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dGFibGUuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblRhYmxlQ2xpY2sodGFibGUuaWQsIHRhYmxlLnRhYmxlU3RhdHVzSWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwic3RyZXRjaFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCJ2YXIoLS13LWJnLWNhcmQpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjEycHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHZhcigtLXctbGluZSlcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJMZWZ0OiBgNnB4IHNvbGlkICR7bGVmdEJvcmRlckNvbG9yfWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIxNHB4IDE2cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbjogXCJsZWZ0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluSGVpZ2h0OiBcIjg4cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCB3aWR0aDogXCIxMDAlXCIsIG1hcmdpbkJvdHRvbTogXCI2cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTWVzbWEgdGlwb2dyYWZpYSBleGF0YSBhcGxpY2FkYSBhcXVpICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1kaXNwbGF5KVwiLCBmb250U2l6ZTogXCIycmVtXCIsIGNvbG9yOiBcInZhcigtLXctaW5rKVwiLCBsaW5lSGVpZ2h0OiAxIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFibGUubnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjY1cmVtXCIsIGZvbnRXZWlnaHQ6IFwiNzAwXCIsIGJhY2tncm91bmRDb2xvcjogc3RhdHVzQmcsIGNvbG9yOiBzdGF0dXNDb2xvciwgcGFkZGluZzogXCI0cHggOHB4XCIsIGJvcmRlclJhZGl1czogXCIyMHB4XCIsIGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IFwiNHB4XCIsIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IHdpZHRoOiBcIjZweFwiLCBoZWlnaHQ6IFwiNnB4XCIsIGJvcmRlclJhZGl1czogXCI1MCVcIiwgYmFja2dyb3VuZENvbG9yOiBzdGF0dXNDb2xvciB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzVGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwidmFyKC0tdy1pbmstZGltKVwiLCBmb250V2VpZ2h0OiA1MDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N1YlRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy93YWl0ZXIvY29tcG9uZW50cy90YWJzL1RhYk1lc2FzLnRzeCJ9