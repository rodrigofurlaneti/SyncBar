import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Alert.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function Alert({ variant, title, message, action, onClose }) {
  const colors = {
    info: { bg: "#e3f2fd", border: "#1976d2", icon: "ℹ️", text: "#0d47a1" },
    success: { bg: "#e8f5e9", border: "#388e3c", icon: "✓", text: "#1b5e20" },
    warning: { bg: "#fff3e0", border: "#f57c00", icon: "⚠️", text: "#e65100" },
    error: { bg: "#ffebee", border: "#d32f2f", icon: "✕", text: "#b71c1c" }
  };
  const color = colors[variant];
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      style: {
        padding: 12,
        borderRadius: 6,
        background: color.bg,
        border: `1px solid ${color.border}`,
        display: "grid",
        gap: 8,
        gridAutoFlow: "column",
        alignItems: "start",
        justifyContent: "space-between"
      },
      role: variant === "error" ? "alert" : "status",
      children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.2rem", flexShrink: 0 }, children: color.icon }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx",
            lineNumber: 59,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, color: color.text }, children: [
            title && /* @__PURE__ */ jsxDEV("strong", { style: { fontSize: "0.95rem" }, children: title }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx",
              lineNumber: 61,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.9rem" }, children: message }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx",
              lineNumber: 62,
              columnNumber: 11
            }, this),
            action && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: action.onClick,
                style: {
                  background: "transparent",
                  border: "none",
                  color: color.border,
                  cursor: "pointer",
                  fontSize: "0.85rem",
                  fontWeight: 600,
                  marginTop: 4,
                  textDecoration: "underline"
                },
                children: action.label
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx",
                lineNumber: 64,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx",
            lineNumber: 60,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx",
          lineNumber: 58,
          columnNumber: 7
        }, this),
        onClose && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onClose,
            style: {
              background: "transparent",
              border: "none",
              color: color.text,
              cursor: "pointer",
              fontSize: "1rem",
              padding: 0,
              lineHeight: 1
            },
            "aria-label": "Fechar alerta",
            children: "✕"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx",
            lineNumber: 85,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx",
      lineNumber: 44,
      columnNumber: 5
    },
    this
  );
}
_c = Alert;
var _c;
$RefreshReg$(_c, "Alert");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Alert.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNROzs7Ozs7Ozs7Ozs7Ozs7O0FBMUJELGdCQUFTQSxNQUFNLEVBQUVDLFNBQVNDLE9BQU9DLFNBQVNDLFFBQVFDLFFBQW9CLEdBQUc7QUFDOUUsUUFBTUMsU0FBUztBQUFBLElBQ2JDLE1BQU0sRUFBRUMsSUFBSSxXQUFXQyxRQUFRLFdBQVdDLE1BQU0sTUFBTUMsTUFBTSxVQUFVO0FBQUEsSUFDdEVDLFNBQVMsRUFBRUosSUFBSSxXQUFXQyxRQUFRLFdBQVdDLE1BQU0sS0FBS0MsTUFBTSxVQUFVO0FBQUEsSUFDeEVFLFNBQVMsRUFBRUwsSUFBSSxXQUFXQyxRQUFRLFdBQVdDLE1BQU0sTUFBTUMsTUFBTSxVQUFVO0FBQUEsSUFDekVHLE9BQU8sRUFBRU4sSUFBSSxXQUFXQyxRQUFRLFdBQVdDLE1BQU0sS0FBS0MsTUFBTSxVQUFVO0FBQUEsRUFDeEU7QUFFQSxRQUFNSSxRQUFRVCxPQUFPTCxPQUFPO0FBRTVCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE9BQU87QUFBQSxRQUNMZSxTQUFTO0FBQUEsUUFDVEMsY0FBYztBQUFBLFFBQ2RDLFlBQVlILE1BQU1QO0FBQUFBLFFBQ2xCQyxRQUFRLGFBQWFNLE1BQU1OLE1BQU07QUFBQSxRQUNqQ1UsU0FBUztBQUFBLFFBQ1RDLEtBQUs7QUFBQSxRQUNMQyxjQUFjO0FBQUEsUUFDZEMsWUFBWTtBQUFBLFFBQ1pDLGdCQUFnQjtBQUFBLE1BQ2xCO0FBQUEsTUFDQSxNQUFNdEIsWUFBWSxVQUFVLFVBQVU7QUFBQSxNQUV0QztBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFa0IsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUksVUFBVSxVQUFVQyxZQUFZLEVBQUUsR0FBSVYsZ0JBQU1MLFFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsVUFDL0QsdUJBQUMsU0FBSSxPQUFPLEVBQUVTLFNBQVMsUUFBUUMsS0FBSyxHQUFHTCxPQUFPQSxNQUFNSixLQUFLLEdBQ3REVDtBQUFBQSxxQkFBUyx1QkFBQyxZQUFPLE9BQU8sRUFBRXNCLFVBQVUsVUFBVSxHQUFJdEIsbUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStDO0FBQUEsWUFDekQsdUJBQUMsU0FBSSxPQUFPLEVBQUVzQixVQUFVLFNBQVMsR0FBSXJCLHFCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzVDQyxVQUNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNBLE9BQU9zQjtBQUFBQSxnQkFDaEIsT0FBTztBQUFBLGtCQUNMUixZQUFZO0FBQUEsa0JBQ1pULFFBQVE7QUFBQSxrQkFDUk0sT0FBT0EsTUFBTU47QUFBQUEsa0JBQ2JrQixRQUFRO0FBQUEsa0JBQ1JILFVBQVU7QUFBQSxrQkFDVkksWUFBWTtBQUFBLGtCQUNaQyxXQUFXO0FBQUEsa0JBQ1hDLGdCQUFnQjtBQUFBLGdCQUNsQjtBQUFBLGdCQUVDMUIsaUJBQU8yQjtBQUFBQTtBQUFBQSxjQWRWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWVBO0FBQUEsZUFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQzFCLFdBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNBO0FBQUFBLFlBQ1QsT0FBTztBQUFBLGNBQ0xhLFlBQVk7QUFBQSxjQUNaVCxRQUFRO0FBQUEsY0FDUk0sT0FBT0EsTUFBTUo7QUFBQUEsY0FDYmdCLFFBQVE7QUFBQSxjQUNSSCxVQUFVO0FBQUEsY0FDVlIsU0FBUztBQUFBLGNBQ1RnQixZQUFZO0FBQUEsWUFDZDtBQUFBLFlBQ0EsY0FBVztBQUFBLFlBQWU7QUFBQTtBQUFBLFVBWjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWVBO0FBQUE7QUFBQTtBQUFBLElBeERKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTBEQTtBQUVKO0FBQUNDLEtBdkVlakM7QUFBSyxJQUFBaUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQWxlcnQiLCJ2YXJpYW50IiwidGl0bGUiLCJtZXNzYWdlIiwiYWN0aW9uIiwib25DbG9zZSIsImNvbG9ycyIsImluZm8iLCJiZyIsImJvcmRlciIsImljb24iLCJ0ZXh0Iiwic3VjY2VzcyIsIndhcm5pbmciLCJlcnJvciIsImNvbG9yIiwicGFkZGluZyIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmQiLCJkaXNwbGF5IiwiZ2FwIiwiZ3JpZEF1dG9GbG93IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZm9udFNpemUiLCJmbGV4U2hyaW5rIiwib25DbGljayIsImN1cnNvciIsImZvbnRXZWlnaHQiLCJtYXJnaW5Ub3AiLCJ0ZXh0RGVjb3JhdGlvbiIsImxhYmVsIiwibGluZUhlaWdodCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFsZXJ0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmludGVyZmFjZSBBbGVydFByb3BzIHtcclxuICB2YXJpYW50OiBcImluZm9cIiB8IFwic3VjY2Vzc1wiIHwgXCJ3YXJuaW5nXCIgfCBcImVycm9yXCI7XHJcbiAgdGl0bGU/OiBzdHJpbmc7XHJcbiAgbWVzc2FnZTogUmVhY3ROb2RlO1xyXG4gIGFjdGlvbj86IHtcclxuICAgIGxhYmVsOiBzdHJpbmc7XHJcbiAgICBvbkNsaWNrOiAoKSA9PiB2b2lkO1xyXG4gIH07XHJcbiAgb25DbG9zZT86ICgpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBbGVydCh7IHZhcmlhbnQsIHRpdGxlLCBtZXNzYWdlLCBhY3Rpb24sIG9uQ2xvc2UgfTogQWxlcnRQcm9wcykge1xyXG4gIGNvbnN0IGNvbG9ycyA9IHtcclxuICAgIGluZm86IHsgYmc6IFwiI2UzZjJmZFwiLCBib3JkZXI6IFwiIzE5NzZkMlwiLCBpY29uOiBcIuKEue+4j1wiLCB0ZXh0OiBcIiMwZDQ3YTFcIiB9LFxyXG4gICAgc3VjY2VzczogeyBiZzogXCIjZThmNWU5XCIsIGJvcmRlcjogXCIjMzg4ZTNjXCIsIGljb246IFwi4pyTXCIsIHRleHQ6IFwiIzFiNWUyMFwiIH0sXHJcbiAgICB3YXJuaW5nOiB7IGJnOiBcIiNmZmYzZTBcIiwgYm9yZGVyOiBcIiNmNTdjMDBcIiwgaWNvbjogXCLimqDvuI9cIiwgdGV4dDogXCIjZTY1MTAwXCIgfSxcclxuICAgIGVycm9yOiB7IGJnOiBcIiNmZmViZWVcIiwgYm9yZGVyOiBcIiNkMzJmMmZcIiwgaWNvbjogXCLinJVcIiwgdGV4dDogXCIjYjcxYzFjXCIgfSxcclxuICB9O1xyXG5cclxuICBjb25zdCBjb2xvciA9IGNvbG9yc1t2YXJpYW50XTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgc3R5bGU9e3tcclxuICAgICAgICBwYWRkaW5nOiAxMixcclxuICAgICAgICBib3JkZXJSYWRpdXM6IDYsXHJcbiAgICAgICAgYmFja2dyb3VuZDogY29sb3IuYmcsXHJcbiAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7Y29sb3IuYm9yZGVyfWAsXHJcbiAgICAgICAgZGlzcGxheTogXCJncmlkXCIsXHJcbiAgICAgICAgZ2FwOiA4LFxyXG4gICAgICAgIGdyaWRBdXRvRmxvdzogXCJjb2x1bW5cIixcclxuICAgICAgICBhbGlnbkl0ZW1zOiBcInN0YXJ0XCIsXHJcbiAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxyXG4gICAgICB9fVxyXG4gICAgICByb2xlPXt2YXJpYW50ID09PSBcImVycm9yXCIgPyBcImFsZXJ0XCIgOiBcInN0YXR1c1wifVxyXG4gICAgPlxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiwgZmxleFNocmluazogMCB9fT57Y29sb3IuaWNvbn08L2Rpdj5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIGNvbG9yOiBjb2xvci50ZXh0IH19PlxyXG4gICAgICAgICAge3RpdGxlICYmIDxzdHJvbmcgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45NXJlbVwiIH19Pnt0aXRsZX08L3N0cm9uZz59XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PnttZXNzYWdlfTwvZGl2PlxyXG4gICAgICAgICAge2FjdGlvbiAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXthY3Rpb24ub25DbGlja31cclxuICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ0cmFuc3BhcmVudFwiLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiBcIm5vbmVcIixcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvci5ib3JkZXIsXHJcbiAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC44NXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogNjAwLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luVG9wOiA0LFxyXG4gICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb246IFwidW5kZXJsaW5lXCIsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHthY3Rpb24ubGFiZWx9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7b25DbG9zZSAmJiAoXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ0cmFuc3BhcmVudFwiLFxyXG4gICAgICAgICAgICBib3JkZXI6IFwibm9uZVwiLFxyXG4gICAgICAgICAgICBjb2xvcjogY29sb3IudGV4dCxcclxuICAgICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcclxuICAgICAgICAgICAgZm9udFNpemU6IFwiMXJlbVwiLFxyXG4gICAgICAgICAgICBwYWRkaW5nOiAwLFxyXG4gICAgICAgICAgICBsaW5lSGVpZ2h0OiAxLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJGZWNoYXIgYWxlcnRhXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICDinJVcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQWxlcnQudHN4In0=