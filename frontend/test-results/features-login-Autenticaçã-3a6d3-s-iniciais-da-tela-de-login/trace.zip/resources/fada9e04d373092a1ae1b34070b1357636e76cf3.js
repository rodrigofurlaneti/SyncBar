import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/QueryError.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/QueryError.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ApiError } from "/src/lib/apiClient.ts";
export function QueryError({ error, what }) {
  const message = error instanceof ApiError ? error.message : `Falha ao carregar ${what}.`;
  return /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: [
    "Falha ao carregar ",
    what,
    ": ",
    message
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/QueryError.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_c = QueryError;
var _c;
$RefreshReg$(_c, "QueryError");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/QueryError.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/QueryError.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFaSixTQUFTQSxnQkFBZ0I7QUFRbEIsZ0JBQVNDLFdBQVcsRUFBRUMsT0FBT0MsS0FBWSxHQUFHO0FBQ2pELFFBQU1DLFVBQ0pGLGlCQUFpQkYsV0FBV0UsTUFBTUUsVUFBVSxxQkFBcUJELElBQUk7QUFDdkUsU0FDRSx1QkFBQyxPQUFFLFdBQVUsY0FBWTtBQUFBO0FBQUEsSUFDSkE7QUFBQUEsSUFBSztBQUFBLElBQUdDO0FBQUFBLE9BRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNDLEtBUmVKO0FBQVUsSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQXBpRXJyb3IiLCJRdWVyeUVycm9yIiwiZXJyb3IiLCJ3aGF0IiwibWVzc2FnZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlF1ZXJ5RXJyb3IudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uL2xpYi9hcGlDbGllbnRcIjtcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgZXJyb3I6IHVua25vd247XG4gIHdoYXQ6IHN0cmluZztcbn1cblxuLy8gRXhpYmUgZmFsaGFzIGRlIGNhcnJlZ2FtZW50byBkZSBmb3JtYSBjb25zaXN0ZW50ZSBlbSB0b2RhcyBhcyBwYWdpbmFzLlxuZXhwb3J0IGZ1bmN0aW9uIFF1ZXJ5RXJyb3IoeyBlcnJvciwgd2hhdCB9OiBQcm9wcykge1xuICBjb25zdCBtZXNzYWdlID1cbiAgICBlcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyb3IubWVzc2FnZSA6IGBGYWxoYSBhbyBjYXJyZWdhciAke3doYXR9LmA7XG4gIHJldHVybiAoXG4gICAgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPlxuICAgICAgRmFsaGEgYW8gY2FycmVnYXIge3doYXR9OiB7bWVzc2FnZX1cbiAgICA8L3A+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9RdWVyeUVycm9yLnRzeCJ9