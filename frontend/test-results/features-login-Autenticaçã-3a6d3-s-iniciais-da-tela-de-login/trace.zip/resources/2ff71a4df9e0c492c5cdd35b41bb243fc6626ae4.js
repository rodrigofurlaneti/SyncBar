import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/tabs/TabComandas.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { formatBRL } from "/src/lib/types.ts";
export function TabComandas({ isLoading, comandas, comandaOrders, onComandaClick }) {
  return /* @__PURE__ */ jsxDEV("section", { className: "waiter-section", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "waiter-section-title", style: { marginBottom: 16 }, children: "Comandas" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
      lineNumber: 33,
      columnNumber: 13
    }, this),
    isLoading ? /* @__PURE__ */ jsxDEV("p", { className: "waiter-empty", children: "Carregando comandas..." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this) : !comandas || comandas.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "waiter-empty", children: "Nenhuma comanda registrada." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
      lineNumber: 38,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "waiter-tables-grid", style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: "14px" }, children: comandas.map((comanda) => {
      const order = comandaOrders.find((o) => o.comandaId === comanda.id);
      let leftBorderColor = "var(--w-ok)";
      let statusBg = "color-mix(in srgb, var(--w-ok) 15%, transparent)";
      let statusColor = "var(--w-ok)";
      let statusText = "LIVRE";
      let subText = "Toque para abrir";
      if (order) {
        leftBorderColor = "var(--w-warn)";
        statusBg = "color-mix(in srgb, var(--w-warn) 15%, transparent)";
        statusColor = "var(--w-warn)";
        statusText = "EM USO";
        subText = `${order.items.length} itens - ${formatBRL(order.totalAmount)}`;
      }
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onComandaClick(comanda, order?.id),
          style: {
            display: "flex",
            flexDirection: "column",
            alignItems: "stretch",
            backgroundColor: "var(--w-bg-card)",
            borderRadius: "12px",
            border: "1px solid var(--w-line)",
            borderLeft: `6px solid ${leftBorderColor}`,
            padding: "14px 16px",
            cursor: "pointer",
            textAlign: "left",
            minHeight: "88px",
            justifyContent: "center"
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%", marginBottom: "6px" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontFamily: "var(--font-display)", fontSize: "2rem", color: "var(--w-ink)", lineHeight: 1 }, children: comanda.code || comanda.id }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
                lineNumber: 79,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.65rem", fontWeight: "700", backgroundColor: statusBg, color: statusColor, padding: "4px 8px", borderRadius: "20px", display: "flex", alignItems: "center", gap: "4px", textTransform: "uppercase" }, children: [
                /* @__PURE__ */ jsxDEV("span", { style: { width: "6px", height: "6px", borderRadius: "50%", backgroundColor: statusColor } }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
                  lineNumber: 83,
                  columnNumber: 41
                }, this),
                statusText
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
                lineNumber: 82,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
              lineNumber: 77,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--w-ink-dim)", fontWeight: 500 }, children: subText }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
              lineNumber: 87,
              columnNumber: 33
            }, this)
          ]
        },
        comanda.id,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
          lineNumber: 59,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
      lineNumber: 40,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_c = TabComandas;
var _c;
$RefreshReg$(_c, "TabComandas");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabComandas.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFiWCxTQUFTQSxpQkFBaUI7QUFVcEIsZ0JBQVNDLFlBQVksRUFBRUMsV0FBV0MsVUFBVUMsZUFBZUMsZUFBaUMsR0FBRztBQUNsRyxTQUNJLHVCQUFDLGFBQVEsV0FBVSxrQkFDZjtBQUFBLDJCQUFDLFFBQUcsV0FBVSx3QkFBdUIsT0FBTyxFQUFFQyxjQUFjLEdBQUcsR0FBRyx3QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRTtBQUFBLElBRXpFSixZQUNHLHVCQUFDLE9BQUUsV0FBVSxnQkFBZSxzQ0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRCxJQUNsRCxDQUFDQyxZQUFZQSxTQUFTSSxXQUFXLElBQ2pDLHVCQUFDLE9BQUUsV0FBVSxnQkFBZSwyQ0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RCxJQUV2RCx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxxQkFBcUIseUNBQXlDQyxLQUFLLE9BQU8sR0FDbklQLG1CQUFTUSxJQUFJLENBQUNDLFlBQVk7QUFDdkIsWUFBTUMsUUFBUVQsY0FBY1UsS0FBSyxDQUFDQyxNQUFNQSxFQUFFQyxjQUFjSixRQUFRSyxFQUFFO0FBRWxFLFVBQUlDLGtCQUFrQjtBQUN0QixVQUFJQyxXQUFXO0FBQ2YsVUFBSUMsY0FBYztBQUNsQixVQUFJQyxhQUFhO0FBQ2pCLFVBQUlDLFVBQVU7QUFFZCxVQUFJVCxPQUFPO0FBQ1BLLDBCQUFrQjtBQUNsQkMsbUJBQVc7QUFDWEMsc0JBQWM7QUFDZEMscUJBQWE7QUFDYkMsa0JBQVUsR0FBR1QsTUFBTVUsTUFBTWhCLE1BQU0sWUFBWVAsVUFBVWEsTUFBTVcsV0FBVyxDQUFDO0FBQUEsTUFDM0U7QUFFQSxhQUNJO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFRyxTQUFTLE1BQU1uQixlQUFlTyxTQUFTQyxPQUFPSSxFQUFFO0FBQUEsVUFDaEQsT0FBTztBQUFBLFlBQ0hULFNBQVM7QUFBQSxZQUNUaUIsZUFBZTtBQUFBLFlBQ2ZDLFlBQVk7QUFBQSxZQUNaQyxpQkFBaUI7QUFBQSxZQUNqQkMsY0FBYztBQUFBLFlBQ2RDLFFBQVE7QUFBQSxZQUNSQyxZQUFZLGFBQWFaLGVBQWU7QUFBQSxZQUN4Q2EsU0FBUztBQUFBLFlBQ1RDLFFBQVE7QUFBQSxZQUNSQyxXQUFXO0FBQUEsWUFDWEMsV0FBVztBQUFBLFlBQ1hDLGdCQUFnQjtBQUFBLFVBQ3BCO0FBQUEsVUFFQTtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFM0IsU0FBUyxRQUFRa0IsWUFBWSxVQUFVUyxnQkFBZ0IsaUJBQWlCQyxPQUFPLFFBQVE5QixjQUFjLE1BQU0sR0FFckg7QUFBQSxxQ0FBQyxVQUFLLE9BQU8sRUFBRStCLFlBQVksdUJBQXVCQyxVQUFVLFFBQVFDLE9BQU8sZ0JBQWdCQyxZQUFZLEVBQUUsR0FDcEc1QixrQkFBUTZCLFFBQVE3QixRQUFRSyxNQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRXFCLFVBQVUsV0FBV0ksWUFBWSxPQUFPZixpQkFBaUJSLFVBQVVvQixPQUFPbkIsYUFBYVcsU0FBUyxXQUFXSCxjQUFjLFFBQVFwQixTQUFTLFFBQVFrQixZQUFZLFVBQVVoQixLQUFLLE9BQU9pQyxlQUFlLFlBQVksR0FDMU47QUFBQSx1Q0FBQyxVQUFLLE9BQU8sRUFBRVAsT0FBTyxPQUFPUSxRQUFRLE9BQU9oQixjQUFjLE9BQU9ELGlCQUFpQlAsWUFBWSxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRztBQUFBLGdCQUMvRkM7QUFBQUEsbUJBRkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFaUIsVUFBVSxXQUFXQyxPQUFPLG9CQUFvQkcsWUFBWSxJQUFJLEdBQzFFcEIscUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBO0FBQUE7QUFBQSxRQTdCS1YsUUFBUUs7QUFBQUEsUUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQStCQTtBQUFBLElBRVIsQ0FBQyxLQXBETDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcURBO0FBQUEsT0E3RFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStEQTtBQUVSO0FBQUM0QixLQW5FZTVDO0FBQVcsSUFBQTRDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImZvcm1hdEJSTCIsIlRhYkNvbWFuZGFzIiwiaXNMb2FkaW5nIiwiY29tYW5kYXMiLCJjb21hbmRhT3JkZXJzIiwib25Db21hbmRhQ2xpY2siLCJtYXJnaW5Cb3R0b20iLCJsZW5ndGgiLCJkaXNwbGF5IiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImdhcCIsIm1hcCIsImNvbWFuZGEiLCJvcmRlciIsImZpbmQiLCJvIiwiY29tYW5kYUlkIiwiaWQiLCJsZWZ0Qm9yZGVyQ29sb3IiLCJzdGF0dXNCZyIsInN0YXR1c0NvbG9yIiwic3RhdHVzVGV4dCIsInN1YlRleHQiLCJpdGVtcyIsInRvdGFsQW1vdW50IiwiZmxleERpcmVjdGlvbiIsImFsaWduSXRlbXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJib3JkZXJSYWRpdXMiLCJib3JkZXIiLCJib3JkZXJMZWZ0IiwicGFkZGluZyIsImN1cnNvciIsInRleHRBbGlnbiIsIm1pbkhlaWdodCIsImp1c3RpZnlDb250ZW50Iiwid2lkdGgiLCJmb250RmFtaWx5IiwiZm9udFNpemUiLCJjb2xvciIsImxpbmVIZWlnaHQiLCJjb2RlIiwiZm9udFdlaWdodCIsInRleHRUcmFuc2Zvcm0iLCJoZWlnaHQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYWJDb21hbmRhcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgZm9ybWF0QlJMIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IENvbWFuZGFSZXNwb25zZSwgT3JkZXJSZXNwb25zZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9saWIvdHlwZXNcIjtcclxuXHJcbmludGVyZmFjZSBUYWJDb21hbmRhc1Byb3BzIHtcclxuICAgIGlzTG9hZGluZzogYm9vbGVhbjtcclxuICAgIGNvbWFuZGFzOiBDb21hbmRhUmVzcG9uc2VbXSB8IHVuZGVmaW5lZDtcclxuICAgIGNvbWFuZGFPcmRlcnM6IE9yZGVyUmVzcG9uc2VbXTtcclxuICAgIG9uQ29tYW5kYUNsaWNrOiAoY29tYW5kYTogQ29tYW5kYVJlc3BvbnNlLCBvcmRlcklkPzogbnVtYmVyKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVGFiQ29tYW5kYXMoeyBpc0xvYWRpbmcsIGNvbWFuZGFzLCBjb21hbmRhT3JkZXJzLCBvbkNvbWFuZGFDbGljayB9OiBUYWJDb21hbmRhc1Byb3BzKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIndhaXRlci1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ3YWl0ZXItc2VjdGlvbi10aXRsZVwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMTYgfX0+Q29tYW5kYXM8L2gyPlxyXG5cclxuICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIndhaXRlci1lbXB0eVwiPkNhcnJlZ2FuZG8gY29tYW5kYXMuLi48L3A+XHJcbiAgICAgICAgICAgICkgOiAhY29tYW5kYXMgfHwgY29tYW5kYXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwid2FpdGVyLWVtcHR5XCI+TmVuaHVtYSBjb21hbmRhIHJlZ2lzdHJhZGEuPC9wPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3YWl0ZXItdGFibGVzLWdyaWRcIiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCJyZXBlYXQoYXV0by1maWxsLCBtaW5tYXgoMTUwcHgsIDFmcikpXCIsIGdhcDogXCIxNHB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAge2NvbWFuZGFzLm1hcCgoY29tYW5kYSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBvcmRlciA9IGNvbWFuZGFPcmRlcnMuZmluZCgobykgPT4gby5jb21hbmRhSWQgPT09IGNvbWFuZGEuaWQpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGxlZnRCb3JkZXJDb2xvciA9IFwidmFyKC0tdy1vaylcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXR1c0JnID0gXCJjb2xvci1taXgoaW4gc3JnYiwgdmFyKC0tdy1vaykgMTUlLCB0cmFuc3BhcmVudClcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXR1c0NvbG9yID0gXCJ2YXIoLS13LW9rKVwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhdHVzVGV4dCA9IFwiTElWUkVcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN1YlRleHQgPSBcIlRvcXVlIHBhcmEgYWJyaXJcIjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChvcmRlcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVmdEJvcmRlckNvbG9yID0gXCJ2YXIoLS13LXdhcm4pXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXNCZyA9IFwiY29sb3ItbWl4KGluIHNyZ2IsIHZhcigtLXctd2FybikgMTUlLCB0cmFuc3BhcmVudClcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c0NvbG9yID0gXCJ2YXIoLS13LXdhcm4pXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXNUZXh0ID0gXCJFTSBVU09cIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YlRleHQgPSBgJHtvcmRlci5pdGVtcy5sZW5ndGh9IGl0ZW5zIC0gJHtmb3JtYXRCUkwob3JkZXIudG90YWxBbW91bnQpfWA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjb21hbmRhLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ29tYW5kYUNsaWNrKGNvbWFuZGEsIG9yZGVyPy5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwic3RyZXRjaFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwidmFyKC0tdy1iZy1jYXJkKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiMTJweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHZhcigtLXctbGluZSlcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyTGVmdDogYDZweCBzb2xpZCAke2xlZnRCb3JkZXJDb2xvcn1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjE0cHggMTZweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ246IFwibGVmdFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHQ6IFwiODhweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCB3aWR0aDogXCIxMDAlXCIsIG1hcmdpbkJvdHRvbTogXCI2cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFxdWkgZXN0w6EgYSBtw6FnaWNhOiBhcGxpY2FuZG8gZm9udC1kaXNwbGF5IHBhcmEgZmljYXIgaWd1YWwgw6AgbWVzYSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udEZhbWlseTogXCJ2YXIoLS1mb250LWRpc3BsYXkpXCIsIGZvbnRTaXplOiBcIjJyZW1cIiwgY29sb3I6IFwidmFyKC0tdy1pbmspXCIsIGxpbmVIZWlnaHQ6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29tYW5kYS5jb2RlIHx8IGNvbWFuZGEuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC42NXJlbVwiLCBmb250V2VpZ2h0OiBcIjcwMFwiLCBiYWNrZ3JvdW5kQ29sb3I6IHN0YXR1c0JnLCBjb2xvcjogc3RhdHVzQ29sb3IsIHBhZGRpbmc6IFwiNHB4IDhweFwiLCBib3JkZXJSYWRpdXM6IFwiMjBweFwiLCBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiBcIjRweFwiLCB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgd2lkdGg6IFwiNnB4XCIsIGhlaWdodDogXCI2cHhcIiwgYm9yZGVyUmFkaXVzOiBcIjUwJVwiLCBiYWNrZ3JvdW5kQ29sb3I6IHN0YXR1c0NvbG9yIH19IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzVGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwidmFyKC0tdy1pbmstZGltKVwiLCBmb250V2VpZ2h0OiA1MDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdWJUZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy93YWl0ZXIvY29tcG9uZW50cy90YWJzL1RhYkNvbWFuZGFzLnRzeCJ9