import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodCatalogPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  IFOOD_CATALOG_V1_OPERATIONS,
  batchUpdateIFoodProductPrices,
  batchUpdateIFoodProductStatuses,
  checkIFoodCatalogVersion,
  createIFoodCategory,
  createIFoodProduct,
  deleteIFoodCategory,
  deleteIFoodInventoryBatch,
  deleteIFoodItem,
  deleteIFoodOption,
  deleteIFoodOptionGroup,
  deleteIFoodProduct,
  disassociateIFoodOptionGroup,
  downgradeIFoodCatalogVersion,
  editIFoodCategory,
  editIFoodProduct,
  getIFoodBatchResult,
  getIFoodCatalogs,
  getIFoodInventory,
  getIFoodItemFlat,
  getIFoodProductById,
  invokeIFoodCatalogV1Operation,
  listIFoodCategories,
  listIFoodCategoryItems,
  listIFoodOptionGroups,
  listIFoodProducts,
  listIFoodProductsByExternalCode,
  listIFoodSellableItems,
  setIFoodItemExternalCode,
  setIFoodItemPrice,
  setIFoodOptionExternalCode,
  setIFoodOptionPrice,
  setIFoodOptionStatus,
  updateIFoodOptionGroup,
  updateIFoodOptionGroupStatus,
  uploadIFoodImage,
  upgradeIFoodCatalogVersion
} from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useToast } from "/src/ui/Toast.tsx";
import { Button } from "/src/ui/Button.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { SelectField, TextField } from "/src/ui/Field.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
const TABS = [
  { key: "categorias", label: "Categorias" },
  { key: "produtos", label: "Produtos" },
  { key: "itens", label: "Itens" },
  { key: "complementos", label: "Complementos" },
  { key: "admin", label: "Administração" },
  { key: "v1", label: "Console v1 (legado)" }
];
function prettyJson(raw) {
  if (!raw) return "";
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch {
    return raw;
  }
}
export function IFoodCatalogPage() {
  _s();
  const [activeTab, setActiveTab] = useState("categorias");
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood", style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "← Integração iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Cardápio iFood (Catalog)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 113,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "gerencie categorias, produtos, itens e complementos diretamente no iFood — a sincronização automática (fase 3) continua cobrindo o fluxo essencial; use estas telas pra ajustes finos e operações que ela não cobre." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 116,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 0, borderBottom: "1px solid var(--border)", marginBottom: 20, flexWrap: "wrap" }, children: TABS.map(
      (tab) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setActiveTab(tab.key),
          style: {
            padding: "12px 18px",
            border: "none",
            background: "none",
            cursor: "pointer",
            fontSize: "0.9rem",
            fontWeight: activeTab === tab.key ? 600 : 400,
            color: activeTab === tab.key ? "var(--ink)" : "var(--ink-faint)",
            borderBottom: activeTab === tab.key ? "2px solid var(--ink)" : "2px solid transparent",
            marginBottom: -1
          },
          children: tab.label
        },
        tab.key,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 125,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 123,
      columnNumber: 7
    }, this),
    activeTab === "categorias" && /* @__PURE__ */ jsxDEV(CategoriesTab, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 146,
      columnNumber: 38
    }, this),
    activeTab === "produtos" && /* @__PURE__ */ jsxDEV(ProductsTab, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 147,
      columnNumber: 36
    }, this),
    activeTab === "itens" && /* @__PURE__ */ jsxDEV(ItemsTab, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 148,
      columnNumber: 33
    }, this),
    activeTab === "complementos" && /* @__PURE__ */ jsxDEV(OptionGroupsTab, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 149,
      columnNumber: 40
    }, this),
    activeTab === "admin" && /* @__PURE__ */ jsxDEV(AdminTab, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 150,
      columnNumber: 33
    }, this),
    activeTab === "v1" && /* @__PURE__ */ jsxDEV(V1ConsoleTab, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 151,
      columnNumber: 30
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 108,
    columnNumber: 5
  }, this);
}
_s(IFoodCatalogPage, "y3nyvoyCopjMdMIU6AOlfari41A=");
_c = IFoodCatalogPage;
function CategoriesTab() {
  _s2();
  const { branchId } = useAuthStore();
  const toast = useToast();
  const queryClient = useQueryClient();
  const [catalogId, setCatalogId] = useState("");
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState(null);
  const [groupId, setGroupId] = useState("");
  const [submittedGroupId, setSubmittedGroupId] = useState("");
  const catalogsQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "catalogs", branchId],
    queryFn: () => getIFoodCatalogs(branchId)
  });
  const catalogs = catalogsQuery.data ?? [];
  const effectiveCatalogId = catalogId || catalogs[0]?.catalogId || "";
  const categoriesQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "categories", branchId, effectiveCatalogId],
    queryFn: () => listIFoodCategories(branchId, effectiveCatalogId),
    enabled: !!effectiveCatalogId
  });
  const sellableItemsQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "sellable-items", branchId, submittedGroupId],
    queryFn: () => listIFoodSellableItems(branchId, submittedGroupId),
    enabled: !!submittedGroupId
  });
  const invalidate = () => void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "catalog", "categories"] });
  const deleteMutation = useMutation({
    mutationFn: (categoryId) => deleteIFoodCategory(branchId, categoryId),
    onSuccess: () => {
      toast.success("Categoria excluída no iFood.");
      invalidate();
    },
    onError: () => toast.error("Não foi possível excluir a categoria.")
  });
  const categories = categoriesQuery.data ?? [];
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 18 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 12, alignItems: "flex-end", justifyContent: "space-between" }, children: [
      /* @__PURE__ */ jsxDEV(
        SelectField,
        {
          label: "Catálogo",
          value: effectiveCatalogId,
          onChange: (e) => setCatalogId(e.target.value),
          disabled: catalogsQuery.isLoading,
          hint: "grupo/canal (ex.: iFood, WhatsApp) — o iFood v2 pode ter mais de um",
          children: catalogs.map(
            (c) => /* @__PURE__ */ jsxDEV("option", { value: c.catalogId ?? "", children: [
              c.catalogId,
              " ",
              c.status ? `(${c.status})` : ""
            ] }, c.catalogId ?? "", true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
              lineNumber: 216,
              columnNumber: 13
            }, this)
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 208,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", disabled: !effectiveCatalogId, onClick: () => setCreating(true), children: "+ Nova categoria" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 221,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 207,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 206,
      columnNumber: 7
    }, this),
    catalogsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: catalogsQuery.error, what: "os catálogos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 227,
      columnNumber: 33
    }, this),
    categoriesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: categoriesQuery.error, what: "as categorias" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 228,
      columnNumber: 35
    }, this),
    !categoriesQuery.isLoading && categories.length === 0 && !categoriesQuery.isError && effectiveCatalogId && /* @__PURE__ */ jsxDEV(EmptyState, { title: "Nenhuma categoria", description: "Este catálogo ainda não tem categorias no iFood." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 231,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10 }, children: categories.map(
      (category) => /* @__PURE__ */ jsxDEV("section", { className: "ticket rise", style: { padding: 14 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", alignItems: "center", gap: 10 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 700 }, children: category.name }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 239,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.8rem" }, children: [
            category.id,
            " · status: ",
            category.status ?? "—",
            " · índice: ",
            category.index ?? "—",
            category.externalCode ? ` · código externo: ${category.externalCode}` : ""
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 240,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 238,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => setEditing(category), children: "Editar" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 246,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "danger",
              size: "sm",
              loading: deleteMutation.isPending,
              onClick: () => category.id && deleteMutation.mutate(category.id),
              children: "Excluir"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
              lineNumber: 249,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 245,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 237,
        columnNumber: 13
      }, this) }, category.id, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 236,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 234,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Itens vendáveis por grupo" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 264,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--ink-faint)" }, children: "consulta os itens vendáveis associados a um groupId (obtido na resposta de categorias/itens)." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 265,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Group Id", value: groupId, onChange: (e) => setGroupId(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 269,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setSubmittedGroupId(groupId), children: "Consultar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 270,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 268,
        columnNumber: 9
      }, this),
      sellableItemsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: sellableItemsQuery.error, what: "os itens vendáveis" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 274,
        columnNumber: 40
      }, this),
      (sellableItemsQuery.data ?? []).map(
        (item) => /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", borderTop: "1px solid var(--border)", paddingTop: 6 }, children: [
          item.itemName,
          " — ",
          item.itemPriceValue?.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) ?? "—",
          item.itemExternalCode ? ` · código: ${item.itemExternalCode}` : ""
        ] }, item.itemId, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 276,
          columnNumber: 9
        }, this)
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 263,
      columnNumber: 7
    }, this),
    creating && /* @__PURE__ */ jsxDEV(
      CategoryFormModal,
      {
        branchId,
        catalogId: effectiveCatalogId,
        onClose: () => setCreating(false),
        onSaved: () => {
          setCreating(false);
          invalidate();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 284,
        columnNumber: 7
      },
      this
    ),
    editing && /* @__PURE__ */ jsxDEV(
      CategoryFormModal,
      {
        branchId,
        catalogId: effectiveCatalogId,
        category: editing,
        onClose: () => setEditing(null),
        onSaved: () => {
          setEditing(null);
          invalidate();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 296,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 205,
    columnNumber: 5
  }, this);
}
_s2(CategoriesTab, "oyOLuVPJpBBuNAjVYW7zqEmTtp0=", false, function() {
  return [useAuthStore, useToast, useQueryClient, useQuery, useQuery, useQuery, useMutation];
});
_c2 = CategoriesTab;
function CategoryFormModal({
  branchId,
  catalogId,
  category,
  onClose,
  onSaved
}) {
  _s3();
  const toast = useToast();
  const [name, setName] = useState(category?.name ?? "");
  const [externalCode, setExternalCode] = useState(category?.externalCode ?? "");
  const [status, setStatus] = useState(category?.status ?? "AVAILABLE");
  const [index, setIndex] = useState(category?.index != null ? String(category.index) : "");
  const saveMutation = useMutation({
    mutationFn: async () => {
      if (category?.id) {
        await editIFoodCategory(branchId, catalogId, category.id, {
          name: name.trim() || void 0,
          externalCode: externalCode.trim() || void 0,
          status: status || void 0,
          index: index.trim() ? Number(index) : void 0
        });
      } else {
        await createIFoodCategory(branchId, catalogId, name.trim());
      }
    },
    onSuccess: () => {
      toast.success(category ? "Categoria atualizada no iFood." : "Categoria criada no iFood.");
      onSaved();
    },
    onError: () => toast.error("Não foi possível salvar a categoria.")
  });
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: category ? "Editar categoria" : "Nova categoria", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 340 }, children: [
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome", value: name, onChange: (e) => setName(e.target.value), autoFocus: true }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 353,
      columnNumber: 9
    }, this),
    category && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(TextField, { label: "Código externo (opcional)", value: externalCode, onChange: (e) => setExternalCode(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 356,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(SelectField, { label: "Status", value: status, onChange: (e) => setStatus(e.target.value), children: [
        /* @__PURE__ */ jsxDEV("option", { value: "AVAILABLE", children: "Disponível" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 358,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "UNAVAILABLE", children: "Indisponível" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 359,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 357,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Índice (opcional)", inputMode: "numeric", value: index, onChange: (e) => setIndex(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 361,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 355,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 365,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", disabled: !name.trim(), loading: saveMutation.isPending, onClick: () => saveMutation.mutate(), children: "Salvar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 368,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 364,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 352,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 351,
    columnNumber: 5
  }, this);
}
_s3(CategoryFormModal, "eqOPjCuPVzoa4pZ7ioBZC4PQm/4=", false, function() {
  return [useToast, useMutation];
});
_c3 = CategoryFormModal;
function ProductsTab() {
  _s4();
  const { branchId } = useAuthStore();
  const toast = useToast();
  const queryClient = useQueryClient();
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState(null);
  const [externalCodeLookup, setExternalCodeLookup] = useState("");
  const [submittedExternalCode, setSubmittedExternalCode] = useState("");
  const [idLookup, setIdLookup] = useState("");
  const [lookedUpProduct, setLookedUpProduct] = useState(null);
  const [batchStatusIds, setBatchStatusIds] = useState("");
  const [batchStatusValue, setBatchStatusValue] = useState("AVAILABLE");
  const [batchPriceIds, setBatchPriceIds] = useState("");
  const [batchPriceValue, setBatchPriceValue] = useState("");
  const productsQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "products", branchId],
    queryFn: () => listIFoodProducts(branchId)
  });
  const byExternalCodeQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "products-by-external-code", branchId, submittedExternalCode],
    queryFn: () => listIFoodProductsByExternalCode(branchId, submittedExternalCode),
    enabled: !!submittedExternalCode
  });
  const invalidate = () => void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "catalog", "products"] });
  const deleteMutation = useMutation({
    mutationFn: (productId) => deleteIFoodProduct(branchId, productId),
    onSuccess: () => {
      toast.success("Produto excluído no iFood.");
      invalidate();
    },
    onError: () => toast.error("Não foi possível excluir o produto.")
  });
  const lookupByIdMutation = useMutation({
    mutationFn: () => getIFoodProductById(branchId, idLookup.trim()),
    onSuccess: (result) => setLookedUpProduct(result),
    onError: () => toast.error("Produto não encontrado.")
  });
  const batchStatusMutation = useMutation({
    mutationFn: () => batchUpdateIFoodProductStatuses(
      branchId,
      batchStatusIds.split(",").map((id) => id.trim()).filter(Boolean).map((productId) => ({ productId, status: batchStatusValue }))
    ),
    onSuccess: () => toast.success("Status em lote enviado ao iFood."),
    onError: () => toast.error("Falha ao atualizar status em lote.")
  });
  const batchPriceMutation = useMutation({
    mutationFn: () => batchUpdateIFoodProductPrices(
      branchId,
      batchPriceIds.split(",").map((id) => id.trim()).filter(Boolean).map((productId) => ({ productId, value: Number(batchPriceValue) || 0 }))
    ),
    onSuccess: (result) => toast.success(`Lote de preços enviado. BatchId: ${result.batchId ?? "(ver payload)"}`),
    onError: () => toast.error("Falha ao atualizar preços em lote.")
  });
  const products = productsQuery.data ?? [];
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 18 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => setCreating(true), children: "+ Novo produto" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 458,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 457,
      columnNumber: 7
    }, this),
    productsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: productsQuery.error, what: "os produtos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 463,
      columnNumber: 33
    }, this),
    !productsQuery.isLoading && products.length === 0 && !productsQuery.isError && /* @__PURE__ */ jsxDEV(EmptyState, { title: "Nenhum produto", description: "Nenhum produto encontrado no catálogo do iFood." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 465,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10 }, children: products.map(
      (product) => /* @__PURE__ */ jsxDEV("section", { className: "ticket rise", style: { padding: 14 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", alignItems: "center", gap: 10 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 700 }, children: product.name }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 473,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.8rem" }, children: [
            product.id,
            product.externalCode ? ` · código externo: ${product.externalCode}` : "",
            product.ean ? ` · EAN: ${product.ean}` : ""
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 474,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 472,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => setEditing(product), children: "Editar" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 481,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "danger",
              size: "sm",
              loading: deleteMutation.isPending,
              onClick: () => product.id && deleteMutation.mutate(product.id),
              children: "Excluir"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
              lineNumber: 484,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 480,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 471,
        columnNumber: 13
      }, this) }, product.id, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 470,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 468,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Buscar produto" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 499,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Código externo", value: externalCodeLookup, onChange: (e) => setExternalCodeLookup(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 501,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setSubmittedExternalCode(externalCodeLookup), children: "Buscar por código" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 502,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Product Id", value: idLookup, onChange: (e) => setIdLookup(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 505,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", loading: lookupByIdMutation.isPending, onClick: () => lookupByIdMutation.mutate(), children: "Buscar por Id" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 506,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 500,
        columnNumber: 9
      }, this),
      byExternalCodeQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: byExternalCodeQuery.error, what: "a busca por código externo" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 510,
        columnNumber: 41
      }, this),
      (byExternalCodeQuery.data ?? []).map(
        (p) => /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem" }, children: [
          p.name,
          " — ",
          p.id
        ] }, p.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 512,
          columnNumber: 9
        }, this)
      ),
      lookedUpProduct && /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", borderTop: "1px solid var(--border)", paddingTop: 8 }, children: [
        lookedUpProduct.name,
        " — ",
        lookedUpProduct.id
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 517,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 498,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Atualização em lote" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 524,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--ink-faint)" }, children: "Ids separados por vírgula." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 525,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Product Ids", value: batchStatusIds, onChange: (e) => setBatchStatusIds(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 527,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(SelectField, { label: "Status", value: batchStatusValue, onChange: (e) => setBatchStatusValue(e.target.value), children: [
          /* @__PURE__ */ jsxDEV("option", { value: "AVAILABLE", children: "Disponível" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 529,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "UNAVAILABLE", children: "Indisponível" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 530,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 528,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", loading: batchStatusMutation.isPending, onClick: () => batchStatusMutation.mutate(), children: "Atualizar status em lote" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 532,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 526,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Product Ids", value: batchPriceIds, onChange: (e) => setBatchPriceIds(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 537,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Novo preço", inputMode: "decimal", value: batchPriceValue, onChange: (e) => setBatchPriceValue(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 538,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", loading: batchPriceMutation.isPending, onClick: () => batchPriceMutation.mutate(), children: "Atualizar preço em lote" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 539,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 536,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 523,
      columnNumber: 7
    }, this),
    creating && /* @__PURE__ */ jsxDEV(
      ProductFormModal,
      {
        branchId,
        onClose: () => setCreating(false),
        onSaved: () => {
          setCreating(false);
          invalidate();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 546,
        columnNumber: 7
      },
      this
    ),
    editing && /* @__PURE__ */ jsxDEV(
      ProductFormModal,
      {
        branchId,
        product: editing,
        onClose: () => setEditing(null),
        onSaved: () => {
          setEditing(null);
          invalidate();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 557,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 456,
    columnNumber: 5
  }, this);
}
_s4(ProductsTab, "CtguTX2GT2hoAlZB8JWeyXeiuB8=", false, function() {
  return [useAuthStore, useToast, useQueryClient, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation];
});
_c4 = ProductsTab;
function ProductFormModal({
  branchId,
  product,
  onClose,
  onSaved
}) {
  _s5();
  const toast = useToast();
  const [name, setName] = useState(product?.name ?? "");
  const [description, setDescription] = useState(product?.description ?? "");
  const [externalCode, setExternalCode] = useState(product?.externalCode ?? "");
  const [ean, setEan] = useState(product?.ean ?? "");
  const [image, setImage] = useState(product?.imagePath ?? "");
  const saveMutation = useMutation({
    mutationFn: () => {
      const payload = {
        name: name.trim(),
        description: description.trim() || void 0,
        externalCode: externalCode.trim() || void 0,
        ean: ean.trim() || void 0,
        image: image.trim() || void 0
      };
      return product?.id ? editIFoodProduct(branchId, product.id, payload) : createIFoodProduct(branchId, payload);
    },
    onSuccess: () => {
      toast.success(product ? "Produto atualizado no iFood." : "Produto criado no iFood.");
      onSaved();
    },
    onError: () => toast.error("Não foi possível salvar o produto.")
  });
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: product ? "Editar produto" : "Novo produto", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 360 }, children: [
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome", value: name, onChange: (e) => setName(e.target.value), autoFocus: true }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 610,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Descrição (opcional)", value: description, onChange: (e) => setDescription(e.target.value) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 611,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Código externo (opcional)", value: externalCode, onChange: (e) => setExternalCode(e.target.value) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 612,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "EAN (opcional)", value: ean, onChange: (e) => setEan(e.target.value) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 613,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "URL da imagem (opcional)", value: image, onChange: (e) => setImage(e.target.value) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 614,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: "horários de disponibilidade (shifts) não estão nesta tela — use o console v1/v2 pra casos avançados." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 615,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 619,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", disabled: !name.trim(), loading: saveMutation.isPending, onClick: () => saveMutation.mutate(), children: "Salvar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 622,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 618,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 609,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 608,
    columnNumber: 5
  }, this);
}
_s5(ProductFormModal, "xXObWZP2ioQzJiA8AQXpvpJxRkQ=", false, function() {
  return [useToast, useMutation];
});
_c5 = ProductFormModal;
function ItemsTab() {
  _s6();
  const { branchId } = useAuthStore();
  const toast = useToast();
  const [itemId, setItemId] = useState("");
  const [submittedItemId, setSubmittedItemId] = useState("");
  const [priceValue, setPriceValue] = useState("");
  const [externalCode, setExternalCode] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [productId, setProductId] = useState("");
  const [categoryItemsId, setCategoryItemsId] = useState("");
  const [submittedCategoryItemsId, setSubmittedCategoryItemsId] = useState("");
  const itemQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "item", branchId, submittedItemId],
    queryFn: () => getIFoodItemFlat(branchId, submittedItemId),
    enabled: !!submittedItemId
  });
  const categoryItemsQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "category-items", branchId, submittedCategoryItemsId],
    queryFn: () => listIFoodCategoryItems(branchId, submittedCategoryItemsId),
    enabled: !!submittedCategoryItemsId
  });
  const setPriceMutation = useMutation({
    mutationFn: () => setIFoodItemPrice(branchId, submittedItemId, Number(priceValue) || 0),
    onSuccess: () => {
      toast.success("Preço do item atualizado no iFood.");
      void itemQuery.refetch();
    },
    onError: () => toast.error("Falha ao atualizar o preço do item.")
  });
  const setExternalCodeMutation = useMutation({
    mutationFn: () => setIFoodItemExternalCode(branchId, submittedItemId, externalCode.trim() || void 0),
    onSuccess: () => {
      toast.success("Código externo do item atualizado no iFood.");
      void itemQuery.refetch();
    },
    onError: () => toast.error("Falha ao atualizar o código externo do item.")
  });
  const deleteItemMutation = useMutation({
    mutationFn: () => deleteIFoodItem(branchId, categoryId.trim(), productId.trim()),
    onSuccess: () => toast.success("Item excluído no iFood."),
    onError: () => toast.error("Falha ao excluir o item.")
  });
  const item = itemQuery.data;
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 18 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Consultar item (formato flat v2)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 688,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Item Id", value: itemId, onChange: (e) => setItemId(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 690,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setSubmittedItemId(itemId), children: "Consultar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 691,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 689,
        columnNumber: 9
      }, this),
      itemQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: itemQuery.error, what: "o item" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 695,
        columnNumber: 31
      }, this),
      item && /* @__PURE__ */ jsxDEV("pre", { className: "ticket", style: { padding: 12, fontSize: "0.8rem", overflowX: "auto", whiteSpace: "pre-wrap" }, children: prettyJson(item.rawPayload) || `${item.itemId} · status ${item.status} · preço ${item.priceValue}` }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 697,
        columnNumber: 9
      }, this),
      submittedItemId && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10 }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Novo preço", inputMode: "decimal", value: priceValue, onChange: (e) => setPriceValue(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 704,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", loading: setPriceMutation.isPending, onClick: () => setPriceMutation.mutate(), children: "Atualizar preço" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 705,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 703,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Novo código externo", value: externalCode, onChange: (e) => setExternalCode(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 710,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", loading: setExternalCodeMutation.isPending, onClick: () => setExternalCodeMutation.mutate(), children: "Atualizar código externo" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 711,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 709,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 702,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 687,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Excluir item de uma categoria" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 720,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Category Id", value: categoryId, onChange: (e) => setCategoryId(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 722,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Product Id", value: productId, onChange: (e) => setProductId(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 723,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "danger",
            disabled: !categoryId.trim() || !productId.trim(),
            loading: deleteItemMutation.isPending,
            onClick: () => deleteItemMutation.mutate(),
            children: "Excluir item"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 724,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 721,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 719,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Itens de uma categoria" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 736,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Category Id", value: categoryItemsId, onChange: (e) => setCategoryItemsId(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 738,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setSubmittedCategoryItemsId(categoryItemsId), children: "Consultar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 739,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 737,
        columnNumber: 9
      }, this),
      categoryItemsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: categoryItemsQuery.error, what: "os itens da categoria" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 743,
        columnNumber: 40
      }, this),
      categoryItemsQuery.data?.rawPayload && /* @__PURE__ */ jsxDEV("pre", { className: "ticket", style: { padding: 12, fontSize: "0.8rem", overflowX: "auto", whiteSpace: "pre-wrap" }, children: prettyJson(categoryItemsQuery.data.rawPayload) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 745,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 735,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 686,
    columnNumber: 5
  }, this);
}
_s6(ItemsTab, "gRoIes8JmC8RRLLLyh2yEzRHunY=", false, function() {
  return [useAuthStore, useToast, useQuery, useQuery, useMutation, useMutation, useMutation];
});
_c6 = ItemsTab;
function OptionGroupsTab() {
  _s7();
  const { branchId } = useAuthStore();
  const toast = useToast();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [optionId, setOptionId] = useState("");
  const [optionPrice, setOptionPrice] = useState("");
  const [optionExternalCode, setOptionExternalCode] = useState("");
  const groupsQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "option-groups", branchId],
    queryFn: () => listIFoodOptionGroups(branchId, true)
  });
  const invalidate = () => void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "catalog", "option-groups"] });
  const deleteGroupMutation = useMutation({
    mutationFn: (id) => deleteIFoodOptionGroup(branchId, id),
    onSuccess: () => {
      toast.success("Grupo de opções excluído no iFood.");
      invalidate();
    },
    onError: () => toast.error("Falha ao excluir o grupo de opções.")
  });
  const toggleStatusMutation = useMutation({
    mutationFn: ({ id, available }) => updateIFoodOptionGroupStatus(branchId, id, available),
    onSuccess: () => {
      toast.success("Status do grupo atualizado no iFood.");
      invalidate();
    },
    onError: () => toast.error("Falha ao atualizar o status do grupo.")
  });
  const setOptionPriceMutation = useMutation({
    mutationFn: () => setIFoodOptionPrice(branchId, optionId.trim(), Number(optionPrice) || 0),
    onSuccess: () => toast.success("Preço da opção atualizado no iFood."),
    onError: () => toast.error("Falha ao atualizar o preço da opção.")
  });
  const setOptionExternalCodeMutation = useMutation({
    mutationFn: () => setIFoodOptionExternalCode(branchId, optionId.trim(), optionExternalCode.trim()),
    onSuccess: () => toast.success("Código externo da opção atualizado no iFood."),
    onError: () => toast.error("Falha ao atualizar o código externo da opção.")
  });
  const toggleOptionStatusMutation = useMutation({
    mutationFn: (available) => setIFoodOptionStatus(branchId, optionId.trim(), available),
    onSuccess: () => toast.success("Status da opção atualizado no iFood."),
    onError: () => toast.error("Falha ao atualizar o status da opção.")
  });
  const deleteOptionMutation = useMutation({
    mutationFn: () => deleteIFoodOption(branchId, editing?.id ?? "", optionId.trim()),
    onSuccess: () => toast.success("Opção excluída no iFood."),
    onError: () => toast.error("Falha ao excluir a opção.")
  });
  const disassociateMutation = useMutation({
    mutationFn: ({ groupId, productId }) => disassociateIFoodOptionGroup(branchId, groupId, productId),
    onSuccess: () => toast.success("Grupo desassociado do produto no iFood."),
    onError: () => toast.error("Falha ao desassociar o grupo do produto.")
  });
  const renameGroupMutation = useMutation({
    mutationFn: (name) => updateIFoodOptionGroup(branchId, editing?.id ?? "", name),
    onSuccess: () => {
      toast.success("Nome do grupo atualizado no iFood.");
      invalidate();
    },
    onError: () => toast.error("Falha ao renomear o grupo.")
  });
  const [disassociateProductId, setDisassociateProductId] = useState("");
  const [renameValue, setRenameValue] = useState("");
  const groups = groupsQuery.data ?? [];
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 18 }, children: [
    groupsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: groupsQuery.error, what: "os grupos de opções" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 840,
      columnNumber: 31
    }, this),
    !groupsQuery.isLoading && groups.length === 0 && !groupsQuery.isError && /* @__PURE__ */ jsxDEV(EmptyState, { title: "Nenhum grupo de opções", description: "Nenhum grupo de complementos encontrado no iFood." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 842,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10 }, children: groups.map(
      (group) => /* @__PURE__ */ jsxDEV("section", { className: "ticket rise", style: { padding: 14 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", alignItems: "center", gap: 10 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 700 }, children: group.name }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 850,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.8rem" }, children: [
            group.id,
            " · status: ",
            group.status ?? "—"
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 851,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 849,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              onClick: () => {
                setEditing(group);
                setRenameValue(group.name ?? "");
              },
              children: "Gerenciar opções"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
              lineNumber: 856,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              loading: toggleStatusMutation.isPending,
              onClick: () => group.id && toggleStatusMutation.mutate({ id: group.id, available: group.status !== "AVAILABLE" }),
              children: group.status === "AVAILABLE" ? "Pausar" : "Reativar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
              lineNumber: 866,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "danger",
              size: "sm",
              loading: deleteGroupMutation.isPending,
              onClick: () => group.id && deleteGroupMutation.mutate(group.id),
              children: "Excluir"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
              lineNumber: 874,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 855,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 848,
        columnNumber: 13
      }, this) }, group.id, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 847,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 845,
      columnNumber: 7
    }, this),
    editing && /* @__PURE__ */ jsxDEV(Modal, { onClose: () => setEditing(null), title: `Opções de "${editing.name}"`, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 380 }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Nome do grupo", value: renameValue, onChange: (e) => setRenameValue(e.target.value), autoFocus: true }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 892,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            disabled: !renameValue.trim() || renameValue.trim() === editing.name,
            loading: renameGroupMutation.isPending,
            onClick: () => renameGroupMutation.mutate(renameValue.trim()),
            children: "Renomear"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 893,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 891,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("hr", { style: { border: "none", borderTop: "1px solid var(--border)", margin: "2px 0" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 903,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Option Id", value: optionId, onChange: (e) => setOptionId(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 905,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Novo preço", inputMode: "decimal", value: optionPrice, onChange: (e) => setOptionPrice(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 907,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            disabled: !optionId.trim(),
            loading: setOptionPriceMutation.isPending,
            onClick: () => setOptionPriceMutation.mutate(),
            children: "Atualizar preço"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 908,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 906,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Novo código externo", value: optionExternalCode, onChange: (e) => setOptionExternalCode(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 918,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            disabled: !optionId.trim() || !optionExternalCode.trim(),
            loading: setOptionExternalCodeMutation.isPending,
            onClick: () => setOptionExternalCodeMutation.mutate(),
            children: "Atualizar código"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 919,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 917,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10 }, children: [
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            disabled: !optionId.trim(),
            loading: toggleOptionStatusMutation.isPending,
            onClick: () => toggleOptionStatusMutation.mutate(true),
            children: "Ativar opção"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 929,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            disabled: !optionId.trim(),
            loading: toggleOptionStatusMutation.isPending,
            onClick: () => toggleOptionStatusMutation.mutate(false),
            children: "Pausar opção"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 937,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "danger",
            disabled: !optionId.trim(),
            loading: deleteOptionMutation.isPending,
            onClick: () => deleteOptionMutation.mutate(),
            children: "Excluir opção"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 945,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 928,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("hr", { style: { border: "none", borderTop: "1px solid var(--border)", margin: "6px 0" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 955,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("strong", { style: { fontSize: "0.9rem" }, children: "Desassociar este grupo de um produto" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 957,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Product Id", value: disassociateProductId, onChange: (e) => setDisassociateProductId(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 959,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            disabled: !disassociateProductId.trim(),
            loading: disassociateMutation.isPending,
            onClick: () => editing.id && disassociateMutation.mutate({ groupId: editing.id, productId: disassociateProductId.trim() }),
            children: "Desassociar"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 960,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 958,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end", marginTop: 6 }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setEditing(null), children: "Fechar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 973,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 972,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 890,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 889,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 839,
    columnNumber: 5
  }, this);
}
_s7(OptionGroupsTab, "9TZjHpmu12e2CjVfVKqH83bPxVU=", false, function() {
  return [useAuthStore, useToast, useQueryClient, useQuery, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation];
});
_c7 = OptionGroupsTab;
function AdminTab() {
  _s8();
  const { branchId } = useAuthStore();
  const toast = useToast();
  const [inventoryProductId, setInventoryProductId] = useState("");
  const [submittedInventoryId, setSubmittedInventoryId] = useState("");
  const [batchDeleteIds, setBatchDeleteIds] = useState("");
  const [batchResultId, setBatchResultId] = useState("");
  const [submittedBatchResultId, setSubmittedBatchResultId] = useState("");
  const [imageJsonBody, setImageJsonBody] = useState("");
  const [confirmingUpgrade, setConfirmingUpgrade] = useState(false);
  const [confirmingDowngrade, setConfirmingDowngrade] = useState(false);
  const versionQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "version", branchId],
    queryFn: () => checkIFoodCatalogVersion(branchId)
  });
  const inventoryQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "inventory", branchId, submittedInventoryId],
    queryFn: () => getIFoodInventory(branchId, submittedInventoryId),
    enabled: !!submittedInventoryId
  });
  const batchResultQuery = useQuery({
    queryKey: ["integrations", "ifood", "catalog", "batch-result", branchId, submittedBatchResultId],
    queryFn: () => getIFoodBatchResult(branchId, submittedBatchResultId),
    enabled: !!submittedBatchResultId
  });
  const deleteInventoryBatchMutation = useMutation({
    mutationFn: () => deleteIFoodInventoryBatch(
      branchId,
      batchDeleteIds.split(",").map((id) => id.trim()).filter(Boolean)
    ),
    onSuccess: () => toast.success("Estoque removido em lote no iFood."),
    onError: () => toast.error("Falha ao remover estoque em lote.")
  });
  const upgradeMutation = useMutation({
    mutationFn: () => upgradeIFoodCatalogVersion(branchId),
    onSuccess: () => {
      toast.success("Catálogo migrado para v2 no iFood.");
      setConfirmingUpgrade(false);
      void versionQuery.refetch();
    },
    onError: () => toast.error("Falha ao migrar o catálogo para v2.")
  });
  const downgradeMutation = useMutation({
    mutationFn: () => downgradeIFoodCatalogVersion(branchId),
    onSuccess: () => {
      toast.success("Catálogo revertido para v1 no iFood.");
      setConfirmingDowngrade(false);
      void versionQuery.refetch();
    },
    onError: () => toast.error("Falha ao reverter o catálogo para v1.")
  });
  const uploadImageMutation = useMutation({
    mutationFn: () => uploadIFoodImage(branchId, imageJsonBody),
    onSuccess: (result) => toast.success(`Imagem enviada. Resposta: ${prettyJson(result.rawPayload).slice(0, 120) || "(vazia)"}`),
    onError: () => toast.error("Falha ao enviar a imagem — confira o JSON.")
  });
  const inventory = inventoryQuery.data;
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 18 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Versão do catálogo" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1058,
        columnNumber: 9
      }, this),
      versionQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: versionQuery.error, what: "a versão do catálogo" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1059,
        columnNumber: 34
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: [
        "Versão atual: ",
        versionQuery.data?.version ?? "—"
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1060,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: "⚠️ upgrade/downgrade são operações destrutivas e irreversíveis contra o catálogo real do merchant no iFood — confirme com atenção." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1061,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10 }, children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setConfirmingUpgrade(true), children: "Migrar para v2 (upgrade)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1066,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setConfirmingDowngrade(true), children: "Reverter para v1 (downgrade)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1069,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1065,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1057,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Estoque" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1076,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Product Id", value: inventoryProductId, onChange: (e) => setInventoryProductId(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1078,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setSubmittedInventoryId(inventoryProductId), children: "Consultar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1079,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1077,
        columnNumber: 9
      }, this),
      inventoryQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: inventoryQuery.error, what: "o estoque" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1083,
        columnNumber: 36
      }, this),
      inventory && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem" }, children: [
        "Quantidade: ",
        inventory.amount ?? "—",
        " · em estoque: ",
        inventory.inStock ? "sim" : "não"
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1085,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Remover estoque em lote (Ids separados por vírgula)",
            value: batchDeleteIds,
            onChange: (e) => setBatchDeleteIds(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 1090,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "danger",
            disabled: !batchDeleteIds.trim(),
            loading: deleteInventoryBatchMutation.isPending,
            onClick: () => deleteInventoryBatchMutation.mutate(),
            children: "Remover"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 1095,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1089,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1075,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Resultado de processamento em lote" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1107,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--ink-faint)" }, children: "use o BatchId devolvido por uma atualização de preços em lote (aba Produtos)." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1108,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Batch Id", value: batchResultId, onChange: (e) => setBatchResultId(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1112,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setSubmittedBatchResultId(batchResultId), children: "Consultar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1113,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1111,
        columnNumber: 9
      }, this),
      batchResultQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: batchResultQuery.error, what: "o resultado do lote" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1117,
        columnNumber: 38
      }, this),
      batchResultQuery.data && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Status: ",
          batchResultQuery.data.batchStatus ?? "—"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1120,
          columnNumber: 13
        }, this),
        batchResultQuery.data.results.map(
          (r, idx) => /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
            r.resourceId,
            ": ",
            r.result,
            " ",
            r.failureReason ? `(${r.failureReason})` : ""
          ] }, idx, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 1122,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1119,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1106,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Upload de imagem" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1131,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: "⚠️ a doc oficial não documenta o schema deste endpoint — cole o JSON pronto que o iFood espera; a resposta crua aparece após o envio." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1132,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          value: imageJsonBody,
          onChange: (e) => setImageJsonBody(e.target.value),
          rows: 5,
          placeholder: '{"image": "..."}',
          style: { fontFamily: "monospace", fontSize: "0.8rem", padding: 8 }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1136,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "ghost",
          disabled: !imageJsonBody.trim(),
          loading: uploadImageMutation.isPending,
          onClick: () => uploadImageMutation.mutate(),
          children: "Enviar imagem"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1144,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1143,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1130,
      columnNumber: 7
    }, this),
    confirmingUpgrade && /* @__PURE__ */ jsxDEV(Modal, { onClose: () => setConfirmingUpgrade(false), title: "Confirmar migração para v2", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 320 }, children: [
      /* @__PURE__ */ jsxDEV("span", { children: [
        "Esta ação é ",
        /* @__PURE__ */ jsxDEV("strong", { children: "destrutiva e irreversível" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1159,
          columnNumber: 27
        }, this),
        " — o iFood vai reorganizar todo o catálogo real do merchant desta filial de v1 para v2. Confirma?"
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1158,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setConfirmingUpgrade(false), children: "Cancelar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1163,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "danger", loading: upgradeMutation.isPending, onClick: () => upgradeMutation.mutate(), children: "Confirmar migração" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1166,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1162,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1157,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1156,
      columnNumber: 7
    }, this),
    confirmingDowngrade && /* @__PURE__ */ jsxDEV(Modal, { onClose: () => setConfirmingDowngrade(false), title: "Confirmar reversão para v1", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 320 }, children: [
      /* @__PURE__ */ jsxDEV("span", { children: [
        "Esta ação é ",
        /* @__PURE__ */ jsxDEV("strong", { children: "destrutiva e irreversível" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1178,
          columnNumber: 27
        }, this),
        " — o iFood vai reorganizar todo o catálogo real do merchant desta filial de v2 para v1. Confirma?"
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1177,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setConfirmingDowngrade(false), children: "Cancelar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1182,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "danger", loading: downgradeMutation.isPending, onClick: () => downgradeMutation.mutate(), children: "Confirmar reversão" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1185,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1181,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1176,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1175,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 1056,
    columnNumber: 5
  }, this);
}
_s8(AdminTab, "UfMTjZkppm+mxORglRUOM6xvb6w=", false, function() {
  return [useAuthStore, useToast, useQuery, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation];
});
_c8 = AdminTab;
function V1ConsoleTab() {
  _s9();
  const { branchId } = useAuthStore();
  const toast = useToast();
  const [operation, setOperation] = useState(IFOOD_CATALOG_V1_OPERATIONS[0]);
  const [routeParamsText, setRouteParamsText] = useState("");
  const [queryParamsText, setQueryParamsText] = useState("");
  const [jsonBody, setJsonBody] = useState("");
  const invokeMutation = useMutation({
    mutationFn: () => {
      let routeParams;
      let queryParams;
      try {
        routeParams = routeParamsText.trim() ? JSON.parse(routeParamsText) : void 0;
        queryParams = queryParamsText.trim() ? JSON.parse(queryParamsText) : void 0;
      } catch {
        throw new Error("invalid-json");
      }
      return invokeIFoodCatalogV1Operation(branchId, operation, {
        routeParams,
        queryParams,
        jsonBody: jsonBody.trim() || void 0
      });
    },
    onSuccess: (result) => {
      if (result.success) toast.success(`Chamada v1 concluída (HTTP ${result.statusCode}).`);
      else
        toast.error(`iFood respondeu com erro (HTTP ${result.statusCode}) — veja o payload abaixo.`);
    },
    onError: (error) => toast.error(error instanceof Error && error.message === "invalid-json" ? "routeParams/queryParams precisam ser JSON válido." : "Falha ao chamar o endpoint v1.")
  });
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 18 }, children: /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
    /* @__PURE__ */ jsxDEV("strong", { children: "Console genérico — módulo Catalog v1 (legado)" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1235,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--ink-faint)" }, children: 'use esta tela apenas se o merchant desta filial ainda estiver na versão v1 do catálogo (ver aba Administração → "Versão do catálogo"). Cobre os 56 endpoints legados sem tela dedicada — escolha a operação, informe os parâmetros de rota/query (como JSON) e o corpo (quando aplicável). A resposta, inclusive erros do iFood, é sempre mostrada crua abaixo.' }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1236,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      SelectField,
      {
        label: "Operação",
        value: operation,
        onChange: (e) => setOperation(e.target.value),
        children: IFOOD_CATALOG_V1_OPERATIONS.map(
          (op) => /* @__PURE__ */ jsxDEV("option", { value: op, children: op }, op, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
            lineNumber: 1249,
            columnNumber: 11
          }, this)
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1243,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
      /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.85rem", fontWeight: 600 }, children: "Route params (JSON, opcional)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1256,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          value: routeParamsText,
          onChange: (e) => setRouteParamsText(e.target.value),
          rows: 2,
          placeholder: '{"categoryId": "..."}',
          style: { fontFamily: "monospace", fontSize: "0.8rem", padding: 8 }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1257,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1255,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
      /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.85rem", fontWeight: 600 }, children: "Query params (JSON, opcional)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1267,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          value: queryParamsText,
          onChange: (e) => setQueryParamsText(e.target.value),
          rows: 2,
          placeholder: '{"page": "1"}',
          style: { fontFamily: "monospace", fontSize: "0.8rem", padding: 8 }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1268,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1266,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
      /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.85rem", fontWeight: 600 }, children: "Corpo JSON (opcional — POST/PUT/PATCH)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
        lineNumber: 1278,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          value: jsonBody,
          onChange: (e) => setJsonBody(e.target.value),
          rows: 6,
          placeholder: '{"name": "..."}',
          style: { fontFamily: "monospace", fontSize: "0.8rem", padding: 8 }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
          lineNumber: 1279,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1277,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "primary", loading: invokeMutation.isPending, onClick: () => invokeMutation.mutate(), children: "Chamar iFood" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1289,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1288,
      columnNumber: 9
    }, this),
    invokeMutation.data && /* @__PURE__ */ jsxDEV("pre", { className: "ticket", style: { padding: 12, fontSize: "0.8rem", overflowX: "auto", whiteSpace: "pre-wrap" }, children: `HTTP ${invokeMutation.data.statusCode}${invokeMutation.data.errorMessage ? ` — ${invokeMutation.data.errorMessage}` : ""}

${prettyJson(invokeMutation.data.responseBody)}` }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
      lineNumber: 1295,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 1234,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx",
    lineNumber: 1233,
    columnNumber: 5
  }, this);
}
_s9(V1ConsoleTab, "ltdnnIbe8knZv4bEm6s5LuQsU/Q=", false, function() {
  return [useAuthStore, useToast, useMutation];
});
_c9 = V1ConsoleTab;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
$RefreshReg$(_c, "IFoodCatalogPage");
$RefreshReg$(_c2, "CategoriesTab");
$RefreshReg$(_c3, "CategoryFormModal");
$RefreshReg$(_c4, "ProductsTab");
$RefreshReg$(_c5, "ProductFormModal");
$RefreshReg$(_c6, "ItemsTab");
$RefreshReg$(_c7, "OptionGroupsTab");
$RefreshReg$(_c8, "AdminTab");
$RefreshReg$(_c9, "V1ConsoleTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodCatalogPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEZRLFNBcVBFLFVBclBGOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFGUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUtLO0FBQ1AsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsYUFBYUMsaUJBQWlCO0FBQ3ZDLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxrQkFBa0I7QUFjM0IsTUFBTUMsT0FBMEM7QUFBQSxFQUM5QyxFQUFFQyxLQUFLLGNBQWNDLE9BQU8sYUFBYTtBQUFBLEVBQ3pDLEVBQUVELEtBQUssWUFBWUMsT0FBTyxXQUFXO0FBQUEsRUFDckMsRUFBRUQsS0FBSyxTQUFTQyxPQUFPLFFBQVE7QUFBQSxFQUMvQixFQUFFRCxLQUFLLGdCQUFnQkMsT0FBTyxlQUFlO0FBQUEsRUFDN0MsRUFBRUQsS0FBSyxTQUFTQyxPQUFPLGdCQUFnQjtBQUFBLEVBQ3ZDLEVBQUVELEtBQUssTUFBTUMsT0FBTyxzQkFBc0I7QUFBQztBQUc3QyxTQUFTQyxXQUFXQyxLQUF3QztBQUMxRCxNQUFJLENBQUNBLElBQUssUUFBTztBQUNqQixNQUFJO0FBQ0YsV0FBT0MsS0FBS0MsVUFBVUQsS0FBS0UsTUFBTUgsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUFBLEVBQ2hELFFBQVE7QUFDTixXQUFPQTtBQUFBQSxFQUNUO0FBQ0Y7QUFFTyxnQkFBU0ksbUJBQW1CO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUk3RCxTQUFrQixZQUFZO0FBRWhFLFNBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUU4RCxTQUFTLElBQUlDLFVBQVUsTUFBTUMsUUFBUSxTQUFTLEdBQzNEO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFQyxjQUFjLEdBQUcsR0FDOUM7QUFBQSw2QkFBQyxRQUFLLElBQUcsc0JBQXFCLE9BQU8sRUFBRUMsT0FBTyxvQkFBb0JDLFVBQVUsVUFBVSxHQUFHLGtDQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUEsVUFBVSxTQUFTLEdBQUcsd0NBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVELE9BQU8sb0JBQW9CQyxVQUFVLFNBQVMsR0FBRyxvT0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxTQUFTLFFBQVFDLEtBQUssR0FBR0MsY0FBYywyQkFBMkJMLGNBQWMsSUFBSU0sVUFBVSxPQUFPLEdBQ2hIckIsZUFBS3NCO0FBQUFBLE1BQUksQ0FBQ0MsUUFDVDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNWixhQUFhWSxJQUFJdEIsR0FBRztBQUFBLFVBQ25DLE9BQU87QUFBQSxZQUNMVyxTQUFTO0FBQUEsWUFDVFksUUFBUTtBQUFBLFlBQ1JDLFlBQVk7QUFBQSxZQUNaQyxRQUFRO0FBQUEsWUFDUlQsVUFBVTtBQUFBLFlBQ1ZVLFlBQVlqQixjQUFjYSxJQUFJdEIsTUFBTSxNQUFNO0FBQUEsWUFDMUNlLE9BQU9OLGNBQWNhLElBQUl0QixNQUFNLGVBQWU7QUFBQSxZQUM5Q21CLGNBQWNWLGNBQWNhLElBQUl0QixNQUFNLHlCQUF5QjtBQUFBLFlBQy9EYyxjQUFjO0FBQUEsVUFDaEI7QUFBQSxVQUVDUSxjQUFJckI7QUFBQUE7QUFBQUEsUUFmQXFCLElBQUl0QjtBQUFBQSxRQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFpQkE7QUFBQSxJQUNELEtBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkE7QUFBQSxJQUVDUyxjQUFjLGdCQUFnQix1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUM1Q0EsY0FBYyxjQUFjLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWTtBQUFBLElBQ3hDQSxjQUFjLFdBQVcsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNsQ0EsY0FBYyxrQkFBa0IsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLElBQ2hEQSxjQUFjLFdBQVcsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNsQ0EsY0FBYyxRQUFRLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYTtBQUFBLE9BM0N0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNENBO0FBRUo7QUFJQUQsR0F0RGdCRCxrQkFBZ0I7QUFBQSxLQUFoQkE7QUF3RGhCLFNBQVNvQixnQkFBZ0I7QUFBQUMsTUFBQTtBQUN2QixRQUFNLEVBQUVDLFNBQVMsSUFBSXRDLGFBQWE7QUFDbEMsUUFBTXVDLFFBQVF0QyxTQUFTO0FBQ3ZCLFFBQU11QyxjQUFjOUUsZUFBZTtBQUNuQyxRQUFNLENBQUMrRSxXQUFXQyxZQUFZLElBQUlwRixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDcUYsVUFBVUMsV0FBVyxJQUFJdEYsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQ3VGLFNBQVNDLFVBQVUsSUFBSXhGLFNBQXVDLElBQUk7QUFDekUsUUFBTSxDQUFDeUYsU0FBU0MsVUFBVSxJQUFJMUYsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQzJGLGtCQUFrQkMsbUJBQW1CLElBQUk1RixTQUFTLEVBQUU7QUFFM0QsUUFBTTZGLGdCQUFnQjFGLFNBQVM7QUFBQSxJQUM3QjJGLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxXQUFXLFlBQVlkLFFBQVE7QUFBQSxJQUNuRWUsU0FBU0EsTUFBTXpFLGlCQUFpQjBELFFBQVE7QUFBQSxFQUMxQyxDQUFDO0FBRUQsUUFBTWdCLFdBQVdILGNBQWNJLFFBQVE7QUFDdkMsUUFBTUMscUJBQXFCZixhQUFhYSxTQUFTLENBQUMsR0FBR2IsYUFBYTtBQUVsRSxRQUFNZ0Isa0JBQWtCaEcsU0FBUztBQUFBLElBQy9CMkYsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFdBQVcsY0FBY2QsVUFBVWtCLGtCQUFrQjtBQUFBLElBQ3pGSCxTQUFTQSxNQUFNcEUsb0JBQW9CcUQsVUFBVWtCLGtCQUFrQjtBQUFBLElBQy9ERSxTQUFTLENBQUMsQ0FBQ0Y7QUFBQUEsRUFDYixDQUFDO0FBRUQsUUFBTUcscUJBQXFCbEcsU0FBUztBQUFBLElBQ2xDMkYsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFdBQVcsa0JBQWtCZCxVQUFVVyxnQkFBZ0I7QUFBQSxJQUMzRkksU0FBU0EsTUFBTS9ELHVCQUF1QmdELFVBQVVXLGdCQUFnQjtBQUFBLElBQ2hFUyxTQUFTLENBQUMsQ0FBQ1Q7QUFBQUEsRUFDYixDQUFDO0FBRUQsUUFBTVcsYUFBYUEsTUFDakIsS0FBS3BCLFlBQVlxQixrQkFBa0IsRUFBRVQsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFdBQVcsWUFBWSxFQUFFLENBQUM7QUFFckcsUUFBTVUsaUJBQWlCdEcsWUFBWTtBQUFBLElBQ2pDdUcsWUFBWUEsQ0FBQ0MsZUFBdUIvRixvQkFBb0JxRSxVQUFVMEIsVUFBVTtBQUFBLElBQzVFQyxXQUFXQSxNQUFNO0FBQ2YxQixZQUFNMkIsUUFBUSw4QkFBOEI7QUFDNUNOLGlCQUFXO0FBQUEsSUFDYjtBQUFBLElBQ0FPLFNBQVNBLE1BQU01QixNQUFNNkIsTUFBTSx1Q0FBdUM7QUFBQSxFQUNwRSxDQUFDO0FBRUQsUUFBTUMsYUFBYVosZ0JBQWdCRixRQUFRO0FBRTNDLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUU3QixTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNyQztBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRVAsU0FBUyxJQUFJTSxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNuRSxpQ0FBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUEsS0FBSyxJQUFJMkMsWUFBWSxZQUFZQyxnQkFBZ0IsZ0JBQWdCLEdBQzVHO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLE9BQU9mO0FBQUFBLFVBQ1AsVUFBVSxDQUFDZ0IsTUFBTTlCLGFBQWE4QixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsVUFDNUMsVUFBVXZCLGNBQWN3QjtBQUFBQSxVQUN4QixNQUFLO0FBQUEsVUFFSnJCLG1CQUFTeEI7QUFBQUEsWUFBSSxDQUFDOEMsTUFDYix1QkFBQyxZQUErQixPQUFPQSxFQUFFbkMsYUFBYSxJQUNuRG1DO0FBQUFBLGdCQUFFbkM7QUFBQUEsY0FBVTtBQUFBLGNBQUVtQyxFQUFFQyxTQUFTLElBQUlELEVBQUVDLE1BQU0sTUFBTTtBQUFBLGlCQURqQ0QsRUFBRW5DLGFBQWEsSUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBQ0Q7QUFBQTtBQUFBLFFBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BWUE7QUFBQSxNQUNBLHVCQUFDLFVBQU8sU0FBUSxXQUFVLFVBQVUsQ0FBQ2Usb0JBQW9CLFNBQVMsTUFBTVosWUFBWSxJQUFJLEdBQUcsZ0NBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBRUNPLGNBQWMyQixXQUFXLHVCQUFDLGNBQVcsT0FBTzNCLGNBQWNpQixPQUFPLE1BQUssa0JBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkQ7QUFBQSxJQUNwRlgsZ0JBQWdCcUIsV0FBVyx1QkFBQyxjQUFXLE9BQU9yQixnQkFBZ0JXLE9BQU8sTUFBSyxtQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RDtBQUFBLElBRXpGLENBQUNYLGdCQUFnQmtCLGFBQWFOLFdBQVdVLFdBQVcsS0FBSyxDQUFDdEIsZ0JBQWdCcUIsV0FBV3RCLHNCQUNwRix1QkFBQyxjQUFXLE9BQU0scUJBQW9CLGFBQVksc0RBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0c7QUFBQSxJQUd0Ryx1QkFBQyxTQUFJLE9BQU8sRUFBRTlCLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ3BDMEMscUJBQVd2QztBQUFBQSxNQUFJLENBQUNrRCxhQUNmLHVCQUFDLGFBQTBCLFdBQVUsZUFBYyxPQUFPLEVBQUU1RCxTQUFTLEdBQUcsR0FDdEUsaUNBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVtRCxnQkFBZ0IsaUJBQWlCRCxZQUFZLFVBQVUzQyxLQUFLLEdBQUcsR0FDMUc7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRUQsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRVEsWUFBWSxJQUFJLEdBQUk2QyxtQkFBU0MsUUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxVQUFLLE9BQU8sRUFBRXpELE9BQU8sb0JBQW9CQyxVQUFVLFNBQVMsR0FDMUR1RDtBQUFBQSxxQkFBU0U7QUFBQUEsWUFBRztBQUFBLFlBQVlGLFNBQVNILFVBQVU7QUFBQSxZQUFJO0FBQUEsWUFBWUcsU0FBU0csU0FBUztBQUFBLFlBQzdFSCxTQUFTSSxlQUFlLHNCQUFzQkosU0FBU0ksWUFBWSxLQUFLO0FBQUEsZUFGM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRTFELFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsaUNBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFNBQVMsTUFBTW1CLFdBQVdrQyxRQUFRLEdBQUcsc0JBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixNQUFLO0FBQUEsY0FDTCxTQUFTbEIsZUFBZXVCO0FBQUFBLGNBQ3hCLFNBQVMsTUFBTUwsU0FBU0UsTUFBTXBCLGVBQWV3QixPQUFPTixTQUFTRSxFQUFFO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFKbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkEsS0F0QllGLFNBQVNFLElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxJQUNELEtBMUJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRTlELFNBQVMsSUFBSU0sU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDbkU7QUFBQSw2QkFBQyxZQUFPLHlDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUNqQyx1QkFBQyxVQUFLLE9BQU8sRUFBRUYsVUFBVSxXQUFXRCxPQUFPLG1CQUFtQixHQUFHLDZHQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFRyxLQUFLLElBQUkyQyxZQUFZLFdBQVcsR0FDM0U7QUFBQSwrQkFBQyxhQUFVLE9BQU0sWUFBVyxPQUFPdkIsU0FBUyxVQUFVLENBQUN5QixNQUFNeEIsV0FBV3dCLEVBQUVDLE9BQU9DLEtBQUssS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RjtBQUFBLFFBQ3hGLHVCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVMsTUFBTXhCLG9CQUFvQkgsT0FBTyxHQUFHLHlCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0NZLG1CQUFtQm1CLFdBQVcsdUJBQUMsY0FBVyxPQUFPbkIsbUJBQW1CUyxPQUFPLE1BQUssd0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxPQUNuR1QsbUJBQW1CSixRQUFRLElBQUl6QjtBQUFBQSxRQUFJLENBQUN5RCxTQUNwQyx1QkFBQyxTQUFzQixPQUFPLEVBQUU5RCxVQUFVLFdBQVcrRCxXQUFXLDJCQUEyQkMsWUFBWSxFQUFFLEdBQ3RHRjtBQUFBQSxlQUFLRztBQUFBQSxVQUFTO0FBQUEsVUFBSUgsS0FBS0ksZ0JBQWdCQyxlQUFlLFNBQVMsRUFBRUMsT0FBTyxZQUFZQyxVQUFVLE1BQU0sQ0FBQyxLQUFLO0FBQUEsVUFDMUdQLEtBQUtRLG1CQUFtQixjQUFjUixLQUFLUSxnQkFBZ0IsS0FBSztBQUFBLGFBRnpEUixLQUFLUyxRQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLE1BQ0Q7QUFBQSxTQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBO0FBQUEsSUFFQ3JELFlBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxXQUFXYTtBQUFBQSxRQUNYLFNBQVMsTUFBTVosWUFBWSxLQUFLO0FBQUEsUUFDaEMsU0FBUyxNQUFNO0FBQ2JBLHNCQUFZLEtBQUs7QUFDakJnQixxQkFBVztBQUFBLFFBQ2I7QUFBQTtBQUFBLE1BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0k7QUFBQSxJQUlMZixXQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsV0FBV1c7QUFBQUEsUUFDWCxVQUFVWDtBQUFBQSxRQUNWLFNBQVMsTUFBTUMsV0FBVyxJQUFJO0FBQUEsUUFDOUIsU0FBUyxNQUFNO0FBQ2JBLHFCQUFXLElBQUk7QUFDZmMscUJBQVc7QUFBQSxRQUNiO0FBQUE7QUFBQSxNQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFJO0FBQUEsT0FuR1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNHQTtBQUVKO0FBQUN2QixJQXJKUUQsZUFBYTtBQUFBLFVBQ0NwQyxjQUNQQyxVQUNNdkMsZ0JBT0VELFVBUUVBLFVBTUdBLFVBU0pELFdBQVc7QUFBQTtBQUFBLE1BakMzQjRFO0FBdUpULFNBQVM2RCxrQkFBa0I7QUFBQSxFQUN6QjNEO0FBQUFBLEVBQ0FHO0FBQUFBLEVBQ0F1QztBQUFBQSxFQUNBa0I7QUFBQUEsRUFDQUM7QUFPRixHQUFHO0FBQUFDLE1BQUE7QUFDRCxRQUFNN0QsUUFBUXRDLFNBQVM7QUFDdkIsUUFBTSxDQUFDZ0YsTUFBTW9CLE9BQU8sSUFBSS9JLFNBQVMwSCxVQUFVQyxRQUFRLEVBQUU7QUFDckQsUUFBTSxDQUFDRyxjQUFja0IsZUFBZSxJQUFJaEosU0FBUzBILFVBQVVJLGdCQUFnQixFQUFFO0FBQzdFLFFBQU0sQ0FBQ1AsUUFBUTBCLFNBQVMsSUFBSWpKLFNBQVMwSCxVQUFVSCxVQUFVLFdBQVc7QUFDcEUsUUFBTSxDQUFDTSxPQUFPcUIsUUFBUSxJQUFJbEosU0FBUzBILFVBQVVHLFNBQVMsT0FBT3NCLE9BQU96QixTQUFTRyxLQUFLLElBQUksRUFBRTtBQUV4RixRQUFNdUIsZUFBZWxKLFlBQVk7QUFBQSxJQUMvQnVHLFlBQVksWUFBWTtBQUN0QixVQUFJaUIsVUFBVUUsSUFBSTtBQUNoQixjQUFNekcsa0JBQWtCNkQsVUFBVUcsV0FBV3VDLFNBQVNFLElBQUk7QUFBQSxVQUN4REQsTUFBTUEsS0FBSzBCLEtBQUssS0FBS0M7QUFBQUEsVUFDckJ4QixjQUFjQSxhQUFhdUIsS0FBSyxLQUFLQztBQUFBQSxVQUNyQy9CLFFBQVFBLFVBQVUrQjtBQUFBQSxVQUNsQnpCLE9BQU9BLE1BQU13QixLQUFLLElBQUlFLE9BQU8xQixLQUFLLElBQUl5QjtBQUFBQSxRQUN4QyxDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0wsY0FBTTdJLG9CQUFvQnVFLFVBQVVHLFdBQVd3QyxLQUFLMEIsS0FBSyxDQUFDO0FBQUEsTUFDNUQ7QUFBQSxJQUNGO0FBQUEsSUFDQTFDLFdBQVdBLE1BQU07QUFDZjFCLFlBQU0yQixRQUFRYyxXQUFXLG1DQUFtQyw0QkFBNEI7QUFDeEZtQixjQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0FoQyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0sc0NBQXNDO0FBQUEsRUFDbkUsQ0FBQztBQUVELFNBQ0UsdUJBQUMsU0FBTSxTQUFrQixPQUFPWSxXQUFXLHFCQUFxQixrQkFDOUQsaUNBQUMsU0FBSSxPQUFPLEVBQUV0RCxTQUFTLFFBQVFDLEtBQUssSUFBSW1GLFVBQVUsSUFBSSxHQUNwRDtBQUFBLDJCQUFDLGFBQVUsT0FBTSxRQUFPLE9BQU83QixNQUFNLFVBQVUsQ0FBQ1QsTUFBTTZCLFFBQVE3QixFQUFFQyxPQUFPQyxLQUFLLEdBQUcsV0FBUyxRQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdGO0FBQUEsSUFDdkZNLFlBQ0MsbUNBQ0U7QUFBQSw2QkFBQyxhQUFVLE9BQU0sNkJBQTRCLE9BQU9JLGNBQWMsVUFBVSxDQUFDWixNQUFNOEIsZ0JBQWdCOUIsRUFBRUMsT0FBT0MsS0FBSyxLQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1IO0FBQUEsTUFDbkgsdUJBQUMsZUFBWSxPQUFNLFVBQVMsT0FBT0csUUFBUSxVQUFVLENBQUNMLE1BQU0rQixVQUFVL0IsRUFBRUMsT0FBT0MsS0FBSyxHQUNsRjtBQUFBLCtCQUFDLFlBQU8sT0FBTSxhQUFZLDBCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFDcEMsdUJBQUMsWUFBTyxPQUFNLGVBQWMsNEJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxXQUYxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLGFBQVUsT0FBTSxxQkFBb0IsV0FBVSxXQUFVLE9BQU9TLE9BQU8sVUFBVSxDQUFDWCxNQUFNZ0MsU0FBU2hDLEVBQUVDLE9BQU9DLEtBQUssS0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSDtBQUFBLFNBTm5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUYsdUJBQUMsU0FBSSxPQUFPLEVBQUVoRCxTQUFTLFFBQVFDLEtBQUssSUFBSTRDLGdCQUFnQixXQUFXLEdBQ2pFO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUzJCLFNBQVMsc0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxTQUFRLFdBQVUsVUFBVSxDQUFDakIsS0FBSzBCLEtBQUssR0FBRyxTQUFTRCxhQUFhckIsV0FBVyxTQUFTLE1BQU1xQixhQUFhcEIsT0FBTyxHQUFHLHNCQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQkEsS0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCQTtBQUVKO0FBSUFjLElBcEVTSCxtQkFBaUI7QUFBQSxVQWFWaEcsVUFNT3pDLFdBQVc7QUFBQTtBQUFBLE1BbkJ6QnlJO0FBc0VULFNBQVNjLGNBQWM7QUFBQUMsTUFBQTtBQUNyQixRQUFNLEVBQUUxRSxTQUFTLElBQUl0QyxhQUFhO0FBQ2xDLFFBQU11QyxRQUFRdEMsU0FBUztBQUN2QixRQUFNdUMsY0FBYzlFLGVBQWU7QUFDbkMsUUFBTSxDQUFDaUYsVUFBVUMsV0FBVyxJQUFJdEYsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQ3VGLFNBQVNDLFVBQVUsSUFBSXhGLFNBQXNDLElBQUk7QUFDeEUsUUFBTSxDQUFDMkosb0JBQW9CQyxxQkFBcUIsSUFBSTVKLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUM2Six1QkFBdUJDLHdCQUF3QixJQUFJOUosU0FBUyxFQUFFO0FBQ3JFLFFBQU0sQ0FBQytKLFVBQVVDLFdBQVcsSUFBSWhLLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNpSyxpQkFBaUJDLGtCQUFrQixJQUFJbEssU0FBc0MsSUFBSTtBQUN4RixRQUFNLENBQUNtSyxnQkFBZ0JDLGlCQUFpQixJQUFJcEssU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3FLLGtCQUFrQkMsbUJBQW1CLElBQUl0SyxTQUFTLFdBQVc7QUFDcEUsUUFBTSxDQUFDdUssZUFBZUMsZ0JBQWdCLElBQUl4SyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDeUssaUJBQWlCQyxrQkFBa0IsSUFBSTFLLFNBQVMsRUFBRTtBQUV6RCxRQUFNMkssZ0JBQWdCeEssU0FBUztBQUFBLElBQzdCMkYsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFdBQVcsWUFBWWQsUUFBUTtBQUFBLElBQ25FZSxTQUFTQSxNQUFNakUsa0JBQWtCa0QsUUFBUTtBQUFBLEVBQzNDLENBQUM7QUFFRCxRQUFNNEYsc0JBQXNCekssU0FBUztBQUFBLElBQ25DMkYsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFdBQVcsNkJBQTZCZCxVQUFVNkUscUJBQXFCO0FBQUEsSUFDM0c5RCxTQUFTQSxNQUFNaEUsZ0NBQWdDaUQsVUFBVTZFLHFCQUFxQjtBQUFBLElBQzlFekQsU0FBUyxDQUFDLENBQUN5RDtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNdkQsYUFBYUEsTUFDakIsS0FBS3BCLFlBQVlxQixrQkFBa0IsRUFBRVQsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFdBQVcsVUFBVSxFQUFFLENBQUM7QUFFbkcsUUFBTVUsaUJBQWlCdEcsWUFBWTtBQUFBLElBQ2pDdUcsWUFBWUEsQ0FBQ29FLGNBQXNCN0osbUJBQW1CZ0UsVUFBVTZGLFNBQVM7QUFBQSxJQUN6RWxFLFdBQVdBLE1BQU07QUFDZjFCLFlBQU0yQixRQUFRLDRCQUE0QjtBQUMxQ04saUJBQVc7QUFBQSxJQUNiO0FBQUEsSUFDQU8sU0FBU0EsTUFBTTVCLE1BQU02QixNQUFNLHFDQUFxQztBQUFBLEVBQ2xFLENBQUM7QUFFRCxRQUFNZ0UscUJBQXFCNUssWUFBWTtBQUFBLElBQ3JDdUcsWUFBWUEsTUFBTWhGLG9CQUFvQnVELFVBQVUrRSxTQUFTVixLQUFLLENBQUM7QUFBQSxJQUMvRDFDLFdBQVdBLENBQUNvRSxXQUFXYixtQkFBbUJhLE1BQU07QUFBQSxJQUNoRGxFLFNBQVNBLE1BQU01QixNQUFNNkIsTUFBTSx5QkFBeUI7QUFBQSxFQUN0RCxDQUFDO0FBRUQsUUFBTWtFLHNCQUFzQjlLLFlBQVk7QUFBQSxJQUN0Q3VHLFlBQVlBLE1BQ1ZsRztBQUFBQSxNQUNFeUU7QUFBQUEsTUFDQW1GLGVBQ0djLE1BQU0sR0FBRyxFQUNUekcsSUFBSSxDQUFDb0QsT0FBT0EsR0FBR3lCLEtBQUssQ0FBQyxFQUNyQjZCLE9BQU9DLE9BQU8sRUFDZDNHLElBQUksQ0FBQ3FHLGVBQWUsRUFBRUEsV0FBV3RELFFBQVE4QyxpQkFBaUIsRUFBRTtBQUFBLElBQ2pFO0FBQUEsSUFDRjFELFdBQVdBLE1BQU0xQixNQUFNMkIsUUFBUSxrQ0FBa0M7QUFBQSxJQUNqRUMsU0FBU0EsTUFBTTVCLE1BQU02QixNQUFNLG9DQUFvQztBQUFBLEVBQ2pFLENBQUM7QUFFRCxRQUFNc0UscUJBQXFCbEwsWUFBWTtBQUFBLElBQ3JDdUcsWUFBWUEsTUFDVm5HO0FBQUFBLE1BQ0UwRTtBQUFBQSxNQUNBdUYsY0FDR1UsTUFBTSxHQUFHLEVBQ1R6RyxJQUFJLENBQUNvRCxPQUFPQSxHQUFHeUIsS0FBSyxDQUFDLEVBQ3JCNkIsT0FBT0MsT0FBTyxFQUNkM0csSUFBSSxDQUFDcUcsZUFBZSxFQUFFQSxXQUFXekQsT0FBT21DLE9BQU9rQixlQUFlLEtBQUssRUFBRSxFQUFFO0FBQUEsSUFDNUU7QUFBQSxJQUNGOUQsV0FBV0EsQ0FBQ29FLFdBQVc5RixNQUFNMkIsUUFBUSxvQ0FBb0NtRSxPQUFPTSxXQUFXLGVBQWUsRUFBRTtBQUFBLElBQzVHeEUsU0FBU0EsTUFBTTVCLE1BQU02QixNQUFNLG9DQUFvQztBQUFBLEVBQ2pFLENBQUM7QUFFRCxRQUFNd0UsV0FBV1gsY0FBYzFFLFFBQVE7QUFFdkMsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRTdCLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ3JDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFNEMsZ0JBQWdCLFdBQVcsR0FDMUQsaUNBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNM0IsWUFBWSxJQUFJLEdBQUcsOEJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUNxRixjQUFjbkQsV0FBVyx1QkFBQyxjQUFXLE9BQU9tRCxjQUFjN0QsT0FBTyxNQUFLLGlCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsSUFDbkYsQ0FBQzZELGNBQWN0RCxhQUFhaUUsU0FBUzdELFdBQVcsS0FBSyxDQUFDa0QsY0FBY25ELFdBQ25FLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsYUFBWSxxREFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRztBQUFBLElBR2xHLHVCQUFDLFNBQUksT0FBTyxFQUFFcEQsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDcENpSCxtQkFBUzlHO0FBQUFBLE1BQUksQ0FBQytHLFlBQ2IsdUJBQUMsYUFBeUIsV0FBVSxlQUFjLE9BQU8sRUFBRXpILFNBQVMsR0FBRyxHQUNyRSxpQ0FBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRW1ELGdCQUFnQixpQkFBaUJELFlBQVksVUFBVTNDLEtBQUssR0FBRyxHQUMxRztBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFRCxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFUSxZQUFZLElBQUksR0FBSTBHLGtCQUFRNUQsUUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUNoRCx1QkFBQyxVQUFLLE9BQU8sRUFBRXpELE9BQU8sb0JBQW9CQyxVQUFVLFNBQVMsR0FDMURvSDtBQUFBQSxvQkFBUTNEO0FBQUFBLFlBQ1IyRCxRQUFRekQsZUFBZSxzQkFBc0J5RCxRQUFRekQsWUFBWSxLQUFLO0FBQUEsWUFDdEV5RCxRQUFRQyxNQUFNLFdBQVdELFFBQVFDLEdBQUcsS0FBSztBQUFBLGVBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVwSCxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLGlDQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTLE1BQU1tQixXQUFXK0YsT0FBTyxHQUFHLHNCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsU0FBUy9FLGVBQWV1QjtBQUFBQSxjQUN4QixTQUFTLE1BQU13RCxRQUFRM0QsTUFBTXBCLGVBQWV3QixPQUFPdUQsUUFBUTNELEVBQUU7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUpqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQSxLQXZCWTJELFFBQVEzRCxJQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsSUFDRCxLQTNCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUU5RCxTQUFTLElBQUlNLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ25FO0FBQUEsNkJBQUMsWUFBTyw4QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsTUFDdEIsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVBLEtBQUssSUFBSTJDLFlBQVksV0FBVyxHQUMzRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxrQkFBaUIsT0FBTzJDLG9CQUFvQixVQUFVLENBQUN6QyxNQUFNMEMsc0JBQXNCMUMsRUFBRUMsT0FBT0MsS0FBSyxLQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9IO0FBQUEsUUFDcEgsdUJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUyxNQUFNMEMseUJBQXlCSCxrQkFBa0IsR0FBRyxpQ0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxhQUFVLE9BQU0sY0FBYSxPQUFPSSxVQUFVLFVBQVUsQ0FBQzdDLE1BQU04QyxZQUFZOUMsRUFBRUMsT0FBT0MsS0FBSyxLQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRGO0FBQUEsUUFDNUYsdUJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUzBELG1CQUFtQi9DLFdBQVcsU0FBUyxNQUFNK0MsbUJBQW1COUMsT0FBTyxHQUFHLDZCQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0M0QyxvQkFBb0JwRCxXQUFXLHVCQUFDLGNBQVcsT0FBT29ELG9CQUFvQjlELE9BQU8sTUFBSyxnQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRTtBQUFBLE9BQzdHOEQsb0JBQW9CM0UsUUFBUSxJQUFJekI7QUFBQUEsUUFBSSxDQUFDaUgsTUFDckMsdUJBQUMsU0FBZSxPQUFPLEVBQUV0SCxVQUFVLFVBQVUsR0FDMUNzSDtBQUFBQSxZQUFFOUQ7QUFBQUEsVUFBSztBQUFBLFVBQUk4RCxFQUFFN0Q7QUFBQUEsYUFETjZELEVBQUU3RCxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BQ0Q7QUFBQSxNQUNBcUMsbUJBQ0MsdUJBQUMsU0FBSSxPQUFPLEVBQUU5RixVQUFVLFdBQVcrRCxXQUFXLDJCQUEyQkMsWUFBWSxFQUFFLEdBQ3BGOEI7QUFBQUEsd0JBQWdCdEM7QUFBQUEsUUFBSztBQUFBLFFBQUlzQyxnQkFBZ0JyQztBQUFBQSxXQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUU5RCxTQUFTLElBQUlNLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ25FO0FBQUEsNkJBQUMsWUFBTyxtQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJCO0FBQUEsTUFDM0IsdUJBQUMsVUFBSyxPQUFPLEVBQUVGLFVBQVUsV0FBV0QsT0FBTyxtQkFBbUIsR0FBRywwQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRjtBQUFBLE1BQzNGLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFRyxLQUFLLElBQUkyQyxZQUFZLFdBQVcsR0FDM0U7QUFBQSwrQkFBQyxhQUFVLE9BQU0sZUFBYyxPQUFPbUQsZ0JBQWdCLFVBQVUsQ0FBQ2pELE1BQU1rRCxrQkFBa0JsRCxFQUFFQyxPQUFPQyxLQUFLLEtBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUc7QUFBQSxRQUN6Ryx1QkFBQyxlQUFZLE9BQU0sVUFBUyxPQUFPaUQsa0JBQWtCLFVBQVUsQ0FBQ25ELE1BQU1vRCxvQkFBb0JwRCxFQUFFQyxPQUFPQyxLQUFLLEdBQ3RHO0FBQUEsaUNBQUMsWUFBTyxPQUFNLGFBQVksMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9DO0FBQUEsVUFDcEMsdUJBQUMsWUFBTyxPQUFNLGVBQWMsNEJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsYUFGMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTNEQsb0JBQW9CakQsV0FBVyxTQUFTLE1BQU1pRCxvQkFBb0JoRCxPQUFPLEdBQUcsd0NBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRTNELEtBQUssSUFBSTJDLFlBQVksV0FBVyxHQUMzRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxlQUFjLE9BQU91RCxlQUFlLFVBQVUsQ0FBQ3JELE1BQU1zRCxpQkFBaUJ0RCxFQUFFQyxPQUFPQyxLQUFLLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxRQUN2Ryx1QkFBQyxhQUFVLE9BQU0sY0FBYSxXQUFVLFdBQVUsT0FBT3FELGlCQUFpQixVQUFVLENBQUN2RCxNQUFNd0QsbUJBQW1CeEQsRUFBRUMsT0FBT0MsS0FBSyxLQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThIO0FBQUEsUUFDOUgsdUJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBU2dFLG1CQUFtQnJELFdBQVcsU0FBUyxNQUFNcUQsbUJBQW1CcEQsT0FBTyxHQUFHLHVDQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUVDM0MsWUFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFNBQVMsTUFBTUMsWUFBWSxLQUFLO0FBQUEsUUFDaEMsU0FBUyxNQUFNO0FBQ2JBLHNCQUFZLEtBQUs7QUFDakJnQixxQkFBVztBQUFBLFFBQ2I7QUFBQTtBQUFBLE1BTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUk7QUFBQSxJQUlMZixXQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsU0FBU0E7QUFBQUEsUUFDVCxTQUFTLE1BQU1DLFdBQVcsSUFBSTtBQUFBLFFBQzlCLFNBQVMsTUFBTTtBQUNiQSxxQkFBVyxJQUFJO0FBQ2ZjLHFCQUFXO0FBQUEsUUFDYjtBQUFBO0FBQUEsTUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPSTtBQUFBLE9BNUdSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErR0E7QUFFSjtBQUFDb0QsSUE1TFFELGFBQVc7QUFBQSxVQUNHL0csY0FDUEMsVUFDTXZDLGdCQVlFRCxVQUtNQSxVQVNMRCxhQVNJQSxhQU1DQSxhQWNEQSxXQUFXO0FBQUE7QUFBQSxNQTFEL0J1SjtBQThMVCxTQUFTaUMsaUJBQWlCO0FBQUEsRUFDeEIxRztBQUFBQSxFQUNBdUc7QUFBQUEsRUFDQTNDO0FBQUFBLEVBQ0FDO0FBTUYsR0FBRztBQUFBOEMsTUFBQTtBQUNELFFBQU0xRyxRQUFRdEMsU0FBUztBQUN2QixRQUFNLENBQUNnRixNQUFNb0IsT0FBTyxJQUFJL0ksU0FBU3VMLFNBQVM1RCxRQUFRLEVBQUU7QUFDcEQsUUFBTSxDQUFDaUUsYUFBYUMsY0FBYyxJQUFJN0wsU0FBU3VMLFNBQVNLLGVBQWUsRUFBRTtBQUN6RSxRQUFNLENBQUM5RCxjQUFja0IsZUFBZSxJQUFJaEosU0FBU3VMLFNBQVN6RCxnQkFBZ0IsRUFBRTtBQUM1RSxRQUFNLENBQUMwRCxLQUFLTSxNQUFNLElBQUk5TCxTQUFTdUwsU0FBU0MsT0FBTyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ08sT0FBT0MsUUFBUSxJQUFJaE0sU0FBU3VMLFNBQVNVLGFBQWEsRUFBRTtBQUUzRCxRQUFNN0MsZUFBZWxKLFlBQVk7QUFBQSxJQUMvQnVHLFlBQVlBLE1BQU07QUFDaEIsWUFBTXlGLFVBQVU7QUFBQSxRQUNkdkUsTUFBTUEsS0FBSzBCLEtBQUs7QUFBQSxRQUNoQnVDLGFBQWFBLFlBQVl2QyxLQUFLLEtBQUtDO0FBQUFBLFFBQ25DeEIsY0FBY0EsYUFBYXVCLEtBQUssS0FBS0M7QUFBQUEsUUFDckNrQyxLQUFLQSxJQUFJbkMsS0FBSyxLQUFLQztBQUFBQSxRQUNuQnlDLE9BQU9BLE1BQU0xQyxLQUFLLEtBQUtDO0FBQUFBLE1BQ3pCO0FBQ0EsYUFBT2lDLFNBQVMzRCxLQUFLeEcsaUJBQWlCNEQsVUFBVXVHLFFBQVEzRCxJQUFJc0UsT0FBTyxJQUFJeEwsbUJBQW1Cc0UsVUFBVWtILE9BQU87QUFBQSxJQUM3RztBQUFBLElBQ0F2RixXQUFXQSxNQUFNO0FBQ2YxQixZQUFNMkIsUUFBUTJFLFVBQVUsaUNBQWlDLDBCQUEwQjtBQUNuRjFDLGNBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQWhDLFNBQVNBLE1BQU01QixNQUFNNkIsTUFBTSxvQ0FBb0M7QUFBQSxFQUNqRSxDQUFDO0FBRUQsU0FDRSx1QkFBQyxTQUFNLFNBQWtCLE9BQU95RSxVQUFVLG1CQUFtQixnQkFDM0QsaUNBQUMsU0FBSSxPQUFPLEVBQUVuSCxTQUFTLFFBQVFDLEtBQUssSUFBSW1GLFVBQVUsSUFBSSxHQUNwRDtBQUFBLDJCQUFDLGFBQVUsT0FBTSxRQUFPLE9BQU83QixNQUFNLFVBQVUsQ0FBQ1QsTUFBTTZCLFFBQVE3QixFQUFFQyxPQUFPQyxLQUFLLEdBQUcsV0FBUyxRQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdGO0FBQUEsSUFDeEYsdUJBQUMsYUFBVSxPQUFNLHdCQUF1QixPQUFPd0UsYUFBYSxVQUFVLENBQUMxRSxNQUFNMkUsZUFBZTNFLEVBQUVDLE9BQU9DLEtBQUssS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RztBQUFBLElBQzVHLHVCQUFDLGFBQVUsT0FBTSw2QkFBNEIsT0FBT1UsY0FBYyxVQUFVLENBQUNaLE1BQU04QixnQkFBZ0I5QixFQUFFQyxPQUFPQyxLQUFLLEtBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUg7QUFBQSxJQUNuSCx1QkFBQyxhQUFVLE9BQU0sa0JBQWlCLE9BQU9vRSxLQUFLLFVBQVUsQ0FBQ3RFLE1BQU00RSxPQUFPNUUsRUFBRUMsT0FBT0MsS0FBSyxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNGO0FBQUEsSUFDdEYsdUJBQUMsYUFBVSxPQUFNLDRCQUEyQixPQUFPMkUsT0FBTyxVQUFVLENBQUM3RSxNQUFNOEUsU0FBUzlFLEVBQUVDLE9BQU9DLEtBQUssS0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRztBQUFBLElBQ3BHLHVCQUFDLFVBQUssT0FBTyxFQUFFakQsVUFBVSxVQUFVRCxPQUFPLG1CQUFtQixHQUFHLG9IQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFRSxTQUFTLFFBQVFDLEtBQUssSUFBSTRDLGdCQUFnQixXQUFXLEdBQ2pFO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUzJCLFNBQVMsc0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxTQUFRLFdBQVUsVUFBVSxDQUFDakIsS0FBSzBCLEtBQUssR0FBRyxTQUFTRCxhQUFhckIsV0FBVyxTQUFTLE1BQU1xQixhQUFhcEIsT0FBTyxHQUFHLHNCQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBSUEyRCxJQTlEU0Qsa0JBQWdCO0FBQUEsVUFXVC9JLFVBT096QyxXQUFXO0FBQUE7QUFBQSxNQWxCekJ3TDtBQWdFVCxTQUFTUyxXQUFXO0FBQUFDLE1BQUE7QUFDbEIsUUFBTSxFQUFFcEgsU0FBUyxJQUFJdEMsYUFBYTtBQUNsQyxRQUFNdUMsUUFBUXRDLFNBQVM7QUFDdkIsUUFBTSxDQUFDK0YsUUFBUTJELFNBQVMsSUFBSXJNLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNzTSxpQkFBaUJDLGtCQUFrQixJQUFJdk0sU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ3dNLFlBQVlDLGFBQWEsSUFBSXpNLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM4SCxjQUFja0IsZUFBZSxJQUFJaEosU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQzBHLFlBQVlnRyxhQUFhLElBQUkxTSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNkssV0FBVzhCLFlBQVksSUFBSTNNLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM0TSxpQkFBaUJDLGtCQUFrQixJQUFJN00sU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQzhNLDBCQUEwQkMsMkJBQTJCLElBQUkvTSxTQUFTLEVBQUU7QUFFM0UsUUFBTWdOLFlBQVk3TSxTQUFTO0FBQUEsSUFDekIyRixVQUFVLENBQUMsZ0JBQWdCLFNBQVMsV0FBVyxRQUFRZCxVQUFVc0gsZUFBZTtBQUFBLElBQ2hGdkcsU0FBU0EsTUFBTXZFLGlCQUFpQndELFVBQVVzSCxlQUFlO0FBQUEsSUFDekRsRyxTQUFTLENBQUMsQ0FBQ2tHO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1XLHFCQUFxQjlNLFNBQVM7QUFBQSxJQUNsQzJGLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxXQUFXLGtCQUFrQmQsVUFBVThILHdCQUF3QjtBQUFBLElBQ25HL0csU0FBU0EsTUFBTW5FLHVCQUF1Qm9ELFVBQVU4SCx3QkFBd0I7QUFBQSxJQUN4RTFHLFNBQVMsQ0FBQyxDQUFDMEc7QUFBQUEsRUFDYixDQUFDO0FBRUQsUUFBTUksbUJBQW1CaE4sWUFBWTtBQUFBLElBQ25DdUcsWUFBWUEsTUFBTXZFLGtCQUFrQjhDLFVBQVVzSCxpQkFBaUIvQyxPQUFPaUQsVUFBVSxLQUFLLENBQUM7QUFBQSxJQUN0RjdGLFdBQVdBLE1BQU07QUFDZjFCLFlBQU0yQixRQUFRLG9DQUFvQztBQUNsRCxXQUFLb0csVUFBVUcsUUFBUTtBQUFBLElBQ3pCO0FBQUEsSUFDQXRHLFNBQVNBLE1BQU01QixNQUFNNkIsTUFBTSxxQ0FBcUM7QUFBQSxFQUNsRSxDQUFDO0FBRUQsUUFBTXNHLDBCQUEwQmxOLFlBQVk7QUFBQSxJQUMxQ3VHLFlBQVlBLE1BQU14RSx5QkFBeUIrQyxVQUFVc0gsaUJBQWlCeEUsYUFBYXVCLEtBQUssS0FBS0MsTUFBUztBQUFBLElBQ3RHM0MsV0FBV0EsTUFBTTtBQUNmMUIsWUFBTTJCLFFBQVEsNkNBQTZDO0FBQzNELFdBQUtvRyxVQUFVRyxRQUFRO0FBQUEsSUFDekI7QUFBQSxJQUNBdEcsU0FBU0EsTUFBTTVCLE1BQU02QixNQUFNLDhDQUE4QztBQUFBLEVBQzNFLENBQUM7QUFFRCxRQUFNdUcscUJBQXFCbk4sWUFBWTtBQUFBLElBQ3JDdUcsWUFBWUEsTUFBTTVGLGdCQUFnQm1FLFVBQVUwQixXQUFXMkMsS0FBSyxHQUFHd0IsVUFBVXhCLEtBQUssQ0FBQztBQUFBLElBQy9FMUMsV0FBV0EsTUFBTTFCLE1BQU0yQixRQUFRLHlCQUF5QjtBQUFBLElBQ3hEQyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0sMEJBQTBCO0FBQUEsRUFDdkQsQ0FBQztBQUVELFFBQU1tQixPQUFPK0UsVUFBVS9HO0FBRXZCLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUU3QixTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNyQztBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRVAsU0FBUyxJQUFJTSxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNuRTtBQUFBLDZCQUFDLFlBQU8sZ0RBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QztBQUFBLE1BQ3hDLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFQSxLQUFLLElBQUkyQyxZQUFZLFdBQVcsR0FDM0U7QUFBQSwrQkFBQyxhQUFVLE9BQU0sV0FBVSxPQUFPMEIsUUFBUSxVQUFVLENBQUN4QixNQUFNbUYsVUFBVW5GLEVBQUVDLE9BQU9DLEtBQUssS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFFBQ3JGLHVCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVMsTUFBTW1GLG1CQUFtQjdELE1BQU0sR0FBRyx5QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNDc0UsVUFBVXhGLFdBQVcsdUJBQUMsY0FBVyxPQUFPd0YsVUFBVWxHLE9BQU8sTUFBSyxZQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsTUFDdEVtQixRQUNDLHVCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRW5FLFNBQVMsSUFBSUssVUFBVSxVQUFVbUosV0FBVyxRQUFRQyxZQUFZLFdBQVcsR0FDekdsSyxxQkFBVzRFLEtBQUt1RixVQUFVLEtBQUssR0FBR3ZGLEtBQUtTLE1BQU0sYUFBYVQsS0FBS1YsTUFBTSxZQUFZVSxLQUFLdUUsVUFBVSxNQURuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVERixtQkFDQyx1QkFBQyxTQUFJLE9BQU8sRUFBRWxJLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ3JDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVBLEtBQUssSUFBSTJDLFlBQVksV0FBVyxHQUMzRTtBQUFBLGlDQUFDLGFBQVUsT0FBTSxjQUFhLFdBQVUsV0FBVSxPQUFPd0YsWUFBWSxVQUFVLENBQUN0RixNQUFNdUYsY0FBY3ZGLEVBQUVDLE9BQU9DLEtBQUssS0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0g7QUFBQSxVQUNwSCx1QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTOEYsaUJBQWlCbkYsV0FBVyxTQUFTLE1BQU1tRixpQkFBaUJsRixPQUFPLEdBQUcsK0JBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUUzRCxLQUFLLElBQUkyQyxZQUFZLFdBQVcsR0FDM0U7QUFBQSxpQ0FBQyxhQUFVLE9BQU0sdUJBQXNCLE9BQU9jLGNBQWMsVUFBVSxDQUFDWixNQUFNOEIsZ0JBQWdCOUIsRUFBRUMsT0FBT0MsS0FBSyxLQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RztBQUFBLFVBQzdHLHVCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVNnRyx3QkFBd0JyRixXQUFXLFNBQVMsTUFBTXFGLHdCQUF3QnBGLE9BQU8sR0FBRyx3Q0FBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVsRSxTQUFTLElBQUlNLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ25FO0FBQUEsNkJBQUMsWUFBTyw2Q0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsTUFDckMsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVBLEtBQUssSUFBSTJDLFlBQVksV0FBVyxHQUMzRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxlQUFjLE9BQU9OLFlBQVksVUFBVSxDQUFDUSxNQUFNd0YsY0FBY3hGLEVBQUVDLE9BQU9DLEtBQUssS0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRztBQUFBLFFBQ2pHLHVCQUFDLGFBQVUsT0FBTSxjQUFhLE9BQU95RCxXQUFXLFVBQVUsQ0FBQzNELE1BQU15RixhQUFhekYsRUFBRUMsT0FBT0MsS0FBSyxLQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThGO0FBQUEsUUFDOUY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLFVBQVUsQ0FBQ1YsV0FBVzJDLEtBQUssS0FBSyxDQUFDd0IsVUFBVXhCLEtBQUs7QUFBQSxZQUNoRCxTQUFTZ0UsbUJBQW1CdEY7QUFBQUEsWUFDNUIsU0FBUyxNQUFNc0YsbUJBQW1CckYsT0FBTztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBSjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFbEUsU0FBUyxJQUFJTSxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNuRTtBQUFBLDZCQUFDLFlBQU8sc0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QjtBQUFBLE1BQzlCLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFQSxLQUFLLElBQUkyQyxZQUFZLFdBQVcsR0FDM0U7QUFBQSwrQkFBQyxhQUFVLE9BQU0sZUFBYyxPQUFPNEYsaUJBQWlCLFVBQVUsQ0FBQzFGLE1BQU0yRixtQkFBbUIzRixFQUFFQyxPQUFPQyxLQUFLLEtBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkc7QUFBQSxRQUMzRyx1QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTLE1BQU0yRiw0QkFBNEJILGVBQWUsR0FBRyx5QkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNDSyxtQkFBbUJ6RixXQUFXLHVCQUFDLGNBQVcsT0FBT3lGLG1CQUFtQm5HLE9BQU8sTUFBSywyQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLE1BQ3ZHbUcsbUJBQW1CaEgsTUFBTXVILGNBQ3hCLHVCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRTFKLFNBQVMsSUFBSUssVUFBVSxVQUFVbUosV0FBVyxRQUFRQyxZQUFZLFdBQVcsR0FDekdsSyxxQkFBVzRKLG1CQUFtQmhILEtBQUt1SCxVQUFVLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsT0EvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdFQTtBQUVKO0FBSUFwQixJQXpIU0QsVUFBUTtBQUFBLFVBQ016SixjQUNQQyxVQVVJeEMsVUFNU0EsVUFNRkQsYUFTT0EsYUFTTEEsV0FBVztBQUFBO0FBQUEsTUExQy9CaU07QUEySFQsU0FBU3NCLGtCQUFrQjtBQUFBQyxNQUFBO0FBQ3pCLFFBQU0sRUFBRTFJLFNBQVMsSUFBSXRDLGFBQWE7QUFDbEMsUUFBTXVDLFFBQVF0QyxTQUFTO0FBQ3ZCLFFBQU11QyxjQUFjOUUsZUFBZTtBQUNuQyxRQUFNLENBQUNtRixTQUFTQyxVQUFVLElBQUl4RixTQUEwQyxJQUFJO0FBQzVFLFFBQU0sQ0FBQzJOLFVBQVVDLFdBQVcsSUFBSTVOLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUM2TixhQUFhQyxjQUFjLElBQUk5TixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDK04sb0JBQW9CQyxxQkFBcUIsSUFBSWhPLFNBQVMsRUFBRTtBQUUvRCxRQUFNaU8sY0FBYzlOLFNBQVM7QUFBQSxJQUMzQjJGLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxXQUFXLGlCQUFpQmQsUUFBUTtBQUFBLElBQ3hFZSxTQUFTQSxNQUFNbEUsc0JBQXNCbUQsVUFBVSxJQUFJO0FBQUEsRUFDckQsQ0FBQztBQUVELFFBQU1zQixhQUFhQSxNQUNqQixLQUFLcEIsWUFBWXFCLGtCQUFrQixFQUFFVCxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsV0FBVyxlQUFlLEVBQUUsQ0FBQztBQUV4RyxRQUFNb0ksc0JBQXNCaE8sWUFBWTtBQUFBLElBQ3RDdUcsWUFBWUEsQ0FBQ21CLE9BQWU3Ryx1QkFBdUJpRSxVQUFVNEMsRUFBRTtBQUFBLElBQy9EakIsV0FBV0EsTUFBTTtBQUNmMUIsWUFBTTJCLFFBQVEsb0NBQW9DO0FBQ2xETixpQkFBVztBQUFBLElBQ2I7QUFBQSxJQUNBTyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0scUNBQXFDO0FBQUEsRUFDbEUsQ0FBQztBQUVELFFBQU1xSCx1QkFBdUJqTyxZQUFZO0FBQUEsSUFDdkN1RyxZQUFZQSxDQUFDLEVBQUVtQixJQUFJd0csVUFBOEMsTUFBTTdMLDZCQUE2QnlDLFVBQVU0QyxJQUFJd0csU0FBUztBQUFBLElBQzNIekgsV0FBV0EsTUFBTTtBQUNmMUIsWUFBTTJCLFFBQVEsc0NBQXNDO0FBQ3BETixpQkFBVztBQUFBLElBQ2I7QUFBQSxJQUNBTyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0sdUNBQXVDO0FBQUEsRUFDcEUsQ0FBQztBQUVELFFBQU11SCx5QkFBeUJuTyxZQUFZO0FBQUEsSUFDekN1RyxZQUFZQSxNQUFNckUsb0JBQW9CNEMsVUFBVTJJLFNBQVN0RSxLQUFLLEdBQUdFLE9BQU9zRSxXQUFXLEtBQUssQ0FBQztBQUFBLElBQ3pGbEgsV0FBV0EsTUFBTTFCLE1BQU0yQixRQUFRLHFDQUFxQztBQUFBLElBQ3BFQyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0sc0NBQXNDO0FBQUEsRUFDbkUsQ0FBQztBQUVELFFBQU13SCxnQ0FBZ0NwTyxZQUFZO0FBQUEsSUFDaER1RyxZQUFZQSxNQUFNdEUsMkJBQTJCNkMsVUFBVTJJLFNBQVN0RSxLQUFLLEdBQUcwRSxtQkFBbUIxRSxLQUFLLENBQUM7QUFBQSxJQUNqRzFDLFdBQVdBLE1BQU0xQixNQUFNMkIsUUFBUSw4Q0FBOEM7QUFBQSxJQUM3RUMsU0FBU0EsTUFBTTVCLE1BQU02QixNQUFNLCtDQUErQztBQUFBLEVBQzVFLENBQUM7QUFFRCxRQUFNeUgsNkJBQTZCck8sWUFBWTtBQUFBLElBQzdDdUcsWUFBWUEsQ0FBQzJILGNBQXVCL0wscUJBQXFCMkMsVUFBVTJJLFNBQVN0RSxLQUFLLEdBQUcrRSxTQUFTO0FBQUEsSUFDN0Z6SCxXQUFXQSxNQUFNMUIsTUFBTTJCLFFBQVEsc0NBQXNDO0FBQUEsSUFDckVDLFNBQVNBLE1BQU01QixNQUFNNkIsTUFBTSx1Q0FBdUM7QUFBQSxFQUNwRSxDQUFDO0FBRUQsUUFBTTBILHVCQUF1QnRPLFlBQVk7QUFBQSxJQUN2Q3VHLFlBQVlBLE1BQU0zRixrQkFBa0JrRSxVQUFVTyxTQUFTcUMsTUFBTSxJQUFJK0YsU0FBU3RFLEtBQUssQ0FBQztBQUFBLElBQ2hGMUMsV0FBV0EsTUFBTTFCLE1BQU0yQixRQUFRLDBCQUEwQjtBQUFBLElBQ3pEQyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0sMkJBQTJCO0FBQUEsRUFDeEQsQ0FBQztBQUVELFFBQU0ySCx1QkFBdUJ2TyxZQUFZO0FBQUEsSUFDdkN1RyxZQUFZQSxDQUFDLEVBQUVoQixTQUFTb0YsVUFBa0QsTUFDeEU1Siw2QkFBNkIrRCxVQUFVUyxTQUFTb0YsU0FBUztBQUFBLElBQzNEbEUsV0FBV0EsTUFBTTFCLE1BQU0yQixRQUFRLHlDQUF5QztBQUFBLElBQ3hFQyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0sMENBQTBDO0FBQUEsRUFDdkUsQ0FBQztBQUVELFFBQU00SCxzQkFBc0J4TyxZQUFZO0FBQUEsSUFDdEN1RyxZQUFZQSxDQUFDa0IsU0FBaUJyRix1QkFBdUIwQyxVQUFVTyxTQUFTcUMsTUFBTSxJQUFJRCxJQUFJO0FBQUEsSUFDdEZoQixXQUFXQSxNQUFNO0FBQ2YxQixZQUFNMkIsUUFBUSxvQ0FBb0M7QUFDbEROLGlCQUFXO0FBQUEsSUFDYjtBQUFBLElBQ0FPLFNBQVNBLE1BQU01QixNQUFNNkIsTUFBTSw0QkFBNEI7QUFBQSxFQUN6RCxDQUFDO0FBRUQsUUFBTSxDQUFDNkgsdUJBQXVCQyx3QkFBd0IsSUFBSTVPLFNBQVMsRUFBRTtBQUNyRSxRQUFNLENBQUM2TyxhQUFhQyxjQUFjLElBQUk5TyxTQUFTLEVBQUU7QUFFakQsUUFBTStPLFNBQVNkLFlBQVloSSxRQUFRO0FBRW5DLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUU3QixTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNwQzRKO0FBQUFBLGdCQUFZekcsV0FBVyx1QkFBQyxjQUFXLE9BQU95RyxZQUFZbkgsT0FBTyxNQUFLLHlCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdFO0FBQUEsSUFDdkYsQ0FBQ21ILFlBQVk1RyxhQUFhMEgsT0FBT3RILFdBQVcsS0FBSyxDQUFDd0csWUFBWXpHLFdBQzdELHVCQUFDLGNBQVcsT0FBTSwwQkFBeUIsYUFBWSx1REFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRztBQUFBLElBRzVHLHVCQUFDLFNBQUksT0FBTyxFQUFFcEQsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDcEMwSyxpQkFBT3ZLO0FBQUFBLE1BQUksQ0FBQ3dLLFVBQ1gsdUJBQUMsYUFBdUIsV0FBVSxlQUFjLE9BQU8sRUFBRWxMLFNBQVMsR0FBRyxHQUNuRSxpQ0FBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRW1ELGdCQUFnQixpQkFBaUJELFlBQVksVUFBVTNDLEtBQUssR0FBRyxHQUMxRztBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFRCxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFUSxZQUFZLElBQUksR0FBSW1LLGdCQUFNckgsUUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5Qyx1QkFBQyxVQUFLLE9BQU8sRUFBRXpELE9BQU8sb0JBQW9CQyxVQUFVLFNBQVMsR0FDMUQ2SztBQUFBQSxrQkFBTXBIO0FBQUFBLFlBQUc7QUFBQSxZQUFZb0gsTUFBTXpILFVBQVU7QUFBQSxlQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFbkQsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNO0FBQ2JtQiwyQkFBV3dKLEtBQUs7QUFDaEJGLCtCQUFlRSxNQUFNckgsUUFBUSxFQUFFO0FBQUEsY0FDakM7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsU0FBU3dHLHFCQUFxQnBHO0FBQUFBLGNBQzlCLFNBQVMsTUFBTWlILE1BQU1wSCxNQUFNdUcscUJBQXFCbkcsT0FBTyxFQUFFSixJQUFJb0gsTUFBTXBILElBQUl3RyxXQUFXWSxNQUFNekgsV0FBVyxZQUFZLENBQUM7QUFBQSxjQUUvR3lILGdCQUFNekgsV0FBVyxjQUFjLFdBQVc7QUFBQTtBQUFBLFlBTjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsU0FBUzJHLG9CQUFvQm5HO0FBQUFBLGNBQzdCLFNBQVMsTUFBTWlILE1BQU1wSCxNQUFNc0csb0JBQW9CbEcsT0FBT2dILE1BQU1wSCxFQUFFO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFKbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsV0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1DQSxLQXBDWW9ILE1BQU1wSCxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUNBO0FBQUEsSUFDRCxLQXhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUNBO0FBQUEsSUFFQ3JDLFdBQ0MsdUJBQUMsU0FBTSxTQUFTLE1BQU1DLFdBQVcsSUFBSSxHQUFHLE9BQU8sY0FBY0QsUUFBUW9DLElBQUksS0FDdkUsaUNBQUMsU0FBSSxPQUFPLEVBQUV2RCxTQUFTLFFBQVFDLEtBQUssSUFBSW1GLFVBQVUsSUFBSSxHQUNwRDtBQUFBLDZCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFbkYsS0FBSyxJQUFJMkMsWUFBWSxXQUFXLEdBQzNFO0FBQUEsK0JBQUMsYUFBVSxPQUFNLGlCQUFnQixPQUFPNkgsYUFBYSxVQUFVLENBQUMzSCxNQUFNNEgsZUFBZTVILEVBQUVDLE9BQU9DLEtBQUssR0FBRyxXQUFTLFFBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0c7QUFBQSxRQUMvRztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsVUFBVSxDQUFDeUgsWUFBWXhGLEtBQUssS0FBS3dGLFlBQVl4RixLQUFLLE1BQU05RCxRQUFRb0M7QUFBQUEsWUFDaEUsU0FBUytHLG9CQUFvQjNHO0FBQUFBLFlBQzdCLFNBQVMsTUFBTTJHLG9CQUFvQjFHLE9BQU82RyxZQUFZeEYsS0FBSyxDQUFDO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFKaEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BRUEsdUJBQUMsUUFBRyxPQUFPLEVBQUUzRSxRQUFRLFFBQVF3RCxXQUFXLDJCQUEyQmxFLFFBQVEsUUFBUSxLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGO0FBQUEsTUFFckYsdUJBQUMsYUFBVSxPQUFNLGFBQVksT0FBTzJKLFVBQVUsVUFBVSxDQUFDekcsTUFBTTBHLFlBQVkxRyxFQUFFQyxPQUFPQyxLQUFLLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkY7QUFBQSxNQUMzRix1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRS9DLEtBQUssSUFBSTJDLFlBQVksV0FBVyxHQUMzRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxjQUFhLFdBQVUsV0FBVSxPQUFPNkcsYUFBYSxVQUFVLENBQUMzRyxNQUFNNEcsZUFBZTVHLEVBQUVDLE9BQU9DLEtBQUssS0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSDtBQUFBLFFBQ3RIO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixVQUFVLENBQUN1RyxTQUFTdEUsS0FBSztBQUFBLFlBQ3pCLFNBQVNnRix1QkFBdUJ0RztBQUFBQSxZQUNoQyxTQUFTLE1BQU1zRyx1QkFBdUJyRyxPQUFPO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUUzRCxLQUFLLElBQUkyQyxZQUFZLFdBQVcsR0FDM0U7QUFBQSwrQkFBQyxhQUFVLE9BQU0sdUJBQXNCLE9BQU8rRyxvQkFBb0IsVUFBVSxDQUFDN0csTUFBTThHLHNCQUFzQjlHLEVBQUVDLE9BQU9DLEtBQUssS0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5SDtBQUFBLFFBQ3pIO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixVQUFVLENBQUN1RyxTQUFTdEUsS0FBSyxLQUFLLENBQUMwRSxtQkFBbUIxRSxLQUFLO0FBQUEsWUFDdkQsU0FBU2lGLDhCQUE4QnZHO0FBQUFBLFlBQ3ZDLFNBQVMsTUFBTXVHLDhCQUE4QnRHLE9BQU87QUFBQSxZQUFFO0FBQUE7QUFBQSxVQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRTNELEtBQUssR0FBRyxHQUNuRDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixVQUFVLENBQUNzSixTQUFTdEUsS0FBSztBQUFBLFlBQ3pCLFNBQVNrRiwyQkFBMkJ4RztBQUFBQSxZQUNwQyxTQUFTLE1BQU13RywyQkFBMkJ2RyxPQUFPLElBQUk7QUFBQSxZQUFFO0FBQUE7QUFBQSxVQUp6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLFVBQVUsQ0FBQzJGLFNBQVN0RSxLQUFLO0FBQUEsWUFDekIsU0FBU2tGLDJCQUEyQnhHO0FBQUFBLFlBQ3BDLFNBQVMsTUFBTXdHLDJCQUEyQnZHLE9BQU8sS0FBSztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBSjFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsVUFBVSxDQUFDMkYsU0FBU3RFLEtBQUs7QUFBQSxZQUN6QixTQUFTbUYscUJBQXFCekc7QUFBQUEsWUFDOUIsU0FBUyxNQUFNeUcscUJBQXFCeEcsT0FBTztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLE1BRUEsdUJBQUMsUUFBRyxPQUFPLEVBQUV0RCxRQUFRLFFBQVF3RCxXQUFXLDJCQUEyQmxFLFFBQVEsUUFBUSxLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGO0FBQUEsTUFFckYsdUJBQUMsWUFBTyxPQUFPLEVBQUVHLFVBQVUsU0FBUyxHQUFHLG9EQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsTUFDM0UsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVFLEtBQUssSUFBSTJDLFlBQVksV0FBVyxHQUMzRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxjQUFhLE9BQU8ySCx1QkFBdUIsVUFBVSxDQUFDekgsTUFBTTBILHlCQUF5QjFILEVBQUVDLE9BQU9DLEtBQUssS0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSDtBQUFBLFFBQ3RIO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixVQUFVLENBQUN1SCxzQkFBc0J0RixLQUFLO0FBQUEsWUFDdEMsU0FBU29GLHFCQUFxQjFHO0FBQUFBLFlBQzlCLFNBQVMsTUFDUHhDLFFBQVFxQyxNQUFNNkcscUJBQXFCekcsT0FBTyxFQUFFdkMsU0FBU0YsUUFBUXFDLElBQUlpRCxXQUFXOEQsc0JBQXNCdEYsS0FBSyxFQUFFLENBQUM7QUFBQSxZQUMzRztBQUFBO0FBQUEsVUFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWpGLFNBQVMsUUFBUTZDLGdCQUFnQixZQUFZZ0ksV0FBVyxFQUFFLEdBQ3RFLGlDQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVMsTUFBTXpKLFdBQVcsSUFBSSxHQUFHLHNCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQXRGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUZBLEtBeEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5RkE7QUFBQSxPQTNJSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNklBO0FBRUo7QUFJQWtJLElBcE9TRCxpQkFBZTtBQUFBLFVBQ0QvSyxjQUNQQyxVQUNNdkMsZ0JBTUFELFVBUVFELGFBU0NBLGFBU0VBLGFBTU9BLGFBTUhBLGFBTU5BLGFBTUFBLGFBT0RBLFdBQVc7QUFBQTtBQUFBLE1BbEVoQ3VOO0FBc09ULFNBQVN5QixXQUFXO0FBQUFDLE1BQUE7QUFDbEIsUUFBTSxFQUFFbkssU0FBUyxJQUFJdEMsYUFBYTtBQUNsQyxRQUFNdUMsUUFBUXRDLFNBQVM7QUFDdkIsUUFBTSxDQUFDeU0sb0JBQW9CQyxxQkFBcUIsSUFBSXJQLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUNzUCxzQkFBc0JDLHVCQUF1QixJQUFJdlAsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ3dQLGdCQUFnQkMsaUJBQWlCLElBQUl6UCxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDMFAsZUFBZUMsZ0JBQWdCLElBQUkzUCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDNFAsd0JBQXdCQyx5QkFBeUIsSUFBSTdQLFNBQVMsRUFBRTtBQUN2RSxRQUFNLENBQUM4UCxlQUFlQyxnQkFBZ0IsSUFBSS9QLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNnUSxtQkFBbUJDLG9CQUFvQixJQUFJalEsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ2tRLHFCQUFxQkMsc0JBQXNCLElBQUluUSxTQUFTLEtBQUs7QUFFcEUsUUFBTW9RLGVBQWVqUSxTQUFTO0FBQUEsSUFDNUIyRixVQUFVLENBQUMsZ0JBQWdCLFNBQVMsV0FBVyxXQUFXZCxRQUFRO0FBQUEsSUFDbEVlLFNBQVNBLE1BQU12Rix5QkFBeUJ3RSxRQUFRO0FBQUEsRUFDbEQsQ0FBQztBQUVELFFBQU1xTCxpQkFBaUJsUSxTQUFTO0FBQUEsSUFDOUIyRixVQUFVLENBQUMsZ0JBQWdCLFNBQVMsV0FBVyxhQUFhZCxVQUFVc0ssb0JBQW9CO0FBQUEsSUFDMUZ2SixTQUFTQSxNQUFNeEUsa0JBQWtCeUQsVUFBVXNLLG9CQUFvQjtBQUFBLElBQy9EbEosU0FBUyxDQUFDLENBQUNrSjtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNZ0IsbUJBQW1CblEsU0FBUztBQUFBLElBQ2hDMkYsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFdBQVcsZ0JBQWdCZCxVQUFVNEssc0JBQXNCO0FBQUEsSUFDL0Y3SixTQUFTQSxNQUFNMUUsb0JBQW9CMkQsVUFBVTRLLHNCQUFzQjtBQUFBLElBQ25FeEosU0FBUyxDQUFDLENBQUN3SjtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNVywrQkFBK0JyUSxZQUFZO0FBQUEsSUFDL0N1RyxZQUFZQSxNQUNWN0Y7QUFBQUEsTUFDRW9FO0FBQUFBLE1BQ0F3SyxlQUFldkUsTUFBTSxHQUFHLEVBQUV6RyxJQUFJLENBQUNvRCxPQUFPQSxHQUFHeUIsS0FBSyxDQUFDLEVBQUU2QixPQUFPQyxPQUFPO0FBQUEsSUFDakU7QUFBQSxJQUNGeEUsV0FBV0EsTUFBTTFCLE1BQU0yQixRQUFRLG9DQUFvQztBQUFBLElBQ25FQyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0sbUNBQW1DO0FBQUEsRUFDaEUsQ0FBQztBQUVELFFBQU0wSixrQkFBa0J0USxZQUFZO0FBQUEsSUFDbEN1RyxZQUFZQSxNQUFNaEUsMkJBQTJCdUMsUUFBUTtBQUFBLElBQ3JEMkIsV0FBV0EsTUFBTTtBQUNmMUIsWUFBTTJCLFFBQVEsb0NBQW9DO0FBQ2xEcUosMkJBQXFCLEtBQUs7QUFDMUIsV0FBS0csYUFBYWpELFFBQVE7QUFBQSxJQUM1QjtBQUFBLElBQ0F0RyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0scUNBQXFDO0FBQUEsRUFDbEUsQ0FBQztBQUVELFFBQU0ySixvQkFBb0J2USxZQUFZO0FBQUEsSUFDcEN1RyxZQUFZQSxNQUFNdkYsNkJBQTZCOEQsUUFBUTtBQUFBLElBQ3ZEMkIsV0FBV0EsTUFBTTtBQUNmMUIsWUFBTTJCLFFBQVEsc0NBQXNDO0FBQ3BEdUosNkJBQXVCLEtBQUs7QUFDNUIsV0FBS0MsYUFBYWpELFFBQVE7QUFBQSxJQUM1QjtBQUFBLElBQ0F0RyxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0sdUNBQXVDO0FBQUEsRUFDcEUsQ0FBQztBQUVELFFBQU00SixzQkFBc0J4USxZQUFZO0FBQUEsSUFDdEN1RyxZQUFZQSxNQUFNakUsaUJBQWlCd0MsVUFBVThLLGFBQWE7QUFBQSxJQUMxRG5KLFdBQVdBLENBQUNvRSxXQUFXOUYsTUFBTTJCLFFBQVEsNkJBQTZCdkQsV0FBVzBILE9BQU95QyxVQUFVLEVBQUVtRCxNQUFNLEdBQUcsR0FBRyxLQUFLLFNBQVMsRUFBRTtBQUFBLElBQzVIOUosU0FBU0EsTUFBTTVCLE1BQU02QixNQUFNLDRDQUE0QztBQUFBLEVBQ3pFLENBQUM7QUFFRCxRQUFNOEosWUFBWVAsZUFBZXBLO0FBRWpDLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUU3QixTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNyQztBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRVAsU0FBUyxJQUFJTSxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNuRTtBQUFBLDZCQUFDLFlBQU8sa0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQjtBQUFBLE1BQ3pCK0wsYUFBYTVJLFdBQVcsdUJBQUMsY0FBVyxPQUFPNEksYUFBYXRKLE9BQU8sTUFBSywwQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLE1BQzNGLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFFBQWVzSixhQUFhbkssTUFBTTRLLFdBQVc7QUFBQSxXQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVEO0FBQUEsTUFDdkQsdUJBQUMsVUFBSyxPQUFPLEVBQUUxTSxVQUFVLFVBQVVELE9BQU8sbUJBQW1CLEdBQUcsa0pBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVHLEtBQUssR0FBRyxHQUNuRDtBQUFBLCtCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVMsTUFBTTRMLHFCQUFxQixJQUFJLEdBQUcsd0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUyxNQUFNRSx1QkFBdUIsSUFBSSxHQUFHLDRDQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFck0sU0FBUyxJQUFJTSxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNuRTtBQUFBLDZCQUFDLFlBQU8sdUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDZix1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUEsS0FBSyxJQUFJMkMsWUFBWSxXQUFXLEdBQzNFO0FBQUEsK0JBQUMsYUFBVSxPQUFNLGNBQWEsT0FBT29JLG9CQUFvQixVQUFVLENBQUNsSSxNQUFNbUksc0JBQXNCbkksRUFBRUMsT0FBT0MsS0FBSyxLQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdIO0FBQUEsUUFDaEgsdUJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUyxNQUFNbUksd0JBQXdCSCxrQkFBa0IsR0FBRyx5QkFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNDaUIsZUFBZTdJLFdBQVcsdUJBQUMsY0FBVyxPQUFPNkksZUFBZXZKLE9BQU8sTUFBSyxlQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlEO0FBQUEsTUFDbkY4SixhQUNDLHVCQUFDLFVBQUssT0FBTyxFQUFFek0sVUFBVSxVQUFVLEdBQUc7QUFBQTtBQUFBLFFBQ3ZCeU0sVUFBVUUsVUFBVTtBQUFBLFFBQUk7QUFBQSxRQUFnQkYsVUFBVUcsVUFBVSxRQUFRO0FBQUEsV0FEbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRix1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRTFNLEtBQUssSUFBSTJDLFlBQVksV0FBVyxHQUMzRTtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPd0k7QUFBQUEsWUFDUCxVQUFVLENBQUN0SSxNQUFNdUksa0JBQWtCdkksRUFBRUMsT0FBT0MsS0FBSztBQUFBO0FBQUEsVUFIbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3FEO0FBQUEsUUFFckQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLFVBQVUsQ0FBQ29JLGVBQWVuRyxLQUFLO0FBQUEsWUFDL0IsU0FBU2tILDZCQUE2QnhJO0FBQUFBLFlBQ3RDLFNBQVMsTUFBTXdJLDZCQUE2QnZJLE9BQU87QUFBQSxZQUFFO0FBQUE7QUFBQSxVQUp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsU0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFbEUsU0FBUyxJQUFJTSxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNuRTtBQUFBLDZCQUFDLFlBQU8sa0RBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQztBQUFBLE1BQzFDLHVCQUFDLFVBQUssT0FBTyxFQUFFRixVQUFVLFdBQVdELE9BQU8sbUJBQW1CLEdBQUcsNkZBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVHLEtBQUssSUFBSTJDLFlBQVksV0FBVyxHQUMzRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxZQUFXLE9BQU8wSSxlQUFlLFVBQVUsQ0FBQ3hJLE1BQU15SSxpQkFBaUJ6SSxFQUFFQyxPQUFPQyxLQUFLLEtBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0c7QUFBQSxRQUNwRyx1QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTLE1BQU15SSwwQkFBMEJILGFBQWEsR0FBRyx5QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNDWSxpQkFBaUI5SSxXQUFXLHVCQUFDLGNBQVcsT0FBTzhJLGlCQUFpQnhKLE9BQU8sTUFBSyx5QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLE1BQ2pHd0osaUJBQWlCckssUUFDaEIsdUJBQUMsU0FBSSxPQUFPLEVBQUU3QixTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLCtCQUFDLFVBQUs7QUFBQTtBQUFBLFVBQVNpTSxpQkFBaUJySyxLQUFLK0ssZUFBZTtBQUFBLGFBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Q7QUFBQSxRQUN2RFYsaUJBQWlCckssS0FBS2dMLFFBQVF6TTtBQUFBQSxVQUFJLENBQUMwTSxHQUFHQyxRQUNyQyx1QkFBQyxVQUFlLE9BQU8sRUFBRWhOLFVBQVUsVUFBVUQsT0FBTyxtQkFBbUIsR0FDcEVnTjtBQUFBQSxjQUFFRTtBQUFBQSxZQUFXO0FBQUEsWUFBR0YsRUFBRW5HO0FBQUFBLFlBQU87QUFBQSxZQUFFbUcsRUFBRUcsZ0JBQWdCLElBQUlILEVBQUVHLGFBQWEsTUFBTTtBQUFBLGVBRDlERixLQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUNEO0FBQUEsV0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVyTixTQUFTLElBQUlNLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ25FO0FBQUEsNkJBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsTUFDeEIsdUJBQUMsVUFBSyxPQUFPLEVBQUVGLFVBQVUsVUFBVUQsT0FBTyxtQkFBbUIsR0FBRyxxSkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTzRMO0FBQUFBLFVBQ1AsVUFBVSxDQUFDNUksTUFBTTZJLGlCQUFpQjdJLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxVQUNoRCxNQUFNO0FBQUEsVUFDTixhQUFZO0FBQUEsVUFDWixPQUFPLEVBQUVrSyxZQUFZLGFBQWFuTixVQUFVLFVBQVVMLFNBQVMsRUFBRTtBQUFBO0FBQUEsUUFMbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3FFO0FBQUEsTUFFckUsdUJBQUMsU0FBSSxPQUFPLEVBQUVNLFNBQVMsUUFBUTZDLGdCQUFnQixXQUFXLEdBQ3hEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixVQUFVLENBQUM2SSxjQUFjekcsS0FBSztBQUFBLFVBQzlCLFNBQVNxSCxvQkFBb0IzSTtBQUFBQSxVQUM3QixTQUFTLE1BQU0ySSxvQkFBb0IxSSxPQUFPO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFFQ2dJLHFCQUNDLHVCQUFDLFNBQU0sU0FBUyxNQUFNQyxxQkFBcUIsS0FBSyxHQUFHLE9BQU0sOEJBQ3ZELGlDQUFDLFNBQUksT0FBTyxFQUFFN0wsU0FBUyxRQUFRQyxLQUFLLElBQUltRixVQUFVLElBQUksR0FDcEQ7QUFBQSw2QkFBQyxVQUFLO0FBQUE7QUFBQSxRQUNRLHVCQUFDLFlBQU8seUNBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQVM7QUFBQSxXQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFcEYsU0FBUyxRQUFRQyxLQUFLLElBQUk0QyxnQkFBZ0IsV0FBVyxHQUNqRTtBQUFBLCtCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVMsTUFBTWdKLHFCQUFxQixLQUFLLEdBQUcsd0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBTyxTQUFRLFVBQVMsU0FBU08sZ0JBQWdCekksV0FBVyxTQUFTLE1BQU15SSxnQkFBZ0J4SSxPQUFPLEdBQUcsa0NBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUdEa0ksdUJBQ0MsdUJBQUMsU0FBTSxTQUFTLE1BQU1DLHVCQUF1QixLQUFLLEdBQUcsT0FBTSw4QkFDekQsaUNBQUMsU0FBSSxPQUFPLEVBQUUvTCxTQUFTLFFBQVFDLEtBQUssSUFBSW1GLFVBQVUsSUFBSSxHQUNwRDtBQUFBLDZCQUFDLFVBQUs7QUFBQTtBQUFBLFFBQ1EsdUJBQUMsWUFBTyx5Q0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsUUFBUztBQUFBLFdBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVwRixTQUFTLFFBQVFDLEtBQUssSUFBSTRDLGdCQUFnQixXQUFXLEdBQ2pFO0FBQUEsK0JBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUyxNQUFNa0osdUJBQXVCLEtBQUssR0FBRyx3QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFNBQVEsVUFBUyxTQUFTTSxrQkFBa0IxSSxXQUFXLFNBQVMsTUFBTTBJLGtCQUFrQnpJLE9BQU8sR0FBRyxrQ0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLE9BdElKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3SUE7QUFFSjtBQUlBbUgsSUFsTlNELFVBQVE7QUFBQSxVQUNNeE0sY0FDUEMsVUFVT3hDLFVBS0VBLFVBTUVBLFVBTVlELGFBVWJBLGFBVUVBLGFBVUVBLFdBQVc7QUFBQTtBQUFBLE1BM0RoQ2dQO0FBb05ULFNBQVNxQyxlQUFlO0FBQUFDLE1BQUE7QUFDdEIsUUFBTSxFQUFFeE0sU0FBUyxJQUFJdEMsYUFBYTtBQUNsQyxRQUFNdUMsUUFBUXRDLFNBQVM7QUFDdkIsUUFBTSxDQUFDOE8sV0FBV0MsWUFBWSxJQUFJMVIsU0FBa0NLLDRCQUE0QixDQUFDLENBQUM7QUFDbEcsUUFBTSxDQUFDc1IsaUJBQWlCQyxrQkFBa0IsSUFBSTVSLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUM2UixpQkFBaUJDLGtCQUFrQixJQUFJOVIsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQytSLFVBQVVDLFdBQVcsSUFBSWhTLFNBQVMsRUFBRTtBQUUzQyxRQUFNaVMsaUJBQWlCL1IsWUFBWTtBQUFBLElBQ2pDdUcsWUFBWUEsTUFBTTtBQUNoQixVQUFJeUw7QUFDSixVQUFJQztBQUNKLFVBQUk7QUFDRkQsc0JBQWNQLGdCQUFnQnRJLEtBQUssSUFBSTlGLEtBQUtFLE1BQU1rTyxlQUFlLElBQUlySTtBQUNyRTZJLHNCQUFjTixnQkFBZ0J4SSxLQUFLLElBQUk5RixLQUFLRSxNQUFNb08sZUFBZSxJQUFJdkk7QUFBQUEsTUFDdkUsUUFBUTtBQUNOLGNBQU0sSUFBSThJLE1BQU0sY0FBYztBQUFBLE1BQ2hDO0FBQ0EsYUFBTzFRLDhCQUE4QnNELFVBQVV5TSxXQUFXO0FBQUEsUUFDeERTO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FKLFVBQVVBLFNBQVMxSSxLQUFLLEtBQUtDO0FBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNIO0FBQUEsSUFDQTNDLFdBQVdBLENBQUNvRSxXQUFXO0FBQ3JCLFVBQUlBLE9BQU9uRSxRQUFTM0IsT0FBTTJCLFFBQVEsOEJBQThCbUUsT0FBT3NILFVBQVUsSUFBSTtBQUFBO0FBQ2hGcE4sY0FBTTZCLE1BQU0sa0NBQWtDaUUsT0FBT3NILFVBQVUsNEJBQTRCO0FBQUEsSUFDbEc7QUFBQSxJQUNBeEwsU0FBU0EsQ0FBQ0MsVUFDUjdCLE1BQU02QixNQUFNQSxpQkFBaUJzTCxTQUFTdEwsTUFBTXdMLFlBQVksaUJBQWlCLHNEQUFzRCxnQ0FBZ0M7QUFBQSxFQUNuSyxDQUFDO0FBRUQsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRWxPLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ3JDLGlDQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRVAsU0FBUyxJQUFJTSxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNuRTtBQUFBLDJCQUFDLFlBQU8sNkRBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRDtBQUFBLElBQ3JELHVCQUFDLFVBQUssT0FBTyxFQUFFRixVQUFVLFdBQVdELE9BQU8sbUJBQW1CLEdBQUcsK1dBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLE9BQU91TjtBQUFBQSxRQUNQLFVBQVUsQ0FBQ3ZLLE1BQU13SyxhQUFheEssRUFBRUMsT0FBT0MsS0FBZ0M7QUFBQSxRQUV0RS9HLHNDQUE0Qm1FO0FBQUFBLFVBQUksQ0FBQytOLE9BQ2hDLHVCQUFDLFlBQWdCLE9BQU9BLElBQ3JCQSxnQkFEVUEsSUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsUUFDRDtBQUFBO0FBQUEsTUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFVQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVuTyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLDZCQUFDLFdBQU0sT0FBTyxFQUFFRixVQUFVLFdBQVdVLFlBQVksSUFBSSxHQUFHLDZDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGO0FBQUEsTUFDckY7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU84TTtBQUFBQSxVQUNQLFVBQVUsQ0FBQ3pLLE1BQU0wSyxtQkFBbUIxSyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsVUFDbEQsTUFBTTtBQUFBLFVBQ04sYUFBWTtBQUFBLFVBQ1osT0FBTyxFQUFFa0ssWUFBWSxhQUFhbk4sVUFBVSxVQUFVTCxTQUFTLEVBQUU7QUFBQTtBQUFBLFFBTG5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtxRTtBQUFBLFNBUHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVNLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsNkJBQUMsV0FBTSxPQUFPLEVBQUVGLFVBQVUsV0FBV1UsWUFBWSxJQUFJLEdBQUcsNkNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUY7QUFBQSxNQUNyRjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBT2dOO0FBQUFBLFVBQ1AsVUFBVSxDQUFDM0ssTUFBTTRLLG1CQUFtQjVLLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxVQUNsRCxNQUFNO0FBQUEsVUFDTixhQUFZO0FBQUEsVUFDWixPQUFPLEVBQUVrSyxZQUFZLGFBQWFuTixVQUFVLFVBQVVMLFNBQVMsRUFBRTtBQUFBO0FBQUEsUUFMbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3FFO0FBQUEsU0FQdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRU0sU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSw2QkFBQyxXQUFNLE9BQU8sRUFBRUYsVUFBVSxXQUFXVSxZQUFZLElBQUksR0FBRyxzREFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RjtBQUFBLE1BQzlGO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPa047QUFBQUEsVUFDUCxVQUFVLENBQUM3SyxNQUFNOEssWUFBWTlLLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxVQUMzQyxNQUFNO0FBQUEsVUFDTixhQUFZO0FBQUEsVUFDWixPQUFPLEVBQUVrSyxZQUFZLGFBQWFuTixVQUFVLFVBQVVMLFNBQVMsRUFBRTtBQUFBO0FBQUEsUUFMbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3FFO0FBQUEsU0FQdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRU0sU0FBUyxRQUFRNkMsZ0JBQWdCLFdBQVcsR0FDeEQsaUNBQUMsVUFBTyxTQUFRLFdBQVUsU0FBU2dMLGVBQWVsSyxXQUFXLFNBQVMsTUFBTWtLLGVBQWVqSyxPQUFPLEdBQUcsNEJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUNpSyxlQUFlaE0sUUFDZCx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVuQyxTQUFTLElBQUlLLFVBQVUsVUFBVW1KLFdBQVcsUUFBUUMsWUFBWSxXQUFXLEdBQ3pHLGtCQUFRMEUsZUFBZWhNLEtBQUtvTSxVQUFVLEdBQUdKLGVBQWVoTSxLQUFLdU0sZUFBZSxNQUFNUCxlQUFlaE0sS0FBS3VNLFlBQVksS0FBSyxFQUFFO0FBQUE7QUFBQSxFQUFPblAsV0FBVzRPLGVBQWVoTSxLQUFLd00sWUFBWSxDQUFDLE1BRC9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BL0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpRUEsS0FsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1FQTtBQUVKO0FBQUNqQixJQXRHUUQsY0FBWTtBQUFBLFVBQ0U3TyxjQUNQQyxVQU1TekMsV0FBVztBQUFBO0FBQUEsTUFSM0JxUjtBQUFZLElBQUFtQixJQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUFSLElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsIklGT09EX0NBVEFMT0dfVjFfT1BFUkFUSU9OUyIsImJhdGNoVXBkYXRlSUZvb2RQcm9kdWN0UHJpY2VzIiwiYmF0Y2hVcGRhdGVJRm9vZFByb2R1Y3RTdGF0dXNlcyIsImNoZWNrSUZvb2RDYXRhbG9nVmVyc2lvbiIsImNyZWF0ZUlGb29kQ2F0ZWdvcnkiLCJjcmVhdGVJRm9vZFByb2R1Y3QiLCJkZWxldGVJRm9vZENhdGVnb3J5IiwiZGVsZXRlSUZvb2RJbnZlbnRvcnlCYXRjaCIsImRlbGV0ZUlGb29kSXRlbSIsImRlbGV0ZUlGb29kT3B0aW9uIiwiZGVsZXRlSUZvb2RPcHRpb25Hcm91cCIsImRlbGV0ZUlGb29kUHJvZHVjdCIsImRpc2Fzc29jaWF0ZUlGb29kT3B0aW9uR3JvdXAiLCJkb3duZ3JhZGVJRm9vZENhdGFsb2dWZXJzaW9uIiwiZWRpdElGb29kQ2F0ZWdvcnkiLCJlZGl0SUZvb2RQcm9kdWN0IiwiZ2V0SUZvb2RCYXRjaFJlc3VsdCIsImdldElGb29kQ2F0YWxvZ3MiLCJnZXRJRm9vZEludmVudG9yeSIsImdldElGb29kSXRlbUZsYXQiLCJnZXRJRm9vZFByb2R1Y3RCeUlkIiwiaW52b2tlSUZvb2RDYXRhbG9nVjFPcGVyYXRpb24iLCJsaXN0SUZvb2RDYXRlZ29yaWVzIiwibGlzdElGb29kQ2F0ZWdvcnlJdGVtcyIsImxpc3RJRm9vZE9wdGlvbkdyb3VwcyIsImxpc3RJRm9vZFByb2R1Y3RzIiwibGlzdElGb29kUHJvZHVjdHNCeUV4dGVybmFsQ29kZSIsImxpc3RJRm9vZFNlbGxhYmxlSXRlbXMiLCJzZXRJRm9vZEl0ZW1FeHRlcm5hbENvZGUiLCJzZXRJRm9vZEl0ZW1QcmljZSIsInNldElGb29kT3B0aW9uRXh0ZXJuYWxDb2RlIiwic2V0SUZvb2RPcHRpb25QcmljZSIsInNldElGb29kT3B0aW9uU3RhdHVzIiwidXBkYXRlSUZvb2RPcHRpb25Hcm91cCIsInVwZGF0ZUlGb29kT3B0aW9uR3JvdXBTdGF0dXMiLCJ1cGxvYWRJRm9vZEltYWdlIiwidXBncmFkZUlGb29kQ2F0YWxvZ1ZlcnNpb24iLCJ1c2VBdXRoU3RvcmUiLCJ1c2VUb2FzdCIsIkJ1dHRvbiIsIk1vZGFsIiwiU2VsZWN0RmllbGQiLCJUZXh0RmllbGQiLCJRdWVyeUVycm9yIiwiRW1wdHlTdGF0ZSIsIlRBQlMiLCJrZXkiLCJsYWJlbCIsInByZXR0eUpzb24iLCJyYXciLCJKU09OIiwic3RyaW5naWZ5IiwicGFyc2UiLCJJRm9vZENhdGFsb2dQYWdlIiwiX3MiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJtYXJnaW5Cb3R0b20iLCJjb2xvciIsImZvbnRTaXplIiwiZGlzcGxheSIsImdhcCIsImJvcmRlckJvdHRvbSIsImZsZXhXcmFwIiwibWFwIiwidGFiIiwiYm9yZGVyIiwiYmFja2dyb3VuZCIsImN1cnNvciIsImZvbnRXZWlnaHQiLCJDYXRlZ29yaWVzVGFiIiwiX3MyIiwiYnJhbmNoSWQiLCJ0b2FzdCIsInF1ZXJ5Q2xpZW50IiwiY2F0YWxvZ0lkIiwic2V0Q2F0YWxvZ0lkIiwiY3JlYXRpbmciLCJzZXRDcmVhdGluZyIsImVkaXRpbmciLCJzZXRFZGl0aW5nIiwiZ3JvdXBJZCIsInNldEdyb3VwSWQiLCJzdWJtaXR0ZWRHcm91cElkIiwic2V0U3VibWl0dGVkR3JvdXBJZCIsImNhdGFsb2dzUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJjYXRhbG9ncyIsImRhdGEiLCJlZmZlY3RpdmVDYXRhbG9nSWQiLCJjYXRlZ29yaWVzUXVlcnkiLCJlbmFibGVkIiwic2VsbGFibGVJdGVtc1F1ZXJ5IiwiaW52YWxpZGF0ZSIsImludmFsaWRhdGVRdWVyaWVzIiwiZGVsZXRlTXV0YXRpb24iLCJtdXRhdGlvbkZuIiwiY2F0ZWdvcnlJZCIsIm9uU3VjY2VzcyIsInN1Y2Nlc3MiLCJvbkVycm9yIiwiZXJyb3IiLCJjYXRlZ29yaWVzIiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZSIsInRhcmdldCIsInZhbHVlIiwiaXNMb2FkaW5nIiwiYyIsInN0YXR1cyIsImlzRXJyb3IiLCJsZW5ndGgiLCJjYXRlZ29yeSIsIm5hbWUiLCJpZCIsImluZGV4IiwiZXh0ZXJuYWxDb2RlIiwiaXNQZW5kaW5nIiwibXV0YXRlIiwiaXRlbSIsImJvcmRlclRvcCIsInBhZGRpbmdUb3AiLCJpdGVtTmFtZSIsIml0ZW1QcmljZVZhbHVlIiwidG9Mb2NhbGVTdHJpbmciLCJzdHlsZSIsImN1cnJlbmN5IiwiaXRlbUV4dGVybmFsQ29kZSIsIml0ZW1JZCIsIkNhdGVnb3J5Rm9ybU1vZGFsIiwib25DbG9zZSIsIm9uU2F2ZWQiLCJfczMiLCJzZXROYW1lIiwic2V0RXh0ZXJuYWxDb2RlIiwic2V0U3RhdHVzIiwic2V0SW5kZXgiLCJTdHJpbmciLCJzYXZlTXV0YXRpb24iLCJ0cmltIiwidW5kZWZpbmVkIiwiTnVtYmVyIiwibWluV2lkdGgiLCJQcm9kdWN0c1RhYiIsIl9zNCIsImV4dGVybmFsQ29kZUxvb2t1cCIsInNldEV4dGVybmFsQ29kZUxvb2t1cCIsInN1Ym1pdHRlZEV4dGVybmFsQ29kZSIsInNldFN1Ym1pdHRlZEV4dGVybmFsQ29kZSIsImlkTG9va3VwIiwic2V0SWRMb29rdXAiLCJsb29rZWRVcFByb2R1Y3QiLCJzZXRMb29rZWRVcFByb2R1Y3QiLCJiYXRjaFN0YXR1c0lkcyIsInNldEJhdGNoU3RhdHVzSWRzIiwiYmF0Y2hTdGF0dXNWYWx1ZSIsInNldEJhdGNoU3RhdHVzVmFsdWUiLCJiYXRjaFByaWNlSWRzIiwic2V0QmF0Y2hQcmljZUlkcyIsImJhdGNoUHJpY2VWYWx1ZSIsInNldEJhdGNoUHJpY2VWYWx1ZSIsInByb2R1Y3RzUXVlcnkiLCJieUV4dGVybmFsQ29kZVF1ZXJ5IiwicHJvZHVjdElkIiwibG9va3VwQnlJZE11dGF0aW9uIiwicmVzdWx0IiwiYmF0Y2hTdGF0dXNNdXRhdGlvbiIsInNwbGl0IiwiZmlsdGVyIiwiQm9vbGVhbiIsImJhdGNoUHJpY2VNdXRhdGlvbiIsImJhdGNoSWQiLCJwcm9kdWN0cyIsInByb2R1Y3QiLCJlYW4iLCJwIiwiUHJvZHVjdEZvcm1Nb2RhbCIsIl9zNSIsImRlc2NyaXB0aW9uIiwic2V0RGVzY3JpcHRpb24iLCJzZXRFYW4iLCJpbWFnZSIsInNldEltYWdlIiwiaW1hZ2VQYXRoIiwicGF5bG9hZCIsIkl0ZW1zVGFiIiwiX3M2Iiwic2V0SXRlbUlkIiwic3VibWl0dGVkSXRlbUlkIiwic2V0U3VibWl0dGVkSXRlbUlkIiwicHJpY2VWYWx1ZSIsInNldFByaWNlVmFsdWUiLCJzZXRDYXRlZ29yeUlkIiwic2V0UHJvZHVjdElkIiwiY2F0ZWdvcnlJdGVtc0lkIiwic2V0Q2F0ZWdvcnlJdGVtc0lkIiwic3VibWl0dGVkQ2F0ZWdvcnlJdGVtc0lkIiwic2V0U3VibWl0dGVkQ2F0ZWdvcnlJdGVtc0lkIiwiaXRlbVF1ZXJ5IiwiY2F0ZWdvcnlJdGVtc1F1ZXJ5Iiwic2V0UHJpY2VNdXRhdGlvbiIsInJlZmV0Y2giLCJzZXRFeHRlcm5hbENvZGVNdXRhdGlvbiIsImRlbGV0ZUl0ZW1NdXRhdGlvbiIsIm92ZXJmbG93WCIsIndoaXRlU3BhY2UiLCJyYXdQYXlsb2FkIiwiT3B0aW9uR3JvdXBzVGFiIiwiX3M3Iiwib3B0aW9uSWQiLCJzZXRPcHRpb25JZCIsIm9wdGlvblByaWNlIiwic2V0T3B0aW9uUHJpY2UiLCJvcHRpb25FeHRlcm5hbENvZGUiLCJzZXRPcHRpb25FeHRlcm5hbENvZGUiLCJncm91cHNRdWVyeSIsImRlbGV0ZUdyb3VwTXV0YXRpb24iLCJ0b2dnbGVTdGF0dXNNdXRhdGlvbiIsImF2YWlsYWJsZSIsInNldE9wdGlvblByaWNlTXV0YXRpb24iLCJzZXRPcHRpb25FeHRlcm5hbENvZGVNdXRhdGlvbiIsInRvZ2dsZU9wdGlvblN0YXR1c011dGF0aW9uIiwiZGVsZXRlT3B0aW9uTXV0YXRpb24iLCJkaXNhc3NvY2lhdGVNdXRhdGlvbiIsInJlbmFtZUdyb3VwTXV0YXRpb24iLCJkaXNhc3NvY2lhdGVQcm9kdWN0SWQiLCJzZXREaXNhc3NvY2lhdGVQcm9kdWN0SWQiLCJyZW5hbWVWYWx1ZSIsInNldFJlbmFtZVZhbHVlIiwiZ3JvdXBzIiwiZ3JvdXAiLCJtYXJnaW5Ub3AiLCJBZG1pblRhYiIsIl9zOCIsImludmVudG9yeVByb2R1Y3RJZCIsInNldEludmVudG9yeVByb2R1Y3RJZCIsInN1Ym1pdHRlZEludmVudG9yeUlkIiwic2V0U3VibWl0dGVkSW52ZW50b3J5SWQiLCJiYXRjaERlbGV0ZUlkcyIsInNldEJhdGNoRGVsZXRlSWRzIiwiYmF0Y2hSZXN1bHRJZCIsInNldEJhdGNoUmVzdWx0SWQiLCJzdWJtaXR0ZWRCYXRjaFJlc3VsdElkIiwic2V0U3VibWl0dGVkQmF0Y2hSZXN1bHRJZCIsImltYWdlSnNvbkJvZHkiLCJzZXRJbWFnZUpzb25Cb2R5IiwiY29uZmlybWluZ1VwZ3JhZGUiLCJzZXRDb25maXJtaW5nVXBncmFkZSIsImNvbmZpcm1pbmdEb3duZ3JhZGUiLCJzZXRDb25maXJtaW5nRG93bmdyYWRlIiwidmVyc2lvblF1ZXJ5IiwiaW52ZW50b3J5UXVlcnkiLCJiYXRjaFJlc3VsdFF1ZXJ5IiwiZGVsZXRlSW52ZW50b3J5QmF0Y2hNdXRhdGlvbiIsInVwZ3JhZGVNdXRhdGlvbiIsImRvd25ncmFkZU11dGF0aW9uIiwidXBsb2FkSW1hZ2VNdXRhdGlvbiIsInNsaWNlIiwiaW52ZW50b3J5IiwidmVyc2lvbiIsImFtb3VudCIsImluU3RvY2siLCJiYXRjaFN0YXR1cyIsInJlc3VsdHMiLCJyIiwiaWR4IiwicmVzb3VyY2VJZCIsImZhaWx1cmVSZWFzb24iLCJmb250RmFtaWx5IiwiVjFDb25zb2xlVGFiIiwiX3M5Iiwib3BlcmF0aW9uIiwic2V0T3BlcmF0aW9uIiwicm91dGVQYXJhbXNUZXh0Iiwic2V0Um91dGVQYXJhbXNUZXh0IiwicXVlcnlQYXJhbXNUZXh0Iiwic2V0UXVlcnlQYXJhbXNUZXh0IiwianNvbkJvZHkiLCJzZXRKc29uQm9keSIsImludm9rZU11dGF0aW9uIiwicm91dGVQYXJhbXMiLCJxdWVyeVBhcmFtcyIsIkVycm9yIiwic3RhdHVzQ29kZSIsIm1lc3NhZ2UiLCJvcCIsImVycm9yTWVzc2FnZSIsInJlc3BvbnNlQm9keSIsIl9jIiwiX2MyIiwiX2MzIiwiX2M0IiwiX2M1IiwiX2M2IiwiX2M3IiwiX2M4IiwiX2M5Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIklGb29kQ2F0YWxvZ1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQge1xyXG4gIElGT09EX0NBVEFMT0dfVjFfT1BFUkFUSU9OUyxcclxuICBiYXRjaFVwZGF0ZUlGb29kUHJvZHVjdFByaWNlcyxcclxuICBiYXRjaFVwZGF0ZUlGb29kUHJvZHVjdFN0YXR1c2VzLFxyXG4gIGNoZWNrSUZvb2RDYXRhbG9nVmVyc2lvbixcclxuICBjcmVhdGVJRm9vZENhdGVnb3J5LFxyXG4gIGNyZWF0ZUlGb29kUHJvZHVjdCxcclxuICBkZWxldGVJRm9vZENhdGVnb3J5LFxyXG4gIGRlbGV0ZUlGb29kSW52ZW50b3J5QmF0Y2gsXHJcbiAgZGVsZXRlSUZvb2RJdGVtLFxyXG4gIGRlbGV0ZUlGb29kT3B0aW9uLFxyXG4gIGRlbGV0ZUlGb29kT3B0aW9uR3JvdXAsXHJcbiAgZGVsZXRlSUZvb2RQcm9kdWN0LFxyXG4gIGRpc2Fzc29jaWF0ZUlGb29kT3B0aW9uR3JvdXAsXHJcbiAgZG93bmdyYWRlSUZvb2RDYXRhbG9nVmVyc2lvbixcclxuICBlZGl0SUZvb2RDYXRlZ29yeSxcclxuICBlZGl0SUZvb2RQcm9kdWN0LFxyXG4gIGdldElGb29kQmF0Y2hSZXN1bHQsXHJcbiAgZ2V0SUZvb2RDYXRhbG9ncyxcclxuICBnZXRJRm9vZEludmVudG9yeSxcclxuICBnZXRJRm9vZEl0ZW1GbGF0LFxyXG4gIGdldElGb29kUHJvZHVjdEJ5SWQsXHJcbiAgaW52b2tlSUZvb2RDYXRhbG9nVjFPcGVyYXRpb24sXHJcbiAgbGlzdElGb29kQ2F0ZWdvcmllcyxcclxuICBsaXN0SUZvb2RDYXRlZ29yeUl0ZW1zLFxyXG4gIGxpc3RJRm9vZE9wdGlvbkdyb3VwcyxcclxuICBsaXN0SUZvb2RQcm9kdWN0cyxcclxuICBsaXN0SUZvb2RQcm9kdWN0c0J5RXh0ZXJuYWxDb2RlLFxyXG4gIGxpc3RJRm9vZFNlbGxhYmxlSXRlbXMsXHJcbiAgc2V0SUZvb2RJdGVtRXh0ZXJuYWxDb2RlLFxyXG4gIHNldElGb29kSXRlbVByaWNlLFxyXG4gIHNldElGb29kT3B0aW9uRXh0ZXJuYWxDb2RlLFxyXG4gIHNldElGb29kT3B0aW9uUHJpY2UsXHJcbiAgc2V0SUZvb2RPcHRpb25TdGF0dXMsXHJcbiAgdXBkYXRlSUZvb2RPcHRpb25Hcm91cCxcclxuICB1cGRhdGVJRm9vZE9wdGlvbkdyb3VwU3RhdHVzLFxyXG4gIHVwbG9hZElGb29kSW1hZ2UsXHJcbiAgdXBncmFkZUlGb29kQ2F0YWxvZ1ZlcnNpb24sXHJcbiAgdHlwZSBJRm9vZENhdGFsb2dWMU9wZXJhdGlvbixcclxuICB0eXBlIElGb29kQ2F0ZWdvcnlSZXNwb25zZSxcclxuICB0eXBlIElGb29kT3B0aW9uR3JvdXBSZXNwb25zZSxcclxuICB0eXBlIElGb29kUHJvZHVjdFJlc3BvbnNlLFxyXG59IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi8uLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IE1vZGFsIH0gZnJvbSBcIi4uLy4uL3VpL01vZGFsXCI7XHJcbmltcG9ydCB7IFNlbGVjdEZpZWxkLCBUZXh0RmllbGQgfSBmcm9tIFwiLi4vLi4vdWkvRmllbGRcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCIuLi8uLi91aS9FbXB0eVN0YXRlXCI7XHJcblxyXG4vLyBGYXNlIDEwIOKAlCBtw7NkdWxvIENhdGFsb2cgY29tcGxldG8uIFRpZXIgMSAodjIsIHZpdmEsIGrDoSB1c2FkYSBwZWxhIHNpbmNyb25pemHDp8OjbyBhdXRvbcOhdGljYVxyXG4vLyBkZXNkZSBhIGZhc2UgMyk6IHRlbGFzIGRlZGljYWRhcyBkZSBjYXRlZ29yaWFzLCBwcm9kdXRvcywgaXRlbnMgZSBncnVwb3MgZGUgb3DDp8O1ZXMvb3DDp8O1ZXMsIG1haXNcclxuLy8gYXMgb3BlcmHDp8O1ZXMgYWRtaW5pc3RyYXRpdmFzIChlc3RvcXVlLCBsb3RlLCB2ZXJzw6NvIGRvIGNhdMOhbG9nbywgaW1hZ2VtKS4gVGllciAyICh2MSwgbGVnYWRvKTpcclxuLy8gY29uc29sZSBnZW7DqXJpY28g4oCUIHRvZG8gbWVyY2hhbnQgZXN0w6EgZW0gdjEgT1UgdjIsIG51bmNhIG5vcyBkb2lzOyBxdWVtIGVzdMOhIGVtIHYxIHVzYSBhIGFiYVxyXG4vLyBcIkNvbnNvbGUgdjFcIiBwcmEgY2hhbWFyIHF1YWxxdWVyIHVtIGRvcyA1NiBlbmRwb2ludHMgbGVnYWRvcyBzZW0gdGVsYSBkZWRpY2FkYS5cclxuLy8gUmVzc2FsdmEgaW1wb3J0YW50ZSwgdsOhbGlkYSBwcmEgdG9kYXMgYXMgYWJhczogb3Mgbm9tZXMgZGUgY2FtcG8gZm9yYW0gY29uZmlybWFkb3MgY29udHJhIGFcclxuLy8gY29sbGVjdGlvbiBvZmljaWFsIGRvIFBvc3RtYW4sIG1hcyBvcyBWQUxPUkVTIGRlIGV4ZW1wbG8gZGEgZG9jIHPDo28gcGxhY2Vob2xkZXJzIGdlcmFkb3MgcGVsb1xyXG4vLyBQb3N0bWFuIChzY2hlbWEgbW9jayksIG7Do28gdHLDoWZlZ28gcmVhbCBjYXB0dXJhZG8g4oCUIHRyYXRlIGNvbW8gXCJlc3RydXR1cmEgY29uZmlybWFkYSwgdmFsb3Jlc1xyXG4vLyBuw6NvIGNvbmZpcm1hZG9zXCIgYXTDqSB0ZXN0YXIgY29udHJhIG8gc2FuZGJveC5cclxuXHJcbnR5cGUgVGFiVHlwZSA9IFwiY2F0ZWdvcmlhc1wiIHwgXCJwcm9kdXRvc1wiIHwgXCJpdGVuc1wiIHwgXCJjb21wbGVtZW50b3NcIiB8IFwiYWRtaW5cIiB8IFwidjFcIjtcclxuXHJcbmNvbnN0IFRBQlM6IHsga2V5OiBUYWJUeXBlOyBsYWJlbDogc3RyaW5nIH1bXSA9IFtcclxuICB7IGtleTogXCJjYXRlZ29yaWFzXCIsIGxhYmVsOiBcIkNhdGVnb3JpYXNcIiB9LFxyXG4gIHsga2V5OiBcInByb2R1dG9zXCIsIGxhYmVsOiBcIlByb2R1dG9zXCIgfSxcclxuICB7IGtleTogXCJpdGVuc1wiLCBsYWJlbDogXCJJdGVuc1wiIH0sXHJcbiAgeyBrZXk6IFwiY29tcGxlbWVudG9zXCIsIGxhYmVsOiBcIkNvbXBsZW1lbnRvc1wiIH0sXHJcbiAgeyBrZXk6IFwiYWRtaW5cIiwgbGFiZWw6IFwiQWRtaW5pc3RyYcOnw6NvXCIgfSxcclxuICB7IGtleTogXCJ2MVwiLCBsYWJlbDogXCJDb25zb2xlIHYxIChsZWdhZG8pXCIgfSxcclxuXTtcclxuXHJcbmZ1bmN0aW9uIHByZXR0eUpzb24ocmF3OiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKTogc3RyaW5nIHtcclxuICBpZiAoIXJhdykgcmV0dXJuIFwiXCI7XHJcbiAgdHJ5IHtcclxuICAgIHJldHVybiBKU09OLnN0cmluZ2lmeShKU09OLnBhcnNlKHJhdyksIG51bGwsIDIpO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIHJhdztcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJRm9vZENhdGFsb2dQYWdlKCkge1xyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTxUYWJUeXBlPihcImNhdGVnb3JpYXNcIik7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDExMDAsIG1hcmdpbjogXCIwIGF1dG9cIiB9fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAxOCB9fT5cclxuICAgICAgICA8TGluayB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZFwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAg4oaQIEludGVncmHDp8OjbyBpRm9vZFxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuN3JlbVwiIH19PlxyXG4gICAgICAgICAgQ2FyZMOhcGlvIGlGb29kIChDYXRhbG9nKVxyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5cclxuICAgICAgICAgIGdlcmVuY2llIGNhdGVnb3JpYXMsIHByb2R1dG9zLCBpdGVucyBlIGNvbXBsZW1lbnRvcyBkaXJldGFtZW50ZSBubyBpRm9vZCDigJQgYSBzaW5jcm9uaXphw6fDo29cclxuICAgICAgICAgIGF1dG9tw6F0aWNhIChmYXNlIDMpIGNvbnRpbnVhIGNvYnJpbmRvIG8gZmx1eG8gZXNzZW5jaWFsOyB1c2UgZXN0YXMgdGVsYXMgcHJhIGFqdXN0ZXMgZmlub3NcclxuICAgICAgICAgIGUgb3BlcmHDp8O1ZXMgcXVlIGVsYSBuw6NvIGNvYnJlLlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDAsIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgdmFyKC0tYm9yZGVyKVwiLCBtYXJnaW5Cb3R0b206IDIwLCBmbGV4V3JhcDogXCJ3cmFwXCIgfX0+XHJcbiAgICAgICAge1RBQlMubWFwKCh0YWIpID0+IChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAga2V5PXt0YWIua2V5fVxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKHRhYi5rZXkpfVxyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IFwiMTJweCAxOHB4XCIsXHJcbiAgICAgICAgICAgICAgYm9yZGVyOiBcIm5vbmVcIixcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcIm5vbmVcIixcclxuICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxyXG4gICAgICAgICAgICAgIGZvbnRTaXplOiBcIjAuOXJlbVwiLFxyXG4gICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IGFjdGl2ZVRhYiA9PT0gdGFiLmtleSA/IDYwMCA6IDQwMCxcclxuICAgICAgICAgICAgICBjb2xvcjogYWN0aXZlVGFiID09PSB0YWIua2V5ID8gXCJ2YXIoLS1pbmspXCIgOiBcInZhcigtLWluay1mYWludClcIixcclxuICAgICAgICAgICAgICBib3JkZXJCb3R0b206IGFjdGl2ZVRhYiA9PT0gdGFiLmtleSA/IFwiMnB4IHNvbGlkIHZhcigtLWluaylcIiA6IFwiMnB4IHNvbGlkIHRyYW5zcGFyZW50XCIsXHJcbiAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAtMSxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3RhYi5sYWJlbH1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHthY3RpdmVUYWIgPT09IFwiY2F0ZWdvcmlhc1wiICYmIDxDYXRlZ29yaWVzVGFiIC8+fVxyXG4gICAgICB7YWN0aXZlVGFiID09PSBcInByb2R1dG9zXCIgJiYgPFByb2R1Y3RzVGFiIC8+fVxyXG4gICAgICB7YWN0aXZlVGFiID09PSBcIml0ZW5zXCIgJiYgPEl0ZW1zVGFiIC8+fVxyXG4gICAgICB7YWN0aXZlVGFiID09PSBcImNvbXBsZW1lbnRvc1wiICYmIDxPcHRpb25Hcm91cHNUYWIgLz59XHJcbiAgICAgIHthY3RpdmVUYWIgPT09IFwiYWRtaW5cIiAmJiA8QWRtaW5UYWIgLz59XHJcbiAgICAgIHthY3RpdmVUYWIgPT09IFwidjFcIiAmJiA8VjFDb25zb2xlVGFiIC8+fVxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyBDYXRlZ29yaWFzXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuZnVuY3Rpb24gQ2F0ZWdvcmllc1RhYigpIHtcclxuICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gIGNvbnN0IFtjYXRhbG9nSWQsIHNldENhdGFsb2dJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY3JlYXRpbmcsIHNldENyZWF0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZTxJRm9vZENhdGVnb3J5UmVzcG9uc2UgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbZ3JvdXBJZCwgc2V0R3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc3VibWl0dGVkR3JvdXBJZCwgc2V0U3VibWl0dGVkR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgY2F0YWxvZ3NRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImNhdGFsb2dcIiwgXCJjYXRhbG9nc1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZENhdGFsb2dzKGJyYW5jaElkKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgY2F0YWxvZ3MgPSBjYXRhbG9nc1F1ZXJ5LmRhdGEgPz8gW107XHJcbiAgY29uc3QgZWZmZWN0aXZlQ2F0YWxvZ0lkID0gY2F0YWxvZ0lkIHx8IGNhdGFsb2dzWzBdPy5jYXRhbG9nSWQgfHwgXCJcIjtcclxuXHJcbiAgY29uc3QgY2F0ZWdvcmllc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwiY2F0YWxvZ1wiLCBcImNhdGVnb3JpZXNcIiwgYnJhbmNoSWQsIGVmZmVjdGl2ZUNhdGFsb2dJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBsaXN0SUZvb2RDYXRlZ29yaWVzKGJyYW5jaElkLCBlZmZlY3RpdmVDYXRhbG9nSWQpLFxyXG4gICAgZW5hYmxlZDogISFlZmZlY3RpdmVDYXRhbG9nSWQsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHNlbGxhYmxlSXRlbXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImNhdGFsb2dcIiwgXCJzZWxsYWJsZS1pdGVtc1wiLCBicmFuY2hJZCwgc3VibWl0dGVkR3JvdXBJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBsaXN0SUZvb2RTZWxsYWJsZUl0ZW1zKGJyYW5jaElkLCBzdWJtaXR0ZWRHcm91cElkKSxcclxuICAgIGVuYWJsZWQ6ICEhc3VibWl0dGVkR3JvdXBJZCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgaW52YWxpZGF0ZSA9ICgpID0+XHJcbiAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwiY2F0YWxvZ1wiLCBcImNhdGVnb3JpZXNcIl0gfSk7XHJcblxyXG4gIGNvbnN0IGRlbGV0ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKGNhdGVnb3J5SWQ6IHN0cmluZykgPT4gZGVsZXRlSUZvb2RDYXRlZ29yeShicmFuY2hJZCwgY2F0ZWdvcnlJZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNhdGVnb3JpYSBleGNsdcOtZGEgbm8gaUZvb2QuXCIpO1xyXG4gICAgICBpbnZhbGlkYXRlKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgZXhjbHVpciBhIGNhdGVnb3JpYS5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGNhdGVnb3JpZXMgPSBjYXRlZ29yaWVzUXVlcnkuZGF0YSA/PyBbXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTggfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTIsIGFsaWduSXRlbXM6IFwiZmxleC1lbmRcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiIH19PlxyXG4gICAgICAgICAgPFNlbGVjdEZpZWxkXHJcbiAgICAgICAgICAgIGxhYmVsPVwiQ2F0w6Fsb2dvXCJcclxuICAgICAgICAgICAgdmFsdWU9e2VmZmVjdGl2ZUNhdGFsb2dJZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXRhbG9nSWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17Y2F0YWxvZ3NRdWVyeS5pc0xvYWRpbmd9XHJcbiAgICAgICAgICAgIGhpbnQ9XCJncnVwby9jYW5hbCAoZXguOiBpRm9vZCwgV2hhdHNBcHApIOKAlCBvIGlGb29kIHYyIHBvZGUgdGVyIG1haXMgZGUgdW1cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7Y2F0YWxvZ3MubWFwKChjKSA9PiAoXHJcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2MuY2F0YWxvZ0lkID8/IFwiXCJ9IHZhbHVlPXtjLmNhdGFsb2dJZCA/PyBcIlwifT5cclxuICAgICAgICAgICAgICAgIHtjLmNhdGFsb2dJZH0ge2Muc3RhdHVzID8gYCgke2Muc3RhdHVzfSlgIDogXCJcIn1cclxuICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L1NlbGVjdEZpZWxkPlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIGRpc2FibGVkPXshZWZmZWN0aXZlQ2F0YWxvZ0lkfSBvbkNsaWNrPXsoKSA9PiBzZXRDcmVhdGluZyh0cnVlKX0+XHJcbiAgICAgICAgICAgICsgTm92YSBjYXRlZ29yaWFcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtjYXRhbG9nc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e2NhdGFsb2dzUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBjYXTDoWxvZ29zXCIgLz59XHJcbiAgICAgIHtjYXRlZ29yaWVzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17Y2F0ZWdvcmllc1F1ZXJ5LmVycm9yfSB3aGF0PVwiYXMgY2F0ZWdvcmlhc1wiIC8+fVxyXG5cclxuICAgICAgeyFjYXRlZ29yaWVzUXVlcnkuaXNMb2FkaW5nICYmIGNhdGVnb3JpZXMubGVuZ3RoID09PSAwICYmICFjYXRlZ29yaWVzUXVlcnkuaXNFcnJvciAmJiBlZmZlY3RpdmVDYXRhbG9nSWQgJiYgKFxyXG4gICAgICAgIDxFbXB0eVN0YXRlIHRpdGxlPVwiTmVuaHVtYSBjYXRlZ29yaWFcIiBkZXNjcmlwdGlvbj1cIkVzdGUgY2F0w6Fsb2dvIGFpbmRhIG7Do28gdGVtIGNhdGVnb3JpYXMgbm8gaUZvb2QuXCIgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAgfX0+XHJcbiAgICAgICAge2NhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4gKFxyXG4gICAgICAgICAgPHNlY3Rpb24ga2V5PXtjYXRlZ29yeS5pZH0gY2xhc3NOYW1lPVwidGlja2V0IHJpc2VcIiBzdHlsZT17eyBwYWRkaW5nOiAxNCB9fT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGdhcDogMTAgfX0+XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNzAwIH19PntjYXRlZ29yeS5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5pZH0gwrcgc3RhdHVzOiB7Y2F0ZWdvcnkuc3RhdHVzID8/IFwi4oCUXCJ9IMK3IMOtbmRpY2U6IHtjYXRlZ29yeS5pbmRleCA/PyBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuZXh0ZXJuYWxDb2RlID8gYCDCtyBjw7NkaWdvIGV4dGVybm86ICR7Y2F0ZWdvcnkuZXh0ZXJuYWxDb2RlfWAgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZyhjYXRlZ29yeSl9PlxyXG4gICAgICAgICAgICAgICAgICBFZGl0YXJcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICAgICAgbG9hZGluZz17ZGVsZXRlTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjYXRlZ29yeS5pZCAmJiBkZWxldGVNdXRhdGlvbi5tdXRhdGUoY2F0ZWdvcnkuaWQpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBFeGNsdWlyXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogMTYsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgIDxzdHJvbmc+SXRlbnMgdmVuZMOhdmVpcyBwb3IgZ3J1cG88L3N0cm9uZz5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgIGNvbnN1bHRhIG9zIGl0ZW5zIHZlbmTDoXZlaXMgYXNzb2NpYWRvcyBhIHVtIGdyb3VwSWQgKG9idGlkbyBuYSByZXNwb3N0YSBkZSBjYXRlZ29yaWFzL2l0ZW5zKS5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwLCBhbGlnbkl0ZW1zOiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiR3JvdXAgSWRcIiB2YWx1ZT17Z3JvdXBJZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRHcm91cElkKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gc2V0U3VibWl0dGVkR3JvdXBJZChncm91cElkKX0+XHJcbiAgICAgICAgICAgIENvbnN1bHRhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge3NlbGxhYmxlSXRlbXNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtzZWxsYWJsZUl0ZW1zUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBpdGVucyB2ZW5kw6F2ZWlzXCIgLz59XHJcbiAgICAgICAgeyhzZWxsYWJsZUl0ZW1zUXVlcnkuZGF0YSA/PyBbXSkubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICA8ZGl2IGtleT17aXRlbS5pdGVtSWR9IHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODVyZW1cIiwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsIHBhZGRpbmdUb3A6IDYgfX0+XHJcbiAgICAgICAgICAgIHtpdGVtLml0ZW1OYW1lfSDigJQge2l0ZW0uaXRlbVByaWNlVmFsdWU/LnRvTG9jYWxlU3RyaW5nKFwicHQtQlJcIiwgeyBzdHlsZTogXCJjdXJyZW5jeVwiLCBjdXJyZW5jeTogXCJCUkxcIiB9KSA/PyBcIuKAlFwifVxyXG4gICAgICAgICAgICB7aXRlbS5pdGVtRXh0ZXJuYWxDb2RlID8gYCDCtyBjw7NkaWdvOiAke2l0ZW0uaXRlbUV4dGVybmFsQ29kZX1gIDogXCJcIn1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtjcmVhdGluZyAmJiAoXHJcbiAgICAgICAgPENhdGVnb3J5Rm9ybU1vZGFsXHJcbiAgICAgICAgICBicmFuY2hJZD17YnJhbmNoSWR9XHJcbiAgICAgICAgICBjYXRhbG9nSWQ9e2VmZmVjdGl2ZUNhdGFsb2dJZH1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldENyZWF0aW5nKGZhbHNlKX1cclxuICAgICAgICAgIG9uU2F2ZWQ9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0Q3JlYXRpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICBpbnZhbGlkYXRlKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7ZWRpdGluZyAmJiAoXHJcbiAgICAgICAgPENhdGVnb3J5Rm9ybU1vZGFsXHJcbiAgICAgICAgICBicmFuY2hJZD17YnJhbmNoSWR9XHJcbiAgICAgICAgICBjYXRhbG9nSWQ9e2VmZmVjdGl2ZUNhdGFsb2dJZH1cclxuICAgICAgICAgIGNhdGVnb3J5PXtlZGl0aW5nfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0RWRpdGluZyhudWxsKX1cclxuICAgICAgICAgIG9uU2F2ZWQ9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0RWRpdGluZyhudWxsKTtcclxuICAgICAgICAgICAgaW52YWxpZGF0ZSgpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gQ2F0ZWdvcnlGb3JtTW9kYWwoe1xyXG4gIGJyYW5jaElkLFxyXG4gIGNhdGFsb2dJZCxcclxuICBjYXRlZ29yeSxcclxuICBvbkNsb3NlLFxyXG4gIG9uU2F2ZWQsXHJcbn06IHtcclxuICBicmFuY2hJZDogbnVtYmVyO1xyXG4gIGNhdGFsb2dJZDogc3RyaW5nO1xyXG4gIGNhdGVnb3J5PzogSUZvb2RDYXRlZ29yeVJlc3BvbnNlO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25TYXZlZDogKCkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZShjYXRlZ29yeT8ubmFtZSA/PyBcIlwiKTtcclxuICBjb25zdCBbZXh0ZXJuYWxDb2RlLCBzZXRFeHRlcm5hbENvZGVdID0gdXNlU3RhdGUoY2F0ZWdvcnk/LmV4dGVybmFsQ29kZSA/PyBcIlwiKTtcclxuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGUoY2F0ZWdvcnk/LnN0YXR1cyA/PyBcIkFWQUlMQUJMRVwiKTtcclxuICBjb25zdCBbaW5kZXgsIHNldEluZGV4XSA9IHVzZVN0YXRlKGNhdGVnb3J5Py5pbmRleCAhPSBudWxsID8gU3RyaW5nKGNhdGVnb3J5LmluZGV4KSA6IFwiXCIpO1xyXG5cclxuICBjb25zdCBzYXZlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGlmIChjYXRlZ29yeT8uaWQpIHtcclxuICAgICAgICBhd2FpdCBlZGl0SUZvb2RDYXRlZ29yeShicmFuY2hJZCwgY2F0YWxvZ0lkLCBjYXRlZ29yeS5pZCwge1xyXG4gICAgICAgICAgbmFtZTogbmFtZS50cmltKCkgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgICAgZXh0ZXJuYWxDb2RlOiBleHRlcm5hbENvZGUudHJpbSgpIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICAgIHN0YXR1czogc3RhdHVzIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICAgIGluZGV4OiBpbmRleC50cmltKCkgPyBOdW1iZXIoaW5kZXgpIDogdW5kZWZpbmVkLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGF3YWl0IGNyZWF0ZUlGb29kQ2F0ZWdvcnkoYnJhbmNoSWQsIGNhdGFsb2dJZCwgbmFtZS50cmltKCkpO1xyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoY2F0ZWdvcnkgPyBcIkNhdGVnb3JpYSBhdHVhbGl6YWRhIG5vIGlGb29kLlwiIDogXCJDYXRlZ29yaWEgY3JpYWRhIG5vIGlGb29kLlwiKTtcclxuICAgICAgb25TYXZlZCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHNhbHZhciBhIGNhdGVnb3JpYS5cIiksXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TW9kYWwgb25DbG9zZT17b25DbG9zZX0gdGl0bGU9e2NhdGVnb3J5ID8gXCJFZGl0YXIgY2F0ZWdvcmlhXCIgOiBcIk5vdmEgY2F0ZWdvcmlhXCJ9PlxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE0LCBtaW5XaWR0aDogMzQwIH19PlxyXG4gICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJOb21lXCIgdmFsdWU9e25hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9IGF1dG9Gb2N1cyAvPlxyXG4gICAgICAgIHtjYXRlZ29yeSAmJiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiQ8OzZGlnbyBleHRlcm5vIChvcGNpb25hbClcIiB2YWx1ZT17ZXh0ZXJuYWxDb2RlfSBvbkNoYW5nZT17KGUpID0+IHNldEV4dGVybmFsQ29kZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgIDxTZWxlY3RGaWVsZCBsYWJlbD1cIlN0YXR1c1wiIHZhbHVlPXtzdGF0dXN9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3RhdHVzKGUudGFyZ2V0LnZhbHVlKX0+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFWQUlMQUJMRVwiPkRpc3BvbsOtdmVsPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlVOQVZBSUxBQkxFXCI+SW5kaXNwb27DrXZlbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICA8L1NlbGVjdEZpZWxkPlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiw41uZGljZSAob3BjaW9uYWwpXCIgaW5wdXRNb2RlPVwibnVtZXJpY1wiIHZhbHVlPXtpbmRleH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRJbmRleChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8Lz5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTAsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICBWb2x0YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIGRpc2FibGVkPXshbmFtZS50cmltKCl9IGxvYWRpbmc9e3NhdmVNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHNhdmVNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgIFNhbHZhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9Nb2RhbD5cclxuICApO1xyXG59XHJcblxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gUHJvZHV0b3NcclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG5mdW5jdGlvbiBQcm9kdWN0c1RhYigpIHtcclxuICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gIGNvbnN0IFtjcmVhdGluZywgc2V0Q3JlYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0aW5nLCBzZXRFZGl0aW5nXSA9IHVzZVN0YXRlPElGb29kUHJvZHVjdFJlc3BvbnNlIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2V4dGVybmFsQ29kZUxvb2t1cCwgc2V0RXh0ZXJuYWxDb2RlTG9va3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzdWJtaXR0ZWRFeHRlcm5hbENvZGUsIHNldFN1Ym1pdHRlZEV4dGVybmFsQ29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaWRMb29rdXAsIHNldElkTG9va3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtsb29rZWRVcFByb2R1Y3QsIHNldExvb2tlZFVwUHJvZHVjdF0gPSB1c2VTdGF0ZTxJRm9vZFByb2R1Y3RSZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtiYXRjaFN0YXR1c0lkcywgc2V0QmF0Y2hTdGF0dXNJZHNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2JhdGNoU3RhdHVzVmFsdWUsIHNldEJhdGNoU3RhdHVzVmFsdWVdID0gdXNlU3RhdGUoXCJBVkFJTEFCTEVcIik7XHJcbiAgY29uc3QgW2JhdGNoUHJpY2VJZHMsIHNldEJhdGNoUHJpY2VJZHNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2JhdGNoUHJpY2VWYWx1ZSwgc2V0QmF0Y2hQcmljZVZhbHVlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBwcm9kdWN0c1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwiY2F0YWxvZ1wiLCBcInByb2R1Y3RzXCIsIGJyYW5jaElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGxpc3RJRm9vZFByb2R1Y3RzKGJyYW5jaElkKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgYnlFeHRlcm5hbENvZGVRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImNhdGFsb2dcIiwgXCJwcm9kdWN0cy1ieS1leHRlcm5hbC1jb2RlXCIsIGJyYW5jaElkLCBzdWJtaXR0ZWRFeHRlcm5hbENvZGVdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gbGlzdElGb29kUHJvZHVjdHNCeUV4dGVybmFsQ29kZShicmFuY2hJZCwgc3VibWl0dGVkRXh0ZXJuYWxDb2RlKSxcclxuICAgIGVuYWJsZWQ6ICEhc3VibWl0dGVkRXh0ZXJuYWxDb2RlLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBpbnZhbGlkYXRlID0gKCkgPT5cclxuICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJjYXRhbG9nXCIsIFwicHJvZHVjdHNcIl0gfSk7XHJcblxyXG4gIGNvbnN0IGRlbGV0ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKHByb2R1Y3RJZDogc3RyaW5nKSA9PiBkZWxldGVJRm9vZFByb2R1Y3QoYnJhbmNoSWQsIHByb2R1Y3RJZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIlByb2R1dG8gZXhjbHXDrWRvIG5vIGlGb29kLlwiKTtcclxuICAgICAgaW52YWxpZGF0ZSgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIGV4Y2x1aXIgbyBwcm9kdXRvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgbG9va3VwQnlJZE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gZ2V0SUZvb2RQcm9kdWN0QnlJZChicmFuY2hJZCwgaWRMb29rdXAudHJpbSgpKSxcclxuICAgIG9uU3VjY2VzczogKHJlc3VsdCkgPT4gc2V0TG9va2VkVXBQcm9kdWN0KHJlc3VsdCksXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIlByb2R1dG8gbsOjbyBlbmNvbnRyYWRvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgYmF0Y2hTdGF0dXNNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIGJhdGNoVXBkYXRlSUZvb2RQcm9kdWN0U3RhdHVzZXMoXHJcbiAgICAgICAgYnJhbmNoSWQsXHJcbiAgICAgICAgYmF0Y2hTdGF0dXNJZHNcclxuICAgICAgICAgIC5zcGxpdChcIixcIilcclxuICAgICAgICAgIC5tYXAoKGlkKSA9PiBpZC50cmltKCkpXHJcbiAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXHJcbiAgICAgICAgICAubWFwKChwcm9kdWN0SWQpID0+ICh7IHByb2R1Y3RJZCwgc3RhdHVzOiBiYXRjaFN0YXR1c1ZhbHVlIH0pKSxcclxuICAgICAgKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4gdG9hc3Quc3VjY2VzcyhcIlN0YXR1cyBlbSBsb3RlIGVudmlhZG8gYW8gaUZvb2QuXCIpLFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJGYWxoYSBhbyBhdHVhbGl6YXIgc3RhdHVzIGVtIGxvdGUuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBiYXRjaFByaWNlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICBiYXRjaFVwZGF0ZUlGb29kUHJvZHVjdFByaWNlcyhcclxuICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICBiYXRjaFByaWNlSWRzXHJcbiAgICAgICAgICAuc3BsaXQoXCIsXCIpXHJcbiAgICAgICAgICAubWFwKChpZCkgPT4gaWQudHJpbSgpKVxyXG4gICAgICAgICAgLmZpbHRlcihCb29sZWFuKVxyXG4gICAgICAgICAgLm1hcCgocHJvZHVjdElkKSA9PiAoeyBwcm9kdWN0SWQsIHZhbHVlOiBOdW1iZXIoYmF0Y2hQcmljZVZhbHVlKSB8fCAwIH0pKSxcclxuICAgICAgKSxcclxuICAgIG9uU3VjY2VzczogKHJlc3VsdCkgPT4gdG9hc3Quc3VjY2VzcyhgTG90ZSBkZSBwcmXDp29zIGVudmlhZG8uIEJhdGNoSWQ6ICR7cmVzdWx0LmJhdGNoSWQgPz8gXCIodmVyIHBheWxvYWQpXCJ9YCksXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIkZhbGhhIGFvIGF0dWFsaXphciBwcmXDp29zIGVtIGxvdGUuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBwcm9kdWN0cyA9IHByb2R1Y3RzUXVlcnkuZGF0YSA/PyBbXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTggfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93XCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0Q3JlYXRpbmcodHJ1ZSl9PlxyXG4gICAgICAgICAgKyBOb3ZvIHByb2R1dG9cclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7cHJvZHVjdHNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtwcm9kdWN0c1F1ZXJ5LmVycm9yfSB3aGF0PVwib3MgcHJvZHV0b3NcIiAvPn1cclxuICAgICAgeyFwcm9kdWN0c1F1ZXJ5LmlzTG9hZGluZyAmJiBwcm9kdWN0cy5sZW5ndGggPT09IDAgJiYgIXByb2R1Y3RzUXVlcnkuaXNFcnJvciAmJiAoXHJcbiAgICAgICAgPEVtcHR5U3RhdGUgdGl0bGU9XCJOZW5odW0gcHJvZHV0b1wiIGRlc2NyaXB0aW9uPVwiTmVuaHVtIHByb2R1dG8gZW5jb250cmFkbyBubyBjYXTDoWxvZ28gZG8gaUZvb2QuXCIgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAgfX0+XHJcbiAgICAgICAge3Byb2R1Y3RzLm1hcCgocHJvZHVjdCkgPT4gKFxyXG4gICAgICAgICAgPHNlY3Rpb24ga2V5PXtwcm9kdWN0LmlkfSBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZVwiIHN0eWxlPXt7IHBhZGRpbmc6IDE0IH19PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiAxMCB9fT5cclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDIgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA3MDAgfX0+e3Byb2R1Y3QubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOHJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICB7cHJvZHVjdC5pZH1cclxuICAgICAgICAgICAgICAgICAge3Byb2R1Y3QuZXh0ZXJuYWxDb2RlID8gYCDCtyBjw7NkaWdvIGV4dGVybm86ICR7cHJvZHVjdC5leHRlcm5hbENvZGV9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtwcm9kdWN0LmVhbiA/IGAgwrcgRUFOOiAke3Byb2R1Y3QuZWFufWAgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZyhwcm9kdWN0KX0+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXRhclxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJkYW5nZXJcIlxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtkZWxldGVNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHByb2R1Y3QuaWQgJiYgZGVsZXRlTXV0YXRpb24ubXV0YXRlKHByb2R1Y3QuaWQpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBFeGNsdWlyXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogMTYsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgIDxzdHJvbmc+QnVzY2FyIHByb2R1dG88L3N0cm9uZz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAsIGFsaWduSXRlbXM6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJDw7NkaWdvIGV4dGVybm9cIiB2YWx1ZT17ZXh0ZXJuYWxDb2RlTG9va3VwfSBvbkNoYW5nZT17KGUpID0+IHNldEV4dGVybmFsQ29kZUxvb2t1cChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldFN1Ym1pdHRlZEV4dGVybmFsQ29kZShleHRlcm5hbENvZGVMb29rdXApfT5cclxuICAgICAgICAgICAgQnVzY2FyIHBvciBjw7NkaWdvXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJQcm9kdWN0IElkXCIgdmFsdWU9e2lkTG9va3VwfSBvbkNoYW5nZT17KGUpID0+IHNldElkTG9va3VwKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgbG9hZGluZz17bG9va3VwQnlJZE11dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gbG9va3VwQnlJZE11dGF0aW9uLm11dGF0ZSgpfT5cclxuICAgICAgICAgICAgQnVzY2FyIHBvciBJZFxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge2J5RXh0ZXJuYWxDb2RlUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17YnlFeHRlcm5hbENvZGVRdWVyeS5lcnJvcn0gd2hhdD1cImEgYnVzY2EgcG9yIGPDs2RpZ28gZXh0ZXJub1wiIC8+fVxyXG4gICAgICAgIHsoYnlFeHRlcm5hbENvZGVRdWVyeS5kYXRhID8/IFtdKS5tYXAoKHApID0+IChcclxuICAgICAgICAgIDxkaXYga2V5PXtwLmlkfSBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+XHJcbiAgICAgICAgICAgIHtwLm5hbWV9IOKAlCB7cC5pZH1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICAgIHtsb29rZWRVcFByb2R1Y3QgJiYgKFxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGJvcmRlclRvcDogXCIxcHggc29saWQgdmFyKC0tYm9yZGVyKVwiLCBwYWRkaW5nVG9wOiA4IH19PlxyXG4gICAgICAgICAgICB7bG9va2VkVXBQcm9kdWN0Lm5hbWV9IOKAlCB7bG9va2VkVXBQcm9kdWN0LmlkfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNiwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgPHN0cm9uZz5BdHVhbGl6YcOnw6NvIGVtIGxvdGU8L3N0cm9uZz5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5JZHMgc2VwYXJhZG9zIHBvciB2w61yZ3VsYS48L3NwYW4+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwLCBhbGlnbkl0ZW1zOiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiUHJvZHVjdCBJZHNcIiB2YWx1ZT17YmF0Y2hTdGF0dXNJZHN9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QmF0Y2hTdGF0dXNJZHMoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPFNlbGVjdEZpZWxkIGxhYmVsPVwiU3RhdHVzXCIgdmFsdWU9e2JhdGNoU3RhdHVzVmFsdWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QmF0Y2hTdGF0dXNWYWx1ZShlLnRhcmdldC52YWx1ZSl9PlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQVZBSUxBQkxFXCI+RGlzcG9uw612ZWw8L29wdGlvbj5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlVOQVZBSUxBQkxFXCI+SW5kaXNwb27DrXZlbDwvb3B0aW9uPlxyXG4gICAgICAgICAgPC9TZWxlY3RGaWVsZD5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgbG9hZGluZz17YmF0Y2hTdGF0dXNNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IGJhdGNoU3RhdHVzTXV0YXRpb24ubXV0YXRlKCl9PlxyXG4gICAgICAgICAgICBBdHVhbGl6YXIgc3RhdHVzIGVtIGxvdGVcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiAxMCwgYWxpZ25JdGVtczogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlByb2R1Y3QgSWRzXCIgdmFsdWU9e2JhdGNoUHJpY2VJZHN9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QmF0Y2hQcmljZUlkcyhlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiTm92byBwcmXDp29cIiBpbnB1dE1vZGU9XCJkZWNpbWFsXCIgdmFsdWU9e2JhdGNoUHJpY2VWYWx1ZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRCYXRjaFByaWNlVmFsdWUoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBsb2FkaW5nPXtiYXRjaFByaWNlTXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBiYXRjaFByaWNlTXV0YXRpb24ubXV0YXRlKCl9PlxyXG4gICAgICAgICAgICBBdHVhbGl6YXIgcHJlw6dvIGVtIGxvdGVcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtjcmVhdGluZyAmJiAoXHJcbiAgICAgICAgPFByb2R1Y3RGb3JtTW9kYWxcclxuICAgICAgICAgIGJyYW5jaElkPXticmFuY2hJZH1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldENyZWF0aW5nKGZhbHNlKX1cclxuICAgICAgICAgIG9uU2F2ZWQ9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0Q3JlYXRpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICBpbnZhbGlkYXRlKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7ZWRpdGluZyAmJiAoXHJcbiAgICAgICAgPFByb2R1Y3RGb3JtTW9kYWxcclxuICAgICAgICAgIGJyYW5jaElkPXticmFuY2hJZH1cclxuICAgICAgICAgIHByb2R1Y3Q9e2VkaXRpbmd9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0aW5nKG51bGwpfVxyXG4gICAgICAgICAgb25TYXZlZD17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRFZGl0aW5nKG51bGwpO1xyXG4gICAgICAgICAgICBpbnZhbGlkYXRlKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBQcm9kdWN0Rm9ybU1vZGFsKHtcclxuICBicmFuY2hJZCxcclxuICBwcm9kdWN0LFxyXG4gIG9uQ2xvc2UsXHJcbiAgb25TYXZlZCxcclxufToge1xyXG4gIGJyYW5jaElkOiBudW1iZXI7XHJcbiAgcHJvZHVjdD86IElGb29kUHJvZHVjdFJlc3BvbnNlO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25TYXZlZDogKCkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZShwcm9kdWN0Py5uYW1lID8/IFwiXCIpO1xyXG4gIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUocHJvZHVjdD8uZGVzY3JpcHRpb24gPz8gXCJcIik7XHJcbiAgY29uc3QgW2V4dGVybmFsQ29kZSwgc2V0RXh0ZXJuYWxDb2RlXSA9IHVzZVN0YXRlKHByb2R1Y3Q/LmV4dGVybmFsQ29kZSA/PyBcIlwiKTtcclxuICBjb25zdCBbZWFuLCBzZXRFYW5dID0gdXNlU3RhdGUocHJvZHVjdD8uZWFuID8/IFwiXCIpO1xyXG4gIGNvbnN0IFtpbWFnZSwgc2V0SW1hZ2VdID0gdXNlU3RhdGUocHJvZHVjdD8uaW1hZ2VQYXRoID8/IFwiXCIpO1xyXG5cclxuICBjb25zdCBzYXZlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgbmFtZTogbmFtZS50cmltKCksXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLnRyaW0oKSB8fCB1bmRlZmluZWQsXHJcbiAgICAgICAgZXh0ZXJuYWxDb2RlOiBleHRlcm5hbENvZGUudHJpbSgpIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICBlYW46IGVhbi50cmltKCkgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIGltYWdlOiBpbWFnZS50cmltKCkgfHwgdW5kZWZpbmVkLFxyXG4gICAgICB9O1xyXG4gICAgICByZXR1cm4gcHJvZHVjdD8uaWQgPyBlZGl0SUZvb2RQcm9kdWN0KGJyYW5jaElkLCBwcm9kdWN0LmlkLCBwYXlsb2FkKSA6IGNyZWF0ZUlGb29kUHJvZHVjdChicmFuY2hJZCwgcGF5bG9hZCk7XHJcbiAgICB9LFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MocHJvZHVjdCA/IFwiUHJvZHV0byBhdHVhbGl6YWRvIG5vIGlGb29kLlwiIDogXCJQcm9kdXRvIGNyaWFkbyBubyBpRm9vZC5cIik7XHJcbiAgICAgIG9uU2F2ZWQoKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBzYWx2YXIgbyBwcm9kdXRvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxNb2RhbCBvbkNsb3NlPXtvbkNsb3NlfSB0aXRsZT17cHJvZHVjdCA/IFwiRWRpdGFyIHByb2R1dG9cIiA6IFwiTm92byBwcm9kdXRvXCJ9PlxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE0LCBtaW5XaWR0aDogMzYwIH19PlxyXG4gICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJOb21lXCIgdmFsdWU9e25hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9IGF1dG9Gb2N1cyAvPlxyXG4gICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJEZXNjcmnDp8OjbyAob3BjaW9uYWwpXCIgdmFsdWU9e2Rlc2NyaXB0aW9ufSBvbkNoYW5nZT17KGUpID0+IHNldERlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiQ8OzZGlnbyBleHRlcm5vIChvcGNpb25hbClcIiB2YWx1ZT17ZXh0ZXJuYWxDb2RlfSBvbkNoYW5nZT17KGUpID0+IHNldEV4dGVybmFsQ29kZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkVBTiAob3BjaW9uYWwpXCIgdmFsdWU9e2Vhbn0gb25DaGFuZ2U9eyhlKSA9PiBzZXRFYW4oZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJVUkwgZGEgaW1hZ2VtIChvcGNpb25hbClcIiB2YWx1ZT17aW1hZ2V9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW1hZ2UoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICBob3LDoXJpb3MgZGUgZGlzcG9uaWJpbGlkYWRlIChzaGlmdHMpIG7Do28gZXN0w6NvIG5lc3RhIHRlbGEg4oCUIHVzZSBvIGNvbnNvbGUgdjEvdjIgcHJhIGNhc29zIGF2YW7Dp2Fkb3MuXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTAsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICBWb2x0YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIGRpc2FibGVkPXshbmFtZS50cmltKCl9IGxvYWRpbmc9e3NhdmVNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHNhdmVNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgIFNhbHZhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9Nb2RhbD5cclxuICApO1xyXG59XHJcblxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gSXRlbnMgKHYyIOKAlCBmbGF0KVxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbmZ1bmN0aW9uIEl0ZW1zVGFiKCkge1xyXG4gIGNvbnN0IHsgYnJhbmNoSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbaXRlbUlkLCBzZXRJdGVtSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3N1Ym1pdHRlZEl0ZW1JZCwgc2V0U3VibWl0dGVkSXRlbUlkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwcmljZVZhbHVlLCBzZXRQcmljZVZhbHVlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtleHRlcm5hbENvZGUsIHNldEV4dGVybmFsQ29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY2F0ZWdvcnlJZCwgc2V0Q2F0ZWdvcnlJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcHJvZHVjdElkLCBzZXRQcm9kdWN0SWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2NhdGVnb3J5SXRlbXNJZCwgc2V0Q2F0ZWdvcnlJdGVtc0lkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzdWJtaXR0ZWRDYXRlZ29yeUl0ZW1zSWQsIHNldFN1Ym1pdHRlZENhdGVnb3J5SXRlbXNJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgaXRlbVF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwiY2F0YWxvZ1wiLCBcIml0ZW1cIiwgYnJhbmNoSWQsIHN1Ym1pdHRlZEl0ZW1JZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZEl0ZW1GbGF0KGJyYW5jaElkLCBzdWJtaXR0ZWRJdGVtSWQpLFxyXG4gICAgZW5hYmxlZDogISFzdWJtaXR0ZWRJdGVtSWQsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGNhdGVnb3J5SXRlbXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImNhdGFsb2dcIiwgXCJjYXRlZ29yeS1pdGVtc1wiLCBicmFuY2hJZCwgc3VibWl0dGVkQ2F0ZWdvcnlJdGVtc0lkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGxpc3RJRm9vZENhdGVnb3J5SXRlbXMoYnJhbmNoSWQsIHN1Ym1pdHRlZENhdGVnb3J5SXRlbXNJZCksXHJcbiAgICBlbmFibGVkOiAhIXN1Ym1pdHRlZENhdGVnb3J5SXRlbXNJZCxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc2V0UHJpY2VNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHNldElGb29kSXRlbVByaWNlKGJyYW5jaElkLCBzdWJtaXR0ZWRJdGVtSWQsIE51bWJlcihwcmljZVZhbHVlKSB8fCAwKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiUHJlw6dvIGRvIGl0ZW0gYXR1YWxpemFkbyBubyBpRm9vZC5cIik7XHJcbiAgICAgIHZvaWQgaXRlbVF1ZXJ5LnJlZmV0Y2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIkZhbGhhIGFvIGF0dWFsaXphciBvIHByZcOnbyBkbyBpdGVtLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc2V0RXh0ZXJuYWxDb2RlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBzZXRJRm9vZEl0ZW1FeHRlcm5hbENvZGUoYnJhbmNoSWQsIHN1Ym1pdHRlZEl0ZW1JZCwgZXh0ZXJuYWxDb2RlLnRyaW0oKSB8fCB1bmRlZmluZWQpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJDw7NkaWdvIGV4dGVybm8gZG8gaXRlbSBhdHVhbGl6YWRvIG5vIGlGb29kLlwiKTtcclxuICAgICAgdm9pZCBpdGVtUXVlcnkucmVmZXRjaCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiRmFsaGEgYW8gYXR1YWxpemFyIG8gY8OzZGlnbyBleHRlcm5vIGRvIGl0ZW0uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBkZWxldGVJdGVtTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBkZWxldGVJRm9vZEl0ZW0oYnJhbmNoSWQsIGNhdGVnb3J5SWQudHJpbSgpLCBwcm9kdWN0SWQudHJpbSgpKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4gdG9hc3Quc3VjY2VzcyhcIkl0ZW0gZXhjbHXDrWRvIG5vIGlGb29kLlwiKSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiRmFsaGEgYW8gZXhjbHVpciBvIGl0ZW0uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBpdGVtID0gaXRlbVF1ZXJ5LmRhdGE7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE4IH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNiwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgPHN0cm9uZz5Db25zdWx0YXIgaXRlbSAoZm9ybWF0byBmbGF0IHYyKTwvc3Ryb25nPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiAxMCwgYWxpZ25JdGVtczogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkl0ZW0gSWRcIiB2YWx1ZT17aXRlbUlkfSBvbkNoYW5nZT17KGUpID0+IHNldEl0ZW1JZChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldFN1Ym1pdHRlZEl0ZW1JZChpdGVtSWQpfT5cclxuICAgICAgICAgICAgQ29uc3VsdGFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7aXRlbVF1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e2l0ZW1RdWVyeS5lcnJvcn0gd2hhdD1cIm8gaXRlbVwiIC8+fVxyXG4gICAgICAgIHtpdGVtICYmIChcclxuICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwidGlja2V0XCIgc3R5bGU9e3sgcGFkZGluZzogMTIsIGZvbnRTaXplOiBcIjAuOHJlbVwiLCBvdmVyZmxvd1g6IFwiYXV0b1wiLCB3aGl0ZVNwYWNlOiBcInByZS13cmFwXCIgfX0+XHJcbiAgICAgICAgICAgIHtwcmV0dHlKc29uKGl0ZW0ucmF3UGF5bG9hZCkgfHwgYCR7aXRlbS5pdGVtSWR9IMK3IHN0YXR1cyAke2l0ZW0uc3RhdHVzfSDCtyBwcmXDp28gJHtpdGVtLnByaWNlVmFsdWV9YH1cclxuICAgICAgICAgIDwvcHJlPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge3N1Ym1pdHRlZEl0ZW1JZCAmJiAoXHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAsIGFsaWduSXRlbXM6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiTm92byBwcmXDp29cIiBpbnB1dE1vZGU9XCJkZWNpbWFsXCIgdmFsdWU9e3ByaWNlVmFsdWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHJpY2VWYWx1ZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBsb2FkaW5nPXtzZXRQcmljZU11dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gc2V0UHJpY2VNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgICAgICBBdHVhbGl6YXIgcHJlw6dvXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAsIGFsaWduSXRlbXM6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiTm92byBjw7NkaWdvIGV4dGVybm9cIiB2YWx1ZT17ZXh0ZXJuYWxDb2RlfSBvbkNoYW5nZT17KGUpID0+IHNldEV4dGVybmFsQ29kZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBsb2FkaW5nPXtzZXRFeHRlcm5hbENvZGVNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHNldEV4dGVybmFsQ29kZU11dGF0aW9uLm11dGF0ZSgpfT5cclxuICAgICAgICAgICAgICAgIEF0dWFsaXphciBjw7NkaWdvIGV4dGVybm9cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICA8c3Ryb25nPkV4Y2x1aXIgaXRlbSBkZSB1bWEgY2F0ZWdvcmlhPC9zdHJvbmc+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwLCBhbGlnbkl0ZW1zOiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiQ2F0ZWdvcnkgSWRcIiB2YWx1ZT17Y2F0ZWdvcnlJZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXRlZ29yeUlkKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJQcm9kdWN0IElkXCIgdmFsdWU9e3Byb2R1Y3RJZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRQcm9kdWN0SWQoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwiZGFuZ2VyXCJcclxuICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYXRlZ29yeUlkLnRyaW0oKSB8fCAhcHJvZHVjdElkLnRyaW0oKX1cclxuICAgICAgICAgICAgbG9hZGluZz17ZGVsZXRlSXRlbU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGVsZXRlSXRlbU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBFeGNsdWlyIGl0ZW1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICA8c3Ryb25nPkl0ZW5zIGRlIHVtYSBjYXRlZ29yaWE8L3N0cm9uZz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAsIGFsaWduSXRlbXM6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJDYXRlZ29yeSBJZFwiIHZhbHVlPXtjYXRlZ29yeUl0ZW1zSWR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2F0ZWdvcnlJdGVtc0lkKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gc2V0U3VibWl0dGVkQ2F0ZWdvcnlJdGVtc0lkKGNhdGVnb3J5SXRlbXNJZCl9PlxyXG4gICAgICAgICAgICBDb25zdWx0YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtjYXRlZ29yeUl0ZW1zUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17Y2F0ZWdvcnlJdGVtc1F1ZXJ5LmVycm9yfSB3aGF0PVwib3MgaXRlbnMgZGEgY2F0ZWdvcmlhXCIgLz59XHJcbiAgICAgICAge2NhdGVnb3J5SXRlbXNRdWVyeS5kYXRhPy5yYXdQYXlsb2FkICYmIChcclxuICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwidGlja2V0XCIgc3R5bGU9e3sgcGFkZGluZzogMTIsIGZvbnRTaXplOiBcIjAuOHJlbVwiLCBvdmVyZmxvd1g6IFwiYXV0b1wiLCB3aGl0ZVNwYWNlOiBcInByZS13cmFwXCIgfX0+XHJcbiAgICAgICAgICAgIHtwcmV0dHlKc29uKGNhdGVnb3J5SXRlbXNRdWVyeS5kYXRhLnJhd1BheWxvYWQpfVxyXG4gICAgICAgICAgPC9wcmU+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gQ29tcGxlbWVudG9zIChncnVwb3MgZGUgb3DDp8O1ZXMgLyBvcMOnw7VlcylcclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG5mdW5jdGlvbiBPcHRpb25Hcm91cHNUYWIoKSB7XHJcbiAgY29uc3QgeyBicmFuY2hJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZTxJRm9vZE9wdGlvbkdyb3VwUmVzcG9uc2UgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbb3B0aW9uSWQsIHNldE9wdGlvbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtvcHRpb25QcmljZSwgc2V0T3B0aW9uUHJpY2VdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW29wdGlvbkV4dGVybmFsQ29kZSwgc2V0T3B0aW9uRXh0ZXJuYWxDb2RlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBncm91cHNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImNhdGFsb2dcIiwgXCJvcHRpb24tZ3JvdXBzXCIsIGJyYW5jaElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGxpc3RJRm9vZE9wdGlvbkdyb3VwcyhicmFuY2hJZCwgdHJ1ZSksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGludmFsaWRhdGUgPSAoKSA9PlxyXG4gICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImNhdGFsb2dcIiwgXCJvcHRpb24tZ3JvdXBzXCJdIH0pO1xyXG5cclxuICBjb25zdCBkZWxldGVHcm91cE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKGlkOiBzdHJpbmcpID0+IGRlbGV0ZUlGb29kT3B0aW9uR3JvdXAoYnJhbmNoSWQsIGlkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiR3J1cG8gZGUgb3DDp8O1ZXMgZXhjbHXDrWRvIG5vIGlGb29kLlwiKTtcclxuICAgICAgaW52YWxpZGF0ZSgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiRmFsaGEgYW8gZXhjbHVpciBvIGdydXBvIGRlIG9ww6fDtWVzLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlU3RhdHVzTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoeyBpZCwgYXZhaWxhYmxlIH06IHsgaWQ6IHN0cmluZzsgYXZhaWxhYmxlOiBib29sZWFuIH0pID0+IHVwZGF0ZUlGb29kT3B0aW9uR3JvdXBTdGF0dXMoYnJhbmNoSWQsIGlkLCBhdmFpbGFibGUpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJTdGF0dXMgZG8gZ3J1cG8gYXR1YWxpemFkbyBubyBpRm9vZC5cIik7XHJcbiAgICAgIGludmFsaWRhdGUoKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIkZhbGhhIGFvIGF0dWFsaXphciBvIHN0YXR1cyBkbyBncnVwby5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHNldE9wdGlvblByaWNlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBzZXRJRm9vZE9wdGlvblByaWNlKGJyYW5jaElkLCBvcHRpb25JZC50cmltKCksIE51bWJlcihvcHRpb25QcmljZSkgfHwgMCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHRvYXN0LnN1Y2Nlc3MoXCJQcmXDp28gZGEgb3DDp8OjbyBhdHVhbGl6YWRvIG5vIGlGb29kLlwiKSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiRmFsaGEgYW8gYXR1YWxpemFyIG8gcHJlw6dvIGRhIG9ww6fDo28uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBzZXRPcHRpb25FeHRlcm5hbENvZGVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHNldElGb29kT3B0aW9uRXh0ZXJuYWxDb2RlKGJyYW5jaElkLCBvcHRpb25JZC50cmltKCksIG9wdGlvbkV4dGVybmFsQ29kZS50cmltKCkpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB0b2FzdC5zdWNjZXNzKFwiQ8OzZGlnbyBleHRlcm5vIGRhIG9ww6fDo28gYXR1YWxpemFkbyBubyBpRm9vZC5cIiksXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIkZhbGhhIGFvIGF0dWFsaXphciBvIGPDs2RpZ28gZXh0ZXJubyBkYSBvcMOnw6NvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlT3B0aW9uU3RhdHVzTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoYXZhaWxhYmxlOiBib29sZWFuKSA9PiBzZXRJRm9vZE9wdGlvblN0YXR1cyhicmFuY2hJZCwgb3B0aW9uSWQudHJpbSgpLCBhdmFpbGFibGUpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB0b2FzdC5zdWNjZXNzKFwiU3RhdHVzIGRhIG9ww6fDo28gYXR1YWxpemFkbyBubyBpRm9vZC5cIiksXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIkZhbGhhIGFvIGF0dWFsaXphciBvIHN0YXR1cyBkYSBvcMOnw6NvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZGVsZXRlT3B0aW9uTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBkZWxldGVJRm9vZE9wdGlvbihicmFuY2hJZCwgZWRpdGluZz8uaWQgPz8gXCJcIiwgb3B0aW9uSWQudHJpbSgpKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4gdG9hc3Quc3VjY2VzcyhcIk9ww6fDo28gZXhjbHXDrWRhIG5vIGlGb29kLlwiKSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiRmFsaGEgYW8gZXhjbHVpciBhIG9ww6fDo28uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBkaXNhc3NvY2lhdGVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICh7IGdyb3VwSWQsIHByb2R1Y3RJZCB9OiB7IGdyb3VwSWQ6IHN0cmluZzsgcHJvZHVjdElkOiBzdHJpbmcgfSkgPT5cclxuICAgICAgZGlzYXNzb2NpYXRlSUZvb2RPcHRpb25Hcm91cChicmFuY2hJZCwgZ3JvdXBJZCwgcHJvZHVjdElkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4gdG9hc3Quc3VjY2VzcyhcIkdydXBvIGRlc2Fzc29jaWFkbyBkbyBwcm9kdXRvIG5vIGlGb29kLlwiKSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiRmFsaGEgYW8gZGVzYXNzb2NpYXIgbyBncnVwbyBkbyBwcm9kdXRvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcmVuYW1lR3JvdXBNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46IChuYW1lOiBzdHJpbmcpID0+IHVwZGF0ZUlGb29kT3B0aW9uR3JvdXAoYnJhbmNoSWQsIGVkaXRpbmc/LmlkID8/IFwiXCIsIG5hbWUpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJOb21lIGRvIGdydXBvIGF0dWFsaXphZG8gbm8gaUZvb2QuXCIpO1xyXG4gICAgICBpbnZhbGlkYXRlKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJGYWxoYSBhbyByZW5vbWVhciBvIGdydXBvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Rpc2Fzc29jaWF0ZVByb2R1Y3RJZCwgc2V0RGlzYXNzb2NpYXRlUHJvZHVjdElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyZW5hbWVWYWx1ZSwgc2V0UmVuYW1lVmFsdWVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IGdyb3VwcyA9IGdyb3Vwc1F1ZXJ5LmRhdGEgPz8gW107XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE4IH19PlxyXG4gICAgICB7Z3JvdXBzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17Z3JvdXBzUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBncnVwb3MgZGUgb3DDp8O1ZXNcIiAvPn1cclxuICAgICAgeyFncm91cHNRdWVyeS5pc0xvYWRpbmcgJiYgZ3JvdXBzLmxlbmd0aCA9PT0gMCAmJiAhZ3JvdXBzUXVlcnkuaXNFcnJvciAmJiAoXHJcbiAgICAgICAgPEVtcHR5U3RhdGUgdGl0bGU9XCJOZW5odW0gZ3J1cG8gZGUgb3DDp8O1ZXNcIiBkZXNjcmlwdGlvbj1cIk5lbmh1bSBncnVwbyBkZSBjb21wbGVtZW50b3MgZW5jb250cmFkbyBubyBpRm9vZC5cIiAvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCB9fT5cclxuICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgIDxzZWN0aW9uIGtleT17Z3JvdXAuaWR9IGNsYXNzTmFtZT1cInRpY2tldCByaXNlXCIgc3R5bGU9e3sgcGFkZGluZzogMTQgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDcwMCB9fT57Z3JvdXAubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOHJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXAuaWR9IMK3IHN0YXR1czoge2dyb3VwLnN0YXR1cyA/PyBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEVkaXRpbmcoZ3JvdXApO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFJlbmFtZVZhbHVlKGdyb3VwLm5hbWUgPz8gXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEdlcmVuY2lhciBvcMOnw7Vlc1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e3RvZ2dsZVN0YXR1c011dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZ3JvdXAuaWQgJiYgdG9nZ2xlU3RhdHVzTXV0YXRpb24ubXV0YXRlKHsgaWQ6IGdyb3VwLmlkLCBhdmFpbGFibGU6IGdyb3VwLnN0YXR1cyAhPT0gXCJBVkFJTEFCTEVcIiB9KX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2dyb3VwLnN0YXR1cyA9PT0gXCJBVkFJTEFCTEVcIiA/IFwiUGF1c2FyXCIgOiBcIlJlYXRpdmFyXCJ9XHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImRhbmdlclwiXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2RlbGV0ZUdyb3VwTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBncm91cC5pZCAmJiBkZWxldGVHcm91cE11dGF0aW9uLm11dGF0ZShncm91cC5pZCl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEV4Y2x1aXJcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7ZWRpdGluZyAmJiAoXHJcbiAgICAgICAgPE1vZGFsIG9uQ2xvc2U9eygpID0+IHNldEVkaXRpbmcobnVsbCl9IHRpdGxlPXtgT3DDp8O1ZXMgZGUgXCIke2VkaXRpbmcubmFtZX1cImB9PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxNCwgbWluV2lkdGg6IDM4MCB9fT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwLCBhbGlnbkl0ZW1zOiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk5vbWUgZG8gZ3J1cG9cIiB2YWx1ZT17cmVuYW1lVmFsdWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVuYW1lVmFsdWUoZS50YXJnZXQudmFsdWUpfSBhdXRvRm9jdXMgLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFyZW5hbWVWYWx1ZS50cmltKCkgfHwgcmVuYW1lVmFsdWUudHJpbSgpID09PSBlZGl0aW5nLm5hbWV9XHJcbiAgICAgICAgICAgICAgICBsb2FkaW5nPXtyZW5hbWVHcm91cE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbmFtZUdyb3VwTXV0YXRpb24ubXV0YXRlKHJlbmFtZVZhbHVlLnRyaW0oKSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgUmVub21lYXJcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8aHIgc3R5bGU9e3sgYm9yZGVyOiBcIm5vbmVcIiwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsIG1hcmdpbjogXCIycHggMFwiIH19IC8+XHJcblxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiT3B0aW9uIElkXCIgdmFsdWU9e29wdGlvbklkfSBvbkNoYW5nZT17KGUpID0+IHNldE9wdGlvbklkKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwLCBhbGlnbkl0ZW1zOiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk5vdm8gcHJlw6dvXCIgaW5wdXRNb2RlPVwiZGVjaW1hbFwiIHZhbHVlPXtvcHRpb25QcmljZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRPcHRpb25QcmljZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshb3B0aW9uSWQudHJpbSgpfVxyXG4gICAgICAgICAgICAgICAgbG9hZGluZz17c2V0T3B0aW9uUHJpY2VNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcHRpb25QcmljZU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEF0dWFsaXphciBwcmXDp29cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiAxMCwgYWxpZ25JdGVtczogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJOb3ZvIGPDs2RpZ28gZXh0ZXJub1wiIHZhbHVlPXtvcHRpb25FeHRlcm5hbENvZGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0T3B0aW9uRXh0ZXJuYWxDb2RlKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFvcHRpb25JZC50cmltKCkgfHwgIW9wdGlvbkV4dGVybmFsQ29kZS50cmltKCl9XHJcbiAgICAgICAgICAgICAgICBsb2FkaW5nPXtzZXRPcHRpb25FeHRlcm5hbENvZGVNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcHRpb25FeHRlcm5hbENvZGVNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBBdHVhbGl6YXIgY8OzZGlnb1xyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW9wdGlvbklkLnRyaW0oKX1cclxuICAgICAgICAgICAgICAgIGxvYWRpbmc9e3RvZ2dsZU9wdGlvblN0YXR1c011dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRvZ2dsZU9wdGlvblN0YXR1c011dGF0aW9uLm11dGF0ZSh0cnVlKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBBdGl2YXIgb3DDp8Ojb1xyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW9wdGlvbklkLnRyaW0oKX1cclxuICAgICAgICAgICAgICAgIGxvYWRpbmc9e3RvZ2dsZU9wdGlvblN0YXR1c011dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRvZ2dsZU9wdGlvblN0YXR1c011dGF0aW9uLm11dGF0ZShmYWxzZSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgUGF1c2FyIG9ww6fDo29cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshb3B0aW9uSWQudHJpbSgpfVxyXG4gICAgICAgICAgICAgICAgbG9hZGluZz17ZGVsZXRlT3B0aW9uTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGVsZXRlT3B0aW9uTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgRXhjbHVpciBvcMOnw6NvXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGhyIHN0eWxlPXt7IGJvcmRlcjogXCJub25lXCIsIGJvcmRlclRvcDogXCIxcHggc29saWQgdmFyKC0tYm9yZGVyKVwiLCBtYXJnaW46IFwiNnB4IDBcIiB9fSAvPlxyXG5cclxuICAgICAgICAgICAgPHN0cm9uZyBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5EZXNhc3NvY2lhciBlc3RlIGdydXBvIGRlIHVtIHByb2R1dG88L3N0cm9uZz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwLCBhbGlnbkl0ZW1zOiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlByb2R1Y3QgSWRcIiB2YWx1ZT17ZGlzYXNzb2NpYXRlUHJvZHVjdElkfSBvbkNoYW5nZT17KGUpID0+IHNldERpc2Fzc29jaWF0ZVByb2R1Y3RJZChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshZGlzYXNzb2NpYXRlUHJvZHVjdElkLnRyaW0oKX1cclxuICAgICAgICAgICAgICAgIGxvYWRpbmc9e2Rpc2Fzc29jaWF0ZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgIGVkaXRpbmcuaWQgJiYgZGlzYXNzb2NpYXRlTXV0YXRpb24ubXV0YXRlKHsgZ3JvdXBJZDogZWRpdGluZy5pZCwgcHJvZHVjdElkOiBkaXNhc3NvY2lhdGVQcm9kdWN0SWQudHJpbSgpIH0pXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgRGVzYXNzb2NpYXJcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiLCBtYXJnaW5Ub3A6IDYgfX0+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRFZGl0aW5nKG51bGwpfT5cclxuICAgICAgICAgICAgICAgIEZlY2hhclxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gQWRtaW5pc3RyYcOnw6NvIChlc3RvcXVlLCBsb3RlLCB2ZXJzw6NvIGRvIGNhdMOhbG9nbywgaW1hZ2VtKVxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbmZ1bmN0aW9uIEFkbWluVGFiKCkge1xyXG4gIGNvbnN0IHsgYnJhbmNoSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbaW52ZW50b3J5UHJvZHVjdElkLCBzZXRJbnZlbnRvcnlQcm9kdWN0SWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3N1Ym1pdHRlZEludmVudG9yeUlkLCBzZXRTdWJtaXR0ZWRJbnZlbnRvcnlJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYmF0Y2hEZWxldGVJZHMsIHNldEJhdGNoRGVsZXRlSWRzXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtiYXRjaFJlc3VsdElkLCBzZXRCYXRjaFJlc3VsdElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzdWJtaXR0ZWRCYXRjaFJlc3VsdElkLCBzZXRTdWJtaXR0ZWRCYXRjaFJlc3VsdElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpbWFnZUpzb25Cb2R5LCBzZXRJbWFnZUpzb25Cb2R5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjb25maXJtaW5nVXBncmFkZSwgc2V0Q29uZmlybWluZ1VwZ3JhZGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjb25maXJtaW5nRG93bmdyYWRlLCBzZXRDb25maXJtaW5nRG93bmdyYWRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgdmVyc2lvblF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwiY2F0YWxvZ1wiLCBcInZlcnNpb25cIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gY2hlY2tJRm9vZENhdGFsb2dWZXJzaW9uKGJyYW5jaElkKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgaW52ZW50b3J5UXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJjYXRhbG9nXCIsIFwiaW52ZW50b3J5XCIsIGJyYW5jaElkLCBzdWJtaXR0ZWRJbnZlbnRvcnlJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZEludmVudG9yeShicmFuY2hJZCwgc3VibWl0dGVkSW52ZW50b3J5SWQpLFxyXG4gICAgZW5hYmxlZDogISFzdWJtaXR0ZWRJbnZlbnRvcnlJZCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgYmF0Y2hSZXN1bHRRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImNhdGFsb2dcIiwgXCJiYXRjaC1yZXN1bHRcIiwgYnJhbmNoSWQsIHN1Ym1pdHRlZEJhdGNoUmVzdWx0SWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RCYXRjaFJlc3VsdChicmFuY2hJZCwgc3VibWl0dGVkQmF0Y2hSZXN1bHRJZCksXHJcbiAgICBlbmFibGVkOiAhIXN1Ym1pdHRlZEJhdGNoUmVzdWx0SWQsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGRlbGV0ZUludmVudG9yeUJhdGNoTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICBkZWxldGVJRm9vZEludmVudG9yeUJhdGNoKFxyXG4gICAgICAgIGJyYW5jaElkLFxyXG4gICAgICAgIGJhdGNoRGVsZXRlSWRzLnNwbGl0KFwiLFwiKS5tYXAoKGlkKSA9PiBpZC50cmltKCkpLmZpbHRlcihCb29sZWFuKSxcclxuICAgICAgKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4gdG9hc3Quc3VjY2VzcyhcIkVzdG9xdWUgcmVtb3ZpZG8gZW0gbG90ZSBubyBpRm9vZC5cIiksXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIkZhbGhhIGFvIHJlbW92ZXIgZXN0b3F1ZSBlbSBsb3RlLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgdXBncmFkZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gdXBncmFkZUlGb29kQ2F0YWxvZ1ZlcnNpb24oYnJhbmNoSWQpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJDYXTDoWxvZ28gbWlncmFkbyBwYXJhIHYyIG5vIGlGb29kLlwiKTtcclxuICAgICAgc2V0Q29uZmlybWluZ1VwZ3JhZGUoZmFsc2UpO1xyXG4gICAgICB2b2lkIHZlcnNpb25RdWVyeS5yZWZldGNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJGYWxoYSBhbyBtaWdyYXIgbyBjYXTDoWxvZ28gcGFyYSB2Mi5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGRvd25ncmFkZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gZG93bmdyYWRlSUZvb2RDYXRhbG9nVmVyc2lvbihicmFuY2hJZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNhdMOhbG9nbyByZXZlcnRpZG8gcGFyYSB2MSBubyBpRm9vZC5cIik7XHJcbiAgICAgIHNldENvbmZpcm1pbmdEb3duZ3JhZGUoZmFsc2UpO1xyXG4gICAgICB2b2lkIHZlcnNpb25RdWVyeS5yZWZldGNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJGYWxoYSBhbyByZXZlcnRlciBvIGNhdMOhbG9nbyBwYXJhIHYxLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgdXBsb2FkSW1hZ2VNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHVwbG9hZElGb29kSW1hZ2UoYnJhbmNoSWQsIGltYWdlSnNvbkJvZHkpLFxyXG4gICAgb25TdWNjZXNzOiAocmVzdWx0KSA9PiB0b2FzdC5zdWNjZXNzKGBJbWFnZW0gZW52aWFkYS4gUmVzcG9zdGE6ICR7cHJldHR5SnNvbihyZXN1bHQucmF3UGF5bG9hZCkuc2xpY2UoMCwgMTIwKSB8fCBcIih2YXppYSlcIn1gKSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiRmFsaGEgYW8gZW52aWFyIGEgaW1hZ2VtIOKAlCBjb25maXJhIG8gSlNPTi5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGludmVudG9yeSA9IGludmVudG9yeVF1ZXJ5LmRhdGE7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE4IH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNiwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgPHN0cm9uZz5WZXJzw6NvIGRvIGNhdMOhbG9nbzwvc3Ryb25nPlxyXG4gICAgICAgIHt2ZXJzaW9uUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17dmVyc2lvblF1ZXJ5LmVycm9yfSB3aGF0PVwiYSB2ZXJzw6NvIGRvIGNhdMOhbG9nb1wiIC8+fVxyXG4gICAgICAgIDxzcGFuPlZlcnPDo28gYXR1YWw6IHt2ZXJzaW9uUXVlcnkuZGF0YT8udmVyc2lvbiA/PyBcIuKAlFwifTwvc3Bhbj5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAg4pqg77iPIHVwZ3JhZGUvZG93bmdyYWRlIHPDo28gb3BlcmHDp8O1ZXMgZGVzdHJ1dGl2YXMgZSBpcnJldmVyc8OtdmVpcyBjb250cmEgbyBjYXTDoWxvZ28gcmVhbCBkbyBtZXJjaGFudCBub1xyXG4gICAgICAgICAgaUZvb2Qg4oCUIGNvbmZpcm1lIGNvbSBhdGVuw6fDo28uXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiAxMCB9fT5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gc2V0Q29uZmlybWluZ1VwZ3JhZGUodHJ1ZSl9PlxyXG4gICAgICAgICAgICBNaWdyYXIgcGFyYSB2MiAodXBncmFkZSlcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRDb25maXJtaW5nRG93bmdyYWRlKHRydWUpfT5cclxuICAgICAgICAgICAgUmV2ZXJ0ZXIgcGFyYSB2MSAoZG93bmdyYWRlKVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogMTYsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgIDxzdHJvbmc+RXN0b3F1ZTwvc3Ryb25nPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiAxMCwgYWxpZ25JdGVtczogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlByb2R1Y3QgSWRcIiB2YWx1ZT17aW52ZW50b3J5UHJvZHVjdElkfSBvbkNoYW5nZT17KGUpID0+IHNldEludmVudG9yeVByb2R1Y3RJZChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldFN1Ym1pdHRlZEludmVudG9yeUlkKGludmVudG9yeVByb2R1Y3RJZCl9PlxyXG4gICAgICAgICAgICBDb25zdWx0YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtpbnZlbnRvcnlRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtpbnZlbnRvcnlRdWVyeS5lcnJvcn0gd2hhdD1cIm8gZXN0b3F1ZVwiIC8+fVxyXG4gICAgICAgIHtpbnZlbnRvcnkgJiYgKFxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgICBRdWFudGlkYWRlOiB7aW52ZW50b3J5LmFtb3VudCA/PyBcIuKAlFwifSDCtyBlbSBlc3RvcXVlOiB7aW52ZW50b3J5LmluU3RvY2sgPyBcInNpbVwiIDogXCJuw6NvXCJ9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAsIGFsaWduSXRlbXM6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgbGFiZWw9XCJSZW1vdmVyIGVzdG9xdWUgZW0gbG90ZSAoSWRzIHNlcGFyYWRvcyBwb3IgdsOtcmd1bGEpXCJcclxuICAgICAgICAgICAgdmFsdWU9e2JhdGNoRGVsZXRlSWRzfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJhdGNoRGVsZXRlSWRzKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJkYW5nZXJcIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17IWJhdGNoRGVsZXRlSWRzLnRyaW0oKX1cclxuICAgICAgICAgICAgbG9hZGluZz17ZGVsZXRlSW52ZW50b3J5QmF0Y2hNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRlbGV0ZUludmVudG9yeUJhdGNoTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFJlbW92ZXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICA8c3Ryb25nPlJlc3VsdGFkbyBkZSBwcm9jZXNzYW1lbnRvIGVtIGxvdGU8L3N0cm9uZz5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgIHVzZSBvIEJhdGNoSWQgZGV2b2x2aWRvIHBvciB1bWEgYXR1YWxpemHDp8OjbyBkZSBwcmXDp29zIGVtIGxvdGUgKGFiYSBQcm9kdXRvcykuXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiAxMCwgYWxpZ25JdGVtczogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkJhdGNoIElkXCIgdmFsdWU9e2JhdGNoUmVzdWx0SWR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QmF0Y2hSZXN1bHRJZChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldFN1Ym1pdHRlZEJhdGNoUmVzdWx0SWQoYmF0Y2hSZXN1bHRJZCl9PlxyXG4gICAgICAgICAgICBDb25zdWx0YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtiYXRjaFJlc3VsdFF1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e2JhdGNoUmVzdWx0UXVlcnkuZXJyb3J9IHdoYXQ9XCJvIHJlc3VsdGFkbyBkbyBsb3RlXCIgLz59XHJcbiAgICAgICAge2JhdGNoUmVzdWx0UXVlcnkuZGF0YSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuPlN0YXR1czoge2JhdGNoUmVzdWx0UXVlcnkuZGF0YS5iYXRjaFN0YXR1cyA/PyBcIuKAlFwifTwvc3Bhbj5cclxuICAgICAgICAgICAge2JhdGNoUmVzdWx0UXVlcnkuZGF0YS5yZXN1bHRzLm1hcCgociwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpZHh9IHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICB7ci5yZXNvdXJjZUlkfToge3IucmVzdWx0fSB7ci5mYWlsdXJlUmVhc29uID8gYCgke3IuZmFpbHVyZVJlYXNvbn0pYCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogMTYsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgIDxzdHJvbmc+VXBsb2FkIGRlIGltYWdlbTwvc3Ryb25nPlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICDimqDvuI8gYSBkb2Mgb2ZpY2lhbCBuw6NvIGRvY3VtZW50YSBvIHNjaGVtYSBkZXN0ZSBlbmRwb2ludCDigJQgY29sZSBvIEpTT04gcHJvbnRvIHF1ZSBvIGlGb29kIGVzcGVyYTsgYVxyXG4gICAgICAgICAgcmVzcG9zdGEgY3J1YSBhcGFyZWNlIGFww7NzIG8gZW52aW8uXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgdmFsdWU9e2ltYWdlSnNvbkJvZHl9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEltYWdlSnNvbkJvZHkoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgcm93cz17NX1cclxuICAgICAgICAgIHBsYWNlaG9sZGVyPSd7XCJpbWFnZVwiOiBcIi4uLlwifSdcclxuICAgICAgICAgIHN0eWxlPXt7IGZvbnRGYW1pbHk6IFwibW9ub3NwYWNlXCIsIGZvbnRTaXplOiBcIjAuOHJlbVwiLCBwYWRkaW5nOiA4IH19XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17IWltYWdlSnNvbkJvZHkudHJpbSgpfVxyXG4gICAgICAgICAgICBsb2FkaW5nPXt1cGxvYWRJbWFnZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBsb2FkSW1hZ2VNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgRW52aWFyIGltYWdlbVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge2NvbmZpcm1pbmdVcGdyYWRlICYmIChcclxuICAgICAgICA8TW9kYWwgb25DbG9zZT17KCkgPT4gc2V0Q29uZmlybWluZ1VwZ3JhZGUoZmFsc2UpfSB0aXRsZT1cIkNvbmZpcm1hciBtaWdyYcOnw6NvIHBhcmEgdjJcIj5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQsIG1pbldpZHRoOiAzMjAgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgIEVzdGEgYcOnw6NvIMOpIDxzdHJvbmc+ZGVzdHJ1dGl2YSBlIGlycmV2ZXJzw612ZWw8L3N0cm9uZz4g4oCUIG8gaUZvb2QgdmFpIHJlb3JnYW5pemFyIHRvZG8gbyBjYXTDoWxvZ28gcmVhbFxyXG4gICAgICAgICAgICAgIGRvIG1lcmNoYW50IGRlc3RhIGZpbGlhbCBkZSB2MSBwYXJhIHYyLiBDb25maXJtYT9cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEwLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gc2V0Q29uZmlybWluZ1VwZ3JhZGUoZmFsc2UpfT5cclxuICAgICAgICAgICAgICAgIENhbmNlbGFyXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZGFuZ2VyXCIgbG9hZGluZz17dXBncmFkZU11dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gdXBncmFkZU11dGF0aW9uLm11dGF0ZSgpfT5cclxuICAgICAgICAgICAgICAgIENvbmZpcm1hciBtaWdyYcOnw6NvXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtjb25maXJtaW5nRG93bmdyYWRlICYmIChcclxuICAgICAgICA8TW9kYWwgb25DbG9zZT17KCkgPT4gc2V0Q29uZmlybWluZ0Rvd25ncmFkZShmYWxzZSl9IHRpdGxlPVwiQ29uZmlybWFyIHJldmVyc8OjbyBwYXJhIHYxXCI+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE0LCBtaW5XaWR0aDogMzIwIH19PlxyXG4gICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICBFc3RhIGHDp8OjbyDDqSA8c3Ryb25nPmRlc3RydXRpdmEgZSBpcnJldmVyc8OtdmVsPC9zdHJvbmc+IOKAlCBvIGlGb29kIHZhaSByZW9yZ2FuaXphciB0b2RvIG8gY2F0w6Fsb2dvIHJlYWxcclxuICAgICAgICAgICAgICBkbyBtZXJjaGFudCBkZXN0YSBmaWxpYWwgZGUgdjIgcGFyYSB2MS4gQ29uZmlybWE/XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldENvbmZpcm1pbmdEb3duZ3JhZGUoZmFsc2UpfT5cclxuICAgICAgICAgICAgICAgIENhbmNlbGFyXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZGFuZ2VyXCIgbG9hZGluZz17ZG93bmdyYWRlTXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBkb3duZ3JhZGVNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgICAgICBDb25maXJtYXIgcmV2ZXJzw6NvXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyBDb25zb2xlIHYxIChsZWdhZG8pXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuZnVuY3Rpb24gVjFDb25zb2xlVGFiKCkge1xyXG4gIGNvbnN0IHsgYnJhbmNoSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbb3BlcmF0aW9uLCBzZXRPcGVyYXRpb25dID0gdXNlU3RhdGU8SUZvb2RDYXRhbG9nVjFPcGVyYXRpb24+KElGT09EX0NBVEFMT0dfVjFfT1BFUkFUSU9OU1swXSk7XHJcbiAgY29uc3QgW3JvdXRlUGFyYW1zVGV4dCwgc2V0Um91dGVQYXJhbXNUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtxdWVyeVBhcmFtc1RleHQsIHNldFF1ZXJ5UGFyYW1zVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbanNvbkJvZHksIHNldEpzb25Cb2R5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBpbnZva2VNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHtcclxuICAgICAgbGV0IHJvdXRlUGFyYW1zOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHwgdW5kZWZpbmVkO1xyXG4gICAgICBsZXQgcXVlcnlQYXJhbXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gfCB1bmRlZmluZWQ7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgcm91dGVQYXJhbXMgPSByb3V0ZVBhcmFtc1RleHQudHJpbSgpID8gSlNPTi5wYXJzZShyb3V0ZVBhcmFtc1RleHQpIDogdW5kZWZpbmVkO1xyXG4gICAgICAgIHF1ZXJ5UGFyYW1zID0gcXVlcnlQYXJhbXNUZXh0LnRyaW0oKSA/IEpTT04ucGFyc2UocXVlcnlQYXJhbXNUZXh0KSA6IHVuZGVmaW5lZDtcclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiaW52YWxpZC1qc29uXCIpO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBpbnZva2VJRm9vZENhdGFsb2dWMU9wZXJhdGlvbihicmFuY2hJZCwgb3BlcmF0aW9uLCB7XHJcbiAgICAgICAgcm91dGVQYXJhbXMsXHJcbiAgICAgICAgcXVlcnlQYXJhbXMsXHJcbiAgICAgICAganNvbkJvZHk6IGpzb25Cb2R5LnRyaW0oKSB8fCB1bmRlZmluZWQsXHJcbiAgICAgIH0pO1xyXG4gICAgfSxcclxuICAgIG9uU3VjY2VzczogKHJlc3VsdCkgPT4ge1xyXG4gICAgICBpZiAocmVzdWx0LnN1Y2Nlc3MpIHRvYXN0LnN1Y2Nlc3MoYENoYW1hZGEgdjEgY29uY2x1w61kYSAoSFRUUCAke3Jlc3VsdC5zdGF0dXNDb2RlfSkuYCk7XHJcbiAgICAgIGVsc2UgdG9hc3QuZXJyb3IoYGlGb29kIHJlc3BvbmRldSBjb20gZXJybyAoSFRUUCAke3Jlc3VsdC5zdGF0dXNDb2RlfSkg4oCUIHZlamEgbyBwYXlsb2FkIGFiYWl4by5gKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoZXJyb3I6IHVua25vd24pID0+XHJcbiAgICAgIHRvYXN0LmVycm9yKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgJiYgZXJyb3IubWVzc2FnZSA9PT0gXCJpbnZhbGlkLWpzb25cIiA/IFwicm91dGVQYXJhbXMvcXVlcnlQYXJhbXMgcHJlY2lzYW0gc2VyIEpTT04gdsOhbGlkby5cIiA6IFwiRmFsaGEgYW8gY2hhbWFyIG8gZW5kcG9pbnQgdjEuXCIpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxOCB9fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogMTYsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgIDxzdHJvbmc+Q29uc29sZSBnZW7DqXJpY28g4oCUIG3Ds2R1bG8gQ2F0YWxvZyB2MSAobGVnYWRvKTwvc3Ryb25nPlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgdXNlIGVzdGEgdGVsYSBhcGVuYXMgc2UgbyBtZXJjaGFudCBkZXN0YSBmaWxpYWwgYWluZGEgZXN0aXZlciBuYSB2ZXJzw6NvIHYxIGRvIGNhdMOhbG9nbyAodmVyIGFiYVxyXG4gICAgICAgICAgQWRtaW5pc3RyYcOnw6NvIOKGkiBcIlZlcnPDo28gZG8gY2F0w6Fsb2dvXCIpLiBDb2JyZSBvcyA1NiBlbmRwb2ludHMgbGVnYWRvcyBzZW0gdGVsYSBkZWRpY2FkYSDigJQgZXNjb2xoYSBhXHJcbiAgICAgICAgICBvcGVyYcOnw6NvLCBpbmZvcm1lIG9zIHBhcsOibWV0cm9zIGRlIHJvdGEvcXVlcnkgKGNvbW8gSlNPTikgZSBvIGNvcnBvIChxdWFuZG8gYXBsaWPDoXZlbCkuIEEgcmVzcG9zdGEsXHJcbiAgICAgICAgICBpbmNsdXNpdmUgZXJyb3MgZG8gaUZvb2QsIMOpIHNlbXByZSBtb3N0cmFkYSBjcnVhIGFiYWl4by5cclxuICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgIDxTZWxlY3RGaWVsZFxyXG4gICAgICAgICAgbGFiZWw9XCJPcGVyYcOnw6NvXCJcclxuICAgICAgICAgIHZhbHVlPXtvcGVyYXRpb259XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE9wZXJhdGlvbihlLnRhcmdldC52YWx1ZSBhcyBJRm9vZENhdGFsb2dWMU9wZXJhdGlvbil9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge0lGT09EX0NBVEFMT0dfVjFfT1BFUkFUSU9OUy5tYXAoKG9wKSA9PiAoXHJcbiAgICAgICAgICAgIDxvcHRpb24ga2V5PXtvcH0gdmFsdWU9e29wfT5cclxuICAgICAgICAgICAgICB7b3B9XHJcbiAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9TZWxlY3RGaWVsZD5cclxuXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODVyZW1cIiwgZm9udFdlaWdodDogNjAwIH19PlJvdXRlIHBhcmFtcyAoSlNPTiwgb3BjaW9uYWwpPC9sYWJlbD5cclxuICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICB2YWx1ZT17cm91dGVQYXJhbXNUZXh0fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJvdXRlUGFyYW1zVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHJvd3M9ezJ9XHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPSd7XCJjYXRlZ29yeUlkXCI6IFwiLi4uXCJ9J1xyXG4gICAgICAgICAgICBzdHlsZT17eyBmb250RmFtaWx5OiBcIm1vbm9zcGFjZVwiLCBmb250U2l6ZTogXCIwLjhyZW1cIiwgcGFkZGluZzogOCB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODVyZW1cIiwgZm9udFdlaWdodDogNjAwIH19PlF1ZXJ5IHBhcmFtcyAoSlNPTiwgb3BjaW9uYWwpPC9sYWJlbD5cclxuICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICB2YWx1ZT17cXVlcnlQYXJhbXNUZXh0fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFF1ZXJ5UGFyYW1zVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHJvd3M9ezJ9XHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPSd7XCJwYWdlXCI6IFwiMVwifSdcclxuICAgICAgICAgICAgc3R5bGU9e3sgZm9udEZhbWlseTogXCJtb25vc3BhY2VcIiwgZm9udFNpemU6IFwiMC44cmVtXCIsIHBhZGRpbmc6IDggfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCB9fT5Db3JwbyBKU09OIChvcGNpb25hbCDigJQgUE9TVC9QVVQvUEFUQ0gpPC9sYWJlbD5cclxuICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICB2YWx1ZT17anNvbkJvZHl9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SnNvbkJvZHkoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICByb3dzPXs2fVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj0ne1wibmFtZVwiOiBcIi4uLlwifSdcclxuICAgICAgICAgICAgc3R5bGU9e3sgZm9udEZhbWlseTogXCJtb25vc3BhY2VcIiwgZm9udFNpemU6IFwiMC44cmVtXCIsIHBhZGRpbmc6IDggfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgbG9hZGluZz17aW52b2tlTXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBpbnZva2VNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgIENoYW1hciBpRm9vZFxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHtpbnZva2VNdXRhdGlvbi5kYXRhICYmIChcclxuICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwidGlja2V0XCIgc3R5bGU9e3sgcGFkZGluZzogMTIsIGZvbnRTaXplOiBcIjAuOHJlbVwiLCBvdmVyZmxvd1g6IFwiYXV0b1wiLCB3aGl0ZVNwYWNlOiBcInByZS13cmFwXCIgfX0+XHJcbiAgICAgICAgICAgIHtgSFRUUCAke2ludm9rZU11dGF0aW9uLmRhdGEuc3RhdHVzQ29kZX0ke2ludm9rZU11dGF0aW9uLmRhdGEuZXJyb3JNZXNzYWdlID8gYCDigJQgJHtpbnZva2VNdXRhdGlvbi5kYXRhLmVycm9yTWVzc2FnZX1gIDogXCJcIn1cXG5cXG4ke3ByZXR0eUpzb24oaW52b2tlTXV0YXRpb24uZGF0YS5yZXNwb25zZUJvZHkpfWB9XHJcbiAgICAgICAgICA8L3ByZT5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2ludGVncmF0aW9ucy9JRm9vZENhdGFsb2dQYWdlLnRzeCJ9