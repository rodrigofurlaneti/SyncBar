import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodLogisticsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  assignIFoodDriver,
  dispatchIFoodLogistics,
  getIFoodLogisticsDeliveries,
  getIFoodLogisticsOrderDetails,
  getIFoodOrders,
  markIFoodArrivedAtDestination,
  markIFoodArrivedAtOrigin,
  markIFoodGoingToOrigin,
  verifyIFoodDeliveryCode
} from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useToast } from "/src/ui/Toast.tsx";
import { Button } from "/src/ui/Button.tsx";
import { StatusBadge } from "/src/ui/StatusBadge.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { SelectField, TextField } from "/src/ui/Field.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
const REFRESH_INTERVAL_MS = 2e4;
const STATUS_LABEL = {
  DRIVER_ASSIGNED: "Entregador atribuído",
  GOING_TO_ORIGIN: "A caminho da loja",
  ARRIVED_AT_ORIGIN: "Chegou na loja",
  DISPATCHED: "Despachado",
  ARRIVED_AT_DESTINATION: "Chegou no destino",
  DELIVERY_CODE_VERIFIED: "Entrega confirmada"
};
const STATUS_COLOR = {
  DRIVER_ASSIGNED: "var(--ink-faint)",
  GOING_TO_ORIGIN: "var(--warn, #d97706)",
  ARRIVED_AT_ORIGIN: "var(--warn, #d97706)",
  DISPATCHED: "var(--warn, #d97706)",
  ARRIVED_AT_DESTINATION: "var(--warn, #d97706)",
  DELIVERY_CODE_VERIFIED: "var(--ok)"
};
export function IFoodLogisticsPage() {
  _s();
  const queryClient = useQueryClient();
  const { branchId } = useAuthStore();
  const [assigning, setAssigning] = useState(null);
  const [verifying, setVerifying] = useState(null);
  const [detailsFor, setDetailsFor] = useState(null);
  const deliveriesQuery = useQuery({
    queryKey: ["integrations", "ifood", "logistics", branchId],
    queryFn: () => getIFoodLogisticsDeliveries(branchId),
    refetchInterval: REFRESH_INTERVAL_MS
  });
  const ordersQuery = useQuery({
    queryKey: ["integrations", "ifood", "orders", branchId],
    queryFn: () => getIFoodOrders(branchId),
    refetchInterval: REFRESH_INTERVAL_MS
  });
  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "logistics"] });
    void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "orders"] });
  };
  const deliveries = deliveriesQuery.data ?? [];
  const assignedIFoodOrderIds = new Set(deliveries.map((d) => d.ifoodOrderId));
  const eligibleOrders = (ordersQuery.data ?? []).filter(
    (o) => o.deliveredBy != null && o.deliveredBy !== "IFOOD" && o.status !== "CANCELLED" && o.status !== "CONCLUDED" && !assignedIFoodOrderIds.has(o.id)
  );
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1e3, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood", style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "← Integração iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Logística (frota própria)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
          lineNumber: 116,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "entregue pedidos do iFood com a equipe da própria casa — atribua o entregador e avise cada passo pro iFood" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
          lineNumber: 119,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 115,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 111,
      columnNumber: 7
    }, this),
    (deliveriesQuery.isError || ordersQuery.isError) && /* @__PURE__ */ jsxDEV(QueryError, { error: deliveriesQuery.error ?? ordersQuery.error, what: "a logística do iFood" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { style: { marginBottom: 22 }, children: [
      /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.15rem", display: "block", marginBottom: 10 }, children: "Aguardando entregador" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 131,
        columnNumber: 9
      }, this),
      !ordersQuery.isLoading && eligibleOrders.length === 0 && /* @__PURE__ */ jsxDEV(
        EmptyState,
        {
          title: "Nenhum pedido esperando entregador",
          description: "Pedidos do iFood marcados para entrega por frota própria aparecem aqui assim que confirmados."
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
          lineNumber: 135,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10 }, children: eligibleOrders.map(
        (order) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "ticket rise",
            style: { padding: 16, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" },
            children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
                /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 700 }, children: [
                  order.displayId ?? `Pedido #${order.id}`,
                  " — ",
                  order.customerName
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
                  lineNumber: 148,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: order.deliveryAddress }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
                  lineNumber: 151,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
                lineNumber: 147,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => setAssigning(order), children: "Atribuir entregador" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
                lineNumber: 153,
                columnNumber: 15
              }, this)
            ]
          },
          order.id,
          true,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
            lineNumber: 142,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 140,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 130,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.15rem", display: "block", marginBottom: 10 }, children: "Entregas em andamento" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 162,
        columnNumber: 9
      }, this),
      !deliveriesQuery.isLoading && deliveries.length === 0 && /* @__PURE__ */ jsxDEV(
        EmptyState,
        {
          title: "Nenhuma entrega em andamento",
          description: "Assim que um entregador for atribuído a um pedido, o acompanhamento aparece aqui."
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
          lineNumber: 166,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12 }, children: deliveries.map(
        (delivery) => /* @__PURE__ */ jsxDEV(
          LogisticsDeliveryCard,
          {
            delivery,
            onAdvanced: invalidate,
            onVerifyCode: () => setVerifying(delivery),
            onViewDetails: () => setDetailsFor(delivery)
          },
          delivery.id,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
            lineNumber: 173,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 171,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 161,
      columnNumber: 7
    }, this),
    detailsFor && /* @__PURE__ */ jsxDEV(LogisticsOrderDetailsModal, { delivery: detailsFor, onClose: () => setDetailsFor(null) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 184,
      columnNumber: 22
    }, this),
    assigning && /* @__PURE__ */ jsxDEV(
      AssignDriverModal,
      {
        order: assigning,
        onClose: () => setAssigning(null),
        onAssigned: () => {
          setAssigning(null);
          invalidate();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 187,
        columnNumber: 7
      },
      this
    ),
    verifying && /* @__PURE__ */ jsxDEV(
      VerifyCodeModal,
      {
        delivery: verifying,
        onClose: () => setVerifying(null),
        onVerified: () => {
          setVerifying(null);
          invalidate();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 198,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
    lineNumber: 110,
    columnNumber: 5
  }, this);
}
_s(IFoodLogisticsPage, "JsdD1nTqAvroCmoNI6HIzf/1HEw=", false, function() {
  return [useQueryClient, useAuthStore, useQuery, useQuery];
});
_c = IFoodLogisticsPage;
function LogisticsDeliveryCard({
  delivery,
  onAdvanced,
  onVerifyCode,
  onViewDetails
}) {
  _s2();
  const toast = useToast();
  const goingToOriginMutation = useMutation({
    mutationFn: () => markIFoodGoingToOrigin(delivery.ifoodOrderId),
    onSuccess: onAdvanced,
    onError: () => toast.error("Não foi possível avançar — confira se o pedido ainda está ativo.")
  });
  const arrivedAtOriginMutation = useMutation({
    mutationFn: () => markIFoodArrivedAtOrigin(delivery.ifoodOrderId),
    onSuccess: onAdvanced,
    onError: () => toast.error("Não foi possível avançar — confira se o pedido ainda está ativo.")
  });
  const dispatchMutation = useMutation({
    mutationFn: () => dispatchIFoodLogistics(delivery.ifoodOrderId),
    onSuccess: onAdvanced,
    onError: () => toast.error("Não foi possível avançar — confira se o pedido ainda está ativo.")
  });
  const arrivedAtDestinationMutation = useMutation({
    mutationFn: () => markIFoodArrivedAtDestination(delivery.ifoodOrderId),
    onSuccess: onAdvanced,
    onError: () => toast.error("Não foi possível avançar — confira se o pedido ainda está ativo.")
  });
  const pending = goingToOriginMutation.isPending || arrivedAtOriginMutation.isPending || dispatchMutation.isPending || arrivedAtDestinationMutation.isPending;
  return /* @__PURE__ */ jsxDEV("section", { className: "ticket rise", style: { padding: 18, display: "grid", gap: 10 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 700, fontSize: "1.05rem" }, children: [
          delivery.ifoodOrderDisplayId ?? `Pedido #${delivery.ifoodOrderId}`,
          delivery.customerName ? ` — ${delivery.customerName}` : ""
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
          lineNumber: 252,
          columnNumber: 11
        }, this),
        delivery.deliveryAddress && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: delivery.deliveryAddress }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
          lineNumber: 256,
          columnNumber: 40
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.82rem" }, children: [
          delivery.driverName,
          " · ",
          delivery.driverPhone,
          " · ",
          delivery.driverVehicleType
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
          lineNumber: 257,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 251,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StatusBadge, { color: STATUS_COLOR[delivery.status] ?? "var(--ink-faint)", children: STATUS_LABEL[delivery.status] ?? delivery.status }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 261,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 250,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end", flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onViewDetails, children: "Ver detalhes no iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 267,
        columnNumber: 9
      }, this),
      delivery.status === "DRIVER_ASSIGNED" && /* @__PURE__ */ jsxDEV(Button, { variant: "primary", loading: goingToOriginMutation.isPending, disabled: pending, onClick: () => goingToOriginMutation.mutate(), children: "Saiu para a loja" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 271,
        columnNumber: 9
      }, this),
      delivery.status === "GOING_TO_ORIGIN" && /* @__PURE__ */ jsxDEV(Button, { variant: "primary", loading: arrivedAtOriginMutation.isPending, disabled: pending, onClick: () => arrivedAtOriginMutation.mutate(), children: "Chegou na loja" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 276,
        columnNumber: 9
      }, this),
      delivery.status === "ARRIVED_AT_ORIGIN" && /* @__PURE__ */ jsxDEV(Button, { variant: "primary", loading: dispatchMutation.isPending, disabled: pending, onClick: () => dispatchMutation.mutate(), children: "Despachar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 281,
        columnNumber: 9
      }, this),
      delivery.status === "DISPATCHED" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          loading: arrivedAtDestinationMutation.isPending,
          disabled: pending,
          onClick: () => arrivedAtDestinationMutation.mutate(),
          children: "Chegou no destino"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
          lineNumber: 286,
          columnNumber: 9
        },
        this
      ),
      delivery.status === "ARRIVED_AT_DESTINATION" && /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: onVerifyCode, children: "Verificar código de entrega" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 296,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 266,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
    lineNumber: 249,
    columnNumber: 5
  }, this);
}
_s2(LogisticsDeliveryCard, "JGWhjpsiB58P+FystqkjLOakJks=", false, function() {
  return [useToast, useMutation, useMutation, useMutation, useMutation];
});
_c2 = LogisticsDeliveryCard;
function LogisticsOrderDetailsModal({ delivery, onClose }) {
  _s3();
  const detailsQuery = useQuery({
    queryKey: ["integrations", "ifood", "logistics-order-details", delivery.ifoodOrderId],
    queryFn: () => getIFoodLogisticsOrderDetails(delivery.ifoodOrderId)
  });
  let formatted = detailsQuery.data?.rawPayload ?? null;
  if (formatted) {
    try {
      formatted = JSON.stringify(JSON.parse(formatted), null, 2);
    } catch {
    }
  }
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: `Detalhes no iFood — ${delivery.ifoodOrderDisplayId ?? `Pedido #${delivery.ifoodOrderId}`}`, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12, minWidth: 360, maxWidth: 520 }, children: [
    /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.82rem" }, children: "A doc oficial do iFood não documenta os campos desta resposta — o JSON é mostrado como o iFood devolveu." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 326,
      columnNumber: 9
    }, this),
    detailsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: detailsQuery.error, what: "os detalhes da entrega" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 330,
      columnNumber: 34
    }, this),
    detailsQuery.isLoading && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "Carregando…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 331,
      columnNumber: 36
    }, this),
    formatted && /* @__PURE__ */ jsxDEV(
      "pre",
      {
        style: {
          maxHeight: 320,
          overflow: "auto",
          fontSize: "0.78rem",
          padding: 10,
          borderRadius: 8,
          background: "var(--surface-2, rgba(0,0,0,0.04))"
        },
        children: formatted
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 333,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Fechar" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 347,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 346,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
    lineNumber: 325,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
    lineNumber: 324,
    columnNumber: 5
  }, this);
}
_s3(LogisticsOrderDetailsModal, "VGlLhGytRVLBmVnE8hFVvNxEaBI=", false, function() {
  return [useQuery];
});
_c3 = LogisticsOrderDetailsModal;
function AssignDriverModal({
  order,
  onClose,
  onAssigned
}) {
  _s4();
  const toast = useToast();
  const [driverName, setDriverName] = useState("");
  const [driverPhone, setDriverPhone] = useState("");
  const [driverVehicleType, setDriverVehicleType] = useState("MOTORCYCLE");
  const mutation = useMutation({
    mutationFn: () => assignIFoodDriver(order.id, {
      driverName: driverName.trim(),
      driverPhone: driverPhone.trim(),
      driverVehicleType
    }),
    onSuccess: () => {
      toast.success("Entregador atribuído — o iFood já foi avisado.");
      onAssigned();
    },
    onError: () => toast.error("Não foi possível atribuir o entregador.")
  });
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: `Atribuir entregador — ${order.displayId ?? `Pedido #${order.id}`}`, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 320 }, children: [
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome do entregador", value: driverName, onChange: (e) => setDriverName(e.target.value), autoFocus: true }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 387,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Telefone do entregador", value: driverPhone, onChange: (e) => setDriverPhone(e.target.value), placeholder: "(11) 98765-4321" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 388,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(SelectField, { label: "Veículo", value: driverVehicleType, onChange: (e) => setDriverVehicleType(e.target.value), children: [
      /* @__PURE__ */ jsxDEV("option", { value: "MOTORCYCLE", children: "Moto" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 390,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("option", { value: "BICYCLE", children: "Bicicleta" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 391,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("option", { value: "CAR", children: "Carro" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 392,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("option", { value: "ON_FOOT", children: "A pé" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 393,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 389,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 397,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          disabled: !driverName.trim() || !driverPhone.trim(),
          loading: mutation.isPending,
          onClick: () => mutation.mutate(),
          children: "Atribuir"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
          lineNumber: 400,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 396,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
    lineNumber: 386,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
    lineNumber: 385,
    columnNumber: 5
  }, this);
}
_s4(AssignDriverModal, "368eBdzbiwfbQE5G7kD28Q8FBYI=", false, function() {
  return [useToast, useMutation];
});
_c4 = AssignDriverModal;
function VerifyCodeModal({
  delivery,
  onClose,
  onVerified
}) {
  _s5();
  const toast = useToast();
  const [code, setCode] = useState("");
  const mutation = useMutation({
    mutationFn: () => verifyIFoodDeliveryCode(delivery.ifoodOrderId, code.trim()),
    onSuccess: (result) => {
      if (result.codeMatched) {
        toast.success("Entrega confirmada.");
        onVerified();
      } else {
        toast.error("Código incorreto — confira com o cliente e tente de novo.");
      }
    },
    onError: () => toast.error("Não foi possível verificar o código.")
  });
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: "Verificar código de entrega", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 280 }, children: [
    /* @__PURE__ */ jsxDEV(TextField, { label: "Código informado pelo cliente", value: code, onChange: (e) => setCode(e.target.value), autoFocus: true }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 442,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 444,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", disabled: !code.trim(), loading: mutation.isPending, onClick: () => mutation.mutate(), children: "Verificar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
        lineNumber: 447,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
      lineNumber: 443,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
    lineNumber: 441,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx",
    lineNumber: 440,
    columnNumber: 5
  }, this);
}
_s5(VerifyCodeModal, "+mJWAmAhFVe5ZdIXm1EJ2Hkhez0=", false, function() {
  return [useToast, useMutation];
});
_c5 = VerifyCodeModal;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "IFoodLogisticsPage");
$RefreshReg$(_c2, "LogisticsDeliveryCard");
$RefreshReg$(_c3, "LogisticsOrderDetailsModal");
$RefreshReg$(_c4, "AssignDriverModal");
$RefreshReg$(_c5, "VerifyCodeModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodLogisticsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEZROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVGUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUdLO0FBQ1AsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBUTNCLE1BQU1DLHNCQUFzQjtBQUU1QixNQUFNQyxlQUF1QztBQUFBLEVBQzNDQyxpQkFBaUI7QUFBQSxFQUNqQkMsaUJBQWlCO0FBQUEsRUFDakJDLG1CQUFtQjtBQUFBLEVBQ25CQyxZQUFZO0FBQUEsRUFDWkMsd0JBQXdCO0FBQUEsRUFDeEJDLHdCQUF3QjtBQUMxQjtBQUVBLE1BQU1DLGVBQXVDO0FBQUEsRUFDM0NOLGlCQUFpQjtBQUFBLEVBQ2pCQyxpQkFBaUI7QUFBQSxFQUNqQkMsbUJBQW1CO0FBQUEsRUFDbkJDLFlBQVk7QUFBQSxFQUNaQyx3QkFBd0I7QUFBQSxFQUN4QkMsd0JBQXdCO0FBQzFCO0FBRU8sZ0JBQVNFLHFCQUFxQjtBQUFBQyxLQUFBO0FBQ25DLFFBQU1DLGNBQWM5QixlQUFlO0FBQ25DLFFBQU0sRUFBRStCLFNBQVMsSUFBSXJCLGFBQWE7QUFDbEMsUUFBTSxDQUFDc0IsV0FBV0MsWUFBWSxJQUFJckMsU0FBb0MsSUFBSTtBQUMxRSxRQUFNLENBQUNzQyxXQUFXQyxZQUFZLElBQUl2QyxTQUFnRCxJQUFJO0FBQ3RGLFFBQU0sQ0FBQ3dDLFlBQVlDLGFBQWEsSUFBSXpDLFNBQWdELElBQUk7QUFFeEYsUUFBTTBDLGtCQUFrQnZDLFNBQVM7QUFBQSxJQUMvQndDLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxhQUFhUixRQUFRO0FBQUEsSUFDekRTLFNBQVNBLE1BQU1yQyw0QkFBNEI0QixRQUFRO0FBQUEsSUFDbkRVLGlCQUFpQnRCO0FBQUFBLEVBQ25CLENBQUM7QUFFRCxRQUFNdUIsY0FBYzNDLFNBQVM7QUFBQSxJQUMzQndDLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxVQUFVUixRQUFRO0FBQUEsSUFDdERTLFNBQVNBLE1BQU1uQyxlQUFlMEIsUUFBUTtBQUFBLElBQ3RDVSxpQkFBaUJ0QjtBQUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTXdCLGFBQWFBLE1BQU07QUFDdkIsU0FBS2IsWUFBWWMsa0JBQWtCLEVBQUVMLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxXQUFXLEVBQUUsQ0FBQztBQUN2RixTQUFLVCxZQUFZYyxrQkFBa0IsRUFBRUwsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFFBQVEsRUFBRSxDQUFDO0FBQUEsRUFDdEY7QUFFQSxRQUFNTSxhQUFhUCxnQkFBZ0JRLFFBQVE7QUFDM0MsUUFBTUMsd0JBQXdCLElBQUlDLElBQUlILFdBQVdJLElBQUksQ0FBQ0MsTUFBTUEsRUFBRUMsWUFBWSxDQUFDO0FBSTNFLFFBQU1DLGtCQUFrQlYsWUFBWUksUUFBUSxJQUFJTztBQUFBQSxJQUM5QyxDQUFDQyxNQUNDQSxFQUFFQyxlQUFlLFFBQ2pCRCxFQUFFQyxnQkFBZ0IsV0FDbEJELEVBQUVFLFdBQVcsZUFDYkYsRUFBRUUsV0FBVyxlQUNiLENBQUNULHNCQUFzQlUsSUFBSUgsRUFBRUksRUFBRTtBQUFBLEVBQ25DO0FBRUEsU0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsU0FBUyxJQUFJQyxVQUFVLEtBQU1DLFFBQVEsU0FBUyxHQUMzRDtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRUMsY0FBYyxHQUFHLEdBQzlDO0FBQUEsNkJBQUMsUUFBSyxJQUFHLHNCQUFxQixPQUFPLEVBQUVDLE9BQU8sb0JBQW9CQyxVQUFVLFVBQVUsR0FBRyxrQ0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSwrQkFBQyxRQUFHLFdBQVUsV0FBVSxPQUFPLEVBQUVGLFVBQVUsU0FBUyxHQUFHLHlDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFRCxPQUFPLG9CQUFvQkMsVUFBVSxTQUFTLEdBQUcsMEhBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxLQUVFMUIsZ0JBQWdCNkIsV0FBV3pCLFlBQVl5QixZQUN2Qyx1QkFBQyxjQUFXLE9BQU83QixnQkFBZ0I4QixTQUFTMUIsWUFBWTBCLE9BQU8sTUFBSywwQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRjtBQUFBLElBRzVGLHVCQUFDLGFBQVEsT0FBTyxFQUFFTixjQUFjLEdBQUcsR0FDakM7QUFBQSw2QkFBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVFLFVBQVUsV0FBV0MsU0FBUyxTQUFTSCxjQUFjLEdBQUcsR0FBRyxxQ0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQyxDQUFDcEIsWUFBWTJCLGFBQWFqQixlQUFla0IsV0FBVyxLQUNuRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sYUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFNkc7QUFBQSxNQUcvRyx1QkFBQyxTQUFJLE9BQU8sRUFBRUwsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDcENkLHlCQUFlSDtBQUFBQSxRQUFJLENBQUNzQixVQUNuQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsV0FBVTtBQUFBLFlBQ1YsT0FBTyxFQUFFWixTQUFTLElBQUlNLFNBQVMsUUFBUU8sZ0JBQWdCLGlCQUFpQkMsWUFBWSxVQUFVUCxLQUFLLElBQUlRLFVBQVUsT0FBTztBQUFBLFlBRXhIO0FBQUEscUNBQUMsU0FBSSxPQUFPLEVBQUVULFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsdUNBQUMsVUFBSyxPQUFPLEVBQUVTLFlBQVksSUFBSSxHQUM1Qko7QUFBQUEsd0JBQU1LLGFBQWEsV0FBV0wsTUFBTWIsRUFBRTtBQUFBLGtCQUFHO0FBQUEsa0JBQUlhLE1BQU1NO0FBQUFBLHFCQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVkLE9BQU8sa0JBQWtCQyxVQUFVLFVBQVUsR0FBSU8sZ0JBQU1PLG1CQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRjtBQUFBLG1CQUp4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTLE1BQU03QyxhQUFhc0MsS0FBSyxHQUFHLG1DQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUE7QUFBQTtBQUFBLFVBWktBLE1BQU1iO0FBQUFBLFVBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNBO0FBQUEsTUFDRCxLQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsU0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZCQTtBQUFBLElBRUEsdUJBQUMsYUFDQztBQUFBLDZCQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRU0sVUFBVSxXQUFXQyxTQUFTLFNBQVNILGNBQWMsR0FBRyxHQUFHLHFDQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDLENBQUN4QixnQkFBZ0IrQixhQUFheEIsV0FBV3lCLFdBQVcsS0FDbkQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLGFBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRWlHO0FBQUEsTUFHbkcsdUJBQUMsU0FBSSxPQUFPLEVBQUVMLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ3BDckIscUJBQVdJO0FBQUFBLFFBQUksQ0FBQzhCLGFBQ2Y7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDO0FBQUEsWUFDQSxZQUFZcEM7QUFBQUEsWUFDWixjQUFjLE1BQU1SLGFBQWE0QyxRQUFRO0FBQUEsWUFDekMsZUFBZSxNQUFNMUMsY0FBYzBDLFFBQVE7QUFBQTtBQUFBLFVBSnRDQSxTQUFTckI7QUFBQUEsVUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUsrQztBQUFBLE1BRWhELEtBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsU0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLElBRUN0QixjQUFjLHVCQUFDLDhCQUEyQixVQUFVQSxZQUFZLFNBQVMsTUFBTUMsY0FBYyxJQUFJLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUY7QUFBQSxJQUVuR0wsYUFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBT0E7QUFBQUEsUUFDUCxTQUFTLE1BQU1DLGFBQWEsSUFBSTtBQUFBLFFBQ2hDLFlBQVksTUFBTTtBQUNoQkEsdUJBQWEsSUFBSTtBQUNqQlUscUJBQVc7QUFBQSxRQUNiO0FBQUE7QUFBQSxNQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1JO0FBQUEsSUFJTFQsYUFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsVUFBVUE7QUFBQUEsUUFDVixTQUFTLE1BQU1DLGFBQWEsSUFBSTtBQUFBLFFBQ2hDLFlBQVksTUFBTTtBQUNoQkEsdUJBQWEsSUFBSTtBQUNqQlEscUJBQVc7QUFBQSxRQUNiO0FBQUE7QUFBQSxNQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1JO0FBQUEsT0E5RlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlHQTtBQUVKO0FBQUNkLEdBMUllRCxvQkFBa0I7QUFBQSxVQUNaNUIsZ0JBQ0NVLGNBS0dYLFVBTUpBLFFBQVE7QUFBQTtBQUFBLEtBYmQ2QjtBQTRJaEIsU0FBU29ELHNCQUFzQjtBQUFBLEVBQzdCRDtBQUFBQSxFQUNBRTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQU1GLEdBQUc7QUFBQUMsTUFBQTtBQUNELFFBQU1DLFFBQVExRSxTQUFTO0FBRXZCLFFBQU0yRSx3QkFBd0J4RixZQUFZO0FBQUEsSUFDeEN5RixZQUFZQSxNQUFNL0UsdUJBQXVCdUUsU0FBUzVCLFlBQVk7QUFBQSxJQUM5RHFDLFdBQVdQO0FBQUFBLElBQ1hRLFNBQVNBLE1BQU1KLE1BQU1qQixNQUFNLGtFQUFrRTtBQUFBLEVBQy9GLENBQUM7QUFDRCxRQUFNc0IsMEJBQTBCNUYsWUFBWTtBQUFBLElBQzFDeUYsWUFBWUEsTUFBTWhGLHlCQUF5QndFLFNBQVM1QixZQUFZO0FBQUEsSUFDaEVxQyxXQUFXUDtBQUFBQSxJQUNYUSxTQUFTQSxNQUFNSixNQUFNakIsTUFBTSxrRUFBa0U7QUFBQSxFQUMvRixDQUFDO0FBQ0QsUUFBTXVCLG1CQUFtQjdGLFlBQVk7QUFBQSxJQUNuQ3lGLFlBQVlBLE1BQU1yRix1QkFBdUI2RSxTQUFTNUIsWUFBWTtBQUFBLElBQzlEcUMsV0FBV1A7QUFBQUEsSUFDWFEsU0FBU0EsTUFBTUosTUFBTWpCLE1BQU0sa0VBQWtFO0FBQUEsRUFDL0YsQ0FBQztBQUNELFFBQU13QiwrQkFBK0I5RixZQUFZO0FBQUEsSUFDL0N5RixZQUFZQSxNQUFNakYsOEJBQThCeUUsU0FBUzVCLFlBQVk7QUFBQSxJQUNyRXFDLFdBQVdQO0FBQUFBLElBQ1hRLFNBQVNBLE1BQU1KLE1BQU1qQixNQUFNLGtFQUFrRTtBQUFBLEVBQy9GLENBQUM7QUFFRCxRQUFNeUIsVUFDSlAsc0JBQXNCUSxhQUFhSix3QkFBd0JJLGFBQWFILGlCQUFpQkcsYUFBYUYsNkJBQTZCRTtBQUVySSxTQUNFLHVCQUFDLGFBQVEsV0FBVSxlQUFjLE9BQU8sRUFBRW5DLFNBQVMsSUFBSU0sU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDOUU7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRU0sZ0JBQWdCLGlCQUFpQk4sS0FBSyxHQUFHLEdBQ3BGO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVELFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVTLFlBQVksS0FBS1gsVUFBVSxVQUFVLEdBQ2pEZTtBQUFBQSxtQkFBU2dCLHVCQUF1QixXQUFXaEIsU0FBUzVCLFlBQVk7QUFBQSxVQUNoRTRCLFNBQVNGLGVBQWUsTUFBTUUsU0FBU0YsWUFBWSxLQUFLO0FBQUEsYUFGM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQ0UsU0FBU0QsbUJBQW1CLHVCQUFDLFVBQUssT0FBTyxFQUFFZixPQUFPLGtCQUFrQkMsVUFBVSxVQUFVLEdBQUllLG1CQUFTRCxtQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFFBQ3RILHVCQUFDLFVBQUssT0FBTyxFQUFFZixPQUFPLG9CQUFvQkMsVUFBVSxVQUFVLEdBQzNEZTtBQUFBQSxtQkFBU2lCO0FBQUFBLFVBQVc7QUFBQSxVQUFJakIsU0FBU2tCO0FBQUFBLFVBQVk7QUFBQSxVQUFJbEIsU0FBU21CO0FBQUFBLGFBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxlQUFZLE9BQU92RSxhQUFhb0QsU0FBU3ZCLE1BQU0sS0FBSyxvQkFDbERwQyx1QkFBYTJELFNBQVN2QixNQUFNLEtBQUt1QixTQUFTdkIsVUFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFUyxTQUFTLFFBQVFDLEtBQUssSUFBSU0sZ0JBQWdCLFlBQVlFLFVBQVUsT0FBTyxHQUNuRjtBQUFBLDZCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVNTLGVBQWUscUNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0NKLFNBQVN2QixXQUFXLHFCQUNuQix1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTOEIsc0JBQXNCUSxXQUFXLFVBQVVELFNBQVMsU0FBUyxNQUFNUCxzQkFBc0JhLE9BQU8sR0FBRyxnQ0FBdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRHBCLFNBQVN2QixXQUFXLHFCQUNuQix1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTa0Msd0JBQXdCSSxXQUFXLFVBQVVELFNBQVMsU0FBUyxNQUFNSCx3QkFBd0JTLE9BQU8sR0FBRyw4QkFBMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRHBCLFNBQVN2QixXQUFXLHVCQUNuQix1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTbUMsaUJBQWlCRyxXQUFXLFVBQVVELFNBQVMsU0FBUyxNQUFNRixpQkFBaUJRLE9BQU8sR0FBRyx5QkFBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRHBCLFNBQVN2QixXQUFXLGdCQUNuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsU0FBU29DLDZCQUE2QkU7QUFBQUEsVUFDdEMsVUFBVUQ7QUFBQUEsVUFDVixTQUFTLE1BQU1ELDZCQUE2Qk8sT0FBTztBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsTUFFRHBCLFNBQVN2QixXQUFXLDRCQUNuQix1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTMEIsY0FBYywyQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDQTtBQUFBLE9BbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvREE7QUFFSjtBQUlBRSxJQWhHU0osdUJBQXFCO0FBQUEsVUFXZHJFLFVBRWdCYixhQUtFQSxhQUtQQSxhQUtZQSxXQUFXO0FBQUE7QUFBQSxNQTVCekNrRjtBQWlHVCxTQUFTb0IsMkJBQTJCLEVBQUVyQixVQUFVc0IsUUFBMkUsR0FBRztBQUFBQyxNQUFBO0FBQzVILFFBQU1DLGVBQWV4RyxTQUFTO0FBQUEsSUFDNUJ3QyxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsMkJBQTJCd0MsU0FBUzVCLFlBQVk7QUFBQSxJQUNwRlgsU0FBU0EsTUFBTXBDLDhCQUE4QjJFLFNBQVM1QixZQUFZO0FBQUEsRUFDcEUsQ0FBQztBQUVELE1BQUlxRCxZQUFZRCxhQUFhekQsTUFBTTJELGNBQWM7QUFDakQsTUFBSUQsV0FBVztBQUNiLFFBQUk7QUFDRkEsa0JBQVlFLEtBQUtDLFVBQVVELEtBQUtFLE1BQU1KLFNBQVMsR0FBRyxNQUFNLENBQUM7QUFBQSxJQUMzRCxRQUFRO0FBQUEsSUFDTjtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQU0sU0FBa0IsT0FBTyx1QkFBdUJ6QixTQUFTZ0IsdUJBQXVCLFdBQVdoQixTQUFTNUIsWUFBWSxFQUFFLElBQ3ZILGlDQUFDLFNBQUksT0FBTyxFQUFFYyxTQUFTLFFBQVFDLEtBQUssSUFBSTJDLFVBQVUsS0FBS2pELFVBQVUsSUFBSSxHQUNuRTtBQUFBLDJCQUFDLFVBQUssT0FBTyxFQUFFRyxPQUFPLG9CQUFvQkMsVUFBVSxVQUFVLEdBQUcsd0hBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0N1QyxhQUFhcEMsV0FBVyx1QkFBQyxjQUFXLE9BQU9vQyxhQUFhbkMsT0FBTyxNQUFLLDRCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9FO0FBQUEsSUFDNUZtQyxhQUFhbEMsYUFBYSx1QkFBQyxVQUFLLE9BQU8sRUFBRU4sT0FBTyxtQkFBbUIsR0FBRywyQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RDtBQUFBLElBQ2pGeUMsYUFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFVBQ0xNLFdBQVc7QUFBQSxVQUNYQyxVQUFVO0FBQUEsVUFDVi9DLFVBQVU7QUFBQSxVQUNWTCxTQUFTO0FBQUEsVUFDVHFELGNBQWM7QUFBQSxVQUNkQyxZQUFZO0FBQUEsUUFDZDtBQUFBLFFBRUNUO0FBQUFBO0FBQUFBLE1BVkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV0E7QUFBQSxJQUVGLHVCQUFDLFNBQUksT0FBTyxFQUFFdkMsU0FBUyxRQUFRTyxnQkFBZ0IsV0FBVyxHQUN4RCxpQ0FBQyxVQUFPLFNBQVEsU0FBUSxTQUFTNkIsU0FBUyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEJBO0FBRUo7QUFBQ0MsSUE5Q1FGLDRCQUEwQjtBQUFBLFVBQ1pyRyxRQUFRO0FBQUE7QUFBQSxNQUR0QnFHO0FBZ0RULFNBQVNjLGtCQUFrQjtBQUFBLEVBQ3pCM0M7QUFBQUEsRUFDQThCO0FBQUFBLEVBQ0FjO0FBS0YsR0FBRztBQUFBQyxNQUFBO0FBQ0QsUUFBTS9CLFFBQVExRSxTQUFTO0FBQ3ZCLFFBQU0sQ0FBQ3FGLFlBQVlxQixhQUFhLElBQUl6SCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDcUcsYUFBYXFCLGNBQWMsSUFBSTFILFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNzRyxtQkFBbUJxQixvQkFBb0IsSUFBSTNILFNBQVMsWUFBWTtBQUV2RSxRQUFNNEgsV0FBVzFILFlBQVk7QUFBQSxJQUMzQnlGLFlBQVlBLE1BQ1Z0RixrQkFBa0JzRSxNQUFNYixJQUFJO0FBQUEsTUFDMUJzQyxZQUFZQSxXQUFXeUIsS0FBSztBQUFBLE1BQzVCeEIsYUFBYUEsWUFBWXdCLEtBQUs7QUFBQSxNQUM5QnZCO0FBQUFBLElBQ0YsQ0FBQztBQUFBLElBQ0hWLFdBQVdBLE1BQU07QUFDZkgsWUFBTXFDLFFBQVEsZ0RBQWdEO0FBQzlEUCxpQkFBVztBQUFBLElBQ2I7QUFBQSxJQUNBMUIsU0FBU0EsTUFBTUosTUFBTWpCLE1BQU0seUNBQXlDO0FBQUEsRUFDdEUsQ0FBQztBQUVELFNBQ0UsdUJBQUMsU0FBTSxTQUFrQixPQUFPLHlCQUF5QkcsTUFBTUssYUFBYSxXQUFXTCxNQUFNYixFQUFFLEVBQUUsSUFDL0YsaUNBQUMsU0FBSSxPQUFPLEVBQUVPLFNBQVMsUUFBUUMsS0FBSyxJQUFJMkMsVUFBVSxJQUFJLEdBQ3BEO0FBQUEsMkJBQUMsYUFBVSxPQUFNLHNCQUFxQixPQUFPYixZQUFZLFVBQVUsQ0FBQzJCLE1BQU1OLGNBQWNNLEVBQUVDLE9BQU9DLEtBQUssR0FBRyxXQUFTLFFBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0g7QUFBQSxJQUNsSCx1QkFBQyxhQUFVLE9BQU0sMEJBQXlCLE9BQU81QixhQUFhLFVBQVUsQ0FBQzBCLE1BQU1MLGVBQWVLLEVBQUVDLE9BQU9DLEtBQUssR0FBRyxhQUFZLHFCQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRJO0FBQUEsSUFDNUksdUJBQUMsZUFBWSxPQUFNLFdBQVUsT0FBTzNCLG1CQUFtQixVQUFVLENBQUN5QixNQUFNSixxQkFBcUJJLEVBQUVDLE9BQU9DLEtBQUssR0FDekc7QUFBQSw2QkFBQyxZQUFPLE9BQU0sY0FBYSxvQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQy9CLHVCQUFDLFlBQU8sT0FBTSxXQUFVLHlCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsWUFBTyxPQUFNLE9BQU0scUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxZQUFPLE9BQU0sV0FBVSxvQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLFNBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUU1RCxTQUFTLFFBQVFDLEtBQUssSUFBSU0sZ0JBQWdCLFdBQVcsR0FDakU7QUFBQSw2QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTNkIsU0FBUyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsVUFBVSxDQUFDTCxXQUFXeUIsS0FBSyxLQUFLLENBQUN4QixZQUFZd0IsS0FBSztBQUFBLFVBQ2xELFNBQVNELFNBQVMxQjtBQUFBQSxVQUNsQixTQUFTLE1BQU0wQixTQUFTckIsT0FBTztBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBLEtBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5QkE7QUFFSjtBQUFDaUIsSUF4RFFGLG1CQUFpQjtBQUFBLFVBU1Z2RyxVQUtHYixXQUFXO0FBQUE7QUFBQSxNQWRyQm9IO0FBMERULFNBQVNZLGdCQUFnQjtBQUFBLEVBQ3ZCL0M7QUFBQUEsRUFDQXNCO0FBQUFBLEVBQ0EwQjtBQUtGLEdBQUc7QUFBQUMsTUFBQTtBQUNELFFBQU0zQyxRQUFRMUUsU0FBUztBQUN2QixRQUFNLENBQUNzSCxNQUFNQyxPQUFPLElBQUl0SSxTQUFTLEVBQUU7QUFFbkMsUUFBTTRILFdBQVcxSCxZQUFZO0FBQUEsSUFDM0J5RixZQUFZQSxNQUFNOUUsd0JBQXdCc0UsU0FBUzVCLGNBQWM4RSxLQUFLUixLQUFLLENBQUM7QUFBQSxJQUM1RWpDLFdBQVdBLENBQUMyQyxXQUFXO0FBQ3JCLFVBQUlBLE9BQU9DLGFBQWE7QUFDdEIvQyxjQUFNcUMsUUFBUSxxQkFBcUI7QUFDbkNLLG1CQUFXO0FBQUEsTUFDYixPQUFPO0FBQ0wxQyxjQUFNakIsTUFBTSwyREFBMkQ7QUFBQSxNQUN6RTtBQUFBLElBQ0Y7QUFBQSxJQUNBcUIsU0FBU0EsTUFBTUosTUFBTWpCLE1BQU0sc0NBQXNDO0FBQUEsRUFDbkUsQ0FBQztBQUVELFNBQ0UsdUJBQUMsU0FBTSxTQUFrQixPQUFNLCtCQUM3QixpQ0FBQyxTQUFJLE9BQU8sRUFBRUgsU0FBUyxRQUFRQyxLQUFLLElBQUkyQyxVQUFVLElBQUksR0FDcEQ7QUFBQSwyQkFBQyxhQUFVLE9BQU0saUNBQWdDLE9BQU9vQixNQUFNLFVBQVUsQ0FBQ04sTUFBTU8sUUFBUVAsRUFBRUMsT0FBT0MsS0FBSyxHQUFHLFdBQVMsUUFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpSDtBQUFBLElBQ2pILHVCQUFDLFNBQUksT0FBTyxFQUFFNUQsU0FBUyxRQUFRQyxLQUFLLElBQUlNLGdCQUFnQixXQUFXLEdBQ2pFO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUzZCLFNBQVMsc0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxTQUFRLFdBQVUsVUFBVSxDQUFDNEIsS0FBS1IsS0FBSyxHQUFHLFNBQVNELFNBQVMxQixXQUFXLFNBQVMsTUFBTTBCLFNBQVNyQixPQUFPLEdBQUcseUJBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsT0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFSjtBQUFDNkIsSUF4Q1FGLGlCQUFlO0FBQUEsVUFTUm5ILFVBR0diLFdBQVc7QUFBQTtBQUFBLE1BWnJCZ0k7QUFBZSxJQUFBTyxJQUFBQyxLQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUFKLElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJMaW5rIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiYXNzaWduSUZvb2REcml2ZXIiLCJkaXNwYXRjaElGb29kTG9naXN0aWNzIiwiZ2V0SUZvb2RMb2dpc3RpY3NEZWxpdmVyaWVzIiwiZ2V0SUZvb2RMb2dpc3RpY3NPcmRlckRldGFpbHMiLCJnZXRJRm9vZE9yZGVycyIsIm1hcmtJRm9vZEFycml2ZWRBdERlc3RpbmF0aW9uIiwibWFya0lGb29kQXJyaXZlZEF0T3JpZ2luIiwibWFya0lGb29kR29pbmdUb09yaWdpbiIsInZlcmlmeUlGb29kRGVsaXZlcnlDb2RlIiwidXNlQXV0aFN0b3JlIiwidXNlVG9hc3QiLCJCdXR0b24iLCJTdGF0dXNCYWRnZSIsIk1vZGFsIiwiU2VsZWN0RmllbGQiLCJUZXh0RmllbGQiLCJRdWVyeUVycm9yIiwiRW1wdHlTdGF0ZSIsIlJFRlJFU0hfSU5URVJWQUxfTVMiLCJTVEFUVVNfTEFCRUwiLCJEUklWRVJfQVNTSUdORUQiLCJHT0lOR19UT19PUklHSU4iLCJBUlJJVkVEX0FUX09SSUdJTiIsIkRJU1BBVENIRUQiLCJBUlJJVkVEX0FUX0RFU1RJTkFUSU9OIiwiREVMSVZFUllfQ09ERV9WRVJJRklFRCIsIlNUQVRVU19DT0xPUiIsIklGb29kTG9naXN0aWNzUGFnZSIsIl9zIiwicXVlcnlDbGllbnQiLCJicmFuY2hJZCIsImFzc2lnbmluZyIsInNldEFzc2lnbmluZyIsInZlcmlmeWluZyIsInNldFZlcmlmeWluZyIsImRldGFpbHNGb3IiLCJzZXREZXRhaWxzRm9yIiwiZGVsaXZlcmllc1F1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicmVmZXRjaEludGVydmFsIiwib3JkZXJzUXVlcnkiLCJpbnZhbGlkYXRlIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJkZWxpdmVyaWVzIiwiZGF0YSIsImFzc2lnbmVkSUZvb2RPcmRlcklkcyIsIlNldCIsIm1hcCIsImQiLCJpZm9vZE9yZGVySWQiLCJlbGlnaWJsZU9yZGVycyIsImZpbHRlciIsIm8iLCJkZWxpdmVyZWRCeSIsInN0YXR1cyIsImhhcyIsImlkIiwicGFkZGluZyIsIm1heFdpZHRoIiwibWFyZ2luIiwibWFyZ2luQm90dG9tIiwiY29sb3IiLCJmb250U2l6ZSIsImRpc3BsYXkiLCJnYXAiLCJpc0Vycm9yIiwiZXJyb3IiLCJpc0xvYWRpbmciLCJsZW5ndGgiLCJvcmRlciIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImZsZXhXcmFwIiwiZm9udFdlaWdodCIsImRpc3BsYXlJZCIsImN1c3RvbWVyTmFtZSIsImRlbGl2ZXJ5QWRkcmVzcyIsImRlbGl2ZXJ5IiwiTG9naXN0aWNzRGVsaXZlcnlDYXJkIiwib25BZHZhbmNlZCIsIm9uVmVyaWZ5Q29kZSIsIm9uVmlld0RldGFpbHMiLCJfczIiLCJ0b2FzdCIsImdvaW5nVG9PcmlnaW5NdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJvblN1Y2Nlc3MiLCJvbkVycm9yIiwiYXJyaXZlZEF0T3JpZ2luTXV0YXRpb24iLCJkaXNwYXRjaE11dGF0aW9uIiwiYXJyaXZlZEF0RGVzdGluYXRpb25NdXRhdGlvbiIsInBlbmRpbmciLCJpc1BlbmRpbmciLCJpZm9vZE9yZGVyRGlzcGxheUlkIiwiZHJpdmVyTmFtZSIsImRyaXZlclBob25lIiwiZHJpdmVyVmVoaWNsZVR5cGUiLCJtdXRhdGUiLCJMb2dpc3RpY3NPcmRlckRldGFpbHNNb2RhbCIsIm9uQ2xvc2UiLCJfczMiLCJkZXRhaWxzUXVlcnkiLCJmb3JtYXR0ZWQiLCJyYXdQYXlsb2FkIiwiSlNPTiIsInN0cmluZ2lmeSIsInBhcnNlIiwibWluV2lkdGgiLCJtYXhIZWlnaHQiLCJvdmVyZmxvdyIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmQiLCJBc3NpZ25Ecml2ZXJNb2RhbCIsIm9uQXNzaWduZWQiLCJfczQiLCJzZXREcml2ZXJOYW1lIiwic2V0RHJpdmVyUGhvbmUiLCJzZXREcml2ZXJWZWhpY2xlVHlwZSIsIm11dGF0aW9uIiwidHJpbSIsInN1Y2Nlc3MiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJWZXJpZnlDb2RlTW9kYWwiLCJvblZlcmlmaWVkIiwiX3M1IiwiY29kZSIsInNldENvZGUiLCJyZXN1bHQiLCJjb2RlTWF0Y2hlZCIsIl9jIiwiX2MyIiwiX2MzIiwiX2M0IiwiX2M1Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIklGb29kTG9naXN0aWNzUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7XHJcbiAgYXNzaWduSUZvb2REcml2ZXIsXHJcbiAgZGlzcGF0Y2hJRm9vZExvZ2lzdGljcyxcclxuICBnZXRJRm9vZExvZ2lzdGljc0RlbGl2ZXJpZXMsXHJcbiAgZ2V0SUZvb2RMb2dpc3RpY3NPcmRlckRldGFpbHMsXHJcbiAgZ2V0SUZvb2RPcmRlcnMsXHJcbiAgbWFya0lGb29kQXJyaXZlZEF0RGVzdGluYXRpb24sXHJcbiAgbWFya0lGb29kQXJyaXZlZEF0T3JpZ2luLFxyXG4gIG1hcmtJRm9vZEdvaW5nVG9PcmlnaW4sXHJcbiAgdmVyaWZ5SUZvb2REZWxpdmVyeUNvZGUsXHJcbiAgdHlwZSBJRm9vZExvZ2lzdGljc0RlbGl2ZXJ5UmVzcG9uc2UsXHJcbiAgdHlwZSBJRm9vZE9yZGVyUmVzcG9uc2UsXHJcbn0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIi4uLy4uL3VpL1RvYXN0XCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCIuLi8uLi91aS9CdXR0b25cIjtcclxuaW1wb3J0IHsgU3RhdHVzQmFkZ2UgfSBmcm9tIFwiLi4vLi4vdWkvU3RhdHVzQmFkZ2VcIjtcclxuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiLi4vLi4vdWkvTW9kYWxcIjtcclxuaW1wb3J0IHsgU2VsZWN0RmllbGQsIFRleHRGaWVsZCB9IGZyb20gXCIuLi8uLi91aS9GaWVsZFwiO1xyXG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xyXG5pbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSBcIi4uLy4uL3VpL0VtcHR5U3RhdGVcIjtcclxuXHJcbi8vIEZhc2UgNyDigJQgTG9naXN0aWNzOiBlbnRyZWdhLCBwZWxhIEZST1RBIFBSw5NQUklBLCBkZSB1bSBwZWRpZG8gUVVFIFZFSU8gZG8gaUZvb2QgKGRlbGl2ZXJlZEJ5XHJcbi8vIGRpZmVyZW50ZSBkZSBcIklGT09EXCIgbm8gcGVkaWRvIOKAlCB2ZXIgSUZvb2RPcmRlclJlc3BvbnNlLmRlbGl2ZXJlZEJ5KS4gRGlmZXJlbnRlIGRhIHRlbGFcclxuLy8gXCJFbnRyZWdhcyBpRm9vZCAoU2hpcHBpbmcpXCIgKGZhc2UgOCwgZW50cmVnYWRvciBkbyBwcsOzcHJpbyBpRm9vZCBwcmEgcGVkaWRvIGRlIE9VVFJPIGNhbmFsKSxcclxuLy8gYXF1aSDDqSBvIGludmVyc28g4oCUIG8gcGVkaWRvIGV4aXN0ZSBubyBpRm9vZCwgc8OzIHF1ZW0gZW50cmVnYSDDqSBhIGVxdWlwZSBkbyBsb2ppc3RhLCBlIG8gaUZvb2RcclxuLy8gc8OzIHByZWNpc2Egc2VyIGF2aXNhZG8gZGUgY2FkYSBwYXNzbyAoYXRyaWJ1aXIg4oaSIHNhaXUgcHJhIG9yaWdlbSDihpIgY2hlZ291IG5hIG9yaWdlbSDihpJcclxuLy8gZGVzcGFjaG91IOKGkiBjaGVnb3Ugbm8gZGVzdGlubyDihpIgdmVyaWZpY2FyIGPDs2RpZ28gZGUgZW50cmVnYSkuXHJcbmNvbnN0IFJFRlJFU0hfSU5URVJWQUxfTVMgPSAyMF8wMDA7XHJcblxyXG5jb25zdCBTVEFUVVNfTEFCRUw6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XHJcbiAgRFJJVkVSX0FTU0lHTkVEOiBcIkVudHJlZ2Fkb3IgYXRyaWJ1w61kb1wiLFxyXG4gIEdPSU5HX1RPX09SSUdJTjogXCJBIGNhbWluaG8gZGEgbG9qYVwiLFxyXG4gIEFSUklWRURfQVRfT1JJR0lOOiBcIkNoZWdvdSBuYSBsb2phXCIsXHJcbiAgRElTUEFUQ0hFRDogXCJEZXNwYWNoYWRvXCIsXHJcbiAgQVJSSVZFRF9BVF9ERVNUSU5BVElPTjogXCJDaGVnb3Ugbm8gZGVzdGlub1wiLFxyXG4gIERFTElWRVJZX0NPREVfVkVSSUZJRUQ6IFwiRW50cmVnYSBjb25maXJtYWRhXCIsXHJcbn07XHJcblxyXG5jb25zdCBTVEFUVVNfQ09MT1I6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XHJcbiAgRFJJVkVSX0FTU0lHTkVEOiBcInZhcigtLWluay1mYWludClcIixcclxuICBHT0lOR19UT19PUklHSU46IFwidmFyKC0td2FybiwgI2Q5NzcwNilcIixcclxuICBBUlJJVkVEX0FUX09SSUdJTjogXCJ2YXIoLS13YXJuLCAjZDk3NzA2KVwiLFxyXG4gIERJU1BBVENIRUQ6IFwidmFyKC0td2FybiwgI2Q5NzcwNilcIixcclxuICBBUlJJVkVEX0FUX0RFU1RJTkFUSU9OOiBcInZhcigtLXdhcm4sICNkOTc3MDYpXCIsXHJcbiAgREVMSVZFUllfQ09ERV9WRVJJRklFRDogXCJ2YXIoLS1vaylcIixcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJRm9vZExvZ2lzdGljc1BhZ2UoKSB7XHJcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgYnJhbmNoSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IFthc3NpZ25pbmcsIHNldEFzc2lnbmluZ10gPSB1c2VTdGF0ZTxJRm9vZE9yZGVyUmVzcG9uc2UgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbdmVyaWZ5aW5nLCBzZXRWZXJpZnlpbmddID0gdXNlU3RhdGU8SUZvb2RMb2dpc3RpY3NEZWxpdmVyeVJlc3BvbnNlIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2RldGFpbHNGb3IsIHNldERldGFpbHNGb3JdID0gdXNlU3RhdGU8SUZvb2RMb2dpc3RpY3NEZWxpdmVyeVJlc3BvbnNlIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IGRlbGl2ZXJpZXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImxvZ2lzdGljc1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZExvZ2lzdGljc0RlbGl2ZXJpZXMoYnJhbmNoSWQpLFxyXG4gICAgcmVmZXRjaEludGVydmFsOiBSRUZSRVNIX0lOVEVSVkFMX01TLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBvcmRlcnNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcIm9yZGVyc1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZE9yZGVycyhicmFuY2hJZCksXHJcbiAgICByZWZldGNoSW50ZXJ2YWw6IFJFRlJFU0hfSU5URVJWQUxfTVMsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGludmFsaWRhdGUgPSAoKSA9PiB7XHJcbiAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwibG9naXN0aWNzXCJdIH0pO1xyXG4gICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcIm9yZGVyc1wiXSB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBkZWxpdmVyaWVzID0gZGVsaXZlcmllc1F1ZXJ5LmRhdGEgPz8gW107XHJcbiAgY29uc3QgYXNzaWduZWRJRm9vZE9yZGVySWRzID0gbmV3IFNldChkZWxpdmVyaWVzLm1hcCgoZCkgPT4gZC5pZm9vZE9yZGVySWQpKTtcclxuXHJcbiAgLy8gUGVkaWRvcyBlbGVnw612ZWlzIHByYSBmcm90YSBwcsOzcHJpYTogdmllcmFtIGRvIGlGb29kLCBkZWxpdmVyZWRCeSBwcmVlbmNoaWRvIGUgZGlmZXJlbnRlIGRlXHJcbiAgLy8gXCJJRk9PRFwiIChzZWxmLWRlbGl2ZXJ5KSwgYWluZGEgbsOjbyBjYW5jZWxhZG9zL2VudHJlZ3VlcywgZSBzZW0gZW50cmVnYSBqw6EgYXRyaWJ1w61kYS5cclxuICBjb25zdCBlbGlnaWJsZU9yZGVycyA9IChvcmRlcnNRdWVyeS5kYXRhID8/IFtdKS5maWx0ZXIoXHJcbiAgICAobykgPT5cclxuICAgICAgby5kZWxpdmVyZWRCeSAhPSBudWxsICYmXHJcbiAgICAgIG8uZGVsaXZlcmVkQnkgIT09IFwiSUZPT0RcIiAmJlxyXG4gICAgICBvLnN0YXR1cyAhPT0gXCJDQU5DRUxMRURcIiAmJlxyXG4gICAgICBvLnN0YXR1cyAhPT0gXCJDT05DTFVERURcIiAmJlxyXG4gICAgICAhYXNzaWduZWRJRm9vZE9yZGVySWRzLmhhcyhvLmlkKSxcclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMDAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMTggfX0+XHJcbiAgICAgICAgPExpbmsgdG89XCIvaW50ZWdyYWNvZXMvaWZvb2RcIiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5cclxuICAgICAgICAgIOKGkCBJbnRlZ3Jhw6fDo28gaUZvb2RcclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjdyZW1cIiB9fT5cclxuICAgICAgICAgICAgTG9nw61zdGljYSAoZnJvdGEgcHLDs3ByaWEpXHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5cclxuICAgICAgICAgICAgZW50cmVndWUgcGVkaWRvcyBkbyBpRm9vZCBjb20gYSBlcXVpcGUgZGEgcHLDs3ByaWEgY2FzYSDigJQgYXRyaWJ1YSBvIGVudHJlZ2Fkb3IgZSBhdmlzZVxyXG4gICAgICAgICAgICBjYWRhIHBhc3NvIHBybyBpRm9vZFxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsoZGVsaXZlcmllc1F1ZXJ5LmlzRXJyb3IgfHwgb3JkZXJzUXVlcnkuaXNFcnJvcikgJiYgKFxyXG4gICAgICAgIDxRdWVyeUVycm9yIGVycm9yPXtkZWxpdmVyaWVzUXVlcnkuZXJyb3IgPz8gb3JkZXJzUXVlcnkuZXJyb3J9IHdoYXQ9XCJhIGxvZ8Otc3RpY2EgZG8gaUZvb2RcIiAvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPHNlY3Rpb24gc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAyMiB9fT5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4xNXJlbVwiLCBkaXNwbGF5OiBcImJsb2NrXCIsIG1hcmdpbkJvdHRvbTogMTAgfX0+XHJcbiAgICAgICAgICBBZ3VhcmRhbmRvIGVudHJlZ2Fkb3JcclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgeyFvcmRlcnNRdWVyeS5pc0xvYWRpbmcgJiYgZWxpZ2libGVPcmRlcnMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICAgIHRpdGxlPVwiTmVuaHVtIHBlZGlkbyBlc3BlcmFuZG8gZW50cmVnYWRvclwiXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiUGVkaWRvcyBkbyBpRm9vZCBtYXJjYWRvcyBwYXJhIGVudHJlZ2EgcG9yIGZyb3RhIHByw7NwcmlhIGFwYXJlY2VtIGFxdWkgYXNzaW0gcXVlIGNvbmZpcm1hZG9zLlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCB9fT5cclxuICAgICAgICAgIHtlbGlnaWJsZU9yZGVycy5tYXAoKG9yZGVyKSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBrZXk9e29yZGVyLmlkfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRpY2tldCByaXNlXCJcclxuICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiAxNiwgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiAxMiwgZmxleFdyYXA6IFwid3JhcFwiIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDIgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA3MDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgIHtvcmRlci5kaXNwbGF5SWQgPz8gYFBlZGlkbyAjJHtvcmRlci5pZH1gfSDigJQge29yZGVyLmN1c3RvbWVyTmFtZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT57b3JkZXIuZGVsaXZlcnlBZGRyZXNzfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0QXNzaWduaW5nKG9yZGVyKX0+XHJcbiAgICAgICAgICAgICAgICBBdHJpYnVpciBlbnRyZWdhZG9yXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgIDxzZWN0aW9uPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjE1cmVtXCIsIGRpc3BsYXk6IFwiYmxvY2tcIiwgbWFyZ2luQm90dG9tOiAxMCB9fT5cclxuICAgICAgICAgIEVudHJlZ2FzIGVtIGFuZGFtZW50b1xyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICB7IWRlbGl2ZXJpZXNRdWVyeS5pc0xvYWRpbmcgJiYgZGVsaXZlcmllcy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgICAgdGl0bGU9XCJOZW5odW1hIGVudHJlZ2EgZW0gYW5kYW1lbnRvXCJcclxuICAgICAgICAgICAgZGVzY3JpcHRpb249XCJBc3NpbSBxdWUgdW0gZW50cmVnYWRvciBmb3IgYXRyaWJ1w61kbyBhIHVtIHBlZGlkbywgbyBhY29tcGFuaGFtZW50byBhcGFyZWNlIGFxdWkuXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgICAge2RlbGl2ZXJpZXMubWFwKChkZWxpdmVyeSkgPT4gKFxyXG4gICAgICAgICAgICA8TG9naXN0aWNzRGVsaXZlcnlDYXJkXHJcbiAgICAgICAgICAgICAga2V5PXtkZWxpdmVyeS5pZH1cclxuICAgICAgICAgICAgICBkZWxpdmVyeT17ZGVsaXZlcnl9XHJcbiAgICAgICAgICAgICAgb25BZHZhbmNlZD17aW52YWxpZGF0ZX1cclxuICAgICAgICAgICAgICBvblZlcmlmeUNvZGU9eygpID0+IHNldFZlcmlmeWluZyhkZWxpdmVyeSl9XHJcbiAgICAgICAgICAgICAgb25WaWV3RGV0YWlscz17KCkgPT4gc2V0RGV0YWlsc0ZvcihkZWxpdmVyeSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAge2RldGFpbHNGb3IgJiYgPExvZ2lzdGljc09yZGVyRGV0YWlsc01vZGFsIGRlbGl2ZXJ5PXtkZXRhaWxzRm9yfSBvbkNsb3NlPXsoKSA9PiBzZXREZXRhaWxzRm9yKG51bGwpfSAvPn1cclxuXHJcbiAgICAgIHthc3NpZ25pbmcgJiYgKFxyXG4gICAgICAgIDxBc3NpZ25Ecml2ZXJNb2RhbFxyXG4gICAgICAgICAgb3JkZXI9e2Fzc2lnbmluZ31cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFzc2lnbmluZyhudWxsKX1cclxuICAgICAgICAgIG9uQXNzaWduZWQ9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0QXNzaWduaW5nKG51bGwpO1xyXG4gICAgICAgICAgICBpbnZhbGlkYXRlKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7dmVyaWZ5aW5nICYmIChcclxuICAgICAgICA8VmVyaWZ5Q29kZU1vZGFsXHJcbiAgICAgICAgICBkZWxpdmVyeT17dmVyaWZ5aW5nfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0VmVyaWZ5aW5nKG51bGwpfVxyXG4gICAgICAgICAgb25WZXJpZmllZD17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRWZXJpZnlpbmcobnVsbCk7XHJcbiAgICAgICAgICAgIGludmFsaWRhdGUoKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBMb2dpc3RpY3NEZWxpdmVyeUNhcmQoe1xyXG4gIGRlbGl2ZXJ5LFxyXG4gIG9uQWR2YW5jZWQsXHJcbiAgb25WZXJpZnlDb2RlLFxyXG4gIG9uVmlld0RldGFpbHMsXHJcbn06IHtcclxuICBkZWxpdmVyeTogSUZvb2RMb2dpc3RpY3NEZWxpdmVyeVJlc3BvbnNlO1xyXG4gIG9uQWR2YW5jZWQ6ICgpID0+IHZvaWQ7XHJcbiAgb25WZXJpZnlDb2RlOiAoKSA9PiB2b2lkO1xyXG4gIG9uVmlld0RldGFpbHM6ICgpID0+IHZvaWQ7XHJcbn0pIHtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcblxyXG4gIGNvbnN0IGdvaW5nVG9PcmlnaW5NdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IG1hcmtJRm9vZEdvaW5nVG9PcmlnaW4oZGVsaXZlcnkuaWZvb2RPcmRlcklkKSxcclxuICAgIG9uU3VjY2Vzczogb25BZHZhbmNlZCxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIGF2YW7Dp2FyIOKAlCBjb25maXJhIHNlIG8gcGVkaWRvIGFpbmRhIGVzdMOhIGF0aXZvLlwiKSxcclxuICB9KTtcclxuICBjb25zdCBhcnJpdmVkQXRPcmlnaW5NdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IG1hcmtJRm9vZEFycml2ZWRBdE9yaWdpbihkZWxpdmVyeS5pZm9vZE9yZGVySWQpLFxyXG4gICAgb25TdWNjZXNzOiBvbkFkdmFuY2VkLFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgYXZhbsOnYXIg4oCUIGNvbmZpcmEgc2UgbyBwZWRpZG8gYWluZGEgZXN0w6EgYXRpdm8uXCIpLFxyXG4gIH0pO1xyXG4gIGNvbnN0IGRpc3BhdGNoTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBkaXNwYXRjaElGb29kTG9naXN0aWNzKGRlbGl2ZXJ5Lmlmb29kT3JkZXJJZCksXHJcbiAgICBvblN1Y2Nlc3M6IG9uQWR2YW5jZWQsXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBhdmFuw6dhciDigJQgY29uZmlyYSBzZSBvIHBlZGlkbyBhaW5kYSBlc3TDoSBhdGl2by5cIiksXHJcbiAgfSk7XHJcbiAgY29uc3QgYXJyaXZlZEF0RGVzdGluYXRpb25NdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IG1hcmtJRm9vZEFycml2ZWRBdERlc3RpbmF0aW9uKGRlbGl2ZXJ5Lmlmb29kT3JkZXJJZCksXHJcbiAgICBvblN1Y2Nlc3M6IG9uQWR2YW5jZWQsXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBhdmFuw6dhciDigJQgY29uZmlyYSBzZSBvIHBlZGlkbyBhaW5kYSBlc3TDoSBhdGl2by5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHBlbmRpbmcgPVxyXG4gICAgZ29pbmdUb09yaWdpbk11dGF0aW9uLmlzUGVuZGluZyB8fCBhcnJpdmVkQXRPcmlnaW5NdXRhdGlvbi5pc1BlbmRpbmcgfHwgZGlzcGF0Y2hNdXRhdGlvbi5pc1BlbmRpbmcgfHwgYXJyaXZlZEF0RGVzdGluYXRpb25NdXRhdGlvbi5pc1BlbmRpbmc7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZVwiIHN0eWxlPXt7IHBhZGRpbmc6IDE4LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCB9fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNzAwLCBmb250U2l6ZTogXCIxLjA1cmVtXCIgfX0+XHJcbiAgICAgICAgICAgIHtkZWxpdmVyeS5pZm9vZE9yZGVyRGlzcGxheUlkID8/IGBQZWRpZG8gIyR7ZGVsaXZlcnkuaWZvb2RPcmRlcklkfWB9XHJcbiAgICAgICAgICAgIHtkZWxpdmVyeS5jdXN0b21lck5hbWUgPyBgIOKAlCAke2RlbGl2ZXJ5LmN1c3RvbWVyTmFtZX1gIDogXCJcIn1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIHtkZWxpdmVyeS5kZWxpdmVyeUFkZHJlc3MgJiYgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PntkZWxpdmVyeS5kZWxpdmVyeUFkZHJlc3N9PC9zcGFuPn1cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44MnJlbVwiIH19PlxyXG4gICAgICAgICAgICB7ZGVsaXZlcnkuZHJpdmVyTmFtZX0gwrcge2RlbGl2ZXJ5LmRyaXZlclBob25lfSDCtyB7ZGVsaXZlcnkuZHJpdmVyVmVoaWNsZVR5cGV9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPFN0YXR1c0JhZGdlIGNvbG9yPXtTVEFUVVNfQ09MT1JbZGVsaXZlcnkuc3RhdHVzXSA/PyBcInZhcigtLWluay1mYWludClcIn0+XHJcbiAgICAgICAgICB7U1RBVFVTX0xBQkVMW2RlbGl2ZXJ5LnN0YXR1c10gPz8gZGVsaXZlcnkuc3RhdHVzfVxyXG4gICAgICAgIDwvU3RhdHVzQmFkZ2U+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiwgZmxleFdyYXA6IFwid3JhcFwiIH19PlxyXG4gICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25WaWV3RGV0YWlsc30+XHJcbiAgICAgICAgICBWZXIgZGV0YWxoZXMgbm8gaUZvb2RcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICB7ZGVsaXZlcnkuc3RhdHVzID09PSBcIkRSSVZFUl9BU1NJR05FRFwiICYmIChcclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBsb2FkaW5nPXtnb2luZ1RvT3JpZ2luTXV0YXRpb24uaXNQZW5kaW5nfSBkaXNhYmxlZD17cGVuZGluZ30gb25DbGljaz17KCkgPT4gZ29pbmdUb09yaWdpbk11dGF0aW9uLm11dGF0ZSgpfT5cclxuICAgICAgICAgICAgU2FpdSBwYXJhIGEgbG9qYVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7ZGVsaXZlcnkuc3RhdHVzID09PSBcIkdPSU5HX1RPX09SSUdJTlwiICYmIChcclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBsb2FkaW5nPXthcnJpdmVkQXRPcmlnaW5NdXRhdGlvbi5pc1BlbmRpbmd9IGRpc2FibGVkPXtwZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBhcnJpdmVkQXRPcmlnaW5NdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgIENoZWdvdSBuYSBsb2phXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICAgIHtkZWxpdmVyeS5zdGF0dXMgPT09IFwiQVJSSVZFRF9BVF9PUklHSU5cIiAmJiAoXHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgbG9hZGluZz17ZGlzcGF0Y2hNdXRhdGlvbi5pc1BlbmRpbmd9IGRpc2FibGVkPXtwZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBkaXNwYXRjaE11dGF0aW9uLm11dGF0ZSgpfT5cclxuICAgICAgICAgICAgRGVzcGFjaGFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICAgIHtkZWxpdmVyeS5zdGF0dXMgPT09IFwiRElTUEFUQ0hFRFwiICYmIChcclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICBsb2FkaW5nPXthcnJpdmVkQXREZXN0aW5hdGlvbk11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e3BlbmRpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFycml2ZWRBdERlc3RpbmF0aW9uTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENoZWdvdSBubyBkZXN0aW5vXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICAgIHtkZWxpdmVyeS5zdGF0dXMgPT09IFwiQVJSSVZFRF9BVF9ERVNUSU5BVElPTlwiICYmIChcclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBvbkNsaWNrPXtvblZlcmlmeUNvZGV9PlxyXG4gICAgICAgICAgICBWZXJpZmljYXIgY8OzZGlnbyBkZSBlbnRyZWdhXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcblxyXG4vLyBGYXNlIDljIOKAlCBmZWNoYSBvIGdhcCByZXN0YW50ZSBkbyBtw7NkdWxvIExvZ2lzdGljcyBkYSBhdWRpdG9yaWEgZGUgMjAyNi0wOC0yMC8yMTogZGV0YWxoZXMgZGFcclxuLy8gZW50cmVnYSBkaXJldG8gbm8gaUZvb2QuIEEgZG9jIG9maWNpYWwgbsOjbyBkb2N1bWVudGEgbyBzY2hlbWEgZGEgcmVzcG9zdGEgKHPDsyBcIjxvYmplY3Q+XCIpLCBlbnTDo29cclxuLy8gbyBKU09OIGJydXRvIMOpIGV4aWJpZG8gcHLDqS1mb3JtYXRhZG8g4oCUIG7Do28gaMOhIGNvbW8gc2FiZXIgcXVlIGNhbXBvcyBtb3N0cmFyIGRlIGZvcm1hIGFtaWfDoXZlbC5cclxuZnVuY3Rpb24gTG9naXN0aWNzT3JkZXJEZXRhaWxzTW9kYWwoeyBkZWxpdmVyeSwgb25DbG9zZSB9OiB7IGRlbGl2ZXJ5OiBJRm9vZExvZ2lzdGljc0RlbGl2ZXJ5UmVzcG9uc2U7IG9uQ2xvc2U6ICgpID0+IHZvaWQgfSkge1xyXG4gIGNvbnN0IGRldGFpbHNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImxvZ2lzdGljcy1vcmRlci1kZXRhaWxzXCIsIGRlbGl2ZXJ5Lmlmb29kT3JkZXJJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZExvZ2lzdGljc09yZGVyRGV0YWlscyhkZWxpdmVyeS5pZm9vZE9yZGVySWQpLFxyXG4gIH0pO1xyXG5cclxuICBsZXQgZm9ybWF0dGVkID0gZGV0YWlsc1F1ZXJ5LmRhdGE/LnJhd1BheWxvYWQgPz8gbnVsbDtcclxuICBpZiAoZm9ybWF0dGVkKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBmb3JtYXR0ZWQgPSBKU09OLnN0cmluZ2lmeShKU09OLnBhcnNlKGZvcm1hdHRlZCksIG51bGwsIDIpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIG1hbnTDqW0gbyB0ZXh0byBjcnUgc2UgbsOjbyBmb3IgSlNPTiB2w6FsaWRvXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsIG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPXtgRGV0YWxoZXMgbm8gaUZvb2Qg4oCUICR7ZGVsaXZlcnkuaWZvb2RPcmRlckRpc3BsYXlJZCA/PyBgUGVkaWRvICMke2RlbGl2ZXJ5Lmlmb29kT3JkZXJJZH1gfWB9PlxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyLCBtaW5XaWR0aDogMzYwLCBtYXhXaWR0aDogNTIwIH19PlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44MnJlbVwiIH19PlxyXG4gICAgICAgICAgQSBkb2Mgb2ZpY2lhbCBkbyBpRm9vZCBuw6NvIGRvY3VtZW50YSBvcyBjYW1wb3MgZGVzdGEgcmVzcG9zdGEg4oCUIG8gSlNPTiDDqSBtb3N0cmFkbyBjb21vIG9cclxuICAgICAgICAgIGlGb29kIGRldm9sdmV1LlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICB7ZGV0YWlsc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e2RldGFpbHNRdWVyeS5lcnJvcn0gd2hhdD1cIm9zIGRldGFsaGVzIGRhIGVudHJlZ2FcIiAvPn1cclxuICAgICAgICB7ZGV0YWlsc1F1ZXJ5LmlzTG9hZGluZyAmJiA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+Q2FycmVnYW5kb+KApjwvc3Bhbj59XHJcbiAgICAgICAge2Zvcm1hdHRlZCAmJiAoXHJcbiAgICAgICAgICA8cHJlXHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgbWF4SGVpZ2h0OiAzMjAsXHJcbiAgICAgICAgICAgICAgb3ZlcmZsb3c6IFwiYXV0b1wiLFxyXG4gICAgICAgICAgICAgIGZvbnRTaXplOiBcIjAuNzhyZW1cIixcclxuICAgICAgICAgICAgICBwYWRkaW5nOiAxMCxcclxuICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDgsXHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1zdXJmYWNlLTIsIHJnYmEoMCwwLDAsMC4wNCkpXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtmb3JtYXR0ZWR9XHJcbiAgICAgICAgICA8L3ByZT5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICBGZWNoYXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvTW9kYWw+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gQXNzaWduRHJpdmVyTW9kYWwoe1xyXG4gIG9yZGVyLFxyXG4gIG9uQ2xvc2UsXHJcbiAgb25Bc3NpZ25lZCxcclxufToge1xyXG4gIG9yZGVyOiBJRm9vZE9yZGVyUmVzcG9uc2U7XHJcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxuICBvbkFzc2lnbmVkOiAoKSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG4gIGNvbnN0IFtkcml2ZXJOYW1lLCBzZXREcml2ZXJOYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtkcml2ZXJQaG9uZSwgc2V0RHJpdmVyUGhvbmVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2RyaXZlclZlaGljbGVUeXBlLCBzZXREcml2ZXJWZWhpY2xlVHlwZV0gPSB1c2VTdGF0ZShcIk1PVE9SQ1lDTEVcIik7XHJcblxyXG4gIGNvbnN0IG11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgYXNzaWduSUZvb2REcml2ZXIob3JkZXIuaWQsIHtcclxuICAgICAgICBkcml2ZXJOYW1lOiBkcml2ZXJOYW1lLnRyaW0oKSxcclxuICAgICAgICBkcml2ZXJQaG9uZTogZHJpdmVyUGhvbmUudHJpbSgpLFxyXG4gICAgICAgIGRyaXZlclZlaGljbGVUeXBlLFxyXG4gICAgICB9KSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiRW50cmVnYWRvciBhdHJpYnXDrWRvIOKAlCBvIGlGb29kIGrDoSBmb2kgYXZpc2Fkby5cIik7XHJcbiAgICAgIG9uQXNzaWduZWQoKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBhdHJpYnVpciBvIGVudHJlZ2Fkb3IuXCIpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsIG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPXtgQXRyaWJ1aXIgZW50cmVnYWRvciDigJQgJHtvcmRlci5kaXNwbGF5SWQgPz8gYFBlZGlkbyAjJHtvcmRlci5pZH1gfWB9PlxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE0LCBtaW5XaWR0aDogMzIwIH19PlxyXG4gICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJOb21lIGRvIGVudHJlZ2Fkb3JcIiB2YWx1ZT17ZHJpdmVyTmFtZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXREcml2ZXJOYW1lKGUudGFyZ2V0LnZhbHVlKX0gYXV0b0ZvY3VzIC8+XHJcbiAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlRlbGVmb25lIGRvIGVudHJlZ2Fkb3JcIiB2YWx1ZT17ZHJpdmVyUGhvbmV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0RHJpdmVyUGhvbmUoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIigxMSkgOTg3NjUtNDMyMVwiIC8+XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIGxhYmVsPVwiVmXDrWN1bG9cIiB2YWx1ZT17ZHJpdmVyVmVoaWNsZVR5cGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0RHJpdmVyVmVoaWNsZVR5cGUoZS50YXJnZXQudmFsdWUpfT5cclxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNT1RPUkNZQ0xFXCI+TW90bzwvb3B0aW9uPlxyXG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJJQ1lDTEVcIj5CaWNpY2xldGE8L29wdGlvbj5cclxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDQVJcIj5DYXJybzwvb3B0aW9uPlxyXG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk9OX0ZPT1RcIj5BIHDDqTwvb3B0aW9uPlxyXG4gICAgICAgIDwvU2VsZWN0RmllbGQ+XHJcblxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTAsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICBWb2x0YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXshZHJpdmVyTmFtZS50cmltKCkgfHwgIWRyaXZlclBob25lLnRyaW0oKX1cclxuICAgICAgICAgICAgbG9hZGluZz17bXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBtdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQXRyaWJ1aXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvTW9kYWw+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gVmVyaWZ5Q29kZU1vZGFsKHtcclxuICBkZWxpdmVyeSxcclxuICBvbkNsb3NlLFxyXG4gIG9uVmVyaWZpZWQsXHJcbn06IHtcclxuICBkZWxpdmVyeTogSUZvb2RMb2dpc3RpY3NEZWxpdmVyeVJlc3BvbnNlO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25WZXJpZmllZDogKCkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbY29kZSwgc2V0Q29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiB2ZXJpZnlJRm9vZERlbGl2ZXJ5Q29kZShkZWxpdmVyeS5pZm9vZE9yZGVySWQsIGNvZGUudHJpbSgpKSxcclxuICAgIG9uU3VjY2VzczogKHJlc3VsdCkgPT4ge1xyXG4gICAgICBpZiAocmVzdWx0LmNvZGVNYXRjaGVkKSB7XHJcbiAgICAgICAgdG9hc3Quc3VjY2VzcyhcIkVudHJlZ2EgY29uZmlybWFkYS5cIik7XHJcbiAgICAgICAgb25WZXJpZmllZCgpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRvYXN0LmVycm9yKFwiQ8OzZGlnbyBpbmNvcnJldG8g4oCUIGNvbmZpcmEgY29tIG8gY2xpZW50ZSBlIHRlbnRlIGRlIG5vdm8uXCIpO1xyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgdmVyaWZpY2FyIG8gY8OzZGlnby5cIiksXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TW9kYWwgb25DbG9zZT17b25DbG9zZX0gdGl0bGU9XCJWZXJpZmljYXIgY8OzZGlnbyBkZSBlbnRyZWdhXCI+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQsIG1pbldpZHRoOiAyODAgfX0+XHJcbiAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkPDs2RpZ28gaW5mb3JtYWRvIHBlbG8gY2xpZW50ZVwiIHZhbHVlPXtjb2RlfSBvbkNoYW5nZT17KGUpID0+IHNldENvZGUoZS50YXJnZXQudmFsdWUpfSBhdXRvRm9jdXMgLz5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEwLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgICAgVm9sdGFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBkaXNhYmxlZD17IWNvZGUudHJpbSgpfSBsb2FkaW5nPXttdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IG11dGF0aW9uLm11dGF0ZSgpfT5cclxuICAgICAgICAgICAgVmVyaWZpY2FyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L01vZGFsPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2ludGVncmF0aW9ucy9JRm9vZExvZ2lzdGljc1BhZ2UudHN4In0=