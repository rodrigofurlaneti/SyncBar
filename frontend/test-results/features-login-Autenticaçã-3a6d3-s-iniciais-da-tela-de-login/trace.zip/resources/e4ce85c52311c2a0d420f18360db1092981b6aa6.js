import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/ProductsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { useDialog } from "/src/ui/Dialog.tsx";
import {
  activateCategory,
  activateProduct,
  createCategory,
  createProduct,
  deactivateCategory,
  deactivateProduct,
  getCategories,
  getCategoriesForManagement,
  getMenuForManagement,
  updateCategory,
  updateProduct,
  uploadProductImage
} from "/src/features/catalog/api.ts";
import { getStockByBranch } from "/src/features/stock/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { formatBRL, unitOfMeasureLabel } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { ProductComplementLinkPanel } from "/src/features/catalog/ProductComplementLinkPanel.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { Button } from "/src/ui/Button.tsx";
import { Field, TextField, SelectField } from "/src/ui/Field.tsx";
import { Switch } from "/src/ui/Switch.tsx";
import { StatusBadge } from "/src/ui/StatusBadge.tsx";
import { useToast } from "/src/ui/Toast.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
const PAGE_SIZE = 8;
const ALL_CATEGORIES = "all";
const emptyForm = {
  categoryId: "",
  unitOfMeasureId: "1",
  name: "",
  description: "",
  barcode: "",
  salePrice: "",
  costPrice: "",
  isStockControlled: true,
  preparationTimeMinutes: ""
};
const parseNum = (raw) => {
  if (raw.trim() === "") return null;
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) ? value : null;
};
const DragIcon = () => /* @__PURE__ */ jsxDEV("svg", { width: "13", height: "13", viewBox: "0 0 24 24", fill: "currentColor", "aria-hidden": "true", children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "8", cy: "6", r: "1.6" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
    lineNumber: 81,
    columnNumber: 9
  }, this),
  /* @__PURE__ */ jsxDEV("circle", { cx: "16", cy: "6", r: "1.6" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
    lineNumber: 81,
    columnNumber: 41
  }, this),
  /* @__PURE__ */ jsxDEV("circle", { cx: "8", cy: "12", r: "1.6" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
    lineNumber: 82,
    columnNumber: 9
  }, this),
  /* @__PURE__ */ jsxDEV("circle", { cx: "16", cy: "12", r: "1.6" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
    lineNumber: 82,
    columnNumber: 42
  }, this),
  /* @__PURE__ */ jsxDEV("circle", { cx: "8", cy: "18", r: "1.6" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
    lineNumber: 83,
    columnNumber: 9
  }, this),
  /* @__PURE__ */ jsxDEV("circle", { cx: "16", cy: "18", r: "1.6" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
    lineNumber: 83,
    columnNumber: 42
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
  lineNumber: 80,
  columnNumber: 1
}, this);
_c = DragIcon;
const SearchIcon = () => /* @__PURE__ */ jsxDEV("svg", { width: "15", height: "15", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true", children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "11", cy: "11", r: "7", stroke: "currentColor", strokeWidth: "1.8" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
    lineNumber: 88,
    columnNumber: 9
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M21 21l-4.3-4.3", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
    lineNumber: 89,
    columnNumber: 9
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
  lineNumber: 87,
  columnNumber: 1
}, this);
_c2 = SearchIcon;
const ChevronLeft = () => /* @__PURE__ */ jsxDEV("svg", { width: "12", height: "12", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("path", { d: "M15 5l-7 7 7 7", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
  lineNumber: 94,
  columnNumber: 9
}, this) }, void 0, false, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
  lineNumber: 93,
  columnNumber: 1
}, this);
_c3 = ChevronLeft;
const ChevronRight = () => /* @__PURE__ */ jsxDEV("svg", { width: "12", height: "12", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("path", { d: "M9 5l7 7-7 7", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
  lineNumber: 99,
  columnNumber: 9
}, this) }, void 0, false, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
  lineNumber: 98,
  columnNumber: 1
}, this);
_c4 = ChevronRight;
export function ProductsPage() {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const toast = useToast();
  const { companyId, branchId } = useAuthStore();
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [newCategory, setNewCategory] = useState("");
  const [creatingCategory, setCreatingCategory] = useState(false);
  const [modalNewCategory, setModalNewCategory] = useState("");
  const [editingCategoryId, setEditingCategoryId] = useState(null);
  const [categoryEditName, setCategoryEditName] = useState("");
  const [categoryEditOrder, setCategoryEditOrder] = useState("");
  const [dragCategoryId, setDragCategoryId] = useState(null);
  const [imageFile, setImageFile] = useState(null);
  const [error, setError] = useState(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState(ALL_CATEGORIES);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage] = useState(1);
  const imagePreviewUrl = useMemo(
    () => imageFile !== null ? URL.createObjectURL(imageFile) : null,
    [imageFile]
  );
  useEffect(() => {
    return () => {
      if (imagePreviewUrl !== null) URL.revokeObjectURL(imagePreviewUrl);
    };
  }, [imagePreviewUrl]);
  const categoriesQuery = useQuery({
    queryKey: ["categories", companyId],
    queryFn: () => getCategories(companyId ?? 1)
  });
  const categoriesManagementQuery = useQuery({
    queryKey: ["categories", "management", companyId],
    queryFn: () => getCategoriesForManagement(companyId ?? 1)
  });
  const productsQuery = useQuery({
    queryKey: ["menu", "management", companyId],
    queryFn: () => getMenuForManagement(companyId ?? 1)
  });
  const stockQuery = useQuery({
    queryKey: ["stock", "branch", branchId],
    queryFn: () => getStockByBranch(branchId ?? 1),
    enabled: branchId != null
  });
  const stockByProduct = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const s of stockQuery.data ?? []) map.set(s.productId, s);
    return map;
  }, [stockQuery.data]);
  const sortedCategories = useMemo(
    () => [...categoriesManagementQuery.data ?? []].sort((a, b) => a.displayOrder - b.displayOrder),
    [categoriesManagementQuery.data]
  );
  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: ["menu"] });
    void queryClient.invalidateQueries({ queryKey: ["categories"] });
  };
  const openEditor = (product) => {
    setError(null);
    setImageFile(null);
    setCreatingCategory(false);
    setModalNewCategory("");
    setEditing(product);
    if (product === "new") setForm({ ...emptyForm, categoryId: String(categoriesQuery.data?.[0]?.id ?? "") });
    else
      setForm({
        categoryId: String(product.categoryId),
        unitOfMeasureId: String(product.unitOfMeasureId),
        name: product.name,
        description: product.description ?? "",
        barcode: product.barcode ?? "",
        salePrice: String(product.salePrice),
        costPrice: product.costPrice === null ? "" : String(product.costPrice),
        isStockControlled: product.isStockControlled,
        preparationTimeMinutes: product.preparationTimeMinutes === null ? "" : String(product.preparationTimeMinutes)
      });
  };
  const buildPayload = () => ({
    categoryId: Number(form.categoryId),
    unitOfMeasureId: Number(form.unitOfMeasureId),
    name: form.name.trim(),
    description: form.description.trim() === "" ? null : form.description.trim(),
    barcode: form.barcode.trim() === "" ? null : form.barcode.trim(),
    salePrice: parseNum(form.salePrice) ?? 0,
    costPrice: parseNum(form.costPrice),
    isStockControlled: form.isStockControlled,
    preparationTimeMinutes: form.preparationTimeMinutes.trim() === "" ? null : Number(form.preparationTimeMinutes)
  });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const saveMutation = useMutation({
    mutationFn: async () => {
      const productId = editing === "new" ? await createProduct(companyId ?? 1, buildPayload()) : editing.id;
      if (editing !== "new") await updateProduct(productId, buildPayload());
      if (imageFile !== null) await uploadProductImage(productId, imageFile);
    },
    onSuccess: () => {
      toast.success(editing === "new" ? "Produto criado." : "Produto atualizado.");
      setEditing(null);
      refresh();
    },
    onError: onApiError
  });
  const toggleProductMutation = useMutation({
    mutationFn: ({ id, activate }) => activate ? activateProduct(id) : deactivateProduct(id),
    onSuccess: (_data, vars) => {
      toast.success(vars.activate ? "Produto ativado." : "Produto desativado.");
      refresh();
    },
    onError: onApiError
  });
  const toggleProduct = async (product) => {
    if (product.isActive) {
      const confirmed = await dialog.confirm({
        title: "Desativar produto",
        message: `Desativar "${product.name}"? Ele deixa de aparecer no cardápio para pedidos.`,
        confirmLabel: "Desativar",
        danger: true
      });
      if (!confirmed) return;
    }
    toggleProductMutation.mutate({ id: product.id, activate: !product.isActive });
  };
  const categoryMutation = useMutation({
    mutationFn: () => createCategory(companyId ?? 1, newCategory.trim(), (categoriesManagementQuery.data?.length ?? 0) + 1),
    onSuccess: () => {
      setNewCategory("");
      refresh();
    },
    onError: onApiError
  });
  const modalCategoryMutation = useMutation({
    mutationFn: () => createCategory(companyId ?? 1, modalNewCategory.trim(), (categoriesManagementQuery.data?.length ?? 0) + 1),
    onSuccess: (newCategoryId) => {
      toast.success("Categoria criada.");
      setForm((f) => ({ ...f, categoryId: String(newCategoryId) }));
      setModalNewCategory("");
      setCreatingCategory(false);
      setError(null);
      refresh();
    },
    onError: onApiError
  });
  const startCategoryEdit = (category) => {
    setEditingCategoryId(category.id);
    setCategoryEditName(category.name);
    setCategoryEditOrder(String(category.displayOrder));
  };
  const cancelCategoryEdit = () => {
    setEditingCategoryId(null);
    setCategoryEditName("");
    setCategoryEditOrder("");
  };
  const updateCategoryMutation = useMutation({
    mutationFn: () => updateCategory(editingCategoryId, categoryEditName.trim(), Number(categoryEditOrder) || 0),
    onSuccess: () => {
      toast.success("Categoria atualizada.");
      cancelCategoryEdit();
      refresh();
    },
    onError: onApiError
  });
  const toggleCategoryMutation = useMutation({
    mutationFn: ({ id, activate }) => activate ? activateCategory(id) : deactivateCategory(id),
    onSuccess: (_data, vars) => {
      toast.success(vars.activate ? "Categoria ativada." : "Categoria desativada.");
      refresh();
    },
    onError: onApiError
  });
  const toggleCategory = async (category) => {
    if (category.isActive) {
      const confirmed = await dialog.confirm({
        title: "Desativar categoria",
        message: `Desativar "${category.name}"? Produtos já cadastrados nela continuam funcionando, mas ela deixa de aparecer como opção para novos cadastros.`,
        confirmLabel: "Desativar",
        danger: true
      });
      if (!confirmed) return;
    }
    toggleCategoryMutation.mutate({ id: category.id, activate: !category.isActive });
  };
  const reorderMutation = useMutation({
    mutationFn: async ({ from, to }) => {
      await Promise.all(
        [
          updateCategory(from.id, from.name, to.displayOrder),
          updateCategory(to.id, to.name, from.displayOrder)
        ]
      );
    },
    onSuccess: () => refresh(),
    onError: onApiError
  });
  const handleCategoryDrop = (target) => {
    const source = sortedCategories.find((c) => c.id === dragCategoryId);
    setDragCategoryId(null);
    if (!source || source.id === target.id) return;
    reorderMutation.mutate({ from: source, to: target });
  };
  const selectCategory = (id) => {
    setSelectedCategoryId(id);
    setPage(1);
  };
  const filteredProducts = useMemo(() => {
    let list = productsQuery.data ?? [];
    if (selectedCategoryId !== ALL_CATEGORIES) list = list.filter((p) => p.categoryId === selectedCategoryId);
    if (statusFilter === "active") list = list.filter((p) => p.isActive);
    if (statusFilter === "inactive") list = list.filter((p) => !p.isActive);
    if (search.trim() !== "") {
      const q = search.trim().toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q));
    }
    return list;
  }, [productsQuery.data, selectedCategoryId, statusFilter, search]);
  const totalPages = Math.max(1, Math.ceil(filteredProducts.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * PAGE_SIZE;
  const pageItems = filteredProducts.slice(pageStart, pageStart + PAGE_SIZE);
  const stockBadge = (product) => {
    if (!product.isStockControlled) return /* @__PURE__ */ jsxDEV(StatusBadge, { color: "var(--ink-faint)", children: "Sem controle" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 370,
      columnNumber: 44
    }, this);
    const stock = stockByProduct.get(product.id);
    if (!stock) return /* @__PURE__ */ jsxDEV(StatusBadge, { color: "var(--ink-faint)", children: "Sem registro" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 372,
      columnNumber: 24
    }, this);
    if (stock.currentQuantity <= 0) return /* @__PURE__ */ jsxDEV(StatusBadge, { color: "var(--danger)", children: "Sem estoque" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 373,
      columnNumber: 44
    }, this);
    if (stock.isBelowMinimum) return /* @__PURE__ */ jsxDEV(StatusBadge, { color: "var(--amber)", children: [
      "Baixo · ",
      stock.currentQuantity
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 374,
      columnNumber: 38
    }, this);
    return /* @__PURE__ */ jsxDEV(StatusBadge, { color: "var(--ok)", children: [
      "Em estoque · ",
      stock.currentQuantity
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 375,
      columnNumber: 12
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1280, margin: "0 auto", position: "relative" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Cardápio" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
        lineNumber: 381,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
        lineNumber: 382,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: () => openEditor("new"), children: "+ Novo produto" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
        lineNumber: 383,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 380,
      columnNumber: 13
    }, this),
    categoriesManagementQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: categoriesManagementQuery.error, what: "as categorias" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 386,
      columnNumber: 51
    }, this),
    productsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: productsQuery.error, what: "o cardápio" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 387,
      columnNumber: 39
    }, this),
    error && !editing && /* @__PURE__ */ jsxDEV("p", { className: "error-text", role: "alert", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 389,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "catalog-split rise rise-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "catalog-panel", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "catalog-panel-head", children: [
          /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "0.95rem", color: "var(--ink-dim)" }, children: "Categorias" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 398,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "catalog-count", children: sortedCategories.length }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 399,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
          lineNumber: 397,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "category-list", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `category-row is-pinned ${selectedCategoryId === ALL_CATEGORIES ? "is-selected" : ""}`,
              onClick: () => selectCategory(ALL_CATEGORIES),
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "category-drag-handle", style: { visibility: "hidden" }, children: /* @__PURE__ */ jsxDEV(DragIcon, {}, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 407,
                  columnNumber: 101
                }, this) }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 407,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "category-main", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "category-name", children: "Todos os produtos" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 409,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "category-count-pill", children: productsQuery.data?.length ?? 0 }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 410,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 408,
                  columnNumber: 29
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 403,
              columnNumber: 25
            },
            this
          ),
          sortedCategories.map(
            (category, index) => editingCategoryId === category.id ? /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 6, alignItems: "center", padding: "4px 8px" }, children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  autoFocus: true,
                  value: categoryEditName,
                  onChange: (e) => setCategoryEditName(e.target.value),
                  style: { flex: 1, minWidth: 0, minHeight: 36 }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 417,
                  columnNumber: 37
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  inputMode: "numeric",
                  value: categoryEditOrder,
                  onChange: (e) => setCategoryEditOrder(e.target.value),
                  title: "Ordem de exibição",
                  style: { width: 52, minHeight: 36 }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 423,
                  columnNumber: 37
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  loading: updateCategoryMutation.isPending,
                  disabled: categoryEditName.trim() === "",
                  onClick: () => updateCategoryMutation.mutate(),
                  children: "Salvar"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 431,
                  columnNumber: 37
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", iconOnly: true, "aria-label": "Cancelar edição", onClick: cancelCategoryEdit, children: "✕" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 439,
                columnNumber: 37
              }, this)
            ] }, category.id, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 416,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `category-row ${selectedCategoryId === category.id ? "is-selected" : ""} ${!category.isActive ? "is-inactive" : ""} ${dragCategoryId === category.id ? "is-dragging" : ""}`,
                draggable: true,
                onClick: () => selectCategory(category.id),
                onDragStart: () => setDragCategoryId(category.id),
                onDragEnd: () => setDragCategoryId(null),
                onDragOver: (e) => e.preventDefault(),
                onDrop: (e) => {
                  e.preventDefault();
                  handleCategoryDrop(category);
                },
                children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "category-drag-handle", title: "Arraste para reordenar", onClick: (e) => e.stopPropagation(), children: /* @__PURE__ */ jsxDEV(DragIcon, {}, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 455,
                    columnNumber: 41
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 454,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "category-order", children: String(index + 1).padStart(2, "0") }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 457,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "category-main", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "category-name", children: category.name }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 459,
                      columnNumber: 41
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "category-count-pill", children: category.productCount }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 460,
                      columnNumber: 41
                    }, this),
                    !category.isActive && /* @__PURE__ */ jsxDEV("span", { className: "category-inactive-tag", children: "Inativa" }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 461,
                      columnNumber: 64
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 458,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Switch,
                    {
                      checked: category.isActive,
                      onChange: () => toggleCategory(category),
                      label: category.isActive ? `Desativar categoria ${category.name}` : `Ativar categoria ${category.name}`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 463,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      size: "sm",
                      iconOnly: true,
                      "aria-label": `Editar categoria ${category.name}`,
                      onClick: (e) => {
                        e.stopPropagation();
                        startCategoryEdit(category);
                      },
                      children: "✎"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 468,
                      columnNumber: 37
                    },
                    this
                  )
                ]
              },
              category.id,
              true,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 444,
                columnNumber: 13
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
          lineNumber: 402,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "catalog-new-cat", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              placeholder: "Nova categoria…",
              value: newCategory,
              onChange: (e) => setNewCategory(e.target.value),
              onKeyDown: (e) => {
                if (e.key === "Enter" && newCategory.trim() !== "") categoryMutation.mutate();
              }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 482,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "sm",
              iconOnly: true,
              "aria-label": "Criar categoria",
              disabled: newCategory.trim() === "" || categoryMutation.isPending,
              loading: categoryMutation.isPending,
              onClick: () => categoryMutation.mutate(),
              children: "+"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 490,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
          lineNumber: 481,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "catalog-hint", children: "Arraste para reordenar. Desativar uma categoria não afeta os produtos já vinculados a ela." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
          lineNumber: 502,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
        lineNumber: 396,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "catalog-panel", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "catalog-toolbar", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "catalog-search", children: [
            /* @__PURE__ */ jsxDEV(SearchIcon, {}, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 511,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                placeholder: "Buscar produto por nome…",
                value: search,
                onChange: (e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 512,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 510,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "segmented", role: "group", "aria-label": "Filtrar por status", children: ["all", "active", "inactive"].map(
            (s) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: statusFilter === s ? "is-active" : "",
                onClick: () => {
                  setStatusFilter(s);
                  setPage(1);
                },
                children: s === "all" ? "Todos" : s === "active" ? "Ativos" : "Inativos"
              },
              s,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 520,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 518,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
          lineNumber: 509,
          columnNumber: 21
        }, this),
        productsQuery.isLoading && /* @__PURE__ */ jsxDEV("div", { style: { padding: 16 }, children: /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 5, rowHeight: 62 }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
          lineNumber: 532,
          columnNumber: 78
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
          lineNumber: 532,
          columnNumber: 49
        }, this),
        !productsQuery.isLoading && filteredProducts.length === 0 && /* @__PURE__ */ jsxDEV(
          EmptyState,
          {
            icon: "🍽",
            title: "Nenhum produto encontrado",
            description: search.trim() !== "" ? `Nenhum resultado para "${search.trim()}". Ajuste a busca ou o filtro de status.` : (productsQuery.data?.length ?? 0) === 0 ? "Adicione o primeiro item do cardápio para começar a montar pedidos." : "Nenhum produto nesta categoria com o filtro atual.",
            action: /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: () => openEditor("new"), children: "+ Novo produto" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 546,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 535,
            columnNumber: 11
          },
          this
        ),
        !productsQuery.isLoading && filteredProducts.length > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { border: "none", borderRadius: 0 }, children: pageItems.map(
            (product) => /* @__PURE__ */ jsxDEV("div", { className: `ticket-row product-row ${!product.isActive ? "is-inactive" : ""}`, children: /* @__PURE__ */ jsxDEV("div", { className: "product-row-grid", style: { flex: 1 }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12, alignItems: "center", minWidth: 0 }, children: [
                product.imageUrl ? /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: product.imageUrl,
                    alt: product.name,
                    width: 44,
                    height: 44,
                    loading: "lazy",
                    style: { width: 44, height: 44, objectFit: "cover", borderRadius: 8, border: "1px solid var(--line)", flexShrink: 0 }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 561,
                    columnNumber: 21
                  },
                  this
                ) : /* @__PURE__ */ jsxDEV("div", { style: { width: 44, height: 44, borderRadius: 8, background: "var(--bg-press)", display: "grid", placeItems: "center", color: "var(--ink-faint)", fontSize: "1.1rem", flexShrink: 0 }, children: "🍽" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 570,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2, minWidth: 0 }, children: [
                  /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", alignItems: "center", gap: 7, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }, children: [
                    product.name,
                    !product.isActive && /* @__PURE__ */ jsxDEV("span", { className: "category-inactive-tag", children: "Inativo" }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 577,
                      columnNumber: 79
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 575,
                    columnNumber: 53
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }, children: [
                    product.categoryName,
                    product.description ? ` · ${product.description}` : ""
                  ] }, void 0, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 579,
                    columnNumber: 53
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 574,
                  columnNumber: 49
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 559,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--amber)", textAlign: "right" }, children: formatBRL(product.salePrice) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 585,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "product-stock-cell", children: stockBadge(product) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 588,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, alignItems: "center", justifyContent: "flex-end" }, children: [
                /* @__PURE__ */ jsxDEV(Button, { size: "sm", iconOnly: true, "aria-label": `Editar ${product.name}`, onClick: () => openEditor(product), children: "✎" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 590,
                  columnNumber: 49
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Switch,
                  {
                    checked: product.isActive,
                    onChange: () => toggleProduct(product),
                    label: product.isActive ? `Desativar ${product.name}` : `Ativar ${product.name}`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 593,
                    columnNumber: 49
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 589,
                columnNumber: 45
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 558,
              columnNumber: 41
            }, this) }, product.id, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 557,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 555,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "catalog-footer", children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              "Mostrando ",
              pageStart + 1,
              "–",
              Math.min(pageStart + PAGE_SIZE, filteredProducts.length),
              " de ",
              filteredProducts.length,
              " produtos"
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 605,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pager", children: [
              /* @__PURE__ */ jsxDEV("button", { type: "button", disabled: currentPage <= 1, onClick: () => setPage(currentPage - 1), "aria-label": "Página anterior", children: /* @__PURE__ */ jsxDEV(ChevronLeft, {}, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 610,
                columnNumber: 41
              }, this) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 609,
                columnNumber: 37
              }, this),
              Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (n) => /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: n === currentPage ? "is-current" : "",
                    onClick: () => setPage(n),
                    children: n
                  },
                  n,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 613,
                    columnNumber: 17
                  },
                  this
                )
              ),
              /* @__PURE__ */ jsxDEV("button", { type: "button", disabled: currentPage >= totalPages, onClick: () => setPage(currentPage + 1), "aria-label": "Próxima página", children: /* @__PURE__ */ jsxDEV(ChevronRight, {}, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 623,
                columnNumber: 41
              }, this) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 622,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 608,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 604,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
          lineNumber: 554,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
        lineNumber: 508,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
      lineNumber: 394,
      columnNumber: 13
    }, this),
    editing !== null && /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: editing === "new" ? "Novo produto" : "Editar produto",
        onClose: () => setEditing(null),
        variant: "center",
        wide: true,
        children: [
          /* @__PURE__ */ jsxDEV(
            TextField,
            {
              label: "Nome",
              type: "text",
              value: form.name,
              onChange: (e) => setForm({ ...form, name: e.target.value }),
              autoFocus: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 639,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { alignItems: "end" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 240 }, children: /* @__PURE__ */ jsxDEV(
              Field,
              {
                label: /* @__PURE__ */ jsxDEV("span", { className: "ui-row", style: { justifyContent: "space-between", width: "100%" }, children: [
                  "Categoria",
                  !creatingCategory && /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => setCreatingCategory(true),
                      style: { background: "transparent", border: "none", color: "var(--amber)", cursor: "pointer", fontSize: "0.8rem", padding: 0 },
                      children: "+ nova categoria"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 658,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 655,
                  columnNumber: 15
                }, this),
                children: (a11y) => creatingCategory ? /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 6 }, children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      ...a11y,
                      type: "text",
                      autoFocus: true,
                      placeholder: "Nome da categoria",
                      value: modalNewCategory,
                      onChange: (e) => setModalNewCategory(e.target.value),
                      onKeyDown: (e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          if (modalNewCategory.trim() !== "") modalCategoryMutation.mutate();
                        } else if (e.key === "Escape") {
                          setCreatingCategory(false);
                          setModalNewCategory("");
                        }
                      },
                      style: { flex: 1, minWidth: 0 }
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 672,
                      columnNumber: 45
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      size: "sm",
                      loading: modalCategoryMutation.isPending,
                      disabled: modalNewCategory.trim() === "",
                      onClick: () => modalCategoryMutation.mutate(),
                      children: "Criar"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 690,
                      columnNumber: 45
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      size: "sm",
                      iconOnly: true,
                      "aria-label": "Cancelar criação de categoria",
                      onClick: () => {
                        setCreatingCategory(false);
                        setModalNewCategory("");
                      },
                      children: "✕"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                      lineNumber: 698,
                      columnNumber: 45
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 671,
                  columnNumber: 15
                }, this) : /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    ...a11y,
                    value: form.categoryId,
                    onChange: (e) => setForm({ ...form, categoryId: e.target.value }),
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione a categoria…" }, void 0, false, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                        lineNumber: 713,
                        columnNumber: 45
                      }, this),
                      (categoriesQuery.data ?? []).map(
                        (c) => /* @__PURE__ */ jsxDEV("option", { value: c.id, children: c.name }, c.id, false, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                          lineNumber: 715,
                          columnNumber: 17
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 708,
                    columnNumber: 15
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 653,
                columnNumber: 29
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 652,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
              SelectField,
              {
                label: "Unidade",
                value: form.unitOfMeasureId,
                onChange: (e) => setForm({ ...form, unitOfMeasureId: e.target.value }),
                children: Object.entries(unitOfMeasureLabel).map(
                  ([id, label]) => /* @__PURE__ */ jsxDEV("option", { value: id, children: label }, id, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                    lineNumber: 729,
                    columnNumber: 15
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 723,
                columnNumber: 29
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 722,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 651,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
              TextField,
              {
                label: "Preço de venda (R$)",
                inputMode: "decimal",
                value: form.salePrice,
                onChange: (e) => setForm({ ...form, salePrice: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 737,
                columnNumber: 29
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 736,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
              TextField,
              {
                label: "Custo (R$, opcional)",
                inputMode: "decimal",
                value: form.costPrice,
                onChange: (e) => setForm({ ...form, costPrice: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 745,
                columnNumber: 29
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 744,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 735,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            TextField,
            {
              label: "Descrição",
              type: "text",
              value: form.description,
              onChange: (e) => setForm({ ...form, description: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 754,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { alignItems: "end" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
              TextField,
              {
                label: "Preparo (min, opcional)",
                inputMode: "numeric",
                value: form.preparationTimeMinutes,
                onChange: (e) => setForm({ ...form, preparationTimeMinutes: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 763,
                columnNumber: 29
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 762,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 10, paddingBottom: 12 }, children: [
              /* @__PURE__ */ jsxDEV(
                Switch,
                {
                  checked: form.isStockControlled,
                  onChange: (next) => setForm({ ...form, isStockControlled: next }),
                  label: "Controla estoque"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                  lineNumber: 771,
                  columnNumber: 29
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Controla estoque" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 776,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 770,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 761,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "field-label", children: "Foto do produto (JPG/PNG/WebP, até 2 MB)" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 781,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "file",
                accept: "image/jpeg,image/png,image/webp",
                onChange: (e) => setImageFile(e.target.files?.[0] ?? null)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 782,
                columnNumber: 25
              },
              this
            ),
            (imagePreviewUrl !== null || editing !== "new" && editing !== null && editing.imageUrl) && /* @__PURE__ */ jsxDEV(
              "img",
              {
                src: imagePreviewUrl ?? editing.imageUrl,
                alt: "Prévia",
                width: 90,
                height: 90,
                style: { width: 90, height: 90, objectFit: "cover", borderRadius: 10, border: "1px solid var(--line)" }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
                lineNumber: 788,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 780,
            columnNumber: 21
          }, this),
          editing !== "new" && editing !== null && /* @__PURE__ */ jsxDEV(ProductComplementLinkPanel, { productId: editing.id }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 799,
            columnNumber: 9
          }, this),
          error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", role: "alert", children: error }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 803,
            columnNumber: 9
          }, this),
          form.categoryId === "" && /* @__PURE__ */ jsxDEV("p", { className: "field-hint", style: { margin: 0 }, children: "Selecione uma categoria para habilitar o salvar." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
            lineNumber: 808,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "primary",
              block: true,
              loading: saveMutation.isPending,
              disabled: form.name.trim() === "" || form.categoryId === "",
              onClick: () => saveMutation.mutate(),
              children: "Salvar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
              lineNumber: 813,
              columnNumber: 21
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
        lineNumber: 633,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx",
    lineNumber: 379,
    columnNumber: 5
  }, this);
}
_s(ProductsPage, "8ajlIM9unsnCCVGIiWF66bXUyqs=", false, function() {
  return [useQueryClient, useDialog, useToast, useAuthStore, useQuery, useQuery, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation];
});
_c5 = ProductsPage;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "DragIcon");
$RefreshReg$(_c2, "SearchIcon");
$RefreshReg$(_c3, "ChevronLeft");
$RefreshReg$(_c4, "ChevronRight");
$RefreshReg$(_c5, "ProductsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRRLFNBeWRnQixVQXpkaEI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBN0RSLFNBQVNBLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUM3QyxTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQsU0FBU0MsaUJBQWlCO0FBQzFCO0FBQUEsRUFDSUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FFRztBQUNQLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVdDLDBCQUEwQjtBQUU5QyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0NBQWtDO0FBQzNDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxPQUFPQyxXQUFXQyxtQkFBbUI7QUFDOUMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxvQkFBb0I7QUFFN0IsTUFBTUMsWUFBWTtBQUNsQixNQUFNQyxpQkFBaUI7QUFHdkIsTUFBTUMsWUFBWTtBQUFBLEVBQ2RDLFlBQVk7QUFBQSxFQUNaQyxpQkFBaUI7QUFBQSxFQUNqQkMsTUFBTTtBQUFBLEVBQ05DLGFBQWE7QUFBQSxFQUNiQyxTQUFTO0FBQUEsRUFDVEMsV0FBVztBQUFBLEVBQ1hDLFdBQVc7QUFBQSxFQUNYQyxtQkFBbUI7QUFBQSxFQUNuQkMsd0JBQXdCO0FBQzVCO0FBSUEsTUFBTUMsV0FBV0EsQ0FBQ0MsUUFBK0I7QUFDN0MsTUFBSUEsSUFBSUMsS0FBSyxNQUFNLEdBQUksUUFBTztBQUM5QixRQUFNQyxRQUFRQyxPQUFPSCxJQUFJSSxRQUFRLEtBQUssR0FBRyxDQUFDO0FBQzFDLFNBQU9ELE9BQU9FLFNBQVNILEtBQUssSUFBSUEsUUFBUTtBQUM1QztBQUdBLE1BQU1JLFdBQVdBLE1BQ2IsdUJBQUMsU0FBSSxPQUFNLE1BQUssUUFBTyxNQUFLLFNBQVEsYUFBWSxNQUFLLGdCQUFlLGVBQVksUUFDNUU7QUFBQSx5QkFBQyxZQUFPLElBQUcsS0FBSSxJQUFHLEtBQUksR0FBRSxTQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTZCO0FBQUEsRUFBRyx1QkFBQyxZQUFPLElBQUcsTUFBSyxJQUFHLEtBQUksR0FBRSxTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThCO0FBQUEsRUFDOUQsdUJBQUMsWUFBTyxJQUFHLEtBQUksSUFBRyxNQUFLLEdBQUUsU0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE4QjtBQUFBLEVBQUcsdUJBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxNQUFLLEdBQUUsU0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUErQjtBQUFBLEVBQ2hFLHVCQUFDLFlBQU8sSUFBRyxLQUFJLElBQUcsTUFBSyxHQUFFLFNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEI7QUFBQSxFQUFHLHVCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsTUFBSyxHQUFFLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0I7QUFBQSxLQUhwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BSUE7QUFDRkMsS0FOSUQ7QUFPTixNQUFNRSxhQUFhQSxNQUNmLHVCQUFDLFNBQUksT0FBTSxNQUFLLFFBQU8sTUFBSyxTQUFRLGFBQVksTUFBSyxRQUFPLGVBQVksUUFDcEU7QUFBQSx5QkFBQyxZQUFPLElBQUcsTUFBSyxJQUFHLE1BQUssR0FBRSxLQUFJLFFBQU8sZ0JBQWUsYUFBWSxTQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFFO0FBQUEsRUFDckUsdUJBQUMsVUFBSyxHQUFFLG1CQUFrQixRQUFPLGdCQUFlLGFBQVksT0FBTSxlQUFjLFdBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUY7QUFBQSxLQUYzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BR0E7QUFDRkMsTUFMSUQ7QUFNTixNQUFNRSxjQUFjQSxNQUNoQix1QkFBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxlQUFZLFFBQ3BFLGlDQUFDLFVBQUssR0FBRSxrQkFBaUIsUUFBTyxnQkFBZSxhQUFZLEtBQUksZUFBYyxTQUFRLGdCQUFlLFdBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBMkcsS0FEL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBO0FBQ0ZDLE1BSklEO0FBS04sTUFBTUUsZUFBZUEsTUFDakIsdUJBQUMsU0FBSSxPQUFNLE1BQUssUUFBTyxNQUFLLFNBQVEsYUFBWSxNQUFLLFFBQU8sZUFBWSxRQUNwRSxpQ0FBQyxVQUFLLEdBQUUsZ0JBQWUsUUFBTyxnQkFBZSxhQUFZLEtBQUksZUFBYyxTQUFRLGdCQUFlLFdBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBeUcsS0FEN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBO0FBQ0ZDLE1BSklEO0FBTUMsZ0JBQVNFLGVBQWU7QUFBQUMsS0FBQTtBQUMzQixRQUFNQyxjQUFjNUQsZUFBZTtBQUNuQyxRQUFNNkQsU0FBUzVELFVBQVU7QUFDekIsUUFBTTZELFFBQVFsQyxTQUFTO0FBQ3ZCLFFBQU0sRUFBRW1DLFdBQVdDLFNBQVMsSUFBSWpELGFBQWE7QUFDN0MsUUFBTSxDQUFDa0QsU0FBU0MsVUFBVSxJQUFJckUsU0FBbUQsSUFBSTtBQUNyRixRQUFNLENBQUNzRSxNQUFNQyxPQUFPLElBQUl2RSxTQUFvQm9DLFNBQVM7QUFDckQsUUFBTSxDQUFDb0MsYUFBYUMsY0FBYyxJQUFJekUsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQzBFLGtCQUFrQkMsbUJBQW1CLElBQUkzRSxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDNEUsa0JBQWtCQyxtQkFBbUIsSUFBSTdFLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUM4RSxtQkFBbUJDLG9CQUFvQixJQUFJL0UsU0FBd0IsSUFBSTtBQUM5RSxRQUFNLENBQUNnRixrQkFBa0JDLG1CQUFtQixJQUFJakYsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQ2tGLG1CQUFtQkMsb0JBQW9CLElBQUluRixTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDb0YsZ0JBQWdCQyxpQkFBaUIsSUFBSXJGLFNBQXdCLElBQUk7QUFDeEUsUUFBTSxDQUFDc0YsV0FBV0MsWUFBWSxJQUFJdkYsU0FBc0IsSUFBSTtBQUM1RCxRQUFNLENBQUN3RixPQUFPQyxRQUFRLElBQUl6RixTQUF3QixJQUFJO0FBR3RELFFBQU0sQ0FBQzBGLG9CQUFvQkMscUJBQXFCLElBQUkzRixTQUF5Q21DLGNBQWM7QUFDM0csUUFBTSxDQUFDeUQsUUFBUUMsU0FBUyxJQUFJN0YsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzhGLGNBQWNDLGVBQWUsSUFBSS9GLFNBQXVCLEtBQUs7QUFDcEUsUUFBTSxDQUFDZ0csTUFBTUMsT0FBTyxJQUFJakcsU0FBUyxDQUFDO0FBRWxDLFFBQU1rRyxrQkFBa0JuRztBQUFBQSxJQUNwQixNQUFPdUYsY0FBYyxPQUFPYSxJQUFJQyxnQkFBZ0JkLFNBQVMsSUFBSTtBQUFBLElBQzdELENBQUNBLFNBQVM7QUFBQSxFQUNkO0FBQ0F4RixZQUFVLE1BQU07QUFDWixXQUFPLE1BQU07QUFDVCxVQUFJb0csb0JBQW9CLEtBQU1DLEtBQUlFLGdCQUFnQkgsZUFBZTtBQUFBLElBQ3JFO0FBQUEsRUFDSixHQUFHLENBQUNBLGVBQWUsQ0FBQztBQUlwQixRQUFNSSxrQkFBa0JwRyxTQUFTO0FBQUEsSUFDN0JxRyxVQUFVLENBQUMsY0FBY3JDLFNBQVM7QUFBQSxJQUNsQ3NDLFNBQVNBLE1BQU03RixjQUFjdUQsYUFBYSxDQUFDO0FBQUEsRUFDL0MsQ0FBQztBQUlELFFBQU11Qyw0QkFBNEJ2RyxTQUFTO0FBQUEsSUFDdkNxRyxVQUFVLENBQUMsY0FBYyxjQUFjckMsU0FBUztBQUFBLElBQ2hEc0MsU0FBU0EsTUFBTTVGLDJCQUEyQnNELGFBQWEsQ0FBQztBQUFBLEVBQzVELENBQUM7QUFFRCxRQUFNd0MsZ0JBQWdCeEcsU0FBUztBQUFBLElBQzNCcUcsVUFBVSxDQUFDLFFBQVEsY0FBY3JDLFNBQVM7QUFBQSxJQUMxQ3NDLFNBQVNBLE1BQU0zRixxQkFBcUJxRCxhQUFhLENBQUM7QUFBQSxFQUN0RCxDQUFDO0FBS0QsUUFBTXlDLGFBQWF6RyxTQUFTO0FBQUEsSUFDeEJxRyxVQUFVLENBQUMsU0FBUyxVQUFVcEMsUUFBUTtBQUFBLElBQ3RDcUMsU0FBU0EsTUFBTXZGLGlCQUFpQmtELFlBQVksQ0FBQztBQUFBLElBQzdDeUMsU0FBU3pDLFlBQVk7QUFBQSxFQUN6QixDQUFDO0FBQ0QsUUFBTTBDLGlCQUFpQjlHLFFBQVEsTUFBTTtBQUNqQyxVQUFNK0csTUFBTSxvQkFBSUMsSUFBK0I7QUFDL0MsZUFBV0MsS0FBS0wsV0FBV00sUUFBUSxHQUFJSCxLQUFJSSxJQUFJRixFQUFFRyxXQUFXSCxDQUFDO0FBQzdELFdBQU9GO0FBQUFBLEVBQ1gsR0FBRyxDQUFDSCxXQUFXTSxJQUFJLENBQUM7QUFFcEIsUUFBTUcsbUJBQW1Cckg7QUFBQUEsSUFDckIsTUFBTSxDQUFDLEdBQUkwRywwQkFBMEJRLFFBQVEsRUFBRyxFQUFFSSxLQUFLLENBQUNDLEdBQUdDLE1BQU1ELEVBQUVFLGVBQWVELEVBQUVDLFlBQVk7QUFBQSxJQUNoRyxDQUFDZiwwQkFBMEJRLElBQUk7QUFBQSxFQUNuQztBQUVBLFFBQU1RLFVBQVVBLE1BQU07QUFDbEIsU0FBSzFELFlBQVkyRCxrQkFBa0IsRUFBRW5CLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztBQUN6RCxTQUFLeEMsWUFBWTJELGtCQUFrQixFQUFFbkIsVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQUEsRUFDbkU7QUFFQSxRQUFNb0IsYUFBYUEsQ0FBQ0MsWUFBK0M7QUFDL0RuQyxhQUFTLElBQUk7QUFDYkYsaUJBQWEsSUFBSTtBQUNqQlosd0JBQW9CLEtBQUs7QUFDekJFLHdCQUFvQixFQUFFO0FBQ3RCUixlQUFXdUQsT0FBTztBQUNsQixRQUFJQSxZQUFZLE1BQU9yRCxTQUFRLEVBQUUsR0FBR25DLFdBQVdDLFlBQVl3RixPQUFPdkIsZ0JBQWdCVyxPQUFPLENBQUMsR0FBR2EsTUFBTSxFQUFFLEVBQUUsQ0FBQztBQUFBO0FBRXBHdkQsY0FBUTtBQUFBLFFBQ0psQyxZQUFZd0YsT0FBT0QsUUFBUXZGLFVBQVU7QUFBQSxRQUNyQ0MsaUJBQWlCdUYsT0FBT0QsUUFBUXRGLGVBQWU7QUFBQSxRQUMvQ0MsTUFBTXFGLFFBQVFyRjtBQUFBQSxRQUNkQyxhQUFhb0YsUUFBUXBGLGVBQWU7QUFBQSxRQUNwQ0MsU0FBU21GLFFBQVFuRixXQUFXO0FBQUEsUUFDNUJDLFdBQVdtRixPQUFPRCxRQUFRbEYsU0FBUztBQUFBLFFBQ25DQyxXQUFXaUYsUUFBUWpGLGNBQWMsT0FBTyxLQUFLa0YsT0FBT0QsUUFBUWpGLFNBQVM7QUFBQSxRQUNyRUMsbUJBQW1CZ0YsUUFBUWhGO0FBQUFBLFFBQzNCQyx3QkFBd0IrRSxRQUFRL0UsMkJBQTJCLE9BQU8sS0FBS2dGLE9BQU9ELFFBQVEvRSxzQkFBc0I7QUFBQSxNQUNoSCxDQUFDO0FBQUEsRUFDVDtBQUVBLFFBQU1rRixlQUFlQSxPQUF1QjtBQUFBLElBQ3hDMUYsWUFBWWEsT0FBT29CLEtBQUtqQyxVQUFVO0FBQUEsSUFDbENDLGlCQUFpQlksT0FBT29CLEtBQUtoQyxlQUFlO0FBQUEsSUFDNUNDLE1BQU0rQixLQUFLL0IsS0FBS1MsS0FBSztBQUFBLElBQ3JCUixhQUFhOEIsS0FBSzlCLFlBQVlRLEtBQUssTUFBTSxLQUFLLE9BQU9zQixLQUFLOUIsWUFBWVEsS0FBSztBQUFBLElBQzNFUCxTQUFTNkIsS0FBSzdCLFFBQVFPLEtBQUssTUFBTSxLQUFLLE9BQU9zQixLQUFLN0IsUUFBUU8sS0FBSztBQUFBLElBQy9ETixXQUFXSSxTQUFTd0IsS0FBSzVCLFNBQVMsS0FBSztBQUFBLElBQ3ZDQyxXQUFXRyxTQUFTd0IsS0FBSzNCLFNBQVM7QUFBQSxJQUNsQ0MsbUJBQW1CMEIsS0FBSzFCO0FBQUFBLElBQ3hCQyx3QkFBd0J5QixLQUFLekIsdUJBQXVCRyxLQUFLLE1BQU0sS0FBSyxPQUFPRSxPQUFPb0IsS0FBS3pCLHNCQUFzQjtBQUFBLEVBQ2pIO0FBRUEsUUFBTW1GLGFBQWFBLENBQUNDLE1BQ2hCeEMsU0FBU3dDLGFBQWE5RyxXQUFXOEcsRUFBRUMsVUFBVSxrQkFBa0I7QUFFbkUsUUFBTUMsZUFBZWxJLFlBQVk7QUFBQSxJQUM3Qm1JLFlBQVksWUFBWTtBQUNwQixZQUFNakIsWUFDRi9DLFlBQVksUUFDTixNQUFNNUQsY0FBYzBELGFBQWEsR0FBRzZELGFBQWEsQ0FBQyxJQUNqRDNELFFBQXNDMEQ7QUFDakQsVUFBSTFELFlBQVksTUFBTyxPQUFNckQsY0FBY29HLFdBQVdZLGFBQWEsQ0FBQztBQUNwRSxVQUFJekMsY0FBYyxLQUFNLE9BQU10RSxtQkFBbUJtRyxXQUFXN0IsU0FBUztBQUFBLElBQ3pFO0FBQUEsSUFDQStDLFdBQVdBLE1BQU07QUFDYnBFLFlBQU1xRSxRQUFRbEUsWUFBWSxRQUFRLG9CQUFvQixxQkFBcUI7QUFDM0VDLGlCQUFXLElBQUk7QUFDZm9ELGNBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQWMsU0FBU1A7QUFBQUEsRUFDYixDQUFDO0FBSUQsUUFBTVEsd0JBQXdCdkksWUFBWTtBQUFBLElBQ3RDbUksWUFBWUEsQ0FBQyxFQUFFTixJQUFJVyxTQUE0QyxNQUMzREEsV0FBV25JLGdCQUFnQndILEVBQUUsSUFBSXBILGtCQUFrQm9ILEVBQUU7QUFBQSxJQUN6RE8sV0FBV0EsQ0FBQ0ssT0FBT0MsU0FBUztBQUN4QjFFLFlBQU1xRSxRQUFRSyxLQUFLRixXQUFXLHFCQUFxQixxQkFBcUI7QUFDeEVoQixjQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0FjLFNBQVNQO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1ZLGdCQUFnQixPQUFPaEIsWUFBdUM7QUFDaEUsUUFBSUEsUUFBUWlCLFVBQVU7QUFDbEIsWUFBTUMsWUFBWSxNQUFNOUUsT0FBTytFLFFBQVE7QUFBQSxRQUNuQ0MsT0FBTztBQUFBLFFBQ1BkLFNBQVMsY0FBY04sUUFBUXJGLElBQUk7QUFBQSxRQUNuQzBHLGNBQWM7QUFBQSxRQUNkQyxRQUFRO0FBQUEsTUFDWixDQUFDO0FBQ0QsVUFBSSxDQUFDSixVQUFXO0FBQUEsSUFDcEI7QUFDQU4sMEJBQXNCVyxPQUFPLEVBQUVyQixJQUFJRixRQUFRRSxJQUFJVyxVQUFVLENBQUNiLFFBQVFpQixTQUFTLENBQUM7QUFBQSxFQUNoRjtBQUVBLFFBQU1PLG1CQUFtQm5KLFlBQVk7QUFBQSxJQUNqQ21JLFlBQVlBLE1BQ1I3SCxlQUFlMkQsYUFBYSxHQUFHTSxZQUFZeEIsS0FBSyxJQUFJeUQsMEJBQTBCUSxNQUFNb0MsVUFBVSxLQUFLLENBQUM7QUFBQSxJQUN4R2hCLFdBQVdBLE1BQU07QUFDYjVELHFCQUFlLEVBQUU7QUFDakJnRCxjQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0FjLFNBQVNQO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1zQix3QkFBd0JySixZQUFZO0FBQUEsSUFDdENtSSxZQUFZQSxNQUNSN0gsZUFBZTJELGFBQWEsR0FBR1UsaUJBQWlCNUIsS0FBSyxJQUFJeUQsMEJBQTBCUSxNQUFNb0MsVUFBVSxLQUFLLENBQUM7QUFBQSxJQUM3R2hCLFdBQVdBLENBQUNrQixrQkFBa0I7QUFDMUJ0RixZQUFNcUUsUUFBUSxtQkFBbUI7QUFDakMvRCxjQUFRLENBQUNpRixPQUFPLEVBQUUsR0FBR0EsR0FBR25ILFlBQVl3RixPQUFPMEIsYUFBYSxFQUFFLEVBQUU7QUFDNUQxRSwwQkFBb0IsRUFBRTtBQUN0QkYsMEJBQW9CLEtBQUs7QUFDekJjLGVBQVMsSUFBSTtBQUNiZ0MsY0FBUTtBQUFBLElBQ1o7QUFBQSxJQUNBYyxTQUFTUDtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNeUIsb0JBQW9CQSxDQUFDQyxhQUF5QztBQUNoRTNFLHlCQUFxQjJFLFNBQVM1QixFQUFFO0FBQ2hDN0Msd0JBQW9CeUUsU0FBU25ILElBQUk7QUFDakM0Qyx5QkFBcUIwQyxPQUFPNkIsU0FBU2xDLFlBQVksQ0FBQztBQUFBLEVBQ3REO0FBRUEsUUFBTW1DLHFCQUFxQkEsTUFBTTtBQUM3QjVFLHlCQUFxQixJQUFJO0FBQ3pCRSx3QkFBb0IsRUFBRTtBQUN0QkUseUJBQXFCLEVBQUU7QUFBQSxFQUMzQjtBQUVBLFFBQU15RSx5QkFBeUIzSixZQUFZO0FBQUEsSUFDdkNtSSxZQUFZQSxNQUNSdEgsZUFBZWdFLG1CQUFvQkUsaUJBQWlCaEMsS0FBSyxHQUFHRSxPQUFPZ0MsaUJBQWlCLEtBQUssQ0FBQztBQUFBLElBQzlGbUQsV0FBV0EsTUFBTTtBQUNicEUsWUFBTXFFLFFBQVEsdUJBQXVCO0FBQ3JDcUIseUJBQW1CO0FBQ25CbEMsY0FBUTtBQUFBLElBQ1o7QUFBQSxJQUNBYyxTQUFTUDtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNNkIseUJBQXlCNUosWUFBWTtBQUFBLElBQ3ZDbUksWUFBWUEsQ0FBQyxFQUFFTixJQUFJVyxTQUE0QyxNQUMzREEsV0FBV3BJLGlCQUFpQnlILEVBQUUsSUFBSXJILG1CQUFtQnFILEVBQUU7QUFBQSxJQUMzRE8sV0FBV0EsQ0FBQ0ssT0FBT0MsU0FBUztBQUN4QjFFLFlBQU1xRSxRQUFRSyxLQUFLRixXQUFXLHVCQUF1Qix1QkFBdUI7QUFDNUVoQixjQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0FjLFNBQVNQO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU04QixpQkFBaUIsT0FBT0osYUFBeUM7QUFDbkUsUUFBSUEsU0FBU2IsVUFBVTtBQUNuQixZQUFNQyxZQUFZLE1BQU05RSxPQUFPK0UsUUFBUTtBQUFBLFFBQ25DQyxPQUFPO0FBQUEsUUFDUGQsU0FBUyxjQUFjd0IsU0FBU25ILElBQUk7QUFBQSxRQUNwQzBHLGNBQWM7QUFBQSxRQUNkQyxRQUFRO0FBQUEsTUFDWixDQUFDO0FBQ0QsVUFBSSxDQUFDSixVQUFXO0FBQUEsSUFDcEI7QUFDQWUsMkJBQXVCVixPQUFPLEVBQUVyQixJQUFJNEIsU0FBUzVCLElBQUlXLFVBQVUsQ0FBQ2lCLFNBQVNiLFNBQVMsQ0FBQztBQUFBLEVBQ25GO0FBSUEsUUFBTWtCLGtCQUFrQjlKLFlBQVk7QUFBQSxJQUNoQ21JLFlBQVksT0FBTyxFQUFFNEIsTUFBTUMsR0FBeUUsTUFBTTtBQUN0RyxZQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDZHJKLGVBQWVrSixLQUFLbEMsSUFBSWtDLEtBQUt6SCxNQUFNMEgsR0FBR3pDLFlBQVk7QUFBQSxVQUNsRDFHLGVBQWVtSixHQUFHbkMsSUFBSW1DLEdBQUcxSCxNQUFNeUgsS0FBS3hDLFlBQVk7QUFBQSxRQUFDO0FBQUEsTUFDcEQ7QUFBQSxJQUNMO0FBQUEsSUFDQWEsV0FBV0EsTUFBTVosUUFBUTtBQUFBLElBQ3pCYyxTQUFTUDtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNb0MscUJBQXFCQSxDQUFDQyxXQUF1QztBQUMvRCxVQUFNQyxTQUFTbEQsaUJBQWlCbUQsS0FBSyxDQUFDQyxNQUFNQSxFQUFFMUMsT0FBTzFDLGNBQWM7QUFDbkVDLHNCQUFrQixJQUFJO0FBQ3RCLFFBQUksQ0FBQ2lGLFVBQVVBLE9BQU94QyxPQUFPdUMsT0FBT3ZDLEdBQUk7QUFDeENpQyxvQkFBZ0JaLE9BQU8sRUFBRWEsTUFBTU0sUUFBUUwsSUFBSUksT0FBTyxDQUFDO0FBQUEsRUFDdkQ7QUFFQSxRQUFNSSxpQkFBaUJBLENBQUMzQyxPQUF1QztBQUMzRG5DLDBCQUFzQm1DLEVBQUU7QUFDeEI3QixZQUFRLENBQUM7QUFBQSxFQUNiO0FBRUEsUUFBTXlFLG1CQUFtQjNLLFFBQVEsTUFBTTtBQUNuQyxRQUFJNEssT0FBT2pFLGNBQWNPLFFBQVE7QUFDakMsUUFBSXZCLHVCQUF1QnZELGVBQWdCd0ksUUFBT0EsS0FBS0MsT0FBTyxDQUFDQyxNQUFNQSxFQUFFeEksZUFBZXFELGtCQUFrQjtBQUN4RyxRQUFJSSxpQkFBaUIsU0FBVTZFLFFBQU9BLEtBQUtDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWhDLFFBQVE7QUFDbkUsUUFBSS9DLGlCQUFpQixXQUFZNkUsUUFBT0EsS0FBS0MsT0FBTyxDQUFDQyxNQUFNLENBQUNBLEVBQUVoQyxRQUFRO0FBQ3RFLFFBQUlqRCxPQUFPNUMsS0FBSyxNQUFNLElBQUk7QUFDdEIsWUFBTThILElBQUlsRixPQUFPNUMsS0FBSyxFQUFFK0gsWUFBWTtBQUNwQ0osYUFBT0EsS0FBS0MsT0FBTyxDQUFDQyxNQUFNQSxFQUFFdEksS0FBS3dJLFlBQVksRUFBRUMsU0FBU0YsQ0FBQyxDQUFDO0FBQUEsSUFDOUQ7QUFDQSxXQUFPSDtBQUFBQSxFQUNYLEdBQUcsQ0FBQ2pFLGNBQWNPLE1BQU12QixvQkFBb0JJLGNBQWNGLE1BQU0sQ0FBQztBQUVqRSxRQUFNcUYsYUFBYUMsS0FBS0MsSUFBSSxHQUFHRCxLQUFLRSxLQUFLVixpQkFBaUJyQixTQUFTbkgsU0FBUyxDQUFDO0FBQzdFLFFBQU1tSixjQUFjSCxLQUFLSSxJQUFJdEYsTUFBTWlGLFVBQVU7QUFDN0MsUUFBTU0sYUFBYUYsY0FBYyxLQUFLbko7QUFDdEMsUUFBTXNKLFlBQVlkLGlCQUFpQmUsTUFBTUYsV0FBV0EsWUFBWXJKLFNBQVM7QUFFekUsUUFBTXdKLGFBQWFBLENBQUM5RCxZQUF1QztBQUN2RCxRQUFJLENBQUNBLFFBQVFoRixrQkFBbUIsUUFBTyx1QkFBQyxlQUFZLE9BQU0sb0JBQW1CLDRCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtEO0FBQ3pGLFVBQU0rSSxRQUFROUUsZUFBZStFLElBQUloRSxRQUFRRSxFQUFFO0FBQzNDLFFBQUksQ0FBQzZELE1BQU8sUUFBTyx1QkFBQyxlQUFZLE9BQU0sb0JBQW1CLDRCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtEO0FBQ3JFLFFBQUlBLE1BQU1FLG1CQUFtQixFQUFHLFFBQU8sdUJBQUMsZUFBWSxPQUFNLGlCQUFnQiwyQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QztBQUNyRixRQUFJRixNQUFNRyxlQUFnQixRQUFPLHVCQUFDLGVBQVksT0FBTSxnQkFBZTtBQUFBO0FBQUEsTUFBU0gsTUFBTUU7QUFBQUEsU0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRTtBQUNsRyxXQUFPLHVCQUFDLGVBQVksT0FBTSxhQUFZO0FBQUE7QUFBQSxNQUFjRixNQUFNRTtBQUFBQSxTQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1FO0FBQUEsRUFDOUU7QUFFQSxTQUNJLHVCQUFDLFVBQUssT0FBTyxFQUFFRSxTQUFTLElBQUlDLFVBQVUsTUFBTUMsUUFBUSxVQUFVQyxVQUFVLFdBQVcsR0FDL0U7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVDLFNBQVMsUUFBUUMsWUFBWSxZQUFZQyxLQUFLLElBQUlDLGNBQWMsR0FBRyxHQUM5RjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxTQUFTLEdBQUcsd0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Q7QUFBQSxNQUMvRCx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsTUFBTSxFQUFFLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGVBQWMsU0FBUyxNQUFNN0UsV0FBVyxLQUFLLEdBQUcsOEJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEY7QUFBQSxTQUhsRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUVDbEIsMEJBQTBCZ0csV0FBVyx1QkFBQyxjQUFXLE9BQU9oRywwQkFBMEJqQixPQUFPLE1BQUssbUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0U7QUFBQSxJQUM3R2tCLGNBQWMrRixXQUFXLHVCQUFDLGNBQVcsT0FBTy9GLGNBQWNsQixPQUFPLE1BQUssZ0JBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQ7QUFBQSxJQUNsRkEsU0FBUyxDQUFDcEIsV0FDUCx1QkFBQyxPQUFFLFdBQVUsY0FBYSxNQUFLLFNBQzFCb0IsbUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFHSix1QkFBQyxTQUFJLFdBQVUsNkJBRVg7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0JBQ1g7QUFBQSxpQ0FBQyxRQUFHLE9BQU8sRUFBRStHLFVBQVUsV0FBV0csT0FBTyxpQkFBaUIsR0FBRywwQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUU7QUFBQSxVQUN2RSx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCdEYsMkJBQWlCaUMsVUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxhQUY3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFXLDBCQUEwQjNELHVCQUF1QnZELGlCQUFpQixnQkFBZ0IsRUFBRTtBQUFBLGNBQy9GLFNBQVMsTUFBTXNJLGVBQWV0SSxjQUFjO0FBQUEsY0FFNUM7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsd0JBQXVCLE9BQU8sRUFBRXdLLFlBQVksU0FBUyxHQUFHLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBUyxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRjtBQUFBLGdCQUNwRix1QkFBQyxVQUFLLFdBQVUsaUJBQ1o7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsaUJBQWdCLGlDQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRDtBQUFBLGtCQUNqRCx1QkFBQyxVQUFLLFdBQVUsdUJBQXVCakcsd0JBQWNPLE1BQU1vQyxVQUFVLEtBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVFO0FBQUEscUJBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQTtBQUFBO0FBQUEsWUFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLFVBRUNqQyxpQkFBaUJOO0FBQUFBLFlBQUksQ0FBQzRDLFVBQVVrRCxVQUM3QjlILHNCQUFzQjRFLFNBQVM1QixLQUMzQix1QkFBQyxTQUFzQixPQUFPLEVBQUVxRSxTQUFTLFFBQVFFLEtBQUssR0FBR0QsWUFBWSxVQUFVTCxTQUFTLFVBQVUsR0FDOUY7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRztBQUFBLGtCQUNBLE9BQU8vRztBQUFBQSxrQkFDUCxVQUFVLENBQUNpRCxNQUFNaEQsb0JBQW9CZ0QsRUFBRW9DLE9BQU9wSCxLQUFLO0FBQUEsa0JBQ25ELE9BQU8sRUFBRXVKLE1BQU0sR0FBR0ssVUFBVSxHQUFHQyxXQUFXLEdBQUc7QUFBQTtBQUFBLGdCQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJbUQ7QUFBQSxjQUVuRDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLE9BQU81SDtBQUFBQSxrQkFDUCxVQUFVLENBQUMrQyxNQUFNOUMscUJBQXFCOEMsRUFBRW9DLE9BQU9wSCxLQUFLO0FBQUEsa0JBQ3BELE9BQU07QUFBQSxrQkFDTixPQUFPLEVBQUU4SixPQUFPLElBQUlELFdBQVcsR0FBRztBQUFBO0FBQUEsZ0JBTnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU13QztBQUFBLGNBRXhDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxTQUFTbEQsdUJBQXVCb0Q7QUFBQUEsa0JBQ2hDLFVBQVVoSSxpQkFBaUJoQyxLQUFLLE1BQU07QUFBQSxrQkFDdEMsU0FBUyxNQUFNNEcsdUJBQXVCVCxPQUFPO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUpuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGNBQ0EsdUJBQUMsVUFBTyxNQUFLLE1BQUssVUFBUSxNQUFDLGNBQVcsbUJBQWtCLFNBQVNRLG9CQUFvQixpQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXpCTUQsU0FBUzVCLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBLElBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFRyxXQUFXLGdCQUFnQnBDLHVCQUF1QmdFLFNBQVM1QixLQUFLLGdCQUFnQixFQUFFLElBQUksQ0FBQzRCLFNBQVNiLFdBQVcsZ0JBQWdCLEVBQUUsSUFBSXpELG1CQUFtQnNFLFNBQVM1QixLQUFLLGdCQUFnQixFQUFFO0FBQUEsZ0JBQ3BMO0FBQUEsZ0JBQ0EsU0FBUyxNQUFNMkMsZUFBZWYsU0FBUzVCLEVBQUU7QUFBQSxnQkFDekMsYUFBYSxNQUFNekMsa0JBQWtCcUUsU0FBUzVCLEVBQUU7QUFBQSxnQkFDaEQsV0FBVyxNQUFNekMsa0JBQWtCLElBQUk7QUFBQSxnQkFDdkMsWUFBWSxDQUFDNEMsTUFBTUEsRUFBRWdGLGVBQWU7QUFBQSxnQkFDcEMsUUFBUSxDQUFDaEYsTUFBTTtBQUFFQSxvQkFBRWdGLGVBQWU7QUFBRzdDLHFDQUFtQlYsUUFBUTtBQUFBLGdCQUFHO0FBQUEsZ0JBRW5FO0FBQUEseUNBQUMsVUFBSyxXQUFVLHdCQUF1QixPQUFNLDBCQUF5QixTQUFTLENBQUN6QixNQUFNQSxFQUFFaUYsZ0JBQWdCLEdBQ3BHLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBUyxLQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUsa0JBQWtCckYsaUJBQU8rRSxRQUFRLENBQUMsRUFBRU8sU0FBUyxHQUFHLEdBQUcsS0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUU7QUFBQSxrQkFDckUsdUJBQUMsVUFBSyxXQUFVLGlCQUNaO0FBQUEsMkNBQUMsVUFBSyxXQUFVLGlCQUFpQnpELG1CQUFTbkgsUUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSxvQkFDL0MsdUJBQUMsVUFBSyxXQUFVLHVCQUF1Qm1ILG1CQUFTMEQsZ0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZEO0FBQUEsb0JBQzVELENBQUMxRCxTQUFTYixZQUFZLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsdUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStDO0FBQUEsdUJBSDFFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxTQUFTYSxTQUFTYjtBQUFBQSxzQkFDbEIsVUFBVSxNQUFNaUIsZUFBZUosUUFBUTtBQUFBLHNCQUN2QyxPQUFPQSxTQUFTYixXQUFXLHVCQUF1QmEsU0FBU25ILElBQUksS0FBSyxvQkFBb0JtSCxTQUFTbkgsSUFBSTtBQUFBO0FBQUEsb0JBSHpHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFHNEc7QUFBQSxrQkFFNUc7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csTUFBSztBQUFBLHNCQUNMO0FBQUEsc0JBQ0EsY0FBWSxvQkFBb0JtSCxTQUFTbkgsSUFBSTtBQUFBLHNCQUM3QyxTQUFTLENBQUMwRixNQUFNO0FBQUVBLDBCQUFFaUYsZ0JBQWdCO0FBQUd6RCwwQ0FBa0JDLFFBQVE7QUFBQSxzQkFBRztBQUFBLHNCQUFFO0FBQUE7QUFBQSxvQkFKMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9BO0FBQUE7QUFBQTtBQUFBLGNBOUJLQSxTQUFTNUI7QUFBQUEsY0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdDQTtBQUFBLFVBRVI7QUFBQSxhQTVFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ1g7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csYUFBWTtBQUFBLGNBQ1osT0FBT3REO0FBQUFBLGNBQ1AsVUFBVSxDQUFDeUQsTUFBTXhELGVBQWV3RCxFQUFFb0MsT0FBT3BILEtBQUs7QUFBQSxjQUM5QyxXQUFXLENBQUNnRixNQUFNO0FBQ2Qsb0JBQUlBLEVBQUVvRixRQUFRLFdBQVc3SSxZQUFZeEIsS0FBSyxNQUFNLEdBQUlvRyxrQkFBaUJELE9BQU87QUFBQSxjQUNoRjtBQUFBO0FBQUEsWUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNTTtBQUFBLFVBRU47QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxjQUFXO0FBQUEsY0FDWCxVQUFVM0UsWUFBWXhCLEtBQUssTUFBTSxNQUFNb0csaUJBQWlCNEQ7QUFBQUEsY0FDeEQsU0FBUzVELGlCQUFpQjREO0FBQUFBLGNBQzFCLFNBQVMsTUFBTTVELGlCQUFpQkQsT0FBTztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBTjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsYUFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBRUEsdUJBQUMsT0FBRSxXQUFVLGdCQUFlLDBHQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQTVHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkdBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUJBQ1g7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsa0JBQ1g7QUFBQSxtQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFXO0FBQUEsWUFDWDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLGFBQVk7QUFBQSxnQkFDWixPQUFPdkQ7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDcUMsTUFBTTtBQUFFcEMsNEJBQVVvQyxFQUFFb0MsT0FBT3BILEtBQUs7QUFBR2dELDBCQUFRLENBQUM7QUFBQSxnQkFBRztBQUFBO0FBQUEsY0FIOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR2dFO0FBQUEsZUFMcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQVksTUFBSyxTQUFRLGNBQVcsc0JBQzdDLFdBQUMsT0FBTyxVQUFVLFVBQVUsRUFBcUJhO0FBQUFBLFlBQUksQ0FBQ0UsTUFDcEQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFRyxNQUFLO0FBQUEsZ0JBQ0wsV0FBV2xCLGlCQUFpQmtCLElBQUksY0FBYztBQUFBLGdCQUM5QyxTQUFTLE1BQU07QUFBRWpCLGtDQUFnQmlCLENBQUM7QUFBR2YsMEJBQVEsQ0FBQztBQUFBLGdCQUFHO0FBQUEsZ0JBRWhEZSxnQkFBTSxRQUFRLFVBQVVBLE1BQU0sV0FBVyxXQUFXO0FBQUE7QUFBQSxjQUxoREE7QUFBQUEsY0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxVQUNILEtBVkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxRQUVDTixjQUFjNEcsYUFBYSx1QkFBQyxTQUFJLE9BQU8sRUFBRXZCLFNBQVMsR0FBRyxHQUFHLGlDQUFDLGdCQUFhLE1BQU0sR0FBRyxXQUFXLE1BQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUMsS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFFBRWhHLENBQUNyRixjQUFjNEcsYUFBYTVDLGlCQUFpQnJCLFdBQVcsS0FDckQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLE9BQU07QUFBQSxZQUNOLGFBQ0l6RCxPQUFPNUMsS0FBSyxNQUFNLEtBQ1osMEJBQTBCNEMsT0FBTzVDLEtBQUssQ0FBQyw4Q0FDdEMwRCxjQUFjTyxNQUFNb0MsVUFBVSxPQUFPLElBQ2xDLHdFQUNBO0FBQUEsWUFFZCxRQUNJLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsZUFBYyxTQUFTLE1BQU0xQixXQUFXLEtBQUssR0FBRyw4QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBO0FBQUEsVUFiUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFjSztBQUFBLFFBSVIsQ0FBQ2pCLGNBQWM0RyxhQUFhNUMsaUJBQWlCckIsU0FBUyxLQUNuRCxtQ0FDSTtBQUFBLGlDQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRWtFLFFBQVEsUUFBUUMsY0FBYyxFQUFFLEdBQzVEaEMsb0JBQVUxRTtBQUFBQSxZQUFJLENBQUNjLFlBQ1osdUJBQUMsU0FBSSxXQUFXLDBCQUEwQixDQUFDQSxRQUFRaUIsV0FBVyxnQkFBZ0IsRUFBRSxJQUM1RSxpQ0FBQyxTQUFJLFdBQVUsb0JBQW1CLE9BQU8sRUFBRTJELE1BQU0sRUFBRSxHQUMvQztBQUFBLHFDQUFDLFNBQUksT0FBTyxFQUFFTCxTQUFTLFFBQVFFLEtBQUssSUFBSUQsWUFBWSxVQUFVUyxVQUFVLEVBQUUsR0FDckVqRjtBQUFBQSx3QkFBUTZGLFdBQ0w7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csS0FBSzdGLFFBQVE2RjtBQUFBQSxvQkFDYixLQUFLN0YsUUFBUXJGO0FBQUFBLG9CQUNiLE9BQU87QUFBQSxvQkFDUCxRQUFRO0FBQUEsb0JBQ1IsU0FBUTtBQUFBLG9CQUNSLE9BQU8sRUFBRXdLLE9BQU8sSUFBSVcsUUFBUSxJQUFJQyxXQUFXLFNBQVNILGNBQWMsR0FBR0QsUUFBUSx5QkFBeUJLLFlBQVksRUFBRTtBQUFBO0FBQUEsa0JBTnhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNMEgsSUFHMUgsdUJBQUMsU0FBSSxPQUFPLEVBQUViLE9BQU8sSUFBSVcsUUFBUSxJQUFJRixjQUFjLEdBQUdLLFlBQVksbUJBQW1CMUIsU0FBUyxRQUFRMkIsWUFBWSxVQUFVcEIsT0FBTyxvQkFBb0JILFVBQVUsVUFBVXFCLFlBQVksRUFBRSxHQUFHLGtCQUE1TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUosdUJBQUMsU0FBSSxPQUFPLEVBQUV6QixTQUFTLFFBQVFFLEtBQUssR0FBR1EsVUFBVSxFQUFFLEdBQy9DO0FBQUEseUNBQUMsVUFBSyxPQUFPLEVBQUVWLFNBQVMsUUFBUUMsWUFBWSxVQUFVQyxLQUFLLEdBQUcwQixZQUFZLFVBQVVDLFVBQVUsVUFBVUMsY0FBYyxXQUFXLEdBQzVIckc7QUFBQUEsNEJBQVFyRjtBQUFBQSxvQkFDUixDQUFDcUYsUUFBUWlCLFlBQVksdUJBQUMsVUFBSyxXQUFVLHlCQUF3Qix1QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSx1QkFGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFMEQsVUFBVSxVQUFVRyxPQUFPLG9CQUFvQnFCLFlBQVksVUFBVUMsVUFBVSxVQUFVQyxjQUFjLFdBQVcsR0FDNUhyRztBQUFBQSw0QkFBUXNHO0FBQUFBLG9CQUNSdEcsUUFBUXBGLGNBQWMsTUFBTW9GLFFBQVFwRixXQUFXLEtBQUs7QUFBQSx1QkFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF5QkE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSxZQUFXLE9BQU8sRUFBRWtLLE9BQU8sZ0JBQWdCeUIsV0FBVyxRQUFRLEdBQ3pFL00sb0JBQVV3RyxRQUFRbEYsU0FBUyxLQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsc0JBQXNCZ0oscUJBQVc5RCxPQUFPLEtBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBEO0FBQUEsY0FDMUQsdUJBQUMsU0FBSSxPQUFPLEVBQUV1RSxTQUFTLFFBQVFFLEtBQUssR0FBR0QsWUFBWSxVQUFVZ0MsZ0JBQWdCLFdBQVcsR0FDcEY7QUFBQSx1Q0FBQyxVQUFPLE1BQUssTUFBSyxVQUFRLE1BQUMsY0FBWSxVQUFVeEcsUUFBUXJGLElBQUksSUFBSSxTQUFTLE1BQU1vRixXQUFXQyxPQUFPLEdBQUcsaUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxTQUFTQSxRQUFRaUI7QUFBQUEsb0JBQ2pCLFVBQVUsTUFBTUQsY0FBY2hCLE9BQU87QUFBQSxvQkFDckMsT0FBT0EsUUFBUWlCLFdBQVcsYUFBYWpCLFFBQVFyRixJQUFJLEtBQUssVUFBVXFGLFFBQVFyRixJQUFJO0FBQUE7QUFBQSxrQkFIbEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUdxRjtBQUFBLG1CQVB6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBeENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUNBLEtBMUNxRnFGLFFBQVFFLElBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkNBO0FBQUEsVUFDSCxLQTlDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStDQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNYO0FBQUEsbUNBQUMsVUFBSztBQUFBO0FBQUEsY0FDU3lELFlBQVk7QUFBQSxjQUFFO0FBQUEsY0FBRUwsS0FBS0ksSUFBSUMsWUFBWXJKLFdBQVd3SSxpQkFBaUJyQixNQUFNO0FBQUEsY0FBRTtBQUFBLGNBQUtxQixpQkFBaUJyQjtBQUFBQSxjQUFPO0FBQUEsaUJBRHJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNYO0FBQUEscUNBQUMsWUFBTyxNQUFLLFVBQVMsVUFBVWdDLGVBQWUsR0FBRyxTQUFTLE1BQU1wRixRQUFRb0YsY0FBYyxDQUFDLEdBQUcsY0FBVyxtQkFDbEcsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBWSxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQ2dELE1BQU1yRSxLQUFLLEVBQUVYLFFBQVE0QixXQUFXLEdBQUcsQ0FBQ3FELEdBQUdDLE1BQU1BLElBQUksQ0FBQyxFQUFFekg7QUFBQUEsZ0JBQUksQ0FBQzBILE1BQ3REO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVHLE1BQUs7QUFBQSxvQkFDTCxXQUFXQSxNQUFNbkQsY0FBYyxlQUFlO0FBQUEsb0JBQzlDLFNBQVMsTUFBTXBGLFFBQVF1SSxDQUFDO0FBQUEsb0JBRXZCQTtBQUFBQTtBQUFBQSxrQkFMSUE7QUFBQUEsa0JBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLGNBQ0g7QUFBQSxjQUNELHVCQUFDLFlBQU8sTUFBSyxVQUFTLFVBQVVuRCxlQUFlSixZQUFZLFNBQVMsTUFBTWhGLFFBQVFvRixjQUFjLENBQUMsR0FBRyxjQUFXLGtCQUMzRyxpQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxlQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLGFBeEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5RUE7QUFBQSxXQXZIUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUhBO0FBQUEsU0EzT0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRPQTtBQUFBLElBRUNqSCxZQUFZLFFBQ1Q7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE9BQU9BLFlBQVksUUFBUSxpQkFBaUI7QUFBQSxRQUM1QyxTQUFTLE1BQU1DLFdBQVcsSUFBSTtBQUFBLFFBQzlCLFNBQVE7QUFBQSxRQUNSLE1BQUk7QUFBQSxRQUVKO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLE9BQU9DLEtBQUsvQjtBQUFBQSxjQUNaLFVBQVUsQ0FBQzBGLE1BQU0xRCxRQUFRLEVBQUUsR0FBR0QsTUFBTS9CLE1BQU0wRixFQUFFb0MsT0FBT3BILE1BQU0sQ0FBQztBQUFBLGNBQzFELFdBQVM7QUFBQTtBQUFBLFlBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS2E7QUFBQSxVQU9iLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFbUosWUFBWSxNQUFNLEdBQzNEO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUVJLE1BQU0sR0FBR0ssVUFBVSxJQUFJLEdBQ2pDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csT0FDSSx1QkFBQyxVQUFLLFdBQVUsVUFBUyxPQUFPLEVBQUV1QixnQkFBZ0IsaUJBQWlCckIsT0FBTyxPQUFPLEdBQUc7QUFBQTtBQUFBLGtCQUUvRSxDQUFDckksb0JBQ0U7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTUMsb0JBQW9CLElBQUk7QUFBQSxzQkFDdkMsT0FBTyxFQUFFa0osWUFBWSxlQUFlTixRQUFRLFFBQVFiLE9BQU8sZ0JBQWdCK0IsUUFBUSxXQUFXbEMsVUFBVSxVQUFVUixTQUFTLEVBQUU7QUFBQSxzQkFBRTtBQUFBO0FBQUEsb0JBSG5JO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLHFCQVRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFHSCxXQUFDMkMsU0FDRWhLLG1CQUNJLHVCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRTJILEtBQUssRUFBRSxHQUNwQztBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLEdBQUlxQztBQUFBQSxzQkFDSixNQUFLO0FBQUEsc0JBQ0w7QUFBQSxzQkFDQSxhQUFZO0FBQUEsc0JBQ1osT0FBTzlKO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ3FELE1BQU1wRCxvQkFBb0JvRCxFQUFFb0MsT0FBT3BILEtBQUs7QUFBQSxzQkFDbkQsV0FBVyxDQUFDZ0YsTUFBTTtBQUNkLDRCQUFJQSxFQUFFb0YsUUFBUSxTQUFTO0FBQ25CcEYsNEJBQUVnRixlQUFlO0FBQ2pCLDhCQUFJckksaUJBQWlCNUIsS0FBSyxNQUFNLEdBQUlzRyx1QkFBc0JILE9BQU87QUFBQSx3QkFDckUsV0FBV2xCLEVBQUVvRixRQUFRLFVBQVU7QUFDM0IxSSw4Q0FBb0IsS0FBSztBQUN6QkUsOENBQW9CLEVBQUU7QUFBQSx3QkFDMUI7QUFBQSxzQkFDSjtBQUFBLHNCQUNBLE9BQU8sRUFBRTJILE1BQU0sR0FBR0ssVUFBVSxFQUFFO0FBQUE7QUFBQSxvQkFoQmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFnQm9DO0FBQUEsa0JBRXBDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLE1BQUs7QUFBQSxzQkFDTCxTQUFTdkQsc0JBQXNCMEQ7QUFBQUEsc0JBQy9CLFVBQVVwSSxpQkFBaUI1QixLQUFLLE1BQU07QUFBQSxzQkFDdEMsU0FBUyxNQUFNc0csc0JBQXNCSCxPQUFPO0FBQUEsc0JBQUU7QUFBQTtBQUFBLG9CQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxNQUFLO0FBQUEsc0JBQ0w7QUFBQSxzQkFDQSxjQUFXO0FBQUEsc0JBQ1gsU0FBUyxNQUFNO0FBQUV4RSw0Q0FBb0IsS0FBSztBQUFHRSw0Q0FBb0IsRUFBRTtBQUFBLHNCQUFHO0FBQUEsc0JBQUU7QUFBQTtBQUFBLG9CQUo1RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT0E7QUFBQSxxQkFsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQ0EsSUFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxHQUFJNko7QUFBQUEsb0JBQ0osT0FBT3BLLEtBQUtqQztBQUFBQSxvQkFDWixVQUFVLENBQUM0RixNQUFNMUQsUUFBUSxFQUFFLEdBQUdELE1BQU1qQyxZQUFZNEYsRUFBRW9DLE9BQU9wSCxNQUFNLENBQUM7QUFBQSxvQkFFaEU7QUFBQSw2Q0FBQyxZQUFPLE9BQU0sSUFBRyxzQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUM7QUFBQSx1QkFDckNxRCxnQkFBZ0JXLFFBQVEsSUFBSUg7QUFBQUEsd0JBQUksQ0FBQzBELE1BQy9CLHVCQUFDLFlBQWtCLE9BQU9BLEVBQUUxQyxJQUFLMEMsWUFBRWpJLFFBQXRCaUksRUFBRTFDLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBd0M7QUFBQSxzQkFDM0M7QUFBQTtBQUFBO0FBQUEsa0JBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUE7QUFBQSxjQWhFWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtRUEsS0FwRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFMEUsTUFBTSxHQUFHSyxVQUFVLElBQUksR0FDakM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxPQUFNO0FBQUEsZ0JBQ04sT0FBT3ZJLEtBQUtoQztBQUFBQSxnQkFDWixVQUFVLENBQUMyRixNQUFNMUQsUUFBUSxFQUFFLEdBQUdELE1BQU1oQyxpQkFBaUIyRixFQUFFb0MsT0FBT3BILE1BQU0sQ0FBQztBQUFBLGdCQUVwRTBMLGlCQUFPQyxRQUFRdk4sa0JBQWtCLEVBQUV5RjtBQUFBQSxrQkFBSSxDQUFDLENBQUNnQixJQUFJK0csS0FBSyxNQUMvQyx1QkFBQyxZQUFnQixPQUFPL0csSUFBSytHLG1CQUFoQi9HLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUM7QUFBQSxnQkFDdEM7QUFBQTtBQUFBLGNBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUEsS0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUFqRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrRkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFMEUsTUFBTSxHQUFHSyxVQUFVLElBQUksR0FDakM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxPQUFNO0FBQUEsZ0JBQ04sV0FBVTtBQUFBLGdCQUNWLE9BQU92SSxLQUFLNUI7QUFBQUEsZ0JBQ1osVUFBVSxDQUFDdUYsTUFBTTFELFFBQVEsRUFBRSxHQUFHRCxNQUFNNUIsV0FBV3VGLEVBQUVvQyxPQUFPcEgsTUFBTSxDQUFDO0FBQUE7QUFBQSxjQUpuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJcUUsS0FMekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUV1SixNQUFNLEdBQUdLLFVBQVUsSUFBSSxHQUNqQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE9BQU07QUFBQSxnQkFDTixXQUFVO0FBQUEsZ0JBQ1YsT0FBT3ZJLEtBQUszQjtBQUFBQSxnQkFDWixVQUFVLENBQUNzRixNQUFNMUQsUUFBUSxFQUFFLEdBQUdELE1BQU0zQixXQUFXc0YsRUFBRW9DLE9BQU9wSCxNQUFNLENBQUM7QUFBQTtBQUFBLGNBSm5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlxRSxLQUx6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxPQUFNO0FBQUEsY0FDTixNQUFLO0FBQUEsY0FDTCxPQUFPcUIsS0FBSzlCO0FBQUFBLGNBQ1osVUFBVSxDQUFDeUYsTUFBTTFELFFBQVEsRUFBRSxHQUFHRCxNQUFNOUIsYUFBYXlGLEVBQUVvQyxPQUFPcEgsTUFBTSxDQUFDO0FBQUE7QUFBQSxZQUpyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJdUU7QUFBQSxVQUd2RSx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRW1KLFlBQVksTUFBTSxHQUMzRDtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFSSxNQUFNLEdBQUdLLFVBQVUsSUFBSSxHQUNqQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE9BQU07QUFBQSxnQkFDTixXQUFVO0FBQUEsZ0JBQ1YsT0FBT3ZJLEtBQUt6QjtBQUFBQSxnQkFDWixVQUFVLENBQUNvRixNQUFNMUQsUUFBUSxFQUFFLEdBQUdELE1BQU16Qix3QkFBd0JvRixFQUFFb0MsT0FBT3BILE1BQU0sQ0FBQztBQUFBO0FBQUEsY0FKaEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWtGLEtBTHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRW9KLEtBQUssSUFBSXlDLGVBQWUsR0FBRyxHQUN4RDtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLFNBQVN4SyxLQUFLMUI7QUFBQUEsa0JBQ2QsVUFBVSxDQUFDbU0sU0FBU3hLLFFBQVEsRUFBRSxHQUFHRCxNQUFNMUIsbUJBQW1CbU0sS0FBSyxDQUFDO0FBQUEsa0JBQ2hFLE9BQU07QUFBQTtBQUFBLGdCQUhWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUc0QjtBQUFBLGNBRTVCLHVCQUFDLFVBQUssT0FBTyxFQUFFckMsT0FBTyxrQkFBa0JILFVBQVUsU0FBUyxHQUFHLGdDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RTtBQUFBLGlCQU5sRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGVBQWMsd0RBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsUUFBTztBQUFBLGdCQUNQLFVBQVUsQ0FBQ3RFLE1BQU0xQyxhQUFhMEMsRUFBRW9DLE9BQU8yRSxRQUFRLENBQUMsS0FBSyxJQUFJO0FBQUE7QUFBQSxjQUg3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHK0Q7QUFBQSxhQUU3RDlJLG9CQUFvQixRQUFTOUIsWUFBWSxTQUFTQSxZQUFZLFFBQVFBLFFBQVFxSixhQUM1RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLEtBQUt2SCxtQkFBb0I5QixRQUFzQ3FKO0FBQUFBLGdCQUMvRCxLQUFJO0FBQUEsZ0JBQ0osT0FBTztBQUFBLGdCQUNQLFFBQVE7QUFBQSxnQkFDUixPQUFPLEVBQUVWLE9BQU8sSUFBSVcsUUFBUSxJQUFJQyxXQUFXLFNBQVNILGNBQWMsSUFBSUQsUUFBUSx3QkFBd0I7QUFBQTtBQUFBLGNBTDFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUs0RztBQUFBLGVBYnBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFFQ25KLFlBQVksU0FBU0EsWUFBWSxRQUM5Qix1QkFBQyw4QkFBMkIsV0FBV0EsUUFBUTBELE1BQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsVUFHckR0QyxTQUNHLHVCQUFDLE9BQUUsV0FBVSxjQUFhLE1BQUssU0FDMUJBLG1CQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVIbEIsS0FBS2pDLGVBQWUsTUFDakIsdUJBQUMsT0FBRSxXQUFVLGNBQWEsT0FBTyxFQUFFNEosUUFBUSxFQUFFLEdBQUcsZ0VBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUdKO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFRO0FBQUEsY0FDUjtBQUFBLGNBQ0EsU0FBUzlELGFBQWE2RTtBQUFBQSxjQUN0QixVQUFVMUksS0FBSy9CLEtBQUtTLEtBQUssTUFBTSxNQUFNc0IsS0FBS2pDLGVBQWU7QUFBQSxjQUN6RCxTQUFTLE1BQU04RixhQUFhZ0IsT0FBTztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBTHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUE7QUFBQTtBQUFBLE1BNUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTZMQTtBQUFBLE9BM2JSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2YkE7QUFFUjtBQUFDckYsR0FudEJlRCxjQUFZO0FBQUEsVUFDSjFELGdCQUNMQyxXQUNEMkIsVUFDa0JiLGNBK0JSaEIsVUFPVUEsVUFLWkEsVUFRSEEsVUF5REVELGFBbUJTQSxhQXVCTEEsYUFVS0EsYUEwQkNBLGFBV0FBLGFBeUJQQSxXQUFXO0FBQUE7QUFBQSxNQWxPdkI0RDtBQUFZLElBQUFQLElBQUFFLEtBQUFFLEtBQUFFLEtBQUFxTDtBQUFBLGFBQUEzTCxJQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQXFMLEtBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJ1c2VEaWFsb2ciLCJhY3RpdmF0ZUNhdGVnb3J5IiwiYWN0aXZhdGVQcm9kdWN0IiwiY3JlYXRlQ2F0ZWdvcnkiLCJjcmVhdGVQcm9kdWN0IiwiZGVhY3RpdmF0ZUNhdGVnb3J5IiwiZGVhY3RpdmF0ZVByb2R1Y3QiLCJnZXRDYXRlZ29yaWVzIiwiZ2V0Q2F0ZWdvcmllc0Zvck1hbmFnZW1lbnQiLCJnZXRNZW51Rm9yTWFuYWdlbWVudCIsInVwZGF0ZUNhdGVnb3J5IiwidXBkYXRlUHJvZHVjdCIsInVwbG9hZFByb2R1Y3RJbWFnZSIsImdldFN0b2NrQnlCcmFuY2giLCJ1c2VBdXRoU3RvcmUiLCJBcGlFcnJvciIsImZvcm1hdEJSTCIsInVuaXRPZk1lYXN1cmVMYWJlbCIsIlF1ZXJ5RXJyb3IiLCJQcm9kdWN0Q29tcGxlbWVudExpbmtQYW5lbCIsIk1vZGFsIiwiQnV0dG9uIiwiRmllbGQiLCJUZXh0RmllbGQiLCJTZWxlY3RGaWVsZCIsIlN3aXRjaCIsIlN0YXR1c0JhZGdlIiwidXNlVG9hc3QiLCJFbXB0eVN0YXRlIiwiU2tlbGV0b25MaXN0IiwiUEFHRV9TSVpFIiwiQUxMX0NBVEVHT1JJRVMiLCJlbXB0eUZvcm0iLCJjYXRlZ29yeUlkIiwidW5pdE9mTWVhc3VyZUlkIiwibmFtZSIsImRlc2NyaXB0aW9uIiwiYmFyY29kZSIsInNhbGVQcmljZSIsImNvc3RQcmljZSIsImlzU3RvY2tDb250cm9sbGVkIiwicHJlcGFyYXRpb25UaW1lTWludXRlcyIsInBhcnNlTnVtIiwicmF3IiwidHJpbSIsInZhbHVlIiwiTnVtYmVyIiwicmVwbGFjZSIsImlzRmluaXRlIiwiRHJhZ0ljb24iLCJfYyIsIlNlYXJjaEljb24iLCJfYzIiLCJDaGV2cm9uTGVmdCIsIl9jMyIsIkNoZXZyb25SaWdodCIsIl9jNCIsIlByb2R1Y3RzUGFnZSIsIl9zIiwicXVlcnlDbGllbnQiLCJkaWFsb2ciLCJ0b2FzdCIsImNvbXBhbnlJZCIsImJyYW5jaElkIiwiZWRpdGluZyIsInNldEVkaXRpbmciLCJmb3JtIiwic2V0Rm9ybSIsIm5ld0NhdGVnb3J5Iiwic2V0TmV3Q2F0ZWdvcnkiLCJjcmVhdGluZ0NhdGVnb3J5Iiwic2V0Q3JlYXRpbmdDYXRlZ29yeSIsIm1vZGFsTmV3Q2F0ZWdvcnkiLCJzZXRNb2RhbE5ld0NhdGVnb3J5IiwiZWRpdGluZ0NhdGVnb3J5SWQiLCJzZXRFZGl0aW5nQ2F0ZWdvcnlJZCIsImNhdGVnb3J5RWRpdE5hbWUiLCJzZXRDYXRlZ29yeUVkaXROYW1lIiwiY2F0ZWdvcnlFZGl0T3JkZXIiLCJzZXRDYXRlZ29yeUVkaXRPcmRlciIsImRyYWdDYXRlZ29yeUlkIiwic2V0RHJhZ0NhdGVnb3J5SWQiLCJpbWFnZUZpbGUiLCJzZXRJbWFnZUZpbGUiLCJlcnJvciIsInNldEVycm9yIiwic2VsZWN0ZWRDYXRlZ29yeUlkIiwic2V0U2VsZWN0ZWRDYXRlZ29yeUlkIiwic2VhcmNoIiwic2V0U2VhcmNoIiwic3RhdHVzRmlsdGVyIiwic2V0U3RhdHVzRmlsdGVyIiwicGFnZSIsInNldFBhZ2UiLCJpbWFnZVByZXZpZXdVcmwiLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJyZXZva2VPYmplY3RVUkwiLCJjYXRlZ29yaWVzUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJjYXRlZ29yaWVzTWFuYWdlbWVudFF1ZXJ5IiwicHJvZHVjdHNRdWVyeSIsInN0b2NrUXVlcnkiLCJlbmFibGVkIiwic3RvY2tCeVByb2R1Y3QiLCJtYXAiLCJNYXAiLCJzIiwiZGF0YSIsInNldCIsInByb2R1Y3RJZCIsInNvcnRlZENhdGVnb3JpZXMiLCJzb3J0IiwiYSIsImIiLCJkaXNwbGF5T3JkZXIiLCJyZWZyZXNoIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJvcGVuRWRpdG9yIiwicHJvZHVjdCIsIlN0cmluZyIsImlkIiwiYnVpbGRQYXlsb2FkIiwib25BcGlFcnJvciIsImUiLCJtZXNzYWdlIiwic2F2ZU11dGF0aW9uIiwibXV0YXRpb25GbiIsIm9uU3VjY2VzcyIsInN1Y2Nlc3MiLCJvbkVycm9yIiwidG9nZ2xlUHJvZHVjdE11dGF0aW9uIiwiYWN0aXZhdGUiLCJfZGF0YSIsInZhcnMiLCJ0b2dnbGVQcm9kdWN0IiwiaXNBY3RpdmUiLCJjb25maXJtZWQiLCJjb25maXJtIiwidGl0bGUiLCJjb25maXJtTGFiZWwiLCJkYW5nZXIiLCJtdXRhdGUiLCJjYXRlZ29yeU11dGF0aW9uIiwibGVuZ3RoIiwibW9kYWxDYXRlZ29yeU11dGF0aW9uIiwibmV3Q2F0ZWdvcnlJZCIsImYiLCJzdGFydENhdGVnb3J5RWRpdCIsImNhdGVnb3J5IiwiY2FuY2VsQ2F0ZWdvcnlFZGl0IiwidXBkYXRlQ2F0ZWdvcnlNdXRhdGlvbiIsInRvZ2dsZUNhdGVnb3J5TXV0YXRpb24iLCJ0b2dnbGVDYXRlZ29yeSIsInJlb3JkZXJNdXRhdGlvbiIsImZyb20iLCJ0byIsIlByb21pc2UiLCJhbGwiLCJoYW5kbGVDYXRlZ29yeURyb3AiLCJ0YXJnZXQiLCJzb3VyY2UiLCJmaW5kIiwiYyIsInNlbGVjdENhdGVnb3J5IiwiZmlsdGVyZWRQcm9kdWN0cyIsImxpc3QiLCJmaWx0ZXIiLCJwIiwicSIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ0b3RhbFBhZ2VzIiwiTWF0aCIsIm1heCIsImNlaWwiLCJjdXJyZW50UGFnZSIsIm1pbiIsInBhZ2VTdGFydCIsInBhZ2VJdGVtcyIsInNsaWNlIiwic3RvY2tCYWRnZSIsInN0b2NrIiwiZ2V0IiwiY3VycmVudFF1YW50aXR5IiwiaXNCZWxvd01pbmltdW0iLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJwb3NpdGlvbiIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwibWFyZ2luQm90dG9tIiwiZm9udFNpemUiLCJmbGV4IiwiaXNFcnJvciIsImNvbG9yIiwidmlzaWJpbGl0eSIsImluZGV4IiwibWluV2lkdGgiLCJtaW5IZWlnaHQiLCJ3aWR0aCIsImlzUGVuZGluZyIsInByZXZlbnREZWZhdWx0Iiwic3RvcFByb3BhZ2F0aW9uIiwicGFkU3RhcnQiLCJwcm9kdWN0Q291bnQiLCJrZXkiLCJpc0xvYWRpbmciLCJib3JkZXIiLCJib3JkZXJSYWRpdXMiLCJpbWFnZVVybCIsImhlaWdodCIsIm9iamVjdEZpdCIsImZsZXhTaHJpbmsiLCJiYWNrZ3JvdW5kIiwicGxhY2VJdGVtcyIsIndoaXRlU3BhY2UiLCJvdmVyZmxvdyIsInRleHRPdmVyZmxvdyIsImNhdGVnb3J5TmFtZSIsInRleHRBbGlnbiIsImp1c3RpZnlDb250ZW50IiwiQXJyYXkiLCJfIiwiaSIsIm4iLCJjdXJzb3IiLCJhMTF5IiwiT2JqZWN0IiwiZW50cmllcyIsImxhYmVsIiwicGFkZGluZ0JvdHRvbSIsIm5leHQiLCJmaWxlcyIsIl9jNSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9kdWN0c1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgdXNlRGlhbG9nIH0gZnJvbSBcIi4uLy4uL3VpL0RpYWxvZ1wiO1xyXG5pbXBvcnQge1xyXG4gICAgYWN0aXZhdGVDYXRlZ29yeSxcclxuICAgIGFjdGl2YXRlUHJvZHVjdCxcclxuICAgIGNyZWF0ZUNhdGVnb3J5LFxyXG4gICAgY3JlYXRlUHJvZHVjdCxcclxuICAgIGRlYWN0aXZhdGVDYXRlZ29yeSxcclxuICAgIGRlYWN0aXZhdGVQcm9kdWN0LFxyXG4gICAgZ2V0Q2F0ZWdvcmllcyxcclxuICAgIGdldENhdGVnb3JpZXNGb3JNYW5hZ2VtZW50LFxyXG4gICAgZ2V0TWVudUZvck1hbmFnZW1lbnQsXHJcbiAgICB1cGRhdGVDYXRlZ29yeSxcclxuICAgIHVwZGF0ZVByb2R1Y3QsXHJcbiAgICB1cGxvYWRQcm9kdWN0SW1hZ2UsXHJcbiAgICB0eXBlIFByb2R1Y3RQYXlsb2FkLFxyXG59IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyBnZXRTdG9ja0J5QnJhbmNoIH0gZnJvbSBcIi4uL3N0b2NrL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IGZvcm1hdEJSTCwgdW5pdE9mTWVhc3VyZUxhYmVsIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IENhdGVnb3J5TWFuYWdlbWVudFJlc3BvbnNlLCBQcm9kdWN0TWFuYWdlbWVudFJlc3BvbnNlLCBTdG9ja0l0ZW1SZXNwb25zZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuaW1wb3J0IHsgUHJvZHVjdENvbXBsZW1lbnRMaW5rUGFuZWwgfSBmcm9tIFwiLi9Qcm9kdWN0Q29tcGxlbWVudExpbmtQYW5lbFwiO1xyXG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gXCIuLi8uLi91aS9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IEZpZWxkLCBUZXh0RmllbGQsIFNlbGVjdEZpZWxkIH0gZnJvbSBcIi4uLy4uL3VpL0ZpZWxkXCI7XHJcbmltcG9ydCB7IFN3aXRjaCB9IGZyb20gXCIuLi8uLi91aS9Td2l0Y2hcIjtcclxuaW1wb3J0IHsgU3RhdHVzQmFkZ2UgfSBmcm9tIFwiLi4vLi4vdWkvU3RhdHVzQmFkZ2VcIjtcclxuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vLi4vdWkvVG9hc3RcIjtcclxuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCIuLi8uLi91aS9FbXB0eVN0YXRlXCI7XHJcbmltcG9ydCB7IFNrZWxldG9uTGlzdCB9IGZyb20gXCIuLi8uLi91aS9Ta2VsZXRvblwiO1xyXG5cclxuY29uc3QgUEFHRV9TSVpFID0gODtcclxuY29uc3QgQUxMX0NBVEVHT1JJRVMgPSBcImFsbFwiIGFzIGNvbnN0O1xyXG50eXBlIFN0YXR1c0ZpbHRlciA9IFwiYWxsXCIgfCBcImFjdGl2ZVwiIHwgXCJpbmFjdGl2ZVwiO1xyXG5cclxuY29uc3QgZW1wdHlGb3JtID0ge1xyXG4gICAgY2F0ZWdvcnlJZDogXCJcIixcclxuICAgIHVuaXRPZk1lYXN1cmVJZDogXCIxXCIsXHJcbiAgICBuYW1lOiBcIlwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICBiYXJjb2RlOiBcIlwiLFxyXG4gICAgc2FsZVByaWNlOiBcIlwiLFxyXG4gICAgY29zdFByaWNlOiBcIlwiLFxyXG4gICAgaXNTdG9ja0NvbnRyb2xsZWQ6IHRydWUsXHJcbiAgICBwcmVwYXJhdGlvblRpbWVNaW51dGVzOiBcIlwiLFxyXG59O1xyXG5cclxudHlwZSBGb3JtU3RhdGUgPSB0eXBlb2YgZW1wdHlGb3JtO1xyXG5cclxuY29uc3QgcGFyc2VOdW0gPSAocmF3OiBzdHJpbmcpOiBudW1iZXIgfCBudWxsID0+IHtcclxuICAgIGlmIChyYXcudHJpbSgpID09PSBcIlwiKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IHZhbHVlID0gTnVtYmVyKHJhdy5yZXBsYWNlKFwiLFwiLCBcIi5cIikpO1xyXG4gICAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgPyB2YWx1ZSA6IG51bGw7XHJcbn07XHJcblxyXG4vKiDDjWNvbmVzIGlubGluZSAoc2VtIGRlcGVuZMOqbmNpYSBleHRlcm5hKSDigJQgdHJhw6dvIGZpbm8sIDEuNnB4LCBubyBlc3RpbG8gZG8gcmVzdG8gZGEgVUkuICovXHJcbmNvbnN0IERyYWdJY29uID0gKCkgPT4gKFxyXG4gICAgPHN2ZyB3aWR0aD1cIjEzXCIgaGVpZ2h0PVwiMTNcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICAgIDxjaXJjbGUgY3g9XCI4XCIgY3k9XCI2XCIgcj1cIjEuNlwiIC8+PGNpcmNsZSBjeD1cIjE2XCIgY3k9XCI2XCIgcj1cIjEuNlwiIC8+XHJcbiAgICAgICAgPGNpcmNsZSBjeD1cIjhcIiBjeT1cIjEyXCIgcj1cIjEuNlwiIC8+PGNpcmNsZSBjeD1cIjE2XCIgY3k9XCIxMlwiIHI9XCIxLjZcIiAvPlxyXG4gICAgICAgIDxjaXJjbGUgY3g9XCI4XCIgY3k9XCIxOFwiIHI9XCIxLjZcIiAvPjxjaXJjbGUgY3g9XCIxNlwiIGN5PVwiMThcIiByPVwiMS42XCIgLz5cclxuICAgIDwvc3ZnPlxyXG4pO1xyXG5jb25zdCBTZWFyY2hJY29uID0gKCkgPT4gKFxyXG4gICAgPHN2ZyB3aWR0aD1cIjE1XCIgaGVpZ2h0PVwiMTVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgICA8Y2lyY2xlIGN4PVwiMTFcIiBjeT1cIjExXCIgcj1cIjdcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjEuOFwiIC8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0yMSAyMWwtNC4zLTQuM1wiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMS44XCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgLz5cclxuICAgIDwvc3ZnPlxyXG4pO1xyXG5jb25zdCBDaGV2cm9uTGVmdCA9ICgpID0+IChcclxuICAgIDxzdmcgd2lkdGg9XCIxMlwiIGhlaWdodD1cIjEyXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgICAgPHBhdGggZD1cIk0xNSA1bC03IDcgNyA3XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIC8+XHJcbiAgICA8L3N2Zz5cclxuKTtcclxuY29uc3QgQ2hldnJvblJpZ2h0ID0gKCkgPT4gKFxyXG4gICAgPHN2ZyB3aWR0aD1cIjEyXCIgaGVpZ2h0PVwiMTJcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgICA8cGF0aCBkPVwiTTkgNWw3IDctNyA3XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIC8+XHJcbiAgICA8L3N2Zz5cclxuKTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBQcm9kdWN0c1BhZ2UoKSB7XHJcbiAgICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgICBjb25zdCBkaWFsb2cgPSB1c2VEaWFsb2coKTtcclxuICAgIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICAgIGNvbnN0IHsgY29tcGFueUlkLCBicmFuY2hJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgICBjb25zdCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZTxQcm9kdWN0TWFuYWdlbWVudFJlc3BvbnNlIHwgXCJuZXdcIiB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGU8Rm9ybVN0YXRlPihlbXB0eUZvcm0pO1xyXG4gICAgY29uc3QgW25ld0NhdGVnb3J5LCBzZXROZXdDYXRlZ29yeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtjcmVhdGluZ0NhdGVnb3J5LCBzZXRDcmVhdGluZ0NhdGVnb3J5XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFttb2RhbE5ld0NhdGVnb3J5LCBzZXRNb2RhbE5ld0NhdGVnb3J5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW2VkaXRpbmdDYXRlZ29yeUlkLCBzZXRFZGl0aW5nQ2F0ZWdvcnlJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFtjYXRlZ29yeUVkaXROYW1lLCBzZXRDYXRlZ29yeUVkaXROYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW2NhdGVnb3J5RWRpdE9yZGVyLCBzZXRDYXRlZ29yeUVkaXRPcmRlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtkcmFnQ2F0ZWdvcnlJZCwgc2V0RHJhZ0NhdGVnb3J5SWRdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbaW1hZ2VGaWxlLCBzZXRJbWFnZUZpbGVdID0gdXNlU3RhdGU8RmlsZSB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgICAvLyBQYWluZWwgZGUgcHJvZHV0b3M6IGNhdGVnb3JpYSBzZWxlY2lvbmFkYSwgYnVzY2EsIGZpbHRybyBkZSBzdGF0dXMgZSBwYWdpbmHDp8Ojby5cclxuICAgIGNvbnN0IFtzZWxlY3RlZENhdGVnb3J5SWQsIHNldFNlbGVjdGVkQ2F0ZWdvcnlJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCB0eXBlb2YgQUxMX0NBVEVHT1JJRVM+KEFMTF9DQVRFR09SSUVTKTtcclxuICAgIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtzdGF0dXNGaWx0ZXIsIHNldFN0YXR1c0ZpbHRlcl0gPSB1c2VTdGF0ZTxTdGF0dXNGaWx0ZXI+KFwiYWxsXCIpO1xyXG4gICAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMSk7XHJcblxyXG4gICAgY29uc3QgaW1hZ2VQcmV2aWV3VXJsID0gdXNlTWVtbyhcclxuICAgICAgICAoKSA9PiAoaW1hZ2VGaWxlICE9PSBudWxsID8gVVJMLmNyZWF0ZU9iamVjdFVSTChpbWFnZUZpbGUpIDogbnVsbCksXHJcbiAgICAgICAgW2ltYWdlRmlsZV0sXHJcbiAgICApO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoaW1hZ2VQcmV2aWV3VXJsICE9PSBudWxsKSBVUkwucmV2b2tlT2JqZWN0VVJMKGltYWdlUHJldmlld1VybCk7XHJcbiAgICAgICAgfTtcclxuICAgIH0sIFtpbWFnZVByZXZpZXdVcmxdKTtcclxuXHJcbiAgICAvLyBMaXN0YSBcInBhcmEgcGVkaWRvXCIgKHPDsyBhdGl2YXMpIOKAlCBhbGltZW50YSBvIDxzZWxlY3Q+IGRlIGNhdGVnb3JpYSBkbyBtb2RhbCBkZSBwcm9kdXRvO1xyXG4gICAgLy8gbnVuY2EgZGV2ZSBzZXIgcG9zc8OtdmVsIGNhZGFzdHJhciB1bSBwcm9kdXRvIG51bWEgY2F0ZWdvcmlhIGrDoSBkZXNhdGl2YWRhLlxyXG4gICAgY29uc3QgY2F0ZWdvcmllc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgICAgIHF1ZXJ5S2V5OiBbXCJjYXRlZ29yaWVzXCIsIGNvbXBhbnlJZF0sXHJcbiAgICAgICAgcXVlcnlGbjogKCkgPT4gZ2V0Q2F0ZWdvcmllcyhjb21wYW55SWQgPz8gMSksXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBMaXN0YSBcImRlIGdlcmVuY2lhbWVudG9cIiAoYXRpdmFzICsgaW5hdGl2YXMsIGNvbSBjb250YWRvciBkZSBpdGVucykg4oCUIGFsaW1lbnRhIGEgY29sdW5hXHJcbiAgICAvLyBkZSBjYXRlZ29yaWFzIGRvIHNwbGl0IHZpZXcuXHJcbiAgICBjb25zdCBjYXRlZ29yaWVzTWFuYWdlbWVudFF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgICAgIHF1ZXJ5S2V5OiBbXCJjYXRlZ29yaWVzXCIsIFwibWFuYWdlbWVudFwiLCBjb21wYW55SWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldENhdGVnb3JpZXNGb3JNYW5hZ2VtZW50KGNvbXBhbnlJZCA/PyAxKSxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHByb2R1Y3RzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcIm1lbnVcIiwgXCJtYW5hZ2VtZW50XCIsIGNvbXBhbnlJZF0sXHJcbiAgICAgICAgcXVlcnlGbjogKCkgPT4gZ2V0TWVudUZvck1hbmFnZW1lbnQoY29tcGFueUlkID8/IDEpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gRXN0b3F1ZSByZWFsIGRhIGZpbGlhbCBhdHVhbCDigJQgdXNhZG8gc8OzIHBhcmEgbyBzZWxvIFwiRW0gZXN0b3F1ZS9CYWl4by9TZW0gZXN0b3F1ZVwiLlxyXG4gICAgLy8gU2UgZmFsaGFyIG91IG7Do28gdGl2ZXIgYnJhbmNoSWQsIG9zIHByb2R1dG9zIGNvbSBjb250cm9sZSBkZSBlc3RvcXVlIGNhZW0gbm8gc2Vsb1xyXG4gICAgLy8gbmV1dHJvIFwiU2VtIHJlZ2lzdHJvXCIgZW0gdmV6IGRlIHF1ZWJyYXIgYSB0ZWxhLlxyXG4gICAgY29uc3Qgc3RvY2tRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgICAgICBxdWVyeUtleTogW1wic3RvY2tcIiwgXCJicmFuY2hcIiwgYnJhbmNoSWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldFN0b2NrQnlCcmFuY2goYnJhbmNoSWQgPz8gMSksXHJcbiAgICAgICAgZW5hYmxlZDogYnJhbmNoSWQgIT0gbnVsbCxcclxuICAgIH0pO1xyXG4gICAgY29uc3Qgc3RvY2tCeVByb2R1Y3QgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBjb25zdCBtYXAgPSBuZXcgTWFwPG51bWJlciwgU3RvY2tJdGVtUmVzcG9uc2U+KCk7XHJcbiAgICAgICAgZm9yIChjb25zdCBzIG9mIHN0b2NrUXVlcnkuZGF0YSA/PyBbXSkgbWFwLnNldChzLnByb2R1Y3RJZCwgcyk7XHJcbiAgICAgICAgcmV0dXJuIG1hcDtcclxuICAgIH0sIFtzdG9ja1F1ZXJ5LmRhdGFdKTtcclxuXHJcbiAgICBjb25zdCBzb3J0ZWRDYXRlZ29yaWVzID0gdXNlTWVtbyhcclxuICAgICAgICAoKSA9PiBbLi4uKGNhdGVnb3JpZXNNYW5hZ2VtZW50UXVlcnkuZGF0YSA/PyBbXSldLnNvcnQoKGEsIGIpID0+IGEuZGlzcGxheU9yZGVyIC0gYi5kaXNwbGF5T3JkZXIpLFxyXG4gICAgICAgIFtjYXRlZ29yaWVzTWFuYWdlbWVudFF1ZXJ5LmRhdGFdLFxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCByZWZyZXNoID0gKCkgPT4ge1xyXG4gICAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wibWVudVwiXSB9KTtcclxuICAgICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImNhdGVnb3JpZXNcIl0gfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IG9wZW5FZGl0b3IgPSAocHJvZHVjdDogUHJvZHVjdE1hbmFnZW1lbnRSZXNwb25zZSB8IFwibmV3XCIpID0+IHtcclxuICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICBzZXRJbWFnZUZpbGUobnVsbCk7XHJcbiAgICAgICAgc2V0Q3JlYXRpbmdDYXRlZ29yeShmYWxzZSk7XHJcbiAgICAgICAgc2V0TW9kYWxOZXdDYXRlZ29yeShcIlwiKTtcclxuICAgICAgICBzZXRFZGl0aW5nKHByb2R1Y3QpO1xyXG4gICAgICAgIGlmIChwcm9kdWN0ID09PSBcIm5ld1wiKSBzZXRGb3JtKHsgLi4uZW1wdHlGb3JtLCBjYXRlZ29yeUlkOiBTdHJpbmcoY2F0ZWdvcmllc1F1ZXJ5LmRhdGE/LlswXT8uaWQgPz8gXCJcIikgfSk7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBzZXRGb3JtKHtcclxuICAgICAgICAgICAgICAgIGNhdGVnb3J5SWQ6IFN0cmluZyhwcm9kdWN0LmNhdGVnb3J5SWQpLFxyXG4gICAgICAgICAgICAgICAgdW5pdE9mTWVhc3VyZUlkOiBTdHJpbmcocHJvZHVjdC51bml0T2ZNZWFzdXJlSWQpLFxyXG4gICAgICAgICAgICAgICAgbmFtZTogcHJvZHVjdC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHByb2R1Y3QuZGVzY3JpcHRpb24gPz8gXCJcIixcclxuICAgICAgICAgICAgICAgIGJhcmNvZGU6IHByb2R1Y3QuYmFyY29kZSA/PyBcIlwiLFxyXG4gICAgICAgICAgICAgICAgc2FsZVByaWNlOiBTdHJpbmcocHJvZHVjdC5zYWxlUHJpY2UpLFxyXG4gICAgICAgICAgICAgICAgY29zdFByaWNlOiBwcm9kdWN0LmNvc3RQcmljZSA9PT0gbnVsbCA/IFwiXCIgOiBTdHJpbmcocHJvZHVjdC5jb3N0UHJpY2UpLFxyXG4gICAgICAgICAgICAgICAgaXNTdG9ja0NvbnRyb2xsZWQ6IHByb2R1Y3QuaXNTdG9ja0NvbnRyb2xsZWQsXHJcbiAgICAgICAgICAgICAgICBwcmVwYXJhdGlvblRpbWVNaW51dGVzOiBwcm9kdWN0LnByZXBhcmF0aW9uVGltZU1pbnV0ZXMgPT09IG51bGwgPyBcIlwiIDogU3RyaW5nKHByb2R1Y3QucHJlcGFyYXRpb25UaW1lTWludXRlcyksXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBidWlsZFBheWxvYWQgPSAoKTogUHJvZHVjdFBheWxvYWQgPT4gKHtcclxuICAgICAgICBjYXRlZ29yeUlkOiBOdW1iZXIoZm9ybS5jYXRlZ29yeUlkKSxcclxuICAgICAgICB1bml0T2ZNZWFzdXJlSWQ6IE51bWJlcihmb3JtLnVuaXRPZk1lYXN1cmVJZCksXHJcbiAgICAgICAgbmFtZTogZm9ybS5uYW1lLnRyaW0oKSxcclxuICAgICAgICBkZXNjcmlwdGlvbjogZm9ybS5kZXNjcmlwdGlvbi50cmltKCkgPT09IFwiXCIgPyBudWxsIDogZm9ybS5kZXNjcmlwdGlvbi50cmltKCksXHJcbiAgICAgICAgYmFyY29kZTogZm9ybS5iYXJjb2RlLnRyaW0oKSA9PT0gXCJcIiA/IG51bGwgOiBmb3JtLmJhcmNvZGUudHJpbSgpLFxyXG4gICAgICAgIHNhbGVQcmljZTogcGFyc2VOdW0oZm9ybS5zYWxlUHJpY2UpID8/IDAsXHJcbiAgICAgICAgY29zdFByaWNlOiBwYXJzZU51bShmb3JtLmNvc3RQcmljZSksXHJcbiAgICAgICAgaXNTdG9ja0NvbnRyb2xsZWQ6IGZvcm0uaXNTdG9ja0NvbnRyb2xsZWQsXHJcbiAgICAgICAgcHJlcGFyYXRpb25UaW1lTWludXRlczogZm9ybS5wcmVwYXJhdGlvblRpbWVNaW51dGVzLnRyaW0oKSA9PT0gXCJcIiA/IG51bGwgOiBOdW1iZXIoZm9ybS5wcmVwYXJhdGlvblRpbWVNaW51dGVzKSxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IG9uQXBpRXJyb3IgPSAoZTogdW5rbm93bikgPT5cclxuICAgICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIk9wZXJhw6fDo28gZmFsaG91LlwiKTtcclxuXHJcbiAgICBjb25zdCBzYXZlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBwcm9kdWN0SWQgPVxyXG4gICAgICAgICAgICAgICAgZWRpdGluZyA9PT0gXCJuZXdcIlxyXG4gICAgICAgICAgICAgICAgICAgID8gYXdhaXQgY3JlYXRlUHJvZHVjdChjb21wYW55SWQgPz8gMSwgYnVpbGRQYXlsb2FkKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgOiAoZWRpdGluZyBhcyBQcm9kdWN0TWFuYWdlbWVudFJlc3BvbnNlKS5pZDtcclxuICAgICAgICAgICAgaWYgKGVkaXRpbmcgIT09IFwibmV3XCIpIGF3YWl0IHVwZGF0ZVByb2R1Y3QocHJvZHVjdElkLCBidWlsZFBheWxvYWQoKSk7XHJcbiAgICAgICAgICAgIGlmIChpbWFnZUZpbGUgIT09IG51bGwpIGF3YWl0IHVwbG9hZFByb2R1Y3RJbWFnZShwcm9kdWN0SWQsIGltYWdlRmlsZSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhlZGl0aW5nID09PSBcIm5ld1wiID8gXCJQcm9kdXRvIGNyaWFkby5cIiA6IFwiUHJvZHV0byBhdHVhbGl6YWRvLlwiKTtcclxuICAgICAgICAgICAgc2V0RWRpdGluZyhudWxsKTtcclxuICAgICAgICAgICAgcmVmcmVzaCgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIFVtIHN3aXRjaCBzw7MsIGR1YXMgbXV0YcOnw7VlcyBwb3IgdHLDoXM6IGxpZ2EgY2hhbWEgYWN0aXZhdGVQcm9kdWN0LCBkZXNsaWdhIGNoYW1hXHJcbiAgICAvLyBkZWFjdGl2YXRlUHJvZHVjdCDigJQgbWFudMOpbSBvIGhpc3TDs3JpY28vXSlzb2Z0IGRlbGV0ZSBzZW0gcHJlY2lzYXIgZGUgZG9pcyBib3TDtWVzLlxyXG4gICAgY29uc3QgdG9nZ2xlUHJvZHVjdE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46ICh7IGlkLCBhY3RpdmF0ZSB9OiB7IGlkOiBudW1iZXI7IGFjdGl2YXRlOiBib29sZWFuIH0pID0+XHJcbiAgICAgICAgICAgIGFjdGl2YXRlID8gYWN0aXZhdGVQcm9kdWN0KGlkKSA6IGRlYWN0aXZhdGVQcm9kdWN0KGlkKSxcclxuICAgICAgICBvblN1Y2Nlc3M6IChfZGF0YSwgdmFycykgPT4ge1xyXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKHZhcnMuYWN0aXZhdGUgPyBcIlByb2R1dG8gYXRpdmFkby5cIiA6IFwiUHJvZHV0byBkZXNhdGl2YWRvLlwiKTtcclxuICAgICAgICAgICAgcmVmcmVzaCgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHRvZ2dsZVByb2R1Y3QgPSBhc3luYyAocHJvZHVjdDogUHJvZHVjdE1hbmFnZW1lbnRSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChwcm9kdWN0LmlzQWN0aXZlKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGNvbmZpcm1lZCA9IGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBcIkRlc2F0aXZhciBwcm9kdXRvXCIsXHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBgRGVzYXRpdmFyIFwiJHtwcm9kdWN0Lm5hbWV9XCI/IEVsZSBkZWl4YSBkZSBhcGFyZWNlciBubyBjYXJkw6FwaW8gcGFyYSBwZWRpZG9zLmAsXHJcbiAgICAgICAgICAgICAgICBjb25maXJtTGFiZWw6IFwiRGVzYXRpdmFyXCIsXHJcbiAgICAgICAgICAgICAgICBkYW5nZXI6IHRydWUsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBpZiAoIWNvbmZpcm1lZCkgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0b2dnbGVQcm9kdWN0TXV0YXRpb24ubXV0YXRlKHsgaWQ6IHByb2R1Y3QuaWQsIGFjdGl2YXRlOiAhcHJvZHVjdC5pc0FjdGl2ZSB9KTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgY2F0ZWdvcnlNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICAgICAgICBjcmVhdGVDYXRlZ29yeShjb21wYW55SWQgPz8gMSwgbmV3Q2F0ZWdvcnkudHJpbSgpLCAoY2F0ZWdvcmllc01hbmFnZW1lbnRRdWVyeS5kYXRhPy5sZW5ndGggPz8gMCkgKyAxKSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgICAgc2V0TmV3Q2F0ZWdvcnkoXCJcIik7XHJcbiAgICAgICAgICAgIHJlZnJlc2goKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBtb2RhbENhdGVnb3J5TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgICAgICAgY3JlYXRlQ2F0ZWdvcnkoY29tcGFueUlkID8/IDEsIG1vZGFsTmV3Q2F0ZWdvcnkudHJpbSgpLCAoY2F0ZWdvcmllc01hbmFnZW1lbnRRdWVyeS5kYXRhPy5sZW5ndGggPz8gMCkgKyAxKSxcclxuICAgICAgICBvblN1Y2Nlc3M6IChuZXdDYXRlZ29yeUlkKSA9PiB7XHJcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJDYXRlZ29yaWEgY3JpYWRhLlwiKTtcclxuICAgICAgICAgICAgc2V0Rm9ybSgoZikgPT4gKHsgLi4uZiwgY2F0ZWdvcnlJZDogU3RyaW5nKG5ld0NhdGVnb3J5SWQpIH0pKTtcclxuICAgICAgICAgICAgc2V0TW9kYWxOZXdDYXRlZ29yeShcIlwiKTtcclxuICAgICAgICAgICAgc2V0Q3JlYXRpbmdDYXRlZ29yeShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICAgICAgICByZWZyZXNoKCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3Qgc3RhcnRDYXRlZ29yeUVkaXQgPSAoY2F0ZWdvcnk6IENhdGVnb3J5TWFuYWdlbWVudFJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgc2V0RWRpdGluZ0NhdGVnb3J5SWQoY2F0ZWdvcnkuaWQpO1xyXG4gICAgICAgIHNldENhdGVnb3J5RWRpdE5hbWUoY2F0ZWdvcnkubmFtZSk7XHJcbiAgICAgICAgc2V0Q2F0ZWdvcnlFZGl0T3JkZXIoU3RyaW5nKGNhdGVnb3J5LmRpc3BsYXlPcmRlcikpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBjYW5jZWxDYXRlZ29yeUVkaXQgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0RWRpdGluZ0NhdGVnb3J5SWQobnVsbCk7XHJcbiAgICAgICAgc2V0Q2F0ZWdvcnlFZGl0TmFtZShcIlwiKTtcclxuICAgICAgICBzZXRDYXRlZ29yeUVkaXRPcmRlcihcIlwiKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgdXBkYXRlQ2F0ZWdvcnlNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICAgICAgICB1cGRhdGVDYXRlZ29yeShlZGl0aW5nQ2F0ZWdvcnlJZCEsIGNhdGVnb3J5RWRpdE5hbWUudHJpbSgpLCBOdW1iZXIoY2F0ZWdvcnlFZGl0T3JkZXIpIHx8IDApLFxyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiQ2F0ZWdvcmlhIGF0dWFsaXphZGEuXCIpO1xyXG4gICAgICAgICAgICBjYW5jZWxDYXRlZ29yeUVkaXQoKTtcclxuICAgICAgICAgICAgcmVmcmVzaCgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHRvZ2dsZUNhdGVnb3J5TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKHsgaWQsIGFjdGl2YXRlIH06IHsgaWQ6IG51bWJlcjsgYWN0aXZhdGU6IGJvb2xlYW4gfSkgPT5cclxuICAgICAgICAgICAgYWN0aXZhdGUgPyBhY3RpdmF0ZUNhdGVnb3J5KGlkKSA6IGRlYWN0aXZhdGVDYXRlZ29yeShpZCksXHJcbiAgICAgICAgb25TdWNjZXNzOiAoX2RhdGEsIHZhcnMpID0+IHtcclxuICAgICAgICAgICAgdG9hc3Quc3VjY2Vzcyh2YXJzLmFjdGl2YXRlID8gXCJDYXRlZ29yaWEgYXRpdmFkYS5cIiA6IFwiQ2F0ZWdvcmlhIGRlc2F0aXZhZGEuXCIpO1xyXG4gICAgICAgICAgICByZWZyZXNoKCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgdG9nZ2xlQ2F0ZWdvcnkgPSBhc3luYyAoY2F0ZWdvcnk6IENhdGVnb3J5TWFuYWdlbWVudFJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKGNhdGVnb3J5LmlzQWN0aXZlKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGNvbmZpcm1lZCA9IGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBcIkRlc2F0aXZhciBjYXRlZ29yaWFcIixcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGBEZXNhdGl2YXIgXCIke2NhdGVnb3J5Lm5hbWV9XCI/IFByb2R1dG9zIGrDoSBjYWRhc3RyYWRvcyBuZWxhIGNvbnRpbnVhbSBmdW5jaW9uYW5kbywgbWFzIGVsYSBkZWl4YSBkZSBhcGFyZWNlciBjb21vIG9ww6fDo28gcGFyYSBub3ZvcyBjYWRhc3Ryb3MuYCxcclxuICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJEZXNhdGl2YXJcIixcclxuICAgICAgICAgICAgICAgIGRhbmdlcjogdHJ1ZSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGlmICghY29uZmlybWVkKSByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRvZ2dsZUNhdGVnb3J5TXV0YXRpb24ubXV0YXRlKHsgaWQ6IGNhdGVnb3J5LmlkLCBhY3RpdmF0ZTogIWNhdGVnb3J5LmlzQWN0aXZlIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBSZW9yZGVuYXIgYXJyYXN0YW5kbzogdHJvY2EgbyBEaXNwbGF5T3JkZXIgZGFzIGR1YXMgY2F0ZWdvcmlhcyBlbnZvbHZpZGFzIHZpYSBvXHJcbiAgICAvLyBtZXNtbyBlbmRwb2ludCBQVVQgL2FwaS9jYXRlZ29yaWVzL3tpZH0gcXVlIGEgZWRpw6fDo28gbWFudWFsIGrDoSB1c2EuXHJcbiAgICBjb25zdCByZW9yZGVyTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogYXN5bmMgKHsgZnJvbSwgdG8gfTogeyBmcm9tOiBDYXRlZ29yeU1hbmFnZW1lbnRSZXNwb25zZTsgdG86IENhdGVnb3J5TWFuYWdlbWVudFJlc3BvbnNlIH0pID0+IHtcclxuICAgICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICAgICAgdXBkYXRlQ2F0ZWdvcnkoZnJvbS5pZCwgZnJvbS5uYW1lLCB0by5kaXNwbGF5T3JkZXIpLFxyXG4gICAgICAgICAgICAgICAgdXBkYXRlQ2F0ZWdvcnkodG8uaWQsIHRvLm5hbWUsIGZyb20uZGlzcGxheU9yZGVyKSxcclxuICAgICAgICAgICAgXSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHJlZnJlc2goKSxcclxuICAgICAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2F0ZWdvcnlEcm9wID0gKHRhcmdldDogQ2F0ZWdvcnlNYW5hZ2VtZW50UmVzcG9uc2UpID0+IHtcclxuICAgICAgICBjb25zdCBzb3VyY2UgPSBzb3J0ZWRDYXRlZ29yaWVzLmZpbmQoKGMpID0+IGMuaWQgPT09IGRyYWdDYXRlZ29yeUlkKTtcclxuICAgICAgICBzZXREcmFnQ2F0ZWdvcnlJZChudWxsKTtcclxuICAgICAgICBpZiAoIXNvdXJjZSB8fCBzb3VyY2UuaWQgPT09IHRhcmdldC5pZCkgcmV0dXJuO1xyXG4gICAgICAgIHJlb3JkZXJNdXRhdGlvbi5tdXRhdGUoeyBmcm9tOiBzb3VyY2UsIHRvOiB0YXJnZXQgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHNlbGVjdENhdGVnb3J5ID0gKGlkOiBudW1iZXIgfCB0eXBlb2YgQUxMX0NBVEVHT1JJRVMpID0+IHtcclxuICAgICAgICBzZXRTZWxlY3RlZENhdGVnb3J5SWQoaWQpO1xyXG4gICAgICAgIHNldFBhZ2UoMSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGZpbHRlcmVkUHJvZHVjdHMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBsZXQgbGlzdCA9IHByb2R1Y3RzUXVlcnkuZGF0YSA/PyBbXTtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRDYXRlZ29yeUlkICE9PSBBTExfQ0FURUdPUklFUykgbGlzdCA9IGxpc3QuZmlsdGVyKChwKSA9PiBwLmNhdGVnb3J5SWQgPT09IHNlbGVjdGVkQ2F0ZWdvcnlJZCk7XHJcbiAgICAgICAgaWYgKHN0YXR1c0ZpbHRlciA9PT0gXCJhY3RpdmVcIikgbGlzdCA9IGxpc3QuZmlsdGVyKChwKSA9PiBwLmlzQWN0aXZlKTtcclxuICAgICAgICBpZiAoc3RhdHVzRmlsdGVyID09PSBcImluYWN0aXZlXCIpIGxpc3QgPSBsaXN0LmZpbHRlcigocCkgPT4gIXAuaXNBY3RpdmUpO1xyXG4gICAgICAgIGlmIChzZWFyY2gudHJpbSgpICE9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHEgPSBzZWFyY2gudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgIGxpc3QgPSBsaXN0LmZpbHRlcigocCkgPT4gcC5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbGlzdDtcclxuICAgIH0sIFtwcm9kdWN0c1F1ZXJ5LmRhdGEsIHNlbGVjdGVkQ2F0ZWdvcnlJZCwgc3RhdHVzRmlsdGVyLCBzZWFyY2hdKTtcclxuXHJcbiAgICBjb25zdCB0b3RhbFBhZ2VzID0gTWF0aC5tYXgoMSwgTWF0aC5jZWlsKGZpbHRlcmVkUHJvZHVjdHMubGVuZ3RoIC8gUEFHRV9TSVpFKSk7XHJcbiAgICBjb25zdCBjdXJyZW50UGFnZSA9IE1hdGgubWluKHBhZ2UsIHRvdGFsUGFnZXMpO1xyXG4gICAgY29uc3QgcGFnZVN0YXJ0ID0gKGN1cnJlbnRQYWdlIC0gMSkgKiBQQUdFX1NJWkU7XHJcbiAgICBjb25zdCBwYWdlSXRlbXMgPSBmaWx0ZXJlZFByb2R1Y3RzLnNsaWNlKHBhZ2VTdGFydCwgcGFnZVN0YXJ0ICsgUEFHRV9TSVpFKTtcclxuXHJcbiAgICBjb25zdCBzdG9ja0JhZGdlID0gKHByb2R1Y3Q6IFByb2R1Y3RNYW5hZ2VtZW50UmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAoIXByb2R1Y3QuaXNTdG9ja0NvbnRyb2xsZWQpIHJldHVybiA8U3RhdHVzQmFkZ2UgY29sb3I9XCJ2YXIoLS1pbmstZmFpbnQpXCI+U2VtIGNvbnRyb2xlPC9TdGF0dXNCYWRnZT47XHJcbiAgICAgICAgY29uc3Qgc3RvY2sgPSBzdG9ja0J5UHJvZHVjdC5nZXQocHJvZHVjdC5pZCk7XHJcbiAgICAgICAgaWYgKCFzdG9jaykgcmV0dXJuIDxTdGF0dXNCYWRnZSBjb2xvcj1cInZhcigtLWluay1mYWludClcIj5TZW0gcmVnaXN0cm88L1N0YXR1c0JhZGdlPjtcclxuICAgICAgICBpZiAoc3RvY2suY3VycmVudFF1YW50aXR5IDw9IDApIHJldHVybiA8U3RhdHVzQmFkZ2UgY29sb3I9XCJ2YXIoLS1kYW5nZXIpXCI+U2VtIGVzdG9xdWU8L1N0YXR1c0JhZGdlPjtcclxuICAgICAgICBpZiAoc3RvY2suaXNCZWxvd01pbmltdW0pIHJldHVybiA8U3RhdHVzQmFkZ2UgY29sb3I9XCJ2YXIoLS1hbWJlcilcIj5CYWl4byDCtyB7c3RvY2suY3VycmVudFF1YW50aXR5fTwvU3RhdHVzQmFkZ2U+O1xyXG4gICAgICAgIHJldHVybiA8U3RhdHVzQmFkZ2UgY29sb3I9XCJ2YXIoLS1vaylcIj5FbSBlc3RvcXVlIMK3IHtzdG9jay5jdXJyZW50UXVhbnRpdHl9PC9TdGF0dXNCYWRnZT47XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMjgwLCBtYXJnaW46IFwiMCBhdXRvXCIsIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImJhc2VsaW5lXCIsIGdhcDogMTQsIG1hcmdpbkJvdHRvbTogMTggfX0+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuN3JlbVwiIH19PkNhcmTDoXBpbzwvaDI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiIG9uQ2xpY2s9eygpID0+IG9wZW5FZGl0b3IoXCJuZXdcIil9PisgTm92byBwcm9kdXRvPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge2NhdGVnb3JpZXNNYW5hZ2VtZW50UXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17Y2F0ZWdvcmllc01hbmFnZW1lbnRRdWVyeS5lcnJvcn0gd2hhdD1cImFzIGNhdGVnb3JpYXNcIiAvPn1cclxuICAgICAgICAgICAge3Byb2R1Y3RzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17cHJvZHVjdHNRdWVyeS5lcnJvcn0gd2hhdD1cIm8gY2FyZMOhcGlvXCIgLz59XHJcbiAgICAgICAgICAgIHtlcnJvciAmJiAhZWRpdGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCIgcm9sZT1cImFsZXJ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXRhbG9nLXNwbGl0IHJpc2UgcmlzZS0xXCI+XHJcbiAgICAgICAgICAgICAgICB7LyogLS0tIENvbHVuYSBlc3F1ZXJkYTogY2F0ZWdvcmlhcyAtLS0gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctcGFuZWxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctcGFuZWwtaGVhZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45NXJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiIH19PkNhdGVnb3JpYXM8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXRhbG9nLWNvdW50XCI+e3NvcnRlZENhdGVnb3JpZXMubGVuZ3RofTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXRlZ29yeS1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGNhdGVnb3J5LXJvdyBpcy1waW5uZWQgJHtzZWxlY3RlZENhdGVnb3J5SWQgPT09IEFMTF9DQVRFR09SSUVTID8gXCJpcy1zZWxlY3RlZFwiIDogXCJcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2VsZWN0Q2F0ZWdvcnkoQUxMX0NBVEVHT1JJRVMpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXRlZ29yeS1kcmFnLWhhbmRsZVwiIHN0eWxlPXt7IHZpc2liaWxpdHk6IFwiaGlkZGVuXCIgfX0+PERyYWdJY29uIC8+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2F0ZWdvcnktbWFpblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhdGVnb3J5LW5hbWVcIj5Ub2RvcyBvcyBwcm9kdXRvczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXRlZ29yeS1jb3VudC1waWxsXCI+e3Byb2R1Y3RzUXVlcnkuZGF0YT8ubGVuZ3RoID8/IDB9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzb3J0ZWRDYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnksIGluZGV4KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdGluZ0NhdGVnb3J5SWQgPT09IGNhdGVnb3J5LmlkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjYXRlZ29yeS5pZH0gc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogNiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgcGFkZGluZzogXCI0cHggOHB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2F0ZWdvcnlFZGl0TmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2F0ZWdvcnlFZGl0TmFtZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCwgbWluSGVpZ2h0OiAzNiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwibnVtZXJpY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2F0ZWdvcnlFZGl0T3JkZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENhdGVnb3J5RWRpdE9yZGVyKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiT3JkZW0gZGUgZXhpYmnDp8Ojb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogNTIsIG1pbkhlaWdodDogMzYgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e3VwZGF0ZUNhdGVnb3J5TXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NhdGVnb3J5RWRpdE5hbWUudHJpbSgpID09PSBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlQ2F0ZWdvcnlNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2FsdmFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIGljb25Pbmx5IGFyaWEtbGFiZWw9XCJDYW5jZWxhciBlZGnDp8Ojb1wiIG9uQ2xpY2s9e2NhbmNlbENhdGVnb3J5RWRpdH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDinJVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjYXRlZ29yeS5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY2F0ZWdvcnktcm93ICR7c2VsZWN0ZWRDYXRlZ29yeUlkID09PSBjYXRlZ29yeS5pZCA/IFwiaXMtc2VsZWN0ZWRcIiA6IFwiXCJ9ICR7IWNhdGVnb3J5LmlzQWN0aXZlID8gXCJpcy1pbmFjdGl2ZVwiIDogXCJcIn0gJHtkcmFnQ2F0ZWdvcnlJZCA9PT0gY2F0ZWdvcnkuaWQgPyBcImlzLWRyYWdnaW5nXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRyYWdnYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZWxlY3RDYXRlZ29yeShjYXRlZ29yeS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRHJhZ1N0YXJ0PXsoKSA9PiBzZXREcmFnQ2F0ZWdvcnlJZChjYXRlZ29yeS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRHJhZ0VuZD17KCkgPT4gc2V0RHJhZ0NhdGVnb3J5SWQobnVsbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRHJhZ092ZXI9eyhlKSA9PiBlLnByZXZlbnREZWZhdWx0KCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRHJvcD17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBoYW5kbGVDYXRlZ29yeURyb3AoY2F0ZWdvcnkpOyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2F0ZWdvcnktZHJhZy1oYW5kbGVcIiB0aXRsZT1cIkFycmFzdGUgcGFyYSByZW9yZGVuYXJcIiBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RHJhZ0ljb24gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXRlZ29yeS1vcmRlclwiPntTdHJpbmcoaW5kZXggKyAxKS5wYWRTdGFydCgyLCBcIjBcIil9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXRlZ29yeS1tYWluXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXRlZ29yeS1uYW1lXCI+e2NhdGVnb3J5Lm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2F0ZWdvcnktY291bnQtcGlsbFwiPntjYXRlZ29yeS5wcm9kdWN0Q291bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFjYXRlZ29yeS5pc0FjdGl2ZSAmJiA8c3BhbiBjbGFzc05hbWU9XCJjYXRlZ29yeS1pbmFjdGl2ZS10YWdcIj5JbmF0aXZhPC9zcGFuPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3dpdGNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtjYXRlZ29yeS5pc0FjdGl2ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB0b2dnbGVDYXRlZ29yeShjYXRlZ29yeSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17Y2F0ZWdvcnkuaXNBY3RpdmUgPyBgRGVzYXRpdmFyIGNhdGVnb3JpYSAke2NhdGVnb3J5Lm5hbWV9YCA6IGBBdGl2YXIgY2F0ZWdvcmlhICR7Y2F0ZWdvcnkubmFtZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbk9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BFZGl0YXIgY2F0ZWdvcmlhICR7Y2F0ZWdvcnkubmFtZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgc3RhcnRDYXRlZ29yeUVkaXQoY2F0ZWdvcnkpOyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDinI5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctbmV3LWNhdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm92YSBjYXRlZ29yaWHigKZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0NhdGVnb3J5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdDYXRlZ29yeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIgJiYgbmV3Q2F0ZWdvcnkudHJpbSgpICE9PSBcIlwiKSBjYXRlZ29yeU11dGF0aW9uLm11dGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb25Pbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ3JpYXIgY2F0ZWdvcmlhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtuZXdDYXRlZ29yeS50cmltKCkgPT09IFwiXCIgfHwgY2F0ZWdvcnlNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtjYXRlZ29yeU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNhdGVnb3J5TXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImNhdGFsb2ctaGludFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBcnJhc3RlIHBhcmEgcmVvcmRlbmFyLiBEZXNhdGl2YXIgdW1hIGNhdGVnb3JpYSBuw6NvIGFmZXRhIG9zIHByb2R1dG9zIGrDoSB2aW5jdWxhZG9zIGEgZWxhLlxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiAtLS0gQ29sdW5hIGRpcmVpdGE6IHByb2R1dG9zIGRhIGNhdGVnb3JpYSBzZWxlY2lvbmFkYSAtLS0gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctcGFuZWxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctdG9vbGJhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctc2VhcmNoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VhcmNoSWNvbiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgcHJvZHV0byBwb3Igbm9tZeKAplwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHsgc2V0U2VhcmNoKGUudGFyZ2V0LnZhbHVlKTsgc2V0UGFnZSgxKTsgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlZ21lbnRlZFwiIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJGaWx0cmFyIHBvciBzdGF0dXNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoW1wiYWxsXCIsIFwiYWN0aXZlXCIsIFwiaW5hY3RpdmVcIl0gYXMgU3RhdHVzRmlsdGVyW10pLm1hcCgocykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdGF0dXNGaWx0ZXIgPT09IHMgPyBcImlzLWFjdGl2ZVwiIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRTdGF0dXNGaWx0ZXIocyk7IHNldFBhZ2UoMSk7IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cyA9PT0gXCJhbGxcIiA/IFwiVG9kb3NcIiA6IHMgPT09IFwiYWN0aXZlXCIgPyBcIkF0aXZvc1wiIDogXCJJbmF0aXZvc1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdHNRdWVyeS5pc0xvYWRpbmcgJiYgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAxNiB9fT48U2tlbGV0b25MaXN0IHJvd3M9ezV9IHJvd0hlaWdodD17NjJ9IC8+PC9kaXY+fVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7IXByb2R1Y3RzUXVlcnkuaXNMb2FkaW5nICYmIGZpbHRlcmVkUHJvZHVjdHMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249XCLwn429XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTmVuaHVtIHByb2R1dG8gZW5jb250cmFkb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbj17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoLnRyaW0oKSAhPT0gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGBOZW5odW0gcmVzdWx0YWRvIHBhcmEgXCIke3NlYXJjaC50cmltKCl9XCIuIEFqdXN0ZSBhIGJ1c2NhIG91IG8gZmlsdHJvIGRlIHN0YXR1cy5gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogKHByb2R1Y3RzUXVlcnkuZGF0YT8ubGVuZ3RoID8/IDApID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiQWRpY2lvbmUgbyBwcmltZWlybyBpdGVtIGRvIGNhcmTDoXBpbyBwYXJhIGNvbWXDp2FyIGEgbW9udGFyIHBlZGlkb3MuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJOZW5odW0gcHJvZHV0byBuZXN0YSBjYXRlZ29yaWEgY29tIG8gZmlsdHJvIGF0dWFsLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb249e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgb25DbGljaz17KCkgPT4gb3BlbkVkaXRvcihcIm5ld1wiKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICsgTm92byBwcm9kdXRvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgeyFwcm9kdWN0c1F1ZXJ5LmlzTG9hZGluZyAmJiBmaWx0ZXJlZFByb2R1Y3RzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIiBzdHlsZT17eyBib3JkZXI6IFwibm9uZVwiLCBib3JkZXJSYWRpdXM6IDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BhZ2VJdGVtcy5tYXAoKHByb2R1Y3QpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B0aWNrZXQtcm93IHByb2R1Y3Qtcm93ICR7IXByb2R1Y3QuaXNBY3RpdmUgPyBcImlzLWluYWN0aXZlXCIgOiBcIlwifWB9IGtleT17cHJvZHVjdC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3Qtcm93LWdyaWRcIiBzdHlsZT17eyBmbGV4OiAxIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIG1pbldpZHRoOiAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdC5pbWFnZVVybCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e3Byb2R1Y3QuaW1hZ2VVcmx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtwcm9kdWN0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg9ezQ0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodD17NDR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz1cImxhenlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA0NCwgaGVpZ2h0OiA0NCwgb2JqZWN0Rml0OiBcImNvdmVyXCIsIGJvcmRlclJhZGl1czogOCwgYm9yZGVyOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lKVwiLCBmbGV4U2hyaW5rOiAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB3aWR0aDogNDQsIGhlaWdodDogNDQsIGJvcmRlclJhZGl1czogOCwgYmFja2dyb3VuZDogXCJ2YXIoLS1iZy1wcmVzcylcIiwgZGlzcGxheTogXCJncmlkXCIsIHBsYWNlSXRlbXM6IFwiY2VudGVyXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMS4xcmVtXCIsIGZsZXhTaHJpbms6IDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+NvVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiwgbWluV2lkdGg6IDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiA3LCB3aGl0ZVNwYWNlOiBcIm5vd3JhcFwiLCBvdmVyZmxvdzogXCJoaWRkZW5cIiwgdGV4dE92ZXJmbG93OiBcImVsbGlwc2lzXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Byb2R1Y3QubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IXByb2R1Y3QuaXNBY3RpdmUgJiYgPHNwYW4gY2xhc3NOYW1lPVwiY2F0ZWdvcnktaW5hY3RpdmUtdGFnXCI+SW5hdGl2bzwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCB3aGl0ZVNwYWNlOiBcIm5vd3JhcFwiLCBvdmVyZmxvdzogXCJoaWRkZW5cIiwgdGV4dE92ZXJmbG93OiBcImVsbGlwc2lzXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Byb2R1Y3QuY2F0ZWdvcnlOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0LmRlc2NyaXB0aW9uID8gYCDCtyAke3Byb2R1Y3QuZGVzY3JpcHRpb259YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tYW1iZXIpXCIsIHRleHRBbGlnbjogXCJyaWdodFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0QlJMKHByb2R1Y3Quc2FsZVByaWNlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHJvZHVjdC1zdG9jay1jZWxsXCI+e3N0b2NrQmFkZ2UocHJvZHVjdCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogOCwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBpY29uT25seSBhcmlhLWxhYmVsPXtgRWRpdGFyICR7cHJvZHVjdC5uYW1lfWB9IG9uQ2xpY2s9eygpID0+IG9wZW5FZGl0b3IocHJvZHVjdCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pyOXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3dpdGNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtwcm9kdWN0LmlzQWN0aXZlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHRvZ2dsZVByb2R1Y3QocHJvZHVjdCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17cHJvZHVjdC5pc0FjdGl2ZSA/IGBEZXNhdGl2YXIgJHtwcm9kdWN0Lm5hbWV9YCA6IGBBdGl2YXIgJHtwcm9kdWN0Lm5hbWV9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2F0YWxvZy1mb290ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTW9zdHJhbmRvIHtwYWdlU3RhcnQgKyAxfeKAk3tNYXRoLm1pbihwYWdlU3RhcnQgKyBQQUdFX1NJWkUsIGZpbHRlcmVkUHJvZHVjdHMubGVuZ3RoKX0gZGUge2ZpbHRlcmVkUHJvZHVjdHMubGVuZ3RofSBwcm9kdXRvc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2VyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGRpc2FibGVkPXtjdXJyZW50UGFnZSA8PSAxfSBvbkNsaWNrPXsoKSA9PiBzZXRQYWdlKGN1cnJlbnRQYWdlIC0gMSl9IGFyaWEtbGFiZWw9XCJQw6FnaW5hIGFudGVyaW9yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiB0b3RhbFBhZ2VzIH0sIChfLCBpKSA9PiBpICsgMSkubWFwKChuKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17biA9PT0gY3VycmVudFBhZ2UgPyBcImlzLWN1cnJlbnRcIiA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFnZShuKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9e2N1cnJlbnRQYWdlID49IHRvdGFsUGFnZXN9IG9uQ2xpY2s9eygpID0+IHNldFBhZ2UoY3VycmVudFBhZ2UgKyAxKX0gYXJpYS1sYWJlbD1cIlByw7N4aW1hIHDDoWdpbmFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtlZGl0aW5nICE9PSBudWxsICYmIChcclxuICAgICAgICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPXtlZGl0aW5nID09PSBcIm5ld1wiID8gXCJOb3ZvIHByb2R1dG9cIiA6IFwiRWRpdGFyIHByb2R1dG9cIn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0aW5nKG51bGwpfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHdpZGVcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTm9tZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBhbGlnbkl0ZW1zOiBcImVuZFwiIOKAlCBvIGxhYmVsIFwiQ2F0ZWdvcmlhXCIgcG9kZSBxdWVicmFyIGVtIDIgbGluaGFzIHBvciBjYXVzYVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkbyBsaW5rIFwiKyBub3ZhIGNhdGVnb3JpYVwiIGVtYnV0aWRvIG5lbGU7IGFsaW5oYW5kbyBwZWxvIHJvZGFww6kgZGEgbGluaGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9zIGRvaXMgY2FtcG9zIChzZWxlY3RzKSBmaWNhbSBzZW1wcmUgbmEgbWVzbWEgYWx0dXJhLCBtZXNtbyBxdWFuZG8gdW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWwgw6kgbWFpcyBhbHRvIHF1ZSBvIG91dHJvLiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGFsaWduSXRlbXM6IFwiZW5kXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDI0MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidWktcm93XCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCB3aWR0aDogXCIxMDAlXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDYXRlZ29yaWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshY3JlYXRpbmdDYXRlZ29yeSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3JlYXRpbmdDYXRlZ29yeSh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogXCJ0cmFuc3BhcmVudFwiLCBib3JkZXI6IFwibm9uZVwiLCBjb2xvcjogXCJ2YXIoLS1hbWJlcilcIiwgY3Vyc29yOiBcInBvaW50ZXJcIiwgZm9udFNpemU6IFwiMC44cmVtXCIsIHBhZGRpbmc6IDAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICsgbm92YSBjYXRlZ29yaWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhhMTF5KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjcmVhdGluZ0NhdGVnb3J5ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDYgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5hMTF5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWUgZGEgY2F0ZWdvcmlhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21vZGFsTmV3Q2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TW9kYWxOZXdDYXRlZ29yeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtb2RhbE5ld0NhdGVnb3J5LnRyaW0oKSAhPT0gXCJcIikgbW9kYWxDYXRlZ29yeU11dGF0aW9uLm11dGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChlLmtleSA9PT0gXCJFc2NhcGVcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENyZWF0aW5nQ2F0ZWdvcnkoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE1vZGFsTmV3Q2F0ZWdvcnkoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e21vZGFsQ2F0ZWdvcnlNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXttb2RhbE5ld0NhdGVnb3J5LnRyaW0oKSA9PT0gXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbW9kYWxDYXRlZ29yeU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3JpYXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb25Pbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDYW5jZWxhciBjcmlhw6fDo28gZGUgY2F0ZWdvcmlhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRDcmVhdGluZ0NhdGVnb3J5KGZhbHNlKTsgc2V0TW9kYWxOZXdDYXRlZ29yeShcIlwiKTsgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKclVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey4uLmExMXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uY2F0ZWdvcnlJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBjYXRlZ29yeUlkOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWNpb25lIGEgY2F0ZWdvcmlh4oCmPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhjYXRlZ29yaWVzUXVlcnkuZGF0YSA/PyBbXSkubWFwKChjKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjLmlkfSB2YWx1ZT17Yy5pZH0+e2MubmFtZX08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9GaWVsZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVW5pZGFkZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0udW5pdE9mTWVhc3VyZUlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHVuaXRPZk1lYXN1cmVJZDogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKHVuaXRPZk1lYXN1cmVMYWJlbCkubWFwKChbaWQsIGxhYmVsXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17aWR9IHZhbHVlPXtpZH0+e2xhYmVsfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RGaWVsZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlByZcOnbyBkZSB2ZW5kYSAoUiQpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5zYWxlUHJpY2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgc2FsZVByaWNlOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNjAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJDdXN0byAoUiQsIG9wY2lvbmFsKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uY29zdFByaWNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGNvc3RQcmljZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkRlc2NyacOnw6NvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgZGVzY3JpcHRpb246IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgYWxpZ25JdGVtczogXCJlbmRcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTYwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUHJlcGFybyAobWluLCBvcGNpb25hbClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnByZXBhcmF0aW9uVGltZU1pbnV0ZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgcHJlcGFyYXRpb25UaW1lTWludXRlczogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDEwLCBwYWRkaW5nQm90dG9tOiAxMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTd2l0Y2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtLmlzU3RvY2tDb250cm9sbGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsobmV4dCkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGlzU3RvY2tDb250cm9sbGVkOiBuZXh0IH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ29udHJvbGEgZXN0b3F1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+Q29udHJvbGEgZXN0b3F1ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmllbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmllbGQtbGFiZWxcIj5Gb3RvIGRvIHByb2R1dG8gKEpQRy9QTkcvV2ViUCwgYXTDqSAyIE1CKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS9qcGVnLGltYWdlL3BuZyxpbWFnZS93ZWJwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW1hZ2VGaWxlKGUudGFyZ2V0LmZpbGVzPy5bMF0gPz8gbnVsbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsoaW1hZ2VQcmV2aWV3VXJsICE9PSBudWxsIHx8IChlZGl0aW5nICE9PSBcIm5ld1wiICYmIGVkaXRpbmcgIT09IG51bGwgJiYgZWRpdGluZy5pbWFnZVVybCkpICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2ltYWdlUHJldmlld1VybCA/PyAoZWRpdGluZyBhcyBQcm9kdWN0TWFuYWdlbWVudFJlc3BvbnNlKS5pbWFnZVVybCF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiUHLDqXZpYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg9ezkwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodD17OTB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDkwLCBoZWlnaHQ6IDkwLCBvYmplY3RGaXQ6IFwiY292ZXJcIiwgYm9yZGVyUmFkaXVzOiAxMCwgYm9yZGVyOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lKVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZWRpdGluZyAhPT0gXCJuZXdcIiAmJiBlZGl0aW5nICE9PSBudWxsICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFByb2R1Y3RDb21wbGVtZW50TGlua1BhbmVsIHByb2R1Y3RJZD17ZWRpdGluZy5pZH0gLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCIgcm9sZT1cImFsZXJ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtLmNhdGVnb3J5SWQgPT09IFwiXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmaWVsZC1oaW50XCIgc3R5bGU9e3sgbWFyZ2luOiAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWNpb25lIHVtYSBjYXRlZ29yaWEgcGFyYSBoYWJpbGl0YXIgbyBzYWx2YXIuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17c2F2ZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Zvcm0ubmFtZS50cmltKCkgPT09IFwiXCIgfHwgZm9ybS5jYXRlZ29yeUlkID09PSBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzYXZlTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTYWx2YXJcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgPC9tYWluPlxyXG4gICAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvY2F0YWxvZy9Qcm9kdWN0c1BhZ2UudHN4In0=