import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/reservations/ReservationsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { useDialog } from "/src/ui/Dialog.tsx";
import { cancelReservation, confirmReservation, createReservation, getReservationsByBranch } from "/src/features/reservations/api.ts";
import { getTablesByBranch } from "/src/features/tables/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { ReservationStatus, TableStatus, reservationStatusLabel } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { Button } from "/src/ui/Button.tsx";
import { TextField, SelectField } from "/src/ui/Field.tsx";
import { useToast } from "/src/ui/Toast.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
function defaultRange() {
  const from = /* @__PURE__ */ new Date();
  from.setHours(0, 0, 0, 0);
  const to = new Date(from);
  to.setDate(to.getDate() + 14);
  return { from: from.toISOString(), to: to.toISOString() };
}
export function ReservationsPage() {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const toast = useToast();
  const { branchId } = useAuthStore();
  const [creating, setCreating] = useState(false);
  const [confirmingId, setConfirmingId] = useState(null);
  const [tableForConfirm, setTableForConfirm] = useState("");
  const [error, setError] = useState(null);
  const range = useMemo(defaultRange, []);
  const [form, setForm] = useState({
    customerName: "",
    customerPhone: "",
    partySize: 2,
    reservedFor: "",
    notes: ""
  });
  const reservationsQuery = useQuery({
    queryKey: ["reservations", branchId, range.from, range.to],
    queryFn: () => getReservationsByBranch(branchId, range.from, range.to)
  });
  const tablesQuery = useQuery({
    queryKey: ["tables", branchId],
    queryFn: () => getTablesByBranch(branchId)
  });
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["reservations"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const createMutation = useMutation({
    mutationFn: () => createReservation({
      branchId,
      customerName: form.customerName.trim(),
      customerPhone: form.customerPhone.trim() === "" ? null : form.customerPhone.trim(),
      partySize: form.partySize,
      reservedFor: new Date(form.reservedFor).toISOString(),
      notes: form.notes.trim() === "" ? null : form.notes.trim()
    }),
    onSuccess: () => {
      setError(null);
      setCreating(false);
      setForm({ customerName: "", customerPhone: "", partySize: 2, reservedFor: "", notes: "" });
      refresh();
      toast.success("Reserva criada.");
    },
    onError: onApiError
  });
  const confirmMutation = useMutation({
    mutationFn: (id) => confirmReservation(id, Number(tableForConfirm)),
    onSuccess: () => {
      setError(null);
      setConfirmingId(null);
      setTableForConfirm("");
      refresh();
      void queryClient.invalidateQueries({ queryKey: ["tables"] });
      toast.success("Reserva confirmada.");
    },
    onError: onApiError
  });
  const cancelMutation = useMutation({
    mutationFn: (id) => cancelReservation(id),
    onSuccess: () => {
      refresh();
      void queryClient.invalidateQueries({ queryKey: ["tables"] });
      toast.success("Reserva cancelada.");
    },
    onError: onApiError
  });
  const sorted = [...reservationsQuery.data ?? []].sort(
    (a, b) => new Date(a.reservedFor).getTime() - new Date(b.reservedFor).getTime()
  );
  const freeTables = (tablesQuery.data ?? []).filter((t) => t.tableStatusId === TableStatus.Livre);
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1e3, margin: "0 auto", position: "relative" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 6, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Reservas de mesa" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 128,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "próximos 14 dias" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 129,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 130,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "button", onClick: () => {
        setError(null);
        setCreating(true);
      }, children: "+ Nova reserva" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 131,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
      lineNumber: 127,
      columnNumber: 13
    }, this),
    reservationsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: reservationsQuery.error, what: "as reservas" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
      lineNumber: 136,
      columnNumber: 43
    }, this),
    error && !creating && confirmingId === null && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
      lineNumber: 137,
      columnNumber: 61
    }, this),
    reservationsQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 4, rowHeight: 80 }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
      lineNumber: 139,
      columnNumber: 45
    }, this),
    !reservationsQuery.isLoading && sorted.length === 0 && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: "📅",
        title: "Nenhuma reserva nos próximos 14 dias",
        description: "Crie uma reserva para reservar uma mesa com antecedência.",
        action: /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "button", onClick: () => {
          setError(null);
          setCreating(true);
        }, children: "+ Nova reserva" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 147,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 142,
        columnNumber: 7
      },
      this
    ),
    !reservationsQuery.isLoading && sorted.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "rise rise-1", style: { display: "grid", gap: 10, marginTop: 12 }, children: sorted.map(
      (r) => /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: [
          /* @__PURE__ */ jsxDEV("span", { children: r.customerName }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
            lineNumber: 159,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": "var(--busy)" }, children: reservationStatusLabel[r.reservationStatusId] }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
            lineNumber: 160,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 158,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: new Date(r.reservedFor).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
              lineNumber: 166,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
              r.partySize,
              " pessoas ",
              r.customerPhone ? `· ${r.customerPhone}` : ""
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
              lineNumber: 169,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
            lineNumber: 165,
            columnNumber: 29
          }, this),
          r.reservationStatusId === ReservationStatus.Pending && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: "btn-ghost",
                type: "button",
                style: { minHeight: 44, padding: "0 10px", fontSize: "0.85rem" },
                onClick: () => {
                  setError(null);
                  setConfirmingId(r.id);
                },
                children: "Confirmar"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
                lineNumber: 175,
                columnNumber: 37
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: "btn-danger",
                type: "button",
                style: { minHeight: 44, padding: "0 10px", fontSize: "0.85rem" },
                onClick: async () => {
                  if (await dialog.confirm({ title: "Cancelar reserva", message: `Cancelar a reserva de ${r.customerName}?`, confirmLabel: "Cancelar reserva", danger: true }))
                    cancelMutation.mutate(r.id);
                },
                children: "Cancelar"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
                lineNumber: 183,
                columnNumber: 37
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
            lineNumber: 174,
            columnNumber: 13
          }, this),
          r.reservationStatusId === ReservationStatus.Confirmed && /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "btn-danger",
              type: "button",
              style: { minHeight: 44, padding: "0 10px", fontSize: "0.85rem" },
              onClick: async () => {
                if (await dialog.confirm({ title: "Cancelar reserva", message: `Cancelar a reserva de ${r.customerName}?`, confirmLabel: "Cancelar reserva", danger: true }))
                  cancelMutation.mutate(r.id);
              },
              children: "Cancelar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
              lineNumber: 197,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 164,
          columnNumber: 25
        }, this)
      ] }, r.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 157,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
      lineNumber: 155,
      columnNumber: 7
    }, this),
    creating && /* @__PURE__ */ jsxDEV(Modal, { title: "Nova reserva", onClose: () => setCreating(false), variant: "center", children: [
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Nome do cliente",
          type: "text",
          value: form.customerName,
          onChange: (e) => setForm((f) => ({ ...f, customerName: e.target.value })),
          autoFocus: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 217,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Telefone",
            type: "text",
            value: form.customerPhone,
            onChange: (e) => setForm((f) => ({ ...f, customerPhone: e.target.value }))
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
            lineNumber: 227,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 226,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 100 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Pessoas",
            type: "number",
            min: 1,
            value: form.partySize,
            onChange: (e) => setForm((f) => ({ ...f, partySize: Number(e.target.value) }))
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
            lineNumber: 235,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 234,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 225,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Data e hora",
          type: "datetime-local",
          value: form.reservedFor,
          onChange: (e) => setForm((f) => ({ ...f, reservedFor: e.target.value }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 245,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Observações",
          type: "text",
          value: form.notes,
          onChange: (e) => setForm((f) => ({ ...f, notes: e.target.value }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 252,
          columnNumber: 21
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 259,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          loading: createMutation.isPending,
          disabled: form.customerName.trim() === "" || form.reservedFor === "",
          onClick: () => createMutation.mutate(),
          children: "Criar reserva"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 261,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
      lineNumber: 216,
      columnNumber: 7
    }, this),
    confirmingId !== null && /* @__PURE__ */ jsxDEV(Modal, { title: "Confirmar reserva — escolher mesa", onClose: () => setConfirmingId(null), variant: "center", children: [
      /* @__PURE__ */ jsxDEV(SelectField, { label: "Mesa livre", value: tableForConfirm, onChange: (e) => setTableForConfirm(e.target.value), autoFocus: true, children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione…" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 276,
          columnNumber: 25
        }, this),
        freeTables.map(
          (t) => /* @__PURE__ */ jsxDEV("option", { value: t.id, children: [
            "Mesa ",
            t.number
          ] }, t.id, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
            lineNumber: 278,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 275,
        columnNumber: 21
      }, this),
      freeTables.length === 0 && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "Nenhuma mesa livre no momento." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 282,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
        lineNumber: 284,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          loading: confirmMutation.isPending,
          disabled: tableForConfirm === "",
          onClick: () => confirmMutation.mutate(confirmingId),
          children: "Confirmar e reservar mesa"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
          lineNumber: 285,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
      lineNumber: 274,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx",
    lineNumber: 126,
    columnNumber: 5
  }, this);
}
_s(ReservationsPage, "lt4m5xfoIz4LvzxJ/5gmg9rL0wU=", false, function() {
  return [useQueryClient, useDialog, useToast, useAuthStore, useQuery, useQuery, useMutation, useMutation, useMutation];
});
_c = ReservationsPage;
var _c;
$RefreshReg$(_c, "ReservationsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/reservations/ReservationsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEdnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1R2YsU0FBU0EsU0FBU0MsZ0JBQWdCO0FBQ25DLFNBQVNDLGFBQWFDLFVBQVVDLHNCQUFzQjtBQUN0RCxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsbUJBQW1CQyxvQkFBb0JDLG1CQUFtQkMsK0JBQStCO0FBQ2xHLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG1CQUFtQkMsYUFBYUMsOEJBQThCO0FBQ3ZFLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsV0FBV0MsbUJBQW1CO0FBQ3ZDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBRTdCLFNBQVNDLGVBQWU7QUFDcEIsUUFBTUMsT0FBTyxvQkFBSUMsS0FBSztBQUN0QkQsT0FBS0UsU0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQ3hCLFFBQU1DLEtBQUssSUFBSUYsS0FBS0QsSUFBSTtBQUN4QkcsS0FBR0MsUUFBUUQsR0FBR0UsUUFBUSxJQUFJLEVBQUU7QUFDNUIsU0FBTyxFQUFFTCxNQUFNQSxLQUFLTSxZQUFZLEdBQUdILElBQUlBLEdBQUdHLFlBQVksRUFBRTtBQUM1RDtBQUVPLGdCQUFTQyxtQkFBbUI7QUFBQUMsS0FBQTtBQUMvQixRQUFNQyxjQUFjOUIsZUFBZTtBQUNuQyxRQUFNK0IsU0FBUzlCLFVBQVU7QUFDekIsUUFBTStCLFFBQVFmLFNBQVM7QUFDdkIsUUFBTSxFQUFFZ0IsU0FBUyxJQUFJMUIsYUFBYTtBQUNsQyxRQUFNLENBQUMyQixVQUFVQyxXQUFXLElBQUl0QyxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDdUMsY0FBY0MsZUFBZSxJQUFJeEMsU0FBd0IsSUFBSTtBQUNwRSxRQUFNLENBQUN5QyxpQkFBaUJDLGtCQUFrQixJQUFJMUMsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQzJDLE9BQU9DLFFBQVEsSUFBSTVDLFNBQXdCLElBQUk7QUFDdEQsUUFBTTZDLFFBQVE5QyxRQUFRd0IsY0FBYyxFQUFFO0FBRXRDLFFBQU0sQ0FBQ3VCLE1BQU1DLE9BQU8sSUFBSS9DLFNBQVM7QUFBQSxJQUM3QmdELGNBQWM7QUFBQSxJQUNkQyxlQUFlO0FBQUEsSUFDZkMsV0FBVztBQUFBLElBQ1hDLGFBQWE7QUFBQSxJQUNiQyxPQUFPO0FBQUEsRUFDWCxDQUFDO0FBRUQsUUFBTUMsb0JBQW9CbkQsU0FBUztBQUFBLElBQy9Cb0QsVUFBVSxDQUFDLGdCQUFnQmxCLFVBQVVTLE1BQU1yQixNQUFNcUIsTUFBTWxCLEVBQUU7QUFBQSxJQUN6RDRCLFNBQVNBLE1BQU0vQyx3QkFBd0I0QixVQUFVUyxNQUFNckIsTUFBTXFCLE1BQU1sQixFQUFFO0FBQUEsRUFDekUsQ0FBQztBQUVELFFBQU02QixjQUFjdEQsU0FBUztBQUFBLElBQ3pCb0QsVUFBVSxDQUFDLFVBQVVsQixRQUFRO0FBQUEsSUFDN0JtQixTQUFTQSxNQUFNOUMsa0JBQWtCMkIsUUFBUTtBQUFBLEVBQzdDLENBQUM7QUFFRCxRQUFNcUIsVUFBVUEsTUFBTSxLQUFLeEIsWUFBWXlCLGtCQUFrQixFQUFFSixVQUFVLENBQUMsY0FBYyxFQUFFLENBQUM7QUFDdkYsUUFBTUssYUFBYUEsQ0FBQ0MsTUFBZWhCLFNBQVNnQixhQUFhakQsV0FBV2lELEVBQUVDLFVBQVUsa0JBQWtCO0FBRWxHLFFBQU1DLGlCQUFpQjdELFlBQVk7QUFBQSxJQUMvQjhELFlBQVlBLE1BQ1J4RCxrQkFBa0I7QUFBQSxNQUNkNkI7QUFBQUEsTUFDQVksY0FBY0YsS0FBS0UsYUFBYWdCLEtBQUs7QUFBQSxNQUNyQ2YsZUFBZUgsS0FBS0csY0FBY2UsS0FBSyxNQUFNLEtBQUssT0FBT2xCLEtBQUtHLGNBQWNlLEtBQUs7QUFBQSxNQUNqRmQsV0FBV0osS0FBS0k7QUFBQUEsTUFDaEJDLGFBQWEsSUFBSTFCLEtBQUtxQixLQUFLSyxXQUFXLEVBQUVyQixZQUFZO0FBQUEsTUFDcERzQixPQUFPTixLQUFLTSxNQUFNWSxLQUFLLE1BQU0sS0FBSyxPQUFPbEIsS0FBS00sTUFBTVksS0FBSztBQUFBLElBQzdELENBQUM7QUFBQSxJQUNMQyxXQUFXQSxNQUFNO0FBQ2JyQixlQUFTLElBQUk7QUFDYk4sa0JBQVksS0FBSztBQUNqQlMsY0FBUSxFQUFFQyxjQUFjLElBQUlDLGVBQWUsSUFBSUMsV0FBVyxHQUFHQyxhQUFhLElBQUlDLE9BQU8sR0FBRyxDQUFDO0FBQ3pGSyxjQUFRO0FBQ1J0QixZQUFNK0IsUUFBUSxpQkFBaUI7QUFBQSxJQUNuQztBQUFBLElBQ0FDLFNBQVNSO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1TLGtCQUFrQm5FLFlBQVk7QUFBQSxJQUNoQzhELFlBQVlBLENBQUNNLE9BQWUvRCxtQkFBbUIrRCxJQUFJQyxPQUFPN0IsZUFBZSxDQUFDO0FBQUEsSUFDMUV3QixXQUFXQSxNQUFNO0FBQ2JyQixlQUFTLElBQUk7QUFDYkosc0JBQWdCLElBQUk7QUFDcEJFLHlCQUFtQixFQUFFO0FBQ3JCZSxjQUFRO0FBQ1IsV0FBS3hCLFlBQVl5QixrQkFBa0IsRUFBRUosVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzNEbkIsWUFBTStCLFFBQVEscUJBQXFCO0FBQUEsSUFDdkM7QUFBQSxJQUNBQyxTQUFTUjtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNWSxpQkFBaUJ0RSxZQUFZO0FBQUEsSUFDL0I4RCxZQUFZQSxDQUFDTSxPQUFlaEUsa0JBQWtCZ0UsRUFBRTtBQUFBLElBQ2hESixXQUFXQSxNQUFNO0FBQ2JSLGNBQVE7QUFDUixXQUFLeEIsWUFBWXlCLGtCQUFrQixFQUFFSixVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDM0RuQixZQUFNK0IsUUFBUSxvQkFBb0I7QUFBQSxJQUN0QztBQUFBLElBQ0FDLFNBQVNSO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1hLFNBQVMsQ0FBQyxHQUFJbkIsa0JBQWtCb0IsUUFBUSxFQUFHLEVBQUVDO0FBQUFBLElBQy9DLENBQUNDLEdBQUdDLE1BQU0sSUFBSW5ELEtBQUtrRCxFQUFFeEIsV0FBVyxFQUFFMEIsUUFBUSxJQUFJLElBQUlwRCxLQUFLbUQsRUFBRXpCLFdBQVcsRUFBRTBCLFFBQVE7QUFBQSxFQUNsRjtBQUVBLFFBQU1DLGNBQWN0QixZQUFZaUIsUUFBUSxJQUFJTSxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLGtCQUFrQnBFLFlBQVlxRSxLQUFLO0FBRS9GLFNBQ0ksdUJBQUMsVUFBSyxPQUFPLEVBQUVDLFNBQVMsSUFBSUMsVUFBVSxLQUFNQyxRQUFRLFVBQVVDLFVBQVUsV0FBVyxHQUMvRTtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxZQUFZLFlBQVlDLEtBQUssSUFBSUMsY0FBYyxHQUFHQyxVQUFVLE9BQU8sR0FDL0c7QUFBQSw2QkFBQyxRQUFHLFdBQVUsV0FBVSxPQUFPLEVBQUVDLFVBQVUsU0FBUyxHQUFHLGdDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFO0FBQUEsTUFDdkUsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sb0JBQW9CRCxVQUFVLFNBQVMsR0FBRyxnQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRjtBQUFBLE1BQ2hGLHVCQUFDLFVBQUssT0FBTyxFQUFFRSxNQUFNLEVBQUUsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLFlBQU8sV0FBVSxlQUFjLE1BQUssVUFBUyxTQUFTLE1BQU07QUFBRWxELGlCQUFTLElBQUk7QUFBR04sb0JBQVksSUFBSTtBQUFBLE1BQUcsR0FBRyw4QkFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVDZSxrQkFBa0IwQyxXQUFXLHVCQUFDLGNBQVcsT0FBTzFDLGtCQUFrQlYsT0FBTyxNQUFLLGlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThEO0FBQUEsSUFDM0ZBLFNBQVMsQ0FBQ04sWUFBWUUsaUJBQWlCLFFBQVEsdUJBQUMsT0FBRSxXQUFVLGNBQWNJLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFFaEZVLGtCQUFrQjJDLGFBQWEsdUJBQUMsZ0JBQWEsTUFBTSxHQUFHLFdBQVcsTUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLElBRXBFLENBQUMzQyxrQkFBa0IyQyxhQUFheEIsT0FBT3lCLFdBQVcsS0FDL0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQUs7QUFBQSxRQUNMLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLFFBQ0ksdUJBQUMsWUFBTyxXQUFVLGVBQWMsTUFBSyxVQUFTLFNBQVMsTUFBTTtBQUFFckQsbUJBQVMsSUFBSTtBQUFHTixzQkFBWSxJQUFJO0FBQUEsUUFBRyxHQUFHLDhCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBLE1BUFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUs7QUFBQSxJQUlSLENBQUNlLGtCQUFrQjJDLGFBQWF4QixPQUFPeUIsU0FBUyxLQUNqRCx1QkFBQyxTQUFJLFdBQVUsZUFBYyxPQUFPLEVBQUVWLFNBQVMsUUFBUUUsS0FBSyxJQUFJUyxXQUFXLEdBQUcsR0FDekUxQixpQkFBTzJCO0FBQUFBLE1BQUksQ0FBQ0MsTUFDVCx1QkFBQyxTQUFlLFdBQVUsVUFDdEI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZUFDWDtBQUFBLGlDQUFDLFVBQU1BLFlBQUVwRCxnQkFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQjtBQUFBLFVBQ3RCLHVCQUFDLFVBQUssV0FBVSxRQUFPLE9BQU8sRUFBRSxTQUFTLGNBQWMsR0FDbERsQyxpQ0FBdUJzRixFQUFFQyxtQkFBbUIsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUViLFlBQVksU0FBUyxHQUN0RDtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFRCxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUNsQztBQUFBLG1DQUFDLFVBQUssV0FBVSxZQUNYLGNBQUloRSxLQUFLMkUsRUFBRWpELFdBQVcsRUFBRW1ELGVBQWUsU0FBUyxFQUFFQyxXQUFXLFNBQVNDLFdBQVcsUUFBUSxDQUFDLEtBRC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFWixVQUFVLFVBQVVDLE9BQU8sbUJBQW1CLEdBQ3hETztBQUFBQSxnQkFBRWxEO0FBQUFBLGNBQVU7QUFBQSxjQUFVa0QsRUFBRW5ELGdCQUFnQixLQUFLbUQsRUFBRW5ELGFBQWEsS0FBSztBQUFBLGlCQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQ21ELEVBQUVDLHdCQUF3QnpGLGtCQUFrQjZGLFdBQ3pDLHVCQUFDLFNBQUksT0FBTyxFQUFFbEIsU0FBUyxRQUFRRSxLQUFLLEVBQUUsR0FDbEM7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBQ0wsT0FBTyxFQUFFaUIsV0FBVyxJQUFJdkIsU0FBUyxVQUFVUyxVQUFVLFVBQVU7QUFBQSxnQkFDL0QsU0FBUyxNQUFNO0FBQUVoRCwyQkFBUyxJQUFJO0FBQUdKLGtDQUFnQjRELEVBQUUvQixFQUFFO0FBQUEsZ0JBQUc7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FKOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxPQUFPLEVBQUVxQyxXQUFXLElBQUl2QixTQUFTLFVBQVVTLFVBQVUsVUFBVTtBQUFBLGdCQUMvRCxTQUFTLFlBQVk7QUFDakIsc0JBQUksTUFBTTFELE9BQU95RSxRQUFRLEVBQUVDLE9BQU8sb0JBQW9CL0MsU0FBUyx5QkFBeUJ1QyxFQUFFcEQsWUFBWSxLQUFLNkQsY0FBYyxvQkFBb0JDLFFBQVEsS0FBSyxDQUFDO0FBQ3ZKdkMsbUNBQWV3QyxPQUFPWCxFQUFFL0IsRUFBRTtBQUFBLGdCQUNsQztBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUVIK0IsRUFBRUMsd0JBQXdCekYsa0JBQWtCb0csYUFDekM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLE9BQU8sRUFBRU4sV0FBVyxJQUFJdkIsU0FBUyxVQUFVUyxVQUFVLFVBQVU7QUFBQSxjQUMvRCxTQUFTLFlBQVk7QUFDakIsb0JBQUksTUFBTTFELE9BQU95RSxRQUFRLEVBQUVDLE9BQU8sb0JBQW9CL0MsU0FBUyx5QkFBeUJ1QyxFQUFFcEQsWUFBWSxLQUFLNkQsY0FBYyxvQkFBb0JDLFFBQVEsS0FBSyxDQUFDO0FBQ3ZKdkMsaUNBQWV3QyxPQUFPWCxFQUFFL0IsRUFBRTtBQUFBLGNBQ2xDO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFQTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBM0NSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2Q0E7QUFBQSxXQXBETStCLEVBQUUvQixJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxREE7QUFBQSxJQUNILEtBeERMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5REE7QUFBQSxJQUdDaEMsWUFDRyx1QkFBQyxTQUFNLE9BQU0sZ0JBQWUsU0FBUyxNQUFNQyxZQUFZLEtBQUssR0FBRyxTQUFRLFVBQ25FO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE9BQU07QUFBQSxVQUNOLE1BQUs7QUFBQSxVQUNMLE9BQU9RLEtBQUtFO0FBQUFBLFVBQ1osVUFBVSxDQUFDWSxNQUFNYixRQUFRLENBQUNrRSxPQUFPLEVBQUUsR0FBR0EsR0FBR2pFLGNBQWNZLEVBQUVzRCxPQUFPQyxNQUFNLEVBQUU7QUFBQSxVQUN4RSxXQUFTO0FBQUE7QUFBQSxRQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUthO0FBQUEsTUFHYix1QkFBQyxTQUFJLFdBQVUsc0JBQ1g7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRXJCLE1BQU0sR0FBR3NCLFVBQVUsSUFBSSxHQUNqQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csT0FBTTtBQUFBLFlBQ04sTUFBSztBQUFBLFlBQ0wsT0FBT3RFLEtBQUtHO0FBQUFBLFlBQ1osVUFBVSxDQUFDVyxNQUFNYixRQUFRLENBQUNrRSxPQUFPLEVBQUUsR0FBR0EsR0FBR2hFLGVBQWVXLEVBQUVzRCxPQUFPQyxNQUFNLEVBQUU7QUFBQTtBQUFBLFVBSjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUkrRSxLQUxuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFckIsTUFBTSxHQUFHc0IsVUFBVSxJQUFJLEdBQ2pDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxPQUFNO0FBQUEsWUFDTixNQUFLO0FBQUEsWUFDTCxLQUFLO0FBQUEsWUFDTCxPQUFPdEUsS0FBS0k7QUFBQUEsWUFDWixVQUFVLENBQUNVLE1BQU1iLFFBQVEsQ0FBQ2tFLE9BQU8sRUFBRSxHQUFHQSxHQUFHL0QsV0FBV29CLE9BQU9WLEVBQUVzRCxPQUFPQyxLQUFLLEVBQUUsRUFBRTtBQUFBO0FBQUEsVUFMakY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS21GLEtBTnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxPQUFNO0FBQUEsVUFDTixNQUFLO0FBQUEsVUFDTCxPQUFPckUsS0FBS0s7QUFBQUEsVUFDWixVQUFVLENBQUNTLE1BQU1iLFFBQVEsQ0FBQ2tFLE9BQU8sRUFBRSxHQUFHQSxHQUFHOUQsYUFBYVMsRUFBRXNELE9BQU9DLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFKM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSTZFO0FBQUEsTUFHN0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE9BQU07QUFBQSxVQUNOLE1BQUs7QUFBQSxVQUNMLE9BQU9yRSxLQUFLTTtBQUFBQSxVQUNaLFVBQVUsQ0FBQ1EsTUFBTWIsUUFBUSxDQUFDa0UsT0FBTyxFQUFFLEdBQUdBLEdBQUc3RCxPQUFPUSxFQUFFc0QsT0FBT0MsTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUpyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJdUU7QUFBQSxNQUd0RXhFLFNBQVMsdUJBQUMsT0FBRSxXQUFVLGNBQWNBLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFFM0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFNBQVE7QUFBQSxVQUNSO0FBQUEsVUFDQSxTQUFTbUIsZUFBZXVEO0FBQUFBLFVBQ3hCLFVBQVV2RSxLQUFLRSxhQUFhZ0IsS0FBSyxNQUFNLE1BQU1sQixLQUFLSyxnQkFBZ0I7QUFBQSxVQUNsRSxTQUFTLE1BQU1XLGVBQWVpRCxPQUFPO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFMM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxTQXJESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0RBO0FBQUEsSUFHSHhFLGlCQUFpQixRQUNkLHVCQUFDLFNBQU0sT0FBTSxxQ0FBb0MsU0FBUyxNQUFNQyxnQkFBZ0IsSUFBSSxHQUFHLFNBQVEsVUFDM0Y7QUFBQSw2QkFBQyxlQUFZLE9BQU0sY0FBYSxPQUFPQyxpQkFBaUIsVUFBVSxDQUFDbUIsTUFBTWxCLG1CQUFtQmtCLEVBQUVzRCxPQUFPQyxLQUFLLEdBQUcsV0FBUyxNQUNsSDtBQUFBLCtCQUFDLFlBQU8sT0FBTSxJQUFHLDBCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFDMUJyQyxXQUFXcUI7QUFBQUEsVUFBSSxDQUFDbkIsTUFDYix1QkFBQyxZQUFrQixPQUFPQSxFQUFFWCxJQUFJO0FBQUE7QUFBQSxZQUFNVyxFQUFFc0M7QUFBQUEsZUFBM0J0QyxFQUFFWCxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsUUFDbEQ7QUFBQSxXQUpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0NTLFdBQVdtQixXQUFXLEtBQ25CLHVCQUFDLE9BQUUsT0FBTyxFQUFFSixPQUFPLG9CQUFvQkQsVUFBVSxVQUFVLEdBQUcsOENBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEY7QUFBQSxNQUUvRmpELFNBQVMsdUJBQUMsT0FBRSxXQUFVLGNBQWNBLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDM0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFNBQVE7QUFBQSxVQUNSO0FBQUEsVUFDQSxTQUFTeUIsZ0JBQWdCaUQ7QUFBQUEsVUFDekIsVUFBVTVFLG9CQUFvQjtBQUFBLFVBQzlCLFNBQVMsTUFBTTJCLGdCQUFnQjJDLE9BQU94RSxZQUFZO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFMeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxTQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsT0F4S1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBLQTtBQUVSO0FBQUNQLEdBOVBlRCxrQkFBZ0I7QUFBQSxVQUNSNUIsZ0JBQ0xDLFdBQ0RnQixVQUNPVixjQWVLUixVQUtOQSxVQVFHRCxhQW9CQ0EsYUFhREEsV0FBVztBQUFBO0FBQUEsS0FqRXRCOEI7QUFBZ0IsSUFBQXdGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsInVzZURpYWxvZyIsImNhbmNlbFJlc2VydmF0aW9uIiwiY29uZmlybVJlc2VydmF0aW9uIiwiY3JlYXRlUmVzZXJ2YXRpb24iLCJnZXRSZXNlcnZhdGlvbnNCeUJyYW5jaCIsImdldFRhYmxlc0J5QnJhbmNoIiwidXNlQXV0aFN0b3JlIiwiQXBpRXJyb3IiLCJSZXNlcnZhdGlvblN0YXR1cyIsIlRhYmxlU3RhdHVzIiwicmVzZXJ2YXRpb25TdGF0dXNMYWJlbCIsIlF1ZXJ5RXJyb3IiLCJNb2RhbCIsIkJ1dHRvbiIsIlRleHRGaWVsZCIsIlNlbGVjdEZpZWxkIiwidXNlVG9hc3QiLCJFbXB0eVN0YXRlIiwiU2tlbGV0b25MaXN0IiwiZGVmYXVsdFJhbmdlIiwiZnJvbSIsIkRhdGUiLCJzZXRIb3VycyIsInRvIiwic2V0RGF0ZSIsImdldERhdGUiLCJ0b0lTT1N0cmluZyIsIlJlc2VydmF0aW9uc1BhZ2UiLCJfcyIsInF1ZXJ5Q2xpZW50IiwiZGlhbG9nIiwidG9hc3QiLCJicmFuY2hJZCIsImNyZWF0aW5nIiwic2V0Q3JlYXRpbmciLCJjb25maXJtaW5nSWQiLCJzZXRDb25maXJtaW5nSWQiLCJ0YWJsZUZvckNvbmZpcm0iLCJzZXRUYWJsZUZvckNvbmZpcm0iLCJlcnJvciIsInNldEVycm9yIiwicmFuZ2UiLCJmb3JtIiwic2V0Rm9ybSIsImN1c3RvbWVyTmFtZSIsImN1c3RvbWVyUGhvbmUiLCJwYXJ0eVNpemUiLCJyZXNlcnZlZEZvciIsIm5vdGVzIiwicmVzZXJ2YXRpb25zUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJ0YWJsZXNRdWVyeSIsInJlZnJlc2giLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uQXBpRXJyb3IiLCJlIiwibWVzc2FnZSIsImNyZWF0ZU11dGF0aW9uIiwibXV0YXRpb25GbiIsInRyaW0iLCJvblN1Y2Nlc3MiLCJzdWNjZXNzIiwib25FcnJvciIsImNvbmZpcm1NdXRhdGlvbiIsImlkIiwiTnVtYmVyIiwiY2FuY2VsTXV0YXRpb24iLCJzb3J0ZWQiLCJkYXRhIiwic29ydCIsImEiLCJiIiwiZ2V0VGltZSIsImZyZWVUYWJsZXMiLCJmaWx0ZXIiLCJ0IiwidGFibGVTdGF0dXNJZCIsIkxpdnJlIiwicGFkZGluZyIsIm1heFdpZHRoIiwibWFyZ2luIiwicG9zaXRpb24iLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsIm1hcmdpbkJvdHRvbSIsImZsZXhXcmFwIiwiZm9udFNpemUiLCJjb2xvciIsImZsZXgiLCJpc0Vycm9yIiwiaXNMb2FkaW5nIiwibGVuZ3RoIiwibWFyZ2luVG9wIiwibWFwIiwiciIsInJlc2VydmF0aW9uU3RhdHVzSWQiLCJ0b0xvY2FsZVN0cmluZyIsImRhdGVTdHlsZSIsInRpbWVTdHlsZSIsIlBlbmRpbmciLCJtaW5IZWlnaHQiLCJjb25maXJtIiwidGl0bGUiLCJjb25maXJtTGFiZWwiLCJkYW5nZXIiLCJtdXRhdGUiLCJDb25maXJtZWQiLCJmIiwidGFyZ2V0IiwidmFsdWUiLCJtaW5XaWR0aCIsImlzUGVuZGluZyIsIm51bWJlciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlc2VydmF0aW9uc1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IHVzZURpYWxvZyB9IGZyb20gXCIuLi8uLi91aS9EaWFsb2dcIjtcclxuaW1wb3J0IHsgY2FuY2VsUmVzZXJ2YXRpb24sIGNvbmZpcm1SZXNlcnZhdGlvbiwgY3JlYXRlUmVzZXJ2YXRpb24sIGdldFJlc2VydmF0aW9uc0J5QnJhbmNoIH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IGdldFRhYmxlc0J5QnJhbmNoIH0gZnJvbSBcIi4uL3RhYmxlcy9hcGlcIjtcclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tIFwiLi4vLi4vbGliL2FwaUNsaWVudFwiO1xyXG5pbXBvcnQgeyBSZXNlcnZhdGlvblN0YXR1cywgVGFibGVTdGF0dXMsIHJlc2VydmF0aW9uU3RhdHVzTGFiZWwgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcbmltcG9ydCB7IE1vZGFsIH0gZnJvbSBcIi4uLy4uL3VpL01vZGFsXCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCIuLi8uLi91aS9CdXR0b25cIjtcclxuaW1wb3J0IHsgVGV4dEZpZWxkLCBTZWxlY3RGaWVsZCB9IGZyb20gXCIuLi8uLi91aS9GaWVsZFwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi8uLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSBcIi4uLy4uL3VpL0VtcHR5U3RhdGVcIjtcclxuaW1wb3J0IHsgU2tlbGV0b25MaXN0IH0gZnJvbSBcIi4uLy4uL3VpL1NrZWxldG9uXCI7XHJcblxyXG5mdW5jdGlvbiBkZWZhdWx0UmFuZ2UoKSB7XHJcbiAgICBjb25zdCBmcm9tID0gbmV3IERhdGUoKTtcclxuICAgIGZyb20uc2V0SG91cnMoMCwgMCwgMCwgMCk7XHJcbiAgICBjb25zdCB0byA9IG5ldyBEYXRlKGZyb20pO1xyXG4gICAgdG8uc2V0RGF0ZSh0by5nZXREYXRlKCkgKyAxNCk7XHJcbiAgICByZXR1cm4geyBmcm9tOiBmcm9tLnRvSVNPU3RyaW5nKCksIHRvOiB0by50b0lTT1N0cmluZygpIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBSZXNlcnZhdGlvbnNQYWdlKCkge1xyXG4gICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gICAgY29uc3QgZGlhbG9nID0gdXNlRGlhbG9nKCk7XHJcbiAgICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICAgIGNvbnN0IFtjcmVhdGluZywgc2V0Q3JlYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2NvbmZpcm1pbmdJZCwgc2V0Q29uZmlybWluZ0lkXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgW3RhYmxlRm9yQ29uZmlybSwgc2V0VGFibGVGb3JDb25maXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IHJhbmdlID0gdXNlTWVtbyhkZWZhdWx0UmFuZ2UsIFtdKTtcclxuXHJcbiAgICBjb25zdCBbZm9ybSwgc2V0Rm9ybV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgY3VzdG9tZXJOYW1lOiBcIlwiLFxyXG4gICAgICAgIGN1c3RvbWVyUGhvbmU6IFwiXCIsXHJcbiAgICAgICAgcGFydHlTaXplOiAyLFxyXG4gICAgICAgIHJlc2VydmVkRm9yOiBcIlwiLFxyXG4gICAgICAgIG5vdGVzOiBcIlwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgcmVzZXJ2YXRpb25zUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcInJlc2VydmF0aW9uc1wiLCBicmFuY2hJZCwgcmFuZ2UuZnJvbSwgcmFuZ2UudG9dLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldFJlc2VydmF0aW9uc0J5QnJhbmNoKGJyYW5jaElkLCByYW5nZS5mcm9tLCByYW5nZS50byksXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCB0YWJsZXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgICAgICBxdWVyeUtleTogW1widGFibGVzXCIsIGJyYW5jaElkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRUYWJsZXNCeUJyYW5jaChicmFuY2hJZCksXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCByZWZyZXNoID0gKCkgPT4gdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJyZXNlcnZhdGlvbnNcIl0gfSk7XHJcbiAgICBjb25zdCBvbkFwaUVycm9yID0gKGU6IHVua25vd24pID0+IHNldEVycm9yKGUgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGUubWVzc2FnZSA6IFwiT3BlcmHDp8OjbyBmYWxob3UuXCIpO1xyXG5cclxuICAgIGNvbnN0IGNyZWF0ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgICAgICAgIGNyZWF0ZVJlc2VydmF0aW9uKHtcclxuICAgICAgICAgICAgICAgIGJyYW5jaElkLFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXJOYW1lOiBmb3JtLmN1c3RvbWVyTmFtZS50cmltKCksXHJcbiAgICAgICAgICAgICAgICBjdXN0b21lclBob25lOiBmb3JtLmN1c3RvbWVyUGhvbmUudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IGZvcm0uY3VzdG9tZXJQaG9uZS50cmltKCksXHJcbiAgICAgICAgICAgICAgICBwYXJ0eVNpemU6IGZvcm0ucGFydHlTaXplLFxyXG4gICAgICAgICAgICAgICAgcmVzZXJ2ZWRGb3I6IG5ldyBEYXRlKGZvcm0ucmVzZXJ2ZWRGb3IpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICAgICAgICBub3RlczogZm9ybS5ub3Rlcy50cmltKCkgPT09IFwiXCIgPyBudWxsIDogZm9ybS5ub3Rlcy50cmltKCksXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICAgICAgc2V0Q3JlYXRpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRGb3JtKHsgY3VzdG9tZXJOYW1lOiBcIlwiLCBjdXN0b21lclBob25lOiBcIlwiLCBwYXJ0eVNpemU6IDIsIHJlc2VydmVkRm9yOiBcIlwiLCBub3RlczogXCJcIiB9KTtcclxuICAgICAgICAgICAgcmVmcmVzaCgpO1xyXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiUmVzZXJ2YSBjcmlhZGEuXCIpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGNvbmZpcm1NdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAoaWQ6IG51bWJlcikgPT4gY29uZmlybVJlc2VydmF0aW9uKGlkLCBOdW1iZXIodGFibGVGb3JDb25maXJtKSksXHJcbiAgICAgICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICAgICAgICBzZXRDb25maXJtaW5nSWQobnVsbCk7XHJcbiAgICAgICAgICAgIHNldFRhYmxlRm9yQ29uZmlybShcIlwiKTtcclxuICAgICAgICAgICAgcmVmcmVzaCgpO1xyXG4gICAgICAgICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcInRhYmxlc1wiXSB9KTtcclxuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIlJlc2VydmEgY29uZmlybWFkYS5cIik7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgY2FuY2VsTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKGlkOiBudW1iZXIpID0+IGNhbmNlbFJlc2VydmF0aW9uKGlkKSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgICAgcmVmcmVzaCgpO1xyXG4gICAgICAgICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcInRhYmxlc1wiXSB9KTtcclxuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIlJlc2VydmEgY2FuY2VsYWRhLlwiKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBzb3J0ZWQgPSBbLi4uKHJlc2VydmF0aW9uc1F1ZXJ5LmRhdGEgPz8gW10pXS5zb3J0KFxyXG4gICAgICAgIChhLCBiKSA9PiBuZXcgRGF0ZShhLnJlc2VydmVkRm9yKS5nZXRUaW1lKCkgLSBuZXcgRGF0ZShiLnJlc2VydmVkRm9yKS5nZXRUaW1lKCksXHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IGZyZWVUYWJsZXMgPSAodGFibGVzUXVlcnkuZGF0YSA/PyBbXSkuZmlsdGVyKCh0KSA9PiB0LnRhYmxlU3RhdHVzSWQgPT09IFRhYmxlU3RhdHVzLkxpdnJlKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxtYWluIHN0eWxlPXt7IHBhZGRpbmc6IDIyLCBtYXhXaWR0aDogMTAwMCwgbWFyZ2luOiBcIjAgYXV0b1wiLCBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiIH19PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2VcIiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJiYXNlbGluZVwiLCBnYXA6IDE0LCBtYXJnaW5Cb3R0b206IDYsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS43cmVtXCIgfX0+UmVzZXJ2YXMgZGUgbWVzYTwvaDI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PnByw7N4aW1vcyAxNCBkaWFzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB7IHNldEVycm9yKG51bGwpOyBzZXRDcmVhdGluZyh0cnVlKTsgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgKyBOb3ZhIHJlc2VydmFcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtyZXNlcnZhdGlvbnNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtyZXNlcnZhdGlvbnNRdWVyeS5lcnJvcn0gd2hhdD1cImFzIHJlc2VydmFzXCIgLz59XHJcbiAgICAgICAgICAgIHtlcnJvciAmJiAhY3JlYXRpbmcgJiYgY29uZmlybWluZ0lkID09PSBudWxsICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuXHJcbiAgICAgICAgICAgIHtyZXNlcnZhdGlvbnNRdWVyeS5pc0xvYWRpbmcgJiYgPFNrZWxldG9uTGlzdCByb3dzPXs0fSByb3dIZWlnaHQ9ezgwfSAvPn1cclxuXHJcbiAgICAgICAgICAgIHshcmVzZXJ2YXRpb25zUXVlcnkuaXNMb2FkaW5nICYmIHNvcnRlZC5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgICAgICAgICAgICBpY29uPVwi8J+ThVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJOZW5odW1hIHJlc2VydmEgbm9zIHByw7N4aW1vcyAxNCBkaWFzXCJcclxuICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbj1cIkNyaWUgdW1hIHJlc2VydmEgcGFyYSByZXNlcnZhciB1bWEgbWVzYSBjb20gYW50ZWNlZMOqbmNpYS5cIlxyXG4gICAgICAgICAgICAgICAgICAgIGFjdGlvbj17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRFcnJvcihudWxsKTsgc2V0Q3JlYXRpbmcodHJ1ZSk7IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKyBOb3ZhIHJlc2VydmFcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHshcmVzZXJ2YXRpb25zUXVlcnkuaXNMb2FkaW5nICYmIHNvcnRlZC5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEwLCBtYXJnaW5Ub3A6IDEyIH19PlxyXG4gICAgICAgICAgICAgICAge3NvcnRlZC5tYXAoKHIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ci5pZH0gY2xhc3NOYW1lPVwidGlja2V0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LWhlYWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntyLmN1c3RvbWVyTmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGlwXCIgc3R5bGU9e3sgXCItLWRvdFwiOiBcInZhcigtLWJ1c3kpXCIgfSBhcyBSZWFjdC5DU1NQcm9wZXJ0aWVzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzZXJ2YXRpb25TdGF0dXNMYWJlbFtyLnJlc2VydmF0aW9uU3RhdHVzSWRdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIgc3R5bGU9e3sgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoci5yZXNlcnZlZEZvcikudG9Mb2NhbGVTdHJpbmcoXCJwdC1CUlwiLCB7IGRhdGVTdHlsZTogXCJzaG9ydFwiLCB0aW1lU3R5bGU6IFwic2hvcnRcIiB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3IucGFydHlTaXplfSBwZXNzb2FzIHtyLmN1c3RvbWVyUGhvbmUgPyBgwrcgJHtyLmN1c3RvbWVyUGhvbmV9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ci5yZXNlcnZhdGlvblN0YXR1c0lkID09PSBSZXNlcnZhdGlvblN0YXR1cy5QZW5kaW5nICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1pbkhlaWdodDogNDQsIHBhZGRpbmc6IFwiMCAxMHB4XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRFcnJvcihudWxsKTsgc2V0Q29uZmlybWluZ0lkKHIuaWQpOyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb25maXJtYXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1kYW5nZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTBweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYXdhaXQgZGlhbG9nLmNvbmZpcm0oeyB0aXRsZTogXCJDYW5jZWxhciByZXNlcnZhXCIsIG1lc3NhZ2U6IGBDYW5jZWxhciBhIHJlc2VydmEgZGUgJHtyLmN1c3RvbWVyTmFtZX0/YCwgY29uZmlybUxhYmVsOiBcIkNhbmNlbGFyIHJlc2VydmFcIiwgZGFuZ2VyOiB0cnVlIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxNdXRhdGlvbi5tdXRhdGUoci5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ci5yZXNlcnZhdGlvblN0YXR1c0lkID09PSBSZXNlcnZhdGlvblN0YXR1cy5Db25maXJtZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTBweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGF3YWl0IGRpYWxvZy5jb25maXJtKHsgdGl0bGU6IFwiQ2FuY2VsYXIgcmVzZXJ2YVwiLCBtZXNzYWdlOiBgQ2FuY2VsYXIgYSByZXNlcnZhIGRlICR7ci5jdXN0b21lck5hbWV9P2AsIGNvbmZpcm1MYWJlbDogXCJDYW5jZWxhciByZXNlcnZhXCIsIGRhbmdlcjogdHJ1ZSB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxNdXRhdGlvbi5tdXRhdGUoci5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7Y3JlYXRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgPE1vZGFsIHRpdGxlPVwiTm92YSByZXNlcnZhXCIgb25DbG9zZT17KCkgPT4gc2V0Q3JlYXRpbmcoZmFsc2UpfSB2YXJpYW50PVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIk5vbWUgZG8gY2xpZW50ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uY3VzdG9tZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oKGYpID0+ICh7IC4uLmYsIGN1c3RvbWVyTmFtZTogZS50YXJnZXQudmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUZWxlZm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmN1c3RvbWVyUGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKChmKSA9PiAoeyAuLi5mLCBjdXN0b21lclBob25lOiBlLnRhcmdldC52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUGVzc29hc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnBhcnR5U2l6ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oKGYpID0+ICh7IC4uLmYsIHBhcnR5U2l6ZTogTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkRhdGEgZSBob3JhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGV0aW1lLWxvY2FsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ucmVzZXJ2ZWRGb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSgoZikgPT4gKHsgLi4uZiwgcmVzZXJ2ZWRGb3I6IGUudGFyZ2V0LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiT2JzZXJ2YcOnw7Vlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubm90ZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSgoZikgPT4gKHsgLi4uZiwgbm90ZXM6IGUudGFyZ2V0LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17Y3JlYXRlTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Zm9ybS5jdXN0b21lck5hbWUudHJpbSgpID09PSBcIlwiIHx8IGZvcm0ucmVzZXJ2ZWRGb3IgPT09IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNyZWF0ZU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3JpYXIgcmVzZXJ2YVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtjb25maXJtaW5nSWQgIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgPE1vZGFsIHRpdGxlPVwiQ29uZmlybWFyIHJlc2VydmEg4oCUIGVzY29saGVyIG1lc2FcIiBvbkNsb3NlPXsoKSA9PiBzZXRDb25maXJtaW5nSWQobnVsbCl9IHZhcmlhbnQ9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0RmllbGQgbGFiZWw9XCJNZXNhIGxpdnJlXCIgdmFsdWU9e3RhYmxlRm9yQ29uZmlybX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRUYWJsZUZvckNvbmZpcm0oZS50YXJnZXQudmFsdWUpfSBhdXRvRm9jdXM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2lvbmXigKY8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ZyZWVUYWJsZXMubWFwKCh0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dC5pZH0gdmFsdWU9e3QuaWR9Pk1lc2Ege3QubnVtYmVyfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEZpZWxkPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmcmVlVGFibGVzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19Pk5lbmh1bWEgbWVzYSBsaXZyZSBubyBtb21lbnRvLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2NvbmZpcm1NdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt0YWJsZUZvckNvbmZpcm0gPT09IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbmZpcm1NdXRhdGlvbi5tdXRhdGUoY29uZmlybWluZ0lkKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENvbmZpcm1hciBlIHJlc2VydmFyIG1lc2FcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgPC9tYWluPlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9yZXNlcnZhdGlvbnMvUmVzZXJ2YXRpb25zUGFnZS50c3gifQ==