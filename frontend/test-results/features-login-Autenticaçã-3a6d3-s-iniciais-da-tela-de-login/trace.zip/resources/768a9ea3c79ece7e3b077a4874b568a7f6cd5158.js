import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/digitalmenu/DigitalMenuPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useQuery, useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getMenu, getCategories } from "/src/features/catalog/api.ts";
import { getOpenOrdersByBranch, openOrder, addOrderItem } from "/src/features/orders/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { formatBRL } from "/src/lib/types.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { Button } from "/src/ui/Button.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
import { useToast } from "/src/ui/Toast.tsx";
export function DigitalMenuPage() {
  _s();
  const { mesa } = useParams();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { companyId, branchId, employeeId } = useAuthStore();
  const [activeCategoryId, setActiveCategoryId] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const menuQuery = useQuery({
    queryKey: ["menu", companyId],
    queryFn: () => getMenu(companyId ?? 1)
  });
  const categoriesQuery = useQuery({
    queryKey: ["categories", companyId],
    queryFn: () => getCategories(companyId ?? 1)
  });
  const openOrdersQuery = useQuery({
    queryKey: ["orders", "open", branchId],
    queryFn: () => getOpenOrdersByBranch(branchId ?? 1)
  });
  const currentCategoryId = activeCategoryId ?? categoriesQuery.data?.[0]?.id ?? null;
  const activeCategoryName = categoriesQuery.data?.find((c) => c.id === currentCategoryId)?.name ?? "Cardápio";
  const filteredMenu = useMemo(() => {
    if (!currentCategoryId || !menuQuery.data) return [];
    return menuQuery.data.filter((p) => p.categoryId === currentCategoryId);
  }, [menuQuery.data, currentCategoryId]);
  const cartTotal = cart.reduce((acc, item) => acc + item.totalPrice, 0);
  const handleAddToCart = (item) => {
    setCart((prev) => [...prev, item]);
    setSelectedProduct(null);
    toast.success("Item adicionado ao pedido!");
  };
  const handleCallWaiter = () => {
    toast.success("Garçom chamado para a mesa " + mesa);
  };
  const submitOrderMutation = useMutation({
    mutationFn: async () => {
      const tableId = Number(mesa);
      let orderId;
      const existingOrder = openOrdersQuery.data?.find((o) => o.diningTableId === tableId);
      if (existingOrder) {
        orderId = existingOrder.id;
      } else {
        orderId = await openOrder({
          branchId: branchId ?? 1,
          diningTableId: tableId,
          comandaId: null,
          employeeId: employeeId ?? 1,
          guestCount: 1,
          // Assume 1 pessoa inicialmente no autoatendimento
          notes: "Aberto via Cardápio Digital"
        });
      }
      for (const item of cart) {
        await addOrderItem(
          orderId,
          item.product.id,
          item.quantity,
          item.notes,
          employeeId ?? 1,
          item.complements
        );
      }
    },
    onSuccess: () => {
      toast.success("Pedido enviado para a cozinha!");
      setCart([]);
      setIsCartOpen(false);
      queryClient.invalidateQueries({ queryKey: ["orders"] });
    },
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : "Falha ao enviar o pedido.");
    }
  });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("style", { children: `
        .dm-layout {
          display: flex;
          height: 100vh;
          background-color: #ffffff;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          overflow: hidden;
        }
        
        .dm-sidebar {
          width: 280px;
          background-color: #111111;
          color: #ffffff;
          display: flex;
          flex-direction: column;
          flex-shrink: 0;
        }
        
        .dm-logo-container {
          padding: 30px 24px;
        }
        
        .dm-logo {
          font-size: 2.2rem;
          font-weight: bold;
          margin: 0;
          letter-spacing: -1px;
        }
        
        .dm-logo span {
          color: #ff6b00;
        }
        
        .dm-subtitle {
          color: #ff6b00;
          font-size: 0.65rem;
          letter-spacing: 1px;
          margin-top: 4px;
          text-transform: uppercase;
          font-weight: bold;
        }

        .dm-nav-item {
          padding: 16px 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          cursor: pointer;
          font-weight: 500;
          border-left: 4px solid transparent;
          transition: all 0.2s;
        }
        .dm-nav-item.active {
          color: #ff6b00;
          border-left-color: #ff6b00;
          background-color: rgba(255, 107, 0, 0.05);
        }

        .dm-main {
          flex: 1;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }

        .dm-header-desktop {
          display: flex;
          justify-content: flex-end;
          align-items: center;
          padding: 24px 40px;
          gap: 20px;
        }

        .dm-header-mobile {
          display: none;
          background-color: #111111;
          color: #ffffff;
          padding: 40px 20px 20px 20px;
          flex-direction: column;
        }

        .dm-btn-outline {
          border: 1px solid #ff6b00;
          color: #ff6b00;
          background: transparent;
          border-radius: 30px;
          padding: 8px 16px;
          font-weight: bold;
          font-size: 0.85rem;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .dm-btn-outline.dark-text {
          color: #111111;
        }
        
        .dm-badge {
          background-color: #ff6b00;
          color: #ffffff;
          border-radius: 50%;
          width: 20px;
          height: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 0.75rem;
        }

        .dm-content-scroll {
          flex: 1;
          overflow-y: auto;
          padding: 0 40px 40px 40px;
        }

        .dm-title {
          font-size: 2rem;
          font-weight: 800;
          text-transform: uppercase;
          margin: 0 0 4px 0;
          color: #111111;
        }

        .dm-desc {
          color: #666666;
          margin: 0 0 24px 0;
          font-size: 0.95rem;
        }

        .dm-pills-container {
          display: flex;
          gap: 12px;
          overflow-x: auto;
          padding-bottom: 24px;
          scrollbar-width: none;
        }
        .dm-pills-container::-webkit-scrollbar { display: none; }
        
        .dm-pill {
          background-color: #f5f5f5;
          color: #333333;
          border: none;
          border-radius: 20px;
          padding: 8px 24px;
          font-weight: 600;
          font-size: 0.85rem;
          white-space: nowrap;
          cursor: pointer;
        }
        .dm-pill.active {
          background-color: #ff6b00;
          color: #ffffff;
        }

        .dm-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
          gap: 20px;
          margin-bottom: 40px;
        }

        .dm-card {
          display: flex;
          background: #ffffff;
          border: 1px solid #f0f0f0;
          border-radius: 16px;
          padding: 16px;
          gap: 16px;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03);
          cursor: pointer;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .dm-card:active {
          transform: scale(0.98);
        }

        .dm-card-img {
          width: 80px;
          height: 100px;
          object-fit: contain;
          border-radius: 8px;
        }

        .dm-card-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }

        .dm-card-add-btn {
          border: 1px solid #ff6b00;
          background: transparent;
          color: #111111;
          border-radius: 20px;
          padding: 4px 14px;
          font-size: 0.75rem;
          font-weight: bold;
          display: flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .dm-footer-info {
          display: flex;
          justify-content: space-between;
          border-top: 1px solid #eeeeee;
          padding-top: 24px;
          color: #666666;
          font-size: 0.85rem;
        }
        .dm-footer-info strong {
          color: #111111;
          display: block;
          margin-top: 4px;
        }
        
        .dm-bottom-nav {
          display: none;
        }

        @media (max-width: 768px) {
          .dm-layout { flex-direction: column; }
          .dm-sidebar { display: none; }
          .dm-header-desktop { display: none; }
          .dm-header-mobile { display: flex; }
          .dm-content-scroll { padding: 24px 20px 100px 20px; }
          .dm-grid { grid-template-columns: 1fr; }
          .dm-footer-info { flex-direction: column; gap: 16px; }
          
          .dm-bottom-nav {
            display: flex;
            background-color: #111111;
            position: fixed;
            bottom: 0;
            width: 100%;
            padding: 12px 16px;
            overflow-x: auto;
            gap: 24px;
            scrollbar-width: none;
            z-index: 50;
            border-top: 1px solid #222;
          }
          .dm-bottom-nav::-webkit-scrollbar { display: none; }
          
          .dm-bottom-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #888888;
            min-width: 60px;
            cursor: pointer;
          }
          .dm-bottom-item.active { color: #ff6b00; }
          .dm-bottom-item svg { margin-bottom: 6px; }
          .dm-bottom-item span {
            font-size: 0.65rem;
            text-transform: uppercase;
            font-weight: bold;
          }
        }
      ` }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
      lineNumber: 136,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "dm-layout", children: [
      /* @__PURE__ */ jsxDEV("aside", { className: "dm-sidebar", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "dm-logo-container", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "dm-logo", children: [
            "ding",
            /* @__PURE__ */ jsxDEV("span", { children: ".food" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 405,
              columnNumber: 53
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 405,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "dm-subtitle", children: "— Gestão inteligente para restaurantes —" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 406,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 404,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, overflowY: "auto" }, children: categoriesQuery.data?.map(
          (cat) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: `dm-nav-item ${currentCategoryId === cat.id ? "active" : ""}`,
              onClick: () => setActiveCategoryId(cat.id),
              children: [
                /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 12 }, children: [
                  /* @__PURE__ */ jsxDEV(IconPlaceholder, {}, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                    lineNumber: 417,
                    columnNumber: 37
                  }, this),
                  " ",
                  cat.name
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                  lineNumber: 416,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "›" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                  lineNumber: 419,
                  columnNumber: 33
                }, this)
              ]
            },
            cat.id,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 410,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 408,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { margin: "20px", padding: "16px", border: "1px solid #333", borderRadius: 12, display: "flex", alignItems: "center", gap: 12 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "2rem" }, children: "🛎️" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 424,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "#aaa" }, children: "PEÇA PELO APP E GANHE" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 426,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.2rem", color: "#ff6b00", fontWeight: "bold" }, children: [
              "5% ",
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.75rem", color: "#aaa" }, children: "DE DESCONTO!" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 427,
                columnNumber: 106
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 427,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 425,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 423,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
        lineNumber: 403,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "dm-main", children: [
        /* @__PURE__ */ jsxDEV("header", { className: "dm-header-desktop", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "right" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { color: "#ff6b00", fontSize: "0.85rem", fontWeight: "bold" }, children: [
              "MESA ",
              mesa
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 435,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { color: "#666", fontSize: "0.85rem" }, children: "Convidado" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 436,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 434,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "dm-btn-outline", onClick: handleCallWaiter, children: "🛎️ CHAMAR GARÇOM" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 438,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "dm-btn-outline dark-text", onClick: () => setIsCartOpen(true), children: [
            "🛒 MEU PEDIDO ",
            /* @__PURE__ */ jsxDEV("div", { className: "dm-badge", children: cart.length }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 442,
              columnNumber: 43
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 441,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 433,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("header", { className: "dm-header-mobile", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", marginBottom: 24 }, children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "dm-logo", style: { color: "#fff" }, children: [
              "ding",
              /* @__PURE__ */ jsxDEV("span", { children: ".food" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 448,
                columnNumber: 83
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 448,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "dm-subtitle", style: { justifyContent: "center", display: "flex" }, children: "Gestão inteligente para restaurantes" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 449,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 447,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { style: { color: "#ff6b00", fontSize: "0.85rem", fontWeight: "bold", textTransform: "uppercase" }, children: [
                "MESA ",
                mesa
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 453,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { color: "#aaa", fontSize: "0.85rem" }, children: "Convidado" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 454,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 452,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
              /* @__PURE__ */ jsxDEV("button", { className: "dm-btn-outline", style: { padding: "6px 12px", fontSize: "0.75rem" }, onClick: handleCallWaiter, children: "🛎️" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 457,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "dm-btn-outline", style: { color: "#fff", padding: "6px 12px", fontSize: "0.75rem" }, onClick: () => setIsCartOpen(true), children: [
                "🛒 MEU PEDIDO ",
                /* @__PURE__ */ jsxDEV("div", { className: "dm-badge", children: cart.length }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                  lineNumber: 461,
                  columnNumber: 51
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 460,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 456,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 451,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 446,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "dm-content-scroll", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "dm-title", children: activeCategoryName }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 468,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "dm-desc", children: "Refrescância e sabor para todos os momentos" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 469,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "dm-pills-container", children: [
            /* @__PURE__ */ jsxDEV("button", { className: "dm-pill active", children: "TODOS" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 472,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "dm-pill", children: "ÁGUAS" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 473,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "dm-pill", children: "REFRIGERANTES" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 474,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "dm-pill", children: "SUCOS" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 475,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "dm-pill", children: "CERVEJAS" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 476,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 471,
            columnNumber: 25
          }, this),
          menuQuery.isLoading ? /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 4, rowHeight: 120 }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 480,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "dm-grid", children: filteredMenu.map(
            (product) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "dm-card",
                onClick: () => setSelectedProduct(product),
                onKeyDown: (e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setSelectedProduct(product);
                  }
                },
                role: "button",
                tabIndex: 0,
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: product.imageUrl || "https://via.placeholder.com/80x100?text=Sem+Foto",
                      alt: product.name,
                      className: "dm-card-img"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                      lineNumber: 497,
                      columnNumber: 41
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "dm-card-info", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("h4", { style: { margin: "0 0 4px 0", fontSize: "0.95rem", color: "#111", fontWeight: "bold" }, children: product.name }, void 0, false, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                        lineNumber: 504,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "#888", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }, children: product.description || "—" }, void 0, false, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                        lineNumber: 507,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                      lineNumber: 503,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 12 }, children: [
                      /* @__PURE__ */ jsxDEV("div", { style: { color: "#ff6b00", fontWeight: "bold", fontSize: "1rem" }, children: formatBRL(product.salePrice) }, void 0, false, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                        lineNumber: 512,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("button", { className: "dm-card-add-btn", children: "🛒 ADICIONAR" }, void 0, false, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                        lineNumber: 515,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                      lineNumber: 511,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                    lineNumber: 502,
                    columnNumber: 41
                  }, this)
                ]
              },
              product.id,
              true,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 484,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 482,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "dm-footer-info", children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12, alignItems: "center" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "1.5rem", color: "#ff6b00" }, children: "⏱" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 527,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                "TEMPO MÉDIO DE PREPARO ",
                /* @__PURE__ */ jsxDEV("strong", { children: "25 a 35 min" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                  lineNumber: 528,
                  columnNumber: 61
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 528,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 526,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12, alignItems: "center" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "1.5rem", color: "#ff6b00" }, children: "🛵" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 531,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                "TAXA DE ENTREGA ",
                /* @__PURE__ */ jsxDEV("strong", { children: "R$ 6,90" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                  lineNumber: 532,
                  columnNumber: 54
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 532,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 530,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12, alignItems: "center" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "1.5rem", color: "#ff6b00" }, children: "💳" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 535,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                "FORMAS DE PAGAMENTO ",
                /* @__PURE__ */ jsxDEV("strong", { children: "Crédito, Débito e Pix" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                  lineNumber: 536,
                  columnNumber: 58
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 536,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 534,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 525,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 467,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
        lineNumber: 432,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { className: "dm-bottom-nav", children: categoriesQuery.data?.map(
        (cat) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: `dm-bottom-item ${currentCategoryId === cat.id ? "active" : ""}`,
            onClick: () => setActiveCategoryId(cat.id),
            children: [
              /* @__PURE__ */ jsxDEV(IconPlaceholder, {}, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 550,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: cat.name }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 551,
                columnNumber: 29
              }, this)
            ]
          },
          cat.id,
          true,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 544,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
        lineNumber: 542,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
      lineNumber: 402,
      columnNumber: 13
    }, this),
    selectedProduct && /* @__PURE__ */ jsxDEV(
      ProductOrderModal,
      {
        product: selectedProduct,
        onClose: () => setSelectedProduct(null),
        onAdd: handleAddToCart
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
        lineNumber: 559,
        columnNumber: 7
      },
      this
    ),
    isCartOpen && /* @__PURE__ */ jsxDEV(Modal, { title: "Seu Pedido", onClose: () => setIsCartOpen(false), children: /* @__PURE__ */ jsxDEV("div", { style: { minHeight: 200 }, children: cart.length === 0 ? /* @__PURE__ */ jsxDEV("p", { style: { textAlign: "center", color: "#888", marginTop: 40 }, children: "Seu pedido está vazio." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
      lineNumber: 571,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: 12 }, children: [
      cart.map(
        (item) => /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", borderBottom: "1px solid #eee", paddingBottom: 8 }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: [
              item.quantity,
              "x ",
              item.product.name
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 577,
              columnNumber: 45
            }, this),
            item.notes && /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.8rem", color: "#666" }, children: item.notes }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 578,
              columnNumber: 60
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 576,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { style: { color: "#ff6b00" }, children: formatBRL(item.totalPrice) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 580,
            columnNumber: 41
          }, this)
        ] }, item.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 575,
          columnNumber: 13
        }, this)
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", fontSize: "1.2rem", fontWeight: "bold", marginTop: 16 }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Total" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 584,
          columnNumber: 37
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "#ff6b00" }, children: formatBRL(cartTotal) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 585,
          columnNumber: 37
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
        lineNumber: 583,
        columnNumber: 33
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          loading: submitOrderMutation.isPending,
          style: { background: "#ff6b00", borderColor: "#ff6b00", marginTop: 16 },
          onClick: () => submitOrderMutation.mutate(),
          children: "Confirmar Pedido"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 587,
          columnNumber: 33
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
      lineNumber: 573,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
      lineNumber: 569,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
      lineNumber: 568,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
    lineNumber: 135,
    columnNumber: 5
  }, this);
}
_s(DigitalMenuPage, "SEoboLpmSwe79vz+7ZU/pT3Nm7o=", false, function() {
  return [useParams, useQueryClient, useToast, useAuthStore, useQuery, useQuery, useQuery, useMutation];
});
_c = DigitalMenuPage;
function IconPlaceholder() {
  return /* @__PURE__ */ jsxDEV("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.5", children: /* @__PURE__ */ jsxDEV("path", { d: "M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
    lineNumber: 608,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
    lineNumber: 607,
    columnNumber: 5
  }, this);
}
_c2 = IconPlaceholder;
function ProductOrderModal({ product, onClose, onAdd }) {
  _s2();
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState("");
  const [selected, setSelected] = useState({});
  const toggle = (group, complementId) => {
    setSelected((current) => {
      const chosen = current[group.id] ?? [];
      const isSingle = group.maxSelection <= 1;
      if (chosen.includes(complementId)) {
        return { ...current, [group.id]: chosen.filter((id) => id !== complementId) };
      }
      if (isSingle) return { ...current, [group.id]: [complementId] };
      if (chosen.length >= group.maxSelection) return current;
      return { ...current, [group.id]: [...chosen, complementId] };
    });
  };
  const groupSatisfied = (group) => {
    const count = (selected[group.id] ?? []).length;
    return count >= group.minSelection && count <= group.maxSelection;
  };
  const allSatisfied = product.complementGroups.every(groupSatisfied);
  const complementsTotal = product.complementGroups.reduce((acc, group) => {
    const chosenIds = selected[group.id] ?? [];
    const groupSum = group.complements.filter((c) => chosenIds.includes(c.id)).reduce((sum, c) => sum + c.extraPrice, 0);
    return acc + groupSum;
  }, 0);
  const itemTotal = (product.salePrice + complementsTotal) * quantity;
  const handleConfirm = () => {
    const selections = product.complementGroups.flatMap(
      (group) => (selected[group.id] ?? []).map((complementId) => ({ complementGroupId: group.id, complementId }))
    );
    onAdd({
      id: Math.random().toString(36).substr(2, 9),
      product,
      quantity,
      notes: notes.trim(),
      complements: selections,
      totalPrice: itemTotal
    });
  };
  return /* @__PURE__ */ jsxDEV(Modal, { title: product.name, onClose, variant: "center", children: /* @__PURE__ */ jsxDEV("div", { style: { maxHeight: "75vh", overflowY: "auto", paddingRight: 4 }, children: [
    product.imageUrl && /* @__PURE__ */ jsxDEV("img", { src: product.imageUrl, alt: product.name, style: { width: "100%", height: 200, objectFit: "cover", borderRadius: 12, marginBottom: 16 } }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
      lineNumber: 668,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { style: { color: "#666", marginBottom: 20 }, children: product.description }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
      lineNumber: 670,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: 16 }, children: [
      product.complementGroups.map((group) => {
        const chosen = selected[group.id] ?? [];
        const isSingle = group.maxSelection <= 1;
        const satisfied = groupSatisfied(group);
        const activeComplements = group.complements.filter((c) => c.isActive);
        return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "baseline" }, children: [
            /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: group.name }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 684,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: satisfied ? "var(--ink-dim)" : "var(--danger)" }, children: group.minSelection === 0 ? `opcional · até ${group.maxSelection}` : group.minSelection === group.maxSelection ? `escolha ${group.minSelection}` : `escolha de ${group.minSelection} a ${group.maxSelection}` }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
              lineNumber: 685,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 683,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 6 }, children: activeComplements.map((c) => {
            const isChosen = chosen.includes(c.id);
            return /* @__PURE__ */ jsxDEV(
              "label",
              {
                style: {
                  display: "flex",
                  justifyContent: "space-between",
                  padding: "10px",
                  borderRadius: 8,
                  border: `1px solid ${isChosen ? "#ff6b00" : "#eee"}`,
                  cursor: "pointer",
                  background: isChosen ? "rgba(255, 107, 0, 0.05)" : "#fff"
                },
                children: [
                  /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", gap: 8 }, children: [
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: isSingle ? "radio" : "checkbox",
                        checked: isChosen,
                        onChange: () => toggle(group, c.id),
                        style: { accentColor: "#ff6b00" }
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                        lineNumber: 707,
                        columnNumber: 53
                      },
                      this
                    ),
                    c.complementItemName
                  ] }, void 0, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                    lineNumber: 706,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { style: { color: "#888", fontSize: "0.9rem" }, children: c.extraPrice > 0 ? `+ ${formatBRL(c.extraPrice)}` : "sem custo" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                    lineNumber: 715,
                    columnNumber: 49
                  }, this)
                ]
              },
              c.id,
              true,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
                lineNumber: 698,
                columnNumber: 23
              },
              this
            );
          }) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 694,
            columnNumber: 33
          }, this)
        ] }, group.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 682,
          columnNumber: 15
        }, this);
      }),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", background: "#f9f9f9", padding: 12, borderRadius: 8, marginTop: 8 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: "bold" }, children: "Quantidade" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 727,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 16, alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV("button", { onClick: () => setQuantity(Math.max(1, quantity - 1)), style: { width: 32, height: 32, borderRadius: "50%", border: "1px solid #ccc", background: "#fff", fontSize: "1.2rem" }, children: "-" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 729,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "1.2rem", fontWeight: "bold" }, children: quantity }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 730,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => setQuantity(quantity + 1), style: { width: 32, height: 32, borderRadius: "50%", border: "1px solid #ff6b00", color: "#ff6b00", background: "#fff", fontSize: "1.2rem" }, children: "+" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
            lineNumber: 731,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 728,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
        lineNumber: 726,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          placeholder: "Alguma observação? (Ex: Sem gelo)",
          value: notes,
          onChange: (e) => setNotes(e.target.value),
          style: { width: "100%", height: 80, padding: 12, borderRadius: 8, border: "1px solid #ddd", fontFamily: "inherit" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 735,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          disabled: !allSatisfied,
          onClick: handleConfirm,
          style: { background: "#ff6b00", borderColor: "#ff6b00" },
          children: [
            "Adicionar • ",
            formatBRL(itemTotal)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
          lineNumber: 742,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
      lineNumber: 672,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
    lineNumber: 666,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx",
    lineNumber: 665,
    columnNumber: 5
  }, this);
}
_s2(ProductOrderModal, "lzlVX5IGkmTF+F0KJLNFJ1HhY3c=");
_c3 = ProductOrderModal;
var _c, _c2, _c3;
$RefreshReg$(_c, "DigitalMenuPage");
$RefreshReg$(_c2, "IconPlaceholder");
$RefreshReg$(_c3, "ProductOrderModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/digitalmenu/DigitalMenuPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUhRLG1CQUNJLGNBREo7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbkhQLFNBQVNBLFVBQVVDLGVBQWU7QUFDbkMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLFVBQVVDLGFBQWFDLHNCQUFzQjtBQUN0RCxTQUFTQyxTQUFTQyxxQkFBcUI7QUFDdkMsU0FBU0MsdUJBQXVCQyxXQUFXQyxvQkFBb0I7QUFDL0QsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxnQkFBZ0I7QUFFekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFXbEIsZ0JBQVNDLGtCQUFrQjtBQUFBQyxLQUFBO0FBQzlCLFFBQU0sRUFBRUMsS0FBSyxJQUFJbEIsVUFBVTtBQUMzQixRQUFNbUIsY0FBY2hCLGVBQWU7QUFDbkMsUUFBTWlCLFFBQVFMLFNBQVM7QUFDdkIsUUFBTSxFQUFFTSxXQUFXQyxVQUFVQyxXQUFXLElBQUlkLGFBQWE7QUFFekQsUUFBTSxDQUFDZSxrQkFBa0JDLG1CQUFtQixJQUFJM0IsU0FBd0IsSUFBSTtBQUM1RSxRQUFNLENBQUM0QixpQkFBaUJDLGtCQUFrQixJQUFJN0IsU0FBa0MsSUFBSTtBQUNwRixRQUFNLENBQUM4QixNQUFNQyxPQUFPLElBQUkvQixTQUFxQixFQUFFO0FBQy9DLFFBQU0sQ0FBQ2dDLFlBQVlDLGFBQWEsSUFBSWpDLFNBQVMsS0FBSztBQUVsRCxRQUFNa0MsWUFBWS9CLFNBQVM7QUFBQSxJQUN2QmdDLFVBQVUsQ0FBQyxRQUFRWixTQUFTO0FBQUEsSUFDNUJhLFNBQVNBLE1BQU05QixRQUFRaUIsYUFBYSxDQUFDO0FBQUEsRUFDekMsQ0FBQztBQUVELFFBQU1jLGtCQUFrQmxDLFNBQVM7QUFBQSxJQUM3QmdDLFVBQVUsQ0FBQyxjQUFjWixTQUFTO0FBQUEsSUFDbENhLFNBQVNBLE1BQU03QixjQUFjZ0IsYUFBYSxDQUFDO0FBQUEsRUFDL0MsQ0FBQztBQUVELFFBQU1lLGtCQUFrQm5DLFNBQVM7QUFBQSxJQUM3QmdDLFVBQVUsQ0FBQyxVQUFVLFFBQVFYLFFBQVE7QUFBQSxJQUNyQ1ksU0FBU0EsTUFBTTVCLHNCQUFzQmdCLFlBQVksQ0FBQztBQUFBLEVBQ3RELENBQUM7QUFFRCxRQUFNZSxvQkFBb0JiLG9CQUFvQlcsZ0JBQWdCRyxPQUFPLENBQUMsR0FBR0MsTUFBTTtBQUMvRSxRQUFNQyxxQkFBcUJMLGdCQUFnQkcsTUFBTUcsS0FBSyxDQUFBQyxNQUFLQSxFQUFFSCxPQUFPRixpQkFBaUIsR0FBR00sUUFBUTtBQUVoRyxRQUFNQyxlQUFlN0MsUUFBUSxNQUFNO0FBQy9CLFFBQUksQ0FBQ3NDLHFCQUFxQixDQUFDTCxVQUFVTSxLQUFNLFFBQU87QUFDbEQsV0FBT04sVUFBVU0sS0FBS08sT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxlQUFlVixpQkFBaUI7QUFBQSxFQUMxRSxHQUFHLENBQUNMLFVBQVVNLE1BQU1ELGlCQUFpQixDQUFDO0FBRXRDLFFBQU1XLFlBQVlwQixLQUFLcUIsT0FBTyxDQUFDQyxLQUFLQyxTQUFTRCxNQUFNQyxLQUFLQyxZQUFZLENBQUM7QUFFckUsUUFBTUMsa0JBQWtCQSxDQUFDRixTQUFtQjtBQUN4Q3RCLFlBQVEsQ0FBQ3lCLFNBQVMsQ0FBQyxHQUFHQSxNQUFNSCxJQUFJLENBQUM7QUFDakN4Qix1QkFBbUIsSUFBSTtBQUN2QlAsVUFBTW1DLFFBQVEsNEJBQTRCO0FBQUEsRUFDOUM7QUFFQSxRQUFNQyxtQkFBbUJBLE1BQU07QUFDM0JwQyxVQUFNbUMsUUFBUSxnQ0FBZ0NyQyxJQUFJO0FBQUEsRUFDdEQ7QUFFQSxRQUFNdUMsc0JBQXNCdkQsWUFBWTtBQUFBLElBQ3BDd0QsWUFBWSxZQUFZO0FBQ3BCLFlBQU1DLFVBQVVDLE9BQU8xQyxJQUFJO0FBQzNCLFVBQUkyQztBQUdKLFlBQU1DLGdCQUFnQjFCLGdCQUFnQkUsTUFBTUcsS0FBSyxDQUFDc0IsTUFBTUEsRUFBRUMsa0JBQWtCTCxPQUFPO0FBRW5GLFVBQUlHLGVBQWU7QUFDZkQsa0JBQVVDLGNBQWN2QjtBQUFBQSxNQUM1QixPQUFPO0FBRUhzQixrQkFBVSxNQUFNdEQsVUFBVTtBQUFBLFVBQ3RCZSxVQUFVQSxZQUFZO0FBQUEsVUFDdEIwQyxlQUFlTDtBQUFBQSxVQUNmTSxXQUFXO0FBQUEsVUFDWDFDLFlBQVlBLGNBQWM7QUFBQSxVQUMxQjJDLFlBQVk7QUFBQTtBQUFBLFVBQ1pDLE9BQU87QUFBQSxRQUNYLENBQUM7QUFBQSxNQUNMO0FBR0EsaUJBQVdoQixRQUFRdkIsTUFBTTtBQUNyQixjQUFNcEI7QUFBQUEsVUFDRnFEO0FBQUFBLFVBQ0FWLEtBQUtpQixRQUFRN0I7QUFBQUEsVUFDYlksS0FBS2tCO0FBQUFBLFVBQ0xsQixLQUFLZ0I7QUFBQUEsVUFDTDVDLGNBQWM7QUFBQSxVQUNkNEIsS0FBS21CO0FBQUFBLFFBQ1Q7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUFBLElBQ0FDLFdBQVdBLE1BQU07QUFDYm5ELFlBQU1tQyxRQUFRLGdDQUFnQztBQUM5QzFCLGNBQVEsRUFBRTtBQUNWRSxvQkFBYyxLQUFLO0FBQ25CWixrQkFBWXFELGtCQUFrQixFQUFFdkMsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQUEsSUFDMUQ7QUFBQSxJQUNBd0MsU0FBU0EsQ0FBQ0MsTUFBTTtBQUNadEQsWUFBTXVELE1BQU1ELGFBQWEvRCxXQUFXK0QsRUFBRUUsVUFBVSwyQkFBMkI7QUFBQSxJQUMvRTtBQUFBLEVBQ0osQ0FBQztBQUVELFNBQ0ksbUNBQ0k7QUFBQSwyQkFBQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdRSjtBQUFBLElBRUksdUJBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQSw2QkFBQyxXQUFNLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQkFDWDtBQUFBLGlDQUFDLFFBQUcsV0FBVSxXQUFVO0FBQUE7QUFBQSxZQUFJLHVCQUFDLFVBQUsscUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBVztBQUFBLGVBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsVUFDOUMsdUJBQUMsU0FBSSxXQUFVLGVBQWMsd0RBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsYUFGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsTUFBTSxHQUFHQyxXQUFXLE9BQU8sR0FDcEMzQywwQkFBZ0JHLE1BQU15QztBQUFBQSxVQUFJLENBQUNDLFFBQ3hCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFRyxNQUFLO0FBQUEsY0FDTCxXQUFXLGVBQWUzQyxzQkFBc0IyQyxJQUFJekMsS0FBSyxXQUFXLEVBQUU7QUFBQSxjQUN0RSxTQUFTLE1BQU1kLG9CQUFvQnVELElBQUl6QyxFQUFFO0FBQUEsY0FFekM7QUFBQSx1Q0FBQyxTQUFJLE9BQU8sRUFBRTBDLFNBQVMsUUFBUUMsWUFBWSxVQUFVQyxLQUFLLEdBQUcsR0FDekQ7QUFBQSx5Q0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQjtBQUFBLGtCQUFHO0FBQUEsa0JBQUVILElBQUlyQztBQUFBQSxxQkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBTztBQUFBO0FBQUE7QUFBQSxZQVJGcUMsSUFBSXpDO0FBQUFBLFlBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsUUFDSCxLQWJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUU2QyxRQUFRLFFBQVFDLFNBQVMsUUFBUUMsUUFBUSxrQkFBa0JDLGNBQWMsSUFBSU4sU0FBUyxRQUFRQyxZQUFZLFVBQVVDLEtBQUssR0FBRyxHQUN0STtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFSyxVQUFVLE9BQU8sR0FBRyxtQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUM7QUFBQSxVQUNyQyx1QkFBQyxTQUNHO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUVBLFVBQVUsV0FBV0MsT0FBTyxPQUFPLEdBQUcscUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUEsWUFDekUsdUJBQUMsU0FBSSxPQUFPLEVBQUVELFVBQVUsVUFBVUMsT0FBTyxXQUFXQyxZQUFZLE9BQU8sR0FBRztBQUFBO0FBQUEsY0FBRyx1QkFBQyxVQUFLLE9BQU8sRUFBRUYsVUFBVSxXQUFXQyxPQUFPLE9BQU8sR0FBRyw0QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUU7QUFBQSxpQkFBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUo7QUFBQSxlQUZ6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsTUFFQSx1QkFBQyxVQUFLLFdBQVUsV0FDWjtBQUFBLCtCQUFDLFlBQU8sV0FBVSxxQkFDZDtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFRSxXQUFXLFFBQVEsR0FDN0I7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRUYsT0FBTyxXQUFXRCxVQUFVLFdBQVdFLFlBQVksT0FBTyxHQUFHO0FBQUE7QUFBQSxjQUFNeEU7QUFBQUEsaUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsWUFDdEYsdUJBQUMsU0FBSSxPQUFPLEVBQUV1RSxPQUFPLFFBQVFELFVBQVUsVUFBVSxHQUFHLHlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBLGVBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFlBQU8sV0FBVSxrQkFBaUIsU0FBU2hDLGtCQUFrQixpQ0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsWUFBTyxXQUFVLDRCQUEyQixTQUFTLE1BQU16QixjQUFjLElBQUksR0FBRztBQUFBO0FBQUEsWUFDL0QsdUJBQUMsU0FBSSxXQUFVLFlBQVlILGVBQUtnRSxVQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLGVBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMsWUFBTyxXQUFVLG9CQUNkO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUVELFdBQVcsVUFBVUUsY0FBYyxHQUFHLEdBQ2hEO0FBQUEsbUNBQUMsUUFBRyxXQUFVLFdBQVUsT0FBTyxFQUFFSixPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUEsY0FBSSx1QkFBQyxVQUFLLHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVc7QUFBQSxpQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxZQUN4RSx1QkFBQyxTQUFJLFdBQVUsZUFBYyxPQUFPLEVBQUVLLGdCQUFnQixVQUFVYixTQUFTLE9BQU8sR0FBRyxvREFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUg7QUFBQSxlQUYzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUEsU0FBUyxRQUFRYSxnQkFBZ0IsaUJBQWlCWixZQUFZLFNBQVMsR0FDakY7QUFBQSxtQ0FBQyxTQUNHO0FBQUEscUNBQUMsU0FBSSxPQUFPLEVBQUVPLE9BQU8sV0FBV0QsVUFBVSxXQUFXRSxZQUFZLFFBQVFLLGVBQWUsWUFBWSxHQUFHO0FBQUE7QUFBQSxnQkFBTTdFO0FBQUFBLG1CQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrSDtBQUFBLGNBQ2xILHVCQUFDLFNBQUksT0FBTyxFQUFFdUUsT0FBTyxRQUFRRCxVQUFVLFVBQVUsR0FBRyx5QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxpQkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVQLFNBQVMsUUFBUUUsS0FBSyxFQUFFLEdBQ2xDO0FBQUEscUNBQUMsWUFBTyxXQUFVLGtCQUFpQixPQUFPLEVBQUVFLFNBQVMsWUFBWUcsVUFBVSxVQUFVLEdBQUcsU0FBU2hDLGtCQUFrQixtQkFBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsWUFBTyxXQUFVLGtCQUFpQixPQUFPLEVBQUVpQyxPQUFPLFFBQVFKLFNBQVMsWUFBWUcsVUFBVSxVQUFVLEdBQUcsU0FBUyxNQUFNekQsY0FBYyxJQUFJLEdBQUc7QUFBQTtBQUFBLGdCQUN6SCx1QkFBQyxTQUFJLFdBQVUsWUFBWUgsZUFBS2dFLFVBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVDO0FBQUEsbUJBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsYUFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHFCQUNYO0FBQUEsaUNBQUMsUUFBRyxXQUFVLFlBQVlwRCxnQ0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxVQUM3Qyx1QkFBQyxPQUFFLFdBQVUsV0FBVSwyREFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxVQUVsRSx1QkFBQyxTQUFJLFdBQVUsc0JBQ1g7QUFBQSxtQ0FBQyxZQUFPLFdBQVUsa0JBQWlCLHFCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QztBQUFBLFlBQ3hDLHVCQUFDLFlBQU8sV0FBVSxXQUFVLHFCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQ2pDLHVCQUFDLFlBQU8sV0FBVSxXQUFVLDZCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBLFlBQ3pDLHVCQUFDLFlBQU8sV0FBVSxXQUFVLHFCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQ2pDLHVCQUFDLFlBQU8sV0FBVSxXQUFVLHdCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLGVBTHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUVDUixVQUFVZ0UsWUFDUCx1QkFBQyxnQkFBYSxNQUFNLEdBQUcsV0FBVyxPQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQyxJQUV0Qyx1QkFBQyxTQUFJLFdBQVUsV0FDVnBELHVCQUFhbUM7QUFBQUEsWUFBSSxDQUFDWCxZQUNmO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUcsV0FBVTtBQUFBLGdCQUNWLFNBQVMsTUFBTXpDLG1CQUFtQnlDLE9BQU87QUFBQSxnQkFDekMsV0FBVyxDQUFDTSxNQUFNO0FBQ2Qsc0JBQUlBLEVBQUV1QixRQUFRLFdBQVd2QixFQUFFdUIsUUFBUSxLQUFLO0FBQ3BDdkIsc0JBQUV3QixlQUFlO0FBQ2pCdkUsdUNBQW1CeUMsT0FBTztBQUFBLGtCQUM5QjtBQUFBLGdCQUNKO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLFVBQVU7QUFBQSxnQkFFVjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLEtBQUtBLFFBQVErQixZQUFZO0FBQUEsc0JBQ3pCLEtBQUsvQixRQUFRekI7QUFBQUEsc0JBQ2IsV0FBVTtBQUFBO0FBQUEsb0JBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUcyQjtBQUFBLGtCQUUzQix1QkFBQyxTQUFJLFdBQVUsZ0JBQ1g7QUFBQSwyQ0FBQyxTQUNHO0FBQUEsNkNBQUMsUUFBRyxPQUFPLEVBQUV5QyxRQUFRLGFBQWFJLFVBQVUsV0FBV0MsT0FBTyxRQUFRQyxZQUFZLE9BQU8sR0FDcEZ0QixrQkFBUXpCLFFBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFNkMsVUFBVSxXQUFXQyxPQUFPLFFBQVFSLFNBQVMsZUFBZW1CLGlCQUFpQixHQUFHQyxpQkFBaUIsWUFBWUMsVUFBVSxTQUFTLEdBQ3pJbEMsa0JBQVFtQyxlQUFlLE9BRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU9BO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUV0QixTQUFTLFFBQVFhLGdCQUFnQixpQkFBaUJaLFlBQVksVUFBVXNCLFdBQVcsR0FBRyxHQUNoRztBQUFBLDZDQUFDLFNBQUksT0FBTyxFQUFFZixPQUFPLFdBQVdDLFlBQVksUUFBUUYsVUFBVSxPQUFPLEdBQ2hFOUUsb0JBQVUwRCxRQUFRcUMsU0FBUyxLQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsWUFBTyxXQUFVLG1CQUFrQiw0QkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSx1QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQTtBQUFBO0FBQUEsY0FsQ0tyQyxRQUFRN0I7QUFBQUEsY0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW9DQTtBQUFBLFVBQ0gsS0F2Q0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3Q0E7QUFBQSxVQUdKLHVCQUFDLFNBQUksV0FBVSxrQkFDWDtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFMEMsU0FBUyxRQUFRRSxLQUFLLElBQUlELFlBQVksU0FBUyxHQUN6RDtBQUFBLHFDQUFDLFVBQUssT0FBTyxFQUFFTSxVQUFVLFVBQVVDLE9BQU8sVUFBVSxHQUFHLGlCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGNBQ3hELHVCQUFDLFNBQUk7QUFBQTtBQUFBLGdCQUF1Qix1QkFBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1CO0FBQUEsbUJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdEO0FBQUEsaUJBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFUixTQUFTLFFBQVFFLEtBQUssSUFBSUQsWUFBWSxTQUFTLEdBQ3pEO0FBQUEscUNBQUMsVUFBSyxPQUFPLEVBQUVNLFVBQVUsVUFBVUMsT0FBTyxVQUFVLEdBQUcsa0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsY0FDekQsdUJBQUMsU0FBSTtBQUFBO0FBQUEsZ0JBQWdCLHVCQUFDLFlBQU8sdUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLG1CQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBLGlCQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVIsU0FBUyxRQUFRRSxLQUFLLElBQUlELFlBQVksU0FBUyxHQUN6RDtBQUFBLHFDQUFDLFVBQUssT0FBTyxFQUFFTSxVQUFVLFVBQVVDLE9BQU8sVUFBVSxHQUFHLGtCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGNBQ3pELHVCQUFDLFNBQUk7QUFBQTtBQUFBLGdCQUFvQix1QkFBQyxZQUFPLHFDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUEsbUJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsaUJBRm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQXZFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0VBO0FBQUEsV0EzR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNWdEQsMEJBQWdCRyxNQUFNeUM7QUFBQUEsUUFBSSxDQUFDQyxRQUN4QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUcsTUFBSztBQUFBLFlBQ0wsV0FBVyxrQkFBa0IzQyxzQkFBc0IyQyxJQUFJekMsS0FBSyxXQUFXLEVBQUU7QUFBQSxZQUN6RSxTQUFTLE1BQU1kLG9CQUFvQnVELElBQUl6QyxFQUFFO0FBQUEsWUFFekM7QUFBQSxxQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBLGNBQ2hCLHVCQUFDLFVBQU15QyxjQUFJckMsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBO0FBQUE7QUFBQSxVQU5YcUMsSUFBSXpDO0FBQUFBLFVBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsTUFDSCxLQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLFNBeEpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5SkE7QUFBQSxJQUdDYixtQkFDRztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csU0FBU0E7QUFBQUEsUUFDVCxTQUFTLE1BQU1DLG1CQUFtQixJQUFJO0FBQUEsUUFDdEMsT0FBTzBCO0FBQUFBO0FBQUFBLE1BSFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzJCO0FBQUEsSUFLOUJ2QixjQUNHLHVCQUFDLFNBQU0sT0FBTSxjQUFhLFNBQVMsTUFBTUMsY0FBYyxLQUFLLEdBQ3hELGlDQUFDLFNBQUksT0FBTyxFQUFFMkUsV0FBVyxJQUFJLEdBQ3hCOUUsZUFBS2dFLFdBQVcsSUFDYix1QkFBQyxPQUFFLE9BQU8sRUFBRUQsV0FBVyxVQUFVRixPQUFPLFFBQVFlLFdBQVcsR0FBRyxHQUFHLHNDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVGLElBRXZGLHVCQUFDLFNBQUksT0FBTyxFQUFFdkIsU0FBUyxRQUFRMEIsZUFBZSxVQUFVeEIsS0FBSyxHQUFHLEdBQzNEdkQ7QUFBQUEsV0FBS21EO0FBQUFBLFFBQUksQ0FBQTVCLFNBQ04sdUJBQUMsU0FBa0IsT0FBTyxFQUFFOEIsU0FBUyxRQUFRYSxnQkFBZ0IsaUJBQWlCYyxjQUFjLGtCQUFrQkMsZUFBZSxFQUFFLEdBQzNIO0FBQUEsaUNBQUMsU0FDRztBQUFBLG1DQUFDLFlBQVExRDtBQUFBQSxtQkFBS2tCO0FBQUFBLGNBQVM7QUFBQSxjQUFHbEIsS0FBS2lCLFFBQVF6QjtBQUFBQSxpQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQSxZQUMzQ1EsS0FBS2dCLFNBQVMsdUJBQUMsU0FBSSxPQUFPLEVBQUVxQixVQUFVLFVBQVVDLE9BQU8sT0FBTyxHQUFJdEMsZUFBS2dCLFNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStEO0FBQUEsZUFGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsWUFBTyxPQUFPLEVBQUVzQixPQUFPLFVBQVUsR0FBSS9FLG9CQUFVeUMsS0FBS0MsVUFBVSxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRTtBQUFBLGFBTDNERCxLQUFLWixJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLE1BQ0g7QUFBQSxNQUNELHVCQUFDLFNBQUksT0FBTyxFQUFFMEMsU0FBUyxRQUFRYSxnQkFBZ0IsaUJBQWlCTixVQUFVLFVBQVVFLFlBQVksUUFBUWMsV0FBVyxHQUFHLEdBQ2xIO0FBQUEsK0JBQUMsVUFBSyxxQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNYLHVCQUFDLFVBQUssT0FBTyxFQUFFZixPQUFPLFVBQVUsR0FBSS9FLG9CQUFVc0MsU0FBUyxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsV0FGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csU0FBUTtBQUFBLFVBQ1I7QUFBQSxVQUNBLFNBQVNTLG9CQUFvQnFEO0FBQUFBLFVBQzdCLE9BQU8sRUFBRUMsWUFBWSxXQUFXQyxhQUFhLFdBQVdSLFdBQVcsR0FBRztBQUFBLFVBQ3RFLFNBQVMsTUFBTS9DLG9CQUFvQndELE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUxoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLFNBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkEsS0EzQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZCQSxLQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0JBO0FBQUEsT0FoZFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtkQTtBQUVSO0FBQUNoRyxHQWhqQmVELGlCQUFlO0FBQUEsVUFDVmhCLFdBQ0dHLGdCQUNOWSxVQUM4Qk4sY0FPMUJSLFVBS01BLFVBS0FBLFVBeUJJQyxXQUFXO0FBQUE7QUFBQSxLQTlDM0JjO0FBa2pCaEIsU0FBU2tHLGtCQUFrQjtBQUN2QixTQUNJLHVCQUFDLFNBQUksT0FBTSxNQUFLLFFBQU8sTUFBSyxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxPQUMxRixpQ0FBQyxVQUFLLEdBQUUsK0RBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtRSxLQUR2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFUjtBQUFDQyxNQU5RRDtBQVFULFNBQVNFLGtCQUFrQixFQUFFaEQsU0FBU2lELFNBQVNDLE1BQTJGLEdBQUc7QUFBQUMsTUFBQTtBQUN6SSxRQUFNLENBQUNsRCxVQUFVbUQsV0FBVyxJQUFJMUgsU0FBUyxDQUFDO0FBQzFDLFFBQU0sQ0FBQ3FFLE9BQU9zRCxRQUFRLElBQUkzSCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDNEgsVUFBVUMsV0FBVyxJQUFJN0gsU0FBbUMsQ0FBQyxDQUFDO0FBRXJFLFFBQU04SCxTQUFTQSxDQUFDQyxPQUFnQ0MsaUJBQXlCO0FBQ3JFSCxnQkFBWSxDQUFDSSxZQUFZO0FBQ3JCLFlBQU1DLFNBQVNELFFBQVFGLE1BQU10RixFQUFFLEtBQUs7QUFDcEMsWUFBTTBGLFdBQVdKLE1BQU1LLGdCQUFnQjtBQUV2QyxVQUFJRixPQUFPRyxTQUFTTCxZQUFZLEdBQUc7QUFDL0IsZUFBTyxFQUFFLEdBQUdDLFNBQVMsQ0FBQ0YsTUFBTXRGLEVBQUUsR0FBR3lGLE9BQU9uRixPQUFPLENBQUNOLE9BQU9BLE9BQU91RixZQUFZLEVBQUU7QUFBQSxNQUNoRjtBQUNBLFVBQUlHLFNBQVUsUUFBTyxFQUFFLEdBQUdGLFNBQVMsQ0FBQ0YsTUFBTXRGLEVBQUUsR0FBRyxDQUFDdUYsWUFBWSxFQUFFO0FBQzlELFVBQUlFLE9BQU9wQyxVQUFVaUMsTUFBTUssYUFBYyxRQUFPSDtBQUNoRCxhQUFPLEVBQUUsR0FBR0EsU0FBUyxDQUFDRixNQUFNdEYsRUFBRSxHQUFHLENBQUMsR0FBR3lGLFFBQVFGLFlBQVksRUFBRTtBQUFBLElBQy9ELENBQUM7QUFBQSxFQUNMO0FBRUEsUUFBTU0saUJBQWlCQSxDQUFDUCxVQUFtQztBQUN2RCxVQUFNUSxTQUFTWCxTQUFTRyxNQUFNdEYsRUFBRSxLQUFLLElBQUlxRDtBQUN6QyxXQUFPeUMsU0FBU1IsTUFBTVMsZ0JBQWdCRCxTQUFTUixNQUFNSztBQUFBQSxFQUN6RDtBQUVBLFFBQU1LLGVBQWVuRSxRQUFRb0UsaUJBQWlCQyxNQUFNTCxjQUFjO0FBRWxFLFFBQU1NLG1CQUFtQnRFLFFBQVFvRSxpQkFBaUJ2RixPQUFPLENBQUNDLEtBQUsyRSxVQUFVO0FBQ3JFLFVBQU1jLFlBQVlqQixTQUFTRyxNQUFNdEYsRUFBRSxLQUFLO0FBQ3hDLFVBQU1xRyxXQUFXZixNQUFNdkQsWUFDbEJ6QixPQUFPLENBQUNILE1BQU1pRyxVQUFVUixTQUFTekYsRUFBRUgsRUFBRSxDQUFDLEVBQ3RDVSxPQUFPLENBQUM0RixLQUFLbkcsTUFBTW1HLE1BQU1uRyxFQUFFb0csWUFBWSxDQUFDO0FBQzdDLFdBQU81RixNQUFNMEY7QUFBQUEsRUFDakIsR0FBRyxDQUFDO0FBRUosUUFBTUcsYUFBYTNFLFFBQVFxQyxZQUFZaUMsb0JBQW9CckU7QUFFM0QsUUFBTTJFLGdCQUFnQkEsTUFBTTtBQUN4QixVQUFNQyxhQUE2QzdFLFFBQVFvRSxpQkFBaUJVO0FBQUFBLE1BQVEsQ0FBQ3JCLFdBQ2hGSCxTQUFTRyxNQUFNdEYsRUFBRSxLQUFLLElBQUl3QyxJQUFJLENBQUMrQyxrQkFBa0IsRUFBRXFCLG1CQUFtQnRCLE1BQU10RixJQUFJdUYsYUFBYSxFQUFFO0FBQUEsSUFDcEc7QUFFQVIsVUFBTTtBQUFBLE1BQ0YvRSxJQUFJNkcsS0FBS0MsT0FBTyxFQUFFQyxTQUFTLEVBQUUsRUFBRUMsT0FBTyxHQUFHLENBQUM7QUFBQSxNQUMxQ25GO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FGLE9BQU9BLE1BQU1xRixLQUFLO0FBQUEsTUFDbEJsRixhQUFhMkU7QUFBQUEsTUFDYjdGLFlBQVkyRjtBQUFBQSxJQUNoQixDQUFDO0FBQUEsRUFDTDtBQUVBLFNBQ0ksdUJBQUMsU0FBTSxPQUFPM0UsUUFBUXpCLE1BQU0sU0FBa0IsU0FBUSxVQUNsRCxpQ0FBQyxTQUFJLE9BQU8sRUFBRThHLFdBQVcsUUFBUTNFLFdBQVcsUUFBUTRFLGNBQWMsRUFBRSxHQUMvRHRGO0FBQUFBLFlBQVErQixZQUNMLHVCQUFDLFNBQUksS0FBSy9CLFFBQVErQixVQUFVLEtBQUsvQixRQUFRekIsTUFBTSxPQUFPLEVBQUVnSCxPQUFPLFFBQVFDLFFBQVEsS0FBS0MsV0FBVyxTQUFTdEUsY0FBYyxJQUFJTSxjQUFjLEdBQUcsS0FBM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2STtBQUFBLElBRWpKLHVCQUFDLE9BQUUsT0FBTyxFQUFFSixPQUFPLFFBQVFJLGNBQWMsR0FBRyxHQUFJekIsa0JBQVFtQyxlQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9FO0FBQUEsSUFFcEUsdUJBQUMsU0FBSSxPQUFPLEVBQUV0QixTQUFTLFFBQVEwQixlQUFlLFVBQVV4QixLQUFLLEdBQUcsR0FHM0RmO0FBQUFBLGNBQVFvRSxpQkFBaUJ6RCxJQUFJLENBQUM4QyxVQUFVO0FBQ3JDLGNBQU1HLFNBQVNOLFNBQVNHLE1BQU10RixFQUFFLEtBQUs7QUFDckMsY0FBTTBGLFdBQVdKLE1BQU1LLGdCQUFnQjtBQUN2QyxjQUFNNEIsWUFBWTFCLGVBQWVQLEtBQUs7QUFDdEMsY0FBTWtDLG9CQUFvQmxDLE1BQU12RCxZQUFZekIsT0FBTyxDQUFDSCxNQUFNQSxFQUFFc0gsUUFBUTtBQUVwRSxlQUNJLHVCQUFDLFNBQW1CLE9BQU8sRUFBRS9FLFNBQVMsUUFBUUUsS0FBSyxFQUFFLEdBQ2pEO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUVGLFNBQVMsUUFBUWEsZ0JBQWdCLGlCQUFpQlosWUFBWSxXQUFXLEdBQ25GO0FBQUEsbUNBQUMsVUFBSyxPQUFPLEVBQUVRLFlBQVksSUFBSSxHQUFJbUMsZ0JBQU1sRixRQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDLHVCQUFDLFVBQUssT0FBTyxFQUFFNkMsVUFBVSxVQUFVQyxPQUFPcUUsWUFBWSxtQkFBbUIsZ0JBQWdCLEdBQ3BGakMsZ0JBQU1TLGlCQUFpQixJQUNsQixrQkFBa0JULE1BQU1LLFlBQVksS0FDcENMLE1BQU1TLGlCQUFpQlQsTUFBTUssZUFDekIsV0FBV0wsTUFBTVMsWUFBWSxLQUM3QixjQUFjVCxNQUFNUyxZQUFZLE1BQU1ULE1BQU1LLFlBQVksTUFMdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGVBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVqRCxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUNqQzRFLDRCQUFrQmhGLElBQUksQ0FBQ3JDLE1BQU07QUFDMUIsa0JBQU11SCxXQUFXakMsT0FBT0csU0FBU3pGLEVBQUVILEVBQUU7QUFDckMsbUJBQ0k7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFRyxPQUFPO0FBQUEsa0JBQ0gwQyxTQUFTO0FBQUEsa0JBQVFhLGdCQUFnQjtBQUFBLGtCQUFpQlQsU0FBUztBQUFBLGtCQUMzREUsY0FBYztBQUFBLGtCQUFHRCxRQUFRLGFBQWEyRSxXQUFXLFlBQVksTUFBTTtBQUFBLGtCQUNuRUMsUUFBUTtBQUFBLGtCQUFXbkQsWUFBWWtELFdBQVcsNEJBQTRCO0FBQUEsZ0JBQzFFO0FBQUEsZ0JBRUE7QUFBQSx5Q0FBQyxVQUFLLE9BQU8sRUFBRWhGLFNBQVMsUUFBUUUsS0FBSyxFQUFFLEdBQ25DO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csTUFBTThDLFdBQVcsVUFBVTtBQUFBLHdCQUMzQixTQUFTZ0M7QUFBQUEsd0JBQ1QsVUFBVSxNQUFNckMsT0FBT0MsT0FBT25GLEVBQUVILEVBQUU7QUFBQSx3QkFDbEMsT0FBTyxFQUFFNEgsYUFBYSxVQUFVO0FBQUE7QUFBQSxzQkFKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlzQztBQUFBLG9CQUVyQ3pILEVBQUUwSDtBQUFBQSx1QkFQUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUUzRSxPQUFPLFFBQVFELFVBQVUsU0FBUyxHQUM1QzlDLFlBQUVvRyxhQUFhLElBQUksS0FBS3BJLFVBQVVnQyxFQUFFb0csVUFBVSxDQUFDLEtBQUssZUFEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBO0FBQUE7QUFBQSxjQWxCS3BHLEVBQUVIO0FBQUFBLGNBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW9CQTtBQUFBLFVBRVIsQ0FBQyxLQTFCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJCQTtBQUFBLGFBdkNNc0YsTUFBTXRGLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3Q0E7QUFBQSxNQUVSLENBQUM7QUFBQSxNQUVELHVCQUFDLFNBQUksT0FBTyxFQUFFMEMsU0FBUyxRQUFRYSxnQkFBZ0IsaUJBQWlCWixZQUFZLFVBQVU2QixZQUFZLFdBQVcxQixTQUFTLElBQUlFLGNBQWMsR0FBR2lCLFdBQVcsRUFBRSxHQUNwSjtBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFZCxZQUFZLE9BQU8sR0FBRywwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFFBQy9DLHVCQUFDLFNBQUksT0FBTyxFQUFFVCxTQUFTLFFBQVFFLEtBQUssSUFBSUQsWUFBWSxTQUFTLEdBQ3pEO0FBQUEsaUNBQUMsWUFBTyxTQUFTLE1BQU1zQyxZQUFZNEIsS0FBS2lCLElBQUksR0FBR2hHLFdBQVcsQ0FBQyxDQUFDLEdBQUcsT0FBTyxFQUFFc0YsT0FBTyxJQUFJQyxRQUFRLElBQUlyRSxjQUFjLE9BQU9ELFFBQVEsa0JBQWtCeUIsWUFBWSxRQUFRdkIsVUFBVSxTQUFTLEdBQUcsaUJBQXhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlMO0FBQUEsVUFDekwsdUJBQUMsVUFBSyxPQUFPLEVBQUVBLFVBQVUsVUFBVUUsWUFBWSxPQUFPLEdBQUlyQixzQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUU7QUFBQSxVQUNuRSx1QkFBQyxZQUFPLFNBQVMsTUFBTW1ELFlBQVluRCxXQUFXLENBQUMsR0FBRyxPQUFPLEVBQUVzRixPQUFPLElBQUlDLFFBQVEsSUFBSXJFLGNBQWMsT0FBT0QsUUFBUSxxQkFBcUJHLE9BQU8sV0FBV3NCLFlBQVksUUFBUXZCLFVBQVUsU0FBUyxHQUFHLGlCQUFoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpTTtBQUFBLGFBSHJNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csYUFBWTtBQUFBLFVBQ1osT0FBT3JCO0FBQUFBLFVBQ1AsVUFBVSxDQUFDTyxNQUFNK0MsU0FBUy9DLEVBQUU0RixPQUFPQyxLQUFLO0FBQUEsVUFDeEMsT0FBTyxFQUFFWixPQUFPLFFBQVFDLFFBQVEsSUFBSXZFLFNBQVMsSUFBSUUsY0FBYyxHQUFHRCxRQUFRLGtCQUFrQmtGLFlBQVksVUFBVTtBQUFBO0FBQUEsUUFKdEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXdIO0FBQUEsTUFHeEg7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFNBQVE7QUFBQSxVQUNSO0FBQUEsVUFDQSxVQUFVLENBQUNqQztBQUFBQSxVQUNYLFNBQVNTO0FBQUFBLFVBQ1QsT0FBTyxFQUFFakMsWUFBWSxXQUFXQyxhQUFhLFVBQVU7QUFBQSxVQUFFO0FBQUE7QUFBQSxZQUU1Q3RHLFVBQVVxSSxTQUFTO0FBQUE7QUFBQTtBQUFBLFFBUHBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0E5RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStFQTtBQUFBLE9BckZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzRkEsS0F2Rko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdGQTtBQUVSO0FBQUN4QixJQTlJUUgsbUJBQWlCO0FBQUEsTUFBakJBO0FBQWlCLElBQUFxRCxJQUFBdEQsS0FBQXVEO0FBQUEsYUFBQUQsSUFBQTtBQUFBLGFBQUF0RCxLQUFBO0FBQUEsYUFBQXVELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJ1c2VQYXJhbXMiLCJ1c2VRdWVyeSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnlDbGllbnQiLCJnZXRNZW51IiwiZ2V0Q2F0ZWdvcmllcyIsImdldE9wZW5PcmRlcnNCeUJyYW5jaCIsIm9wZW5PcmRlciIsImFkZE9yZGVySXRlbSIsInVzZUF1dGhTdG9yZSIsImZvcm1hdEJSTCIsIkFwaUVycm9yIiwiQnV0dG9uIiwiTW9kYWwiLCJTa2VsZXRvbkxpc3QiLCJ1c2VUb2FzdCIsIkRpZ2l0YWxNZW51UGFnZSIsIl9zIiwibWVzYSIsInF1ZXJ5Q2xpZW50IiwidG9hc3QiLCJjb21wYW55SWQiLCJicmFuY2hJZCIsImVtcGxveWVlSWQiLCJhY3RpdmVDYXRlZ29yeUlkIiwic2V0QWN0aXZlQ2F0ZWdvcnlJZCIsInNlbGVjdGVkUHJvZHVjdCIsInNldFNlbGVjdGVkUHJvZHVjdCIsImNhcnQiLCJzZXRDYXJ0IiwiaXNDYXJ0T3BlbiIsInNldElzQ2FydE9wZW4iLCJtZW51UXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJjYXRlZ29yaWVzUXVlcnkiLCJvcGVuT3JkZXJzUXVlcnkiLCJjdXJyZW50Q2F0ZWdvcnlJZCIsImRhdGEiLCJpZCIsImFjdGl2ZUNhdGVnb3J5TmFtZSIsImZpbmQiLCJjIiwibmFtZSIsImZpbHRlcmVkTWVudSIsImZpbHRlciIsInAiLCJjYXRlZ29yeUlkIiwiY2FydFRvdGFsIiwicmVkdWNlIiwiYWNjIiwiaXRlbSIsInRvdGFsUHJpY2UiLCJoYW5kbGVBZGRUb0NhcnQiLCJwcmV2Iiwic3VjY2VzcyIsImhhbmRsZUNhbGxXYWl0ZXIiLCJzdWJtaXRPcmRlck11dGF0aW9uIiwibXV0YXRpb25GbiIsInRhYmxlSWQiLCJOdW1iZXIiLCJvcmRlcklkIiwiZXhpc3RpbmdPcmRlciIsIm8iLCJkaW5pbmdUYWJsZUlkIiwiY29tYW5kYUlkIiwiZ3Vlc3RDb3VudCIsIm5vdGVzIiwicHJvZHVjdCIsInF1YW50aXR5IiwiY29tcGxlbWVudHMiLCJvblN1Y2Nlc3MiLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uRXJyb3IiLCJlIiwiZXJyb3IiLCJtZXNzYWdlIiwiZmxleCIsIm92ZXJmbG93WSIsIm1hcCIsImNhdCIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwibWFyZ2luIiwicGFkZGluZyIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsImZvbnRTaXplIiwiY29sb3IiLCJmb250V2VpZ2h0IiwidGV4dEFsaWduIiwibGVuZ3RoIiwibWFyZ2luQm90dG9tIiwianVzdGlmeUNvbnRlbnQiLCJ0ZXh0VHJhbnNmb3JtIiwiaXNMb2FkaW5nIiwia2V5IiwicHJldmVudERlZmF1bHQiLCJpbWFnZVVybCIsIldlYmtpdExpbmVDbGFtcCIsIldlYmtpdEJveE9yaWVudCIsIm92ZXJmbG93IiwiZGVzY3JpcHRpb24iLCJtYXJnaW5Ub3AiLCJzYWxlUHJpY2UiLCJtaW5IZWlnaHQiLCJmbGV4RGlyZWN0aW9uIiwiYm9yZGVyQm90dG9tIiwicGFkZGluZ0JvdHRvbSIsImlzUGVuZGluZyIsImJhY2tncm91bmQiLCJib3JkZXJDb2xvciIsIm11dGF0ZSIsIkljb25QbGFjZWhvbGRlciIsIl9jMiIsIlByb2R1Y3RPcmRlck1vZGFsIiwib25DbG9zZSIsIm9uQWRkIiwiX3MyIiwic2V0UXVhbnRpdHkiLCJzZXROb3RlcyIsInNlbGVjdGVkIiwic2V0U2VsZWN0ZWQiLCJ0b2dnbGUiLCJncm91cCIsImNvbXBsZW1lbnRJZCIsImN1cnJlbnQiLCJjaG9zZW4iLCJpc1NpbmdsZSIsIm1heFNlbGVjdGlvbiIsImluY2x1ZGVzIiwiZ3JvdXBTYXRpc2ZpZWQiLCJjb3VudCIsIm1pblNlbGVjdGlvbiIsImFsbFNhdGlzZmllZCIsImNvbXBsZW1lbnRHcm91cHMiLCJldmVyeSIsImNvbXBsZW1lbnRzVG90YWwiLCJjaG9zZW5JZHMiLCJncm91cFN1bSIsInN1bSIsImV4dHJhUHJpY2UiLCJpdGVtVG90YWwiLCJoYW5kbGVDb25maXJtIiwic2VsZWN0aW9ucyIsImZsYXRNYXAiLCJjb21wbGVtZW50R3JvdXBJZCIsIk1hdGgiLCJyYW5kb20iLCJ0b1N0cmluZyIsInN1YnN0ciIsInRyaW0iLCJtYXhIZWlnaHQiLCJwYWRkaW5nUmlnaHQiLCJ3aWR0aCIsImhlaWdodCIsIm9iamVjdEZpdCIsInNhdGlzZmllZCIsImFjdGl2ZUNvbXBsZW1lbnRzIiwiaXNBY3RpdmUiLCJpc0Nob3NlbiIsImN1cnNvciIsImFjY2VudENvbG9yIiwiY29tcGxlbWVudEl0ZW1OYW1lIiwibWF4IiwidGFyZ2V0IiwidmFsdWUiLCJmb250RmFtaWx5IiwiX2MiLCJfYzMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGlnaXRhbE1lbnVQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VRdWVyeSwgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyBnZXRNZW51LCBnZXRDYXRlZ29yaWVzIH0gZnJvbSBcIi4uL2NhdGFsb2cvYXBpXCI7XHJcbmltcG9ydCB7IGdldE9wZW5PcmRlcnNCeUJyYW5jaCwgb3Blbk9yZGVyLCBhZGRPcmRlckl0ZW0gfSBmcm9tIFwiLi4vb3JkZXJzL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBmb3JtYXRCUkwgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHR5cGUgeyBNZW51SXRlbVJlc3BvbnNlLCBPcmRlckl0ZW1Db21wbGVtZW50U2VsZWN0aW9uLCBDb21wbGVtZW50R3JvdXBSZXNwb25zZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uLy4uL3VpL0J1dHRvblwiO1xyXG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gXCIuLi8uLi91aS9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBTa2VsZXRvbkxpc3QgfSBmcm9tIFwiLi4vLi4vdWkvU2tlbGV0b25cIjtcclxuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vLi4vdWkvVG9hc3RcIjtcclxuXHJcbmludGVyZmFjZSBDYXJ0SXRlbSB7XHJcbiAgICBpZDogc3RyaW5nO1xyXG4gICAgcHJvZHVjdDogTWVudUl0ZW1SZXNwb25zZTtcclxuICAgIHF1YW50aXR5OiBudW1iZXI7XHJcbiAgICBub3Rlczogc3RyaW5nO1xyXG4gICAgY29tcGxlbWVudHM6IE9yZGVySXRlbUNvbXBsZW1lbnRTZWxlY3Rpb25bXTtcclxuICAgIHRvdGFsUHJpY2U6IG51bWJlcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIERpZ2l0YWxNZW51UGFnZSgpIHtcclxuICAgIGNvbnN0IHsgbWVzYSB9ID0gdXNlUGFyYW1zKCk7XHJcbiAgICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgICBjb25zdCB7IGNvbXBhbnlJZCwgYnJhbmNoSWQsIGVtcGxveWVlSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG5cclxuICAgIGNvbnN0IFthY3RpdmVDYXRlZ29yeUlkLCBzZXRBY3RpdmVDYXRlZ29yeUlkXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgW3NlbGVjdGVkUHJvZHVjdCwgc2V0U2VsZWN0ZWRQcm9kdWN0XSA9IHVzZVN0YXRlPE1lbnVJdGVtUmVzcG9uc2UgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFtjYXJ0LCBzZXRDYXJ0XSA9IHVzZVN0YXRlPENhcnRJdGVtW10+KFtdKTtcclxuICAgIGNvbnN0IFtpc0NhcnRPcGVuLCBzZXRJc0NhcnRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCBtZW51UXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcIm1lbnVcIiwgY29tcGFueUlkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRNZW51KGNvbXBhbnlJZCA/PyAxKSxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGNhdGVnb3JpZXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgICAgICBxdWVyeUtleTogW1wiY2F0ZWdvcmllc1wiLCBjb21wYW55SWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldENhdGVnb3JpZXMoY29tcGFueUlkID8/IDEpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3Qgb3Blbk9yZGVyc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgICAgIHF1ZXJ5S2V5OiBbXCJvcmRlcnNcIiwgXCJvcGVuXCIsIGJyYW5jaElkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRPcGVuT3JkZXJzQnlCcmFuY2goYnJhbmNoSWQgPz8gMSksXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBjdXJyZW50Q2F0ZWdvcnlJZCA9IGFjdGl2ZUNhdGVnb3J5SWQgPz8gY2F0ZWdvcmllc1F1ZXJ5LmRhdGE/LlswXT8uaWQgPz8gbnVsbDtcclxuICAgIGNvbnN0IGFjdGl2ZUNhdGVnb3J5TmFtZSA9IGNhdGVnb3JpZXNRdWVyeS5kYXRhPy5maW5kKGMgPT4gYy5pZCA9PT0gY3VycmVudENhdGVnb3J5SWQpPy5uYW1lID8/IFwiQ2FyZMOhcGlvXCI7XHJcblxyXG4gICAgY29uc3QgZmlsdGVyZWRNZW51ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFjdXJyZW50Q2F0ZWdvcnlJZCB8fCAhbWVudVF1ZXJ5LmRhdGEpIHJldHVybiBbXTtcclxuICAgICAgICByZXR1cm4gbWVudVF1ZXJ5LmRhdGEuZmlsdGVyKChwKSA9PiBwLmNhdGVnb3J5SWQgPT09IGN1cnJlbnRDYXRlZ29yeUlkKTtcclxuICAgIH0sIFttZW51UXVlcnkuZGF0YSwgY3VycmVudENhdGVnb3J5SWRdKTtcclxuXHJcbiAgICBjb25zdCBjYXJ0VG90YWwgPSBjYXJ0LnJlZHVjZSgoYWNjLCBpdGVtKSA9PiBhY2MgKyBpdGVtLnRvdGFsUHJpY2UsIDApO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUFkZFRvQ2FydCA9IChpdGVtOiBDYXJ0SXRlbSkgPT4ge1xyXG4gICAgICAgIHNldENhcnQoKHByZXYpID0+IFsuLi5wcmV2LCBpdGVtXSk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRQcm9kdWN0KG51bGwpO1xyXG4gICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJJdGVtIGFkaWNpb25hZG8gYW8gcGVkaWRvIVwiKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2FsbFdhaXRlciA9ICgpID0+IHtcclxuICAgICAgICB0b2FzdC5zdWNjZXNzKFwiR2Fyw6dvbSBjaGFtYWRvIHBhcmEgYSBtZXNhIFwiICsgbWVzYSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHN1Ym1pdE9yZGVyTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCB0YWJsZUlkID0gTnVtYmVyKG1lc2EpO1xyXG4gICAgICAgICAgICBsZXQgb3JkZXJJZDogbnVtYmVyO1xyXG5cclxuICAgICAgICAgICAgLy8gVmVyaWZpY2Egc2UgasOhIGV4aXN0ZSB1bSBwZWRpZG8gZW0gYWJlcnRvIG5hIG1lc2FcclxuICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdPcmRlciA9IG9wZW5PcmRlcnNRdWVyeS5kYXRhPy5maW5kKChvKSA9PiBvLmRpbmluZ1RhYmxlSWQgPT09IHRhYmxlSWQpO1xyXG5cclxuICAgICAgICAgICAgaWYgKGV4aXN0aW5nT3JkZXIpIHtcclxuICAgICAgICAgICAgICAgIG9yZGVySWQgPSBleGlzdGluZ09yZGVyLmlkO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy8gU2UgbsOjbyBob3V2ZXIgcGVkaWRvLCBhYnJlIHVtIG5vdm8gY29tIGFzIGNvbmZpZ3VyYcOnw7VlcyBwYWRyw6NvXHJcbiAgICAgICAgICAgICAgICBvcmRlcklkID0gYXdhaXQgb3Blbk9yZGVyKHtcclxuICAgICAgICAgICAgICAgICAgICBicmFuY2hJZDogYnJhbmNoSWQgPz8gMSxcclxuICAgICAgICAgICAgICAgICAgICBkaW5pbmdUYWJsZUlkOiB0YWJsZUlkLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbWFuZGFJZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBlbXBsb3llZUlkOiBlbXBsb3llZUlkID8/IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgZ3Vlc3RDb3VudDogMSwgLy8gQXNzdW1lIDEgcGVzc29hIGluaWNpYWxtZW50ZSBubyBhdXRvYXRlbmRpbWVudG9cclxuICAgICAgICAgICAgICAgICAgICBub3RlczogXCJBYmVydG8gdmlhIENhcmTDoXBpbyBEaWdpdGFsXCIsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gQWRpY2lvbmEgb3MgaXRlbnMgZG8gY2FycmluaG8gYW8gcGVkaWRvXHJcbiAgICAgICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBjYXJ0KSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhZGRPcmRlckl0ZW0oXHJcbiAgICAgICAgICAgICAgICAgICAgb3JkZXJJZCxcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLnByb2R1Y3QuaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5xdWFudGl0eSxcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLm5vdGVzLFxyXG4gICAgICAgICAgICAgICAgICAgIGVtcGxveWVlSWQgPz8gMSxcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLmNvbXBsZW1lbnRzXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIlBlZGlkbyBlbnZpYWRvIHBhcmEgYSBjb3ppbmhhIVwiKTtcclxuICAgICAgICAgICAgc2V0Q2FydChbXSk7XHJcbiAgICAgICAgICAgIHNldElzQ2FydE9wZW4oZmFsc2UpO1xyXG4gICAgICAgICAgICBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJvcmRlcnNcIl0gfSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiAoZSkgPT4ge1xyXG4gICAgICAgICAgICB0b2FzdC5lcnJvcihlIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkZhbGhhIGFvIGVudmlhciBvIHBlZGlkby5cIik7XHJcbiAgICAgICAgfSxcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPHN0eWxlPntgXHJcbiAgICAgICAgLmRtLWxheW91dCB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAxMDB2aDtcclxuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZjtcclxuICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC5kbS1zaWRlYmFyIHtcclxuICAgICAgICAgIHdpZHRoOiAyODBweDtcclxuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMxMTExMTE7XHJcbiAgICAgICAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgICAgZmxleC1zaHJpbms6IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC5kbS1sb2dvLWNvbnRhaW5lciB7XHJcbiAgICAgICAgICBwYWRkaW5nOiAzMHB4IDI0cHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC5kbS1sb2dvIHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMi4ycmVtO1xyXG4gICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICBsZXR0ZXItc3BhY2luZzogLTFweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgLmRtLWxvZ28gc3BhbiB7XHJcbiAgICAgICAgICBjb2xvcjogI2ZmNmIwMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgLmRtLXN1YnRpdGxlIHtcclxuICAgICAgICAgIGNvbG9yOiAjZmY2YjAwO1xyXG4gICAgICAgICAgZm9udC1zaXplOiAwLjY1cmVtO1xyXG4gICAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcclxuICAgICAgICAgIG1hcmdpbi10b3A6IDRweDtcclxuICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5kbS1uYXYtaXRlbSB7XHJcbiAgICAgICAgICBwYWRkaW5nOiAxNnB4IDI0cHg7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICBib3JkZXItbGVmdDogNHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgdHJhbnNpdGlvbjogYWxsIDAuMnM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kbS1uYXYtaXRlbS5hY3RpdmUge1xyXG4gICAgICAgICAgY29sb3I6ICNmZjZiMDA7XHJcbiAgICAgICAgICBib3JkZXItbGVmdC1jb2xvcjogI2ZmNmIwMDtcclxuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMjU1LCAxMDcsIDAsIDAuMDUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmRtLW1haW4ge1xyXG4gICAgICAgICAgZmxleDogMTtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5kbS1oZWFkZXItZGVza3RvcCB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcclxuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICBwYWRkaW5nOiAyNHB4IDQwcHg7XHJcbiAgICAgICAgICBnYXA6IDIwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuZG0taGVhZGVyLW1vYmlsZSB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzExMTExMTtcclxuICAgICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgICAgcGFkZGluZzogNDBweCAyMHB4IDIwcHggMjBweDtcclxuICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuZG0tYnRuLW91dGxpbmUge1xyXG4gICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2ZmNmIwMDtcclxuICAgICAgICAgIGNvbG9yOiAjZmY2YjAwO1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgICAgICAgcGFkZGluZzogOHB4IDE2cHg7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMC44NXJlbTtcclxuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgZ2FwOiA4cHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuZG0tYnRuLW91dGxpbmUuZGFyay10ZXh0IHtcclxuICAgICAgICAgIGNvbG9yOiAjMTExMTExO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAuZG0tYmFkZ2Uge1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmNmIwMDtcclxuICAgICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgd2lkdGg6IDIwcHg7XHJcbiAgICAgICAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgZm9udC1zaXplOiAwLjc1cmVtO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmRtLWNvbnRlbnQtc2Nyb2xsIHtcclxuICAgICAgICAgIGZsZXg6IDE7XHJcbiAgICAgICAgICBvdmVyZmxvdy15OiBhdXRvO1xyXG4gICAgICAgICAgcGFkZGluZzogMCA0MHB4IDQwcHggNDBweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5kbS10aXRsZSB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDJyZW07XHJcbiAgICAgICAgICBmb250LXdlaWdodDogODAwO1xyXG4gICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgIG1hcmdpbjogMCAwIDRweCAwO1xyXG4gICAgICAgICAgY29sb3I6ICMxMTExMTE7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuZG0tZGVzYyB7XHJcbiAgICAgICAgICBjb2xvcjogIzY2NjY2NjtcclxuICAgICAgICAgIG1hcmdpbjogMCAwIDI0cHggMDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMC45NXJlbTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5kbS1waWxscy1jb250YWluZXIge1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGdhcDogMTJweDtcclxuICAgICAgICAgIG92ZXJmbG93LXg6IGF1dG87XHJcbiAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMjRweDtcclxuICAgICAgICAgIHNjcm9sbGJhci13aWR0aDogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmRtLXBpbGxzLWNvbnRhaW5lcjo6LXdlYmtpdC1zY3JvbGxiYXIgeyBkaXNwbGF5OiBub25lOyB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgLmRtLXBpbGwge1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcclxuICAgICAgICAgIGNvbG9yOiAjMzMzMzMzO1xyXG4gICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICAgIHBhZGRpbmc6IDhweCAyNHB4O1xyXG4gICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMC44NXJlbTtcclxuICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kbS1waWxsLmFjdGl2ZSB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmY2YjAwO1xyXG4gICAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuZG0tZ3JpZCB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoYXV0by1maWxsLCBtaW5tYXgoMzIwcHgsIDFmcikpO1xyXG4gICAgICAgICAgZ2FwOiAyMHB4O1xyXG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogNDBweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5kbS1jYXJkIHtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmZmZmO1xyXG4gICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2YwZjBmMDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE2cHg7XHJcbiAgICAgICAgICBwYWRkaW5nOiAxNnB4O1xyXG4gICAgICAgICAgZ2FwOiAxNnB4O1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogMCA0cHggMTVweCByZ2JhKDAsIDAsIDAsIDAuMDMpO1xyXG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuMnMsIGJveC1zaGFkb3cgMC4ycztcclxuICAgICAgICB9XHJcbiAgICAgICAgLmRtLWNhcmQ6YWN0aXZlIHtcclxuICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC45OCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuZG0tY2FyZC1pbWcge1xyXG4gICAgICAgICAgd2lkdGg6IDgwcHg7XHJcbiAgICAgICAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgICAgICAgb2JqZWN0LWZpdDogY29udGFpbjtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5kbS1jYXJkLWluZm8ge1xyXG4gICAgICAgICAgZmxleDogMTtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmRtLWNhcmQtYWRkLWJ0biB7XHJcbiAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZmY2YjAwO1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICBjb2xvcjogIzExMTExMTtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICAgICAgICBwYWRkaW5nOiA0cHggMTRweDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMC43NXJlbTtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICBnYXA6IDZweDtcclxuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5kbS1mb290ZXItaW5mbyB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNlZWVlZWU7XHJcbiAgICAgICAgICBwYWRkaW5nLXRvcDogMjRweDtcclxuICAgICAgICAgIGNvbG9yOiAjNjY2NjY2O1xyXG4gICAgICAgICAgZm9udC1zaXplOiAwLjg1cmVtO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuZG0tZm9vdGVyLWluZm8gc3Ryb25nIHtcclxuICAgICAgICAgIGNvbG9yOiAjMTExMTExO1xyXG4gICAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiA0cHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC5kbS1ib3R0b20tbmF2IHtcclxuICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgICAgICAgIC5kbS1sYXlvdXQgeyBmbGV4LWRpcmVjdGlvbjogY29sdW1uOyB9XHJcbiAgICAgICAgICAuZG0tc2lkZWJhciB7IGRpc3BsYXk6IG5vbmU7IH1cclxuICAgICAgICAgIC5kbS1oZWFkZXItZGVza3RvcCB7IGRpc3BsYXk6IG5vbmU7IH1cclxuICAgICAgICAgIC5kbS1oZWFkZXItbW9iaWxlIHsgZGlzcGxheTogZmxleDsgfVxyXG4gICAgICAgICAgLmRtLWNvbnRlbnQtc2Nyb2xsIHsgcGFkZGluZzogMjRweCAyMHB4IDEwMHB4IDIwcHg7IH1cclxuICAgICAgICAgIC5kbS1ncmlkIHsgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnI7IH1cclxuICAgICAgICAgIC5kbS1mb290ZXItaW5mbyB7IGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47IGdhcDogMTZweDsgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuZG0tYm90dG9tLW5hdiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMxMTExMTE7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgICAgICAgICAgYm90dG9tOiAwO1xyXG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgcGFkZGluZzogMTJweCAxNnB4O1xyXG4gICAgICAgICAgICBvdmVyZmxvdy14OiBhdXRvO1xyXG4gICAgICAgICAgICBnYXA6IDI0cHg7XHJcbiAgICAgICAgICAgIHNjcm9sbGJhci13aWR0aDogbm9uZTtcclxuICAgICAgICAgICAgei1pbmRleDogNTA7XHJcbiAgICAgICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjMjIyO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgLmRtLWJvdHRvbS1uYXY6Oi13ZWJraXQtc2Nyb2xsYmFyIHsgZGlzcGxheTogbm9uZTsgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuZG0tYm90dG9tLWl0ZW0ge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBjb2xvcjogIzg4ODg4ODtcclxuICAgICAgICAgICAgbWluLXdpZHRoOiA2MHB4O1xyXG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAuZG0tYm90dG9tLWl0ZW0uYWN0aXZlIHsgY29sb3I6ICNmZjZiMDA7IH1cclxuICAgICAgICAgIC5kbS1ib3R0b20taXRlbSBzdmcgeyBtYXJnaW4tYm90dG9tOiA2cHg7IH1cclxuICAgICAgICAgIC5kbS1ib3R0b20taXRlbSBzcGFuIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAwLjY1cmVtO1xyXG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIGB9PC9zdHlsZT5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZG0tbGF5b3V0XCI+XHJcbiAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwiZG0tc2lkZWJhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZG0tbG9nby1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cImRtLWxvZ29cIj5kaW5nPHNwYW4+LmZvb2Q8L3NwYW4+PC9oMT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkbS1zdWJ0aXRsZVwiPuKAlCBHZXN0w6NvIGludGVsaWdlbnRlIHBhcmEgcmVzdGF1cmFudGVzIOKAlDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgb3ZlcmZsb3dZOiBcImF1dG9cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3JpZXNRdWVyeS5kYXRhPy5tYXAoKGNhdCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Y2F0LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGRtLW5hdi1pdGVtICR7Y3VycmVudENhdGVnb3J5SWQgPT09IGNhdC5pZCA/IFwiYWN0aXZlXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlQ2F0ZWdvcnlJZChjYXQuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uUGxhY2Vob2xkZXIgLz4ge2NhdC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKAujwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbjogXCIyMHB4XCIsIHBhZGRpbmc6IFwiMTZweFwiLCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMzNcIiwgYm9yZGVyUmFkaXVzOiAxMiwgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IFwiMnJlbVwiIH19PvCfm47vuI88L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IFwiMC43NXJlbVwiLCBjb2xvcjogXCIjYWFhXCIgfX0+UEXDh0EgUEVMTyBBUFAgRSBHQU5IRTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiwgY29sb3I6IFwiI2ZmNmIwMFwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiB9fT41JSA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjc1cmVtXCIsIGNvbG9yOiBcIiNhYWFcIiB9fT5ERSBERVNDT05UTyE8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuXHJcbiAgICAgICAgICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJkbS1tYWluXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJkbS1oZWFkZXItZGVza3RvcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHRleHRBbGlnbjogXCJyaWdodFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBjb2xvcjogXCIjZmY2YjAwXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgZm9udFdlaWdodDogXCJib2xkXCIgfX0+TUVTQSB7bWVzYX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgY29sb3I6IFwiIzY2NlwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+Q29udmlkYWRvPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRtLWJ0bi1vdXRsaW5lXCIgb25DbGljaz17aGFuZGxlQ2FsbFdhaXRlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5uO77iPIENIQU1BUiBHQVLDh09NXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRtLWJ0bi1vdXRsaW5lIGRhcmstdGV4dFwiIG9uQ2xpY2s9eygpID0+IHNldElzQ2FydE9wZW4odHJ1ZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+bkiBNRVUgUEVESURPIDxkaXYgY2xhc3NOYW1lPVwiZG0tYmFkZ2VcIj57Y2FydC5sZW5ndGh9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImRtLWhlYWRlci1tb2JpbGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIG1hcmdpbkJvdHRvbTogMjQgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZG0tbG9nb1wiIHN0eWxlPXt7IGNvbG9yOiBcIiNmZmZcIiB9fT5kaW5nPHNwYW4+LmZvb2Q8L3NwYW4+PC9oMT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZG0tc3VidGl0bGVcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIiwgZGlzcGxheTogXCJmbGV4XCIgfX0+R2VzdMOjbyBpbnRlbGlnZW50ZSBwYXJhIHJlc3RhdXJhbnRlczwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGNvbG9yOiBcIiNmZjZiMDBcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIiB9fT5NRVNBIHttZXNhfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgY29sb3I6IFwiI2FhYVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+Q29udmlkYWRvPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRtLWJ0bi1vdXRsaW5lXCIgc3R5bGU9e3sgcGFkZGluZzogXCI2cHggMTJweFwiLCBmb250U2l6ZTogXCIwLjc1cmVtXCIgfX0gb25DbGljaz17aGFuZGxlQ2FsbFdhaXRlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCfm47vuI9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRtLWJ0bi1vdXRsaW5lXCIgc3R5bGU9e3sgY29sb3I6IFwiI2ZmZlwiLCBwYWRkaW5nOiBcIjZweCAxMnB4XCIsIGZvbnRTaXplOiBcIjAuNzVyZW1cIiB9fSBvbkNsaWNrPXsoKSA9PiBzZXRJc0NhcnRPcGVuKHRydWUpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+bkiBNRVUgUEVESURPIDxkaXYgY2xhc3NOYW1lPVwiZG0tYmFkZ2VcIj57Y2FydC5sZW5ndGh9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9oZWFkZXI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZG0tY29udGVudC1zY3JvbGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRtLXRpdGxlXCI+e2FjdGl2ZUNhdGVnb3J5TmFtZX08L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJkbS1kZXNjXCI+UmVmcmVzY8OibmNpYSBlIHNhYm9yIHBhcmEgdG9kb3Mgb3MgbW9tZW50b3M8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRtLXBpbGxzLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJkbS1waWxsIGFjdGl2ZVwiPlRPRE9TPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRtLXBpbGxcIj7DgUdVQVM8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZG0tcGlsbFwiPlJFRlJJR0VSQU5URVM8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZG0tcGlsbFwiPlNVQ09TPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRtLXBpbGxcIj5DRVJWRUpBUzwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHttZW51UXVlcnkuaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNrZWxldG9uTGlzdCByb3dzPXs0fSByb3dIZWlnaHQ9ezEyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZG0tZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZE1lbnUubWFwKChwcm9kdWN0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17cHJvZHVjdC5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRtLWNhcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRQcm9kdWN0KHByb2R1Y3QpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiIHx8IGUua2V5ID09PSBcIiBcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUHJvZHVjdChwcm9kdWN0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm9sZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJJbmRleD17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17cHJvZHVjdC5pbWFnZVVybCB8fCBcImh0dHBzOi8vdmlhLnBsYWNlaG9sZGVyLmNvbS84MHgxMDA/dGV4dD1TZW0rRm90b1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17cHJvZHVjdC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRtLWNhcmQtaW1nXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRtLWNhcmQtaW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBzdHlsZT17eyBtYXJnaW46IFwiMCAwIDRweCAwXCIsIGZvbnRTaXplOiBcIjAuOTVyZW1cIiwgY29sb3I6IFwiIzExMVwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IFwiMC43NXJlbVwiLCBjb2xvcjogXCIjODg4XCIsIGRpc3BsYXk6IFwiLXdlYmtpdC1ib3hcIiwgV2Via2l0TGluZUNsYW1wOiAyLCBXZWJraXRCb3hPcmllbnQ6IFwidmVydGljYWxcIiwgb3ZlcmZsb3c6IFwiaGlkZGVuXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdC5kZXNjcmlwdGlvbiB8fCBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIG1hcmdpblRvcDogMTIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgY29sb3I6IFwiI2ZmNmIwMFwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IFwiMXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEJSTChwcm9kdWN0LnNhbGVQcmljZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRtLWNhcmQtYWRkLWJ0blwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+bkiBBRElDSU9OQVJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZG0tZm9vdGVyLWluZm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMS41cmVtXCIsIGNvbG9yOiBcIiNmZjZiMDBcIiB9fT7ij7E8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5URU1QTyBNw4lESU8gREUgUFJFUEFSTyA8c3Ryb25nPjI1IGEgMzUgbWluPC9zdHJvbmc+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMS41cmVtXCIsIGNvbG9yOiBcIiNmZjZiMDBcIiB9fT7wn5u1PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+VEFYQSBERSBFTlRSRUdBIDxzdHJvbmc+UiQgNiw5MDwvc3Ryb25nPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEyLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuNXJlbVwiLCBjb2xvcjogXCIjZmY2YjAwXCIgfX0+8J+Sszwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PkZPUk1BUyBERSBQQUdBTUVOVE8gPHN0cm9uZz5DcsOpZGl0bywgRMOpYml0byBlIFBpeDwvc3Ryb25nPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9tYWluPlxyXG5cclxuICAgICAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZG0tYm90dG9tLW5hdlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yaWVzUXVlcnkuZGF0YT8ubWFwKChjYXQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjYXQuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGRtLWJvdHRvbS1pdGVtICR7Y3VycmVudENhdGVnb3J5SWQgPT09IGNhdC5pZCA/IFwiYWN0aXZlXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVDYXRlZ29yeUlkKGNhdC5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uUGxhY2Vob2xkZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntjYXQubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9uYXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIE1PREFMIERFIFBST0RVVE8gQy8gQ09NUExFTUVOVE9TICovfVxyXG4gICAgICAgICAgICB7c2VsZWN0ZWRQcm9kdWN0ICYmIChcclxuICAgICAgICAgICAgICAgIDxQcm9kdWN0T3JkZXJNb2RhbFxyXG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3Q9e3NlbGVjdGVkUHJvZHVjdH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZFByb2R1Y3QobnVsbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25BZGQ9e2hhbmRsZUFkZFRvQ2FydH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7LyogTU9EQUwgRE8gQ0FSUklOSE8gKi99XHJcbiAgICAgICAgICAgIHtpc0NhcnRPcGVuICYmIChcclxuICAgICAgICAgICAgICAgIDxNb2RhbCB0aXRsZT1cIlNldSBQZWRpZG9cIiBvbkNsb3NlPXsoKSA9PiBzZXRJc0NhcnRPcGVuKGZhbHNlKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtaW5IZWlnaHQ6IDIwMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NhcnQubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiLCBjb2xvcjogXCIjODg4XCIsIG1hcmdpblRvcDogNDAgfX0+U2V1IHBlZGlkbyBlc3TDoSB2YXppby48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXJ0Lm1hcChpdGVtID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0uaWR9IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgI2VlZVwiLCBwYWRkaW5nQm90dG9tOiA4IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPntpdGVtLnF1YW50aXR5fXgge2l0ZW0ucHJvZHVjdC5uYW1lfTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLm5vdGVzICYmIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IFwiMC44cmVtXCIsIGNvbG9yOiBcIiM2NjZcIiB9fT57aXRlbS5ub3Rlc308L2Rpdj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgc3R5bGU9e3sgY29sb3I6IFwiI2ZmNmIwMFwiIH19Pntmb3JtYXRCUkwoaXRlbS50b3RhbFByaWNlKX08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiwgZm9udFdlaWdodDogXCJib2xkXCIsIG1hcmdpblRvcDogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlRvdGFsPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCIjZmY2YjAwXCIgfX0+e2Zvcm1hdEJSTChjYXJ0VG90YWwpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17c3VibWl0T3JkZXJNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwiI2ZmNmIwMFwiLCBib3JkZXJDb2xvcjogXCIjZmY2YjAwXCIsIG1hcmdpblRvcDogMTYgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc3VibWl0T3JkZXJNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbmZpcm1hciBQZWRpZG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8Lz5cclxuICAgICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIEljb25QbGFjZWhvbGRlcigpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPHN2ZyB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjEuNVwiPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwiTTEyIDJ2MjBNMTcgNUg5LjVhMy41IDMuNSAwIDAgMCAwIDdoNWEzLjUgMy41IDAgMCAxIDAgN0g2XCIgLz5cclxuICAgICAgICA8L3N2Zz5cclxuICAgICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFByb2R1Y3RPcmRlck1vZGFsKHsgcHJvZHVjdCwgb25DbG9zZSwgb25BZGQgfTogeyBwcm9kdWN0OiBNZW51SXRlbVJlc3BvbnNlLCBvbkNsb3NlOiAoKSA9PiB2b2lkLCBvbkFkZDogKGl0ZW06IENhcnRJdGVtKSA9PiB2b2lkIH0pIHtcclxuICAgIGNvbnN0IFtxdWFudGl0eSwgc2V0UXVhbnRpdHldID0gdXNlU3RhdGUoMSk7XHJcbiAgICBjb25zdCBbbm90ZXMsIHNldE5vdGVzXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxSZWNvcmQ8bnVtYmVyLCBudW1iZXJbXT4+KHt9KTtcclxuXHJcbiAgICBjb25zdCB0b2dnbGUgPSAoZ3JvdXA6IENvbXBsZW1lbnRHcm91cFJlc3BvbnNlLCBjb21wbGVtZW50SWQ6IG51bWJlcikgPT4ge1xyXG4gICAgICAgIHNldFNlbGVjdGVkKChjdXJyZW50KSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGNob3NlbiA9IGN1cnJlbnRbZ3JvdXAuaWRdID8/IFtdO1xyXG4gICAgICAgICAgICBjb25zdCBpc1NpbmdsZSA9IGdyb3VwLm1heFNlbGVjdGlvbiA8PSAxO1xyXG5cclxuICAgICAgICAgICAgaWYgKGNob3Nlbi5pbmNsdWRlcyhjb21wbGVtZW50SWQpKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5jdXJyZW50LCBbZ3JvdXAuaWRdOiBjaG9zZW4uZmlsdGVyKChpZCkgPT4gaWQgIT09IGNvbXBsZW1lbnRJZCkgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaXNTaW5nbGUpIHJldHVybiB7IC4uLmN1cnJlbnQsIFtncm91cC5pZF06IFtjb21wbGVtZW50SWRdIH07XHJcbiAgICAgICAgICAgIGlmIChjaG9zZW4ubGVuZ3RoID49IGdyb3VwLm1heFNlbGVjdGlvbikgcmV0dXJuIGN1cnJlbnQ7XHJcbiAgICAgICAgICAgIHJldHVybiB7IC4uLmN1cnJlbnQsIFtncm91cC5pZF06IFsuLi5jaG9zZW4sIGNvbXBsZW1lbnRJZF0gfTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgZ3JvdXBTYXRpc2ZpZWQgPSAoZ3JvdXA6IENvbXBsZW1lbnRHcm91cFJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgY29uc3QgY291bnQgPSAoc2VsZWN0ZWRbZ3JvdXAuaWRdID8/IFtdKS5sZW5ndGg7XHJcbiAgICAgICAgcmV0dXJuIGNvdW50ID49IGdyb3VwLm1pblNlbGVjdGlvbiAmJiBjb3VudCA8PSBncm91cC5tYXhTZWxlY3Rpb247XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGFsbFNhdGlzZmllZCA9IHByb2R1Y3QuY29tcGxlbWVudEdyb3Vwcy5ldmVyeShncm91cFNhdGlzZmllZCk7XHJcblxyXG4gICAgY29uc3QgY29tcGxlbWVudHNUb3RhbCA9IHByb2R1Y3QuY29tcGxlbWVudEdyb3Vwcy5yZWR1Y2UoKGFjYywgZ3JvdXApID0+IHtcclxuICAgICAgICBjb25zdCBjaG9zZW5JZHMgPSBzZWxlY3RlZFtncm91cC5pZF0gPz8gW107XHJcbiAgICAgICAgY29uc3QgZ3JvdXBTdW0gPSBncm91cC5jb21wbGVtZW50c1xyXG4gICAgICAgICAgICAuZmlsdGVyKChjKSA9PiBjaG9zZW5JZHMuaW5jbHVkZXMoYy5pZCkpXHJcbiAgICAgICAgICAgIC5yZWR1Y2UoKHN1bSwgYykgPT4gc3VtICsgYy5leHRyYVByaWNlLCAwKTtcclxuICAgICAgICByZXR1cm4gYWNjICsgZ3JvdXBTdW07XHJcbiAgICB9LCAwKTtcclxuXHJcbiAgICBjb25zdCBpdGVtVG90YWwgPSAocHJvZHVjdC5zYWxlUHJpY2UgKyBjb21wbGVtZW50c1RvdGFsKSAqIHF1YW50aXR5O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNvbmZpcm0gPSAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgc2VsZWN0aW9uczogT3JkZXJJdGVtQ29tcGxlbWVudFNlbGVjdGlvbltdID0gcHJvZHVjdC5jb21wbGVtZW50R3JvdXBzLmZsYXRNYXAoKGdyb3VwKSA9PlxyXG4gICAgICAgICAgICAoc2VsZWN0ZWRbZ3JvdXAuaWRdID8/IFtdKS5tYXAoKGNvbXBsZW1lbnRJZCkgPT4gKHsgY29tcGxlbWVudEdyb3VwSWQ6IGdyb3VwLmlkLCBjb21wbGVtZW50SWQgfSkpXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgb25BZGQoe1xyXG4gICAgICAgICAgICBpZDogTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyKDIsIDkpLFxyXG4gICAgICAgICAgICBwcm9kdWN0LFxyXG4gICAgICAgICAgICBxdWFudGl0eSxcclxuICAgICAgICAgICAgbm90ZXM6IG5vdGVzLnRyaW0oKSxcclxuICAgICAgICAgICAgY29tcGxlbWVudHM6IHNlbGVjdGlvbnMsXHJcbiAgICAgICAgICAgIHRvdGFsUHJpY2U6IGl0ZW1Ub3RhbCxcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8TW9kYWwgdGl0bGU9e3Byb2R1Y3QubmFtZX0gb25DbG9zZT17b25DbG9zZX0gdmFyaWFudD1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1heEhlaWdodDogXCI3NXZoXCIsIG92ZXJmbG93WTogXCJhdXRvXCIsIHBhZGRpbmdSaWdodDogNCB9fT5cclxuICAgICAgICAgICAgICAgIHtwcm9kdWN0LmltYWdlVXJsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17cHJvZHVjdC5pbWFnZVVybH0gYWx0PXtwcm9kdWN0Lm5hbWV9IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgaGVpZ2h0OiAyMDAsIG9iamVjdEZpdDogXCJjb3ZlclwiLCBib3JkZXJSYWRpdXM6IDEyLCBtYXJnaW5Cb3R0b206IDE2IH19IC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgY29sb3I6IFwiIzY2NlwiLCBtYXJnaW5Cb3R0b206IDIwIH19Pntwcm9kdWN0LmRlc2NyaXB0aW9ufTwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCBnYXA6IDE2IH19PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogTMOzZ2ljYSBkZSBDb21wbGVtZW50b3Mgbm8gcGFkcsOjbyBTeW5jQmFyICovfVxyXG4gICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0LmNvbXBsZW1lbnRHcm91cHMubWFwKChncm91cCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjaG9zZW4gPSBzZWxlY3RlZFtncm91cC5pZF0gPz8gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2luZ2xlID0gZ3JvdXAubWF4U2VsZWN0aW9uIDw9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNhdGlzZmllZCA9IGdyb3VwU2F0aXNmaWVkKGdyb3VwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYWN0aXZlQ29tcGxlbWVudHMgPSBncm91cC5jb21wbGVtZW50cy5maWx0ZXIoKGMpID0+IGMuaXNBY3RpdmUpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtncm91cC5pZH0gc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiYmFzZWxpbmVcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19Pntncm91cC5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44cmVtXCIsIGNvbG9yOiBzYXRpc2ZpZWQgPyBcInZhcigtLWluay1kaW0pXCIgOiBcInZhcigtLWRhbmdlcilcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5taW5TZWxlY3Rpb24gPT09IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGBvcGNpb25hbCDCtyBhdMOpICR7Z3JvdXAubWF4U2VsZWN0aW9ufWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGdyb3VwLm1pblNlbGVjdGlvbiA9PT0gZ3JvdXAubWF4U2VsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYGVzY29saGEgJHtncm91cC5taW5TZWxlY3Rpb259YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGBlc2NvbGhhIGRlICR7Z3JvdXAubWluU2VsZWN0aW9ufSBhICR7Z3JvdXAubWF4U2VsZWN0aW9ufWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA2IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlQ29tcGxlbWVudHMubWFwKChjKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0Nob3NlbiA9IGNob3Nlbi5pbmNsdWRlcyhjLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Yy5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIHBhZGRpbmc6IFwiMTBweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA4LCBib3JkZXI6IGAxcHggc29saWQgJHtpc0Nob3NlbiA/IFwiI2ZmNmIwMFwiIDogXCIjZWVlXCJ9YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvcjogXCJwb2ludGVyXCIsIGJhY2tncm91bmQ6IGlzQ2hvc2VuID8gXCJyZ2JhKDI1NSwgMTA3LCAwLCAwLjA1KVwiIDogXCIjZmZmXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPXtpc1NpbmdsZSA/IFwicmFkaW9cIiA6IFwiY2hlY2tib3hcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtpc0Nob3Nlbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gdG9nZ2xlKGdyb3VwLCBjLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBhY2NlbnRDb2xvcjogXCIjZmY2YjAwXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Yy5jb21wbGVtZW50SXRlbU5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwiIzg4OFwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjLmV4dHJhUHJpY2UgPiAwID8gYCsgJHtmb3JtYXRCUkwoYy5leHRyYVByaWNlKX1gIDogXCJzZW0gY3VzdG9cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGJhY2tncm91bmQ6IFwiI2Y5ZjlmOVwiLCBwYWRkaW5nOiAxMiwgYm9yZGVyUmFkaXVzOiA4LCBtYXJnaW5Ub3A6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IFwiYm9sZFwiIH19PlF1YW50aWRhZGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTYsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFF1YW50aXR5KE1hdGgubWF4KDEsIHF1YW50aXR5IC0gMSkpfSBzdHlsZT17eyB3aWR0aDogMzIsIGhlaWdodDogMzIsIGJvcmRlclJhZGl1czogXCI1MCVcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjY2NjXCIsIGJhY2tncm91bmQ6IFwiI2ZmZlwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT4tPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiwgZm9udFdlaWdodDogXCJib2xkXCIgfX0+e3F1YW50aXR5fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0UXVhbnRpdHkocXVhbnRpdHkgKyAxKX0gc3R5bGU9e3sgd2lkdGg6IDMyLCBoZWlnaHQ6IDMyLCBib3JkZXJSYWRpdXM6IFwiNTAlXCIsIGJvcmRlcjogXCIxcHggc29saWQgI2ZmNmIwMFwiLCBjb2xvcjogXCIjZmY2YjAwXCIsIGJhY2tncm91bmQ6IFwiI2ZmZlwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT4rPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbGd1bWEgb2JzZXJ2YcOnw6NvPyAoRXg6IFNlbSBnZWxvKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtub3Rlc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROb3RlcyhlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgaGVpZ2h0OiA4MCwgcGFkZGluZzogMTIsIGJvcmRlclJhZGl1czogOCwgYm9yZGVyOiBcIjFweCBzb2xpZCAjZGRkXCIsIGZvbnRGYW1pbHk6IFwiaW5oZXJpdFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshYWxsU2F0aXNmaWVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb25maXJtfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcIiNmZjZiMDBcIiwgYm9yZGVyQ29sb3I6IFwiI2ZmNmIwMFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBZGljaW9uYXIg4oCiIHtmb3JtYXRCUkwoaXRlbVRvdGFsKX1cclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9kaWdpdGFsbWVudS9EaWdpdGFsTWVudVBhZ2UudHN4In0=