import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/employees/EmployeesPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { useDialog } from "/src/ui/Dialog.tsx";
import {
  createEmployee,
  createJobTitle,
  dismissEmployee,
  getEmployeesByBranch,
  getJobTitles,
  registerTeamMember,
  updateEmployee
} from "/src/features/employees/api.ts";
import { getFeatures, getJobTitleFeatures, getUserFeatures, setUserFeatures } from "/src/features/access/api.ts";
import { deactivateUser } from "/src/features/users/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { formatBRL } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { Button } from "/src/ui/Button.tsx";
import { Field, TextField } from "/src/ui/Field.tsx";
import { Switch } from "/src/ui/Switch.tsx";
import { useToast } from "/src/ui/Toast.tsx";
const emptyForm = { jobTitleId: "", name: "", cpf: "", email: "", phone: "", salary: "" };
const emptyAccessForm = { hasSystemAccess: false, userName: "", userEmail: "", password: "" };
const parseNum = (raw) => {
  if (raw.trim() === "") return null;
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) ? value : null;
};
const initialsOf = (name) => name.trim().split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase();
const SearchIcon = () => /* @__PURE__ */ jsxDEV("svg", { width: "15", height: "15", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true", children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "11", cy: "11", r: "7", stroke: "currentColor", strokeWidth: "1.8" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
    lineNumber: 75,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M21 21l-4.3-4.3", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
    lineNumber: 76,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
  lineNumber: 74,
  columnNumber: 1
}, this);
_c = SearchIcon;
const KebabIcon = () => /* @__PURE__ */ jsxDEV("svg", { width: "15", height: "15", viewBox: "0 0 24 24", fill: "currentColor", "aria-hidden": "true", children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "5", r: "1.8" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
    lineNumber: 81,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "1.8" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
    lineNumber: 81,
    columnNumber: 38
  }, this),
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "19", r: "1.8" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
    lineNumber: 81,
    columnNumber: 72
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
  lineNumber: 80,
  columnNumber: 1
}, this);
_c2 = KebabIcon;
const CheckIcon = () => /* @__PURE__ */ jsxDEV("svg", { width: "15", height: "15", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("path", { d: "M4 12l5 5L20 6", stroke: "currentColor", strokeWidth: "2.4", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
  lineNumber: 86,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
  lineNumber: 85,
  columnNumber: 1
}, this);
_c3 = CheckIcon;
const PerfilIcon = () => /* @__PURE__ */ jsxDEV("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true", children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "8", r: "4", stroke: "currentColor", strokeWidth: "2" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
    lineNumber: 91,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M4 20c0-4 3.6-7 8-7s8 3 8 7", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
    lineNumber: 92,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
  lineNumber: 90,
  columnNumber: 1
}, this);
_c4 = PerfilIcon;
export function EmployeesPage() {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const toast = useToast();
  const { branchId, companyId } = useAuthStore();
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState(null);
  const [creatingJobTitle, setCreatingJobTitle] = useState(false);
  const [newJobTitle, setNewJobTitle] = useState("");
  const [access, setAccess] = useState(emptyAccessForm);
  const [extraFeatureIds, setExtraFeatureIds] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [openKebabFor, setOpenKebabFor] = useState(null);
  const [accessDrawerFor, setAccessDrawerFor] = useState(null);
  const [drawerExtras, setDrawerExtras] = useState([]);
  const [drawerLoadedFor, setDrawerLoadedFor] = useState(null);
  const employeesQuery = useQuery({
    queryKey: ["employees", branchId],
    queryFn: () => getEmployeesByBranch(branchId)
  });
  const jobTitlesQuery = useQuery({
    queryKey: ["jobtitles", companyId],
    queryFn: () => getJobTitles(companyId ?? 1)
  });
  const featuresQuery = useQuery({
    queryKey: ["access", "features"],
    queryFn: getFeatures,
    enabled: editing === "new" && access.hasSystemAccess || accessDrawerFor !== null
  });
  const jobTitleIdNum = form.jobTitleId === "" ? null : Number(form.jobTitleId);
  const cargoFeaturesQuery = useQuery({
    queryKey: ["access", "jobtitlefeatures", jobTitleIdNum],
    queryFn: () => getJobTitleFeatures(jobTitleIdNum),
    enabled: editing === "new" && access.hasSystemAccess && jobTitleIdNum !== null
  });
  const cargoFeatureIds = useMemo(() => new Set(cargoFeaturesQuery.data ?? []), [cargoFeaturesQuery.data]);
  const drawerCargoFeaturesQuery = useQuery({
    queryKey: ["access", "jobtitlefeatures", accessDrawerFor?.jobTitleId ?? null],
    queryFn: () => getJobTitleFeatures(accessDrawerFor.jobTitleId),
    enabled: accessDrawerFor !== null
  });
  const drawerCargoFeatureIds = useMemo(
    () => new Set(drawerCargoFeaturesQuery.data ?? []),
    [drawerCargoFeaturesQuery.data]
  );
  const drawerUserFeaturesQuery = useQuery({
    queryKey: ["access", "userfeatures", accessDrawerFor?.appUserId ?? null],
    queryFn: () => getUserFeatures(accessDrawerFor.appUserId),
    enabled: accessDrawerFor !== null && accessDrawerFor.appUserId !== null
  });
  useEffect(() => {
    if (accessDrawerFor !== null && drawerUserFeaturesQuery.data !== void 0 && drawerLoadedFor !== accessDrawerFor.id) {
      setDrawerExtras(drawerUserFeaturesQuery.data);
      setDrawerLoadedFor(accessDrawerFor.id);
    }
  }, [accessDrawerFor, drawerUserFeaturesQuery.data, drawerLoadedFor]);
  useEffect(() => {
    setExtraFeatureIds([]);
  }, [jobTitleIdNum]);
  const jobTitleName = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const j of jobTitlesQuery.data ?? []) map.set(j.id, j.name);
    return map;
  }, [jobTitlesQuery.data]);
  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: ["employees"] });
    void queryClient.invalidateQueries({ queryKey: ["users"] });
    void queryClient.invalidateQueries({ queryKey: ["roles"] });
    void queryClient.invalidateQueries({ queryKey: ["access"] });
  };
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const openEditor = (employee) => {
    setError(null);
    setCreatingJobTitle(false);
    setNewJobTitle("");
    setAccess(emptyAccessForm);
    setExtraFeatureIds([]);
    setEditing(employee);
    if (employee === "new")
      setForm({ ...emptyForm, jobTitleId: String(jobTitlesQuery.data?.[0]?.id ?? "") });
    else
      setForm({
        jobTitleId: String(employee.jobTitleId),
        name: employee.name,
        cpf: employee.cpf,
        email: employee.email ?? "",
        phone: employee.phone ?? "",
        salary: employee.salary === null ? "" : String(employee.salary)
      });
  };
  const toggleSystemAccess = (checked) => setAccess((a) => ({
    ...a,
    hasSystemAccess: checked,
    userEmail: checked && a.userEmail === "" ? form.email.trim() : a.userEmail
  }));
  const saveMutation = useMutation({
    // Retorno unificado como Promise<RegisterTeamMemberResult | undefined> — updateEmployee e
    // createEmployee resolvem em void, mas o TS não infere um tipo único de TData a partir de
    // um corpo com "return" de Promises diferentes; a anotação explícita resolve isso e mantém
    // onSuccess tipado (em vez de cair em "never").
    mutationFn: async () => {
      const shared = {
        jobTitleId: Number(form.jobTitleId),
        name: form.name.trim(),
        email: form.email.trim() === "" ? null : form.email.trim(),
        phone: form.phone.trim() === "" ? null : form.phone.trim(),
        salary: parseNum(form.salary)
      };
      if (editing !== "new") {
        await updateEmployee(editing.id, shared);
        return void 0;
      }
      if (!access.hasSystemAccess) {
        await createEmployee({
          branchId,
          cpf: form.cpf.trim(),
          hiredAt: (/* @__PURE__ */ new Date()).toISOString(),
          ...shared
        });
        return void 0;
      }
      return registerTeamMember(companyId ?? 1, {
        branchId,
        cpf: form.cpf.trim(),
        hiredAt: (/* @__PURE__ */ new Date()).toISOString(),
        ...shared,
        hasSystemAccess: true,
        userName: access.userName.trim(),
        userEmail: access.userEmail.trim(),
        password: access.password,
        extraFeatureIds: extraFeatureIds.length > 0 ? extraFeatureIds : null
      });
    },
    onSuccess: (result) => {
      toast.success(editing === "new" ? "Funcionário cadastrado." : "Funcionário atualizado.");
      if (result && typeof result === "object" && "accessWarning" in result && result.accessWarning) {
        toast.error(result.accessWarning);
      }
      setEditing(null);
      refresh();
    },
    onError: onApiError
  });
  const dismissMutation = useMutation({
    mutationFn: (id) => dismissEmployee(id),
    onSuccess: () => {
      toast.success("Funcionário demitido.");
      refresh();
    },
    onError: onApiError
  });
  const jobTitleMutation = useMutation({
    mutationFn: () => createJobTitle(companyId ?? 1, newJobTitle.trim()),
    onSuccess: (newJobTitleId) => {
      toast.success("Cargo criado.");
      setForm((f) => ({ ...f, jobTitleId: String(newJobTitleId) }));
      setNewJobTitle("");
      setCreatingJobTitle(false);
      setError(null);
      void queryClient.invalidateQueries({ queryKey: ["jobtitles"] });
    },
    onError: onApiError
  });
  const toggleExtraFeature = (featureId) => setExtraFeatureIds(
    (current) => current.includes(featureId) ? current.filter((id) => id !== featureId) : [...current, featureId]
  );
  const accessFieldsValid = !access.hasSystemAccess || access.userName.trim() !== "" && access.userEmail.trim() !== "" && access.password.length >= 8;
  const closeDrawer = () => {
    setAccessDrawerFor(null);
    setDrawerExtras([]);
    setDrawerLoadedFor(null);
    setError(null);
  };
  const toggleDrawerExtra = (featureId) => setDrawerExtras(
    (current) => current.includes(featureId) ? current.filter((id) => id !== featureId) : [...current, featureId]
  );
  const drawerSaveMutation = useMutation({
    mutationFn: () => setUserFeatures(accessDrawerFor.appUserId, drawerExtras),
    onSuccess: () => {
      toast.success("Acessos atualizados.");
      closeDrawer();
      refresh();
    },
    onError: onApiError
  });
  const deactivateLoginMutation = useMutation({
    mutationFn: () => deactivateUser(accessDrawerFor.appUserId),
    onSuccess: () => {
      toast.success("Login desativado — o funcionário continua na equipe.");
      closeDrawer();
      refresh();
    },
    onError: onApiError
  });
  const employees = employeesQuery.data ?? [];
  const withAccessCount = employees.filter((e) => e.hasSystemAccess).length;
  const noLoginCount = employees.length - withAccessCount;
  const filteredEmployees = useMemo(() => {
    let list = employees;
    if (statusFilter === "access") list = list.filter((e) => e.hasSystemAccess);
    if (statusFilter === "no-login") list = list.filter((e) => !e.hasSystemAccess);
    if (search.trim() !== "") {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (e) => e.name.toLowerCase().includes(q) || (jobTitleName.get(e.jobTitleId) ?? "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [employees, statusFilter, search, jobTitleName]);
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1280, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "emp-tabs rise", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "emp-tab is-active", children: "Pessoas" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 364,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/acessos", className: "emp-tab", children: "Cargos e acessos padrão" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 365,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
      lineNumber: 363,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 20, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Equipe" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 370,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)", fontSize: "0.9rem", marginTop: 6, maxWidth: 480 }, children: "Todo mundo que trabalha na casa fica aqui — nem todos precisam de acesso ao sistema." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 371,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 369,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => openEditor("new"), children: "+ Novo funcionário" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 375,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
      lineNumber: 368,
      columnNumber: 7
    }, this),
    error && editing === null && accessDrawerFor === null && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
      lineNumber: 378,
      columnNumber: 65
    }, this),
    employeesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: employeesQuery.error, what: "funcionários" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
      lineNumber: 379,
      columnNumber: 34
    }, this),
    jobTitlesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: jobTitlesQuery.error, what: "cargos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
      lineNumber: 380,
      columnNumber: 34
    }, this),
    !employeesQuery.isLoading && employees.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "emp-toolbar rise rise-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "emp-search", children: [
        /* @__PURE__ */ jsxDEV(SearchIcon, {}, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 385,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            placeholder: "Buscar por nome ou cargo…",
            value: search,
            onChange: (e) => setSearch(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 386,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 384,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "segmented", role: "group", "aria-label": "Filtrar por acesso", children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: statusFilter === "all" ? "is-active" : "", onClick: () => setStatusFilter("all"), children: [
          "Todos · ",
          employees.length
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 393,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: statusFilter === "access" ? "is-active" : "", onClick: () => setStatusFilter("access"), children: [
          "Com acesso · ",
          withAccessCount
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 396,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: statusFilter === "no-login" ? "is-active" : "", onClick: () => setStatusFilter("no-login"), children: [
          "Sem login · ",
          noLoginCount
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 399,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 392,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
      lineNumber: 383,
      columnNumber: 7
    }, this),
    employeesQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 5, rowHeight: 58 }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
      lineNumber: 406,
      columnNumber: 36
    }, this),
    !employeesQuery.isLoading && employees.length === 0 && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: "🧑‍🍳",
        title: "Nenhum funcionário ativo",
        description: "Cadastre a equipe para poder abrir usuários e vincular vendas a um responsável.",
        action: /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => openEditor("new"), children: "+ Novo funcionário" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 414,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 409,
        columnNumber: 7
      },
      this
    ),
    !employeesQuery.isLoading && employees.length > 0 && filteredEmployees.length === 0 && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: "🔍",
        title: "Nenhum funcionário encontrado",
        description: `Nenhum resultado para "${search.trim()}" com o filtro atual.`
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 422,
        columnNumber: 7
      },
      this
    ),
    !employeesQuery.isLoading && filteredEmployees.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "emp-grid rise rise-1", children: filteredEmployees.map(
      (employee) => /* @__PURE__ */ jsxDEV("div", { className: `emp-card ${!employee.hasSystemAccess ? "is-no-login" : ""}`, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "emp-card-top", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "emp-avatar", children: initialsOf(employee.name) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 434,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "emp-name-block", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "emp-name", children: employee.name }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 436,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "emp-role", children: jobTitleName.get(employee.jobTitleId) ?? `Cargo ${employee.jobTitleId}` }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 437,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 435,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `emp-status-pill ${employee.hasSystemAccess ? "is-on" : "is-off"}`, children: [
            /* @__PURE__ */ jsxDEV("span", { className: "emp-status-dot" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 440,
              columnNumber: 19
            }, this),
            employee.hasSystemAccess ? "Acesso ativo" : "Sem login"
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 439,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 433,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "emp-meta", children: [
          "CPF ",
          employee.cpf,
          employee.salary !== null ? ` · ${formatBRL(employee.salary)}` : ""
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 445,
          columnNumber: 15
        }, this),
        employee.hasSystemAccess && /* @__PURE__ */ jsxDEV("div", { className: "emp-chip-row", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "emp-perfil-chip", children: [
            /* @__PURE__ */ jsxDEV(PerfilIcon, {}, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 453,
              columnNumber: 21
            }, this),
            employee.roleName ?? "Perfil"
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 452,
            columnNumber: 19
          }, this),
          employee.extraFeatureCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "emp-extra-chip", children: [
            "+",
            employee.extraFeatureCount,
            " acesso",
            employee.extraFeatureCount > 1 ? "s" : "",
            " extra",
            employee.extraFeatureCount > 1 ? "s" : ""
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 457,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 451,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "emp-card-footer", children: [
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => openEditor(employee), children: "Editar" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 466,
            columnNumber: 17
          }, this),
          employee.hasSystemAccess && /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "sm",
              onClick: () => {
                setError(null);
                setAccessDrawerFor(employee);
              },
              children: "Acessos"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 468,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "ui-spacer" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 478,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "sm",
              iconOnly: true,
              "aria-label": "Mais ações",
              onClick: () => setOpenKebabFor(openKebabFor === employee.id ? null : employee.id),
              children: /* @__PURE__ */ jsxDEV(KebabIcon, {}, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 485,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 479,
              columnNumber: 17
            },
            this
          ),
          openKebabFor === employee.id && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                style: { position: "fixed", inset: 0, zIndex: 4 },
                onClick: () => setOpenKebabFor(null)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 489,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "emp-kebab-menu", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "is-danger",
                onClick: async () => {
                  setOpenKebabFor(null);
                  if (await dialog.confirm({
                    title: "Demitir",
                    message: `Demitir "${employee.name}"? O acesso e o CPF serão liberados.`,
                    confirmLabel: "Demitir",
                    danger: true
                  }))
                    dismissMutation.mutate(employee.id);
                },
                children: "Demitir"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 494,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 493,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 488,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 465,
          columnNumber: 15
        }, this)
      ] }, employee.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 432,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
      lineNumber: 430,
      columnNumber: 7
    }, this),
    editing !== null && /* @__PURE__ */ jsxDEV(Modal, { title: editing === "new" ? "Novo funcionário" : "Editar funcionário", onClose: () => setEditing(null), wide: true, children: [
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Nome",
          value: form.name,
          onChange: (e) => setForm({ ...form, name: e.target.value }),
          autoFocus: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 523,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { alignItems: "end" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "CPF (11 dígitos)",
            inputMode: "numeric",
            maxLength: 11,
            disabled: editing !== "new",
            value: form.cpf,
            onChange: (e) => setForm({ ...form, cpf: e.target.value.replace(/\D/g, "") })
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 535,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 534,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 220 }, children: /* @__PURE__ */ jsxDEV(
          Field,
          {
            label: /* @__PURE__ */ jsxDEV("span", { className: "ui-row", style: { justifyContent: "space-between", width: "100%" }, children: [
              "Cargo",
              !creatingJobTitle && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setCreatingJobTitle(true),
                  style: { background: "transparent", border: "none", color: "var(--amber)", cursor: "pointer", fontSize: "0.8rem", padding: 0 },
                  children: "+ novo cargo"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                  lineNumber: 550,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 547,
              columnNumber: 15
            }, this),
            children: (a11y) => creatingJobTitle ? /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 6 }, children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  ...a11y,
                  type: "text",
                  autoFocus: true,
                  placeholder: "Nome do cargo",
                  value: newJobTitle,
                  onChange: (e) => setNewJobTitle(e.target.value),
                  onKeyDown: (e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      if (newJobTitle.trim() !== "") jobTitleMutation.mutate();
                    } else if (e.key === "Escape") {
                      setCreatingJobTitle(false);
                      setNewJobTitle("");
                    }
                  },
                  style: { flex: 1, minWidth: 0 }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                  lineNumber: 564,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  loading: jobTitleMutation.isPending,
                  disabled: newJobTitle.trim() === "",
                  onClick: () => jobTitleMutation.mutate(),
                  children: "Criar"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                  lineNumber: 582,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  iconOnly: true,
                  "aria-label": "Cancelar criação de cargo",
                  onClick: () => {
                    setCreatingJobTitle(false);
                    setNewJobTitle("");
                  },
                  children: "✕"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                  lineNumber: 590,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 563,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(
              "select",
              {
                ...a11y,
                value: form.jobTitleId,
                onChange: (e) => setForm({ ...form, jobTitleId: e.target.value }),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione o cargo…" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                    lineNumber: 605,
                    columnNumber: 23
                  }, this),
                  (jobTitlesQuery.data ?? []).map(
                    (j) => /* @__PURE__ */ jsxDEV("option", { value: j.id, children: j.name }, j.id, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                      lineNumber: 607,
                      columnNumber: 17
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 600,
                columnNumber: 15
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 545,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 544,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 533,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "E-mail",
            value: form.email,
            onChange: (e) => setForm({ ...form, email: e.target.value })
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 618,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 617,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Telefone",
            value: form.phone,
            onChange: (e) => setForm({ ...form, phone: e.target.value })
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 625,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 624,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 616,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Salário (R$, opcional)",
          inputMode: "decimal",
          value: form.salary,
          onChange: (e) => setForm({ ...form, salary: e.target.value })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 633,
          columnNumber: 11
        },
        this
      ),
      editing === "new" && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, marginTop: 4 }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "emp-divider-label", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "emp-divider-line" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 643,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Acesso ao sistema" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 644,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "emp-divider-line" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 645,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 642,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "emp-toggle-row", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "emp-toggle-copy", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "emp-toggle-title", children: "Este colaborador usa o sistema" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 650,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "emp-toggle-hint", children: "Ative só para quem vai operar o PDV — copa, limpeza e segurança normalmente ficam desligados." }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 651,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 649,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Switch,
            {
              checked: access.hasSystemAccess,
              onChange: toggleSystemAccess,
              label: "Este colaborador usa o sistema"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 655,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 648,
          columnNumber: 15
        }, this),
        access.hasSystemAccess && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14 }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
              TextField,
              {
                label: "Usuário",
                value: access.userName,
                onChange: (e) => setAccess({ ...access, userName: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 666,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 665,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
              TextField,
              {
                label: "E-mail de login",
                value: access.userEmail,
                onChange: (e) => setAccess({ ...access, userEmail: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 673,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 672,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 664,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            TextField,
            {
              label: "Senha (mín. 8 caracteres)",
              type: "password",
              value: access.password,
              onChange: (e) => setAccess({ ...access, password: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 680,
              columnNumber: 19
            },
            this
          ),
          jobTitleIdNum !== null && /* @__PURE__ */ jsxDEV("div", { className: "emp-perfil-auto-card", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "emp-perfil-auto-icon", children: /* @__PURE__ */ jsxDEV(PerfilIcon, {}, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 689,
              columnNumber: 61
            }, this) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 689,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "emp-perfil-auto-copy", children: [
              /* @__PURE__ */ jsxDEV("b", { children: [
                "Perfil: ",
                jobTitleName.get(jobTitleIdNum) ?? "—"
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 691,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Criado automaticamente a partir do cargo — sem passo extra." }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 692,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 690,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 688,
            columnNumber: 13
          }, this),
          featuresQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: featuresQuery.error, what: "as telas" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 697,
            columnNumber: 45
          }, this),
          cargoFeatureIds.size > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "emp-access-group-label", children: "O cargo já libera:" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 701,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "emp-chips-wrap", children: (featuresQuery.data ?? []).filter((f) => cargoFeatureIds.has(f.id)).map(
              (f) => /* @__PURE__ */ jsxDEV("span", { className: "emp-access-chip is-locked", children: [
                /* @__PURE__ */ jsxDEV(CheckIcon, {}, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                  lineNumber: 707,
                  columnNumber: 31
                }, this),
                " ",
                f.name
              ] }, f.id, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 706,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 702,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 700,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "emp-access-group-label", children: "Acessos extras só para esta pessoa" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 715,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "emp-chips-wrap", children: (featuresQuery.data ?? []).filter((f) => !cargoFeatureIds.has(f.id)).map((f) => {
              const on = extraFeatureIds.includes(f.id);
              return /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: `emp-access-chip ${on ? "is-on" : "is-off"}`,
                  onClick: () => toggleExtraFeature(f.id),
                  children: [
                    on && /* @__PURE__ */ jsxDEV(CheckIcon, {}, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                      lineNumber: 728,
                      columnNumber: 38
                    }, this),
                    " ",
                    f.name
                  ]
                },
                f.id,
                true,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                  lineNumber: 722,
                  columnNumber: 21
                },
                this
              );
            }) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 716,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 714,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 663,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 641,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 739,
        columnNumber: 21
      }, this),
      form.jobTitleId === "" && /* @__PURE__ */ jsxDEV("p", { className: "field-hint", style: { margin: 0 }, children: "Selecione um cargo para habilitar o salvar." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 741,
        columnNumber: 9
      }, this),
      editing === "new" && form.cpf.length !== 11 && form.cpf.length > 0 && /* @__PURE__ */ jsxDEV("p", { className: "field-hint", style: { margin: 0 }, children: [
        "CPF precisa de 11 dígitos (",
        form.cpf.length,
        "/11)."
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 746,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          loading: saveMutation.isPending,
          disabled: form.name.trim() === "" || form.jobTitleId === "" || editing === "new" && form.cpf.length !== 11 || !accessFieldsValid,
          onClick: () => saveMutation.mutate(),
          children: "Salvar"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
          lineNumber: 751,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
      lineNumber: 522,
      columnNumber: 7
    }, this),
    accessDrawerFor !== null && /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: `Acessos — ${accessDrawerFor.name}`,
        onClose: closeDrawer,
        variant: "drawer",
        ariaLabel: `Acessos de ${accessDrawerFor.name}`,
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "emp-info-line", children: "O acesso efetivo é a soma do que o cargo já dá com o que for ligado abaixo, só para esta pessoa." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 775,
            columnNumber: 11
          }, this),
          drawerCargoFeaturesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: drawerCargoFeaturesQuery.error, what: "os acessos do cargo" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 779,
            columnNumber: 48
          }, this),
          drawerUserFeaturesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: drawerUserFeaturesQuery.error, what: "os acessos da pessoa" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 780,
            columnNumber: 47
          }, this),
          featuresQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: featuresQuery.error, what: "as telas" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 781,
            columnNumber: 37
          }, this),
          drawerCargoFeatureIds.size > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "emp-access-group-label", style: { marginBottom: 8 }, children: [
              'Já incluso pelo cargo "',
              jobTitleName.get(accessDrawerFor.jobTitleId) ?? "",
              '"'
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 785,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "emp-locked-list", children: (featuresQuery.data ?? []).filter((f) => drawerCargoFeatureIds.has(f.id)).map(
              (f) => /* @__PURE__ */ jsxDEV("div", { className: "emp-locked-row", children: [
                /* @__PURE__ */ jsxDEV(CheckIcon, {}, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                  lineNumber: 793,
                  columnNumber: 23
                }, this),
                " ",
                f.name
              ] }, f.id, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 792,
                columnNumber: 13
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 788,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 784,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "emp-access-group-label", children: "Acessos extras desta pessoa" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 801,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "emp-toggle-list", children: (featuresQuery.data ?? []).filter((f) => !drawerCargoFeatureIds.has(f.id)).map(
              (f) => /* @__PURE__ */ jsxDEV("div", { className: "emp-toggle-item", children: [
                /* @__PURE__ */ jsxDEV("span", { children: f.name }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                  lineNumber: 807,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Switch,
                  {
                    checked: drawerExtras.includes(f.id),
                    onChange: () => toggleDrawerExtra(f.id),
                    label: drawerExtras.includes(f.id) ? `Remover acesso a ${f.name}` : `Conceder acesso a ${f.name}`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                    lineNumber: 808,
                    columnNumber: 21
                  },
                  this
                )
              ] }, f.id, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 806,
                columnNumber: 13
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 802,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 800,
            columnNumber: 11
          }, this),
          error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 818,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "primary",
              block: true,
              loading: drawerSaveMutation.isPending,
              disabled: drawerUserFeaturesQuery.isLoading,
              onClick: () => drawerSaveMutation.mutate(),
              children: "Salvar acessos"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 820,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "emp-danger-row", style: { borderTop: "1px solid var(--line)", paddingTop: 14, marginTop: 2 }, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "emp-danger-copy", children: [
              /* @__PURE__ */ jsxDEV("b", { children: "Desativar login" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 832,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "O funcionário continua na equipe, só perde o acesso ao sistema." }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 833,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
              lineNumber: 831,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "danger",
                size: "sm",
                loading: deactivateLoginMutation.isPending,
                onClick: async () => {
                  if (await dialog.confirm({
                    title: "Desativar login",
                    message: `Desativar o login de "${accessDrawerFor.name}"? O funcionário continua na equipe.`,
                    confirmLabel: "Desativar",
                    danger: true
                  }))
                    deactivateLoginMutation.mutate();
                },
                children: "Desativar"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
                lineNumber: 835,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
            lineNumber: 830,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
        lineNumber: 769,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx",
    lineNumber: 362,
    columnNumber: 5
  }, this);
}
_s(EmployeesPage, "iQ+RM9Z/7C0sYQNdJbKlGFvGfoU=", false, function() {
  return [useQueryClient, useDialog, useToast, useAuthStore, useQuery, useQuery, useQuery, useQuery, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation, useMutation];
});
_c5 = EmployeesPage;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "SearchIcon");
$RefreshReg$(_c2, "KebabIcon");
$RefreshReg$(_c3, "CheckIcon");
$RefreshReg$(_c4, "PerfilIcon");
$RefreshReg$(_c5, "EmployeesPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/employees/EmployeesPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURJLFNBNlpjLFVBN1pkOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZESixTQUFTQSxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFDN0MsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQsU0FBU0MsaUJBQWlCO0FBQzFCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLFNBQVNDLGFBQWFDLHFCQUFxQkMsaUJBQWlCQyx1QkFBdUI7QUFDbkYsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsaUJBQWlCO0FBRTFCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxPQUFPQyxpQkFBaUI7QUFDakMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMsWUFBWSxFQUFFQyxZQUFZLElBQUlDLE1BQU0sSUFBSUMsS0FBSyxJQUFJQyxPQUFPLElBQUlDLE9BQU8sSUFBSUMsUUFBUSxHQUFHO0FBR3hGLE1BQU1DLGtCQUFrQixFQUFFQyxpQkFBaUIsT0FBT0MsVUFBVSxJQUFJQyxXQUFXLElBQUlDLFVBQVUsR0FBRztBQUs1RixNQUFNQyxXQUFXQSxDQUFDQyxRQUErQjtBQUMvQyxNQUFJQSxJQUFJQyxLQUFLLE1BQU0sR0FBSSxRQUFPO0FBQzlCLFFBQU1DLFFBQVFDLE9BQU9ILElBQUlJLFFBQVEsS0FBSyxHQUFHLENBQUM7QUFDMUMsU0FBT0QsT0FBT0UsU0FBU0gsS0FBSyxJQUFJQSxRQUFRO0FBQzFDO0FBRUEsTUFBTUksYUFBYUEsQ0FBQ2pCLFNBQ2xCQSxLQUNHWSxLQUFLLEVBQ0xNLE1BQU0sS0FBSyxFQUNYQyxJQUFJLENBQUNDLE1BQU1BLEVBQUUsQ0FBQyxDQUFDLEVBQ2ZDLE1BQU0sR0FBRyxDQUFDLEVBQ1ZDLEtBQUssRUFBRSxFQUNQQyxZQUFZO0FBR2pCLE1BQU1DLGFBQWFBLE1BQ2pCLHVCQUFDLFNBQUksT0FBTSxNQUFLLFFBQU8sTUFBSyxTQUFRLGFBQVksTUFBSyxRQUFPLGVBQVksUUFDdEU7QUFBQSx5QkFBQyxZQUFPLElBQUcsTUFBSyxJQUFHLE1BQUssR0FBRSxLQUFJLFFBQU8sZ0JBQWUsYUFBWSxTQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFFO0FBQUEsRUFDckUsdUJBQUMsVUFBSyxHQUFFLG1CQUFrQixRQUFPLGdCQUFlLGFBQVksT0FBTSxlQUFjLFdBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUY7QUFBQSxLQUZ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BR0E7QUFDQUMsS0FMSUQ7QUFNTixNQUFNRSxZQUFZQSxNQUNoQix1QkFBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssZ0JBQWUsZUFBWSxRQUM5RTtBQUFBLHlCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsS0FBSSxHQUFFLFNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEI7QUFBQSxFQUFHLHVCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsTUFBSyxHQUFFLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0I7QUFBQSxFQUFHLHVCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsTUFBSyxHQUFFLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0I7QUFBQSxLQURwRztBQUFBO0FBQUE7QUFBQTtBQUFBLE9BRUE7QUFDQUMsTUFKSUQ7QUFLTixNQUFNRSxZQUFZQSxNQUNoQix1QkFBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxlQUFZLFFBQ3RFLGlDQUFDLFVBQUssR0FBRSxrQkFBaUIsUUFBTyxnQkFBZSxhQUFZLE9BQU0sZUFBYyxTQUFRLGdCQUFlLFdBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBNkcsS0FEL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBO0FBQ0FDLE1BSklEO0FBS04sTUFBTUUsYUFBYUEsTUFDakIsdUJBQUMsU0FBSSxPQUFNLE1BQUssUUFBTyxNQUFLLFNBQVEsYUFBWSxNQUFLLFFBQU8sZUFBWSxRQUN0RTtBQUFBLHlCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsS0FBSSxHQUFFLEtBQUksUUFBTyxnQkFBZSxhQUFZLE9BQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBa0U7QUFBQSxFQUNsRSx1QkFBQyxVQUFLLEdBQUUsK0JBQThCLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLGVBQWMsV0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpRztBQUFBLEtBRm5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FHQTtBQUNBQyxNQUxJRDtBQU9DLGdCQUFTRSxnQkFBZ0I7QUFBQUMsS0FBQTtBQUM5QixRQUFNQyxjQUFjOUQsZUFBZTtBQUNuQyxRQUFNK0QsU0FBUzlELFVBQVU7QUFDekIsUUFBTStELFFBQVF2QyxTQUFTO0FBQ3ZCLFFBQU0sRUFBRXdDLFVBQVVDLFVBQVUsSUFBSXBELGFBQWE7QUFDN0MsUUFBTSxDQUFDcUQsU0FBU0MsVUFBVSxJQUFJeEUsU0FBMEMsSUFBSTtBQUM1RSxRQUFNLENBQUN5RSxNQUFNQyxPQUFPLElBQUkxRSxTQUFvQjhCLFNBQVM7QUFDckQsUUFBTSxDQUFDNkMsT0FBT0MsUUFBUSxJQUFJNUUsU0FBd0IsSUFBSTtBQUN0RCxRQUFNLENBQUM2RSxrQkFBa0JDLG1CQUFtQixJQUFJOUUsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQytFLGFBQWFDLGNBQWMsSUFBSWhGLFNBQVMsRUFBRTtBQUtqRCxRQUFNLENBQUNpRixRQUFRQyxTQUFTLElBQUlsRixTQUEwQnFDLGVBQWU7QUFDckUsUUFBTSxDQUFDOEMsaUJBQWlCQyxrQkFBa0IsSUFBSXBGLFNBQW1CLEVBQUU7QUFJbkUsUUFBTSxDQUFDcUYsUUFBUUMsU0FBUyxJQUFJdEYsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3VGLGNBQWNDLGVBQWUsSUFBSXhGLFNBQXVCLEtBQUs7QUFDcEUsUUFBTSxDQUFDeUYsY0FBY0MsZUFBZSxJQUFJMUYsU0FBd0IsSUFBSTtBQUNwRSxRQUFNLENBQUMyRixpQkFBaUJDLGtCQUFrQixJQUFJNUYsU0FBa0MsSUFBSTtBQUNwRixRQUFNLENBQUM2RixjQUFjQyxlQUFlLElBQUk5RixTQUFtQixFQUFFO0FBQzdELFFBQU0sQ0FBQytGLGlCQUFpQkMsa0JBQWtCLElBQUloRyxTQUF3QixJQUFJO0FBRTFFLFFBQU1pRyxpQkFBaUI5RixTQUFTO0FBQUEsSUFDOUIrRixVQUFVLENBQUMsYUFBYTdCLFFBQVE7QUFBQSxJQUNoQzhCLFNBQVNBLE1BQU0xRixxQkFBcUI0RCxRQUFRO0FBQUEsRUFDOUMsQ0FBQztBQUVELFFBQU0rQixpQkFBaUJqRyxTQUFTO0FBQUEsSUFDOUIrRixVQUFVLENBQUMsYUFBYTVCLFNBQVM7QUFBQSxJQUNqQzZCLFNBQVNBLE1BQU16RixhQUFhNEQsYUFBYSxDQUFDO0FBQUEsRUFDNUMsQ0FBQztBQUVELFFBQU0rQixnQkFBZ0JsRyxTQUFTO0FBQUEsSUFDN0IrRixVQUFVLENBQUMsVUFBVSxVQUFVO0FBQUEsSUFDL0JDLFNBQVN0RjtBQUFBQSxJQUNUeUYsU0FBVS9CLFlBQVksU0FBU1UsT0FBTzNDLG1CQUFvQnFELG9CQUFvQjtBQUFBLEVBQ2hGLENBQUM7QUFFRCxRQUFNWSxnQkFBZ0I5QixLQUFLMUMsZUFBZSxLQUFLLE9BQU9lLE9BQU8yQixLQUFLMUMsVUFBVTtBQUk1RSxRQUFNeUUscUJBQXFCckcsU0FBUztBQUFBLElBQ2xDK0YsVUFBVSxDQUFDLFVBQVUsb0JBQW9CSyxhQUFhO0FBQUEsSUFDdERKLFNBQVNBLE1BQU1yRixvQkFBb0J5RixhQUF1QjtBQUFBLElBQzFERCxTQUFTL0IsWUFBWSxTQUFTVSxPQUFPM0MsbUJBQW1CaUUsa0JBQWtCO0FBQUEsRUFDNUUsQ0FBQztBQUNELFFBQU1FLGtCQUFrQjFHLFFBQVEsTUFBTSxJQUFJMkcsSUFBSUYsbUJBQW1CRyxRQUFRLEVBQUUsR0FBRyxDQUFDSCxtQkFBbUJHLElBQUksQ0FBQztBQUd2RyxRQUFNQywyQkFBMkJ6RyxTQUFTO0FBQUEsSUFDeEMrRixVQUFVLENBQUMsVUFBVSxvQkFBb0JQLGlCQUFpQjVELGNBQWMsSUFBSTtBQUFBLElBQzVFb0UsU0FBU0EsTUFBTXJGLG9CQUFvQjZFLGdCQUFpQjVELFVBQVU7QUFBQSxJQUM5RHVFLFNBQVNYLG9CQUFvQjtBQUFBLEVBQy9CLENBQUM7QUFDRCxRQUFNa0Isd0JBQXdCOUc7QUFBQUEsSUFDNUIsTUFBTSxJQUFJMkcsSUFBSUUseUJBQXlCRCxRQUFRLEVBQUU7QUFBQSxJQUNqRCxDQUFDQyx5QkFBeUJELElBQUk7QUFBQSxFQUNoQztBQUNBLFFBQU1HLDBCQUEwQjNHLFNBQVM7QUFBQSxJQUN2QytGLFVBQVUsQ0FBQyxVQUFVLGdCQUFnQlAsaUJBQWlCb0IsYUFBYSxJQUFJO0FBQUEsSUFDdkVaLFNBQVNBLE1BQU1wRixnQkFBZ0I0RSxnQkFBaUJvQixTQUFtQjtBQUFBLElBQ25FVCxTQUFTWCxvQkFBb0IsUUFBUUEsZ0JBQWdCb0IsY0FBYztBQUFBLEVBQ3JFLENBQUM7QUFDRGpILFlBQVUsTUFBTTtBQUNkLFFBQ0U2RixvQkFBb0IsUUFDcEJtQix3QkFBd0JILFNBQVNLLFVBQ2pDakIsb0JBQW9CSixnQkFBZ0JzQixJQUNwQztBQUNBbkIsc0JBQWdCZ0Isd0JBQXdCSCxJQUFJO0FBQzVDWCx5QkFBbUJMLGdCQUFnQnNCLEVBQUU7QUFBQSxJQUN2QztBQUFBLEVBQ0YsR0FBRyxDQUFDdEIsaUJBQWlCbUIsd0JBQXdCSCxNQUFNWixlQUFlLENBQUM7QUFJbkVqRyxZQUFVLE1BQU07QUFDZHNGLHVCQUFtQixFQUFFO0FBQUEsRUFDdkIsR0FBRyxDQUFDbUIsYUFBYSxDQUFDO0FBRWxCLFFBQU1XLGVBQWVuSCxRQUFRLE1BQU07QUFDakMsVUFBTW9ELE1BQU0sb0JBQUlnRSxJQUFvQjtBQUNwQyxlQUFXQyxLQUFLaEIsZUFBZU8sUUFBUSxHQUFJeEQsS0FBSWtFLElBQUlELEVBQUVILElBQUlHLEVBQUVwRixJQUFJO0FBQy9ELFdBQU9tQjtBQUFBQSxFQUNULEdBQUcsQ0FBQ2lELGVBQWVPLElBQUksQ0FBQztBQUV4QixRQUFNVyxVQUFVQSxNQUFNO0FBQ3BCLFNBQUtwRCxZQUFZcUQsa0JBQWtCLEVBQUVyQixVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7QUFDOUQsU0FBS2hDLFlBQVlxRCxrQkFBa0IsRUFBRXJCLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUMxRCxTQUFLaEMsWUFBWXFELGtCQUFrQixFQUFFckIsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzFELFNBQUtoQyxZQUFZcUQsa0JBQWtCLEVBQUVyQixVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7QUFBQSxFQUM3RDtBQUVBLFFBQU1zQixhQUFhQSxDQUFDQyxNQUNsQjdDLFNBQVM2QyxhQUFhdEcsV0FBV3NHLEVBQUVDLFVBQVUsa0JBQWtCO0FBRWpFLFFBQU1DLGFBQWFBLENBQUNDLGFBQXVDO0FBQ3pEaEQsYUFBUyxJQUFJO0FBQ2JFLHdCQUFvQixLQUFLO0FBQ3pCRSxtQkFBZSxFQUFFO0FBQ2pCRSxjQUFVN0MsZUFBZTtBQUN6QitDLHVCQUFtQixFQUFFO0FBQ3JCWixlQUFXb0QsUUFBUTtBQUNuQixRQUFJQSxhQUFhO0FBQ2ZsRCxjQUFRLEVBQUUsR0FBRzVDLFdBQVdDLFlBQVk4RixPQUFPekIsZUFBZU8sT0FBTyxDQUFDLEdBQUdNLE1BQU0sRUFBRSxFQUFFLENBQUM7QUFBQTtBQUVoRnZDLGNBQVE7QUFBQSxRQUNOM0MsWUFBWThGLE9BQU9ELFNBQVM3RixVQUFVO0FBQUEsUUFDdENDLE1BQU00RixTQUFTNUY7QUFBQUEsUUFDZkMsS0FBSzJGLFNBQVMzRjtBQUFBQSxRQUNkQyxPQUFPMEYsU0FBUzFGLFNBQVM7QUFBQSxRQUN6QkMsT0FBT3lGLFNBQVN6RixTQUFTO0FBQUEsUUFDekJDLFFBQVF3RixTQUFTeEYsV0FBVyxPQUFPLEtBQUt5RixPQUFPRCxTQUFTeEYsTUFBTTtBQUFBLE1BQ2hFLENBQUM7QUFBQSxFQUNMO0FBSUEsUUFBTTBGLHFCQUFxQkEsQ0FBQ0MsWUFDMUI3QyxVQUFVLENBQUM4QyxPQUFPO0FBQUEsSUFDaEIsR0FBR0E7QUFBQUEsSUFDSDFGLGlCQUFpQnlGO0FBQUFBLElBQ2pCdkYsV0FBV3VGLFdBQVdDLEVBQUV4RixjQUFjLEtBQUtpQyxLQUFLdkMsTUFBTVUsS0FBSyxJQUFJb0YsRUFBRXhGO0FBQUFBLEVBQ25FLEVBQUU7QUFFSixRQUFNeUYsZUFBZS9ILFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSy9CZ0ksWUFBWSxZQUEyRDtBQUNyRSxZQUFNQyxTQUFTO0FBQUEsUUFDYnBHLFlBQVllLE9BQU8yQixLQUFLMUMsVUFBVTtBQUFBLFFBQ2xDQyxNQUFNeUMsS0FBS3pDLEtBQUtZLEtBQUs7QUFBQSxRQUNyQlYsT0FBT3VDLEtBQUt2QyxNQUFNVSxLQUFLLE1BQU0sS0FBSyxPQUFPNkIsS0FBS3ZDLE1BQU1VLEtBQUs7QUFBQSxRQUN6RFQsT0FBT3NDLEtBQUt0QyxNQUFNUyxLQUFLLE1BQU0sS0FBSyxPQUFPNkIsS0FBS3RDLE1BQU1TLEtBQUs7QUFBQSxRQUN6RFIsUUFBUU0sU0FBUytCLEtBQUtyQyxNQUFNO0FBQUEsTUFDOUI7QUFFQSxVQUFJbUMsWUFBWSxPQUFPO0FBQ3JCLGNBQU0zRCxlQUFnQjJELFFBQTZCMEMsSUFBSWtCLE1BQU07QUFDN0QsZUFBT25CO0FBQUFBLE1BQ1Q7QUFFQSxVQUFJLENBQUMvQixPQUFPM0MsaUJBQWlCO0FBQzNCLGNBQU1oQyxlQUFlO0FBQUEsVUFDbkIrRDtBQUFBQSxVQUNBcEMsS0FBS3dDLEtBQUt4QyxJQUFJVyxLQUFLO0FBQUEsVUFDbkJ3RixVQUFTLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVk7QUFBQSxVQUNoQyxHQUFHSDtBQUFBQSxRQUNMLENBQUM7QUFDRCxlQUFPbkI7QUFBQUEsTUFDVDtBQUVBLGFBQU9yRyxtQkFBbUIyRCxhQUFhLEdBQUc7QUFBQSxRQUN4Q0Q7QUFBQUEsUUFDQXBDLEtBQUt3QyxLQUFLeEMsSUFBSVcsS0FBSztBQUFBLFFBQ25Cd0YsVUFBUyxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZO0FBQUEsUUFDaEMsR0FBR0g7QUFBQUEsUUFDSDdGLGlCQUFpQjtBQUFBLFFBQ2pCQyxVQUFVMEMsT0FBTzFDLFNBQVNLLEtBQUs7QUFBQSxRQUMvQkosV0FBV3lDLE9BQU96QyxVQUFVSSxLQUFLO0FBQUEsUUFDakNILFVBQVV3QyxPQUFPeEM7QUFBQUEsUUFDakIwQyxpQkFBaUJBLGdCQUFnQm9ELFNBQVMsSUFBSXBELGtCQUFrQjtBQUFBLE1BQ2xFLENBQUM7QUFBQSxJQUNIO0FBQUEsSUFDQXFELFdBQVdBLENBQUNDLFdBQVc7QUFDckJyRSxZQUFNc0UsUUFBUW5FLFlBQVksUUFBUSw0QkFBNEIseUJBQXlCO0FBR3ZGLFVBQUlrRSxVQUFVLE9BQU9BLFdBQVcsWUFBWSxtQkFBbUJBLFVBQVVBLE9BQU9FLGVBQWU7QUFDN0Z2RSxjQUFNTyxNQUFNOEQsT0FBT0UsYUFBYTtBQUFBLE1BQ2xDO0FBQ0FuRSxpQkFBVyxJQUFJO0FBQ2Y4QyxjQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0FzQixTQUFTcEI7QUFBQUEsRUFDWCxDQUFDO0FBRUQsUUFBTXFCLGtCQUFrQjNJLFlBQVk7QUFBQSxJQUNsQ2dJLFlBQVlBLENBQUNqQixPQUFlekcsZ0JBQWdCeUcsRUFBRTtBQUFBLElBQzlDdUIsV0FBV0EsTUFBTTtBQUNmcEUsWUFBTXNFLFFBQVEsdUJBQXVCO0FBQ3JDcEIsY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBc0IsU0FBU3BCO0FBQUFBLEVBQ1gsQ0FBQztBQUtELFFBQU1zQixtQkFBbUI1SSxZQUFZO0FBQUEsSUFDbkNnSSxZQUFZQSxNQUFNM0gsZUFBZStELGFBQWEsR0FBR1MsWUFBWW5DLEtBQUssQ0FBQztBQUFBLElBQ25FNEYsV0FBV0EsQ0FBQ08sa0JBQWtCO0FBQzVCM0UsWUFBTXNFLFFBQVEsZUFBZTtBQUM3QmhFLGNBQVEsQ0FBQ3NFLE9BQU8sRUFBRSxHQUFHQSxHQUFHakgsWUFBWThGLE9BQU9rQixhQUFhLEVBQUUsRUFBRTtBQUM1RC9ELHFCQUFlLEVBQUU7QUFDakJGLDBCQUFvQixLQUFLO0FBQ3pCRixlQUFTLElBQUk7QUFDYixXQUFLVixZQUFZcUQsa0JBQWtCLEVBQUVyQixVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7QUFBQSxJQUNoRTtBQUFBLElBQ0EwQyxTQUFTcEI7QUFBQUEsRUFDWCxDQUFDO0FBRUQsUUFBTXlCLHFCQUFxQkEsQ0FBQ0MsY0FDMUI5RDtBQUFBQSxJQUFtQixDQUFDK0QsWUFDbEJBLFFBQVFDLFNBQVNGLFNBQVMsSUFBSUMsUUFBUUUsT0FBTyxDQUFDcEMsT0FBT0EsT0FBT2lDLFNBQVMsSUFBSSxDQUFDLEdBQUdDLFNBQVNELFNBQVM7QUFBQSxFQUNqRztBQUVGLFFBQU1JLG9CQUNKLENBQUNyRSxPQUFPM0MsbUJBQ1AyQyxPQUFPMUMsU0FBU0ssS0FBSyxNQUFNLE1BQU1xQyxPQUFPekMsVUFBVUksS0FBSyxNQUFNLE1BQU1xQyxPQUFPeEMsU0FBUzhGLFVBQVU7QUFHaEcsUUFBTWdCLGNBQWNBLE1BQU07QUFDeEIzRCx1QkFBbUIsSUFBSTtBQUN2QkUsb0JBQWdCLEVBQUU7QUFDbEJFLHVCQUFtQixJQUFJO0FBQ3ZCcEIsYUFBUyxJQUFJO0FBQUEsRUFDZjtBQUNBLFFBQU00RSxvQkFBb0JBLENBQUNOLGNBQ3pCcEQ7QUFBQUEsSUFBZ0IsQ0FBQ3FELFlBQ2ZBLFFBQVFDLFNBQVNGLFNBQVMsSUFBSUMsUUFBUUUsT0FBTyxDQUFDcEMsT0FBT0EsT0FBT2lDLFNBQVMsSUFBSSxDQUFDLEdBQUdDLFNBQVNELFNBQVM7QUFBQSxFQUNqRztBQUNGLFFBQU1PLHFCQUFxQnZKLFlBQVk7QUFBQSxJQUNyQ2dJLFlBQVlBLE1BQU1sSCxnQkFBZ0IyRSxnQkFBaUJvQixXQUFxQmxCLFlBQVk7QUFBQSxJQUNwRjJDLFdBQVdBLE1BQU07QUFDZnBFLFlBQU1zRSxRQUFRLHNCQUFzQjtBQUNwQ2Esa0JBQVk7QUFDWmpDLGNBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQXNCLFNBQVNwQjtBQUFBQSxFQUNYLENBQUM7QUFDRCxRQUFNa0MsMEJBQTBCeEosWUFBWTtBQUFBLElBQzFDZ0ksWUFBWUEsTUFBTWpILGVBQWUwRSxnQkFBaUJvQixTQUFtQjtBQUFBLElBQ3JFeUIsV0FBV0EsTUFBTTtBQUNmcEUsWUFBTXNFLFFBQVEsc0RBQXNEO0FBQ3BFYSxrQkFBWTtBQUNaakMsY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBc0IsU0FBU3BCO0FBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1tQyxZQUFZMUQsZUFBZVUsUUFBUTtBQUN6QyxRQUFNaUQsa0JBQWtCRCxVQUFVTixPQUFPLENBQUM1QixNQUFNQSxFQUFFbkYsZUFBZSxFQUFFaUc7QUFDbkUsUUFBTXNCLGVBQWVGLFVBQVVwQixTQUFTcUI7QUFFeEMsUUFBTUUsb0JBQW9CL0osUUFBUSxNQUFNO0FBQ3RDLFFBQUlnSyxPQUFPSjtBQUNYLFFBQUlwRSxpQkFBaUIsU0FBVXdFLFFBQU9BLEtBQUtWLE9BQU8sQ0FBQzVCLE1BQU1BLEVBQUVuRixlQUFlO0FBQzFFLFFBQUlpRCxpQkFBaUIsV0FBWXdFLFFBQU9BLEtBQUtWLE9BQU8sQ0FBQzVCLE1BQU0sQ0FBQ0EsRUFBRW5GLGVBQWU7QUFDN0UsUUFBSStDLE9BQU96QyxLQUFLLE1BQU0sSUFBSTtBQUN4QixZQUFNb0gsSUFBSTNFLE9BQU96QyxLQUFLLEVBQUVxSCxZQUFZO0FBQ3BDRixhQUFPQSxLQUFLVjtBQUFBQSxRQUNWLENBQUM1QixNQUFNQSxFQUFFekYsS0FBS2lJLFlBQVksRUFBRWIsU0FBU1ksQ0FBQyxNQUFNOUMsYUFBYWdELElBQUl6QyxFQUFFMUYsVUFBVSxLQUFLLElBQUlrSSxZQUFZLEVBQUViLFNBQVNZLENBQUM7QUFBQSxNQUM1RztBQUFBLElBQ0Y7QUFDQSxXQUFPRDtBQUFBQSxFQUNULEdBQUcsQ0FBQ0osV0FBV3BFLGNBQWNGLFFBQVE2QixZQUFZLENBQUM7QUFFbEQsU0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRWlELFNBQVMsSUFBSUMsVUFBVSxNQUFNQyxRQUFRLFNBQVMsR0FDM0Q7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUscUJBQW9CLHVCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJDO0FBQUEsTUFDM0MsdUJBQUMsUUFBSyxJQUFHLFlBQVcsV0FBVSxXQUFVLHVDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsU0FGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVDLFNBQVMsUUFBUUMsWUFBWSxZQUFZQyxnQkFBZ0IsaUJBQWlCQyxLQUFLLElBQUlDLFVBQVUsT0FBTyxHQUNqSTtBQUFBLDZCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsV0FBVSxPQUFPLEVBQUVDLFVBQVUsU0FBUyxHQUFHLHNCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsUUFDN0QsdUJBQUMsT0FBRSxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVVFLFdBQVcsR0FBR1QsVUFBVSxJQUFJLEdBQUcsb0dBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTLE1BQU16QyxXQUFXLEtBQUssR0FBRyxrQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RTtBQUFBLFNBUGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBRUNoRCxTQUFTSixZQUFZLFFBQVFvQixvQkFBb0IsUUFBUSx1QkFBQyxPQUFFLFdBQVUsY0FBY2hCLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDMUZzQixlQUFlNkUsV0FBVyx1QkFBQyxjQUFXLE9BQU83RSxlQUFldEIsT0FBTyxNQUFLLGtCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTREO0FBQUEsSUFDdEZ5QixlQUFlMEUsV0FBVyx1QkFBQyxjQUFXLE9BQU8xRSxlQUFlekIsT0FBTyxNQUFLLFlBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0Q7QUFBQSxJQUVoRixDQUFDc0IsZUFBZThFLGFBQWFwQixVQUFVcEIsU0FBUyxLQUMvQyx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1g7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGFBQVk7QUFBQSxZQUNaLE9BQU9sRDtBQUFBQSxZQUNQLFVBQVUsQ0FBQ29DLE1BQU1uQyxVQUFVbUMsRUFBRXVELE9BQU9uSSxLQUFLO0FBQUE7QUFBQSxVQUgzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHNkM7QUFBQSxXQUwvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUFZLE1BQUssU0FBUSxjQUFXLHNCQUNqRDtBQUFBLCtCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVcwQyxpQkFBaUIsUUFBUSxjQUFjLElBQUksU0FBUyxNQUFNQyxnQkFBZ0IsS0FBSyxHQUFHO0FBQUE7QUFBQSxVQUN4R21FLFVBQVVwQjtBQUFBQSxhQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVdoRCxpQkFBaUIsV0FBVyxjQUFjLElBQUksU0FBUyxNQUFNQyxnQkFBZ0IsUUFBUSxHQUFHO0FBQUE7QUFBQSxVQUN6R29FO0FBQUFBLGFBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBV3JFLGlCQUFpQixhQUFhLGNBQWMsSUFBSSxTQUFTLE1BQU1DLGdCQUFnQixVQUFVLEdBQUc7QUFBQTtBQUFBLFVBQzlHcUU7QUFBQUEsYUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUdENUQsZUFBZThFLGFBQWEsdUJBQUMsZ0JBQWEsTUFBTSxHQUFHLFdBQVcsTUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLElBRWpFLENBQUM5RSxlQUFlOEUsYUFBYXBCLFVBQVVwQixXQUFXLEtBQ2pEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxPQUFNO0FBQUEsUUFDTixhQUFZO0FBQUEsUUFDWixRQUNFLHVCQUFDLFVBQU8sU0FBUSxXQUFVLFNBQVMsTUFBTVosV0FBVyxLQUFLLEdBQUcsa0NBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRRztBQUFBLElBSUosQ0FBQzFCLGVBQWU4RSxhQUFhcEIsVUFBVXBCLFNBQVMsS0FBS3VCLGtCQUFrQnZCLFdBQVcsS0FDakY7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLE9BQU07QUFBQSxRQUNOLGFBQWEsMEJBQTBCbEQsT0FBT3pDLEtBQUssQ0FBQztBQUFBO0FBQUEsTUFIdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzhFO0FBQUEsSUFJL0UsQ0FBQ3FELGVBQWU4RSxhQUFhakIsa0JBQWtCdkIsU0FBUyxLQUN2RCx1QkFBQyxTQUFJLFdBQVUsd0JBQ1p1Qiw0QkFBa0IzRztBQUFBQSxNQUFJLENBQUN5RSxhQUN0Qix1QkFBQyxTQUFJLFdBQVcsWUFBWSxDQUFDQSxTQUFTdEYsa0JBQWtCLGdCQUFnQixFQUFFLElBQ3hFO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGNBQWNXLHFCQUFXMkUsU0FBUzVGLElBQUksS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxVQUN2RCx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsWUFBWTRGLG1CQUFTNUYsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUN6Qyx1QkFBQyxTQUFJLFdBQVUsWUFBWWtGLHVCQUFhZ0QsSUFBSXRDLFNBQVM3RixVQUFVLEtBQUssU0FBUzZGLFNBQVM3RixVQUFVLE1BQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1HO0FBQUEsZUFGckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFXLG1CQUFtQjZGLFNBQVN0RixrQkFBa0IsVUFBVSxRQUFRLElBQy9FO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG9CQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQy9Cc0YsU0FBU3RGLGtCQUFrQixpQkFBaUI7QUFBQSxlQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxZQUFXO0FBQUE7QUFBQSxVQUNuQnNGLFNBQVMzRjtBQUFBQSxVQUNiMkYsU0FBU3hGLFdBQVcsT0FBTyxNQUFNaEIsVUFBVXdHLFNBQVN4RixNQUFNLENBQUMsS0FBSztBQUFBLGFBRm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUN3RixTQUFTdEYsbUJBQ1IsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLG1CQUNkO0FBQUEsbUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBVztBQUFBLFlBQ1ZzRixTQUFTcUQsWUFBWTtBQUFBLGVBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNDckQsU0FBU3NELG9CQUFvQixLQUM1Qix1QkFBQyxVQUFLLFdBQVUsa0JBQWlCO0FBQUE7QUFBQSxZQUM3QnRELFNBQVNzRDtBQUFBQSxZQUFrQjtBQUFBLFlBQVF0RCxTQUFTc0Qsb0JBQW9CLElBQUksTUFBTTtBQUFBLFlBQUc7QUFBQSxZQUM5RXRELFNBQVNzRCxvQkFBb0IsSUFBSSxNQUFNO0FBQUEsZUFGMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFHRix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxpQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFTLE1BQU12RCxXQUFXQyxRQUFRLEdBQUcsc0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsVUFDNURBLFNBQVN0RixtQkFDUjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNO0FBQ2JzQyx5QkFBUyxJQUFJO0FBQ2JnQixtQ0FBbUJnQyxRQUFRO0FBQUEsY0FDN0I7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsVUFFRix1QkFBQyxVQUFLLFdBQVUsZUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUMzQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0w7QUFBQSxjQUNBLGNBQVc7QUFBQSxjQUNYLFNBQVMsTUFBTWxDLGdCQUFnQkQsaUJBQWlCbUMsU0FBU1gsS0FBSyxPQUFPVyxTQUFTWCxFQUFFO0FBQUEsY0FFaEYsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFVO0FBQUE7QUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFDQ3hCLGlCQUFpQm1DLFNBQVNYLE1BQ3pCLG1DQUNFO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLEVBQUVrRSxVQUFVLFNBQVNDLE9BQU8sR0FBR0MsUUFBUSxFQUFFO0FBQUEsZ0JBQ2hELFNBQVMsTUFBTTNGLGdCQUFnQixJQUFJO0FBQUE7QUFBQSxjQUZyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFdUM7QUFBQSxZQUV2Qyx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLFNBQVMsWUFBWTtBQUNuQkEsa0NBQWdCLElBQUk7QUFDcEIsc0JBQ0UsTUFBTXZCLE9BQU9tSCxRQUFRO0FBQUEsb0JBQ25CQyxPQUFPO0FBQUEsb0JBQ1A3RCxTQUFTLFlBQVlFLFNBQVM1RixJQUFJO0FBQUEsb0JBQ2xDd0osY0FBYztBQUFBLG9CQUNkQyxRQUFRO0FBQUEsa0JBQ1YsQ0FBQztBQUVENUMsb0NBQWdCNkMsT0FBTzlELFNBQVNYLEVBQUU7QUFBQSxnQkFDdEM7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxlQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLGFBaERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrREE7QUFBQSxXQW5GaUZXLFNBQVNYLElBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvRkE7QUFBQSxJQUNELEtBdkZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3RkE7QUFBQSxJQUdEMUMsWUFBWSxRQUNYLHVCQUFDLFNBQU0sT0FBT0EsWUFBWSxRQUFRLHFCQUFxQixzQkFBc0IsU0FBUyxNQUFNQyxXQUFXLElBQUksR0FBRyxNQUFJLE1BQ2hIO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLE9BQU9DLEtBQUt6QztBQUFBQSxVQUNaLFVBQVUsQ0FBQ3lGLE1BQU0vQyxRQUFRLEVBQUUsR0FBR0QsTUFBTXpDLE1BQU15RixFQUFFdUQsT0FBT25JLE1BQU0sQ0FBQztBQUFBLFVBQzFELFdBQVM7QUFBQTtBQUFBLFFBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSVc7QUFBQSxNQU1YLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFMEgsWUFBWSxNQUFNLEdBQzdEO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVvQixNQUFNLEdBQUdDLFVBQVUsSUFBSSxHQUNuQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sV0FBVTtBQUFBLFlBQ1YsV0FBVztBQUFBLFlBQ1gsVUFBVXJILFlBQVk7QUFBQSxZQUN0QixPQUFPRSxLQUFLeEM7QUFBQUEsWUFDWixVQUFVLENBQUN3RixNQUFNL0MsUUFBUSxFQUFFLEdBQUdELE1BQU14QyxLQUFLd0YsRUFBRXVELE9BQU9uSSxNQUFNRSxRQUFRLE9BQU8sRUFBRSxFQUFFLENBQUM7QUFBQTtBQUFBLFVBTjlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1nRixLQVBsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFNEksTUFBTSxHQUFHQyxVQUFVLElBQUksR0FDbkM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQ0UsdUJBQUMsVUFBSyxXQUFVLFVBQVMsT0FBTyxFQUFFcEIsZ0JBQWdCLGlCQUFpQnFCLE9BQU8sT0FBTyxHQUFHO0FBQUE7QUFBQSxjQUVqRixDQUFDaEgsb0JBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTUMsb0JBQW9CLElBQUk7QUFBQSxrQkFDdkMsT0FBTyxFQUFFZ0gsWUFBWSxlQUFlQyxRQUFRLFFBQVFuQixPQUFPLGdCQUFnQm9CLFFBQVEsV0FBV3JCLFVBQVUsVUFBVVIsU0FBUyxFQUFFO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUhqSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGlCQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUdELFdBQUM4QixTQUNBcEgsbUJBQ0UsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFNEYsS0FBSyxFQUFFLEdBQ3RDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsR0FBSXdCO0FBQUFBLGtCQUNKLE1BQUs7QUFBQSxrQkFDTDtBQUFBLGtCQUNBLGFBQVk7QUFBQSxrQkFDWixPQUFPbEg7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDMEMsTUFBTXpDLGVBQWV5QyxFQUFFdUQsT0FBT25JLEtBQUs7QUFBQSxrQkFDOUMsV0FBVyxDQUFDNEUsTUFBTTtBQUNoQix3QkFBSUEsRUFBRXlFLFFBQVEsU0FBUztBQUNyQnpFLHdCQUFFMEUsZUFBZTtBQUNqQiwwQkFBSXBILFlBQVluQyxLQUFLLE1BQU0sR0FBSWtHLGtCQUFpQjRDLE9BQU87QUFBQSxvQkFDekQsV0FBV2pFLEVBQUV5RSxRQUFRLFVBQVU7QUFDN0JwSCwwQ0FBb0IsS0FBSztBQUN6QkUscUNBQWUsRUFBRTtBQUFBLG9CQUNuQjtBQUFBLGtCQUNGO0FBQUEsa0JBQ0EsT0FBTyxFQUFFMkcsTUFBTSxHQUFHQyxVQUFVLEVBQUU7QUFBQTtBQUFBLGdCQWhCaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZ0JrQztBQUFBLGNBRWxDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTOUMsaUJBQWlCc0Q7QUFBQUEsa0JBQzFCLFVBQVVySCxZQUFZbkMsS0FBSyxNQUFNO0FBQUEsa0JBQ2pDLFNBQVMsTUFBTWtHLGlCQUFpQjRDLE9BQU87QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0w7QUFBQSxrQkFDQSxjQUFXO0FBQUEsa0JBQ1gsU0FBUyxNQUFNO0FBQUU1Ryx3Q0FBb0IsS0FBSztBQUFHRSxtQ0FBZSxFQUFFO0FBQUEsa0JBQUc7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSnJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsaUJBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUNBLElBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxHQUFJaUg7QUFBQUEsZ0JBQ0osT0FBT3hILEtBQUsxQztBQUFBQSxnQkFDWixVQUFVLENBQUMwRixNQUFNL0MsUUFBUSxFQUFFLEdBQUdELE1BQU0xQyxZQUFZMEYsRUFBRXVELE9BQU9uSSxNQUFNLENBQUM7QUFBQSxnQkFFaEU7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sSUFBRyxrQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUM7QUFBQSxtQkFDakN1RCxlQUFlTyxRQUFRLElBQUl4RDtBQUFBQSxvQkFBSSxDQUFDaUUsTUFDaEMsdUJBQUMsWUFBa0IsT0FBT0EsRUFBRUgsSUFBS0csWUFBRXBGLFFBQXRCb0YsRUFBRUgsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3QztBQUFBLGtCQUN6QztBQUFBO0FBQUE7QUFBQSxjQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUE7QUFBQSxVQWhFTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFtRUEsS0FwRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFFQTtBQUFBLFdBaEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpRkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFMEUsTUFBTSxHQUFHQyxVQUFVLElBQUksR0FDbkM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU9uSCxLQUFLdkM7QUFBQUEsWUFDWixVQUFVLENBQUN1RixNQUFNL0MsUUFBUSxFQUFFLEdBQUdELE1BQU12QyxPQUFPdUYsRUFBRXVELE9BQU9uSSxNQUFNLENBQUM7QUFBQTtBQUFBLFVBSDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcrRCxLQUpqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFOEksTUFBTSxHQUFHQyxVQUFVLElBQUksR0FDbkM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU9uSCxLQUFLdEM7QUFBQUEsWUFDWixVQUFVLENBQUNzRixNQUFNL0MsUUFBUSxFQUFFLEdBQUdELE1BQU10QyxPQUFPc0YsRUFBRXVELE9BQU9uSSxNQUFNLENBQUM7QUFBQTtBQUFBLFVBSDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcrRCxLQUpqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLFdBQVU7QUFBQSxVQUNWLE9BQU80QixLQUFLckM7QUFBQUEsVUFDWixVQUFVLENBQUNxRixNQUFNL0MsUUFBUSxFQUFFLEdBQUdELE1BQU1yQyxRQUFRcUYsRUFBRXVELE9BQU9uSSxNQUFNLENBQUM7QUFBQTtBQUFBLFFBSjlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlnRTtBQUFBLE1BRy9EMEIsWUFBWSxTQUNYLHVCQUFDLFNBQUksT0FBTyxFQUFFK0YsU0FBUyxRQUFRRyxLQUFLLElBQUlJLFdBQVcsRUFBRSxHQUNuRDtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxzQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0M7QUFBQSxVQUNsQyx1QkFBQyxVQUFLLGlDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCO0FBQUEsVUFDdkIsdUJBQUMsVUFBSyxXQUFVLHNCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLGFBSHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLG9CQUFtQiw4Q0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCLDZHQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUzVGLE9BQU8zQztBQUFBQSxjQUNoQixVQUFVd0Y7QUFBQUEsY0FDVixPQUFNO0FBQUE7QUFBQSxZQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUd3QztBQUFBLGFBVjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUM3QyxPQUFPM0MsbUJBQ04sdUJBQUMsU0FBSSxPQUFPLEVBQUVnSSxTQUFTLFFBQVFHLEtBQUssR0FBRyxHQUNyQztBQUFBLGlDQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFa0IsTUFBTSxHQUFHQyxVQUFVLElBQUksR0FDbkM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ04sT0FBTzNHLE9BQU8xQztBQUFBQSxnQkFDZCxVQUFVLENBQUNrRixNQUFNdkMsVUFBVSxFQUFFLEdBQUdELFFBQVExQyxVQUFVa0YsRUFBRXVELE9BQU9uSSxNQUFNLENBQUM7QUFBQTtBQUFBLGNBSHBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUdzRSxLQUp4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRThJLE1BQU0sR0FBR0MsVUFBVSxJQUFJLEdBQ25DO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLE9BQU8zRyxPQUFPekM7QUFBQUEsZ0JBQ2QsVUFBVSxDQUFDaUYsTUFBTXZDLFVBQVUsRUFBRSxHQUFHRCxRQUFRekMsV0FBV2lGLEVBQUV1RCxPQUFPbkksTUFBTSxDQUFDO0FBQUE7QUFBQSxjQUhyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHdUUsS0FKekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLE9BQU9vQyxPQUFPeEM7QUFBQUEsY0FDZCxVQUFVLENBQUNnRixNQUFNdkMsVUFBVSxFQUFFLEdBQUdELFFBQVF4QyxVQUFVZ0YsRUFBRXVELE9BQU9uSSxNQUFNLENBQUM7QUFBQTtBQUFBLFlBSnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlzRTtBQUFBLFVBR3JFMEQsa0JBQWtCLFFBQ2pCLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx3QkFBdUIsaUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBVyxLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRDtBQUFBLFlBQ3BELHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHFDQUFDLE9BQUU7QUFBQTtBQUFBLGdCQUFTVyxhQUFhZ0QsSUFBSTNELGFBQWEsS0FBSztBQUFBLG1CQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRDtBQUFBLGNBQ25ELHVCQUFDLFVBQUssMkVBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUU7QUFBQSxpQkFGbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBR0RGLGNBQWN5RSxXQUFXLHVCQUFDLGNBQVcsT0FBT3pFLGNBQWMxQixPQUFPLE1BQUssY0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxVQUVoRjhCLGdCQUFnQjRGLE9BQU8sS0FDdEIsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFNBQUksV0FBVSwwQkFBeUIsa0NBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDMUQsdUJBQUMsU0FBSSxXQUFVLGtCQUNYaEcseUJBQWNNLFFBQVEsSUFDckIwQyxPQUFPLENBQUNMLE1BQU12QyxnQkFBZ0I2RixJQUFJdEQsRUFBRS9CLEVBQUUsQ0FBQyxFQUN2QzlEO0FBQUFBLGNBQUksQ0FBQzZGLE1BQ0osdUJBQUMsVUFBZ0IsV0FBVSw2QkFDekI7QUFBQSx1Q0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVU7QUFBQSxnQkFBRztBQUFBLGdCQUFFQSxFQUFFaEg7QUFBQUEsbUJBRFJnSCxFQUFFL0IsSUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFDRCxLQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUdGLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMEJBQXlCLGtEQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLFNBQUksV0FBVSxrQkFDWFoseUJBQWNNLFFBQVEsSUFDckIwQyxPQUFPLENBQUNMLE1BQU0sQ0FBQ3ZDLGdCQUFnQjZGLElBQUl0RCxFQUFFL0IsRUFBRSxDQUFDLEVBQ3hDOUQsSUFBSSxDQUFDNkYsTUFBTTtBQUNWLG9CQUFNdUQsS0FBS3BILGdCQUFnQmlFLFNBQVNKLEVBQUUvQixFQUFFO0FBQ3hDLHFCQUNFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLE1BQUs7QUFBQSxrQkFDTCxXQUFXLG1CQUFtQnNGLEtBQUssVUFBVSxRQUFRO0FBQUEsa0JBQ3JELFNBQVMsTUFBTXRELG1CQUFtQkQsRUFBRS9CLEVBQUU7QUFBQSxrQkFFckNzRjtBQUFBQSwwQkFBTSx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQVU7QUFBQSxvQkFBSTtBQUFBLG9CQUFFdkQsRUFBRWhIO0FBQUFBO0FBQUFBO0FBQUFBLGdCQUxwQmdILEVBQUUvQjtBQUFBQSxnQkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxZQUVKLENBQUMsS0FmTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVFQTtBQUFBLFdBN0ZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErRkE7QUFBQSxNQUdEdEMsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUMxQ0YsS0FBSzFDLGVBQWUsTUFDbkIsdUJBQUMsT0FBRSxXQUFVLGNBQWEsT0FBTyxFQUFFc0ksUUFBUSxFQUFFLEdBQUcsMkRBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUQ5RixZQUFZLFNBQVNFLEtBQUt4QyxJQUFJc0csV0FBVyxNQUFNOUQsS0FBS3hDLElBQUlzRyxTQUFTLEtBQ2hFLHVCQUFDLE9BQUUsV0FBVSxjQUFhLE9BQU8sRUFBRThCLFFBQVEsRUFBRSxHQUFHO0FBQUE7QUFBQSxRQUNsQjVGLEtBQUt4QyxJQUFJc0c7QUFBQUEsUUFBTztBQUFBLFdBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BR0Y7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVE7QUFBQSxVQUNSO0FBQUEsVUFDQSxTQUFTTixhQUFhbUU7QUFBQUEsVUFDdEIsVUFDRTNILEtBQUt6QyxLQUFLWSxLQUFLLE1BQU0sTUFDckI2QixLQUFLMUMsZUFBZSxNQUNuQndDLFlBQVksU0FBU0UsS0FBS3hDLElBQUlzRyxXQUFXLE1BQzFDLENBQUNlO0FBQUFBLFVBRUgsU0FBUyxNQUFNckIsYUFBYXlELE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQVZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFhQTtBQUFBLFNBbFBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtUEE7QUFBQSxJQUdEL0Ysb0JBQW9CLFFBQ25CO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPLGFBQWFBLGdCQUFnQjNELElBQUk7QUFBQSxRQUN4QyxTQUFTdUg7QUFBQUEsUUFDVCxTQUFRO0FBQUEsUUFDUixXQUFXLGNBQWM1RCxnQkFBZ0IzRCxJQUFJO0FBQUEsUUFFN0M7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsaUJBQWdCLGdIQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQzRFLHlCQUF5QmtFLFdBQVcsdUJBQUMsY0FBVyxPQUFPbEUseUJBQXlCakMsT0FBTyxNQUFLLHlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQ2pIbUMsd0JBQXdCZ0UsV0FBVyx1QkFBQyxjQUFXLE9BQU9oRSx3QkFBd0JuQyxPQUFPLE1BQUssMEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDaEgwQixjQUFjeUUsV0FBVyx1QkFBQyxjQUFXLE9BQU96RSxjQUFjMUIsT0FBTyxNQUFLLGNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFFaEZrQyxzQkFBc0J3RixPQUFPLEtBQzVCLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMEJBQXlCLE9BQU8sRUFBRUcsY0FBYyxFQUFFLEdBQUc7QUFBQTtBQUFBLGNBQzFDdEYsYUFBYWdELElBQUl2RSxnQkFBZ0I1RCxVQUFVLEtBQUs7QUFBQSxjQUFHO0FBQUEsaUJBRDdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxtQkFDWHNFLHlCQUFjTSxRQUFRLElBQ3JCMEMsT0FBTyxDQUFDTCxNQUFNbkMsc0JBQXNCeUYsSUFBSXRELEVBQUUvQixFQUFFLENBQUMsRUFDN0M5RDtBQUFBQSxjQUFJLENBQUM2RixNQUNKLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHVDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBVTtBQUFBLGdCQUFHO0FBQUEsZ0JBQUVBLEVBQUVoSDtBQUFBQSxtQkFEa0JnSCxFQUFFL0IsSUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FQTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFHRix1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBCQUF5QiwyQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxZQUNuRSx1QkFBQyxTQUFJLFdBQVUsbUJBQ1haLHlCQUFjTSxRQUFRLElBQ3JCMEMsT0FBTyxDQUFDTCxNQUFNLENBQUNuQyxzQkFBc0J5RixJQUFJdEQsRUFBRS9CLEVBQUUsQ0FBQyxFQUM5QzlEO0FBQUFBLGNBQUksQ0FBQzZGLE1BQ0osdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsVUFBTUEsWUFBRWhILFFBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBYztBQUFBLGdCQUNkO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVM2RCxhQUFhdUQsU0FBU0osRUFBRS9CLEVBQUU7QUFBQSxvQkFDbkMsVUFBVSxNQUFNdUMsa0JBQWtCUixFQUFFL0IsRUFBRTtBQUFBLG9CQUN0QyxPQUFPcEIsYUFBYXVELFNBQVNKLEVBQUUvQixFQUFFLElBQUksb0JBQW9CK0IsRUFBRWhILElBQUksS0FBSyxxQkFBcUJnSCxFQUFFaEgsSUFBSTtBQUFBO0FBQUEsa0JBSGpHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHb0c7QUFBQSxtQkFMaEVnSCxFQUFFL0IsSUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLFlBQ0QsS0FaTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBRUN0QyxTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUM7QUFBQSxVQUUzQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1I7QUFBQSxjQUNBLFNBQVM4RSxtQkFBbUIyQztBQUFBQSxjQUM1QixVQUFVdEYsd0JBQXdCaUU7QUFBQUEsY0FDbEMsU0FBUyxNQUFNdEIsbUJBQW1CaUMsT0FBTztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBTDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCLE9BQU8sRUFBRWUsV0FBVyx5QkFBeUJDLFlBQVksSUFBSTdCLFdBQVcsRUFBRSxHQUN4RztBQUFBLG1DQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHFDQUFDLE9BQUUsK0JBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0I7QUFBQSxjQUNsQix1QkFBQyxVQUFLLCtFQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsaUJBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLE1BQUs7QUFBQSxnQkFDTCxTQUFTbkIsd0JBQXdCMEM7QUFBQUEsZ0JBQ2pDLFNBQVMsWUFBWTtBQUNuQixzQkFDRSxNQUFNakksT0FBT21ILFFBQVE7QUFBQSxvQkFDbkJDLE9BQU87QUFBQSxvQkFDUDdELFNBQVMseUJBQXlCL0IsZ0JBQWdCM0QsSUFBSTtBQUFBLG9CQUN0RHdKLGNBQWM7QUFBQSxvQkFDZEMsUUFBUTtBQUFBLGtCQUNWLENBQUM7QUFFRC9CLDRDQUF3QmdDLE9BQU87QUFBQSxnQkFDbkM7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFpQkE7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBO0FBQUE7QUFBQSxNQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFxRkE7QUFBQSxPQTVlSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOGVBO0FBRUo7QUFBQ3pILEdBMXZCZUQsZUFBYTtBQUFBLFVBQ1A1RCxnQkFDTEMsV0FDRHdCLFVBQ2tCWCxjQXNCVGYsVUFLQUEsVUFLREEsVUFVS0EsVUFRTUEsVUFTREEsVUFtRVhELGFBc0RHQSxhQVlDQSxhQWlDRUEsYUFTS0EsV0FBVztBQUFBO0FBQUEsTUE5TzdCOEQ7QUFBYSxJQUFBUCxJQUFBRSxLQUFBRSxLQUFBRSxLQUFBNEk7QUFBQSxhQUFBbEosSUFBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUE0SSxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiTGluayIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsInVzZURpYWxvZyIsImNyZWF0ZUVtcGxveWVlIiwiY3JlYXRlSm9iVGl0bGUiLCJkaXNtaXNzRW1wbG95ZWUiLCJnZXRFbXBsb3llZXNCeUJyYW5jaCIsImdldEpvYlRpdGxlcyIsInJlZ2lzdGVyVGVhbU1lbWJlciIsInVwZGF0ZUVtcGxveWVlIiwiZ2V0RmVhdHVyZXMiLCJnZXRKb2JUaXRsZUZlYXR1cmVzIiwiZ2V0VXNlckZlYXR1cmVzIiwic2V0VXNlckZlYXR1cmVzIiwiZGVhY3RpdmF0ZVVzZXIiLCJ1c2VBdXRoU3RvcmUiLCJBcGlFcnJvciIsImZvcm1hdEJSTCIsIlF1ZXJ5RXJyb3IiLCJFbXB0eVN0YXRlIiwiU2tlbGV0b25MaXN0IiwiTW9kYWwiLCJCdXR0b24iLCJGaWVsZCIsIlRleHRGaWVsZCIsIlN3aXRjaCIsInVzZVRvYXN0IiwiZW1wdHlGb3JtIiwiam9iVGl0bGVJZCIsIm5hbWUiLCJjcGYiLCJlbWFpbCIsInBob25lIiwic2FsYXJ5IiwiZW1wdHlBY2Nlc3NGb3JtIiwiaGFzU3lzdGVtQWNjZXNzIiwidXNlck5hbWUiLCJ1c2VyRW1haWwiLCJwYXNzd29yZCIsInBhcnNlTnVtIiwicmF3IiwidHJpbSIsInZhbHVlIiwiTnVtYmVyIiwicmVwbGFjZSIsImlzRmluaXRlIiwiaW5pdGlhbHNPZiIsInNwbGl0IiwibWFwIiwicCIsInNsaWNlIiwiam9pbiIsInRvVXBwZXJDYXNlIiwiU2VhcmNoSWNvbiIsIl9jIiwiS2ViYWJJY29uIiwiX2MyIiwiQ2hlY2tJY29uIiwiX2MzIiwiUGVyZmlsSWNvbiIsIl9jNCIsIkVtcGxveWVlc1BhZ2UiLCJfcyIsInF1ZXJ5Q2xpZW50IiwiZGlhbG9nIiwidG9hc3QiLCJicmFuY2hJZCIsImNvbXBhbnlJZCIsImVkaXRpbmciLCJzZXRFZGl0aW5nIiwiZm9ybSIsInNldEZvcm0iLCJlcnJvciIsInNldEVycm9yIiwiY3JlYXRpbmdKb2JUaXRsZSIsInNldENyZWF0aW5nSm9iVGl0bGUiLCJuZXdKb2JUaXRsZSIsInNldE5ld0pvYlRpdGxlIiwiYWNjZXNzIiwic2V0QWNjZXNzIiwiZXh0cmFGZWF0dXJlSWRzIiwic2V0RXh0cmFGZWF0dXJlSWRzIiwic2VhcmNoIiwic2V0U2VhcmNoIiwic3RhdHVzRmlsdGVyIiwic2V0U3RhdHVzRmlsdGVyIiwib3BlbktlYmFiRm9yIiwic2V0T3BlbktlYmFiRm9yIiwiYWNjZXNzRHJhd2VyRm9yIiwic2V0QWNjZXNzRHJhd2VyRm9yIiwiZHJhd2VyRXh0cmFzIiwic2V0RHJhd2VyRXh0cmFzIiwiZHJhd2VyTG9hZGVkRm9yIiwic2V0RHJhd2VyTG9hZGVkRm9yIiwiZW1wbG95ZWVzUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJqb2JUaXRsZXNRdWVyeSIsImZlYXR1cmVzUXVlcnkiLCJlbmFibGVkIiwiam9iVGl0bGVJZE51bSIsImNhcmdvRmVhdHVyZXNRdWVyeSIsImNhcmdvRmVhdHVyZUlkcyIsIlNldCIsImRhdGEiLCJkcmF3ZXJDYXJnb0ZlYXR1cmVzUXVlcnkiLCJkcmF3ZXJDYXJnb0ZlYXR1cmVJZHMiLCJkcmF3ZXJVc2VyRmVhdHVyZXNRdWVyeSIsImFwcFVzZXJJZCIsInVuZGVmaW5lZCIsImlkIiwiam9iVGl0bGVOYW1lIiwiTWFwIiwiaiIsInNldCIsInJlZnJlc2giLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uQXBpRXJyb3IiLCJlIiwibWVzc2FnZSIsIm9wZW5FZGl0b3IiLCJlbXBsb3llZSIsIlN0cmluZyIsInRvZ2dsZVN5c3RlbUFjY2VzcyIsImNoZWNrZWQiLCJhIiwic2F2ZU11dGF0aW9uIiwibXV0YXRpb25GbiIsInNoYXJlZCIsImhpcmVkQXQiLCJEYXRlIiwidG9JU09TdHJpbmciLCJsZW5ndGgiLCJvblN1Y2Nlc3MiLCJyZXN1bHQiLCJzdWNjZXNzIiwiYWNjZXNzV2FybmluZyIsIm9uRXJyb3IiLCJkaXNtaXNzTXV0YXRpb24iLCJqb2JUaXRsZU11dGF0aW9uIiwibmV3Sm9iVGl0bGVJZCIsImYiLCJ0b2dnbGVFeHRyYUZlYXR1cmUiLCJmZWF0dXJlSWQiLCJjdXJyZW50IiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJhY2Nlc3NGaWVsZHNWYWxpZCIsImNsb3NlRHJhd2VyIiwidG9nZ2xlRHJhd2VyRXh0cmEiLCJkcmF3ZXJTYXZlTXV0YXRpb24iLCJkZWFjdGl2YXRlTG9naW5NdXRhdGlvbiIsImVtcGxveWVlcyIsIndpdGhBY2Nlc3NDb3VudCIsIm5vTG9naW5Db3VudCIsImZpbHRlcmVkRW1wbG95ZWVzIiwibGlzdCIsInEiLCJ0b0xvd2VyQ2FzZSIsImdldCIsInBhZGRpbmciLCJtYXhXaWR0aCIsIm1hcmdpbiIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJnYXAiLCJmbGV4V3JhcCIsImZvbnRTaXplIiwiY29sb3IiLCJtYXJnaW5Ub3AiLCJpc0Vycm9yIiwiaXNMb2FkaW5nIiwidGFyZ2V0Iiwicm9sZU5hbWUiLCJleHRyYUZlYXR1cmVDb3VudCIsInBvc2l0aW9uIiwiaW5zZXQiLCJ6SW5kZXgiLCJjb25maXJtIiwidGl0bGUiLCJjb25maXJtTGFiZWwiLCJkYW5nZXIiLCJtdXRhdGUiLCJmbGV4IiwibWluV2lkdGgiLCJ3aWR0aCIsImJhY2tncm91bmQiLCJib3JkZXIiLCJjdXJzb3IiLCJhMTF5Iiwia2V5IiwicHJldmVudERlZmF1bHQiLCJpc1BlbmRpbmciLCJzaXplIiwiaGFzIiwib24iLCJtYXJnaW5Cb3R0b20iLCJib3JkZXJUb3AiLCJwYWRkaW5nVG9wIiwiX2M1Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVtcGxveWVlc1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IHVzZURpYWxvZyB9IGZyb20gXCIuLi8uLi91aS9EaWFsb2dcIjtcclxuaW1wb3J0IHtcclxuICBjcmVhdGVFbXBsb3llZSxcclxuICBjcmVhdGVKb2JUaXRsZSxcclxuICBkaXNtaXNzRW1wbG95ZWUsXHJcbiAgZ2V0RW1wbG95ZWVzQnlCcmFuY2gsXHJcbiAgZ2V0Sm9iVGl0bGVzLFxyXG4gIHJlZ2lzdGVyVGVhbU1lbWJlcixcclxuICB1cGRhdGVFbXBsb3llZSxcclxufSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHR5cGUgeyBSZWdpc3RlclRlYW1NZW1iZXJSZXN1bHQgfSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgZ2V0RmVhdHVyZXMsIGdldEpvYlRpdGxlRmVhdHVyZXMsIGdldFVzZXJGZWF0dXJlcywgc2V0VXNlckZlYXR1cmVzIH0gZnJvbSBcIi4uL2FjY2Vzcy9hcGlcIjtcclxuaW1wb3J0IHsgZGVhY3RpdmF0ZVVzZXIgfSBmcm9tIFwiLi4vdXNlcnMvYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHsgZm9ybWF0QlJMIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IEVtcGxveWVlUmVzcG9uc2UgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcbmltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tIFwiLi4vLi4vdWkvRW1wdHlTdGF0ZVwiO1xyXG5pbXBvcnQgeyBTa2VsZXRvbkxpc3QgfSBmcm9tIFwiLi4vLi4vdWkvU2tlbGV0b25cIjtcclxuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiLi4vLi4vdWkvTW9kYWxcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uLy4uL3VpL0J1dHRvblwiO1xyXG5pbXBvcnQgeyBGaWVsZCwgVGV4dEZpZWxkIH0gZnJvbSBcIi4uLy4uL3VpL0ZpZWxkXCI7XHJcbmltcG9ydCB7IFN3aXRjaCB9IGZyb20gXCIuLi8uLi91aS9Td2l0Y2hcIjtcclxuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vLi4vdWkvVG9hc3RcIjtcclxuXHJcbmNvbnN0IGVtcHR5Rm9ybSA9IHsgam9iVGl0bGVJZDogXCJcIiwgbmFtZTogXCJcIiwgY3BmOiBcIlwiLCBlbWFpbDogXCJcIiwgcGhvbmU6IFwiXCIsIHNhbGFyeTogXCJcIiB9O1xyXG50eXBlIEZvcm1TdGF0ZSA9IHR5cGVvZiBlbXB0eUZvcm07XHJcblxyXG5jb25zdCBlbXB0eUFjY2Vzc0Zvcm0gPSB7IGhhc1N5c3RlbUFjY2VzczogZmFsc2UsIHVzZXJOYW1lOiBcIlwiLCB1c2VyRW1haWw6IFwiXCIsIHBhc3N3b3JkOiBcIlwiIH07XHJcbnR5cGUgQWNjZXNzRm9ybVN0YXRlID0gdHlwZW9mIGVtcHR5QWNjZXNzRm9ybTtcclxuXHJcbnR5cGUgU3RhdHVzRmlsdGVyID0gXCJhbGxcIiB8IFwiYWNjZXNzXCIgfCBcIm5vLWxvZ2luXCI7XHJcblxyXG5jb25zdCBwYXJzZU51bSA9IChyYXc6IHN0cmluZyk6IG51bWJlciB8IG51bGwgPT4ge1xyXG4gIGlmIChyYXcudHJpbSgpID09PSBcIlwiKSByZXR1cm4gbnVsbDtcclxuICBjb25zdCB2YWx1ZSA9IE51bWJlcihyYXcucmVwbGFjZShcIixcIiwgXCIuXCIpKTtcclxuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHZhbHVlKSA/IHZhbHVlIDogbnVsbDtcclxufTtcclxuXHJcbmNvbnN0IGluaXRpYWxzT2YgPSAobmFtZTogc3RyaW5nKSA9PlxyXG4gIG5hbWVcclxuICAgIC50cmltKClcclxuICAgIC5zcGxpdCgvXFxzKy8pXHJcbiAgICAubWFwKChwKSA9PiBwWzBdKVxyXG4gICAgLnNsaWNlKDAsIDIpXHJcbiAgICAuam9pbihcIlwiKVxyXG4gICAgLnRvVXBwZXJDYXNlKCk7XHJcblxyXG4vKiDDjWNvbmVzIGlubGluZSAoc2VtIGRlcGVuZMOqbmNpYSBleHRlcm5hKSwgbm8gbWVzbW8gZXN0aWxvIGRvIHJlc3RvIGRhIFVJIChDYXJkw6FwaW8pLiAqL1xyXG5jb25zdCBTZWFyY2hJY29uID0gKCkgPT4gKFxyXG4gIDxzdmcgd2lkdGg9XCIxNVwiIGhlaWdodD1cIjE1XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICA8Y2lyY2xlIGN4PVwiMTFcIiBjeT1cIjExXCIgcj1cIjdcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjEuOFwiIC8+XHJcbiAgICA8cGF0aCBkPVwiTTIxIDIxbC00LjMtNC4zXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIxLjhcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5jb25zdCBLZWJhYkljb24gPSAoKSA9PiAoXHJcbiAgPHN2ZyB3aWR0aD1cIjE1XCIgaGVpZ2h0PVwiMTVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCI1XCIgcj1cIjEuOFwiIC8+PGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIxLjhcIiAvPjxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTlcIiByPVwiMS44XCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuY29uc3QgQ2hlY2tJY29uID0gKCkgPT4gKFxyXG4gIDxzdmcgd2lkdGg9XCIxNVwiIGhlaWdodD1cIjE1XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICA8cGF0aCBkPVwiTTQgMTJsNSA1TDIwIDZcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjIuNFwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5jb25zdCBQZXJmaWxJY29uID0gKCkgPT4gKFxyXG4gIDxzdmcgd2lkdGg9XCIxNlwiIGhlaWdodD1cIjE2XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICA8Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjhcIiByPVwiNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIC8+XHJcbiAgICA8cGF0aCBkPVwiTTQgMjBjMC00IDMuNi03IDgtN3M4IDMgOCA3XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBFbXBsb3llZXNQYWdlKCkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCBkaWFsb2cgPSB1c2VEaWFsb2coKTtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgeyBicmFuY2hJZCwgY29tcGFueUlkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZTxFbXBsb3llZVJlc3BvbnNlIHwgXCJuZXdcIiB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlPEZvcm1TdGF0ZT4oZW1wdHlGb3JtKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtjcmVhdGluZ0pvYlRpdGxlLCBzZXRDcmVhdGluZ0pvYlRpdGxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbmV3Sm9iVGl0bGUsIHNldE5ld0pvYlRpdGxlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICAvLyBBY2Vzc28gYW8gc2lzdGVtYSDigJQgc8OzIGV4aXN0ZSBubyBmbHV4byBkZSBcIm5vdm8gZnVuY2lvbsOhcmlvXCIuIENhcmdvIChjaW1hKSBlIGFjZXNzb3MgKGFxdWlcclxuICAvLyBlbWJhaXhvKSBmaWNhbSBuYSBNRVNNQSB0ZWxhOiBuZW0gdG9kbyBmdW5jaW9uw6FyaW8gZGEgZXF1aXBlIHVzYSBvIHNpc3RlbWEgKGF1eGlsaWFyIGRlXHJcbiAgLy8gbGltcGV6YSwgdmlnaWxhbnRlKSwgZW50w6NvIGlzdG8gY29tZcOnYSBkZXNsaWdhZG8gZSBzw7MgcGVkZSB1c3XDoXJpby9zZW5oYSBxdWFuZG8gbGlnYWRvLlxyXG4gIGNvbnN0IFthY2Nlc3MsIHNldEFjY2Vzc10gPSB1c2VTdGF0ZTxBY2Nlc3NGb3JtU3RhdGU+KGVtcHR5QWNjZXNzRm9ybSk7XHJcbiAgY29uc3QgW2V4dHJhRmVhdHVyZUlkcywgc2V0RXh0cmFGZWF0dXJlSWRzXSA9IHVzZVN0YXRlPG51bWJlcltdPihbXSk7XHJcblxyXG4gIC8vIEJ1c2NhL2ZpbHRybyBkYSBncmFkZSBkZSBjYXJ0w7VlcyArIG1lbnUgZGUgYcOnw7VlcyAoa2ViYWIpICsgcGFpbmVsIGRlIGFjZXNzb3MgcG9yIHBlc3NvYSDigJRcclxuICAvLyBpc3RvIMOpIG8gcXVlIHN1YnN0aXR1aSB0ZXIgcXVlIHZpc2l0YXIgXCJVc3XDoXJpb3MgZSBwZXJmaXNcIiBlIFwiQWNlc3Nvc1wiIHNlcGFyYWRhbWVudGUuXHJcbiAgY29uc3QgW3NlYXJjaCwgc2V0U2VhcmNoXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzdGF0dXNGaWx0ZXIsIHNldFN0YXR1c0ZpbHRlcl0gPSB1c2VTdGF0ZTxTdGF0dXNGaWx0ZXI+KFwiYWxsXCIpO1xyXG4gIGNvbnN0IFtvcGVuS2ViYWJGb3IsIHNldE9wZW5LZWJhYkZvcl0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbYWNjZXNzRHJhd2VyRm9yLCBzZXRBY2Nlc3NEcmF3ZXJGb3JdID0gdXNlU3RhdGU8RW1wbG95ZWVSZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtkcmF3ZXJFeHRyYXMsIHNldERyYXdlckV4dHJhc10gPSB1c2VTdGF0ZTxudW1iZXJbXT4oW10pO1xyXG4gIGNvbnN0IFtkcmF3ZXJMb2FkZWRGb3IsIHNldERyYXdlckxvYWRlZEZvcl0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3QgZW1wbG95ZWVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiZW1wbG95ZWVzXCIsIGJyYW5jaElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldEVtcGxveWVlc0J5QnJhbmNoKGJyYW5jaElkKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgam9iVGl0bGVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiam9idGl0bGVzXCIsIGNvbXBhbnlJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRKb2JUaXRsZXMoY29tcGFueUlkID8/IDEpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBmZWF0dXJlc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImFjY2Vzc1wiLCBcImZlYXR1cmVzXCJdLFxyXG4gICAgcXVlcnlGbjogZ2V0RmVhdHVyZXMsXHJcbiAgICBlbmFibGVkOiAoZWRpdGluZyA9PT0gXCJuZXdcIiAmJiBhY2Nlc3MuaGFzU3lzdGVtQWNjZXNzKSB8fCBhY2Nlc3NEcmF3ZXJGb3IgIT09IG51bGwsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGpvYlRpdGxlSWROdW0gPSBmb3JtLmpvYlRpdGxlSWQgPT09IFwiXCIgPyBudWxsIDogTnVtYmVyKGZvcm0uam9iVGl0bGVJZCk7XHJcblxyXG4gIC8vIFRlbGFzIHF1ZSBvIENhcmdvIGrDoSBsaWJlcmEgcG9yIHBhZHLDo28gKEpvYlRpdGxlRmVhdHVyZSkg4oCUIG1vc3RyYWRhcyBjb21vIHJlZmVyw6puY2lhXHJcbiAgLy8gKFwiasOhIGluY2x1c28gdmlhIGNhcmdvXCIpIHBhcmEgYSBwZXNzb2EgbsOjbyBtYXJjYXIgZGUgbm92byBvIHF1ZSBqw6EgdmVtIGRlIGdyYcOnYS5cclxuICBjb25zdCBjYXJnb0ZlYXR1cmVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiYWNjZXNzXCIsIFwiam9idGl0bGVmZWF0dXJlc1wiLCBqb2JUaXRsZUlkTnVtXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldEpvYlRpdGxlRmVhdHVyZXMoam9iVGl0bGVJZE51bSBhcyBudW1iZXIpLFxyXG4gICAgZW5hYmxlZDogZWRpdGluZyA9PT0gXCJuZXdcIiAmJiBhY2Nlc3MuaGFzU3lzdGVtQWNjZXNzICYmIGpvYlRpdGxlSWROdW0gIT09IG51bGwsXHJcbiAgfSk7XHJcbiAgY29uc3QgY2FyZ29GZWF0dXJlSWRzID0gdXNlTWVtbygoKSA9PiBuZXcgU2V0KGNhcmdvRmVhdHVyZXNRdWVyeS5kYXRhID8/IFtdKSwgW2NhcmdvRmVhdHVyZXNRdWVyeS5kYXRhXSk7XHJcblxyXG4gIC8vIE1lc21hIGzDs2dpY2EgZG8gbW9kYWwsIGFnb3JhIHBhcmEgbyBwYWluZWwgZGUgYWNlc3NvcyBkZSB1bWEgcGVzc29hIGrDoSBjYWRhc3RyYWRhLlxyXG4gIGNvbnN0IGRyYXdlckNhcmdvRmVhdHVyZXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJhY2Nlc3NcIiwgXCJqb2J0aXRsZWZlYXR1cmVzXCIsIGFjY2Vzc0RyYXdlckZvcj8uam9iVGl0bGVJZCA/PyBudWxsXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldEpvYlRpdGxlRmVhdHVyZXMoYWNjZXNzRHJhd2VyRm9yIS5qb2JUaXRsZUlkKSxcclxuICAgIGVuYWJsZWQ6IGFjY2Vzc0RyYXdlckZvciAhPT0gbnVsbCxcclxuICB9KTtcclxuICBjb25zdCBkcmF3ZXJDYXJnb0ZlYXR1cmVJZHMgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gbmV3IFNldChkcmF3ZXJDYXJnb0ZlYXR1cmVzUXVlcnkuZGF0YSA/PyBbXSksXHJcbiAgICBbZHJhd2VyQ2FyZ29GZWF0dXJlc1F1ZXJ5LmRhdGFdLFxyXG4gICk7XHJcbiAgY29uc3QgZHJhd2VyVXNlckZlYXR1cmVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiYWNjZXNzXCIsIFwidXNlcmZlYXR1cmVzXCIsIGFjY2Vzc0RyYXdlckZvcj8uYXBwVXNlcklkID8/IG51bGxdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0VXNlckZlYXR1cmVzKGFjY2Vzc0RyYXdlckZvciEuYXBwVXNlcklkIGFzIG51bWJlciksXHJcbiAgICBlbmFibGVkOiBhY2Nlc3NEcmF3ZXJGb3IgIT09IG51bGwgJiYgYWNjZXNzRHJhd2VyRm9yLmFwcFVzZXJJZCAhPT0gbnVsbCxcclxuICB9KTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKFxyXG4gICAgICBhY2Nlc3NEcmF3ZXJGb3IgIT09IG51bGwgJiZcclxuICAgICAgZHJhd2VyVXNlckZlYXR1cmVzUXVlcnkuZGF0YSAhPT0gdW5kZWZpbmVkICYmXHJcbiAgICAgIGRyYXdlckxvYWRlZEZvciAhPT0gYWNjZXNzRHJhd2VyRm9yLmlkXHJcbiAgICApIHtcclxuICAgICAgc2V0RHJhd2VyRXh0cmFzKGRyYXdlclVzZXJGZWF0dXJlc1F1ZXJ5LmRhdGEpO1xyXG4gICAgICBzZXREcmF3ZXJMb2FkZWRGb3IoYWNjZXNzRHJhd2VyRm9yLmlkKTtcclxuICAgIH1cclxuICB9LCBbYWNjZXNzRHJhd2VyRm9yLCBkcmF3ZXJVc2VyRmVhdHVyZXNRdWVyeS5kYXRhLCBkcmF3ZXJMb2FkZWRGb3JdKTtcclxuXHJcbiAgLy8gQW8gdHJvY2FyIG8gY2FyZ28sIG9zIFwiZXh0cmFzXCIgbWFyY2Fkb3MgZXJhbSByZWxhdGl2b3MgYW8gY2FyZ28gYW50ZXJpb3Ig4oCUIGV2aXRhIHNhbHZhclxyXG4gIC8vIGFjZXNzbyBleHRyYSBwYXJhIHVtIGNhcmdvIHF1ZSBhIHBlc3NvYSBuZW0gZXNjb2xoZXUgbWFpcy5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0RXh0cmFGZWF0dXJlSWRzKFtdKTtcclxuICB9LCBbam9iVGl0bGVJZE51bV0pO1xyXG5cclxuICBjb25zdCBqb2JUaXRsZU5hbWUgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XHJcbiAgICBmb3IgKGNvbnN0IGogb2Ygam9iVGl0bGVzUXVlcnkuZGF0YSA/PyBbXSkgbWFwLnNldChqLmlkLCBqLm5hbWUpO1xyXG4gICAgcmV0dXJuIG1hcDtcclxuICB9LCBbam9iVGl0bGVzUXVlcnkuZGF0YV0pO1xyXG5cclxuICBjb25zdCByZWZyZXNoID0gKCkgPT4ge1xyXG4gICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJlbXBsb3llZXNcIl0gfSk7XHJcbiAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcInVzZXJzXCJdIH0pO1xyXG4gICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJyb2xlc1wiXSB9KTtcclxuICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiYWNjZXNzXCJdIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uQXBpRXJyb3IgPSAoZTogdW5rbm93bikgPT5cclxuICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGUubWVzc2FnZSA6IFwiT3BlcmHDp8OjbyBmYWxob3UuXCIpO1xyXG5cclxuICBjb25zdCBvcGVuRWRpdG9yID0gKGVtcGxveWVlOiBFbXBsb3llZVJlc3BvbnNlIHwgXCJuZXdcIikgPT4ge1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICBzZXRDcmVhdGluZ0pvYlRpdGxlKGZhbHNlKTtcclxuICAgIHNldE5ld0pvYlRpdGxlKFwiXCIpO1xyXG4gICAgc2V0QWNjZXNzKGVtcHR5QWNjZXNzRm9ybSk7XHJcbiAgICBzZXRFeHRyYUZlYXR1cmVJZHMoW10pO1xyXG4gICAgc2V0RWRpdGluZyhlbXBsb3llZSk7XHJcbiAgICBpZiAoZW1wbG95ZWUgPT09IFwibmV3XCIpXHJcbiAgICAgIHNldEZvcm0oeyAuLi5lbXB0eUZvcm0sIGpvYlRpdGxlSWQ6IFN0cmluZyhqb2JUaXRsZXNRdWVyeS5kYXRhPy5bMF0/LmlkID8/IFwiXCIpIH0pO1xyXG4gICAgZWxzZVxyXG4gICAgICBzZXRGb3JtKHtcclxuICAgICAgICBqb2JUaXRsZUlkOiBTdHJpbmcoZW1wbG95ZWUuam9iVGl0bGVJZCksXHJcbiAgICAgICAgbmFtZTogZW1wbG95ZWUubmFtZSxcclxuICAgICAgICBjcGY6IGVtcGxveWVlLmNwZixcclxuICAgICAgICBlbWFpbDogZW1wbG95ZWUuZW1haWwgPz8gXCJcIixcclxuICAgICAgICBwaG9uZTogZW1wbG95ZWUucGhvbmUgPz8gXCJcIixcclxuICAgICAgICBzYWxhcnk6IGVtcGxveWVlLnNhbGFyeSA9PT0gbnVsbCA/IFwiXCIgOiBTdHJpbmcoZW1wbG95ZWUuc2FsYXJ5KSxcclxuICAgICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gTGlnYSBvIHRvZ2dsZSBcInVzYSBvIHNpc3RlbWFcIiBwcsOpLXByZWVuY2hlbmRvIG8gZS1tYWlsIGRlIGxvZ2luIGNvbSBvIGUtbWFpbCBkbyBmdW5jaW9uw6FyaW9cclxuICAvLyAoZXZpdGEgZGlnaXRhciBvIG1lc21vIGUtbWFpbCBkdWFzIHZlemVzKSDigJQgYSBwZXNzb2EgYWluZGEgcG9kZSBlZGl0YXIgYW50ZXMgZGUgc2FsdmFyLlxyXG4gIGNvbnN0IHRvZ2dsZVN5c3RlbUFjY2VzcyA9IChjaGVja2VkOiBib29sZWFuKSA9PlxyXG4gICAgc2V0QWNjZXNzKChhKSA9PiAoe1xyXG4gICAgICAuLi5hLFxyXG4gICAgICBoYXNTeXN0ZW1BY2Nlc3M6IGNoZWNrZWQsXHJcbiAgICAgIHVzZXJFbWFpbDogY2hlY2tlZCAmJiBhLnVzZXJFbWFpbCA9PT0gXCJcIiA/IGZvcm0uZW1haWwudHJpbSgpIDogYS51c2VyRW1haWwsXHJcbiAgICB9KSk7XHJcblxyXG4gIGNvbnN0IHNhdmVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIC8vIFJldG9ybm8gdW5pZmljYWRvIGNvbW8gUHJvbWlzZTxSZWdpc3RlclRlYW1NZW1iZXJSZXN1bHQgfCB1bmRlZmluZWQ+IOKAlCB1cGRhdGVFbXBsb3llZSBlXHJcbiAgICAvLyBjcmVhdGVFbXBsb3llZSByZXNvbHZlbSBlbSB2b2lkLCBtYXMgbyBUUyBuw6NvIGluZmVyZSB1bSB0aXBvIMO6bmljbyBkZSBURGF0YSBhIHBhcnRpciBkZVxyXG4gICAgLy8gdW0gY29ycG8gY29tIFwicmV0dXJuXCIgZGUgUHJvbWlzZXMgZGlmZXJlbnRlczsgYSBhbm90YcOnw6NvIGV4cGzDrWNpdGEgcmVzb2x2ZSBpc3NvIGUgbWFudMOpbVxyXG4gICAgLy8gb25TdWNjZXNzIHRpcGFkbyAoZW0gdmV6IGRlIGNhaXIgZW0gXCJuZXZlclwiKS5cclxuICAgIG11dGF0aW9uRm46IGFzeW5jICgpOiBQcm9taXNlPFJlZ2lzdGVyVGVhbU1lbWJlclJlc3VsdCB8IHVuZGVmaW5lZD4gPT4ge1xyXG4gICAgICBjb25zdCBzaGFyZWQgPSB7XHJcbiAgICAgICAgam9iVGl0bGVJZDogTnVtYmVyKGZvcm0uam9iVGl0bGVJZCksXHJcbiAgICAgICAgbmFtZTogZm9ybS5uYW1lLnRyaW0oKSxcclxuICAgICAgICBlbWFpbDogZm9ybS5lbWFpbC50cmltKCkgPT09IFwiXCIgPyBudWxsIDogZm9ybS5lbWFpbC50cmltKCksXHJcbiAgICAgICAgcGhvbmU6IGZvcm0ucGhvbmUudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IGZvcm0ucGhvbmUudHJpbSgpLFxyXG4gICAgICAgIHNhbGFyeTogcGFyc2VOdW0oZm9ybS5zYWxhcnkpLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgaWYgKGVkaXRpbmcgIT09IFwibmV3XCIpIHtcclxuICAgICAgICBhd2FpdCB1cGRhdGVFbXBsb3llZSgoZWRpdGluZyBhcyBFbXBsb3llZVJlc3BvbnNlKS5pZCwgc2hhcmVkKTtcclxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoIWFjY2Vzcy5oYXNTeXN0ZW1BY2Nlc3MpIHtcclxuICAgICAgICBhd2FpdCBjcmVhdGVFbXBsb3llZSh7XHJcbiAgICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICAgIGNwZjogZm9ybS5jcGYudHJpbSgpLFxyXG4gICAgICAgICAgaGlyZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgLi4uc2hhcmVkLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiByZWdpc3RlclRlYW1NZW1iZXIoY29tcGFueUlkID8/IDEsIHtcclxuICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICBjcGY6IGZvcm0uY3BmLnRyaW0oKSxcclxuICAgICAgICBoaXJlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgLi4uc2hhcmVkLFxyXG4gICAgICAgIGhhc1N5c3RlbUFjY2VzczogdHJ1ZSxcclxuICAgICAgICB1c2VyTmFtZTogYWNjZXNzLnVzZXJOYW1lLnRyaW0oKSxcclxuICAgICAgICB1c2VyRW1haWw6IGFjY2Vzcy51c2VyRW1haWwudHJpbSgpLFxyXG4gICAgICAgIHBhc3N3b3JkOiBhY2Nlc3MucGFzc3dvcmQsXHJcbiAgICAgICAgZXh0cmFGZWF0dXJlSWRzOiBleHRyYUZlYXR1cmVJZHMubGVuZ3RoID4gMCA/IGV4dHJhRmVhdHVyZUlkcyA6IG51bGwsXHJcbiAgICAgIH0pO1xyXG4gICAgfSxcclxuICAgIG9uU3VjY2VzczogKHJlc3VsdCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKGVkaXRpbmcgPT09IFwibmV3XCIgPyBcIkZ1bmNpb27DoXJpbyBjYWRhc3RyYWRvLlwiIDogXCJGdW5jaW9uw6FyaW8gYXR1YWxpemFkby5cIik7XHJcbiAgICAgIC8vIHJlZ2lzdGVyVGVhbU1lbWJlciBwb2RlIFwiZGVncmFkYXIgZ3JhY2lvc2FtZW50ZVwiOiBmdW5jaW9uw6FyaW8gY3JpYWRvLCBtYXMgbyB1c3XDoXJpbyBuw6NvXHJcbiAgICAgIC8vIChleC46IHVzZXJuYW1lIGrDoSBlbSB1c28pIOKAlCBhdmlzYW1vcyBzZW0gZXNjb25kZXIgcXVlIG8gY2FkYXN0cm8gZG8gZnVuY2lvbsOhcmlvIHZhbGV1LlxyXG4gICAgICBpZiAocmVzdWx0ICYmIHR5cGVvZiByZXN1bHQgPT09IFwib2JqZWN0XCIgJiYgXCJhY2Nlc3NXYXJuaW5nXCIgaW4gcmVzdWx0ICYmIHJlc3VsdC5hY2Nlc3NXYXJuaW5nKSB7XHJcbiAgICAgICAgdG9hc3QuZXJyb3IocmVzdWx0LmFjY2Vzc1dhcm5pbmcpO1xyXG4gICAgICB9XHJcbiAgICAgIHNldEVkaXRpbmcobnVsbCk7XHJcbiAgICAgIHJlZnJlc2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBkaXNtaXNzTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoaWQ6IG51bWJlcikgPT4gZGlzbWlzc0VtcGxveWVlKGlkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiRnVuY2lvbsOhcmlvIGRlbWl0aWRvLlwiKTtcclxuICAgICAgcmVmcmVzaCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIC8vIENyaWFyIGNhcmdvIHNlbSBzYWlyIGRvIGZvcm11bMOhcmlvIGRlIG5vdm8gZnVuY2lvbsOhcmlvIOKAlCBvIGNhcmdvIG5vdm8gasOhXHJcbiAgLy8gZW50cmEgc2VsZWNpb25hZG8gYXNzaW0gcXVlIGNyaWFkbyAobWVzbW8gcGFkcsOjbyBkbyBcIisgbm92YSBjYXRlZ29yaWFcIiBub1xyXG4gIC8vIGNhZGFzdHJvIGRlIHByb2R1dG8pLlxyXG4gIGNvbnN0IGpvYlRpdGxlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBjcmVhdGVKb2JUaXRsZShjb21wYW55SWQgPz8gMSwgbmV3Sm9iVGl0bGUudHJpbSgpKSxcclxuICAgIG9uU3VjY2VzczogKG5ld0pvYlRpdGxlSWQpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNhcmdvIGNyaWFkby5cIik7XHJcbiAgICAgIHNldEZvcm0oKGYpID0+ICh7IC4uLmYsIGpvYlRpdGxlSWQ6IFN0cmluZyhuZXdKb2JUaXRsZUlkKSB9KSk7XHJcbiAgICAgIHNldE5ld0pvYlRpdGxlKFwiXCIpO1xyXG4gICAgICBzZXRDcmVhdGluZ0pvYlRpdGxlKGZhbHNlKTtcclxuICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiam9idGl0bGVzXCJdIH0pO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHRvZ2dsZUV4dHJhRmVhdHVyZSA9IChmZWF0dXJlSWQ6IG51bWJlcikgPT5cclxuICAgIHNldEV4dHJhRmVhdHVyZUlkcygoY3VycmVudCkgPT5cclxuICAgICAgY3VycmVudC5pbmNsdWRlcyhmZWF0dXJlSWQpID8gY3VycmVudC5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gZmVhdHVyZUlkKSA6IFsuLi5jdXJyZW50LCBmZWF0dXJlSWRdLFxyXG4gICAgKTtcclxuXHJcbiAgY29uc3QgYWNjZXNzRmllbGRzVmFsaWQgPVxyXG4gICAgIWFjY2Vzcy5oYXNTeXN0ZW1BY2Nlc3MgfHxcclxuICAgIChhY2Nlc3MudXNlck5hbWUudHJpbSgpICE9PSBcIlwiICYmIGFjY2Vzcy51c2VyRW1haWwudHJpbSgpICE9PSBcIlwiICYmIGFjY2Vzcy5wYXNzd29yZC5sZW5ndGggPj0gOCk7XHJcblxyXG4gIC8vIC0tLSBQYWluZWwgZGUgYWNlc3NvcyBwb3IgcGVzc29hIChkcmF3ZXIpIOKAlCBzdWJzdGl0dWkgdGVyIHF1ZSBpciBlbSBVc3XDoXJpb3MvQWNlc3NvcyAtLS1cclxuICBjb25zdCBjbG9zZURyYXdlciA9ICgpID0+IHtcclxuICAgIHNldEFjY2Vzc0RyYXdlckZvcihudWxsKTtcclxuICAgIHNldERyYXdlckV4dHJhcyhbXSk7XHJcbiAgICBzZXREcmF3ZXJMb2FkZWRGb3IobnVsbCk7XHJcbiAgICBzZXRFcnJvcihudWxsKTtcclxuICB9O1xyXG4gIGNvbnN0IHRvZ2dsZURyYXdlckV4dHJhID0gKGZlYXR1cmVJZDogbnVtYmVyKSA9PlxyXG4gICAgc2V0RHJhd2VyRXh0cmFzKChjdXJyZW50KSA9PlxyXG4gICAgICBjdXJyZW50LmluY2x1ZGVzKGZlYXR1cmVJZCkgPyBjdXJyZW50LmZpbHRlcigoaWQpID0+IGlkICE9PSBmZWF0dXJlSWQpIDogWy4uLmN1cnJlbnQsIGZlYXR1cmVJZF0sXHJcbiAgICApO1xyXG4gIGNvbnN0IGRyYXdlclNhdmVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHNldFVzZXJGZWF0dXJlcyhhY2Nlc3NEcmF3ZXJGb3IhLmFwcFVzZXJJZCBhcyBudW1iZXIsIGRyYXdlckV4dHJhcyksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkFjZXNzb3MgYXR1YWxpemFkb3MuXCIpO1xyXG4gICAgICBjbG9zZURyYXdlcigpO1xyXG4gICAgICByZWZyZXNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICB9KTtcclxuICBjb25zdCBkZWFjdGl2YXRlTG9naW5NdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IGRlYWN0aXZhdGVVc2VyKGFjY2Vzc0RyYXdlckZvciEuYXBwVXNlcklkIGFzIG51bWJlciksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkxvZ2luIGRlc2F0aXZhZG8g4oCUIG8gZnVuY2lvbsOhcmlvIGNvbnRpbnVhIG5hIGVxdWlwZS5cIik7XHJcbiAgICAgIGNsb3NlRHJhd2VyKCk7XHJcbiAgICAgIHJlZnJlc2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBlbXBsb3llZXMgPSBlbXBsb3llZXNRdWVyeS5kYXRhID8/IFtdO1xyXG4gIGNvbnN0IHdpdGhBY2Nlc3NDb3VudCA9IGVtcGxveWVlcy5maWx0ZXIoKGUpID0+IGUuaGFzU3lzdGVtQWNjZXNzKS5sZW5ndGg7XHJcbiAgY29uc3Qgbm9Mb2dpbkNvdW50ID0gZW1wbG95ZWVzLmxlbmd0aCAtIHdpdGhBY2Nlc3NDb3VudDtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRFbXBsb3llZXMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGxldCBsaXN0ID0gZW1wbG95ZWVzO1xyXG4gICAgaWYgKHN0YXR1c0ZpbHRlciA9PT0gXCJhY2Nlc3NcIikgbGlzdCA9IGxpc3QuZmlsdGVyKChlKSA9PiBlLmhhc1N5c3RlbUFjY2Vzcyk7XHJcbiAgICBpZiAoc3RhdHVzRmlsdGVyID09PSBcIm5vLWxvZ2luXCIpIGxpc3QgPSBsaXN0LmZpbHRlcigoZSkgPT4gIWUuaGFzU3lzdGVtQWNjZXNzKTtcclxuICAgIGlmIChzZWFyY2gudHJpbSgpICE9PSBcIlwiKSB7XHJcbiAgICAgIGNvbnN0IHEgPSBzZWFyY2gudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGxpc3QgPSBsaXN0LmZpbHRlcihcclxuICAgICAgICAoZSkgPT4gZS5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHwgKGpvYlRpdGxlTmFtZS5nZXQoZS5qb2JUaXRsZUlkKSA/PyBcIlwiKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpLFxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGxpc3Q7XHJcbiAgfSwgW2VtcGxveWVlcywgc3RhdHVzRmlsdGVyLCBzZWFyY2gsIGpvYlRpdGxlTmFtZV0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMjgwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLXRhYnMgcmlzZVwiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImVtcC10YWIgaXMtYWN0aXZlXCI+UGVzc29hczwvc3Bhbj5cclxuICAgICAgICA8TGluayB0bz1cIi9hY2Vzc29zXCIgY2xhc3NOYW1lPVwiZW1wLXRhYlwiPkNhcmdvcyBlIGFjZXNzb3MgcGFkcsOjbzwvTGluaz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2VcIiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJmbGV4LWVuZFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMjAsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjdyZW1cIiB9fT5FcXVpcGU8L2gyPlxyXG4gICAgICAgICAgPHAgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIsIG1hcmdpblRvcDogNiwgbWF4V2lkdGg6IDQ4MCB9fT5cclxuICAgICAgICAgICAgVG9kbyBtdW5kbyBxdWUgdHJhYmFsaGEgbmEgY2FzYSBmaWNhIGFxdWkg4oCUIG5lbSB0b2RvcyBwcmVjaXNhbSBkZSBhY2Vzc28gYW8gc2lzdGVtYS5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgb25DbGljaz17KCkgPT4gb3BlbkVkaXRvcihcIm5ld1wiKX0+KyBOb3ZvIGZ1bmNpb27DoXJpbzwvQnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtlcnJvciAmJiBlZGl0aW5nID09PSBudWxsICYmIGFjY2Vzc0RyYXdlckZvciA9PT0gbnVsbCAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgIHtlbXBsb3llZXNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtlbXBsb3llZXNRdWVyeS5lcnJvcn0gd2hhdD1cImZ1bmNpb27DoXJpb3NcIiAvPn1cclxuICAgICAge2pvYlRpdGxlc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e2pvYlRpdGxlc1F1ZXJ5LmVycm9yfSB3aGF0PVwiY2FyZ29zXCIgLz59XHJcblxyXG4gICAgICB7IWVtcGxveWVlc1F1ZXJ5LmlzTG9hZGluZyAmJiBlbXBsb3llZXMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtdG9vbGJhciByaXNlIHJpc2UtMVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtc2VhcmNoXCI+XHJcbiAgICAgICAgICAgIDxTZWFyY2hJY29uIC8+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQnVzY2FyIHBvciBub21lIG91IGNhcmdv4oCmXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNofVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWdtZW50ZWRcIiByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiRmlsdHJhciBwb3IgYWNlc3NvXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17c3RhdHVzRmlsdGVyID09PSBcImFsbFwiID8gXCJpcy1hY3RpdmVcIiA6IFwiXCJ9IG9uQ2xpY2s9eygpID0+IHNldFN0YXR1c0ZpbHRlcihcImFsbFwiKX0+XHJcbiAgICAgICAgICAgICAgVG9kb3Mgwrcge2VtcGxveWVlcy5sZW5ndGh9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e3N0YXR1c0ZpbHRlciA9PT0gXCJhY2Nlc3NcIiA/IFwiaXMtYWN0aXZlXCIgOiBcIlwifSBvbkNsaWNrPXsoKSA9PiBzZXRTdGF0dXNGaWx0ZXIoXCJhY2Nlc3NcIil9PlxyXG4gICAgICAgICAgICAgIENvbSBhY2Vzc28gwrcge3dpdGhBY2Nlc3NDb3VudH1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17c3RhdHVzRmlsdGVyID09PSBcIm5vLWxvZ2luXCIgPyBcImlzLWFjdGl2ZVwiIDogXCJcIn0gb25DbGljaz17KCkgPT4gc2V0U3RhdHVzRmlsdGVyKFwibm8tbG9naW5cIil9PlxyXG4gICAgICAgICAgICAgIFNlbSBsb2dpbiDCtyB7bm9Mb2dpbkNvdW50fVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAge2VtcGxveWVlc1F1ZXJ5LmlzTG9hZGluZyAmJiA8U2tlbGV0b25MaXN0IHJvd3M9ezV9IHJvd0hlaWdodD17NTh9IC8+fVxyXG5cclxuICAgICAgeyFlbXBsb3llZXNRdWVyeS5pc0xvYWRpbmcgJiYgZW1wbG95ZWVzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgIGljb249XCLwn6eR4oCN8J+Ns1wiXHJcbiAgICAgICAgICB0aXRsZT1cIk5lbmh1bSBmdW5jaW9uw6FyaW8gYXRpdm9cIlxyXG4gICAgICAgICAgZGVzY3JpcHRpb249XCJDYWRhc3RyZSBhIGVxdWlwZSBwYXJhIHBvZGVyIGFicmlyIHVzdcOhcmlvcyBlIHZpbmN1bGFyIHZlbmRhcyBhIHVtIHJlc3BvbnPDoXZlbC5cIlxyXG4gICAgICAgICAgYWN0aW9uPXtcclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIG9uQ2xpY2s9eygpID0+IG9wZW5FZGl0b3IoXCJuZXdcIil9PlxyXG4gICAgICAgICAgICAgICsgTm92byBmdW5jaW9uw6FyaW9cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHshZW1wbG95ZWVzUXVlcnkuaXNMb2FkaW5nICYmIGVtcGxveWVlcy5sZW5ndGggPiAwICYmIGZpbHRlcmVkRW1wbG95ZWVzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgIGljb249XCLwn5SNXCJcclxuICAgICAgICAgIHRpdGxlPVwiTmVuaHVtIGZ1bmNpb27DoXJpbyBlbmNvbnRyYWRvXCJcclxuICAgICAgICAgIGRlc2NyaXB0aW9uPXtgTmVuaHVtIHJlc3VsdGFkbyBwYXJhIFwiJHtzZWFyY2gudHJpbSgpfVwiIGNvbSBvIGZpbHRybyBhdHVhbC5gfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7IWVtcGxveWVlc1F1ZXJ5LmlzTG9hZGluZyAmJiBmaWx0ZXJlZEVtcGxveWVlcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC1ncmlkIHJpc2UgcmlzZS0xXCI+XHJcbiAgICAgICAgICB7ZmlsdGVyZWRFbXBsb3llZXMubWFwKChlbXBsb3llZSkgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGVtcC1jYXJkICR7IWVtcGxveWVlLmhhc1N5c3RlbUFjY2VzcyA/IFwiaXMtbm8tbG9naW5cIiA6IFwiXCJ9YH0ga2V5PXtlbXBsb3llZS5pZH0+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtY2FyZC10b3BcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLWF2YXRhclwiPntpbml0aWFsc09mKGVtcGxveWVlLm5hbWUpfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtbmFtZS1ibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC1uYW1lXCI+e2VtcGxveWVlLm5hbWV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLXJvbGVcIj57am9iVGl0bGVOYW1lLmdldChlbXBsb3llZS5qb2JUaXRsZUlkKSA/PyBgQ2FyZ28gJHtlbXBsb3llZS5qb2JUaXRsZUlkfWB9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGVtcC1zdGF0dXMtcGlsbCAke2VtcGxveWVlLmhhc1N5c3RlbUFjY2VzcyA/IFwiaXMtb25cIiA6IFwiaXMtb2ZmXCJ9YH0+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImVtcC1zdGF0dXMtZG90XCIgLz5cclxuICAgICAgICAgICAgICAgICAge2VtcGxveWVlLmhhc1N5c3RlbUFjY2VzcyA/IFwiQWNlc3NvIGF0aXZvXCIgOiBcIlNlbSBsb2dpblwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC1tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICBDUEYge2VtcGxveWVlLmNwZn1cclxuICAgICAgICAgICAgICAgIHtlbXBsb3llZS5zYWxhcnkgIT09IG51bGwgPyBgIMK3ICR7Zm9ybWF0QlJMKGVtcGxveWVlLnNhbGFyeSl9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHtlbXBsb3llZS5oYXNTeXN0ZW1BY2Nlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtY2hpcC1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZW1wLXBlcmZpbC1jaGlwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBlcmZpbEljb24gLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWUucm9sZU5hbWUgPz8gXCJQZXJmaWxcIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB7ZW1wbG95ZWUuZXh0cmFGZWF0dXJlQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJlbXAtZXh0cmEtY2hpcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgK3tlbXBsb3llZS5leHRyYUZlYXR1cmVDb3VudH0gYWNlc3Nve2VtcGxveWVlLmV4dHJhRmVhdHVyZUNvdW50ID4gMSA/IFwic1wiIDogXCJcIn0gZXh0cmFcclxuICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZS5leHRyYUZlYXR1cmVDb3VudCA+IDEgPyBcInNcIiA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtY2FyZC1mb290ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gb3BlbkVkaXRvcihlbXBsb3llZSl9PkVkaXRhcjwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAge2VtcGxveWVlLmhhc1N5c3RlbUFjY2VzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWNjZXNzRHJhd2VyRm9yKGVtcGxveWVlKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQWNlc3Nvc1xyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1aS1zcGFjZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgICBpY29uT25seVxyXG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiTWFpcyBhw6fDtWVzXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0T3BlbktlYmFiRm9yKG9wZW5LZWJhYkZvciA9PT0gZW1wbG95ZWUuaWQgPyBudWxsIDogZW1wbG95ZWUuaWQpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8S2ViYWJJY29uIC8+XHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIHtvcGVuS2ViYWJGb3IgPT09IGVtcGxveWVlLmlkICYmIChcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBwb3NpdGlvbjogXCJmaXhlZFwiLCBpbnNldDogMCwgekluZGV4OiA0IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuS2ViYWJGb3IobnVsbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC1rZWJhYi1tZW51XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpcy1kYW5nZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0T3BlbktlYmFiRm9yKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiRGVtaXRpclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBgRGVtaXRpciBcIiR7ZW1wbG95ZWUubmFtZX1cIj8gTyBhY2Vzc28gZSBvIENQRiBzZXLDo28gbGliZXJhZG9zLmAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJEZW1pdGlyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhbmdlcjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzbWlzc011dGF0aW9uLm11dGF0ZShlbXBsb3llZS5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIERlbWl0aXJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7ZWRpdGluZyAhPT0gbnVsbCAmJiAoXHJcbiAgICAgICAgPE1vZGFsIHRpdGxlPXtlZGl0aW5nID09PSBcIm5ld1wiID8gXCJOb3ZvIGZ1bmNpb27DoXJpb1wiIDogXCJFZGl0YXIgZnVuY2lvbsOhcmlvXCJ9IG9uQ2xvc2U9eygpID0+IHNldEVkaXRpbmcobnVsbCl9IHdpZGU+XHJcbiAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgIGxhYmVsPVwiTm9tZVwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtmb3JtLm5hbWV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIG5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgey8qIGFsaWduSXRlbXM6IFwiZW5kXCIg4oCUIG8gbGFiZWwgXCJDYXJnb1wiIHBvZGUgcXVlYnJhciBlbSAyIGxpbmhhcyBwb3IgY2F1c2EgZG9cclxuICAgICAgICAgICAgICBsaW5rIFwiKyBub3ZvIGNhcmdvXCIgZW1idXRpZG8gbmVsZTsgYWxpbmhhbmRvIHBlbG8gcm9kYXDDqSBkYSBsaW5oYSwgb3MgZG9pc1xyXG4gICAgICAgICAgICAgIGNhbXBvcyBmaWNhbSBzZW1wcmUgbmEgbWVzbWEgYWx0dXJhIChtZXNtbyBhanVzdGUgZmVpdG8gbm8gY2FkYXN0cm8gZGUgcHJvZHV0bykuICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiBcImVuZFwiIH19PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNjAgfX0+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJDUEYgKDExIGTDrWdpdG9zKVwiXHJcbiAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJudW1lcmljXCJcclxuICAgICAgICAgICAgICAgIG1heExlbmd0aD17MTF9XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJuZXdcIn1cclxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmNwZn1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGNwZjogZS50YXJnZXQudmFsdWUucmVwbGFjZSgvXFxEL2csIFwiXCIpIH0pfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAyMjAgfX0+XHJcbiAgICAgICAgICAgICAgPEZpZWxkXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgd2lkdGg6IFwiMTAwJVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIENhcmdvXHJcbiAgICAgICAgICAgICAgICAgICAgeyFjcmVhdGluZ0pvYlRpdGxlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENyZWF0aW5nSm9iVGl0bGUodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwidHJhbnNwYXJlbnRcIiwgYm9yZGVyOiBcIm5vbmVcIiwgY29sb3I6IFwidmFyKC0tYW1iZXIpXCIsIGN1cnNvcjogXCJwb2ludGVyXCIsIGZvbnRTaXplOiBcIjAuOHJlbVwiLCBwYWRkaW5nOiAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICsgbm92byBjYXJnb1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHsoYTExeSkgPT5cclxuICAgICAgICAgICAgICAgICAgY3JlYXRpbmdKb2JUaXRsZSA/IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogNiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Li4uYTExeX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb21lIGRvIGNhcmdvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0pvYlRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0pvYlRpdGxlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobmV3Sm9iVGl0bGUudHJpbSgpICE9PSBcIlwiKSBqb2JUaXRsZU11dGF0aW9uLm11dGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENyZWF0aW5nSm9iVGl0bGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TmV3Sm9iVGl0bGUoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17am9iVGl0bGVNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtuZXdKb2JUaXRsZS50cmltKCkgPT09IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGpvYlRpdGxlTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENyaWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbk9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNhbmNlbGFyIGNyaWHDp8OjbyBkZSBjYXJnb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0Q3JlYXRpbmdKb2JUaXRsZShmYWxzZSk7IHNldE5ld0pvYlRpdGxlKFwiXCIpOyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDinJVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHsuLi5hMTF5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uam9iVGl0bGVJZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGpvYlRpdGxlSWQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2lvbmUgbyBjYXJnb+KApjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgeyhqb2JUaXRsZXNRdWVyeS5kYXRhID8/IFtdKS5tYXAoKGopID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2ouaWR9IHZhbHVlPXtqLmlkfT57ai5uYW1lfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA8L0ZpZWxkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCI+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkUtbWFpbFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5lbWFpbH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGVtYWlsOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTYwIH19PlxyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiVGVsZWZvbmVcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ucGhvbmV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBwaG9uZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgIGxhYmVsPVwiU2Fsw6FyaW8gKFIkLCBvcGNpb25hbClcIlxyXG4gICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm0uc2FsYXJ5fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBzYWxhcnk6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICB7ZWRpdGluZyA9PT0gXCJuZXdcIiAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQsIG1hcmdpblRvcDogNCB9fT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC1kaXZpZGVyLWxhYmVsXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJlbXAtZGl2aWRlci1saW5lXCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkFjZXNzbyBhbyBzaXN0ZW1hPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZW1wLWRpdmlkZXItbGluZVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLXRvZ2dsZS1yb3dcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLXRvZ2dsZS1jb3B5XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLXRvZ2dsZS10aXRsZVwiPkVzdGUgY29sYWJvcmFkb3IgdXNhIG8gc2lzdGVtYTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC10b2dnbGUtaGludFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEF0aXZlIHPDsyBwYXJhIHF1ZW0gdmFpIG9wZXJhciBvIFBEViDigJQgY29wYSwgbGltcGV6YSBlIHNlZ3VyYW7Dp2Egbm9ybWFsbWVudGUgZmljYW0gZGVzbGlnYWRvcy5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxTd2l0Y2hcclxuICAgICAgICAgICAgICAgICAgY2hlY2tlZD17YWNjZXNzLmhhc1N5c3RlbUFjY2Vzc31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RvZ2dsZVN5c3RlbUFjY2Vzc31cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJFc3RlIGNvbGFib3JhZG9yIHVzYSBvIHNpc3RlbWFcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge2FjY2Vzcy5oYXNTeXN0ZW1BY2Nlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxNCB9fT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNjAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVXN1w6FyaW9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWNjZXNzLnVzZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFjY2Vzcyh7IC4uLmFjY2VzcywgdXNlck5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNjAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiRS1tYWlsIGRlIGxvZ2luXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2FjY2Vzcy51c2VyRW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QWNjZXNzKHsgLi4uYWNjZXNzLCB1c2VyRW1haWw6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlNlbmhhIChtw61uLiA4IGNhcmFjdGVyZXMpXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXthY2Nlc3MucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBY2Nlc3MoeyAuLi5hY2Nlc3MsIHBhc3N3b3JkOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtqb2JUaXRsZUlkTnVtICE9PSBudWxsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC1wZXJmaWwtYXV0by1jYXJkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC1wZXJmaWwtYXV0by1pY29uXCI+PFBlcmZpbEljb24gLz48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLXBlcmZpbC1hdXRvLWNvcHlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGI+UGVyZmlsOiB7am9iVGl0bGVOYW1lLmdldChqb2JUaXRsZUlkTnVtKSA/PyBcIuKAlFwifTwvYj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q3JpYWRvIGF1dG9tYXRpY2FtZW50ZSBhIHBhcnRpciBkbyBjYXJnbyDigJQgc2VtIHBhc3NvIGV4dHJhLjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAge2ZlYXR1cmVzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17ZmVhdHVyZXNRdWVyeS5lcnJvcn0gd2hhdD1cImFzIHRlbGFzXCIgLz59XHJcblxyXG4gICAgICAgICAgICAgICAgICB7Y2FyZ29GZWF0dXJlSWRzLnNpemUgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtYWNjZXNzLWdyb3VwLWxhYmVsXCI+TyBjYXJnbyBqw6EgbGliZXJhOjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtY2hpcHMtd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7KGZlYXR1cmVzUXVlcnkuZGF0YSA/PyBbXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKChmKSA9PiBjYXJnb0ZlYXR1cmVJZHMuaGFzKGYuaWQpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGYpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17Zi5pZH0gY2xhc3NOYW1lPVwiZW1wLWFjY2Vzcy1jaGlwIGlzLWxvY2tlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tJY29uIC8+IHtmLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtYWNjZXNzLWdyb3VwLWxhYmVsXCI+QWNlc3NvcyBleHRyYXMgc8OzIHBhcmEgZXN0YSBwZXNzb2E8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC1jaGlwcy13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7KGZlYXR1cmVzUXVlcnkuZGF0YSA/PyBbXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigoZikgPT4gIWNhcmdvRmVhdHVyZUlkcy5oYXMoZi5pZCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGYpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBvbiA9IGV4dHJhRmVhdHVyZUlkcy5pbmNsdWRlcyhmLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2YuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BlbXAtYWNjZXNzLWNoaXAgJHtvbiA/IFwiaXMtb25cIiA6IFwiaXMtb2ZmXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlRXh0cmFGZWF0dXJlKGYuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b24gJiYgPENoZWNrSWNvbiAvPn0ge2YubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG4gICAgICAgICAge2Zvcm0uam9iVGl0bGVJZCA9PT0gXCJcIiAmJiAoXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZpZWxkLWhpbnRcIiBzdHlsZT17eyBtYXJnaW46IDAgfX0+XHJcbiAgICAgICAgICAgICAgU2VsZWNpb25lIHVtIGNhcmdvIHBhcmEgaGFiaWxpdGFyIG8gc2FsdmFyLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAge2VkaXRpbmcgPT09IFwibmV3XCIgJiYgZm9ybS5jcGYubGVuZ3RoICE9PSAxMSAmJiBmb3JtLmNwZi5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZmllbGQtaGludFwiIHN0eWxlPXt7IG1hcmdpbjogMCB9fT5cclxuICAgICAgICAgICAgICBDUEYgcHJlY2lzYSBkZSAxMSBkw61naXRvcyAoe2Zvcm0uY3BmLmxlbmd0aH0vMTEpLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICBsb2FkaW5nPXtzYXZlTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgZm9ybS5uYW1lLnRyaW0oKSA9PT0gXCJcIiB8fFxyXG4gICAgICAgICAgICAgIGZvcm0uam9iVGl0bGVJZCA9PT0gXCJcIiB8fFxyXG4gICAgICAgICAgICAgIChlZGl0aW5nID09PSBcIm5ld1wiICYmIGZvcm0uY3BmLmxlbmd0aCAhPT0gMTEpIHx8XHJcbiAgICAgICAgICAgICAgIWFjY2Vzc0ZpZWxkc1ZhbGlkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2F2ZU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBTYWx2YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7YWNjZXNzRHJhd2VyRm9yICE9PSBudWxsICYmIChcclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIHRpdGxlPXtgQWNlc3NvcyDigJQgJHthY2Nlc3NEcmF3ZXJGb3IubmFtZX1gfVxyXG4gICAgICAgICAgb25DbG9zZT17Y2xvc2VEcmF3ZXJ9XHJcbiAgICAgICAgICB2YXJpYW50PVwiZHJhd2VyXCJcclxuICAgICAgICAgIGFyaWFMYWJlbD17YEFjZXNzb3MgZGUgJHthY2Nlc3NEcmF3ZXJGb3IubmFtZX1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImVtcC1pbmZvLWxpbmVcIj5cclxuICAgICAgICAgICAgTyBhY2Vzc28gZWZldGl2byDDqSBhIHNvbWEgZG8gcXVlIG8gY2FyZ28gasOhIGTDoSBjb20gbyBxdWUgZm9yIGxpZ2FkbyBhYmFpeG8sIHPDsyBwYXJhIGVzdGEgcGVzc29hLlxyXG4gICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgIHtkcmF3ZXJDYXJnb0ZlYXR1cmVzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17ZHJhd2VyQ2FyZ29GZWF0dXJlc1F1ZXJ5LmVycm9yfSB3aGF0PVwib3MgYWNlc3NvcyBkbyBjYXJnb1wiIC8+fVxyXG4gICAgICAgICAge2RyYXdlclVzZXJGZWF0dXJlc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e2RyYXdlclVzZXJGZWF0dXJlc1F1ZXJ5LmVycm9yfSB3aGF0PVwib3MgYWNlc3NvcyBkYSBwZXNzb2FcIiAvPn1cclxuICAgICAgICAgIHtmZWF0dXJlc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e2ZlYXR1cmVzUXVlcnkuZXJyb3J9IHdoYXQ9XCJhcyB0ZWxhc1wiIC8+fVxyXG5cclxuICAgICAgICAgIHtkcmF3ZXJDYXJnb0ZlYXR1cmVJZHMuc2l6ZSA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLWFjY2Vzcy1ncm91cC1sYWJlbFwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogOCB9fT5cclxuICAgICAgICAgICAgICAgIErDoSBpbmNsdXNvIHBlbG8gY2FyZ28gXCJ7am9iVGl0bGVOYW1lLmdldChhY2Nlc3NEcmF3ZXJGb3Iuam9iVGl0bGVJZCkgPz8gXCJcIn1cIlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLWxvY2tlZC1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICB7KGZlYXR1cmVzUXVlcnkuZGF0YSA/PyBbXSlcclxuICAgICAgICAgICAgICAgICAgLmZpbHRlcigoZikgPT4gZHJhd2VyQ2FyZ29GZWF0dXJlSWRzLmhhcyhmLmlkKSlcclxuICAgICAgICAgICAgICAgICAgLm1hcCgoZikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLWxvY2tlZC1yb3dcIiBrZXk9e2YuaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENoZWNrSWNvbiAvPiB7Zi5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLWFjY2Vzcy1ncm91cC1sYWJlbFwiPkFjZXNzb3MgZXh0cmFzIGRlc3RhIHBlc3NvYTwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcC10b2dnbGUtbGlzdFwiPlxyXG4gICAgICAgICAgICAgIHsoZmVhdHVyZXNRdWVyeS5kYXRhID8/IFtdKVxyXG4gICAgICAgICAgICAgICAgLmZpbHRlcigoZikgPT4gIWRyYXdlckNhcmdvRmVhdHVyZUlkcy5oYXMoZi5pZCkpXHJcbiAgICAgICAgICAgICAgICAubWFwKChmKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wLXRvZ2dsZS1pdGVtXCIga2V5PXtmLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Zi5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8U3dpdGNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtkcmF3ZXJFeHRyYXMuaW5jbHVkZXMoZi5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gdG9nZ2xlRHJhd2VyRXh0cmEoZi5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17ZHJhd2VyRXh0cmFzLmluY2x1ZGVzKGYuaWQpID8gYFJlbW92ZXIgYWNlc3NvIGEgJHtmLm5hbWV9YCA6IGBDb25jZWRlciBhY2Vzc28gYSAke2YubmFtZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuXHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgbG9hZGluZz17ZHJhd2VyU2F2ZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2RyYXdlclVzZXJGZWF0dXJlc1F1ZXJ5LmlzTG9hZGluZ31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZHJhd2VyU2F2ZU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBTYWx2YXIgYWNlc3Nvc1xyXG4gICAgICAgICAgPC9CdXR0b24+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtZGFuZ2VyLXJvd1wiIHN0eWxlPXt7IGJvcmRlclRvcDogXCIxcHggc29saWQgdmFyKC0tbGluZSlcIiwgcGFkZGluZ1RvcDogMTQsIG1hcmdpblRvcDogMiB9fT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXAtZGFuZ2VyLWNvcHlcIj5cclxuICAgICAgICAgICAgICA8Yj5EZXNhdGl2YXIgbG9naW48L2I+XHJcbiAgICAgICAgICAgICAgPHNwYW4+TyBmdW5jaW9uw6FyaW8gY29udGludWEgbmEgZXF1aXBlLCBzw7MgcGVyZGUgbyBhY2Vzc28gYW8gc2lzdGVtYS48L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cImRhbmdlclwiXHJcbiAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICBsb2FkaW5nPXtkZWFjdGl2YXRlTG9naW5NdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICBhd2FpdCBkaWFsb2cuY29uZmlybSh7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiRGVzYXRpdmFyIGxvZ2luXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYERlc2F0aXZhciBvIGxvZ2luIGRlIFwiJHthY2Nlc3NEcmF3ZXJGb3IubmFtZX1cIj8gTyBmdW5jaW9uw6FyaW8gY29udGludWEgbmEgZXF1aXBlLmAsXHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlybUxhYmVsOiBcIkRlc2F0aXZhclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhbmdlcjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgZGVhY3RpdmF0ZUxvZ2luTXV0YXRpb24ubXV0YXRlKCk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIERlc2F0aXZhclxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICl9XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvZW1wbG95ZWVzL0VtcGxveWVlc1BhZ2UudHN4In0=