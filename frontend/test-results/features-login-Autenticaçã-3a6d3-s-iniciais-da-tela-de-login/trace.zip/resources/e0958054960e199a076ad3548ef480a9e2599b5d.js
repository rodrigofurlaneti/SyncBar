import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/publicOrdering/ComandaReadingValidation.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Html5Qrcode } from "/node_modules/.vite/deps/html5-qrcode.js?v=ca0b4140";
import { validateComandaReading, validateTableReading } from "/src/features/publicOrdering/api.ts";
export const needsReadingValidation = (r) => r.isCameraInputEnabled || r.isBarcodeEnabled || r.isQrCodeEnabled;
const SCANNER_ELEMENT_ID = "reading-validation-scanner";
const cameraErrorMessage = (err) => {
  const name = err instanceof Error ? err.name : "";
  switch (name) {
    case "NotAllowedError":
      return "O navegador bloqueou o acesso à câmera. Libere a permissão de câmera para este site nas configurações do navegador e tente de novo.";
    case "NotFoundError":
    case "OverconstrainedError":
      return "Nenhuma câmera foi encontrada neste dispositivo.";
    case "NotReadableError":
      return "A câmera já está sendo usada por outro aplicativo ou aba. Feche-o e tente de novo.";
    default:
      return "Não foi possível acessar a câmera. Verifique a permissão do navegador.";
  }
};
const safeStopScanner = (ref) => {
  try {
    ref.current?.stop().catch(() => void 0);
  } catch {
  }
};
function ReadingValidationGate({ requirement, subtitle, submit, onValidated, onCancel }) {
  _s();
  const [scanning, setScanning] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);
  const scannerRef = useRef(null);
  const hasDecodedRef = useRef(false);
  const wantsScan = requirement.isBarcodeEnabled || requirement.isQrCodeEnabled;
  const scanMethod = requirement.isQrCodeEnabled ? "qrcode" : "barcode";
  useEffect(() => {
    return () => {
      safeStopScanner(scannerRef);
    };
  }, []);
  const doSubmit = async (method, payload) => {
    setSubmitting(true);
    setError(null);
    try {
      await submit(method, payload);
      onValidated();
    } catch {
      setError("Não foi possível confirmar a validação. Tente novamente.");
    } finally {
      setSubmitting(false);
    }
  };
  const handlePhotoSelected = (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = typeof reader.result === "string" ? reader.result : "";
      if (dataUrl) void doSubmit("camera", { photoBase64: dataUrl });
    };
    reader.readAsDataURL(file);
  };
  const startScan = async () => {
    setError(null);
    setScanning(true);
    hasDecodedRef.current = false;
    try {
      const scanner = new Html5Qrcode(SCANNER_ELEMENT_ID);
      scannerRef.current = scanner;
      const onDecoded = (decodedText) => {
        if (hasDecodedRef.current) return;
        hasDecodedRef.current = true;
        const finishSubmit = () => {
          setScanning(false);
          void doSubmit(scanMethod, { scannedValue: decodedText });
        };
        try {
          void scanner.stop().catch(() => void 0).finally(finishSubmit);
        } catch {
          finishSubmit();
        }
      };
      const onFrame = () => {
      };
      try {
        await scanner.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 240, height: 240 } }, onDecoded, onFrame);
      } catch {
        await scanner.start({ facingMode: "user" }, { fps: 10, qrbox: { width: 240, height: 240 } }, onDecoded, onFrame);
      }
    } catch (err) {
      setScanning(false);
      setError(cameraErrorMessage(err));
    }
  };
  const stopScan = () => {
    safeStopScanner(scannerRef);
    setScanning(false);
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 16, textAlign: "center" }, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { style: { margin: "0 0 6px", color: "#fff", fontSize: "1.15rem" }, children: "Confirme para continuar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
        lineNumber: 191,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { style: { margin: 0, color: "#a8a8b3", fontSize: "0.9rem" }, children: subtitle }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
        lineNumber: 192,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 190,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { id: SCANNER_ELEMENT_ID, style: { width: "100%", borderRadius: 8, overflow: "hidden", display: scanning ? "block" : "none" } }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 204,
      columnNumber: 13
    }, this),
    scanning ? /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: stopScan, className: "btn-ghost", children: "Cancelar leitura" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 206,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10 }, children: [
      requirement.isCameraInputEnabled && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            ref: fileInputRef,
            type: "file",
            accept: "image/*",
            capture: "user",
            style: { display: "none" },
            onChange: (e) => {
              const file = e.target.files?.[0];
              if (file) handlePhotoSelected(file);
              e.target.value = "";
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
            lineNumber: 211,
            columnNumber: 29
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            disabled: submitting,
            onClick: () => fileInputRef.current?.click(),
            style: { padding: 14, borderRadius: 8, border: "1px solid #323238", backgroundColor: "#f59e0b", color: "#121214", fontWeight: "bold", cursor: submitting ? "not-allowed" : "pointer" },
            children: "📷 Tirar uma foto"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
            lineNumber: 223,
            columnNumber: 29
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
        lineNumber: 210,
        columnNumber: 9
      }, this),
      wantsScan && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          disabled: submitting,
          onClick: () => void startScan(),
          style: { padding: 14, borderRadius: 8, border: "1px solid #323238", backgroundColor: "#f59e0b", color: "#121214", fontWeight: "bold", cursor: submitting ? "not-allowed" : "pointer" },
          children: requirement.isQrCodeEnabled ? "▦ Escanear QR Code" : "▥ Escanear código de barras"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
          lineNumber: 234,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onCancel, disabled: submitting, className: "btn-ghost", children: "Cancelar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
        lineNumber: 243,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 208,
      columnNumber: 7
    }, this),
    submitting && /* @__PURE__ */ jsxDEV("p", { style: { color: "#a8a8b3", fontSize: "0.9rem" }, children: "Confirmando…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 249,
      columnNumber: 28
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { style: { color: "#ef4444", fontSize: "0.9rem" }, children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 250,
      columnNumber: 23
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
    lineNumber: 189,
    columnNumber: 5
  }, this);
}
_s(ReadingValidationGate, "FfsDZ0758se2J27XLJAGlf3n8m0=");
_c = ReadingValidationGate;
export function ComandaReadingValidation({ token, comandaCode, requirement, onValidated, onCancel }) {
  return /* @__PURE__ */ jsxDEV(
    ReadingValidationGate,
    {
      requirement,
      subtitle: `Esta filial exige uma confirmação extra para abrir a comanda ${comandaCode}. Escolha uma das opções abaixo.`,
      submit: (method, payload) => validateComandaReading(token, comandaCode, { method, ...payload }),
      onValidated,
      onCancel
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 266,
      columnNumber: 5
    },
    this
  );
}
_c2 = ComandaReadingValidation;
export function TableReadingValidation({ token, requirement, onValidated, onCancel }) {
  return /* @__PURE__ */ jsxDEV(
    ReadingValidationGate,
    {
      requirement,
      subtitle: "Esta filial exige uma confirmação extra antes de fazer pedidos nesta mesa. Escolha uma das opções abaixo.",
      submit: (method, payload) => validateTableReading(token, { method, ...payload }),
      onValidated,
      onCancel
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 292,
      columnNumber: 5
    },
    this
  );
}
_c3 = TableReadingValidation;
const LINK_SCANNER_ELEMENT_ID = "link-comanda-scanner";
export function LinkComandaValidation({ token, requirement, onLinked, onCancel }) {
  _s2();
  const wantsScan = requirement.isBarcodeEnabled || requirement.isQrCodeEnabled;
  const scanMethod = requirement.isQrCodeEnabled ? "qrcode" : "barcode";
  const [manualCode, setManualCode] = useState("");
  const [scanning, setScanning] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);
  const scannerRef = useRef(null);
  const hasDecodedRef = useRef(false);
  useEffect(() => {
    return () => {
      safeStopScanner(scannerRef);
    };
  }, []);
  const linkComanda = async (code, method, payload) => {
    setSubmitting(true);
    setError(null);
    try {
      await validateComandaReading(token, code, { method, ...payload });
      onLinked(code);
    } catch {
      setError("Não foi possível vincular a comanda. Confira o número/código e tente de novo.");
    } finally {
      setSubmitting(false);
    }
  };
  const handlePhotoSelected = (file) => {
    if (!manualCode.trim()) {
      setError("Informe o número da comanda antes de tirar a foto.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = typeof reader.result === "string" ? reader.result : "";
      if (dataUrl) void linkComanda(manualCode.trim(), "camera", { photoBase64: dataUrl });
    };
    reader.readAsDataURL(file);
  };
  const startScan = async () => {
    setError(null);
    setScanning(true);
    hasDecodedRef.current = false;
    try {
      const scanner = new Html5Qrcode(LINK_SCANNER_ELEMENT_ID);
      scannerRef.current = scanner;
      const onDecoded = (decodedText) => {
        if (hasDecodedRef.current) return;
        hasDecodedRef.current = true;
        const finishLink = () => {
          setScanning(false);
          void linkComanda(decodedText, scanMethod, { scannedValue: decodedText });
        };
        try {
          void scanner.stop().catch(() => void 0).finally(finishLink);
        } catch {
          finishLink();
        }
      };
      const onFrame = () => {
      };
      try {
        await scanner.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 240, height: 240 } }, onDecoded, onFrame);
      } catch {
        await scanner.start({ facingMode: "user" }, { fps: 10, qrbox: { width: 240, height: 240 } }, onDecoded, onFrame);
      }
    } catch (err) {
      setScanning(false);
      setError(cameraErrorMessage(err));
    }
  };
  const stopScan = () => {
    safeStopScanner(scannerRef);
    setScanning(false);
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 16, textAlign: "center" }, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { style: { margin: "0 0 6px", color: "#fff", fontSize: "1.15rem" }, children: "Vincular à comanda" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
        lineNumber: 423,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { style: { margin: 0, color: "#a8a8b3", fontSize: "0.9rem" }, children: wantsScan ? `Escaneie o ${requirement.isQrCodeEnabled ? "QR Code" : "código de barras"} da comanda para lançar este pedido nela.` : "Informe o número da comanda e tire uma foto dela para lançar este pedido nela." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
        lineNumber: 424,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 422,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { id: LINK_SCANNER_ELEMENT_ID, style: { width: "100%", borderRadius: 8, overflow: "hidden", display: scanning ? "block" : "none" } }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 434,
      columnNumber: 13
    }, this),
    scanning ? /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: stopScan, className: "btn-ghost", children: "Cancelar leitura" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 436,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10 }, children: [
      !wantsScan && requirement.isCameraInputEnabled && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: manualCode,
            onChange: (e) => setManualCode(e.target.value),
            placeholder: "Número da comanda (ex: 001)",
            autoFocus: true,
            style: { width: "100%", padding: "14px 16px", borderRadius: 8, border: "1px solid #323238", backgroundColor: "#121214", color: "#fff", fontSize: "1rem", outline: "none", boxSizing: "border-box" }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
            lineNumber: 441,
            columnNumber: 29
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            ref: fileInputRef,
            type: "file",
            accept: "image/*",
            capture: "user",
            style: { display: "none" },
            onChange: (e) => {
              const file = e.target.files?.[0];
              if (file) handlePhotoSelected(file);
              e.target.value = "";
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
            lineNumber: 449,
            columnNumber: 29
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            disabled: submitting || !manualCode.trim(),
            onClick: () => fileInputRef.current?.click(),
            style: { padding: 14, borderRadius: 8, border: "1px solid #323238", backgroundColor: "#f59e0b", color: "#121214", fontWeight: "bold", cursor: submitting || !manualCode.trim() ? "not-allowed" : "pointer" },
            children: "📷 Tirar uma foto"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
            lineNumber: 461,
            columnNumber: 29
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
        lineNumber: 440,
        columnNumber: 9
      }, this),
      wantsScan && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          disabled: submitting,
          onClick: () => void startScan(),
          style: { padding: 14, borderRadius: 8, border: "1px solid #323238", backgroundColor: "#f59e0b", color: "#121214", fontWeight: "bold", cursor: submitting ? "not-allowed" : "pointer" },
          children: requirement.isQrCodeEnabled ? "▦ Escanear QR Code da comanda" : "▥ Escanear código de barras da comanda"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
          lineNumber: 472,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onCancel, disabled: submitting, className: "btn-ghost", children: "Cancelar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
        lineNumber: 481,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 438,
      columnNumber: 7
    }, this),
    submitting && /* @__PURE__ */ jsxDEV("p", { style: { color: "#a8a8b3", fontSize: "0.9rem" }, children: "Vinculando…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 487,
      columnNumber: 28
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { style: { color: "#ef4444", fontSize: "0.9rem" }, children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
      lineNumber: 488,
      columnNumber: 23
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx",
    lineNumber: 421,
    columnNumber: 5
  }, this);
}
_s2(LinkComandaValidation, "9SvWom8YxJfcKPUmw+SfEMmsOVI=");
_c4 = LinkComandaValidation;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "ReadingValidationGate");
$RefreshReg$(_c2, "ComandaReadingValidation");
$RefreshReg$(_c3, "TableReadingValidation");
$RefreshReg$(_c4, "LinkComandaValidation");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/ComandaReadingValidation.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMktnQixTQW1CUSxVQW5CUjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEzS2hCLFNBQVNBLFdBQVdDLFFBQVFDLGdCQUFnQjtBQUM1QyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msd0JBQXdCQyw0QkFBNEI7QUFTdEQsYUFBTUMseUJBQXlCQSxDQUFDQyxNQUNuQ0EsRUFBRUMsd0JBQXdCRCxFQUFFRSxvQkFBb0JGLEVBQUVHO0FBYXRELE1BQU1DLHFCQUFxQjtBQUUzQixNQUFNQyxxQkFBcUJBLENBQUNDLFFBQXlCO0FBQ2pELFFBQU1DLE9BQU9ELGVBQWVFLFFBQVFGLElBQUlDLE9BQU87QUFDL0MsVUFBUUEsTUFBSTtBQUFBLElBQ1IsS0FBSztBQUNELGFBQU87QUFBQSxJQUNYLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFDRCxhQUFPO0FBQUEsSUFDWCxLQUFLO0FBQ0QsYUFBTztBQUFBLElBQ1g7QUFDSSxhQUFPO0FBQUEsRUFDZjtBQUNKO0FBaUJBLE1BQU1FLGtCQUFrQkEsQ0FBQ0MsUUFBeUM7QUFDOUQsTUFBSTtBQUNBQSxRQUFJQyxTQUFTQyxLQUFLLEVBQUVDLE1BQU0sTUFBTUMsTUFBUztBQUFBLEVBQzdDLFFBQVE7QUFBQSxFQUNKO0FBRVI7QUFVQSxTQUFTQyxzQkFBc0IsRUFBRUMsYUFBYUMsVUFBVUMsUUFBUUMsYUFBYUMsU0FBb0IsR0FBRztBQUFBQyxLQUFBO0FBQ2hHLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJNUIsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzZCLFlBQVlDLGFBQWEsSUFBSTlCLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUMrQixPQUFPQyxRQUFRLElBQUloQyxTQUF3QixJQUFJO0FBQ3RELFFBQU1pQyxlQUFlbEMsT0FBeUIsSUFBSTtBQUNsRCxRQUFNbUMsYUFBYW5DLE9BQTJCLElBQUk7QUFNbEQsUUFBTW9DLGdCQUFnQnBDLE9BQU8sS0FBSztBQUVsQyxRQUFNcUMsWUFBWWYsWUFBWWQsb0JBQW9CYyxZQUFZYjtBQUc5RCxRQUFNNkIsYUFBYWhCLFlBQVliLGtCQUFrQixXQUFXO0FBRTVEVixZQUFVLE1BQU07QUFDWixXQUFPLE1BQU07QUFDVGdCLHNCQUFnQm9CLFVBQVU7QUFBQSxJQUM5QjtBQUFBLEVBQ0osR0FBRyxFQUFFO0FBRUwsUUFBTUksV0FBVyxPQUFPQyxRQUF5Q0MsWUFBMkI7QUFDeEZWLGtCQUFjLElBQUk7QUFDbEJFLGFBQVMsSUFBSTtBQUNiLFFBQUk7QUFDQSxZQUFNVCxPQUFPZ0IsUUFBUUMsT0FBTztBQUM1QmhCLGtCQUFZO0FBQUEsSUFDaEIsUUFBUTtBQUNKUSxlQUFTLDBEQUEwRDtBQUFBLElBQ3ZFLFVBQUM7QUFDR0Ysb0JBQWMsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDSjtBQUVBLFFBQU1XLHNCQUFzQkEsQ0FBQ0MsU0FBZTtBQUN4QyxVQUFNQyxTQUFTLElBQUlDLFdBQVc7QUFDOUJELFdBQU9FLFNBQVMsTUFBTTtBQUNsQixZQUFNQyxVQUFVLE9BQU9ILE9BQU9JLFdBQVcsV0FBV0osT0FBT0ksU0FBUztBQUNwRSxVQUFJRCxRQUFTLE1BQUtSLFNBQVMsVUFBVSxFQUFFVSxhQUFhRixRQUFRLENBQUM7QUFBQSxJQUNqRTtBQUNBSCxXQUFPTSxjQUFjUCxJQUFJO0FBQUEsRUFDN0I7QUFFQSxRQUFNUSxZQUFZLFlBQVk7QUFDMUJsQixhQUFTLElBQUk7QUFDYkosZ0JBQVksSUFBSTtBQUNoQk8sa0JBQWNuQixVQUFVO0FBQ3hCLFFBQUk7QUFLQSxZQUFNbUMsVUFBVSxJQUFJbEQsWUFBWVEsa0JBQWtCO0FBQ2xEeUIsaUJBQVdsQixVQUFVbUM7QUFDckIsWUFBTUMsWUFBWUEsQ0FBQ0MsZ0JBQXdCO0FBR3ZDLFlBQUlsQixjQUFjbkIsUUFBUztBQUMzQm1CLHNCQUFjbkIsVUFBVTtBQUN4QixjQUFNc0MsZUFBZUEsTUFBTTtBQUN2QjFCLHNCQUFZLEtBQUs7QUFDakIsZUFBS1UsU0FBU0QsWUFBWSxFQUFFa0IsY0FBY0YsWUFBWSxDQUFDO0FBQUEsUUFDM0Q7QUFDQSxZQUFJO0FBQ0EsZUFBS0YsUUFBUWxDLEtBQUssRUFBRUMsTUFBTSxNQUFNQyxNQUFTLEVBQUVxQyxRQUFRRixZQUFZO0FBQUEsUUFDbkUsUUFBUTtBQUlKQSx1QkFBYTtBQUFBLFFBQ2pCO0FBQUEsTUFDSjtBQUNBLFlBQU1HLFVBQVVBLE1BQU07QUFBQSxNQUFFO0FBQ3hCLFVBQUk7QUFJQSxjQUFNTixRQUFRTyxNQUFNLEVBQUVDLFlBQVksY0FBYyxHQUFHLEVBQUVDLEtBQUssSUFBSUMsT0FBTyxFQUFFQyxPQUFPLEtBQUtDLFFBQVEsSUFBSSxFQUFFLEdBQUdYLFdBQVdLLE9BQU87QUFBQSxNQUMxSCxRQUFRO0FBQ0osY0FBTU4sUUFBUU8sTUFBTSxFQUFFQyxZQUFZLE9BQU8sR0FBRyxFQUFFQyxLQUFLLElBQUlDLE9BQU8sRUFBRUMsT0FBTyxLQUFLQyxRQUFRLElBQUksRUFBRSxHQUFHWCxXQUFXSyxPQUFPO0FBQUEsTUFDbkg7QUFBQSxJQUNKLFNBQVM5QyxLQUFLO0FBQ1ZpQixrQkFBWSxLQUFLO0FBQ2pCSSxlQUFTdEIsbUJBQW1CQyxHQUFHLENBQUM7QUFBQSxJQUNwQztBQUFBLEVBQ0o7QUFFQSxRQUFNcUQsV0FBV0EsTUFBTTtBQUNuQmxELG9CQUFnQm9CLFVBQVU7QUFDMUJOLGdCQUFZLEtBQUs7QUFBQSxFQUNyQjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxPQUFPLEVBQUVxQyxTQUFTLFFBQVFDLEtBQUssSUFBSUMsV0FBVyxTQUFTLEdBQ3hEO0FBQUEsMkJBQUMsU0FDRztBQUFBLDZCQUFDLFFBQUcsT0FBTyxFQUFFQyxRQUFRLFdBQVdDLE9BQU8sUUFBUUMsVUFBVSxVQUFVLEdBQUcsdUNBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkY7QUFBQSxNQUM3Rix1QkFBQyxPQUFFLE9BQU8sRUFBRUYsUUFBUSxHQUFHQyxPQUFPLFdBQVdDLFVBQVUsU0FBUyxHQUFJaEQsc0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxTQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQVdBLHVCQUFDLFNBQUksSUFBSWIsb0JBQW9CLE9BQU8sRUFBRXFELE9BQU8sUUFBUVMsY0FBYyxHQUFHQyxVQUFVLFVBQVVQLFNBQVN0QyxXQUFXLFVBQVUsT0FBTyxLQUEvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlJO0FBQUEsSUFDaElBLFdBQ0csdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBU3FDLFVBQVUsV0FBVSxhQUFZLGdDQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStFLElBRS9FLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNsQzdDO0FBQUFBLGtCQUFZZix3QkFDVCxtQ0FDSTtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxLQUFLMkI7QUFBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxRQUFPO0FBQUEsWUFDUCxTQUFRO0FBQUEsWUFDUixPQUFPLEVBQUVnQyxTQUFTLE9BQU87QUFBQSxZQUN6QixVQUFVLENBQUNRLE1BQU07QUFDYixvQkFBTS9CLE9BQU8rQixFQUFFQyxPQUFPQyxRQUFRLENBQUM7QUFDL0Isa0JBQUlqQyxLQUFNRCxxQkFBb0JDLElBQUk7QUFDbEMrQixnQkFBRUMsT0FBT0UsUUFBUTtBQUFBLFlBQ3JCO0FBQUE7QUFBQSxVQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVNO0FBQUEsUUFFTjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsVUFBVS9DO0FBQUFBLFlBQ1YsU0FBUyxNQUFNSSxhQUFhakIsU0FBUzZELE1BQU07QUFBQSxZQUMzQyxPQUFPLEVBQUVDLFNBQVMsSUFBSVAsY0FBYyxHQUFHUSxRQUFRLHFCQUFxQkMsaUJBQWlCLFdBQVdYLE9BQU8sV0FBV1ksWUFBWSxRQUFRQyxRQUFRckQsYUFBYSxnQkFBZ0IsVUFBVTtBQUFBLFlBQUU7QUFBQTtBQUFBLFVBSjNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0FwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLE1BRUhPLGFBQ0c7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFVBQVVQO0FBQUFBLFVBQ1YsU0FBUyxNQUFNLEtBQUtxQixVQUFVO0FBQUEsVUFDOUIsT0FBTyxFQUFFNEIsU0FBUyxJQUFJUCxjQUFjLEdBQUdRLFFBQVEscUJBQXFCQyxpQkFBaUIsV0FBV1gsT0FBTyxXQUFXWSxZQUFZLFFBQVFDLFFBQVFyRCxhQUFhLGdCQUFnQixVQUFVO0FBQUEsVUFFcExSLHNCQUFZYixrQkFBa0IsdUJBQXVCO0FBQUE7QUFBQSxRQU4xRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLE1BRUosdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBU2lCLFVBQVUsVUFBVUksWUFBWSxXQUFVLGFBQVksd0JBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQ0E7QUFBQSxJQUdIQSxjQUFjLHVCQUFDLE9BQUUsT0FBTyxFQUFFd0MsT0FBTyxXQUFXQyxVQUFVLFNBQVMsR0FBRyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRTtBQUFBLElBQzlFdkMsU0FBUyx1QkFBQyxPQUFFLE9BQU8sRUFBRXNDLE9BQU8sV0FBV0MsVUFBVSxTQUFTLEdBQUl2QyxtQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRDtBQUFBLE9BN0R6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOERBO0FBRVI7QUFBQ0wsR0FoS1FOLHVCQUFxQjtBQUFBLEtBQXJCQTtBQTJLRixnQkFBUytELHlCQUF5QixFQUFFQyxPQUFPQyxhQUFhaEUsYUFBYUcsYUFBYUMsU0FBdUIsR0FBRztBQUMvRyxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRztBQUFBLE1BQ0EsVUFBVSxnRUFBZ0U0RCxXQUFXO0FBQUEsTUFDckYsUUFBUSxDQUFDOUMsUUFBUUMsWUFBWXRDLHVCQUF1QmtGLE9BQU9DLGFBQWEsRUFBRTlDLFFBQVEsR0FBR0MsUUFBUSxDQUFDO0FBQUEsTUFDOUY7QUFBQSxNQUNBO0FBQUE7QUFBQSxJQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUt1QjtBQUcvQjtBQUFDOEMsTUFWZUg7QUEwQlQsZ0JBQVNJLHVCQUF1QixFQUFFSCxPQUFPL0QsYUFBYUcsYUFBYUMsU0FBcUIsR0FBRztBQUM5RixTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRztBQUFBLE1BQ0EsVUFBUztBQUFBLE1BQ1QsUUFBUSxDQUFDYyxRQUFRQyxZQUFZckMscUJBQXFCaUYsT0FBTyxFQUFFN0MsUUFBUSxHQUFHQyxRQUFRLENBQUM7QUFBQSxNQUMvRTtBQUFBLE1BQ0E7QUFBQTtBQUFBLElBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS3VCO0FBRy9CO0FBQUNnRCxNQVZlRDtBQW1CaEIsTUFBTUUsMEJBQTBCO0FBY3pCLGdCQUFTQyxzQkFBc0IsRUFBRU4sT0FBTy9ELGFBQWFzRSxVQUFVbEUsU0FBMkIsR0FBRztBQUFBbUUsTUFBQTtBQUNoRyxRQUFNeEQsWUFBWWYsWUFBWWQsb0JBQW9CYyxZQUFZYjtBQUM5RCxRQUFNNkIsYUFBYWhCLFlBQVliLGtCQUFrQixXQUFXO0FBRTVELFFBQU0sQ0FBQ3FGLFlBQVlDLGFBQWEsSUFBSTlGLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMyQixVQUFVQyxXQUFXLElBQUk1QixTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDNkIsWUFBWUMsYUFBYSxJQUFJOUIsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQytCLE9BQU9DLFFBQVEsSUFBSWhDLFNBQXdCLElBQUk7QUFDdEQsUUFBTWlDLGVBQWVsQyxPQUF5QixJQUFJO0FBQ2xELFFBQU1tQyxhQUFhbkMsT0FBMkIsSUFBSTtBQUtsRCxRQUFNb0MsZ0JBQWdCcEMsT0FBTyxLQUFLO0FBRWxDRCxZQUFVLE1BQU07QUFDWixXQUFPLE1BQU07QUFDVGdCLHNCQUFnQm9CLFVBQVU7QUFBQSxJQUM5QjtBQUFBLEVBQ0osR0FBRyxFQUFFO0FBRUwsUUFBTTZELGNBQWMsT0FBT0MsTUFBY3pELFFBQXlDQyxZQUEyQjtBQUN6R1Ysa0JBQWMsSUFBSTtBQUNsQkUsYUFBUyxJQUFJO0FBQ2IsUUFBSTtBQUlBLFlBQU05Qix1QkFBdUJrRixPQUFPWSxNQUFNLEVBQUV6RCxRQUFRLEdBQUdDLFFBQVEsQ0FBQztBQUNoRW1ELGVBQVNLLElBQUk7QUFBQSxJQUNqQixRQUFRO0FBQ0poRSxlQUFTLCtFQUErRTtBQUFBLElBQzVGLFVBQUM7QUFDR0Ysb0JBQWMsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDSjtBQUVBLFFBQU1XLHNCQUFzQkEsQ0FBQ0MsU0FBZTtBQUN4QyxRQUFJLENBQUNtRCxXQUFXSSxLQUFLLEdBQUc7QUFDcEJqRSxlQUFTLG9EQUFvRDtBQUM3RDtBQUFBLElBQ0o7QUFDQSxVQUFNVyxTQUFTLElBQUlDLFdBQVc7QUFDOUJELFdBQU9FLFNBQVMsTUFBTTtBQUNsQixZQUFNQyxVQUFVLE9BQU9ILE9BQU9JLFdBQVcsV0FBV0osT0FBT0ksU0FBUztBQUNwRSxVQUFJRCxRQUFTLE1BQUtpRCxZQUFZRixXQUFXSSxLQUFLLEdBQUcsVUFBVSxFQUFFakQsYUFBYUYsUUFBUSxDQUFDO0FBQUEsSUFDdkY7QUFDQUgsV0FBT00sY0FBY1AsSUFBSTtBQUFBLEVBQzdCO0FBRUEsUUFBTVEsWUFBWSxZQUFZO0FBQzFCbEIsYUFBUyxJQUFJO0FBQ2JKLGdCQUFZLElBQUk7QUFDaEJPLGtCQUFjbkIsVUFBVTtBQUN4QixRQUFJO0FBSUEsWUFBTW1DLFVBQVUsSUFBSWxELFlBQVl3Rix1QkFBdUI7QUFDdkR2RCxpQkFBV2xCLFVBQVVtQztBQUNyQixZQUFNQyxZQUFZQSxDQUFDQyxnQkFBd0I7QUFHdkMsWUFBSWxCLGNBQWNuQixRQUFTO0FBQzNCbUIsc0JBQWNuQixVQUFVO0FBQ3hCLGNBQU1rRixhQUFhQSxNQUFNO0FBQ3JCdEUsc0JBQVksS0FBSztBQUdqQixlQUFLbUUsWUFBWTFDLGFBQWFoQixZQUFZLEVBQUVrQixjQUFjRixZQUFZLENBQUM7QUFBQSxRQUMzRTtBQUNBLFlBQUk7QUFDQSxlQUFLRixRQUFRbEMsS0FBSyxFQUFFQyxNQUFNLE1BQU1DLE1BQVMsRUFBRXFDLFFBQVEwQyxVQUFVO0FBQUEsUUFDakUsUUFBUTtBQUdKQSxxQkFBVztBQUFBLFFBQ2Y7QUFBQSxNQUNKO0FBQ0EsWUFBTXpDLFVBQVVBLE1BQU07QUFBQSxNQUFFO0FBQ3hCLFVBQUk7QUFDQSxjQUFNTixRQUFRTyxNQUFNLEVBQUVDLFlBQVksY0FBYyxHQUFHLEVBQUVDLEtBQUssSUFBSUMsT0FBTyxFQUFFQyxPQUFPLEtBQUtDLFFBQVEsSUFBSSxFQUFFLEdBQUdYLFdBQVdLLE9BQU87QUFBQSxNQUMxSCxRQUFRO0FBQ0osY0FBTU4sUUFBUU8sTUFBTSxFQUFFQyxZQUFZLE9BQU8sR0FBRyxFQUFFQyxLQUFLLElBQUlDLE9BQU8sRUFBRUMsT0FBTyxLQUFLQyxRQUFRLElBQUksRUFBRSxHQUFHWCxXQUFXSyxPQUFPO0FBQUEsTUFDbkg7QUFBQSxJQUNKLFNBQVM5QyxLQUFLO0FBQ1ZpQixrQkFBWSxLQUFLO0FBQ2pCSSxlQUFTdEIsbUJBQW1CQyxHQUFHLENBQUM7QUFBQSxJQUNwQztBQUFBLEVBQ0o7QUFFQSxRQUFNcUQsV0FBV0EsTUFBTTtBQUNuQmxELG9CQUFnQm9CLFVBQVU7QUFDMUJOLGdCQUFZLEtBQUs7QUFBQSxFQUNyQjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxPQUFPLEVBQUVxQyxTQUFTLFFBQVFDLEtBQUssSUFBSUMsV0FBVyxTQUFTLEdBQ3hEO0FBQUEsMkJBQUMsU0FDRztBQUFBLDZCQUFDLFFBQUcsT0FBTyxFQUFFQyxRQUFRLFdBQVdDLE9BQU8sUUFBUUMsVUFBVSxVQUFVLEdBQUcsa0NBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Y7QUFBQSxNQUN4Rix1QkFBQyxPQUFFLE9BQU8sRUFBRUYsUUFBUSxHQUFHQyxPQUFPLFdBQVdDLFVBQVUsU0FBUyxHQUN2RGxDLHNCQUNLLGNBQWNmLFlBQVliLGtCQUFrQixZQUFZLGtCQUFrQiw4Q0FDMUUsb0ZBSFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUtBLHVCQUFDLFNBQUksSUFBSWlGLHlCQUF5QixPQUFPLEVBQUUzQixPQUFPLFFBQVFTLGNBQWMsR0FBR0MsVUFBVSxVQUFVUCxTQUFTdEMsV0FBVyxVQUFVLE9BQU8sS0FBcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzSTtBQUFBLElBQ3JJQSxXQUNHLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVNxQyxVQUFVLFdBQVUsYUFBWSxnQ0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRSxJQUUvRSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDbEM7QUFBQSxPQUFDOUIsYUFBYWYsWUFBWWYsd0JBQ3ZCLG1DQUNJO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLE9BQU91RjtBQUFBQSxZQUNQLFVBQVUsQ0FBQ3BCLE1BQU1xQixjQUFjckIsRUFBRUMsT0FBT0UsS0FBSztBQUFBLFlBQzdDLGFBQVk7QUFBQSxZQUNaO0FBQUEsWUFDQSxPQUFPLEVBQUVkLE9BQU8sUUFBUWdCLFNBQVMsYUFBYVAsY0FBYyxHQUFHUSxRQUFRLHFCQUFxQkMsaUJBQWlCLFdBQVdYLE9BQU8sUUFBUUMsVUFBVSxRQUFRNkIsU0FBUyxRQUFRQyxXQUFXLGFBQWE7QUFBQTtBQUFBLFVBTnRNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU13TTtBQUFBLFFBRXhNO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxLQUFLbkU7QUFBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxRQUFPO0FBQUEsWUFDUCxTQUFRO0FBQUEsWUFDUixPQUFPLEVBQUVnQyxTQUFTLE9BQU87QUFBQSxZQUN6QixVQUFVLENBQUNRLE1BQU07QUFDYixvQkFBTS9CLE9BQU8rQixFQUFFQyxPQUFPQyxRQUFRLENBQUM7QUFDL0Isa0JBQUlqQyxLQUFNRCxxQkFBb0JDLElBQUk7QUFDbEMrQixnQkFBRUMsT0FBT0UsUUFBUTtBQUFBLFlBQ3JCO0FBQUE7QUFBQSxVQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVNO0FBQUEsUUFFTjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsVUFBVS9DLGNBQWMsQ0FBQ2dFLFdBQVdJLEtBQUs7QUFBQSxZQUN6QyxTQUFTLE1BQU1oRSxhQUFhakIsU0FBUzZELE1BQU07QUFBQSxZQUMzQyxPQUFPLEVBQUVDLFNBQVMsSUFBSVAsY0FBYyxHQUFHUSxRQUFRLHFCQUFxQkMsaUJBQWlCLFdBQVdYLE9BQU8sV0FBV1ksWUFBWSxRQUFRQyxRQUFRckQsY0FBYyxDQUFDZ0UsV0FBV0ksS0FBSyxJQUFJLGdCQUFnQixVQUFVO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFKak47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxXQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkJBO0FBQUEsTUFFSDdELGFBQ0c7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFVBQVVQO0FBQUFBLFVBQ1YsU0FBUyxNQUFNLEtBQUtxQixVQUFVO0FBQUEsVUFDOUIsT0FBTyxFQUFFNEIsU0FBUyxJQUFJUCxjQUFjLEdBQUdRLFFBQVEscUJBQXFCQyxpQkFBaUIsV0FBV1gsT0FBTyxXQUFXWSxZQUFZLFFBQVFDLFFBQVFyRCxhQUFhLGdCQUFnQixVQUFVO0FBQUEsVUFFcExSLHNCQUFZYixrQkFBa0Isa0NBQWtDO0FBQUE7QUFBQSxRQU5yRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLE1BRUosdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBU2lCLFVBQVUsVUFBVUksWUFBWSxXQUFVLGFBQVksd0JBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBN0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4Q0E7QUFBQSxJQUdIQSxjQUFjLHVCQUFDLE9BQUUsT0FBTyxFQUFFd0MsT0FBTyxXQUFXQyxVQUFVLFNBQVMsR0FBRywyQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRDtBQUFBLElBQzdFdkMsU0FBUyx1QkFBQyxPQUFFLE9BQU8sRUFBRXNDLE9BQU8sV0FBV0MsVUFBVSxTQUFTLEdBQUl2QyxtQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRDtBQUFBLE9BbkV6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0VBO0FBRVI7QUFBQzZELElBeEtlRix1QkFBcUI7QUFBQSxNQUFyQkE7QUFBcUIsSUFBQVcsSUFBQWYsS0FBQUUsS0FBQWM7QUFBQSxhQUFBRCxJQUFBO0FBQUEsYUFBQWYsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBYyxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJIdG1sNVFyY29kZSIsInZhbGlkYXRlQ29tYW5kYVJlYWRpbmciLCJ2YWxpZGF0ZVRhYmxlUmVhZGluZyIsIm5lZWRzUmVhZGluZ1ZhbGlkYXRpb24iLCJyIiwiaXNDYW1lcmFJbnB1dEVuYWJsZWQiLCJpc0JhcmNvZGVFbmFibGVkIiwiaXNRckNvZGVFbmFibGVkIiwiU0NBTk5FUl9FTEVNRU5UX0lEIiwiY2FtZXJhRXJyb3JNZXNzYWdlIiwiZXJyIiwibmFtZSIsIkVycm9yIiwic2FmZVN0b3BTY2FubmVyIiwicmVmIiwiY3VycmVudCIsInN0b3AiLCJjYXRjaCIsInVuZGVmaW5lZCIsIlJlYWRpbmdWYWxpZGF0aW9uR2F0ZSIsInJlcXVpcmVtZW50Iiwic3VidGl0bGUiLCJzdWJtaXQiLCJvblZhbGlkYXRlZCIsIm9uQ2FuY2VsIiwiX3MiLCJzY2FubmluZyIsInNldFNjYW5uaW5nIiwic3VibWl0dGluZyIsInNldFN1Ym1pdHRpbmciLCJlcnJvciIsInNldEVycm9yIiwiZmlsZUlucHV0UmVmIiwic2Nhbm5lclJlZiIsImhhc0RlY29kZWRSZWYiLCJ3YW50c1NjYW4iLCJzY2FuTWV0aG9kIiwiZG9TdWJtaXQiLCJtZXRob2QiLCJwYXlsb2FkIiwiaGFuZGxlUGhvdG9TZWxlY3RlZCIsImZpbGUiLCJyZWFkZXIiLCJGaWxlUmVhZGVyIiwib25sb2FkIiwiZGF0YVVybCIsInJlc3VsdCIsInBob3RvQmFzZTY0IiwicmVhZEFzRGF0YVVSTCIsInN0YXJ0U2NhbiIsInNjYW5uZXIiLCJvbkRlY29kZWQiLCJkZWNvZGVkVGV4dCIsImZpbmlzaFN1Ym1pdCIsInNjYW5uZWRWYWx1ZSIsImZpbmFsbHkiLCJvbkZyYW1lIiwic3RhcnQiLCJmYWNpbmdNb2RlIiwiZnBzIiwicXJib3giLCJ3aWR0aCIsImhlaWdodCIsInN0b3BTY2FuIiwiZGlzcGxheSIsImdhcCIsInRleHRBbGlnbiIsIm1hcmdpbiIsImNvbG9yIiwiZm9udFNpemUiLCJib3JkZXJSYWRpdXMiLCJvdmVyZmxvdyIsImUiLCJ0YXJnZXQiLCJmaWxlcyIsInZhbHVlIiwiY2xpY2siLCJwYWRkaW5nIiwiYm9yZGVyIiwiYmFja2dyb3VuZENvbG9yIiwiZm9udFdlaWdodCIsImN1cnNvciIsIkNvbWFuZGFSZWFkaW5nVmFsaWRhdGlvbiIsInRva2VuIiwiY29tYW5kYUNvZGUiLCJfYzIiLCJUYWJsZVJlYWRpbmdWYWxpZGF0aW9uIiwiX2MzIiwiTElOS19TQ0FOTkVSX0VMRU1FTlRfSUQiLCJMaW5rQ29tYW5kYVZhbGlkYXRpb24iLCJvbkxpbmtlZCIsIl9zMiIsIm1hbnVhbENvZGUiLCJzZXRNYW51YWxDb2RlIiwibGlua0NvbWFuZGEiLCJjb2RlIiwidHJpbSIsImZpbmlzaExpbmsiLCJvdXRsaW5lIiwiYm94U2l6aW5nIiwiX2MiLCJfYzQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29tYW5kYVJlYWRpbmdWYWxpZGF0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgSHRtbDVRcmNvZGUgfSBmcm9tIFwiaHRtbDUtcXJjb2RlXCI7XHJcbmltcG9ydCB7IHZhbGlkYXRlQ29tYW5kYVJlYWRpbmcsIHZhbGlkYXRlVGFibGVSZWFkaW5nIH0gZnJvbSBcIi4vYXBpXCI7XHJcblxyXG5leHBvcnQgdHlwZSBSZWFkaW5nVmFsaWRhdGlvblJlcXVpcmVtZW50ID0ge1xyXG4gICAgaXNDYW1lcmFJbnB1dEVuYWJsZWQ6IGJvb2xlYW47XHJcbiAgICBpc0JhcmNvZGVFbmFibGVkOiBib29sZWFuO1xyXG4gICAgaXNRckNvZGVFbmFibGVkOiBib29sZWFuO1xyXG59O1xyXG5cclxuLyoqIEJhc3RhIFVNIGRvcyBjZW7DoXJpb3MgbGlnYWRvcyBzZXIgY29uY2x1w61kbyDigJQgbsOjbyDDqSBwcmVjaXNvIGNvbXBsZXRhciB0b2Rvcy4gKi9cclxuZXhwb3J0IGNvbnN0IG5lZWRzUmVhZGluZ1ZhbGlkYXRpb24gPSAocjogUmVhZGluZ1ZhbGlkYXRpb25SZXF1aXJlbWVudCk6IGJvb2xlYW4gPT5cclxuICAgIHIuaXNDYW1lcmFJbnB1dEVuYWJsZWQgfHwgci5pc0JhcmNvZGVFbmFibGVkIHx8IHIuaXNRckNvZGVFbmFibGVkO1xyXG5cclxudHlwZSBTdWJtaXRQYXlsb2FkID0geyBzY2FubmVkVmFsdWU/OiBzdHJpbmc7IHBob3RvQmFzZTY0Pzogc3RyaW5nIH07XHJcbnR5cGUgU3VibWl0Rm4gPSAobWV0aG9kOiBcImNhbWVyYVwiIHwgXCJiYXJjb2RlXCIgfCBcInFyY29kZVwiLCBwYXlsb2FkOiBTdWJtaXRQYXlsb2FkKSA9PiBQcm9taXNlPHZvaWQ+O1xyXG5cclxudHlwZSBHYXRlUHJvcHMgPSB7XHJcbiAgICByZXF1aXJlbWVudDogUmVhZGluZ1ZhbGlkYXRpb25SZXF1aXJlbWVudDtcclxuICAgIHN1YnRpdGxlOiBzdHJpbmc7XHJcbiAgICBzdWJtaXQ6IFN1Ym1pdEZuO1xyXG4gICAgb25WYWxpZGF0ZWQ6ICgpID0+IHZvaWQ7XHJcbiAgICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcclxufTtcclxuXHJcbmNvbnN0IFNDQU5ORVJfRUxFTUVOVF9JRCA9IFwicmVhZGluZy12YWxpZGF0aW9uLXNjYW5uZXJcIjtcclxuXHJcbmNvbnN0IGNhbWVyYUVycm9yTWVzc2FnZSA9IChlcnI6IHVua25vd24pOiBzdHJpbmcgPT4ge1xyXG4gICAgY29uc3QgbmFtZSA9IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm5hbWUgOiBcIlwiO1xyXG4gICAgc3dpdGNoIChuYW1lKSB7XHJcbiAgICAgICAgY2FzZSBcIk5vdEFsbG93ZWRFcnJvclwiOlxyXG4gICAgICAgICAgICByZXR1cm4gXCJPIG5hdmVnYWRvciBibG9xdWVvdSBvIGFjZXNzbyDDoCBjw6JtZXJhLiBMaWJlcmUgYSBwZXJtaXNzw6NvIGRlIGPDom1lcmEgcGFyYSBlc3RlIHNpdGUgbmFzIGNvbmZpZ3VyYcOnw7VlcyBkbyBuYXZlZ2Fkb3IgZSB0ZW50ZSBkZSBub3ZvLlwiO1xyXG4gICAgICAgIGNhc2UgXCJOb3RGb3VuZEVycm9yXCI6XHJcbiAgICAgICAgY2FzZSBcIk92ZXJjb25zdHJhaW5lZEVycm9yXCI6XHJcbiAgICAgICAgICAgIHJldHVybiBcIk5lbmh1bWEgY8OibWVyYSBmb2kgZW5jb250cmFkYSBuZXN0ZSBkaXNwb3NpdGl2by5cIjtcclxuICAgICAgICBjYXNlIFwiTm90UmVhZGFibGVFcnJvclwiOlxyXG4gICAgICAgICAgICByZXR1cm4gXCJBIGPDom1lcmEgasOhIGVzdMOhIHNlbmRvIHVzYWRhIHBvciBvdXRybyBhcGxpY2F0aXZvIG91IGFiYS4gRmVjaGUtbyBlIHRlbnRlIGRlIG5vdm8uXCI7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuIFwiTsOjbyBmb2kgcG9zc8OtdmVsIGFjZXNzYXIgYSBjw6JtZXJhLiBWZXJpZmlxdWUgYSBwZXJtaXNzw6NvIGRvIG5hdmVnYWRvci5cIjtcclxuICAgIH1cclxufTtcclxuXHJcbi8qKlxyXG4gKiBgSHRtbDVRcmNvZGUuc3RvcCgpYCBsYW7Dp2EgZGUgZm9ybWEgU8ONTkNST05BIChuw6NvIHJldG9ybmEgdW1hIFByb21pc2UgcmVqZWl0YWRhIOKAlCBvXHJcbiAqIHRocm93IGFjb250ZWNlIGFudGVzIGRlIHF1YWxxdWVyIFByb21pc2UgZXhpc3RpcikgcXVhbmRvIGNoYW1hZG8gbnVtIHNjYW5uZXIgcXVlIGrDoVxyXG4gKiBuw6NvIGVzdMOhIHJvZGFuZG8gKFwiQ2Fubm90IHN0b3AsIHNjYW5uZXIgaXMgbm90IHJ1bm5pbmcgb3IgcGF1c2VkLlwiKS4gSXNzbyBhY29udGVjaWFcclxuICogZGVudHJvIGRvIGNsZWFudXAgZG8gdXNlRWZmZWN0IGRlIGRlc21vbnRhZ2VtOiBkZXBvaXMgcXVlIGBvbkRlY29kZWRgIGrDoSBjaGFtYXZhXHJcbiAqIGBzY2FubmVyLnN0b3AoKWAgY29tIHN1Y2Vzc28gKGZsdXhvIG5vcm1hbCBkZSBsZWl0dXJhKSwgbyBjb21wb25lbnRlIGRlc21vbnRhdmEgbG9nb1xyXG4gKiBlbSBzZWd1aWRhIChleC46IGBMaW5rQ29tYW5kYVZhbGlkYXRpb25gIHNvbWUgZGEgw6Fydm9yZSBhc3NpbSBxdWUgbyBgb25MaW5rZWRgIGRvIHBhaVxyXG4gKiBtdWRhIGRlIHRlbGEpIGUgbyBjbGVhbnVwIGNoYW1hdmEgYHN0b3AoKWAgREUgTk9WTyBubyBtZXNtbyBzY2FubmVyIGrDoSBwYXJhZG8g4oCUIHVtXHJcbiAqIGAuY2F0Y2goKWAgZW5jYWRlYWRvIG7Do28gcHJvdGVnZSBjb250cmEgdW0gdGhyb3cgc8OtbmNyb25vLCBlbnTDo28gZXNzYSBzZWd1bmRhIGNoYW1hZGFcclxuICogZXNjYXBhdmEgZGlyZXRvIHBybyBSZWFjdCBkdXJhbnRlIGEgZmFzZSBkZSBjb21taXQgKGVmZWl0byBkZSBkZXNtb250YWdlbSksIG8gcXVlIG9cclxuICogRXJyb3IgQm91bmRhcnkgdHJhdGEgY29tbyB1bSBjcmFzaCByZWFsIGUgZGVycnViYSBhIHRlbGEgKFwiQWxnbyBkZXUgZXJyYWRvXCIpLCBtZXNtb1xyXG4gKiBjb20gbyBwZWRpZG8gasOhIHRlbmRvIHNpZG8gY29uY2x1w61kbyBjb20gc3VjZXNzby4gRW52b2x2ZSB0b2RhIGNoYW1hZGEgYSBgc3RvcCgpYFxyXG4gKiAoY2xlYW51cCwgYm90w6NvIFwiQ2FuY2VsYXIgbGVpdHVyYVwiIGUgbyBwcsOzcHJpbyBgb25EZWNvZGVkYCkgcGFyYSBudW5jYSBkZWl4YXIgZXNzZVxyXG4gKiB0aHJvdyBzw61uY3Jvbm8gZXNjYXBhci5cclxuICovXHJcbmNvbnN0IHNhZmVTdG9wU2Nhbm5lciA9IChyZWY6IHsgY3VycmVudDogSHRtbDVRcmNvZGUgfCBudWxsIH0pID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgcmVmLmN1cnJlbnQ/LnN0b3AoKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgICAgLy8gU2Nhbm5lciBqw6EgcGFyYWRvL3BhcmFuZG8g4oCUIG5hZGEgYSBmYXplci5cclxuICAgIH1cclxufTtcclxuXHJcbi8qKlxyXG4gKiBUcmF2YSBkZSBzZWd1cmFuw6dhIGNvbXVtIMOgcyB2YWxpZGHDp8O1ZXMgZGUgbGVpdHVyYSAoY29tYW5kYSBlIG1lc2EpOiBleGlnZSBxdWUgb1xyXG4gKiBjbGllbnRlIGNvbXBsZXRlIHBlbG8gbWVub3MgdW0gZG9zIGNlbsOhcmlvcyBsaWdhZG9zIG5hIGZpbGlhbCAoY8OibWVyYSwgY8OzZGlnbyBkZVxyXG4gKiBiYXJyYXMgb3UgUVIgQ29kZSkuIFwiQ8OibWVyYVwiID0gdGlyYSB1bWEgZm90byBkZSBjb21wcm92YcOnw6NvIChzZW0gT0NSLCDDqSBzw7MgcmVnaXN0cm8pLlxyXG4gKiBcIkPDs2RpZ28gZGUgYmFycmFzXCIgZSBcIlFSIENvZGVcIiA9IGVzY2FuZWlhIGNvbSBhIGPDom1lcmEgZG8gY2VsdWxhciAobWVzbW8gc2Nhbm5lcixcclxuICogZm9ybWF0b3MgZGlmZXJlbnRlcykuIE7Do28gw6kgZXhwb3J0YWRvIGRpcmV0YW1lbnRlIOKAlCB1c2UgYENvbWFuZGFSZWFkaW5nVmFsaWRhdGlvbmBcclxuICogb3UgYFRhYmxlUmVhZGluZ1ZhbGlkYXRpb25gIGFiYWl4bywgcXVlIHPDsyBkaWZlcmVtIGVtIHByYSBvbmRlIGEgY29tcHJvdmHDp8OjbyB2YWkuXHJcbiAqL1xyXG5mdW5jdGlvbiBSZWFkaW5nVmFsaWRhdGlvbkdhdGUoeyByZXF1aXJlbWVudCwgc3VidGl0bGUsIHN1Ym1pdCwgb25WYWxpZGF0ZWQsIG9uQ2FuY2VsIH06IEdhdGVQcm9wcykge1xyXG4gICAgY29uc3QgW3NjYW5uaW5nLCBzZXRTY2FubmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbc3VibWl0dGluZywgc2V0U3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xyXG4gICAgY29uc3Qgc2Nhbm5lclJlZiA9IHVzZVJlZjxIdG1sNVFyY29kZSB8IG51bGw+KG51bGwpO1xyXG4gICAgLy8gTyBzY2FubmVyIGNoYW1hIG8gY2FsbGJhY2sgZGUgc3VjZXNzbyBkZSBub3ZvIGEgY2FkYSBmcmFtZSBlbSBxdWUgbyBjw7NkaWdvIGFpbmRhXHJcbiAgICAvLyBlc3RpdmVyIHZpc8OtdmVsLCBtZXNtbyBkZXBvaXMgZG8gcHJpbWVpcm8gYWNlcnRvIOKAlCBzdG9wKCkgw6kgYXNzw61uY3Jvbm8sIGVudMOjbyBvXHJcbiAgICAvLyBjw7NkaWdvIGbDrXNpY28gY29udGludWEgXCJzZW5kbyBsaWRvXCIgcG9yIGFsZ3VucyBmcmFtZXMgZW5xdWFudG8gYSBjw6JtZXJhIGZlY2hhLlxyXG4gICAgLy8gU2VtIGVzc2EgdHJhdmEsIHVtIMO6bmljbyBlc2NhbmVhbWVudG8gcG9kaWEgZGlzcGFyYXIgZG9TdWJtaXQgKGUgbyBwZWRpZG8pIG1haXNcclxuICAgIC8vIGRlIHVtYSB2ZXouXHJcbiAgICBjb25zdCBoYXNEZWNvZGVkUmVmID0gdXNlUmVmKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCB3YW50c1NjYW4gPSByZXF1aXJlbWVudC5pc0JhcmNvZGVFbmFibGVkIHx8IHJlcXVpcmVtZW50LmlzUXJDb2RlRW5hYmxlZDtcclxuICAgIC8vIFNlIG9zIGRvaXMgZXN0aXZlcmVtIGxpZ2Fkb3MsIHVtIMO6bmljbyBlc2NhbmVhbWVudG8gc2F0aXNmYXogcXVhbHF1ZXIgdW0gZG9zIGRvaXMg4oCUXHJcbiAgICAvLyBvIG3DqXRvZG8gZW52aWFkbyBhbyBiYWNrZW5kIMOpIHPDsyB1bSByw7N0dWxvIGRlIGF1ZGl0b3JpYSwgbsOjbyBtdWRhIGEgdmFsaWRhw6fDo28gZW0gc2kuXHJcbiAgICBjb25zdCBzY2FuTWV0aG9kID0gcmVxdWlyZW1lbnQuaXNRckNvZGVFbmFibGVkID8gXCJxcmNvZGVcIiA6IFwiYmFyY29kZVwiO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICAgICAgc2FmZVN0b3BTY2FubmVyKHNjYW5uZXJSZWYpO1xyXG4gICAgICAgIH07XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgY29uc3QgZG9TdWJtaXQgPSBhc3luYyAobWV0aG9kOiBcImNhbWVyYVwiIHwgXCJiYXJjb2RlXCIgfCBcInFyY29kZVwiLCBwYXlsb2FkOiBTdWJtaXRQYXlsb2FkKSA9PiB7XHJcbiAgICAgICAgc2V0U3VibWl0dGluZyh0cnVlKTtcclxuICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBhd2FpdCBzdWJtaXQobWV0aG9kLCBwYXlsb2FkKTtcclxuICAgICAgICAgICAgb25WYWxpZGF0ZWQoKTtcclxuICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgICAgc2V0RXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgY29uZmlybWFyIGEgdmFsaWRhw6fDo28uIFRlbnRlIG5vdmFtZW50ZS5cIik7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0U3VibWl0dGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVQaG90b1NlbGVjdGVkID0gKGZpbGU6IEZpbGUpID0+IHtcclxuICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgICAgIHJlYWRlci5vbmxvYWQgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGRhdGFVcmwgPSB0eXBlb2YgcmVhZGVyLnJlc3VsdCA9PT0gXCJzdHJpbmdcIiA/IHJlYWRlci5yZXN1bHQgOiBcIlwiO1xyXG4gICAgICAgICAgICBpZiAoZGF0YVVybCkgdm9pZCBkb1N1Ym1pdChcImNhbWVyYVwiLCB7IHBob3RvQmFzZTY0OiBkYXRhVXJsIH0pO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHN0YXJ0U2NhbiA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICBzZXRTY2FubmluZyh0cnVlKTtcclxuICAgICAgICBoYXNEZWNvZGVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAvLyBgbmV3IEh0bWw1UXJjb2RlKGlkKWAgZmF6IGBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZClgIGUgbGFuw6dhIHNlIG7Do28gYWNoYXJcclxuICAgICAgICAgICAgLy8g4oCUIHBvciBpc3NvIHRhbWLDqW0gZmljYSBkZW50cm8gZG8gdHJ5L2NhdGNoIGFnb3JhOiBtZXNtbyBxdWUgbyBjb250YWluZXIgbsOjb1xyXG4gICAgICAgICAgICAvLyBlc3RlamEgbW9udGFkbyBwb3IgYWxndW0gbW90aXZvIGluZXNwZXJhZG8sIG8gZXJybyBhcGFyZWNlIHBybyB1c3XDoXJpbyBlbSB2ZXpcclxuICAgICAgICAgICAgLy8gZGUgc3VtaXIgc2lsZW5jaW9zYW1lbnRlIChlcmEgbyBxdWUgYWNvbnRlY2lhIGFudGVzIGRlc3NhIGNvcnJlw6fDo28pLlxyXG4gICAgICAgICAgICBjb25zdCBzY2FubmVyID0gbmV3IEh0bWw1UXJjb2RlKFNDQU5ORVJfRUxFTUVOVF9JRCk7XHJcbiAgICAgICAgICAgIHNjYW5uZXJSZWYuY3VycmVudCA9IHNjYW5uZXI7XHJcbiAgICAgICAgICAgIGNvbnN0IG9uRGVjb2RlZCA9IChkZWNvZGVkVGV4dDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyBJZ25vcmEgZnJhbWVzIHJlcGV0aWRvcyBkbyBtZXNtbyBjw7NkaWdvIOKAlCBzw7MgcHJvY2Vzc2EgbyBwcmltZWlybyBhY2VydG9cclxuICAgICAgICAgICAgICAgIC8vICh2ZXIgY29tZW50w6FyaW8gZGUgYGhhc0RlY29kZWRSZWZgIGFjaW1hKS5cclxuICAgICAgICAgICAgICAgIGlmIChoYXNEZWNvZGVkUmVmLmN1cnJlbnQpIHJldHVybjtcclxuICAgICAgICAgICAgICAgIGhhc0RlY29kZWRSZWYuY3VycmVudCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBmaW5pc2hTdWJtaXQgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2Nhbm5pbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZvaWQgZG9TdWJtaXQoc2Nhbk1ldGhvZCwgeyBzY2FubmVkVmFsdWU6IGRlY29kZWRUZXh0IH0pO1xyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdm9pZCBzY2FubmVyLnN0b3AoKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpLmZpbmFsbHkoZmluaXNoU3VibWl0KTtcclxuICAgICAgICAgICAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHN0b3AoKSBwb2RlIGxhbsOnYXIgZGUgZm9ybWEgc8OtbmNyb25hIHNlIG8gc2Nhbm5lciBqw6EgZXN0aXZlclxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHBhcmFuZG8gKGV4Ljogb3V0cmEgY2hhbWFkYSBjb25jb3JyZW50ZSkg4oCUIHNlZ3VlIG1lc21vIGFzc2ltIGNvbVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIG8gdmFsb3IgasOhIGxpZG8sIGVtIHZleiBkZSBkZWl4YXIgYSBQcm9taXNlIHJlamVpdGFyIHNlbSB0cmF0YW1lbnRvLlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbmlzaFN1Ym1pdCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjb25zdCBvbkZyYW1lID0gKCkgPT4geyAvKiBmcmFtZSBzZW0gbGVpdHVyYSDigJQgaWdub3JhIGUgY29udGludWEgdGVudGFuZG8gKi8gfTtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIC8vIFByaW9yaXphIGEgY8OibWVyYSB0cmFzZWlyYSAoY2VsdWxhcikg4oCUIMOpIGEgcXVlIGZheiBzZW50aWRvIHByYSBlc2NhbmVhciB1bVxyXG4gICAgICAgICAgICAgICAgLy8gY8OzZGlnbyBmw61zaWNvLiBFbSBkZXNrdG9wcy9ub3RlYm9va3Mgc8OzIGV4aXN0ZSB1bWEgY8OibWVyYSAoZnJvbnRhbCkgZSBvXHJcbiAgICAgICAgICAgICAgICAvLyBuYXZlZ2Fkb3IgcG9kZSByZWplaXRhciBlc3NhIHJlc3RyacOnw6NvIGNvbSBPdmVyY29uc3RyYWluZWRFcnJvci5cclxuICAgICAgICAgICAgICAgIGF3YWl0IHNjYW5uZXIuc3RhcnQoeyBmYWNpbmdNb2RlOiBcImVudmlyb25tZW50XCIgfSwgeyBmcHM6IDEwLCBxcmJveDogeyB3aWR0aDogMjQwLCBoZWlnaHQ6IDI0MCB9IH0sIG9uRGVjb2RlZCwgb25GcmFtZSk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgc2Nhbm5lci5zdGFydCh7IGZhY2luZ01vZGU6IFwidXNlclwiIH0sIHsgZnBzOiAxMCwgcXJib3g6IHsgd2lkdGg6IDI0MCwgaGVpZ2h0OiAyNDAgfSB9LCBvbkRlY29kZWQsIG9uRnJhbWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIHNldFNjYW5uaW5nKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0RXJyb3IoY2FtZXJhRXJyb3JNZXNzYWdlKGVycikpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3Qgc3RvcFNjYW4gPSAoKSA9PiB7XHJcbiAgICAgICAgc2FmZVN0b3BTY2FubmVyKHNjYW5uZXJSZWYpO1xyXG4gICAgICAgIHNldFNjYW5uaW5nKGZhbHNlKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE2LCB0ZXh0QWxpZ246IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgc3R5bGU9e3sgbWFyZ2luOiBcIjAgMCA2cHhcIiwgY29sb3I6IFwiI2ZmZlwiLCBmb250U2l6ZTogXCIxLjE1cmVtXCIgfX0+Q29uZmlybWUgcGFyYSBjb250aW51YXI8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luOiAwLCBjb2xvcjogXCIjYThhOGIzXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PntzdWJ0aXRsZX08L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qXHJcbiAgICAgICAgICAgICAgTyBjb250YWluZXIgZG8gc2Nhbm5lciBwcmVjaXNhIGV4aXN0aXIgbm8gRE9NIEFOVEVTIGRlIGBuZXcgSHRtbDVRcmNvZGUoaWQpYFxyXG4gICAgICAgICAgICAgIHJvZGFyIOKAlCBhIGJpYmxpb3RlY2EgZmF6IGBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZClgIG5vIGNvbnN0cnV0b3IgZSBsYW7Dp2FcclxuICAgICAgICAgICAgICB1bWEgZXhjZcOnw6NvIHPDrW5jcm9uYSAoZm9yYSBkbyB0cnkvY2F0Y2ggZGUgc3RhcnRTY2FuKSBzZSBuw6NvIGVuY29udHJhci4gQ29tb1xyXG4gICAgICAgICAgICAgIGBzZXRTY2FubmluZyh0cnVlKWAgZSBhIGNyaWHDp8OjbyBkbyBzY2FubmVyIGFjb250ZWNlbSBubyBtZXNtbyBjaWNsbyBzw61uY3Jvbm8sXHJcbiAgICAgICAgICAgICAgbyBSZWFjdCBhaW5kYSBuw6NvIGNvbW1pdG91IG8gbm92byBET00gbmVzc2UgaW5zdGFudGUgc2UgbyBgPGRpdj5gIHPDsyBleGlzdGlzc2VcclxuICAgICAgICAgICAgICBjb25kaWNpb25hbG1lbnRlIOKAlCBwb3IgaXNzbyBlbGUgZmljYSBzZW1wcmUgbW9udGFkbywgc8OzIGVzY29uZGlkbyB2aWEgQ1NTXHJcbiAgICAgICAgICAgICAgcXVhbmRvIG7Do28gZXN0w6EgZXNjYW5lYW5kbyAoZW0gdmV6IGRlIGVzY29uZGlkbyBkbyBET00gaW50ZWlybykuXHJcbiAgICAgICAgICAgICovfVxyXG4gICAgICAgICAgICA8ZGl2IGlkPXtTQ0FOTkVSX0VMRU1FTlRfSUR9IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgYm9yZGVyUmFkaXVzOiA4LCBvdmVyZmxvdzogXCJoaWRkZW5cIiwgZGlzcGxheTogc2Nhbm5pbmcgPyBcImJsb2NrXCIgOiBcIm5vbmVcIiB9fSAvPlxyXG4gICAgICAgICAgICB7c2Nhbm5pbmcgPyAoXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtzdG9wU2Nhbn0gY2xhc3NOYW1lPVwiYnRuLWdob3N0XCI+Q2FuY2VsYXIgbGVpdHVyYTwvYnV0dG9uPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7cmVxdWlyZW1lbnQuaXNDYW1lcmFJbnB1dEVuYWJsZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmPXtmaWxlSW5wdXRSZWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhcHR1cmU9XCJ1c2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBkaXNwbGF5OiBcIm5vbmVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpbGUpIGhhbmRsZVBob3RvU2VsZWN0ZWQoZmlsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c3VibWl0dGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiAxNCwgYm9yZGVyUmFkaXVzOiA4LCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiwgYmFja2dyb3VuZENvbG9yOiBcIiNmNTllMGJcIiwgY29sb3I6IFwiIzEyMTIxNFwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgY3Vyc29yOiBzdWJtaXR0aW5nID8gXCJub3QtYWxsb3dlZFwiIDogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5O3IFRpcmFyIHVtYSBmb3RvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7d2FudHNTY2FuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c3VibWl0dGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgc3RhcnRTY2FuKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiAxNCwgYm9yZGVyUmFkaXVzOiA4LCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiwgYmFja2dyb3VuZENvbG9yOiBcIiNmNTllMGJcIiwgY29sb3I6IFwiIzEyMTIxNFwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgY3Vyc29yOiBzdWJtaXR0aW5nID8gXCJub3QtYWxsb3dlZFwiIDogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlcXVpcmVtZW50LmlzUXJDb2RlRW5hYmxlZCA/IFwi4pamIEVzY2FuZWFyIFFSIENvZGVcIiA6IFwi4palIEVzY2FuZWFyIGPDs2RpZ28gZGUgYmFycmFzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25DYW5jZWx9IGRpc2FibGVkPXtzdWJtaXR0aW5nfSBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge3N1Ym1pdHRpbmcgJiYgPHAgc3R5bGU9e3sgY29sb3I6IFwiI2E4YThiM1wiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5Db25maXJtYW5kb+KApjwvcD59XHJcbiAgICAgICAgICAgIHtlcnJvciAmJiA8cCBzdHlsZT17eyBjb2xvcjogXCIjZWY0NDQ0XCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PntlcnJvcn08L3A+fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufVxyXG5cclxudHlwZSBDb21hbmRhUHJvcHMgPSB7XHJcbiAgICB0b2tlbjogc3RyaW5nO1xyXG4gICAgY29tYW5kYUNvZGU6IHN0cmluZztcclxuICAgIHJlcXVpcmVtZW50OiBSZWFkaW5nVmFsaWRhdGlvblJlcXVpcmVtZW50O1xyXG4gICAgb25WYWxpZGF0ZWQ6ICgpID0+IHZvaWQ7XHJcbiAgICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcclxufTtcclxuXHJcbi8qKiBUcmF2YSBhbnRlcyBkZSBjb25zdWx0YXIvbGFuw6dhciBudW1hIENPTUFOREEg4oCUIGNvbXByb3ZhIGEgbGVpdHVyYSBkYXF1ZWxlIGPDs2RpZ28uICovXHJcbmV4cG9ydCBmdW5jdGlvbiBDb21hbmRhUmVhZGluZ1ZhbGlkYXRpb24oeyB0b2tlbiwgY29tYW5kYUNvZGUsIHJlcXVpcmVtZW50LCBvblZhbGlkYXRlZCwgb25DYW5jZWwgfTogQ29tYW5kYVByb3BzKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxSZWFkaW5nVmFsaWRhdGlvbkdhdGVcclxuICAgICAgICAgICAgcmVxdWlyZW1lbnQ9e3JlcXVpcmVtZW50fVxyXG4gICAgICAgICAgICBzdWJ0aXRsZT17YEVzdGEgZmlsaWFsIGV4aWdlIHVtYSBjb25maXJtYcOnw6NvIGV4dHJhIHBhcmEgYWJyaXIgYSBjb21hbmRhICR7Y29tYW5kYUNvZGV9LiBFc2NvbGhhIHVtYSBkYXMgb3DDp8O1ZXMgYWJhaXhvLmB9XHJcbiAgICAgICAgICAgIHN1Ym1pdD17KG1ldGhvZCwgcGF5bG9hZCkgPT4gdmFsaWRhdGVDb21hbmRhUmVhZGluZyh0b2tlbiwgY29tYW5kYUNvZGUsIHsgbWV0aG9kLCAuLi5wYXlsb2FkIH0pfVxyXG4gICAgICAgICAgICBvblZhbGlkYXRlZD17b25WYWxpZGF0ZWR9XHJcbiAgICAgICAgICAgIG9uQ2FuY2VsPXtvbkNhbmNlbH1cclxuICAgICAgICAvPlxyXG4gICAgKTtcclxufVxyXG5cclxudHlwZSBUYWJsZVByb3BzID0ge1xyXG4gICAgdG9rZW46IHN0cmluZztcclxuICAgIHJlcXVpcmVtZW50OiBSZWFkaW5nVmFsaWRhdGlvblJlcXVpcmVtZW50O1xyXG4gICAgb25WYWxpZGF0ZWQ6ICgpID0+IHZvaWQ7XHJcbiAgICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcclxufTtcclxuXHJcbi8qKlxyXG4gKiBUcmF2YSBhbnRlcyBkZSBsaWJlcmFyIHF1YWxxdWVyIHBlZGlkbyBkaXJldG8gbmEgTUVTQSAoc2VtIGNvbWFuZGEg4oCUIHVzYWRhIHF1YW5kb1xyXG4gKiBcIlZpc3VhbGl6YcOnw6NvIGRvIENsaWVudGUgKFFSIENvZGUpXCIgZXN0w6EgZGVzbGlnYWRhKS4gU2VtIGPDs2RpZ28gZGUgY29tYW5kYTogYSBtZXNhIGrDoVxyXG4gKiDDqSBpZGVudGlmaWNhZGEgcGVsbyBwcsOzcHJpbyB0b2tlbiBkbyBRUiBDb2RlLCBlIMOpIGlzc28gcXVlIG8gYmFja2VuZCB1c2EgcGFyYVxyXG4gKiByZWdpc3RyYXIgYSBjb21wcm92YcOnw6NvICh2ZXIgYFZhbGlkYXRlVGFibGVSZWFkaW5nQ29tbWFuZEhhbmRsZXJgLCBxdWUgZ3JhdmEgb1xyXG4gKiBuw7ptZXJvIGRhIG1lc2EgbmEgdHJpbGhhIGRlIGF1ZGl0b3JpYSkuXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gVGFibGVSZWFkaW5nVmFsaWRhdGlvbih7IHRva2VuLCByZXF1aXJlbWVudCwgb25WYWxpZGF0ZWQsIG9uQ2FuY2VsIH06IFRhYmxlUHJvcHMpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFJlYWRpbmdWYWxpZGF0aW9uR2F0ZVxyXG4gICAgICAgICAgICByZXF1aXJlbWVudD17cmVxdWlyZW1lbnR9XHJcbiAgICAgICAgICAgIHN1YnRpdGxlPVwiRXN0YSBmaWxpYWwgZXhpZ2UgdW1hIGNvbmZpcm1hw6fDo28gZXh0cmEgYW50ZXMgZGUgZmF6ZXIgcGVkaWRvcyBuZXN0YSBtZXNhLiBFc2NvbGhhIHVtYSBkYXMgb3DDp8O1ZXMgYWJhaXhvLlwiXHJcbiAgICAgICAgICAgIHN1Ym1pdD17KG1ldGhvZCwgcGF5bG9hZCkgPT4gdmFsaWRhdGVUYWJsZVJlYWRpbmcodG9rZW4sIHsgbWV0aG9kLCAuLi5wYXlsb2FkIH0pfVxyXG4gICAgICAgICAgICBvblZhbGlkYXRlZD17b25WYWxpZGF0ZWR9XHJcbiAgICAgICAgICAgIG9uQ2FuY2VsPXtvbkNhbmNlbH1cclxuICAgICAgICAvPlxyXG4gICAgKTtcclxufVxyXG5cclxudHlwZSBMaW5rQ29tYW5kYVByb3BzID0ge1xyXG4gICAgdG9rZW46IHN0cmluZztcclxuICAgIHJlcXVpcmVtZW50OiBSZWFkaW5nVmFsaWRhdGlvblJlcXVpcmVtZW50O1xyXG4gICAgb25MaW5rZWQ6IChjb21hbmRhQ29kZTogc3RyaW5nKSA9PiB2b2lkO1xyXG4gICAgb25DYW5jZWw6ICgpID0+IHZvaWQ7XHJcbn07XHJcblxyXG5jb25zdCBMSU5LX1NDQU5ORVJfRUxFTUVOVF9JRCA9IFwibGluay1jb21hbmRhLXNjYW5uZXJcIjtcclxuXHJcbi8qKlxyXG4gKiBVc2FkYSBubyBsdWdhciBkbyBzZWxldG9yIG1hbnVhbCBcIk1lc2Egb3UgQ29tYW5kYT9cIiBxdWFuZG8gXCJWaXN1YWxpemHDp8OjbyBkbyBDbGllbnRlXHJcbiAqIChRUiBDb2RlKVwiIGVzdMOhIGRlc2xpZ2FkYSBlIGEgY8OibWVyYSBlc3TDoSBsaWdhZGEgKElzQ2FtZXJhSW5wdXRFbmFibGVkKTogYW8gY2xpY2FyIGVtXHJcbiAqIFwiUGVkaXJcIiwgZW0gdmV6IGRlIHBlcmd1bnRhciBvbmRlIGFub3RhciwgbyBjbGllbnRlIHByZWNpc2EgVklOQ1VMQVIgbyBwZWRpZG8gYSB1bWFcclxuICogY29tYW5kYSBkZSB2ZXJkYWRlIOKAlCBwb3IgUVIgQ29kZSBvdSBjw7NkaWdvIGRlIGJhcnJhcyAobyB2YWxvciBsaWRvIErDgSDDqSBvIG7Dum1lcm8gZGFcclxuICogY29tYW5kYSwgc2VtIGRpZ2l0YcOnw6NvIOKAlCBJc1FyQ29kZUVuYWJsZWQvSXNCYXJjb2RlRW5hYmxlZCkgb3UsIHF1YW5kbyBzw7MgYSBjw6JtZXJhXHJcbiAqIGVzdMOhIGxpZ2FkYSAoc2VtIFFSL0JhcmNvZGUpLCBkaWdpdGFuZG8gbyBuw7ptZXJvIG1hbnVhbG1lbnRlICsgdGlyYW5kbyB1bWEgZm90byBjb21vXHJcbiAqIGNvbXByb3Zhw6fDo28uIEVtIHF1YWxxdWVyIHVtIGRvcyBjYXNvcywgbyBwZWRpZG8gcmVzdWx0YW50ZSB2YWkgcHJhIGNvbnRhIGRhIENPTUFOREFcclxuICogKG51bmNhIGRhIG1lc2EpIOKAlCB2ZXIgQWRkUHVibGljT3JkZXJJdGVtQ29tbWFuZC9GYXNlIDcgbm8gZG9jIGRvIHByb2pldG8uIFVtYSB2ZXpcclxuICogdmluY3VsYWRvIG5lc3RhIHZpc2l0YSwgYFB1YmxpY09yZGVyUGFnZWAgZ3VhcmRhIG8gY8OzZGlnbyBlIHB1bGEgZXN0YSB0ZWxhIG5vc1xyXG4gKiBwZWRpZG9zIHNlZ3VpbnRlcy5cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBMaW5rQ29tYW5kYVZhbGlkYXRpb24oeyB0b2tlbiwgcmVxdWlyZW1lbnQsIG9uTGlua2VkLCBvbkNhbmNlbCB9OiBMaW5rQ29tYW5kYVByb3BzKSB7XHJcbiAgICBjb25zdCB3YW50c1NjYW4gPSByZXF1aXJlbWVudC5pc0JhcmNvZGVFbmFibGVkIHx8IHJlcXVpcmVtZW50LmlzUXJDb2RlRW5hYmxlZDtcclxuICAgIGNvbnN0IHNjYW5NZXRob2QgPSByZXF1aXJlbWVudC5pc1FyQ29kZUVuYWJsZWQgPyBcInFyY29kZVwiIDogXCJiYXJjb2RlXCI7XHJcblxyXG4gICAgY29uc3QgW21hbnVhbENvZGUsIHNldE1hbnVhbENvZGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbc2Nhbm5pbmcsIHNldFNjYW5uaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtzdWJtaXR0aW5nLCBzZXRTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XHJcbiAgICBjb25zdCBzY2FubmVyUmVmID0gdXNlUmVmPEh0bWw1UXJjb2RlIHwgbnVsbD4obnVsbCk7XHJcbiAgICAvLyBNZXNtYSB0cmF2YSBkZSBSZWFkaW5nVmFsaWRhdGlvbkdhdGUuc3RhcnRTY2FuOiBvIHNjYW5uZXIgY2hhbWEgbyBjYWxsYmFjayBkZVxyXG4gICAgLy8gc3VjZXNzbyBkZSBub3ZvIGEgY2FkYSBmcmFtZSBjb20gbyBjw7NkaWdvIGFpbmRhIHZpc8OtdmVsLCBtZXNtbyBkZXBvaXMgZG8gcHJpbWVpcm9cclxuICAgIC8vIGFjZXJ0byAoc3RvcCgpIMOpIGFzc8OtbmNyb25vKSDigJQgc2VtIGlzc28sIHVtIMO6bmljbyBlc2NhbmVhbWVudG8gcG9kaWEgY2hhbWFyXHJcbiAgICAvLyBsaW5rQ29tYW5kYSAoZSBhYnJpci9sYW7Dp2FyIG5vIHBlZGlkbykgbWFpcyBkZSB1bWEgdmV6LlxyXG4gICAgY29uc3QgaGFzRGVjb2RlZFJlZiA9IHVzZVJlZihmYWxzZSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICBzYWZlU3RvcFNjYW5uZXIoc2Nhbm5lclJlZik7XHJcbiAgICAgICAgfTtcclxuICAgIH0sIFtdKTtcclxuXHJcbiAgICBjb25zdCBsaW5rQ29tYW5kYSA9IGFzeW5jIChjb2RlOiBzdHJpbmcsIG1ldGhvZDogXCJjYW1lcmFcIiB8IFwiYmFyY29kZVwiIHwgXCJxcmNvZGVcIiwgcGF5bG9hZDogU3VibWl0UGF5bG9hZCkgPT4ge1xyXG4gICAgICAgIHNldFN1Ym1pdHRpbmcodHJ1ZSk7XHJcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgLy8gUmVhcHJvdmVpdGEgbyBtZXNtbyBlbmRwb2ludCBkZSBhdWRpdG9yaWEgZGEgRmFzZSA0IOKAlCBjb25maXJtYSBxdWUgYVxyXG4gICAgICAgICAgICAvLyBjb21hbmRhIGV4aXN0ZSAoZmFsaGEgY29tIENvbWFuZGEuTm90Rm91bmQgc2UgbyBjw7NkaWdvIGxpZG8vZGlnaXRhZG8gZm9yXHJcbiAgICAgICAgICAgIC8vIGludsOhbGlkbykgZSBncmF2YSBhIHRyaWxoYSwgYW50ZXMgZGUgbGliZXJhciBvIHbDrW5jdWxvLlxyXG4gICAgICAgICAgICBhd2FpdCB2YWxpZGF0ZUNvbWFuZGFSZWFkaW5nKHRva2VuLCBjb2RlLCB7IG1ldGhvZCwgLi4ucGF5bG9hZCB9KTtcclxuICAgICAgICAgICAgb25MaW5rZWQoY29kZSk7XHJcbiAgICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgICAgIHNldEVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHZpbmN1bGFyIGEgY29tYW5kYS4gQ29uZmlyYSBvIG7Dum1lcm8vY8OzZGlnbyBlIHRlbnRlIGRlIG5vdm8uXCIpO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldFN1Ym1pdHRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUGhvdG9TZWxlY3RlZCA9IChmaWxlOiBGaWxlKSA9PiB7XHJcbiAgICAgICAgaWYgKCFtYW51YWxDb2RlLnRyaW0oKSkge1xyXG4gICAgICAgICAgICBzZXRFcnJvcihcIkluZm9ybWUgbyBuw7ptZXJvIGRhIGNvbWFuZGEgYW50ZXMgZGUgdGlyYXIgYSBmb3RvLlwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgICAgIHJlYWRlci5vbmxvYWQgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGRhdGFVcmwgPSB0eXBlb2YgcmVhZGVyLnJlc3VsdCA9PT0gXCJzdHJpbmdcIiA/IHJlYWRlci5yZXN1bHQgOiBcIlwiO1xyXG4gICAgICAgICAgICBpZiAoZGF0YVVybCkgdm9pZCBsaW5rQ29tYW5kYShtYW51YWxDb2RlLnRyaW0oKSwgXCJjYW1lcmFcIiwgeyBwaG90b0Jhc2U2NDogZGF0YVVybCB9KTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBzdGFydFNjYW4gPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgICAgc2V0U2Nhbm5pbmcodHJ1ZSk7XHJcbiAgICAgICAgaGFzRGVjb2RlZFJlZi5jdXJyZW50ID0gZmFsc2U7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgLy8gYG5ldyBIdG1sNVFyY29kZShpZClgIGZheiBgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpYCBlIGxhbsOnYSBzZSBuw6NvIGFjaGFyIOKAlFxyXG4gICAgICAgICAgICAvLyBwb3IgaXNzbyBmaWNhIGRlbnRybyBkbyB0cnkvY2F0Y2ggKHZlciBjb21lbnTDoXJpbyBlcXVpdmFsZW50ZSBlbVxyXG4gICAgICAgICAgICAvLyBSZWFkaW5nVmFsaWRhdGlvbkdhdGUuc3RhcnRTY2FuKS5cclxuICAgICAgICAgICAgY29uc3Qgc2Nhbm5lciA9IG5ldyBIdG1sNVFyY29kZShMSU5LX1NDQU5ORVJfRUxFTUVOVF9JRCk7XHJcbiAgICAgICAgICAgIHNjYW5uZXJSZWYuY3VycmVudCA9IHNjYW5uZXI7XHJcbiAgICAgICAgICAgIGNvbnN0IG9uRGVjb2RlZCA9IChkZWNvZGVkVGV4dDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyBJZ25vcmEgZnJhbWVzIHJlcGV0aWRvcyBkbyBtZXNtbyBjw7NkaWdvIOKAlCBzw7MgcHJvY2Vzc2EgbyBwcmltZWlybyBhY2VydG9cclxuICAgICAgICAgICAgICAgIC8vICh2ZXIgY29tZW50w6FyaW8gZGUgYGhhc0RlY29kZWRSZWZgIGFjaW1hKS5cclxuICAgICAgICAgICAgICAgIGlmIChoYXNEZWNvZGVkUmVmLmN1cnJlbnQpIHJldHVybjtcclxuICAgICAgICAgICAgICAgIGhhc0RlY29kZWRSZWYuY3VycmVudCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBmaW5pc2hMaW5rID0gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNjYW5uaW5nKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBPIHZhbG9yIGRlY29kaWZpY2FkbyBkbyBRUi9jw7NkaWdvIGRlIGJhcnJhcyBkYSBjb21hbmRhIGbDrXNpY2Egw4kgb1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIG7Dum1lcm8gZGEgY29tYW5kYSDigJQgc2VtIGRpZ2l0YcOnw6NvLCB2ZXIgZGVzY3Jpw6fDo28gZG8gY29tcG9uZW50ZSBhY2ltYS5cclxuICAgICAgICAgICAgICAgICAgICB2b2lkIGxpbmtDb21hbmRhKGRlY29kZWRUZXh0LCBzY2FuTWV0aG9kLCB7IHNjYW5uZWRWYWx1ZTogZGVjb2RlZFRleHQgfSk7XHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICB2b2lkIHNjYW5uZXIuc3RvcCgpLmNhdGNoKCgpID0+IHVuZGVmaW5lZCkuZmluYWxseShmaW5pc2hMaW5rKTtcclxuICAgICAgICAgICAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHN0b3AoKSBwb2RlIGxhbsOnYXIgZGUgZm9ybWEgc8OtbmNyb25hIHNlIG8gc2Nhbm5lciBqw6EgZXN0aXZlclxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHBhcmFuZG8g4oCUIHNlZ3VlIG1lc21vIGFzc2ltIGNvbSBvIHZhbG9yIGrDoSBsaWRvLlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbmlzaExpbmsoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgY29uc3Qgb25GcmFtZSA9ICgpID0+IHsgLyogZnJhbWUgc2VtIGxlaXR1cmEg4oCUIGlnbm9yYSBlIGNvbnRpbnVhIHRlbnRhbmRvICovIH07XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBzY2FubmVyLnN0YXJ0KHsgZmFjaW5nTW9kZTogXCJlbnZpcm9ubWVudFwiIH0sIHsgZnBzOiAxMCwgcXJib3g6IHsgd2lkdGg6IDI0MCwgaGVpZ2h0OiAyNDAgfSB9LCBvbkRlY29kZWQsIG9uRnJhbWUpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IHNjYW5uZXIuc3RhcnQoeyBmYWNpbmdNb2RlOiBcInVzZXJcIiB9LCB7IGZwczogMTAsIHFyYm94OiB7IHdpZHRoOiAyNDAsIGhlaWdodDogMjQwIH0gfSwgb25EZWNvZGVkLCBvbkZyYW1lKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBzZXRTY2FubmluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEVycm9yKGNhbWVyYUVycm9yTWVzc2FnZShlcnIpKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHN0b3BTY2FuID0gKCkgPT4ge1xyXG4gICAgICAgIHNhZmVTdG9wU2Nhbm5lcihzY2FubmVyUmVmKTtcclxuICAgICAgICBzZXRTY2FubmluZyhmYWxzZSk7XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxNiwgdGV4dEFsaWduOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgzIHN0eWxlPXt7IG1hcmdpbjogXCIwIDAgNnB4XCIsIGNvbG9yOiBcIiNmZmZcIiwgZm9udFNpemU6IFwiMS4xNXJlbVwiIH19PlZpbmN1bGFyIMOgIGNvbWFuZGE8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luOiAwLCBjb2xvcjogXCIjYThhOGIzXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHt3YW50c1NjYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBgRXNjYW5laWUgbyAke3JlcXVpcmVtZW50LmlzUXJDb2RlRW5hYmxlZCA/IFwiUVIgQ29kZVwiIDogXCJjw7NkaWdvIGRlIGJhcnJhc1wifSBkYSBjb21hbmRhIHBhcmEgbGFuw6dhciBlc3RlIHBlZGlkbyBuZWxhLmBcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkluZm9ybWUgbyBuw7ptZXJvIGRhIGNvbWFuZGEgZSB0aXJlIHVtYSBmb3RvIGRlbGEgcGFyYSBsYW7Dp2FyIGVzdGUgcGVkaWRvIG5lbGEuXCJ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFZlciBjb21lbnTDoXJpbyBlcXVpdmFsZW50ZSBlbSBSZWFkaW5nVmFsaWRhdGlvbkdhdGU6IG8gY29udGFpbmVyIHByZWNpc2FcclxuICAgICAgICAgICAgICBlc3RhciBzZW1wcmUgbW9udGFkbyAoc8OzIGVzY29uZGlkbyB2aWEgQ1NTKSBwcm8gYG5ldyBIdG1sNVFyY29kZShpZClgIGFjaGFyXHJcbiAgICAgICAgICAgICAgbyBlbGVtZW50byBubyBpbnN0YW50ZSBlbSBxdWUgbyBib3TDo28gw6kgY2xpY2Fkby4gKi99XHJcbiAgICAgICAgICAgIDxkaXYgaWQ9e0xJTktfU0NBTk5FUl9FTEVNRU5UX0lEfSBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIGJvcmRlclJhZGl1czogOCwgb3ZlcmZsb3c6IFwiaGlkZGVuXCIsIGRpc3BsYXk6IHNjYW5uaW5nID8gXCJibG9ja1wiIDogXCJub25lXCIgfX0gLz5cclxuICAgICAgICAgICAge3NjYW5uaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17c3RvcFNjYW59IGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiPkNhbmNlbGFyIGxlaXR1cmE8L2J1dHRvbj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgeyF3YW50c1NjYW4gJiYgcmVxdWlyZW1lbnQuaXNDYW1lcmFJbnB1dEVuYWJsZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttYW51YWxDb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWFudWFsQ29kZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOw7ptZXJvIGRhIGNvbWFuZGEgKGV4OiAwMDEpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIHBhZGRpbmc6IFwiMTRweCAxNnB4XCIsIGJvcmRlclJhZGl1czogOCwgYm9yZGVyOiBcIjFweCBzb2xpZCAjMzIzMjM4XCIsIGJhY2tncm91bmRDb2xvcjogXCIjMTIxMjE0XCIsIGNvbG9yOiBcIiNmZmZcIiwgZm9udFNpemU6IFwiMXJlbVwiLCBvdXRsaW5lOiBcIm5vbmVcIiwgYm94U2l6aW5nOiBcImJvcmRlci1ib3hcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZj17ZmlsZUlucHV0UmVmfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXB0dXJlPVwidXNlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZGlzcGxheTogXCJub25lXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaWxlKSBoYW5kbGVQaG90b1NlbGVjdGVkKGZpbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3N1Ym1pdHRpbmcgfHwgIW1hbnVhbENvZGUudHJpbSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IDE0LCBib3JkZXJSYWRpdXM6IDgsIGJvcmRlcjogXCIxcHggc29saWQgIzMyMzIzOFwiLCBiYWNrZ3JvdW5kQ29sb3I6IFwiI2Y1OWUwYlwiLCBjb2xvcjogXCIjMTIxMjE0XCIsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBjdXJzb3I6IHN1Ym1pdHRpbmcgfHwgIW1hbnVhbENvZGUudHJpbSgpID8gXCJub3QtYWxsb3dlZFwiIDogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5O3IFRpcmFyIHVtYSBmb3RvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7d2FudHNTY2FuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c3VibWl0dGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgc3RhcnRTY2FuKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiAxNCwgYm9yZGVyUmFkaXVzOiA4LCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiwgYmFja2dyb3VuZENvbG9yOiBcIiNmNTllMGJcIiwgY29sb3I6IFwiIzEyMTIxNFwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgY3Vyc29yOiBzdWJtaXR0aW5nID8gXCJub3QtYWxsb3dlZFwiIDogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlcXVpcmVtZW50LmlzUXJDb2RlRW5hYmxlZCA/IFwi4pamIEVzY2FuZWFyIFFSIENvZGUgZGEgY29tYW5kYVwiIDogXCLilqUgRXNjYW5lYXIgY8OzZGlnbyBkZSBiYXJyYXMgZGEgY29tYW5kYVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uQ2FuY2VsfSBkaXNhYmxlZD17c3VibWl0dGluZ30gY2xhc3NOYW1lPVwiYnRuLWdob3N0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbGFyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtzdWJtaXR0aW5nICYmIDxwIHN0eWxlPXt7IGNvbG9yOiBcIiNhOGE4YjNcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+VmluY3VsYW5kb+KApjwvcD59XHJcbiAgICAgICAgICAgIHtlcnJvciAmJiA8cCBzdHlsZT17eyBjb2xvcjogXCIjZWY0NDQ0XCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PntlcnJvcn08L3A+fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvcHVibGljT3JkZXJpbmcvQ29tYW5kYVJlYWRpbmdWYWxpZGF0aW9uLnRzeCJ9