import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppShell.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { NavLink, Outlet, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useThemeStore } from "/src/stores/themeStore.ts";
import { CashDrawer } from "/src/features/cash/CashDrawer.tsx";
import { useMyFeatures } from "/src/features/access/hooks.ts";
import { IFoodAlertsBell } from "/src/components/IFoodAlertsBell.tsx";
import logoDark from "/src/image/logodark.png?import";
import logoLight from "/src/image/logoligth.png?import";
const links = [
  { to: "/", label: "Salão", feature: "Salao" },
  { to: "/garcom", label: "Modo Garçom", feature: "Salao" },
  { to: "/delivery", label: "Delivery", feature: "Salao" },
  { to: "/preparo", label: "Preparo", feature: "Preparo" }
];
export function AppShell() {
  _s();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { userName, branchId, companyId, clear } = useAuthStore();
  const { theme, toggleTheme } = useThemeStore();
  const [cashOpen, setCashOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const featuresQuery = useMyFeatures();
  const access = featuresQuery.data;
  const canSee = (feature) => access !== void 0 && (access.canManageAccess || access.features.includes(feature));
  const closeNav = () => setNavOpen(false);
  return /* @__PURE__ */ jsxDEV("div", { style: { animation: "fadeInAlpha 0.6s ease-out forwards", minHeight: "100%", display: "flex", flexDirection: "column" }, children: [
    /* @__PURE__ */ jsxDEV("style", { children: `
                @keyframes fadeInAlpha {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
            ` }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
      lineNumber: 56,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("a", { href: "#main-content", className: "skip-link", children: "Pular para o conteúdo" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
      lineNumber: 66,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("header", { className: "topbar", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "nav-toggle",
          "aria-label": navOpen ? "Fechar menu" : "Abrir menu",
          "aria-expanded": navOpen,
          "aria-controls": "topbar-nav",
          onClick: () => setNavOpen((open) => !open),
          children: navOpen ? "✕" : "☰"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
          lineNumber: 71,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "img",
        {
          src: theme === "light" ? logoLight : logoDark,
          alt: "Logo do Sistema",
          style: { height: 64, objectFit: "contain", transition: "opacity 0.2s ease-in-out" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
          lineNumber: 83,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("nav", { id: "topbar-nav", className: `topbar-nav${navOpen ? " is-open" : ""}`, children: [
        links.filter((link) => canSee(link.feature)).map(
          (link) => /* @__PURE__ */ jsxDEV(
            NavLink,
            {
              to: link.to,
              end: link.to === "/",
              onClick: closeNav,
              style: ({ isActive }) => ({
                padding: "8px 14px",
                borderRadius: 8,
                textDecoration: "none",
                fontFamily: "var(--font-cond)",
                fontWeight: 600,
                letterSpacing: "0.05em",
                textTransform: "uppercase",
                fontSize: "0.85rem",
                color: isActive ? "var(--amber-ink)" : "var(--ink-dim)",
                background: isActive ? "var(--amber)" : "transparent"
              }),
              children: link.label
            },
            link.to,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
              lineNumber: 91,
              columnNumber: 11
            },
            this
          )
        ),
        access?.canManageAccess && /* @__PURE__ */ jsxDEV(
          NavLink,
          {
            to: "/integracoes/ifood",
            onClick: closeNav,
            title: "Central de integrações iFood — pedidos, cardápio, financeiro, logística e mais",
            style: ({ isActive }) => ({
              padding: "8px 14px",
              borderRadius: 8,
              textDecoration: "none",
              fontFamily: "var(--font-cond)",
              fontWeight: 600,
              letterSpacing: "0.05em",
              textTransform: "uppercase",
              fontSize: "0.85rem",
              color: isActive ? "#fff" : "#EA1D2C",
              background: isActive ? "#EA1D2C" : "transparent",
              border: "1px solid #EA1D2C"
            }),
            children: "🍔 iFood"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
            lineNumber: 113,
            columnNumber: 11
          },
          this
        ),
        access?.canManageAccess && /* @__PURE__ */ jsxDEV(
          NavLink,
          {
            to: "/configuracoes",
            onClick: closeNav,
            style: ({ isActive }) => ({
              padding: "8px 14px",
              borderRadius: 8,
              textDecoration: "none",
              fontFamily: "var(--font-cond)",
              fontWeight: 600,
              letterSpacing: "0.05em",
              textTransform: "uppercase",
              fontSize: "0.85rem",
              color: isActive ? "var(--amber-ink)" : "var(--amber)",
              background: isActive ? "var(--amber)" : "transparent",
              border: "1px dashed var(--amber-deep)"
            }),
            children: "Config."
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
            lineNumber: 135,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
        lineNumber: 89,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
        lineNumber: 156,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "span",
        {
          className: "chip topbar-branch-chip",
          style: { "--dot": "var(--free)" },
          children: [
            "Filial ",
            branchId
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
          lineNumber: 157,
          columnNumber: 17
        },
        this
      ),
      canSee("Caixa") && /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", onClick: () => setCashOpen(true), children: "Caixa" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
        lineNumber: 164,
        columnNumber: 9
      }, this),
      access?.canManageAccess && /* @__PURE__ */ jsxDEV(IFoodAlertsBell, { companyId }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
        lineNumber: 168,
        columnNumber: 45
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-ghost btn-icon",
          "aria-label": theme === "dark" ? "Ativar tema claro" : "Ativar tema escuro",
          title: theme === "dark" ? "Tema claro" : "Tema escuro",
          onClick: toggleTheme,
          children: theme === "dark" ? "☀" : "🌙"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
          lineNumber: 169,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("span", { className: "topbar-username", style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: userName }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
        lineNumber: 178,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-ghost",
          onClick: () => {
            queryClient.clear();
            clear();
            navigate("/login", { replace: true });
          },
          children: "Sair"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
          lineNumber: 181,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
      lineNumber: 70,
      columnNumber: 13
    }, this),
    featuresQuery.isError && /* @__PURE__ */ jsxDEV("p", { className: "error-text", role: "alert", style: { padding: "10px 22px", margin: 0 }, children: "Falha ao carregar seus acessos — a API está atualizada e rodando? (Reinicie-a se acabou de aplicar a funcionalidade de acessos.)" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
      lineNumber: 195,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { id: "main-content", tabIndex: -1, style: { flex: 1 }, children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
      lineNumber: 205,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
      lineNumber: 204,
      columnNumber: 13
    }, this),
    cashOpen && /* @__PURE__ */ jsxDEV(CashDrawer, { onClose: () => setCashOpen(false) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
      lineNumber: 208,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx",
    lineNumber: 55,
    columnNumber: 5
  }, this);
}
_s(AppShell, "fRS16hYWtbNzHjiy3oJam1DRRFE=", false, function() {
  return [useNavigate, useQueryClient, useAuthStore, useThemeStore, useMyFeatures];
});
_c = AppShell;
var _c;
$RefreshReg$(_c, "AppShell");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/AppShell.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBDWCxTQUFTQSxnQkFBZ0I7QUFDMUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLFNBQVNDLFFBQVFDLG1CQUFtQjtBQUM3QyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsdUJBQXVCO0FBR2hDLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxRQUFRO0FBQUEsRUFDVixFQUFFQyxJQUFJLEtBQUtDLE9BQU8sU0FBU0MsU0FBUyxRQUFRO0FBQUEsRUFDNUMsRUFBRUYsSUFBSSxXQUFXQyxPQUFPLGVBQWVDLFNBQVMsUUFBUTtBQUFBLEVBQ3hELEVBQUVGLElBQUksYUFBYUMsT0FBTyxZQUFZQyxTQUFTLFFBQVE7QUFBQSxFQUN2RCxFQUFFRixJQUFJLFlBQVlDLE9BQU8sV0FBV0MsU0FBUyxVQUFVO0FBQUM7QUFHckQsZ0JBQVNDLFdBQVc7QUFBQUMsS0FBQTtBQUN2QixRQUFNQyxXQUFXZCxZQUFZO0FBQzdCLFFBQU1lLGNBQWNsQixlQUFlO0FBQ25DLFFBQU0sRUFBRW1CLFVBQVVDLFVBQVVDLFdBQVdDLE1BQU0sSUFBSWxCLGFBQWE7QUFDOUQsUUFBTSxFQUFFbUIsT0FBT0MsWUFBWSxJQUFJbkIsY0FBYztBQUM3QyxRQUFNLENBQUNvQixVQUFVQyxXQUFXLElBQUkzQixTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDNEIsU0FBU0MsVUFBVSxJQUFJN0IsU0FBUyxLQUFLO0FBQzVDLFFBQU04QixnQkFBZ0J0QixjQUFjO0FBQ3BDLFFBQU11QixTQUFTRCxjQUFjRTtBQUM3QixRQUFNQyxTQUFTQSxDQUFDbEIsWUFDWmdCLFdBQVdHLFdBQWNILE9BQU9JLG1CQUFtQkosT0FBT0ssU0FBU0MsU0FBU3RCLE9BQU87QUFFdkYsUUFBTXVCLFdBQVdBLE1BQU1ULFdBQVcsS0FBSztBQUV2QyxTQUNJLHVCQUFDLFNBQUksT0FBTyxFQUFFVSxXQUFXLHNDQUFzQ0MsV0FBVyxRQUFRQyxTQUFTLFFBQVFDLGVBQWUsU0FBUyxHQUN2SDtBQUFBLDJCQUFDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLRTtBQUFBLElBS0YsdUJBQUMsT0FBRSxNQUFLLGlCQUFnQixXQUFVLGFBQVkscUNBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsWUFBTyxXQUFVLFVBQ2Q7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsY0FBWWQsVUFBVSxnQkFBZ0I7QUFBQSxVQUN0QyxpQkFBZUE7QUFBQUEsVUFDZixpQkFBYztBQUFBLFVBQ2QsU0FBUyxNQUFNQyxXQUFXLENBQUNjLFNBQVMsQ0FBQ0EsSUFBSTtBQUFBLFVBRXhDZixvQkFBVSxNQUFNO0FBQUE7QUFBQSxRQVJyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTQTtBQUFBLE1BR0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLEtBQUtKLFVBQVUsVUFBVWIsWUFBWUQ7QUFBQUEsVUFDckMsS0FBSTtBQUFBLFVBQ0osT0FBTyxFQUFFa0MsUUFBUSxJQUFJQyxXQUFXLFdBQVdDLFlBQVksMkJBQTJCO0FBQUE7QUFBQSxRQUh0RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHd0Y7QUFBQSxNQUd4Rix1QkFBQyxTQUFJLElBQUcsY0FBYSxXQUFXLGFBQWFsQixVQUFVLGFBQWEsRUFBRSxJQUNqRWhCO0FBQUFBLGNBQU1tQyxPQUFPLENBQUNDLFNBQVNmLE9BQU9lLEtBQUtqQyxPQUFPLENBQUMsRUFBRWtDO0FBQUFBLFVBQUksQ0FBQ0QsU0FDL0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVHLElBQUlBLEtBQUtuQztBQUFBQSxjQUNULEtBQUttQyxLQUFLbkMsT0FBTztBQUFBLGNBQ2pCLFNBQVN5QjtBQUFBQSxjQUNULE9BQU8sQ0FBQyxFQUFFWSxTQUFTLE9BQU87QUFBQSxnQkFDdEJDLFNBQVM7QUFBQSxnQkFDVEMsY0FBYztBQUFBLGdCQUNkQyxnQkFBZ0I7QUFBQSxnQkFDaEJDLFlBQVk7QUFBQSxnQkFDWkMsWUFBWTtBQUFBLGdCQUNaQyxlQUFlO0FBQUEsZ0JBQ2ZDLGVBQWU7QUFBQSxnQkFDZkMsVUFBVTtBQUFBLGdCQUNWQyxPQUFPVCxXQUFXLHFCQUFxQjtBQUFBLGdCQUN2Q1UsWUFBWVYsV0FBVyxpQkFBaUI7QUFBQSxjQUM1QztBQUFBLGNBRUNGLGVBQUtsQztBQUFBQTtBQUFBQSxZQWpCRGtDLEtBQUtuQztBQUFBQSxZQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtQkE7QUFBQSxRQUNIO0FBQUEsUUFDQWtCLFFBQVFJLG1CQUNMO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxTQUFTRztBQUFBQSxZQUNULE9BQU07QUFBQSxZQUNOLE9BQU8sQ0FBQyxFQUFFWSxTQUFTLE9BQU87QUFBQSxjQUN0QkMsU0FBUztBQUFBLGNBQ1RDLGNBQWM7QUFBQSxjQUNkQyxnQkFBZ0I7QUFBQSxjQUNoQkMsWUFBWTtBQUFBLGNBQ1pDLFlBQVk7QUFBQSxjQUNaQyxlQUFlO0FBQUEsY0FDZkMsZUFBZTtBQUFBLGNBQ2ZDLFVBQVU7QUFBQSxjQUNWQyxPQUFPVCxXQUFXLFNBQVM7QUFBQSxjQUMzQlUsWUFBWVYsV0FBVyxZQUFZO0FBQUEsY0FDbkNXLFFBQVE7QUFBQSxZQUNaO0FBQUEsWUFBRztBQUFBO0FBQUEsVUFoQlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUJBO0FBQUEsUUFFSDlCLFFBQVFJLG1CQUNMO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxTQUFTRztBQUFBQSxZQUNULE9BQU8sQ0FBQyxFQUFFWSxTQUFTLE9BQU87QUFBQSxjQUN0QkMsU0FBUztBQUFBLGNBQ1RDLGNBQWM7QUFBQSxjQUNkQyxnQkFBZ0I7QUFBQSxjQUNoQkMsWUFBWTtBQUFBLGNBQ1pDLFlBQVk7QUFBQSxjQUNaQyxlQUFlO0FBQUEsY0FDZkMsZUFBZTtBQUFBLGNBQ2ZDLFVBQVU7QUFBQSxjQUNWQyxPQUFPVCxXQUFXLHFCQUFxQjtBQUFBLGNBQ3ZDVSxZQUFZVixXQUFXLGlCQUFpQjtBQUFBLGNBQ3hDVyxRQUFRO0FBQUEsWUFDWjtBQUFBLFlBQUc7QUFBQTtBQUFBLFVBZlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0JBO0FBQUEsV0FoRVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE1BQU0sRUFBRSxLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFdBQVU7QUFBQSxVQUNWLE9BQU8sRUFBRSxTQUFTLGNBQWM7QUFBQSxVQUF5QjtBQUFBO0FBQUEsWUFFakR6QztBQUFBQTtBQUFBQTtBQUFBQSxRQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsTUFDQ1ksT0FBTyxPQUFPLEtBQ1gsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLFNBQVMsTUFBTU4sWUFBWSxJQUFJLEdBQUcscUJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUhJLFFBQVFJLG1CQUFtQix1QkFBQyxtQkFBZ0IsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQztBQUFBLE1BQ2xFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFDVixjQUFZWCxVQUFVLFNBQVMsc0JBQXNCO0FBQUEsVUFDckQsT0FBT0EsVUFBVSxTQUFTLGVBQWU7QUFBQSxVQUN6QyxTQUFTQztBQUFBQSxVQUVSRCxvQkFBVSxTQUFTLE1BQU07QUFBQTtBQUFBLFFBUDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFdBQVUsbUJBQWtCLE9BQU8sRUFBRW1DLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FDbkZ0QyxzQkFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFDVixTQUFTLE1BQU07QUFDWEQsd0JBQVlJLE1BQU07QUFDbEJBLGtCQUFNO0FBQ05MLHFCQUFTLFVBQVUsRUFBRTZDLFNBQVMsS0FBSyxDQUFDO0FBQUEsVUFDeEM7QUFBQSxVQUFFO0FBQUE7QUFBQSxRQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBO0FBQUEsU0F6SEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBIQTtBQUFBLElBRUNqQyxjQUFja0MsV0FDWCx1QkFBQyxPQUFFLFdBQVUsY0FBYSxNQUFLLFNBQVEsT0FBTyxFQUFFYixTQUFTLGFBQWFjLFFBQVEsRUFBRSxHQUFHLGdKQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQU1KLHVCQUFDLFNBQUksSUFBRyxnQkFBZSxVQUFVLElBQUksT0FBTyxFQUFFSCxNQUFNLEVBQUUsR0FDbEQsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVDcEMsWUFBWSx1QkFBQyxjQUFXLFNBQVMsTUFBTUMsWUFBWSxLQUFLLEtBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEM7QUFBQSxPQXpKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBKQTtBQUVSO0FBQUNWLEdBM0tlRCxVQUFRO0FBQUEsVUFDSFosYUFDR0gsZ0JBQzZCSSxjQUNsQkMsZUFHVEUsYUFBYTtBQUFBO0FBQUEsS0FQdkJRO0FBQVEsSUFBQWtEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUXVlcnlDbGllbnQiLCJOYXZMaW5rIiwiT3V0bGV0IiwidXNlTmF2aWdhdGUiLCJ1c2VBdXRoU3RvcmUiLCJ1c2VUaGVtZVN0b3JlIiwiQ2FzaERyYXdlciIsInVzZU15RmVhdHVyZXMiLCJJRm9vZEFsZXJ0c0JlbGwiLCJsb2dvRGFyayIsImxvZ29MaWdodCIsImxpbmtzIiwidG8iLCJsYWJlbCIsImZlYXR1cmUiLCJBcHBTaGVsbCIsIl9zIiwibmF2aWdhdGUiLCJxdWVyeUNsaWVudCIsInVzZXJOYW1lIiwiYnJhbmNoSWQiLCJjb21wYW55SWQiLCJjbGVhciIsInRoZW1lIiwidG9nZ2xlVGhlbWUiLCJjYXNoT3BlbiIsInNldENhc2hPcGVuIiwibmF2T3BlbiIsInNldE5hdk9wZW4iLCJmZWF0dXJlc1F1ZXJ5IiwiYWNjZXNzIiwiZGF0YSIsImNhblNlZSIsInVuZGVmaW5lZCIsImNhbk1hbmFnZUFjY2VzcyIsImZlYXR1cmVzIiwiaW5jbHVkZXMiLCJjbG9zZU5hdiIsImFuaW1hdGlvbiIsIm1pbkhlaWdodCIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwib3BlbiIsImhlaWdodCIsIm9iamVjdEZpdCIsInRyYW5zaXRpb24iLCJmaWx0ZXIiLCJsaW5rIiwibWFwIiwiaXNBY3RpdmUiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwidGV4dERlY29yYXRpb24iLCJmb250RmFtaWx5IiwiZm9udFdlaWdodCIsImxldHRlclNwYWNpbmciLCJ0ZXh0VHJhbnNmb3JtIiwiZm9udFNpemUiLCJjb2xvciIsImJhY2tncm91bmQiLCJib3JkZXIiLCJmbGV4IiwicmVwbGFjZSIsImlzRXJyb3IiLCJtYXJnaW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHBTaGVsbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IE5hdkxpbmssIE91dGxldCwgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyB1c2VUaGVtZVN0b3JlIH0gZnJvbSBcIi4uL3N0b3Jlcy90aGVtZVN0b3JlXCI7XHJcbmltcG9ydCB7IENhc2hEcmF3ZXIgfSBmcm9tIFwiLi4vZmVhdHVyZXMvY2FzaC9DYXNoRHJhd2VyXCI7XHJcbmltcG9ydCB7IHVzZU15RmVhdHVyZXMgfSBmcm9tIFwiLi4vZmVhdHVyZXMvYWNjZXNzL2hvb2tzXCI7XHJcbmltcG9ydCB7IElGb29kQWxlcnRzQmVsbCB9IGZyb20gXCIuL0lGb29kQWxlcnRzQmVsbFwiO1xyXG5cclxuLy8gSW1wb3J0YW5kbyBvcyBkb2lzIGxvZ29zXHJcbmltcG9ydCBsb2dvRGFyayBmcm9tIFwiLi4vaW1hZ2UvbG9nb2RhcmsucG5nXCI7XHJcbmltcG9ydCBsb2dvTGlnaHQgZnJvbSBcIi4uL2ltYWdlL2xvZ29saWd0aC5wbmdcIjtcclxuXHJcbmNvbnN0IGxpbmtzID0gW1xyXG4gICAgeyB0bzogXCIvXCIsIGxhYmVsOiBcIlNhbMOjb1wiLCBmZWF0dXJlOiBcIlNhbGFvXCIgfSxcclxuICAgIHsgdG86IFwiL2dhcmNvbVwiLCBsYWJlbDogXCJNb2RvIEdhcsOnb21cIiwgZmVhdHVyZTogXCJTYWxhb1wiIH0sXHJcbiAgICB7IHRvOiBcIi9kZWxpdmVyeVwiLCBsYWJlbDogXCJEZWxpdmVyeVwiLCBmZWF0dXJlOiBcIlNhbGFvXCIgfSxcclxuICAgIHsgdG86IFwiL3ByZXBhcm9cIiwgbGFiZWw6IFwiUHJlcGFyb1wiLCBmZWF0dXJlOiBcIlByZXBhcm9cIiB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEFwcFNoZWxsKCkge1xyXG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyB1c2VyTmFtZSwgYnJhbmNoSWQsIGNvbXBhbnlJZCwgY2xlYXIgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gICAgY29uc3QgeyB0aGVtZSwgdG9nZ2xlVGhlbWUgfSA9IHVzZVRoZW1lU3RvcmUoKTtcclxuICAgIGNvbnN0IFtjYXNoT3Blbiwgc2V0Q2FzaE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW25hdk9wZW4sIHNldE5hdk9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgZmVhdHVyZXNRdWVyeSA9IHVzZU15RmVhdHVyZXMoKTtcclxuICAgIGNvbnN0IGFjY2VzcyA9IGZlYXR1cmVzUXVlcnkuZGF0YTtcclxuICAgIGNvbnN0IGNhblNlZSA9IChmZWF0dXJlOiBzdHJpbmcpID0+XHJcbiAgICAgICAgYWNjZXNzICE9PSB1bmRlZmluZWQgJiYgKGFjY2Vzcy5jYW5NYW5hZ2VBY2Nlc3MgfHwgYWNjZXNzLmZlYXR1cmVzLmluY2x1ZGVzKGZlYXR1cmUpKTtcclxuXHJcbiAgICBjb25zdCBjbG9zZU5hdiA9ICgpID0+IHNldE5hdk9wZW4oZmFsc2UpO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBhbmltYXRpb246IFwiZmFkZUluQWxwaGEgMC42cyBlYXNlLW91dCBmb3J3YXJkc1wiLCBtaW5IZWlnaHQ6IFwiMTAwJVwiLCBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiB9fT5cclxuICAgICAgICAgICAgPHN0eWxlPntgXHJcbiAgICAgICAgICAgICAgICBAa2V5ZnJhbWVzIGZhZGVJbkFscGhhIHtcclxuICAgICAgICAgICAgICAgICAgICBmcm9tIHsgb3BhY2l0eTogMDsgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRvIHsgb3BhY2l0eTogMTsgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBgfTwvc3R5bGU+XHJcblxyXG4gICAgICAgICAgICB7LyogQWNoYWRvIGRlIHJldmlzw6NvICh3ZWItZGVzaWduLWd1aWRlbGluZXMpOiBzZW0gc2tpcCBsaW5rLCBxdWVtIG5hdmVnYSBzw7MgcG9yIHRlY2xhZG9cclxuICAgICAgICAgIHByZWNpc2EgdGFidWxhciBwZWxvIG1lbnUgaW50ZWlybyBkbyB0b3BiYXIgdG9kYSB2ZXogcXVlIHRyb2NhIGRlIHRlbGEuIFByaW1laXJvXHJcbiAgICAgICAgICBlbGVtZW50byBmb2PDoXZlbCBkYSBww6FnaW5hIOKAlCBpbnZpc8OtdmVsIGF0w6kgcmVjZWJlciBmb2NvLiAqL31cclxuICAgICAgICAgICAgPGEgaHJlZj1cIiNtYWluLWNvbnRlbnRcIiBjbGFzc05hbWU9XCJza2lwLWxpbmtcIj5cclxuICAgICAgICAgICAgICAgIFB1bGFyIHBhcmEgbyBjb250ZcO6ZG9cclxuICAgICAgICAgICAgPC9hPlxyXG5cclxuICAgICAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJ0b3BiYXJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJuYXYtdG9nZ2xlXCJcclxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtuYXZPcGVuID8gXCJGZWNoYXIgbWVudVwiIDogXCJBYnJpciBtZW51XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1leHBhbmRlZD17bmF2T3Blbn1cclxuICAgICAgICAgICAgICAgICAgICBhcmlhLWNvbnRyb2xzPVwidG9wYmFyLW5hdlwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TmF2T3Blbigob3BlbikgPT4gIW9wZW4pfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtuYXZPcGVuID8gXCLinJVcIiA6IFwi4piwXCJ9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQWx0ZXJuw6JuY2lhIGRpcmV0YSBjb20gYmFzZSBubyBlc3RhZG8gJ3RoZW1lJyAqL31cclxuICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICBzcmM9e3RoZW1lID09PSBcImxpZ2h0XCIgPyBsb2dvTGlnaHQgOiBsb2dvRGFya31cclxuICAgICAgICAgICAgICAgICAgICBhbHQ9XCJMb2dvIGRvIFNpc3RlbWFcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogNjQsIG9iamVjdEZpdDogXCJjb250YWluXCIsIHRyYW5zaXRpb246IFwib3BhY2l0eSAwLjJzIGVhc2UtaW4tb3V0XCIgfX1cclxuICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgPG5hdiBpZD1cInRvcGJhci1uYXZcIiBjbGFzc05hbWU9e2B0b3BiYXItbmF2JHtuYXZPcGVuID8gXCIgaXMtb3BlblwiIDogXCJcIn1gfT5cclxuICAgICAgICAgICAgICAgICAgICB7bGlua3MuZmlsdGVyKChsaW5rKSA9PiBjYW5TZWUobGluay5mZWF0dXJlKSkubWFwKChsaW5rKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2xpbmsudG99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17bGluay50b31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZD17bGluay50byA9PT0gXCIvXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjbG9zZU5hdn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXsoeyBpc0FjdGl2ZSB9KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiOHB4IDE0cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb246IFwibm9uZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1jb25kKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDYwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIgYXMgY29uc3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC44NXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBpc0FjdGl2ZSA/IFwidmFyKC0tYW1iZXItaW5rKVwiIDogXCJ2YXIoLS1pbmstZGltKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzQWN0aXZlID8gXCJ2YXIoLS1hbWJlcilcIiA6IFwidHJhbnNwYXJlbnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGluay5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIHthY2Nlc3M/LmNhbk1hbmFnZUFjY2VzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjbG9zZU5hdn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ2VudHJhbCBkZSBpbnRlZ3Jhw6fDtWVzIGlGb29kIOKAlCBwZWRpZG9zLCBjYXJkw6FwaW8sIGZpbmFuY2Vpcm8sIGxvZ8Otc3RpY2EgZSBtYWlzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXsoeyBpc0FjdGl2ZSB9KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiOHB4IDE0cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb246IFwibm9uZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1jb25kKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDYwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIgYXMgY29uc3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC44NXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBpc0FjdGl2ZSA/IFwiI2ZmZlwiIDogXCIjRUExRDJDXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogaXNBY3RpdmUgPyBcIiNFQTFEMkNcIiA6IFwidHJhbnNwYXJlbnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICNFQTFEMkNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn42UIGlGb29kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHthY2Nlc3M/LmNhbk1hbmFnZUFjY2VzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9jb25maWd1cmFjb2VzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlTmF2fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9eyh7IGlzQWN0aXZlIH0pID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCI4cHggMTRweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseTogXCJ2YXIoLS1mb250LWNvbmQpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNjAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIiBhcyBjb25zdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIwLjg1cmVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IGlzQWN0aXZlID8gXCJ2YXIoLS1hbWJlci1pbmspXCIgOiBcInZhcigtLWFtYmVyKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzQWN0aXZlID8gXCJ2YXIoLS1hbWJlcilcIiA6IFwidHJhbnNwYXJlbnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IGRhc2hlZCB2YXIoLS1hbWJlci1kZWVwKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbmZpZy5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L25hdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZsZXg6IDEgfX0gLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2hpcCB0b3BiYXItYnJhbmNoLWNoaXBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IFwiLS1kb3RcIjogXCJ2YXIoLS1mcmVlKVwiIH0gYXMgUmVhY3QuQ1NTUHJvcGVydGllc31cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBGaWxpYWwge2JyYW5jaElkfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge2NhblNlZShcIkNhaXhhXCIpICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRDYXNoT3Blbih0cnVlKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENhaXhhXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge2FjY2Vzcz8uY2FuTWFuYWdlQWNjZXNzICYmIDxJRm9vZEFsZXJ0c0JlbGwgY29tcGFueUlkPXtjb21wYW55SWR9IC8+fVxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdCBidG4taWNvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17dGhlbWUgPT09IFwiZGFya1wiID8gXCJBdGl2YXIgdGVtYSBjbGFyb1wiIDogXCJBdGl2YXIgdGVtYSBlc2N1cm9cIn1cclxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17dGhlbWUgPT09IFwiZGFya1wiID8gXCJUZW1hIGNsYXJvXCIgOiBcIlRlbWEgZXNjdXJvXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlVGhlbWV9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3RoZW1lID09PSBcImRhcmtcIiA/IFwi4piAXCIgOiBcIvCfjJlcIn1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidG9wYmFyLXVzZXJuYW1lXCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45MnJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHt1c2VyTmFtZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlDbGllbnQuY2xlYXIoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xlYXIoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmF2aWdhdGUoXCIvbG9naW5cIiwgeyByZXBsYWNlOiB0cnVlIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU2FpclxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgICAgICAge2ZlYXR1cmVzUXVlcnkuaXNFcnJvciAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCIgcm9sZT1cImFsZXJ0XCIgc3R5bGU9e3sgcGFkZGluZzogXCIxMHB4IDIycHhcIiwgbWFyZ2luOiAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIEZhbGhhIGFvIGNhcnJlZ2FyIHNldXMgYWNlc3NvcyDigJQgYSBBUEkgZXN0w6EgYXR1YWxpemFkYSBlIHJvZGFuZG8/IChSZWluaWNpZS1hXHJcbiAgICAgICAgICAgICAgICAgICAgc2UgYWNhYm91IGRlIGFwbGljYXIgYSBmdW5jaW9uYWxpZGFkZSBkZSBhY2Vzc29zLilcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiB0YWJJbmRleD0tMTogYWx2byBkbyBza2lwIGxpbmsgYWNpbWEg4oCUIHbDoXJpYXMgdGVsYXMgasOhIHTDqm0gc2V1IHByw7NwcmlvIDxtYWluPlxyXG4gICAgICAgICAgKGV4LjogUHJvZHVjdHNQYWdlKSwgZW50w6NvIGVzdGUgw6kgdW0gZGl2IGZvY8OhdmVsIHNpbXBsZXMgZW0gdmV6IGRlIG91dHJvIDxtYWluPlxyXG4gICAgICAgICAgYW5pbmhhZG8gKGxhbmRtYXJrIGR1cGxpY2FkbyBzZXJpYSBpbnbDoWxpZG8pLiAqL31cclxuICAgICAgICAgICAgPGRpdiBpZD1cIm1haW4tY29udGVudFwiIHRhYkluZGV4PXstMX0gc3R5bGU9e3sgZmxleDogMSB9fT5cclxuICAgICAgICAgICAgICAgIDxPdXRsZXQgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7Y2FzaE9wZW4gJiYgPENhc2hEcmF3ZXIgb25DbG9zZT17KCkgPT4gc2V0Q2FzaE9wZW4oZmFsc2UpfSAvPn1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn0iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9BcHBTaGVsbC50c3gifQ==