import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/OrdersPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { generateTableQrToken, getTablesByBranch } from "/src/features/tables/api.ts";
import { getOpenOrdersByBranch } from "/src/features/orders/api.ts";
import { getComandaSetting, getComandasByBranch } from "/src/features/comandas/api.ts";
import { OpenComandaDialog } from "/src/features/comandas/OpenComandaDialog.tsx";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ComandaStatus, TableStatus, formatBRL } from "/src/lib/types.ts";
import { OrderDrawer } from "/src/features/orders/OrderDrawer.tsx";
import { OpenOrderDialog } from "/src/features/orders/OpenOrderDialog.tsx";
import { OpenDeliveryOrderDialog } from "/src/features/orders/OpenDeliveryOrderDialog.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { Overlay } from "/src/features/orders/Overlay.tsx";
const statusColor = {
  [TableStatus.Livre]: "var(--free)",
  [TableStatus.Ocupada]: "var(--busy)",
  [TableStatus.Reservada]: "var(--reserved)",
  [TableStatus.EmFechamento]: "var(--closing)",
  [TableStatus.Interditada]: "var(--blocked)"
};
const comandaColor = {
  [ComandaStatus.Disponivel]: "var(--free)",
  [ComandaStatus.EmUso]: "var(--busy)",
  [ComandaStatus.Extraviada]: "var(--closing)",
  [ComandaStatus.Bloqueada]: "var(--blocked)"
};
const comandaStatusLabel = {
  [ComandaStatus.Disponivel]: "Livre",
  [ComandaStatus.EmUso]: "Em uso",
  [ComandaStatus.Extraviada]: "Extraviada",
  [ComandaStatus.Bloqueada]: "Bloqueada"
};
const statusLabel = {
  [TableStatus.Livre]: "Livre",
  [TableStatus.Ocupada]: "Ocupada",
  [TableStatus.Reservada]: "Reservada",
  [TableStatus.EmFechamento]: "Fechando",
  [TableStatus.Interditada]: "Interditada"
};
export function OrdersPage() {
  _s();
  const queryClient = useQueryClient();
  const { branchId } = useAuthStore();
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [openingTable, setOpeningTable] = useState(null);
  const [openingComanda, setOpeningComanda] = useState(null);
  const [comandaSearch, setComandaSearch] = useState("");
  const [qrTable, setQrTable] = useState(null);
  const [qrUrl, setQrUrl] = useState(null);
  const [openingDelivery, setOpeningDelivery] = useState(false);
  const qrMutation = useMutation({
    mutationFn: (tableId) => generateTableQrToken(tableId),
    onSuccess: (result) => setQrUrl(`${window.location.origin}/pedido/${result.token}`)
  });
  const tablesQuery = useQuery({
    queryKey: ["tables", branchId],
    queryFn: () => getTablesByBranch(branchId),
    refetchInterval: 15e3
  });
  const comandaSettingQuery = useQuery({
    queryKey: ["comandas", "setting", branchId],
    queryFn: () => getComandaSetting(branchId)
  });
  const comandasQuery = useQuery({
    queryKey: ["comandas", branchId],
    queryFn: () => getComandasByBranch(branchId),
    refetchInterval: 15e3
  });
  const ordersQuery = useQuery({
    queryKey: ["orders", "open", branchId],
    queryFn: () => getOpenOrdersByBranch(branchId),
    refetchInterval: 15e3
  });
  const orderByTable = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const order of ordersQuery.data ?? [])
      if (order.diningTableId !== null) map.set(order.diningTableId, order);
    return map;
  }, [ordersQuery.data]);
  const orderByComanda = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const order of ordersQuery.data ?? [])
      if (order.comandaId !== null) map.set(order.comandaId, order);
    return map;
  }, [ordersQuery.data]);
  const filteredComandas = useMemo(
    () => (comandasQuery.data ?? []).filter(
      (c) => comandaSearch.trim() === "" ? true : c.code.includes(comandaSearch.trim())
    ),
    [comandasQuery.data, comandaSearch]
  );
  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: ["tables"] });
    void queryClient.invalidateQueries({ queryKey: ["orders"] });
    void queryClient.invalidateQueries({ queryKey: ["comandas"] });
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("main", { style: { padding: "22px", maxWidth: 1240, margin: "0 auto" }, children: [
      /* @__PURE__ */ jsxDEV("section", { className: "rise", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { alignItems: "baseline", gap: 14, marginBottom: 14 }, children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Mesas" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 137,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "toque numa mesa livre para abrir um pedido" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 140,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "ui-spacer" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 143,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-ghost", type: "button", onClick: () => setOpeningDelivery(true), children: "+ Retirada / Delivery" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 144,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "btn-ghost",
              type: "button",
              disabled: (tablesQuery.data ?? []).length === 0,
              onClick: () => {
                setQrUrl(null);
                setQrTable(tablesQuery.data?.[0] ?? null);
              },
              children: "Gerar QR de autoatendimento"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
              lineNumber: 147,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
          lineNumber: 136,
          columnNumber: 11
        }, this),
        tablesQuery.isLoading && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)" }, children: "Carregando mesas…" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
          lineNumber: 157,
          columnNumber: 37
        }, this),
        tablesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: tablesQuery.error, what: "as mesas" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
          lineNumber: 158,
          columnNumber: 35
        }, this),
        ordersQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: ordersQuery.error, what: "os pedidos abertos" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
          lineNumber: 159,
          columnNumber: 35
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "table-grid", children: (tablesQuery.data ?? []).map((table) => {
          const order = orderByTable.get(table.id);
          const color = statusColor[table.tableStatusId] ?? "var(--ink-faint)";
          return /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "table-tile",
              type: "button",
              style: { "--status": color },
              onClick: () => {
                if (order) setSelectedOrderId(order.id);
                else if (table.tableStatusId === TableStatus.Livre) setOpeningTable(table);
              },
              children: [
                /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "num mono-num", children: table.number }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                    lineNumber: 177,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": color }, children: statusLabel[table.tableStatusId] ?? "—" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                    lineNumber: 178,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                  lineNumber: 176,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--ink-dim)", fontSize: "0.88rem" }, children: order ? /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: [
                  order.items.length,
                  " itens · ",
                  formatBRL(order.totalAmount)
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                  lineNumber: 184,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("span", { children: [
                  table.capacity ?? "—",
                  " lugares"
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                  lineNumber: 188,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                  lineNumber: 182,
                  columnNumber: 19
                }, this)
              ]
            },
            table.id,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
              lineNumber: 166,
              columnNumber: 17
            },
            this
          );
        }) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
          lineNumber: 161,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 135,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rise rise-2", style: { marginTop: 34 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 14, flexWrap: "wrap" }, children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Comandas" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 199,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "toque numa comanda livre para abrir uma conta individual" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 200,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 203,
            columnNumber: 13
          }, this),
          comandaSettingQuery.data && /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": "var(--busy)" }, children: [
            "limite ",
            formatBRL(comandaSettingQuery.data.defaultLimitAmount)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 205,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              placeholder: "nº…",
              inputMode: "numeric",
              value: comandaSearch,
              onChange: (e) => setComandaSearch(e.target.value),
              style: { width: 110 }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
              lineNumber: 209,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
          lineNumber: 198,
          columnNumber: 11
        }, this),
        comandasQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: comandasQuery.error, what: "as comandas" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
          lineNumber: 219,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            style: {
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(76px, 1fr))",
              gap: 8
            },
            children: filteredComandas.map((comanda) => {
              const order = orderByComanda.get(comanda.id);
              const color = comandaColor[comanda.comandaStatusId] ?? "var(--ink-faint)";
              const busy = comanda.comandaStatusId === ComandaStatus.EmUso;
              return /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    if (order) setSelectedOrderId(order.id);
                    else if (comanda.comandaStatusId === ComandaStatus.Disponivel)
                      setOpeningComanda(comanda);
                  },
                  title: order ? `${order.items.length} itens · ${formatBRL(order.totalAmount)}` : void 0,
                  style: {
                    background: busy ? "var(--bg-press)" : "var(--bg-raise)",
                    border: `1px solid ${busy ? color : "var(--line)"}`,
                    borderRadius: 10,
                    minHeight: 64,
                    display: "grid",
                    gap: 2,
                    placeItems: "center",
                    padding: "8px 4px"
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "display mono-num", style: { fontSize: "1.5rem", color: busy ? color : "var(--ink)" }, children: comanda.code }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                      lineNumber: 254,
                      columnNumber: 19
                    }, this),
                    order ? /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { fontSize: "0.68rem", color: "var(--ink-dim)" }, children: formatBRL(order.totalAmount) }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                      lineNumber: 258,
                      columnNumber: 19
                    }, this) : /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.62rem", color, textTransform: "uppercase", letterSpacing: "0.06em" }, children: comandaStatusLabel[comanda.comandaStatusId] ?? "" }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                      lineNumber: 262,
                      columnNumber: 19
                    }, this)
                  ]
                },
                comanda.id,
                true,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                  lineNumber: 234,
                  columnNumber: 17
                },
                this
              );
            })
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 222,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 197,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
      lineNumber: 134,
      columnNumber: 7
    }, this),
    openingComanda && /* @__PURE__ */ jsxDEV(
      OpenComandaDialog,
      {
        comanda: openingComanda,
        onClose: () => setOpeningComanda(null),
        onOpened: (orderId) => {
          setOpeningComanda(null);
          refresh();
          setSelectedOrderId(orderId);
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 274,
        columnNumber: 7
      },
      this
    ),
    openingTable && /* @__PURE__ */ jsxDEV(
      OpenOrderDialog,
      {
        table: openingTable,
        onClose: () => setOpeningTable(null),
        onOpened: (orderId) => {
          setOpeningTable(null);
          refresh();
          setSelectedOrderId(orderId);
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 286,
        columnNumber: 7
      },
      this
    ),
    selectedOrderId !== null && /* @__PURE__ */ jsxDEV(
      OrderDrawer,
      {
        orderId: selectedOrderId,
        onClose: () => {
          setSelectedOrderId(null);
          refresh();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 298,
        columnNumber: 7
      },
      this
    ),
    openingDelivery && /* @__PURE__ */ jsxDEV(
      OpenDeliveryOrderDialog,
      {
        onClose: () => setOpeningDelivery(false),
        onOpened: (orderId) => {
          setOpeningDelivery(false);
          refresh();
          setSelectedOrderId(orderId);
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 308,
        columnNumber: 7
      },
      this
    ),
    qrTable && /* @__PURE__ */ jsxDEV(Overlay, { title: "QR Code de autoatendimento", onClose: () => setQrTable(null), children: [
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Mesa" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
          lineNumber: 321,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: qrTable.id,
            onChange: (e) => {
              const table = (tablesQuery.data ?? []).find((t) => t.id === Number(e.target.value)) ?? null;
              setQrTable(table);
              setQrUrl(null);
            },
            children: (tablesQuery.data ?? []).map(
              (t) => /* @__PURE__ */ jsxDEV("option", { value: t.id, children: [
                "Mesa ",
                t.number
              ] }, t.id, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
                lineNumber: 331,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 322,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 320,
        columnNumber: 11
      }, this),
      qrMutation.isError && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: "Falha ao gerar o QR Code — confirme que existe um funcionário configurado para autoatendimento em Config. → Filial." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 337,
        columnNumber: 9
      }, this),
      qrUrl ? /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10, justifyItems: "center" }, children: [
        /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(qrUrl)}`,
            alt: `QR Code de autoatendimento da mesa ${qrTable.number}`,
            width: 220,
            height: 220,
            style: { borderRadius: 8, background: "#fff" }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
            lineNumber: 345,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("input", { readOnly: true, value: qrUrl, onFocus: (e) => e.target.select(), style: { width: "100%" } }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
          lineNumber: 352,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 344,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "button", disabled: qrMutation.isPending, onClick: () => qrMutation.mutate(qrTable.id), children: qrMutation.isPending ? "Gerando…" : "Gerar QR Code" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
        lineNumber: 355,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
      lineNumber: 319,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx",
    lineNumber: 133,
    columnNumber: 5
  }, this);
}
_s(OrdersPage, "TvV1MIDNypuQDTu8OHxaa5V2ByM=", false, function() {
  return [useQueryClient, useAuthStore, useMutation, useQuery, useQuery, useQuery, useQuery];
});
_c = OrdersPage;
var _c;
$RefreshReg$(_c, "OrdersPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrdersPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUhJLG1CQUlRLGNBSlI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBakhILFNBQVNBLFNBQVNDLGdCQUFvQztBQUN2RCxTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQsU0FBU0Msc0JBQXNCQyx5QkFBeUI7QUFDeEQsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLG1CQUFtQkMsMkJBQTJCO0FBQ3ZELFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZUFBZUMsYUFBYUMsaUJBQWlCO0FBRXRELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGNBQXNDO0FBQUEsRUFDMUMsQ0FBQ1AsWUFBWVEsS0FBSyxHQUFHO0FBQUEsRUFDckIsQ0FBQ1IsWUFBWVMsT0FBTyxHQUFHO0FBQUEsRUFDdkIsQ0FBQ1QsWUFBWVUsU0FBUyxHQUFHO0FBQUEsRUFDekIsQ0FBQ1YsWUFBWVcsWUFBWSxHQUFHO0FBQUEsRUFDNUIsQ0FBQ1gsWUFBWVksV0FBVyxHQUFHO0FBQzdCO0FBRUEsTUFBTUMsZUFBdUM7QUFBQSxFQUMzQyxDQUFDZCxjQUFjZSxVQUFVLEdBQUc7QUFBQSxFQUM1QixDQUFDZixjQUFjZ0IsS0FBSyxHQUFHO0FBQUEsRUFDdkIsQ0FBQ2hCLGNBQWNpQixVQUFVLEdBQUc7QUFBQSxFQUM1QixDQUFDakIsY0FBY2tCLFNBQVMsR0FBRztBQUM3QjtBQUVBLE1BQU1DLHFCQUE2QztBQUFBLEVBQ2pELENBQUNuQixjQUFjZSxVQUFVLEdBQUc7QUFBQSxFQUM1QixDQUFDZixjQUFjZ0IsS0FBSyxHQUFHO0FBQUEsRUFDdkIsQ0FBQ2hCLGNBQWNpQixVQUFVLEdBQUc7QUFBQSxFQUM1QixDQUFDakIsY0FBY2tCLFNBQVMsR0FBRztBQUM3QjtBQUVBLE1BQU1FLGNBQXNDO0FBQUEsRUFDMUMsQ0FBQ25CLFlBQVlRLEtBQUssR0FBRztBQUFBLEVBQ3JCLENBQUNSLFlBQVlTLE9BQU8sR0FBRztBQUFBLEVBQ3ZCLENBQUNULFlBQVlVLFNBQVMsR0FBRztBQUFBLEVBQ3pCLENBQUNWLFlBQVlXLFlBQVksR0FBRztBQUFBLEVBQzVCLENBQUNYLFlBQVlZLFdBQVcsR0FBRztBQUM3QjtBQUVPLGdCQUFTUSxhQUFhO0FBQUFDLEtBQUE7QUFDM0IsUUFBTUMsY0FBYy9CLGVBQWU7QUFDbkMsUUFBTSxFQUFFZ0MsU0FBUyxJQUFJekIsYUFBYTtBQUNsQyxRQUFNLENBQUMwQixpQkFBaUJDLGtCQUFrQixJQUFJckMsU0FBd0IsSUFBSTtBQUMxRSxRQUFNLENBQUNzQyxjQUFjQyxlQUFlLElBQUl2QyxTQUErQixJQUFJO0FBQzNFLFFBQU0sQ0FBQ3dDLGdCQUFnQkMsaUJBQWlCLElBQUl6QyxTQUFpQyxJQUFJO0FBQ2pGLFFBQU0sQ0FBQzBDLGVBQWVDLGdCQUFnQixJQUFJM0MsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzRDLFNBQVNDLFVBQVUsSUFBSTdDLFNBQStCLElBQUk7QUFDakUsUUFBTSxDQUFDOEMsT0FBT0MsUUFBUSxJQUFJL0MsU0FBd0IsSUFBSTtBQUN0RCxRQUFNLENBQUNnRCxpQkFBaUJDLGtCQUFrQixJQUFJakQsU0FBUyxLQUFLO0FBRTVELFFBQU1rRCxhQUFhakQsWUFBWTtBQUFBLElBQzdCa0QsWUFBWUEsQ0FBQ0MsWUFBb0JoRCxxQkFBcUJnRCxPQUFPO0FBQUEsSUFDN0RDLFdBQVdBLENBQUNDLFdBQVdQLFNBQVMsR0FBR1EsT0FBT0MsU0FBU0MsTUFBTSxXQUFXSCxPQUFPSSxLQUFLLEVBQUU7QUFBQSxFQUNwRixDQUFDO0FBRUQsUUFBTUMsY0FBY3pELFNBQVM7QUFBQSxJQUMzQjBELFVBQVUsQ0FBQyxVQUFVekIsUUFBUTtBQUFBLElBQzdCMEIsU0FBU0EsTUFBTXhELGtCQUFrQjhCLFFBQVE7QUFBQSxJQUN6QzJCLGlCQUFpQjtBQUFBLEVBQ25CLENBQUM7QUFFRCxRQUFNQyxzQkFBc0I3RCxTQUFTO0FBQUEsSUFDbkMwRCxVQUFVLENBQUMsWUFBWSxXQUFXekIsUUFBUTtBQUFBLElBQzFDMEIsU0FBU0EsTUFBTXRELGtCQUFrQjRCLFFBQVE7QUFBQSxFQUMzQyxDQUFDO0FBRUQsUUFBTTZCLGdCQUFnQjlELFNBQVM7QUFBQSxJQUM3QjBELFVBQVUsQ0FBQyxZQUFZekIsUUFBUTtBQUFBLElBQy9CMEIsU0FBU0EsTUFBTXJELG9CQUFvQjJCLFFBQVE7QUFBQSxJQUMzQzJCLGlCQUFpQjtBQUFBLEVBQ25CLENBQUM7QUFFRCxRQUFNRyxjQUFjL0QsU0FBUztBQUFBLElBQzNCMEQsVUFBVSxDQUFDLFVBQVUsUUFBUXpCLFFBQVE7QUFBQSxJQUNyQzBCLFNBQVNBLE1BQU12RCxzQkFBc0I2QixRQUFRO0FBQUEsSUFDN0MyQixpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTUksZUFBZW5FLFFBQVEsTUFBTTtBQUNqQyxVQUFNb0UsTUFBTSxvQkFBSUMsSUFBMkI7QUFDM0MsZUFBV0MsU0FBU0osWUFBWUssUUFBUTtBQUN0QyxVQUFJRCxNQUFNRSxrQkFBa0IsS0FBTUosS0FBSUssSUFBSUgsTUFBTUUsZUFBZUYsS0FBSztBQUN0RSxXQUFPRjtBQUFBQSxFQUNULEdBQUcsQ0FBQ0YsWUFBWUssSUFBSSxDQUFDO0FBRXJCLFFBQU1HLGlCQUFpQjFFLFFBQVEsTUFBTTtBQUNuQyxVQUFNb0UsTUFBTSxvQkFBSUMsSUFBMkI7QUFDM0MsZUFBV0MsU0FBU0osWUFBWUssUUFBUTtBQUN0QyxVQUFJRCxNQUFNSyxjQUFjLEtBQU1QLEtBQUlLLElBQUlILE1BQU1LLFdBQVdMLEtBQUs7QUFDOUQsV0FBT0Y7QUFBQUEsRUFDVCxHQUFHLENBQUNGLFlBQVlLLElBQUksQ0FBQztBQUVyQixRQUFNSyxtQkFBbUI1RTtBQUFBQSxJQUN2QixPQUNHaUUsY0FBY00sUUFBUSxJQUFJTTtBQUFBQSxNQUFPLENBQUNDLE1BQ2pDbkMsY0FBY29DLEtBQUssTUFBTSxLQUFLLE9BQU9ELEVBQUVFLEtBQUtDLFNBQVN0QyxjQUFjb0MsS0FBSyxDQUFDO0FBQUEsSUFDM0U7QUFBQSxJQUNGLENBQUNkLGNBQWNNLE1BQU01QixhQUFhO0FBQUEsRUFDcEM7QUFFQSxRQUFNdUMsVUFBVUEsTUFBTTtBQUNwQixTQUFLL0MsWUFBWWdELGtCQUFrQixFQUFFdEIsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzNELFNBQUsxQixZQUFZZ0Qsa0JBQWtCLEVBQUV0QixVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDM0QsU0FBSzFCLFlBQVlnRCxrQkFBa0IsRUFBRXRCLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztBQUFBLEVBQy9EO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFVBQUssT0FBTyxFQUFFdUIsU0FBUyxRQUFRQyxVQUFVLE1BQU1DLFFBQVEsU0FBUyxHQUMvRDtBQUFBLDZCQUFDLGFBQVEsV0FBVSxRQUNqQjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFQyxZQUFZLFlBQVlDLEtBQUssSUFBSUMsY0FBYyxHQUFHLEdBQzdGO0FBQUEsaUNBQUMsUUFBRyxXQUFVLFdBQVUsT0FBTyxFQUFFQyxVQUFVLFNBQVMsR0FBRyxxQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sb0JBQW9CRCxVQUFVLFNBQVMsR0FBRywwREFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUEsVUFDM0IsdUJBQUMsWUFBTyxXQUFVLGFBQVksTUFBSyxVQUFTLFNBQVMsTUFBTXhDLG1CQUFtQixJQUFJLEdBQUcscUNBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTCxXQUFXVSxZQUFZVyxRQUFRLElBQUlxQixXQUFXO0FBQUEsY0FDOUMsU0FBUyxNQUFNO0FBQUU1Qyx5QkFBUyxJQUFJO0FBQUdGLDJCQUFXYyxZQUFZVyxPQUFPLENBQUMsS0FBSyxJQUFJO0FBQUEsY0FBRztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSmhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBRUNYLFlBQVlpQyxhQUFhLHVCQUFDLE9BQUUsT0FBTyxFQUFFRixPQUFPLGlCQUFpQixHQUFHLGlDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdEO0FBQUEsUUFDakYvQixZQUFZa0MsV0FBVyx1QkFBQyxjQUFXLE9BQU9sQyxZQUFZbUMsT0FBTyxNQUFLLGNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUM1RTdCLFlBQVk0QixXQUFXLHVCQUFDLGNBQVcsT0FBTzVCLFlBQVk2QixPQUFPLE1BQUssd0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxRQUV2Rix1QkFBQyxTQUFJLFdBQVUsY0FDWG5DLHVCQUFZVyxRQUFRLElBQUlILElBQUksQ0FBQzRCLFVBQVU7QUFDdkMsZ0JBQU0xQixRQUFRSCxhQUFhOEIsSUFBSUQsTUFBTUUsRUFBRTtBQUN2QyxnQkFBTVAsUUFBUXZFLFlBQVk0RSxNQUFNRyxhQUFhLEtBQUs7QUFDbEQsaUJBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLE9BQU8sRUFBRSxZQUFZUixNQUFNO0FBQUEsY0FDM0IsU0FBUyxNQUFNO0FBQ2Isb0JBQUlyQixNQUFPaEMsb0JBQW1CZ0MsTUFBTTRCLEVBQUU7QUFBQSx5QkFDN0JGLE1BQU1HLGtCQUFrQnRGLFlBQVlRLE1BQU9tQixpQkFBZ0J3RCxLQUFLO0FBQUEsY0FDM0U7QUFBQSxjQUVBO0FBQUEsdUNBQUMsU0FBSSxPQUFPLEVBQUVJLFNBQVMsUUFBUUMsZ0JBQWdCLGdCQUFnQixHQUM3RDtBQUFBLHlDQUFDLFVBQUssV0FBVSxnQkFBZ0JMLGdCQUFNTSxVQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUM3Qyx1QkFBQyxVQUFLLFdBQVUsUUFBTyxPQUFPLEVBQUUsU0FBU1gsTUFBTSxHQUM1QzNELHNCQUFZZ0UsTUFBTUcsYUFBYSxLQUFLLE9BRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVSLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FDeERwQixrQkFDQyx1QkFBQyxVQUFLLFdBQVUsWUFDYkE7QUFBQUEsd0JBQU1pQyxNQUFNWDtBQUFBQSxrQkFBTztBQUFBLGtCQUFVOUUsVUFBVXdELE1BQU1rQyxXQUFXO0FBQUEscUJBRDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsSUFFQSx1QkFBQyxVQUFNUjtBQUFBQSx3QkFBTVMsWUFBWTtBQUFBLGtCQUFJO0FBQUEscUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDLEtBTnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQTtBQUFBO0FBQUEsWUF2QktULE1BQU1FO0FBQUFBLFlBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXlCQTtBQUFBLFFBRUosQ0FBQyxLQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsV0EzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTREQTtBQUFBLE1BRUEsdUJBQUMsYUFBUSxXQUFVLGVBQWMsT0FBTyxFQUFFUSxXQUFXLEdBQUcsR0FDdEQ7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRU4sU0FBUyxRQUFRYixZQUFZLFlBQVlDLEtBQUssSUFBSUMsY0FBYyxJQUFJa0IsVUFBVSxPQUFPLEdBQ2pHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLFdBQVUsT0FBTyxFQUFFakIsVUFBVSxTQUFTLEdBQUcsd0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsVUFDL0QsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sb0JBQW9CRCxVQUFVLFNBQVMsR0FBRyx3RUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVrQixNQUFNLEVBQUUsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUI7QUFBQSxVQUN4QjVDLG9CQUFvQk8sUUFDbkIsdUJBQUMsVUFBSyxXQUFVLFFBQU8sT0FBTyxFQUFFLFNBQVMsY0FBYyxHQUFvQjtBQUFBO0FBQUEsWUFDakV6RCxVQUFVa0Qsb0JBQW9CTyxLQUFLc0Msa0JBQWtCO0FBQUEsZUFEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWLE9BQU9sRTtBQUFBQSxjQUNQLFVBQVUsQ0FBQ21FLE1BQU1sRSxpQkFBaUJrRSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsY0FDaEQsT0FBTyxFQUFFQyxPQUFPLElBQUk7QUFBQTtBQUFBLFlBTHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUt3QjtBQUFBLGFBaEIxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsUUFFQ2hELGNBQWM2QixXQUNiLHVCQUFDLGNBQVcsT0FBTzdCLGNBQWM4QixPQUFPLE1BQUssaUJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQSxRQUc1RDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTztBQUFBLGNBQ0xLLFNBQVM7QUFBQSxjQUNUYyxxQkFBcUI7QUFBQSxjQUNyQjFCLEtBQUs7QUFBQSxZQUNQO0FBQUEsWUFFQ1osMkJBQWlCUixJQUFJLENBQUMrQyxZQUFZO0FBQ2pDLG9CQUFNN0MsUUFBUUksZUFBZXVCLElBQUlrQixRQUFRakIsRUFBRTtBQUMzQyxvQkFBTVAsUUFBUWpFLGFBQWF5RixRQUFRQyxlQUFlLEtBQUs7QUFDdkQsb0JBQU1DLE9BQU9GLFFBQVFDLG9CQUFvQnhHLGNBQWNnQjtBQUN2RCxxQkFDRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNO0FBQ2Isd0JBQUkwQyxNQUFPaEMsb0JBQW1CZ0MsTUFBTTRCLEVBQUU7QUFBQSw2QkFDN0JpQixRQUFRQyxvQkFBb0J4RyxjQUFjZTtBQUNqRGUsd0NBQWtCeUUsT0FBTztBQUFBLGtCQUM3QjtBQUFBLGtCQUNBLE9BQU83QyxRQUFRLEdBQUdBLE1BQU1pQyxNQUFNWCxNQUFNLFlBQVk5RSxVQUFVd0QsTUFBTWtDLFdBQVcsQ0FBQyxLQUFLYztBQUFBQSxrQkFDakYsT0FBTztBQUFBLG9CQUNMQyxZQUFZRixPQUFPLG9CQUFvQjtBQUFBLG9CQUN2Q0csUUFBUSxhQUFhSCxPQUFPMUIsUUFBUSxhQUFhO0FBQUEsb0JBQ2pEOEIsY0FBYztBQUFBLG9CQUNkQyxXQUFXO0FBQUEsb0JBQ1h0QixTQUFTO0FBQUEsb0JBQ1RaLEtBQUs7QUFBQSxvQkFDTG1DLFlBQVk7QUFBQSxvQkFDWnZDLFNBQVM7QUFBQSxrQkFDWDtBQUFBLGtCQUVBO0FBQUEsMkNBQUMsVUFBSyxXQUFVLG9CQUFtQixPQUFPLEVBQUVNLFVBQVUsVUFBVUMsT0FBTzBCLE9BQU8xQixRQUFRLGFBQWEsR0FDaEd3QixrQkFBUW5DLFFBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNDVixRQUNDLHVCQUFDLFVBQUssV0FBVSxZQUFXLE9BQU8sRUFBRW9CLFVBQVUsV0FBV0MsT0FBTyxpQkFBaUIsR0FDOUU3RSxvQkFBVXdELE1BQU1rQyxXQUFXLEtBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUEsSUFFQSx1QkFBQyxVQUFLLE9BQU8sRUFBRWQsVUFBVSxXQUFXQyxPQUFPaUMsZUFBZSxhQUFhQyxlQUFlLFNBQVMsR0FDNUY5Riw2QkFBbUJvRixRQUFRQyxlQUFlLEtBQUssTUFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUE7QUFBQSxnQkE3QkdELFFBQVFqQjtBQUFBQSxnQkFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZ0NBO0FBQUEsWUFFSixDQUFDO0FBQUE7QUFBQSxVQTlDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUErQ0E7QUFBQSxXQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUVBO0FBQUEsU0F4SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlJQTtBQUFBLElBRUN6RCxrQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBU0E7QUFBQUEsUUFDVCxTQUFTLE1BQU1DLGtCQUFrQixJQUFJO0FBQUEsUUFDckMsVUFBVSxDQUFDb0YsWUFBWTtBQUNyQnBGLDRCQUFrQixJQUFJO0FBQ3RCd0Msa0JBQVE7QUFDUjVDLDZCQUFtQndGLE9BQU87QUFBQSxRQUM1QjtBQUFBO0FBQUEsTUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPSTtBQUFBLElBSUx2RixnQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBT0E7QUFBQUEsUUFDUCxTQUFTLE1BQU1DLGdCQUFnQixJQUFJO0FBQUEsUUFDbkMsVUFBVSxDQUFDc0YsWUFBWTtBQUNyQnRGLDBCQUFnQixJQUFJO0FBQ3BCMEMsa0JBQVE7QUFDUjVDLDZCQUFtQndGLE9BQU87QUFBQSxRQUM1QjtBQUFBO0FBQUEsTUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPSTtBQUFBLElBSUx6RixvQkFBb0IsUUFDbkI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVNBO0FBQUFBLFFBQ1QsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixJQUFJO0FBQ3ZCNEMsa0JBQVE7QUFBQSxRQUNWO0FBQUE7QUFBQSxNQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtJO0FBQUEsSUFJTGpDLG1CQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFDdkMsVUFBVSxDQUFDNEUsWUFBWTtBQUNyQjVFLDZCQUFtQixLQUFLO0FBQ3hCZ0Msa0JBQVE7QUFDUjVDLDZCQUFtQndGLE9BQU87QUFBQSxRQUM1QjtBQUFBO0FBQUEsTUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNSTtBQUFBLElBSUxqRixXQUNDLHVCQUFDLFdBQVEsT0FBTSw4QkFBNkIsU0FBUyxNQUFNQyxXQUFXLElBQUksR0FDeEU7QUFBQSw2QkFBQyxXQUFNLE9BQU8sRUFBRXNELFNBQVMsUUFBUVosS0FBSyxFQUFFLEdBQ3RDO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVHLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBRyxvQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQ25FO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPN0MsUUFBUXFEO0FBQUFBLFlBQ2YsVUFBVSxDQUFDWSxNQUFNO0FBQ2Ysb0JBQU1kLFNBQVNwQyxZQUFZVyxRQUFRLElBQUl3RCxLQUFLLENBQUNDLE1BQU1BLEVBQUU5QixPQUFPK0IsT0FBT25CLEVBQUVDLE9BQU9DLEtBQUssQ0FBQyxLQUFLO0FBQ3ZGbEUseUJBQVdrRCxLQUFLO0FBQ2hCaEQsdUJBQVMsSUFBSTtBQUFBLFlBQ2Y7QUFBQSxZQUVFWSx1QkFBWVcsUUFBUSxJQUFJSDtBQUFBQSxjQUFJLENBQUM0RCxNQUM3Qix1QkFBQyxZQUFrQixPQUFPQSxFQUFFOUIsSUFBSTtBQUFBO0FBQUEsZ0JBQU04QixFQUFFMUI7QUFBQUEsbUJBQTNCMEIsRUFBRTlCLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxZQUNoRDtBQUFBO0FBQUEsVUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQy9DLFdBQVcyQyxXQUNWLHVCQUFDLE9BQUUsV0FBVSxjQUFhLG1JQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUdEL0MsUUFDQyx1QkFBQyxTQUFJLE9BQU8sRUFBRXFELFNBQVMsUUFBUVosS0FBSyxJQUFJMEMsY0FBYyxTQUFTLEdBQzdEO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEtBQUssaUVBQWlFQyxtQkFBbUJwRixLQUFLLENBQUM7QUFBQSxZQUMvRixLQUFLLHNDQUFzQ0YsUUFBUXlELE1BQU07QUFBQSxZQUN6RCxPQUFPO0FBQUEsWUFDUCxRQUFRO0FBQUEsWUFDUixPQUFPLEVBQUVtQixjQUFjLEdBQUdGLFlBQVksT0FBTztBQUFBO0FBQUEsVUFML0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS2lEO0FBQUEsUUFFakQsdUJBQUMsV0FBTSxVQUFRLE1BQUMsT0FBT3hFLE9BQU8sU0FBUyxDQUFDK0QsTUFBTUEsRUFBRUMsT0FBT3FCLE9BQU8sR0FBRyxPQUFPLEVBQUVuQixPQUFPLE9BQU8sS0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRjtBQUFBLFdBUjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQSxJQUVBLHVCQUFDLFlBQU8sV0FBVSxlQUFjLE1BQUssVUFBUyxVQUFVOUQsV0FBV2tGLFdBQVcsU0FBUyxNQUFNbEYsV0FBV21GLE9BQU96RixRQUFRcUQsRUFBRSxHQUN0SC9DLHFCQUFXa0YsWUFBWSxhQUFhLG1CQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0NBO0FBQUEsT0FsT0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9PQTtBQUVKO0FBQUNuRyxHQTFTZUQsWUFBVTtBQUFBLFVBQ0o3QixnQkFDQ08sY0FTRlQsYUFLQ0MsVUFNUUEsVUFLTkEsVUFNRkEsUUFBUTtBQUFBO0FBQUEsS0FqQ2Q4QjtBQUFVLElBQUFzRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJnZW5lcmF0ZVRhYmxlUXJUb2tlbiIsImdldFRhYmxlc0J5QnJhbmNoIiwiZ2V0T3Blbk9yZGVyc0J5QnJhbmNoIiwiZ2V0Q29tYW5kYVNldHRpbmciLCJnZXRDb21hbmRhc0J5QnJhbmNoIiwiT3BlbkNvbWFuZGFEaWFsb2ciLCJ1c2VBdXRoU3RvcmUiLCJDb21hbmRhU3RhdHVzIiwiVGFibGVTdGF0dXMiLCJmb3JtYXRCUkwiLCJPcmRlckRyYXdlciIsIk9wZW5PcmRlckRpYWxvZyIsIk9wZW5EZWxpdmVyeU9yZGVyRGlhbG9nIiwiUXVlcnlFcnJvciIsIk92ZXJsYXkiLCJzdGF0dXNDb2xvciIsIkxpdnJlIiwiT2N1cGFkYSIsIlJlc2VydmFkYSIsIkVtRmVjaGFtZW50byIsIkludGVyZGl0YWRhIiwiY29tYW5kYUNvbG9yIiwiRGlzcG9uaXZlbCIsIkVtVXNvIiwiRXh0cmF2aWFkYSIsIkJsb3F1ZWFkYSIsImNvbWFuZGFTdGF0dXNMYWJlbCIsInN0YXR1c0xhYmVsIiwiT3JkZXJzUGFnZSIsIl9zIiwicXVlcnlDbGllbnQiLCJicmFuY2hJZCIsInNlbGVjdGVkT3JkZXJJZCIsInNldFNlbGVjdGVkT3JkZXJJZCIsIm9wZW5pbmdUYWJsZSIsInNldE9wZW5pbmdUYWJsZSIsIm9wZW5pbmdDb21hbmRhIiwic2V0T3BlbmluZ0NvbWFuZGEiLCJjb21hbmRhU2VhcmNoIiwic2V0Q29tYW5kYVNlYXJjaCIsInFyVGFibGUiLCJzZXRRclRhYmxlIiwicXJVcmwiLCJzZXRRclVybCIsIm9wZW5pbmdEZWxpdmVyeSIsInNldE9wZW5pbmdEZWxpdmVyeSIsInFyTXV0YXRpb24iLCJtdXRhdGlvbkZuIiwidGFibGVJZCIsIm9uU3VjY2VzcyIsInJlc3VsdCIsIndpbmRvdyIsImxvY2F0aW9uIiwib3JpZ2luIiwidG9rZW4iLCJ0YWJsZXNRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInJlZmV0Y2hJbnRlcnZhbCIsImNvbWFuZGFTZXR0aW5nUXVlcnkiLCJjb21hbmRhc1F1ZXJ5Iiwib3JkZXJzUXVlcnkiLCJvcmRlckJ5VGFibGUiLCJtYXAiLCJNYXAiLCJvcmRlciIsImRhdGEiLCJkaW5pbmdUYWJsZUlkIiwic2V0Iiwib3JkZXJCeUNvbWFuZGEiLCJjb21hbmRhSWQiLCJmaWx0ZXJlZENvbWFuZGFzIiwiZmlsdGVyIiwiYyIsInRyaW0iLCJjb2RlIiwiaW5jbHVkZXMiLCJyZWZyZXNoIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJhbGlnbkl0ZW1zIiwiZ2FwIiwibWFyZ2luQm90dG9tIiwiZm9udFNpemUiLCJjb2xvciIsImxlbmd0aCIsImlzTG9hZGluZyIsImlzRXJyb3IiLCJlcnJvciIsInRhYmxlIiwiZ2V0IiwiaWQiLCJ0YWJsZVN0YXR1c0lkIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwibnVtYmVyIiwiaXRlbXMiLCJ0b3RhbEFtb3VudCIsImNhcGFjaXR5IiwibWFyZ2luVG9wIiwiZmxleFdyYXAiLCJmbGV4IiwiZGVmYXVsdExpbWl0QW1vdW50IiwiZSIsInRhcmdldCIsInZhbHVlIiwid2lkdGgiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwiY29tYW5kYSIsImNvbWFuZGFTdGF0dXNJZCIsImJ1c3kiLCJ1bmRlZmluZWQiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwibWluSGVpZ2h0IiwicGxhY2VJdGVtcyIsInRleHRUcmFuc2Zvcm0iLCJsZXR0ZXJTcGFjaW5nIiwib3JkZXJJZCIsImZpbmQiLCJ0IiwiTnVtYmVyIiwianVzdGlmeUl0ZW1zIiwiZW5jb2RlVVJJQ29tcG9uZW50Iiwic2VsZWN0IiwiaXNQZW5kaW5nIiwibXV0YXRlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT3JkZXJzUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUsIHR5cGUgQ1NTUHJvcGVydGllcyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyBnZW5lcmF0ZVRhYmxlUXJUb2tlbiwgZ2V0VGFibGVzQnlCcmFuY2ggfSBmcm9tIFwiLi4vdGFibGVzL2FwaVwiO1xyXG5pbXBvcnQgeyBnZXRPcGVuT3JkZXJzQnlCcmFuY2ggfSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgZ2V0Q29tYW5kYVNldHRpbmcsIGdldENvbWFuZGFzQnlCcmFuY2ggfSBmcm9tIFwiLi4vY29tYW5kYXMvYXBpXCI7XHJcbmltcG9ydCB7IE9wZW5Db21hbmRhRGlhbG9nIH0gZnJvbSBcIi4uL2NvbWFuZGFzL09wZW5Db21hbmRhRGlhbG9nXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IENvbWFuZGFTdGF0dXMsIFRhYmxlU3RhdHVzLCBmb3JtYXRCUkwgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB0eXBlIHsgQ29tYW5kYVJlc3BvbnNlLCBPcmRlclJlc3BvbnNlLCBUYWJsZVJlc3BvbnNlIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgeyBPcmRlckRyYXdlciB9IGZyb20gXCIuL09yZGVyRHJhd2VyXCI7XHJcbmltcG9ydCB7IE9wZW5PcmRlckRpYWxvZyB9IGZyb20gXCIuL09wZW5PcmRlckRpYWxvZ1wiO1xyXG5pbXBvcnQgeyBPcGVuRGVsaXZlcnlPcmRlckRpYWxvZyB9IGZyb20gXCIuL09wZW5EZWxpdmVyeU9yZGVyRGlhbG9nXCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcbmltcG9ydCB7IE92ZXJsYXkgfSBmcm9tIFwiLi9PdmVybGF5XCI7XHJcblxyXG5jb25zdCBzdGF0dXNDb2xvcjogUmVjb3JkPG51bWJlciwgc3RyaW5nPiA9IHtcclxuICBbVGFibGVTdGF0dXMuTGl2cmVdOiBcInZhcigtLWZyZWUpXCIsXHJcbiAgW1RhYmxlU3RhdHVzLk9jdXBhZGFdOiBcInZhcigtLWJ1c3kpXCIsXHJcbiAgW1RhYmxlU3RhdHVzLlJlc2VydmFkYV06IFwidmFyKC0tcmVzZXJ2ZWQpXCIsXHJcbiAgW1RhYmxlU3RhdHVzLkVtRmVjaGFtZW50b106IFwidmFyKC0tY2xvc2luZylcIixcclxuICBbVGFibGVTdGF0dXMuSW50ZXJkaXRhZGFdOiBcInZhcigtLWJsb2NrZWQpXCIsXHJcbn07XHJcblxyXG5jb25zdCBjb21hbmRhQ29sb3I6IFJlY29yZDxudW1iZXIsIHN0cmluZz4gPSB7XHJcbiAgW0NvbWFuZGFTdGF0dXMuRGlzcG9uaXZlbF06IFwidmFyKC0tZnJlZSlcIixcclxuICBbQ29tYW5kYVN0YXR1cy5FbVVzb106IFwidmFyKC0tYnVzeSlcIixcclxuICBbQ29tYW5kYVN0YXR1cy5FeHRyYXZpYWRhXTogXCJ2YXIoLS1jbG9zaW5nKVwiLFxyXG4gIFtDb21hbmRhU3RhdHVzLkJsb3F1ZWFkYV06IFwidmFyKC0tYmxvY2tlZClcIixcclxufTtcclxuXHJcbmNvbnN0IGNvbWFuZGFTdGF0dXNMYWJlbDogUmVjb3JkPG51bWJlciwgc3RyaW5nPiA9IHtcclxuICBbQ29tYW5kYVN0YXR1cy5EaXNwb25pdmVsXTogXCJMaXZyZVwiLFxyXG4gIFtDb21hbmRhU3RhdHVzLkVtVXNvXTogXCJFbSB1c29cIixcclxuICBbQ29tYW5kYVN0YXR1cy5FeHRyYXZpYWRhXTogXCJFeHRyYXZpYWRhXCIsXHJcbiAgW0NvbWFuZGFTdGF0dXMuQmxvcXVlYWRhXTogXCJCbG9xdWVhZGFcIixcclxufTtcclxuXHJcbmNvbnN0IHN0YXR1c0xhYmVsOiBSZWNvcmQ8bnVtYmVyLCBzdHJpbmc+ID0ge1xyXG4gIFtUYWJsZVN0YXR1cy5MaXZyZV06IFwiTGl2cmVcIixcclxuICBbVGFibGVTdGF0dXMuT2N1cGFkYV06IFwiT2N1cGFkYVwiLFxyXG4gIFtUYWJsZVN0YXR1cy5SZXNlcnZhZGFdOiBcIlJlc2VydmFkYVwiLFxyXG4gIFtUYWJsZVN0YXR1cy5FbUZlY2hhbWVudG9dOiBcIkZlY2hhbmRvXCIsXHJcbiAgW1RhYmxlU3RhdHVzLkludGVyZGl0YWRhXTogXCJJbnRlcmRpdGFkYVwiLFxyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyc1BhZ2UoKSB7XHJcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgYnJhbmNoSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZE9yZGVySWQsIHNldFNlbGVjdGVkT3JkZXJJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbb3BlbmluZ1RhYmxlLCBzZXRPcGVuaW5nVGFibGVdID0gdXNlU3RhdGU8VGFibGVSZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtvcGVuaW5nQ29tYW5kYSwgc2V0T3BlbmluZ0NvbWFuZGFdID0gdXNlU3RhdGU8Q29tYW5kYVJlc3BvbnNlIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2NvbWFuZGFTZWFyY2gsIHNldENvbWFuZGFTZWFyY2hdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3FyVGFibGUsIHNldFFyVGFibGVdID0gdXNlU3RhdGU8VGFibGVSZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtxclVybCwgc2V0UXJVcmxdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW29wZW5pbmdEZWxpdmVyeSwgc2V0T3BlbmluZ0RlbGl2ZXJ5XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgcXJNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICh0YWJsZUlkOiBudW1iZXIpID0+IGdlbmVyYXRlVGFibGVRclRva2VuKHRhYmxlSWQpLFxyXG4gICAgb25TdWNjZXNzOiAocmVzdWx0KSA9PiBzZXRRclVybChgJHt3aW5kb3cubG9jYXRpb24ub3JpZ2lufS9wZWRpZG8vJHtyZXN1bHQudG9rZW59YCksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHRhYmxlc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcInRhYmxlc1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRUYWJsZXNCeUJyYW5jaChicmFuY2hJZCksXHJcbiAgICByZWZldGNoSW50ZXJ2YWw6IDE1XzAwMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgY29tYW5kYVNldHRpbmdRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJjb21hbmRhc1wiLCBcInNldHRpbmdcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0Q29tYW5kYVNldHRpbmcoYnJhbmNoSWQpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjb21hbmRhc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImNvbWFuZGFzXCIsIGJyYW5jaElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldENvbWFuZGFzQnlCcmFuY2goYnJhbmNoSWQpLFxyXG4gICAgcmVmZXRjaEludGVydmFsOiAxNV8wMDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IG9yZGVyc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcIm9yZGVyc1wiLCBcIm9wZW5cIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0T3Blbk9yZGVyc0J5QnJhbmNoKGJyYW5jaElkKSxcclxuICAgIHJlZmV0Y2hJbnRlcnZhbDogMTVfMDAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBvcmRlckJ5VGFibGUgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBPcmRlclJlc3BvbnNlPigpO1xyXG4gICAgZm9yIChjb25zdCBvcmRlciBvZiBvcmRlcnNRdWVyeS5kYXRhID8/IFtdKVxyXG4gICAgICBpZiAob3JkZXIuZGluaW5nVGFibGVJZCAhPT0gbnVsbCkgbWFwLnNldChvcmRlci5kaW5pbmdUYWJsZUlkLCBvcmRlcik7XHJcbiAgICByZXR1cm4gbWFwO1xyXG4gIH0sIFtvcmRlcnNRdWVyeS5kYXRhXSk7XHJcblxyXG4gIGNvbnN0IG9yZGVyQnlDb21hbmRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwPG51bWJlciwgT3JkZXJSZXNwb25zZT4oKTtcclxuICAgIGZvciAoY29uc3Qgb3JkZXIgb2Ygb3JkZXJzUXVlcnkuZGF0YSA/PyBbXSlcclxuICAgICAgaWYgKG9yZGVyLmNvbWFuZGFJZCAhPT0gbnVsbCkgbWFwLnNldChvcmRlci5jb21hbmRhSWQsIG9yZGVyKTtcclxuICAgIHJldHVybiBtYXA7XHJcbiAgfSwgW29yZGVyc1F1ZXJ5LmRhdGFdKTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRDb21hbmRhcyA9IHVzZU1lbW8oXHJcbiAgICAoKSA9PlxyXG4gICAgICAoY29tYW5kYXNRdWVyeS5kYXRhID8/IFtdKS5maWx0ZXIoKGMpID0+XHJcbiAgICAgICAgY29tYW5kYVNlYXJjaC50cmltKCkgPT09IFwiXCIgPyB0cnVlIDogYy5jb2RlLmluY2x1ZGVzKGNvbWFuZGFTZWFyY2gudHJpbSgpKSxcclxuICAgICAgKSxcclxuICAgIFtjb21hbmRhc1F1ZXJ5LmRhdGEsIGNvbWFuZGFTZWFyY2hdLFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHJlZnJlc2ggPSAoKSA9PiB7XHJcbiAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcInRhYmxlc1wiXSB9KTtcclxuICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wib3JkZXJzXCJdIH0pO1xyXG4gICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJjb21hbmRhc1wiXSB9KTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogXCIyMnB4XCIsIG1heFdpZHRoOiAxMjQwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicmlzZVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiBcImJhc2VsaW5lXCIsIGdhcDogMTQsIG1hcmdpbkJvdHRvbTogMTQgfX0+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS43cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgTWVzYXNcclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5cclxuICAgICAgICAgICAgICB0b3F1ZSBudW1hIG1lc2EgbGl2cmUgcGFyYSBhYnJpciB1bSBwZWRpZG9cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1aS1zcGFjZXJcIiAvPlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuaW5nRGVsaXZlcnkodHJ1ZSl9PlxyXG4gICAgICAgICAgICAgICsgUmV0aXJhZGEgLyBEZWxpdmVyeVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9eyh0YWJsZXNRdWVyeS5kYXRhID8/IFtdKS5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRRclVybChudWxsKTsgc2V0UXJUYWJsZSh0YWJsZXNRdWVyeS5kYXRhPy5bMF0gPz8gbnVsbCk7IH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBHZXJhciBRUiBkZSBhdXRvYXRlbmRpbWVudG9cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7dGFibGVzUXVlcnkuaXNMb2FkaW5nICYmIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+Q2FycmVnYW5kbyBtZXNhc+KApjwvcD59XHJcbiAgICAgICAgICB7dGFibGVzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17dGFibGVzUXVlcnkuZXJyb3J9IHdoYXQ9XCJhcyBtZXNhc1wiIC8+fVxyXG4gICAgICAgICAge29yZGVyc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e29yZGVyc1F1ZXJ5LmVycm9yfSB3aGF0PVwib3MgcGVkaWRvcyBhYmVydG9zXCIgLz59XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YWJsZS1ncmlkXCI+XHJcbiAgICAgICAgICAgIHsodGFibGVzUXVlcnkuZGF0YSA/PyBbXSkubWFwKCh0YWJsZSkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IG9yZGVyID0gb3JkZXJCeVRhYmxlLmdldCh0YWJsZS5pZCk7XHJcbiAgICAgICAgICAgICAgY29uc3QgY29sb3IgPSBzdGF0dXNDb2xvclt0YWJsZS50YWJsZVN0YXR1c0lkXSA/PyBcInZhcigtLWluay1mYWludClcIjtcclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBrZXk9e3RhYmxlLmlkfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0YWJsZS10aWxlXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IFwiLS1zdGF0dXNcIjogY29sb3IgfSBhcyBDU1NQcm9wZXJ0aWVzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9yZGVyKSBzZXRTZWxlY3RlZE9yZGVySWQob3JkZXIuaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHRhYmxlLnRhYmxlU3RhdHVzSWQgPT09IFRhYmxlU3RhdHVzLkxpdnJlKSBzZXRPcGVuaW5nVGFibGUodGFibGUpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibnVtIG1vbm8tbnVtXCI+e3RhYmxlLm51bWJlcn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2hpcFwiIHN0eWxlPXt7IFwiLS1kb3RcIjogY29sb3IgfSBhcyBDU1NQcm9wZXJ0aWVzfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzdGF0dXNMYWJlbFt0YWJsZS50YWJsZVN0YXR1c0lkXSA/PyBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44OHJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHtvcmRlciA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtvcmRlci5pdGVtcy5sZW5ndGh9IGl0ZW5zIMK3IHtmb3JtYXRCUkwob3JkZXIudG90YWxBbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dGFibGUuY2FwYWNpdHkgPz8gXCLigJRcIn0gbHVnYXJlczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMlwiIHN0eWxlPXt7IG1hcmdpblRvcDogMzQgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImJhc2VsaW5lXCIsIGdhcDogMTQsIG1hcmdpbkJvdHRvbTogMTQsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjdyZW1cIiB9fT5Db21hbmRhczwvaDI+XHJcbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgdG9xdWUgbnVtYSBjb21hbmRhIGxpdnJlIHBhcmEgYWJyaXIgdW1hIGNvbnRhIGluZGl2aWR1YWxcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxIH19IC8+XHJcbiAgICAgICAgICAgIHtjb21hbmRhU2V0dGluZ1F1ZXJ5LmRhdGEgJiYgKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNoaXBcIiBzdHlsZT17eyBcIi0tZG90XCI6IFwidmFyKC0tYnVzeSlcIiB9IGFzIENTU1Byb3BlcnRpZXN9PlxyXG4gICAgICAgICAgICAgICAgbGltaXRlIHtmb3JtYXRCUkwoY29tYW5kYVNldHRpbmdRdWVyeS5kYXRhLmRlZmF1bHRMaW1pdEFtb3VudCl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIm7CuuKAplwiXHJcbiAgICAgICAgICAgICAgaW5wdXRNb2RlPVwibnVtZXJpY1wiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvbWFuZGFTZWFyY2h9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb21hbmRhU2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMTEwIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7Y29tYW5kYXNRdWVyeS5pc0Vycm9yICYmIChcclxuICAgICAgICAgICAgPFF1ZXJ5RXJyb3IgZXJyb3I9e2NvbWFuZGFzUXVlcnkuZXJyb3J9IHdoYXQ9XCJhcyBjb21hbmRhc1wiIC8+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICBkaXNwbGF5OiBcImdyaWRcIixcclxuICAgICAgICAgICAgICBncmlkVGVtcGxhdGVDb2x1bW5zOiBcInJlcGVhdChhdXRvLWZpbGwsIG1pbm1heCg3NnB4LCAxZnIpKVwiLFxyXG4gICAgICAgICAgICAgIGdhcDogOCxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2ZpbHRlcmVkQ29tYW5kYXMubWFwKChjb21hbmRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3Qgb3JkZXIgPSBvcmRlckJ5Q29tYW5kYS5nZXQoY29tYW5kYS5pZCk7XHJcbiAgICAgICAgICAgICAgY29uc3QgY29sb3IgPSBjb21hbmRhQ29sb3JbY29tYW5kYS5jb21hbmRhU3RhdHVzSWRdID8/IFwidmFyKC0taW5rLWZhaW50KVwiO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGJ1c3kgPSBjb21hbmRhLmNvbWFuZGFTdGF0dXNJZCA9PT0gQ29tYW5kYVN0YXR1cy5FbVVzbztcclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBrZXk9e2NvbWFuZGEuaWR9XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9yZGVyKSBzZXRTZWxlY3RlZE9yZGVySWQob3JkZXIuaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGNvbWFuZGEuY29tYW5kYVN0YXR1c0lkID09PSBDb21hbmRhU3RhdHVzLkRpc3Bvbml2ZWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRPcGVuaW5nQ29tYW5kYShjb21hbmRhKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgdGl0bGU9e29yZGVyID8gYCR7b3JkZXIuaXRlbXMubGVuZ3RofSBpdGVucyDCtyAke2Zvcm1hdEJSTChvcmRlci50b3RhbEFtb3VudCl9YCA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBidXN5ID8gXCJ2YXIoLS1iZy1wcmVzcylcIiA6IFwidmFyKC0tYmctcmFpc2UpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7YnVzeSA/IGNvbG9yIDogXCJ2YXIoLS1saW5lKVwifWAsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAxMCxcclxuICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHQ6IDY0LFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZ3JpZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGdhcDogMixcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZUl0ZW1zOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiOHB4IDRweFwiLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5IG1vbm8tbnVtXCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS41cmVtXCIsIGNvbG9yOiBidXN5ID8gY29sb3IgOiBcInZhcigtLWluaylcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7Y29tYW5kYS5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtvcmRlciA/IChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuNjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRCUkwob3JkZXIudG90YWxBbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjYycmVtXCIsIGNvbG9yLCB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDZlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2NvbWFuZGFTdGF0dXNMYWJlbFtjb21hbmRhLmNvbWFuZGFTdGF0dXNJZF0gPz8gXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgPC9tYWluPlxyXG5cclxuICAgICAge29wZW5pbmdDb21hbmRhICYmIChcclxuICAgICAgICA8T3BlbkNvbWFuZGFEaWFsb2dcclxuICAgICAgICAgIGNvbWFuZGE9e29wZW5pbmdDb21hbmRhfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0T3BlbmluZ0NvbWFuZGEobnVsbCl9XHJcbiAgICAgICAgICBvbk9wZW5lZD17KG9yZGVySWQpID0+IHtcclxuICAgICAgICAgICAgc2V0T3BlbmluZ0NvbWFuZGEobnVsbCk7XHJcbiAgICAgICAgICAgIHJlZnJlc2goKTtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRPcmRlcklkKG9yZGVySWQpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge29wZW5pbmdUYWJsZSAmJiAoXHJcbiAgICAgICAgPE9wZW5PcmRlckRpYWxvZ1xyXG4gICAgICAgICAgdGFibGU9e29wZW5pbmdUYWJsZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE9wZW5pbmdUYWJsZShudWxsKX1cclxuICAgICAgICAgIG9uT3BlbmVkPXsob3JkZXJJZCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRPcGVuaW5nVGFibGUobnVsbCk7XHJcbiAgICAgICAgICAgIHJlZnJlc2goKTtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRPcmRlcklkKG9yZGVySWQpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3NlbGVjdGVkT3JkZXJJZCAhPT0gbnVsbCAmJiAoXHJcbiAgICAgICAgPE9yZGVyRHJhd2VyXHJcbiAgICAgICAgICBvcmRlcklkPXtzZWxlY3RlZE9yZGVySWR9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNlbGVjdGVkT3JkZXJJZChudWxsKTtcclxuICAgICAgICAgICAgcmVmcmVzaCgpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge29wZW5pbmdEZWxpdmVyeSAmJiAoXHJcbiAgICAgICAgPE9wZW5EZWxpdmVyeU9yZGVyRGlhbG9nXHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuaW5nRGVsaXZlcnkoZmFsc2UpfVxyXG4gICAgICAgICAgb25PcGVuZWQ9eyhvcmRlcklkKSA9PiB7XHJcbiAgICAgICAgICAgIHNldE9wZW5pbmdEZWxpdmVyeShmYWxzZSk7XHJcbiAgICAgICAgICAgIHJlZnJlc2goKTtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRPcmRlcklkKG9yZGVySWQpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3FyVGFibGUgJiYgKFxyXG4gICAgICAgIDxPdmVybGF5IHRpdGxlPVwiUVIgQ29kZSBkZSBhdXRvYXRlbmRpbWVudG9cIiBvbkNsb3NlPXsoKSA9PiBzZXRRclRhYmxlKG51bGwpfT5cclxuICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+TWVzYTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgIHZhbHVlPXtxclRhYmxlLmlkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdGFibGUgPSAodGFibGVzUXVlcnkuZGF0YSA/PyBbXSkuZmluZCgodCkgPT4gdC5pZCA9PT0gTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSkgPz8gbnVsbDtcclxuICAgICAgICAgICAgICAgIHNldFFyVGFibGUodGFibGUpO1xyXG4gICAgICAgICAgICAgICAgc2V0UXJVcmwobnVsbCk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHsodGFibGVzUXVlcnkuZGF0YSA/PyBbXSkubWFwKCh0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dC5pZH0gdmFsdWU9e3QuaWR9Pk1lc2Ege3QubnVtYmVyfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAge3FyTXV0YXRpb24uaXNFcnJvciAmJiAoXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj5cclxuICAgICAgICAgICAgICBGYWxoYSBhbyBnZXJhciBvIFFSIENvZGUg4oCUIGNvbmZpcm1lIHF1ZSBleGlzdGUgdW0gZnVuY2lvbsOhcmlvIGNvbmZpZ3VyYWRvXHJcbiAgICAgICAgICAgICAgcGFyYSBhdXRvYXRlbmRpbWVudG8gZW0gQ29uZmlnLiDihpIgRmlsaWFsLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHtxclVybCA/IChcclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCwganVzdGlmeUl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgIHNyYz17YGh0dHBzOi8vYXBpLnFyc2VydmVyLmNvbS92MS9jcmVhdGUtcXItY29kZS8/c2l6ZT0yMjB4MjIwJmRhdGE9JHtlbmNvZGVVUklDb21wb25lbnQocXJVcmwpfWB9XHJcbiAgICAgICAgICAgICAgICBhbHQ9e2BRUiBDb2RlIGRlIGF1dG9hdGVuZGltZW50byBkYSBtZXNhICR7cXJUYWJsZS5udW1iZXJ9YH1cclxuICAgICAgICAgICAgICAgIHdpZHRoPXsyMjB9XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ9ezIyMH1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJvcmRlclJhZGl1czogOCwgYmFja2dyb3VuZDogXCIjZmZmXCIgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxpbnB1dCByZWFkT25seSB2YWx1ZT17cXJVcmx9IG9uRm9jdXM9eyhlKSA9PiBlLnRhcmdldC5zZWxlY3QoKX0gc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19IC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiIHR5cGU9XCJidXR0b25cIiBkaXNhYmxlZD17cXJNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHFyTXV0YXRpb24ubXV0YXRlKHFyVGFibGUuaWQpfT5cclxuICAgICAgICAgICAgICB7cXJNdXRhdGlvbi5pc1BlbmRpbmcgPyBcIkdlcmFuZG/igKZcIiA6IFwiR2VyYXIgUVIgQ29kZVwifVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9PdmVybGF5PlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvb3JkZXJzL09yZGVyc1BhZ2UudHN4In0=