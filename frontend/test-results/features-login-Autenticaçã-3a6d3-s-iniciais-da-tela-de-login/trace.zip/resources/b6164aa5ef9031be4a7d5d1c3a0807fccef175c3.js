import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/purchasing/PurchasingPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { useDialog } from "/src/ui/Dialog.tsx";
import {
  createSupplier,
  deactivateSupplier,
  getPurchasesByBranch,
  getSuppliersByCompany,
  registerPurchase
} from "/src/features/purchasing/api.ts";
import { getMenu } from "/src/features/catalog/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { formatBRL } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { Button } from "/src/ui/Button.tsx";
import { TextField, SelectField } from "/src/ui/Field.tsx";
import { useToast } from "/src/ui/Toast.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
const parseNum = (raw) => {
  if (raw.trim() === "") return 0;
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) ? value : 0;
};
export function PurchasingPage() {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const toast = useToast();
  const { branchId, companyId, employeeId } = useAuthStore();
  const [creatingSupplier, setCreatingSupplier] = useState(false);
  const [registeringPurchase, setRegisteringPurchase] = useState(false);
  const [error, setError] = useState(null);
  const [supplierForm, setSupplierForm] = useState({
    legalName: "",
    tradeName: "",
    cnpj: "",
    email: "",
    phone: ""
  });
  const [supplierId, setSupplierId] = useState("");
  const [documentNumber, setDocumentNumber] = useState("");
  const [purchasedAt, setPurchasedAt] = useState(() => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
  const [items, setItems] = useState([{ productId: 0, quantity: "1", unitCost: "0" }]);
  const suppliersQuery = useQuery({
    queryKey: ["suppliers", companyId],
    queryFn: () => getSuppliersByCompany(companyId ?? 1)
  });
  const purchasesQuery = useQuery({
    queryKey: ["purchases", branchId],
    queryFn: () => getPurchasesByBranch(branchId)
  });
  const menuQuery = useQuery({
    queryKey: ["menu", companyId],
    queryFn: () => getMenu(companyId ?? 1)
  });
  const productName = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const p of menuQuery.data ?? []) map.set(p.id, p.name);
    return map;
  }, [menuQuery.data]);
  const supplierName = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const s of suppliersQuery.data ?? []) map.set(s.id, s.tradeName ?? s.legalName);
    return map;
  }, [suppliersQuery.data]);
  const refreshSuppliers = () => void queryClient.invalidateQueries({ queryKey: ["suppliers"] });
  const refreshPurchases = () => void queryClient.invalidateQueries({ queryKey: ["purchases"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const createSupplierMutation = useMutation({
    mutationFn: () => createSupplier({
      companyId: companyId ?? 1,
      legalName: supplierForm.legalName.trim(),
      tradeName: supplierForm.tradeName.trim() === "" ? null : supplierForm.tradeName.trim(),
      cnpj: supplierForm.cnpj.trim() === "" ? null : supplierForm.cnpj.trim(),
      email: supplierForm.email.trim() === "" ? null : supplierForm.email.trim(),
      phone: supplierForm.phone.trim() === "" ? null : supplierForm.phone.trim()
    }),
    onSuccess: () => {
      setError(null);
      setCreatingSupplier(false);
      setSupplierForm({ legalName: "", tradeName: "", cnpj: "", email: "", phone: "" });
      refreshSuppliers();
      toast.success("Fornecedor criado.");
    },
    onError: onApiError
  });
  const deactivateSupplierMutation = useMutation({
    mutationFn: (id) => deactivateSupplier(id),
    onSuccess: () => {
      refreshSuppliers();
      toast.success("Fornecedor desativado.");
    },
    onError: onApiError
  });
  const validItems = items.filter((i) => i.productId > 0 && parseNum(i.quantity) > 0).map((i) => ({
    productId: i.productId,
    quantity: parseNum(i.quantity),
    unitCost: parseNum(i.unitCost)
  }));
  const purchaseTotal = validItems.reduce((sum, i) => sum + i.quantity * i.unitCost, 0);
  const registerPurchaseMutation = useMutation({
    mutationFn: () => registerPurchase({
      branchId,
      supplierId: Number(supplierId),
      employeeId: employeeId ?? 1,
      documentNumber: documentNumber.trim() === "" ? null : documentNumber.trim(),
      purchasedAt: new Date(purchasedAt).toISOString(),
      notes: null,
      items: validItems
    }),
    onSuccess: () => {
      setError(null);
      setRegisteringPurchase(false);
      setSupplierId("");
      setDocumentNumber("");
      setItems([{ productId: 0, quantity: "1", unitCost: "0" }]);
      refreshPurchases();
      toast.success("Compra registrada e estoque atualizado.");
    },
    onError: onApiError
  });
  const setItem = (index, patch) => setItems((current) => current.map((it, i) => i === index ? { ...it, ...patch } : it));
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto", position: "relative" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 6, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Fornecedores e Compras" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 176,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 177,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "btn-ghost", type: "button", onClick: () => {
        setError(null);
        setCreatingSupplier(true);
      }, children: "+ Fornecedor" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 178,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "button", onClick: () => {
        setError(null);
        setRegisteringPurchase(true);
      }, children: "+ Registrar compra" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 181,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
      lineNumber: 175,
      columnNumber: 13
    }, this),
    suppliersQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: suppliersQuery.error, what: "os fornecedores" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
      lineNumber: 186,
      columnNumber: 40
    }, this),
    purchasesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: purchasesQuery.error, what: "as compras" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
      lineNumber: 187,
      columnNumber: 40
    }, this),
    error && !creatingSupplier && !registeringPurchase && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
      lineNumber: 188,
      columnNumber: 68
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "rise rise-1", style: { marginTop: 18 }, children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "display", style: { fontSize: "1.15rem", marginBottom: 8 }, children: "Fornecedores" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 191,
        columnNumber: 17
      }, this),
      suppliersQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 3, rowHeight: 48 }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 192,
        columnNumber: 46
      }, this),
      !suppliersQuery.isLoading && (suppliersQuery.data ?? []).length === 0 && /* @__PURE__ */ jsxDEV(
        EmptyState,
        {
          icon: "🚚",
          title: "Nenhum fornecedor cadastrado",
          description: "Cadastre um fornecedor para poder registrar compras.",
          action: /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "button", onClick: () => {
            setError(null);
            setCreatingSupplier(true);
          }, children: "+ Fornecedor" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 199,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 194,
          columnNumber: 9
        },
        this
      ),
      !suppliersQuery.isLoading && (suppliersQuery.data ?? []).length > 0 && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: (suppliersQuery.data ?? []).map(
        (s) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: s.tradeName ?? s.legalName }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
              lineNumber: 210,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
              s.cnpj ?? "sem CNPJ",
              " ",
              s.phone ? `· ${s.phone}` : ""
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
              lineNumber: 211,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 209,
            columnNumber: 33
          }, this),
          s.isActive && /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "btn-danger",
              type: "button",
              style: { minHeight: 44, padding: "0 10px", fontSize: "0.85rem" },
              onClick: async () => {
                if (await dialog.confirm({ title: "Desativar fornecedor", message: `Desativar "${s.legalName}"?`, confirmLabel: "Desativar", danger: true }))
                  deactivateSupplierMutation.mutate(s.id);
              },
              children: "Desativar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
              lineNumber: 216,
              columnNumber: 13
            },
            this
          )
        ] }, s.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 208,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 206,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
      lineNumber: 190,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "rise rise-2", style: { marginTop: 26 }, children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "display", style: { fontSize: "1.15rem", marginBottom: 8 }, children: "Compras registradas" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 235,
        columnNumber: 17
      }, this),
      purchasesQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 3, rowHeight: 72 }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 236,
        columnNumber: 46
      }, this),
      !purchasesQuery.isLoading && (purchasesQuery.data ?? []).length === 0 && /* @__PURE__ */ jsxDEV(
        EmptyState,
        {
          icon: "🧾",
          title: "Nenhuma compra registrada",
          description: "Registre uma compra para dar entrada no estoque.",
          action: /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "button", onClick: () => {
            setError(null);
            setRegisteringPurchase(true);
          }, children: "+ Registrar compra" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 243,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 238,
          columnNumber: 9
        },
        this
      ),
      !purchasesQuery.isLoading && (purchasesQuery.data ?? []).length > 0 && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: (purchasesQuery.data ?? []).map(
        (p) => /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: [
            /* @__PURE__ */ jsxDEV("span", { children: supplierName.get(p.supplierId) ?? `Fornecedor ${p.supplierId}` }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
              lineNumber: 254,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(p.totalAmount) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
              lineNumber: 255,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 253,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { padding: "6px 14px", color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
            new Date(p.purchasedAt).toLocaleDateString("pt-BR"),
            " ",
            p.documentNumber ? `· NF ${p.documentNumber}` : "",
            " · ",
            p.items.map((it) => `${productName.get(it.productId) ?? it.productId} (${it.quantity})`).join(", ")
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 257,
            columnNumber: 33
          }, this)
        ] }, p.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 252,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 250,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
      lineNumber: 234,
      columnNumber: 13
    }, this),
    creatingSupplier && /* @__PURE__ */ jsxDEV(Modal, { title: "Novo fornecedor", onClose: () => setCreatingSupplier(false), variant: "center", wide: true, children: [
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Razão social",
          value: supplierForm.legalName,
          onChange: (e) => setSupplierForm((f) => ({ ...f, legalName: e.target.value })),
          autoFocus: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 270,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Nome fantasia",
          value: supplierForm.tradeName,
          onChange: (e) => setSupplierForm((f) => ({ ...f, tradeName: e.target.value }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 276,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "CNPJ",
            value: supplierForm.cnpj,
            onChange: (e) => setSupplierForm((f) => ({ ...f, cnpj: e.target.value })),
            maxLength: 14
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 283,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 282,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Telefone",
            value: supplierForm.phone,
            onChange: (e) => setSupplierForm((f) => ({ ...f, phone: e.target.value }))
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 291,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 290,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 281,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "E-mail",
          value: supplierForm.email,
          onChange: (e) => setSupplierForm((f) => ({ ...f, email: e.target.value }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 298,
          columnNumber: 21
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 303,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          loading: createSupplierMutation.isPending,
          disabled: supplierForm.legalName.trim() === "",
          onClick: () => createSupplierMutation.mutate(),
          children: "Criar fornecedor"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 304,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
      lineNumber: 269,
      columnNumber: 7
    }, this),
    registeringPurchase && /* @__PURE__ */ jsxDEV(Modal, { title: "Registrar compra", onClose: () => setRegisteringPurchase(false), variant: "center", wide: true, children: [
      /* @__PURE__ */ jsxDEV(SelectField, { label: "Fornecedor", value: supplierId, onChange: (e) => setSupplierId(e.target.value), autoFocus: true, children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione…" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 319,
          columnNumber: 25
        }, this),
        (suppliersQuery.data ?? []).filter((s) => s.isActive).map(
          (s) => /* @__PURE__ */ jsxDEV("option", { value: s.id, children: s.tradeName ?? s.legalName }, s.id, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 321,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 318,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Nº da nota", value: documentNumber, onChange: (e) => setDocumentNumber(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 326,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 325,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Data",
            type: "date",
            value: purchasedAt,
            onChange: (e) => setPurchasedAt(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 329,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 328,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 324,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-stack", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "field-label", children: "Itens" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 339,
          columnNumber: 25
        }, this),
        items.map(
          (item, index) => /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { alignItems: "end" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 2, minWidth: 180 }, children: /* @__PURE__ */ jsxDEV(
              SelectField,
              {
                label: "Produto",
                value: item.productId,
                onChange: (e) => setItem(index, { productId: Number(e.target.value) }),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: 0, children: "Produto…" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
                    lineNumber: 348,
                    columnNumber: 41
                  }, this),
                  (menuQuery.data ?? []).map(
                    (p) => /* @__PURE__ */ jsxDEV("option", { value: p.id, children: p.name }, p.id, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
                      lineNumber: 350,
                      columnNumber: 17
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
                lineNumber: 343,
                columnNumber: 37
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
              lineNumber: 342,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 90 }, children: /* @__PURE__ */ jsxDEV(
              TextField,
              {
                label: "Qtd",
                inputMode: "decimal",
                value: item.quantity,
                onChange: (e) => setItem(index, { quantity: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
                lineNumber: 355,
                columnNumber: 37
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
              lineNumber: 354,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 110 }, children: /* @__PURE__ */ jsxDEV(
              TextField,
              {
                label: "Custo unit.",
                inputMode: "decimal",
                value: item.unitCost,
                onChange: (e) => setItem(index, { unitCost: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
                lineNumber: 363,
                columnNumber: 37
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
              lineNumber: 362,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                iconOnly: true,
                "aria-label": "Remover item",
                disabled: items.length === 1,
                onClick: () => setItems((current) => current.filter((_, i) => i !== index)),
                children: "✕"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
                lineNumber: 370,
                columnNumber: 33
              },
              this
            )
          ] }, index, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 341,
            columnNumber: 11
          }, this)
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => setItems((current) => [...current, { productId: 0, quantity: "1", unitCost: "0" }]),
            children: "+ Adicionar item"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
            lineNumber: 380,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 338,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", color: "var(--ink-dim)" }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Total" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 388,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(purchaseTotal) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 389,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 387,
        columnNumber: 21
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
        lineNumber: 392,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          loading: registerPurchaseMutation.isPending,
          disabled: supplierId === "" || validItems.length === 0,
          onClick: () => registerPurchaseMutation.mutate(),
          children: "Registrar compra e dar entrada no estoque"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
          lineNumber: 393,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
      lineNumber: 317,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx",
    lineNumber: 174,
    columnNumber: 5
  }, this);
}
_s(PurchasingPage, "NevlRRvIotvbaU/chQ5j4iMguyc=", false, function() {
  return [useQueryClient, useDialog, useToast, useAuthStore, useQuery, useQuery, useQuery, useMutation, useMutation, useMutation];
});
_c = PurchasingPage;
var _c;
$RefreshReg$(_c, "PurchasingPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/purchasing/PurchasingPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEpnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1SmYsU0FBU0EsU0FBU0MsZ0JBQWdCO0FBQ25DLFNBQVNDLGFBQWFDLFVBQVVDLHNCQUFzQjtBQUN0RCxTQUFTQyxpQkFBaUI7QUFDMUI7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUVHO0FBQ1AsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQVE3QixNQUFNQyxXQUFXQSxDQUFDQyxRQUF3QjtBQUN0QyxNQUFJQSxJQUFJQyxLQUFLLE1BQU0sR0FBSSxRQUFPO0FBQzlCLFFBQU1DLFFBQVFDLE9BQU9ILElBQUlJLFFBQVEsS0FBSyxHQUFHLENBQUM7QUFDMUMsU0FBT0QsT0FBT0UsU0FBU0gsS0FBSyxJQUFJQSxRQUFRO0FBQzVDO0FBRU8sZ0JBQVNJLGlCQUFpQjtBQUFBQyxLQUFBO0FBQzdCLFFBQU1DLGNBQWM1QixlQUFlO0FBQ25DLFFBQU02QixTQUFTNUIsVUFBVTtBQUN6QixRQUFNNkIsUUFBUWQsU0FBUztBQUN2QixRQUFNLEVBQUVlLFVBQVVDLFdBQVdDLFdBQVcsSUFBSXpCLGFBQWE7QUFDekQsUUFBTSxDQUFDMEIsa0JBQWtCQyxtQkFBbUIsSUFBSXRDLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUN1QyxxQkFBcUJDLHNCQUFzQixJQUFJeEMsU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQ3lDLE9BQU9DLFFBQVEsSUFBSTFDLFNBQXdCLElBQUk7QUFFdEQsUUFBTSxDQUFDMkMsY0FBY0MsZUFBZSxJQUFJNUMsU0FBUztBQUFBLElBQzdDNkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSW5ELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNvRCxnQkFBZ0JDLGlCQUFpQixJQUFJckQsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3NELGFBQWFDLGNBQWMsSUFBSXZELFNBQVMsT0FBTSxvQkFBSXdELEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzFGLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJNUQsU0FBOEIsQ0FBQyxFQUFFNkQsV0FBVyxHQUFHQyxVQUFVLEtBQUtDLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFFeEcsUUFBTUMsaUJBQWlCOUQsU0FBUztBQUFBLElBQzVCK0QsVUFBVSxDQUFDLGFBQWE5QixTQUFTO0FBQUEsSUFDakMrQixTQUFTQSxNQUFNMUQsc0JBQXNCMkIsYUFBYSxDQUFDO0FBQUEsRUFDdkQsQ0FBQztBQUVELFFBQU1nQyxpQkFBaUJqRSxTQUFTO0FBQUEsSUFDNUIrRCxVQUFVLENBQUMsYUFBYS9CLFFBQVE7QUFBQSxJQUNoQ2dDLFNBQVNBLE1BQU0zRCxxQkFBcUIyQixRQUFRO0FBQUEsRUFDaEQsQ0FBQztBQUVELFFBQU1rQyxZQUFZbEUsU0FBUztBQUFBLElBQ3ZCK0QsVUFBVSxDQUFDLFFBQVE5QixTQUFTO0FBQUEsSUFDNUIrQixTQUFTQSxNQUFNeEQsUUFBUXlCLGFBQWEsQ0FBQztBQUFBLEVBQ3pDLENBQUM7QUFFRCxRQUFNa0MsY0FBY3RFLFFBQVEsTUFBTTtBQUM5QixVQUFNdUUsTUFBTSxvQkFBSUMsSUFBb0I7QUFDcEMsZUFBV0MsS0FBS0osVUFBVUssUUFBUSxHQUFJSCxLQUFJSSxJQUFJRixFQUFFRyxJQUFJSCxFQUFFSSxJQUFJO0FBQzFELFdBQU9OO0FBQUFBLEVBQ1gsR0FBRyxDQUFDRixVQUFVSyxJQUFJLENBQUM7QUFFbkIsUUFBTUksZUFBZTlFLFFBQVEsTUFBTTtBQUMvQixVQUFNdUUsTUFBTSxvQkFBSUMsSUFBb0I7QUFDcEMsZUFBV08sS0FBS2QsZUFBZVMsUUFBUSxHQUFJSCxLQUFJSSxJQUFJSSxFQUFFSCxJQUFJRyxFQUFFaEMsYUFBYWdDLEVBQUVqQyxTQUFTO0FBQ25GLFdBQU95QjtBQUFBQSxFQUNYLEdBQUcsQ0FBQ04sZUFBZVMsSUFBSSxDQUFDO0FBRXhCLFFBQU1NLG1CQUFtQkEsTUFBTSxLQUFLaEQsWUFBWWlELGtCQUFrQixFQUFFZixVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7QUFDN0YsUUFBTWdCLG1CQUFtQkEsTUFBTSxLQUFLbEQsWUFBWWlELGtCQUFrQixFQUFFZixVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7QUFDN0YsUUFBTWlCLGFBQWFBLENBQUNDLE1BQWV6QyxTQUFTeUMsYUFBYXZFLFdBQVd1RSxFQUFFQyxVQUFVLGtCQUFrQjtBQUVsRyxRQUFNQyx5QkFBeUJwRixZQUFZO0FBQUEsSUFDdkNxRixZQUFZQSxNQUNSakYsZUFBZTtBQUFBLE1BQ1g4QixXQUFXQSxhQUFhO0FBQUEsTUFDeEJVLFdBQVdGLGFBQWFFLFVBQVVyQixLQUFLO0FBQUEsTUFDdkNzQixXQUFXSCxhQUFhRyxVQUFVdEIsS0FBSyxNQUFNLEtBQUssT0FBT21CLGFBQWFHLFVBQVV0QixLQUFLO0FBQUEsTUFDckZ1QixNQUFNSixhQUFhSSxLQUFLdkIsS0FBSyxNQUFNLEtBQUssT0FBT21CLGFBQWFJLEtBQUt2QixLQUFLO0FBQUEsTUFDdEV3QixPQUFPTCxhQUFhSyxNQUFNeEIsS0FBSyxNQUFNLEtBQUssT0FBT21CLGFBQWFLLE1BQU14QixLQUFLO0FBQUEsTUFDekV5QixPQUFPTixhQUFhTSxNQUFNekIsS0FBSyxNQUFNLEtBQUssT0FBT21CLGFBQWFNLE1BQU16QixLQUFLO0FBQUEsSUFDN0UsQ0FBQztBQUFBLElBQ0wrRCxXQUFXQSxNQUFNO0FBQ2I3QyxlQUFTLElBQUk7QUFDYkosMEJBQW9CLEtBQUs7QUFDekJNLHNCQUFnQixFQUFFQyxXQUFXLElBQUlDLFdBQVcsSUFBSUMsTUFBTSxJQUFJQyxPQUFPLElBQUlDLE9BQU8sR0FBRyxDQUFDO0FBQ2hGOEIsdUJBQWlCO0FBQ2pCOUMsWUFBTXVELFFBQVEsb0JBQW9CO0FBQUEsSUFDdEM7QUFBQSxJQUNBQyxTQUFTUDtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNUSw2QkFBNkJ6RixZQUFZO0FBQUEsSUFDM0NxRixZQUFZQSxDQUFDWCxPQUFlckUsbUJBQW1CcUUsRUFBRTtBQUFBLElBQ2pEWSxXQUFXQSxNQUFNO0FBQ2JSLHVCQUFpQjtBQUNqQjlDLFlBQU11RCxRQUFRLHdCQUF3QjtBQUFBLElBQzFDO0FBQUEsSUFDQUMsU0FBU1A7QUFBQUEsRUFDYixDQUFDO0FBRUQsUUFBTVMsYUFBb0NoQyxNQUNyQ2lDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWhDLFlBQVksS0FBS3ZDLFNBQVN1RSxFQUFFL0IsUUFBUSxJQUFJLENBQUMsRUFDekRRLElBQUksQ0FBQ3VCLE9BQU87QUFBQSxJQUNUaEMsV0FBV2dDLEVBQUVoQztBQUFBQSxJQUNiQyxVQUFVeEMsU0FBU3VFLEVBQUUvQixRQUFRO0FBQUEsSUFDN0JDLFVBQVV6QyxTQUFTdUUsRUFBRTlCLFFBQVE7QUFBQSxFQUNqQyxFQUFFO0FBRU4sUUFBTStCLGdCQUFnQkgsV0FBV0ksT0FBTyxDQUFDQyxLQUFLSCxNQUFNRyxNQUFNSCxFQUFFL0IsV0FBVytCLEVBQUU5QixVQUFVLENBQUM7QUFFcEYsUUFBTWtDLDJCQUEyQmhHLFlBQVk7QUFBQSxJQUN6Q3FGLFlBQVlBLE1BQ1I3RSxpQkFBaUI7QUFBQSxNQUNieUI7QUFBQUEsTUFDQWdCLFlBQVl4QixPQUFPd0IsVUFBVTtBQUFBLE1BQzdCZCxZQUFZQSxjQUFjO0FBQUEsTUFDMUJnQixnQkFBZ0JBLGVBQWU1QixLQUFLLE1BQU0sS0FBSyxPQUFPNEIsZUFBZTVCLEtBQUs7QUFBQSxNQUMxRThCLGFBQWEsSUFBSUUsS0FBS0YsV0FBVyxFQUFFRyxZQUFZO0FBQUEsTUFDL0N5QyxPQUFPO0FBQUEsTUFDUHZDLE9BQU9nQztBQUFBQSxJQUNYLENBQUM7QUFBQSxJQUNMSixXQUFXQSxNQUFNO0FBQ2I3QyxlQUFTLElBQUk7QUFDYkYsNkJBQXVCLEtBQUs7QUFDNUJXLG9CQUFjLEVBQUU7QUFDaEJFLHdCQUFrQixFQUFFO0FBQ3BCTyxlQUFTLENBQUMsRUFBRUMsV0FBVyxHQUFHQyxVQUFVLEtBQUtDLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFDekRrQix1QkFBaUI7QUFDakJoRCxZQUFNdUQsUUFBUSx5Q0FBeUM7QUFBQSxJQUMzRDtBQUFBLElBQ0FDLFNBQVNQO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1pQixVQUFVQSxDQUFDQyxPQUFlQyxVQUM1QnpDLFNBQVMsQ0FBQzBDLFlBQVlBLFFBQVFoQyxJQUFJLENBQUNpQyxJQUFJVixNQUFPQSxNQUFNTyxRQUFRLEVBQUUsR0FBR0csSUFBSSxHQUFHRixNQUFNLElBQUlFLEVBQUcsQ0FBQztBQUUxRixTQUNJLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxTQUFTLElBQUlDLFVBQVUsTUFBTUMsUUFBUSxVQUFVQyxVQUFVLFdBQVcsR0FDL0U7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVDLFNBQVMsUUFBUUMsWUFBWSxZQUFZQyxLQUFLLElBQUlDLGNBQWMsR0FBR0MsVUFBVSxPQUFPLEdBQy9HO0FBQUEsNkJBQUMsUUFBRyxXQUFVLFdBQVUsT0FBTyxFQUFFQyxVQUFVLFNBQVMsR0FBRyxzQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RTtBQUFBLE1BQzdFLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxNQUFNLEVBQUUsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLFlBQU8sV0FBVSxhQUFZLE1BQUssVUFBUyxTQUFTLE1BQU07QUFBRXhFLGlCQUFTLElBQUk7QUFBR0osNEJBQW9CLElBQUk7QUFBQSxNQUFHLEdBQUcsNEJBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxXQUFVLGVBQWMsTUFBSyxVQUFTLFNBQVMsTUFBTTtBQUFFSSxpQkFBUyxJQUFJO0FBQUdGLCtCQUF1QixJQUFJO0FBQUEsTUFBRyxHQUFHLGtDQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUN3QixlQUFlbUQsV0FBVyx1QkFBQyxjQUFXLE9BQU9uRCxlQUFldkIsT0FBTyxNQUFLLHFCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStEO0FBQUEsSUFDekYwQixlQUFlZ0QsV0FBVyx1QkFBQyxjQUFXLE9BQU9oRCxlQUFlMUIsT0FBTyxNQUFLLGdCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsSUFDcEZBLFNBQVMsQ0FBQ0osb0JBQW9CLENBQUNFLHVCQUF1Qix1QkFBQyxPQUFFLFdBQVUsY0FBY0UsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUV4Rix1QkFBQyxhQUFRLFdBQVUsZUFBYyxPQUFPLEVBQUUyRSxXQUFXLEdBQUcsR0FDcEQ7QUFBQSw2QkFBQyxRQUFHLFdBQVUsV0FBVSxPQUFPLEVBQUVILFVBQVUsV0FBV0YsY0FBYyxFQUFFLEdBQUcsNEJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUY7QUFBQSxNQUNwRi9DLGVBQWVxRCxhQUFhLHVCQUFDLGdCQUFhLE1BQU0sR0FBRyxXQUFXLE1BQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxNQUNqRSxDQUFDckQsZUFBZXFELGNBQWNyRCxlQUFlUyxRQUFRLElBQUk2QyxXQUFXLEtBQ2pFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxPQUFNO0FBQUEsVUFDTixhQUFZO0FBQUEsVUFDWixRQUNJLHVCQUFDLFlBQU8sV0FBVSxlQUFjLE1BQUssVUFBUyxTQUFTLE1BQU07QUFBRTVFLHFCQUFTLElBQUk7QUFBR0osZ0NBQW9CLElBQUk7QUFBQSxVQUFHLEdBQUcsNEJBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUs7QUFBQSxNQUdSLENBQUMwQixlQUFlcUQsY0FBY3JELGVBQWVTLFFBQVEsSUFBSTZDLFNBQVMsS0FDL0QsdUJBQUMsU0FBSSxPQUFPLEVBQUVWLFNBQVMsUUFBUUUsS0FBSyxFQUFFLEdBQ2hDOUMsMEJBQWVTLFFBQVEsSUFBSUg7QUFBQUEsUUFBSSxDQUFDUSxNQUM5Qix1QkFBQyxTQUFlLFdBQVUsY0FDdEI7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRThCLFNBQVMsUUFBUUUsS0FBSyxFQUFFLEdBQ2xDO0FBQUEsbUNBQUMsVUFBTWhDLFlBQUVoQyxhQUFhZ0MsRUFBRWpDLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsWUFDbEMsdUJBQUMsVUFBSyxPQUFPLEVBQUVvRSxVQUFVLFVBQVVNLE9BQU8sbUJBQW1CLEdBQ3hEekM7QUFBQUEsZ0JBQUUvQixRQUFRO0FBQUEsY0FBVztBQUFBLGNBQUUrQixFQUFFN0IsUUFBUSxLQUFLNkIsRUFBRTdCLEtBQUssS0FBSztBQUFBLGlCQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQzZCLEVBQUUwQyxZQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTCxPQUFPLEVBQUVDLFdBQVcsSUFBSWpCLFNBQVMsVUFBVVMsVUFBVSxVQUFVO0FBQUEsY0FDL0QsU0FBUyxZQUFZO0FBQ2pCLG9CQUFJLE1BQU1qRixPQUFPMEYsUUFBUSxFQUFFQyxPQUFPLHdCQUF3QnZDLFNBQVMsY0FBY04sRUFBRWpDLFNBQVMsTUFBTStFLGNBQWMsYUFBYUMsUUFBUSxLQUFLLENBQUM7QUFDdkluQyw2Q0FBMkJvQyxPQUFPaEQsRUFBRUgsRUFBRTtBQUFBLGNBQzlDO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFQTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBbEJFRyxFQUFFSCxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxNQUNILEtBdkJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxTQXhDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsZUFBYyxPQUFPLEVBQUV5QyxXQUFXLEdBQUcsR0FDcEQ7QUFBQSw2QkFBQyxRQUFHLFdBQVUsV0FBVSxPQUFPLEVBQUVILFVBQVUsV0FBV0YsY0FBYyxFQUFFLEdBQUcsbUNBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEY7QUFBQSxNQUMzRjVDLGVBQWVrRCxhQUFhLHVCQUFDLGdCQUFhLE1BQU0sR0FBRyxXQUFXLE1BQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxNQUNqRSxDQUFDbEQsZUFBZWtELGNBQWNsRCxlQUFlTSxRQUFRLElBQUk2QyxXQUFXLEtBQ2pFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxPQUFNO0FBQUEsVUFDTixhQUFZO0FBQUEsVUFDWixRQUNJLHVCQUFDLFlBQU8sV0FBVSxlQUFjLE1BQUssVUFBUyxTQUFTLE1BQU07QUFBRTVFLHFCQUFTLElBQUk7QUFBR0YsbUNBQXVCLElBQUk7QUFBQSxVQUFHLEdBQUcsa0NBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUs7QUFBQSxNQUdSLENBQUMyQixlQUFla0QsY0FBY2xELGVBQWVNLFFBQVEsSUFBSTZDLFNBQVMsS0FDL0QsdUJBQUMsU0FBSSxPQUFPLEVBQUVWLFNBQVMsUUFBUUUsS0FBSyxFQUFFLEdBQ2hDM0MsMEJBQWVNLFFBQVEsSUFBSUg7QUFBQUEsUUFBSSxDQUFDRSxNQUM5Qix1QkFBQyxTQUFlLFdBQVUsVUFDdEI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZUFDWDtBQUFBLG1DQUFDLFVBQU1LLHVCQUFha0QsSUFBSXZELEVBQUV0QixVQUFVLEtBQUssY0FBY3NCLEVBQUV0QixVQUFVLE1BQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsVUFBSyxXQUFVLFlBQVlyQyxvQkFBVTJELEVBQUV3RCxXQUFXLEtBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsZUFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUV4QixTQUFTLFlBQVllLE9BQU8sb0JBQW9CTixVQUFVLFVBQVUsR0FDN0U7QUFBQSxnQkFBSXpELEtBQUtnQixFQUFFbEIsV0FBVyxFQUFFMkUsbUJBQW1CLE9BQU87QUFBQSxZQUFFO0FBQUEsWUFBRXpELEVBQUVwQixpQkFBaUIsUUFBUW9CLEVBQUVwQixjQUFjLEtBQUs7QUFBQSxZQUN0RztBQUFBLFlBQ0FvQixFQUFFYixNQUFNVyxJQUFJLENBQUNpQyxPQUFPLEdBQUdsQyxZQUFZMEQsSUFBSXhCLEdBQUcxQyxTQUFTLEtBQUswQyxHQUFHMUMsU0FBUyxLQUFLMEMsR0FBR3pDLFFBQVEsR0FBRyxFQUFFb0UsS0FBSyxJQUFJO0FBQUEsZUFIdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBVE0xRCxFQUFFRyxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLE1BQ0gsS0FiTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQTlCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBQUEsSUFFQ3RDLG9CQUNHLHVCQUFDLFNBQU0sT0FBTSxtQkFBa0IsU0FBUyxNQUFNQyxvQkFBb0IsS0FBSyxHQUFHLFNBQVEsVUFBUyxNQUFJLE1BQzNGO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE9BQU07QUFBQSxVQUNOLE9BQU9LLGFBQWFFO0FBQUFBLFVBQ3BCLFVBQVUsQ0FBQ3NDLE1BQU12QyxnQkFBZ0IsQ0FBQ3VGLE9BQU8sRUFBRSxHQUFHQSxHQUFHdEYsV0FBV3NDLEVBQUVpRCxPQUFPM0csTUFBTSxFQUFFO0FBQUEsVUFDN0UsV0FBUztBQUFBO0FBQUEsUUFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJYTtBQUFBLE1BRWI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE9BQU07QUFBQSxVQUNOLE9BQU9rQixhQUFhRztBQUFBQSxVQUNwQixVQUFVLENBQUNxQyxNQUFNdkMsZ0JBQWdCLENBQUN1RixPQUFPLEVBQUUsR0FBR0EsR0FBR3JGLFdBQVdxQyxFQUFFaUQsT0FBTzNHLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFIakY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR21GO0FBQUEsTUFFbkYsdUJBQUMsU0FBSSxXQUFVLHNCQUNYO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUV5RixNQUFNLEdBQUdtQixVQUFVLElBQUksR0FDakM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE9BQU07QUFBQSxZQUNOLE9BQU8xRixhQUFhSTtBQUFBQSxZQUNwQixVQUFVLENBQUNvQyxNQUFNdkMsZ0JBQWdCLENBQUN1RixPQUFPLEVBQUUsR0FBR0EsR0FBR3BGLE1BQU1vQyxFQUFFaUQsT0FBTzNHLE1BQU0sRUFBRTtBQUFBLFlBQ3hFLFdBQVc7QUFBQTtBQUFBLFVBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWtCLEtBTHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUV5RixNQUFNLEdBQUdtQixVQUFVLElBQUksR0FDakM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE9BQU07QUFBQSxZQUNOLE9BQU8xRixhQUFhTTtBQUFBQSxZQUNwQixVQUFVLENBQUNrQyxNQUFNdkMsZ0JBQWdCLENBQUN1RixPQUFPLEVBQUUsR0FBR0EsR0FBR2xGLE9BQU9rQyxFQUFFaUQsT0FBTzNHLE1BQU0sRUFBRTtBQUFBO0FBQUEsVUFIN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRytFLEtBSm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE9BQU07QUFBQSxVQUNOLE9BQU9rQixhQUFhSztBQUFBQSxVQUNwQixVQUFVLENBQUNtQyxNQUFNdkMsZ0JBQWdCLENBQUN1RixPQUFPLEVBQUUsR0FBR0EsR0FBR25GLE9BQU9tQyxFQUFFaUQsT0FBTzNHLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFIN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRytFO0FBQUEsTUFFOUVnQixTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQzNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxTQUFRO0FBQUEsVUFDUjtBQUFBLFVBQ0EsU0FBUzRDLHVCQUF1QmlEO0FBQUFBLFVBQ2hDLFVBQVUzRixhQUFhRSxVQUFVckIsS0FBSyxNQUFNO0FBQUEsVUFDNUMsU0FBUyxNQUFNNkQsdUJBQXVCeUMsT0FBTztBQUFBLFVBQUU7QUFBQTtBQUFBLFFBTG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0EzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRDQTtBQUFBLElBR0h2Rix1QkFDRyx1QkFBQyxTQUFNLE9BQU0sb0JBQW1CLFNBQVMsTUFBTUMsdUJBQXVCLEtBQUssR0FBRyxTQUFRLFVBQVMsTUFBSSxNQUMvRjtBQUFBLDZCQUFDLGVBQVksT0FBTSxjQUFhLE9BQU9VLFlBQVksVUFBVSxDQUFDaUMsTUFBTWhDLGNBQWNnQyxFQUFFaUQsT0FBTzNHLEtBQUssR0FBRyxXQUFTLE1BQ3hHO0FBQUEsK0JBQUMsWUFBTyxPQUFNLElBQUcsMEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxTQUN6QnVDLGVBQWVTLFFBQVEsSUFBSW1CLE9BQU8sQ0FBQ2QsTUFBTUEsRUFBRTBDLFFBQVEsRUFBRWxEO0FBQUFBLFVBQUksQ0FBQ1EsTUFDeEQsdUJBQUMsWUFBa0IsT0FBT0EsRUFBRUgsSUFBS0csWUFBRWhDLGFBQWFnQyxFQUFFakMsYUFBckNpQyxFQUFFSCxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTREO0FBQUEsUUFDL0Q7QUFBQSxXQUpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHNCQUNYO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUV1QyxNQUFNLEdBQUdtQixVQUFVLElBQUksR0FDakMsaUNBQUMsYUFBVSxPQUFNLGNBQWEsT0FBT2pGLGdCQUFnQixVQUFVLENBQUMrQixNQUFNOUIsa0JBQWtCOEIsRUFBRWlELE9BQU8zRyxLQUFLLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0csS0FENUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXlGLE1BQU0sR0FBR21CLFVBQVUsSUFBSSxHQUNqQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csT0FBTTtBQUFBLFlBQ04sTUFBSztBQUFBLFlBQ0wsT0FBTy9FO0FBQUFBLFlBQ1AsVUFBVSxDQUFDNkIsTUFBTTVCLGVBQWU0QixFQUFFaUQsT0FBTzNHLEtBQUs7QUFBQTtBQUFBLFVBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlvRCxLQUx4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLFlBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVUsZUFBYyxxQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQ2xDa0MsTUFBTVc7QUFBQUEsVUFBSSxDQUFDaUUsTUFBTW5DLFVBQ2QsdUJBQUMsU0FBZ0IsV0FBVSxzQkFBcUIsT0FBTyxFQUFFUyxZQUFZLE1BQU0sR0FDdkU7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRUssTUFBTSxHQUFHbUIsVUFBVSxJQUFJLEdBQ2pDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csT0FBTTtBQUFBLGdCQUNOLE9BQU9FLEtBQUsxRTtBQUFBQSxnQkFDWixVQUFVLENBQUNzQixNQUFNZ0IsUUFBUUMsT0FBTyxFQUFFdkMsV0FBV25DLE9BQU95RCxFQUFFaUQsT0FBTzNHLEtBQUssRUFBRSxDQUFDO0FBQUEsZ0JBRXJFO0FBQUEseUNBQUMsWUFBTyxPQUFPLEdBQUcsd0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBCO0FBQUEsbUJBQ3hCMkMsVUFBVUssUUFBUSxJQUFJSDtBQUFBQSxvQkFBSSxDQUFDRSxNQUN6Qix1QkFBQyxZQUFrQixPQUFPQSxFQUFFRyxJQUFLSCxZQUFFSSxRQUF0QkosRUFBRUcsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3QztBQUFBLGtCQUMzQztBQUFBO0FBQUE7QUFBQSxjQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUV1QyxNQUFNLEdBQUdtQixVQUFVLEdBQUcsR0FDaEM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxPQUFNO0FBQUEsZ0JBQ04sV0FBVTtBQUFBLGdCQUNWLE9BQU9FLEtBQUt6RTtBQUFBQSxnQkFDWixVQUFVLENBQUNxQixNQUFNZ0IsUUFBUUMsT0FBTyxFQUFFdEMsVUFBVXFCLEVBQUVpRCxPQUFPM0csTUFBTSxDQUFDO0FBQUE7QUFBQSxjQUpoRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJa0UsS0FMdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUV5RixNQUFNLEdBQUdtQixVQUFVLElBQUksR0FDakM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxPQUFNO0FBQUEsZ0JBQ04sV0FBVTtBQUFBLGdCQUNWLE9BQU9FLEtBQUt4RTtBQUFBQSxnQkFDWixVQUFVLENBQUNvQixNQUFNZ0IsUUFBUUMsT0FBTyxFQUFFckMsVUFBVW9CLEVBQUVpRCxPQUFPM0csTUFBTSxDQUFDO0FBQUE7QUFBQSxjQUpoRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJa0UsS0FMdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRztBQUFBLGdCQUNBLGNBQVc7QUFBQSxnQkFDWCxVQUFVa0MsTUFBTTJELFdBQVc7QUFBQSxnQkFDM0IsU0FBUyxNQUFNMUQsU0FBUyxDQUFDMEMsWUFBWUEsUUFBUVYsT0FBTyxDQUFDNEMsR0FBRzNDLE1BQU1BLE1BQU1PLEtBQUssQ0FBQztBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUpoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLGVBcENNQSxPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUNBO0FBQUEsUUFDSDtBQUFBLFFBQ0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFNBQVMsTUFBTXhDLFNBQVMsQ0FBQzBDLFlBQVksQ0FBQyxHQUFHQSxTQUFTLEVBQUV6QyxXQUFXLEdBQUdDLFVBQVUsS0FBS0MsVUFBVSxJQUFJLENBQUMsQ0FBQztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBRHZHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlBO0FBQUEsV0E5Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUU2QyxTQUFTLFFBQVE2QixnQkFBZ0IsaUJBQWlCbEIsT0FBTyxpQkFBaUIsR0FDcEY7QUFBQSwrQkFBQyxVQUFLLHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1gsdUJBQUMsVUFBSyxXQUFVLFlBQVkxRyxvQkFBVWlGLGFBQWEsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFdBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUNyRCxTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQzNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxTQUFRO0FBQUEsVUFDUjtBQUFBLFVBQ0EsU0FBU3dELHlCQUF5QnFDO0FBQUFBLFVBQ2xDLFVBQVVwRixlQUFlLE1BQU15QyxXQUFXMkIsV0FBVztBQUFBLFVBQ3JELFNBQVMsTUFBTXJCLHlCQUF5QjZCLE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUxyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLFNBcEZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxRkE7QUFBQSxPQXBPUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc09BO0FBRVI7QUFBQ2hHLEdBL1ZlRCxnQkFBYztBQUFBLFVBQ04xQixnQkFDTEMsV0FDRGUsVUFDOEJSLGNBa0JyQlQsVUFLQUEsVUFLTEEsVUFxQmFELGFBb0JJQSxhQW1CRkEsV0FBVztBQUFBO0FBQUEsS0E1RmhDNEI7QUFBYyxJQUFBNkc7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwidXNlRGlhbG9nIiwiY3JlYXRlU3VwcGxpZXIiLCJkZWFjdGl2YXRlU3VwcGxpZXIiLCJnZXRQdXJjaGFzZXNCeUJyYW5jaCIsImdldFN1cHBsaWVyc0J5Q29tcGFueSIsInJlZ2lzdGVyUHVyY2hhc2UiLCJnZXRNZW51IiwidXNlQXV0aFN0b3JlIiwiQXBpRXJyb3IiLCJmb3JtYXRCUkwiLCJRdWVyeUVycm9yIiwiTW9kYWwiLCJCdXR0b24iLCJUZXh0RmllbGQiLCJTZWxlY3RGaWVsZCIsInVzZVRvYXN0IiwiRW1wdHlTdGF0ZSIsIlNrZWxldG9uTGlzdCIsInBhcnNlTnVtIiwicmF3IiwidHJpbSIsInZhbHVlIiwiTnVtYmVyIiwicmVwbGFjZSIsImlzRmluaXRlIiwiUHVyY2hhc2luZ1BhZ2UiLCJfcyIsInF1ZXJ5Q2xpZW50IiwiZGlhbG9nIiwidG9hc3QiLCJicmFuY2hJZCIsImNvbXBhbnlJZCIsImVtcGxveWVlSWQiLCJjcmVhdGluZ1N1cHBsaWVyIiwic2V0Q3JlYXRpbmdTdXBwbGllciIsInJlZ2lzdGVyaW5nUHVyY2hhc2UiLCJzZXRSZWdpc3RlcmluZ1B1cmNoYXNlIiwiZXJyb3IiLCJzZXRFcnJvciIsInN1cHBsaWVyRm9ybSIsInNldFN1cHBsaWVyRm9ybSIsImxlZ2FsTmFtZSIsInRyYWRlTmFtZSIsImNucGoiLCJlbWFpbCIsInBob25lIiwic3VwcGxpZXJJZCIsInNldFN1cHBsaWVySWQiLCJkb2N1bWVudE51bWJlciIsInNldERvY3VtZW50TnVtYmVyIiwicHVyY2hhc2VkQXQiLCJzZXRQdXJjaGFzZWRBdCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNsaWNlIiwiaXRlbXMiLCJzZXRJdGVtcyIsInByb2R1Y3RJZCIsInF1YW50aXR5IiwidW5pdENvc3QiLCJzdXBwbGllcnNRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInB1cmNoYXNlc1F1ZXJ5IiwibWVudVF1ZXJ5IiwicHJvZHVjdE5hbWUiLCJtYXAiLCJNYXAiLCJwIiwiZGF0YSIsInNldCIsImlkIiwibmFtZSIsInN1cHBsaWVyTmFtZSIsInMiLCJyZWZyZXNoU3VwcGxpZXJzIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJyZWZyZXNoUHVyY2hhc2VzIiwib25BcGlFcnJvciIsImUiLCJtZXNzYWdlIiwiY3JlYXRlU3VwcGxpZXJNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJvblN1Y2Nlc3MiLCJzdWNjZXNzIiwib25FcnJvciIsImRlYWN0aXZhdGVTdXBwbGllck11dGF0aW9uIiwidmFsaWRJdGVtcyIsImZpbHRlciIsImkiLCJwdXJjaGFzZVRvdGFsIiwicmVkdWNlIiwic3VtIiwicmVnaXN0ZXJQdXJjaGFzZU11dGF0aW9uIiwibm90ZXMiLCJzZXRJdGVtIiwiaW5kZXgiLCJwYXRjaCIsImN1cnJlbnQiLCJpdCIsInBhZGRpbmciLCJtYXhXaWR0aCIsIm1hcmdpbiIsInBvc2l0aW9uIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJnYXAiLCJtYXJnaW5Cb3R0b20iLCJmbGV4V3JhcCIsImZvbnRTaXplIiwiZmxleCIsImlzRXJyb3IiLCJtYXJnaW5Ub3AiLCJpc0xvYWRpbmciLCJsZW5ndGgiLCJjb2xvciIsImlzQWN0aXZlIiwibWluSGVpZ2h0IiwiY29uZmlybSIsInRpdGxlIiwiY29uZmlybUxhYmVsIiwiZGFuZ2VyIiwibXV0YXRlIiwiZ2V0IiwidG90YWxBbW91bnQiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJqb2luIiwiZiIsInRhcmdldCIsIm1pbldpZHRoIiwiaXNQZW5kaW5nIiwiaXRlbSIsIl8iLCJqdXN0aWZ5Q29udGVudCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlB1cmNoYXNpbmdQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyB1c2VEaWFsb2cgfSBmcm9tIFwiLi4vLi4vdWkvRGlhbG9nXCI7XHJcbmltcG9ydCB7XHJcbiAgICBjcmVhdGVTdXBwbGllcixcclxuICAgIGRlYWN0aXZhdGVTdXBwbGllcixcclxuICAgIGdldFB1cmNoYXNlc0J5QnJhbmNoLFxyXG4gICAgZ2V0U3VwcGxpZXJzQnlDb21wYW55LFxyXG4gICAgcmVnaXN0ZXJQdXJjaGFzZSxcclxuICAgIHR5cGUgUHVyY2hhc2VJdGVtUGF5bG9hZCxcclxufSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgZ2V0TWVudSB9IGZyb20gXCIuLi9jYXRhbG9nL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IGZvcm1hdEJSTCB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiLi4vLi4vdWkvTW9kYWxcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uLy4uL3VpL0J1dHRvblwiO1xyXG5pbXBvcnQgeyBUZXh0RmllbGQsIFNlbGVjdEZpZWxkIH0gZnJvbSBcIi4uLy4uL3VpL0ZpZWxkXCI7XHJcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIi4uLy4uL3VpL1RvYXN0XCI7XHJcbmltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tIFwiLi4vLi4vdWkvRW1wdHlTdGF0ZVwiO1xyXG5pbXBvcnQgeyBTa2VsZXRvbkxpc3QgfSBmcm9tIFwiLi4vLi4vdWkvU2tlbGV0b25cIjtcclxuXHJcbmludGVyZmFjZSBQdXJjaGFzZUl0ZW1TdGF0ZSB7XHJcbiAgICBwcm9kdWN0SWQ6IG51bWJlcjtcclxuICAgIHF1YW50aXR5OiBzdHJpbmc7XHJcbiAgICB1bml0Q29zdDogc3RyaW5nO1xyXG59XHJcblxyXG5jb25zdCBwYXJzZU51bSA9IChyYXc6IHN0cmluZyk6IG51bWJlciA9PiB7XHJcbiAgICBpZiAocmF3LnRyaW0oKSA9PT0gXCJcIikgcmV0dXJuIDA7XHJcbiAgICBjb25zdCB2YWx1ZSA9IE51bWJlcihyYXcucmVwbGFjZShcIixcIiwgXCIuXCIpKTtcclxuICAgIHJldHVybiBOdW1iZXIuaXNGaW5pdGUodmFsdWUpID8gdmFsdWUgOiAwO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFB1cmNoYXNpbmdQYWdlKCkge1xyXG4gICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gICAgY29uc3QgZGlhbG9nID0gdXNlRGlhbG9nKCk7XHJcbiAgICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgICBjb25zdCB7IGJyYW5jaElkLCBjb21wYW55SWQsIGVtcGxveWVlSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gICAgY29uc3QgW2NyZWF0aW5nU3VwcGxpZXIsIHNldENyZWF0aW5nU3VwcGxpZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3JlZ2lzdGVyaW5nUHVyY2hhc2UsIHNldFJlZ2lzdGVyaW5nUHVyY2hhc2VdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgICBjb25zdCBbc3VwcGxpZXJGb3JtLCBzZXRTdXBwbGllckZvcm1dID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIGxlZ2FsTmFtZTogXCJcIixcclxuICAgICAgICB0cmFkZU5hbWU6IFwiXCIsXHJcbiAgICAgICAgY25wajogXCJcIixcclxuICAgICAgICBlbWFpbDogXCJcIixcclxuICAgICAgICBwaG9uZTogXCJcIixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IFtzdXBwbGllcklkLCBzZXRTdXBwbGllcklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW2RvY3VtZW50TnVtYmVyLCBzZXREb2N1bWVudE51bWJlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtwdXJjaGFzZWRBdCwgc2V0UHVyY2hhc2VkQXRdID0gdXNlU3RhdGUoKCkgPT4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKSk7XHJcbiAgICBjb25zdCBbaXRlbXMsIHNldEl0ZW1zXSA9IHVzZVN0YXRlPFB1cmNoYXNlSXRlbVN0YXRlW10+KFt7IHByb2R1Y3RJZDogMCwgcXVhbnRpdHk6IFwiMVwiLCB1bml0Q29zdDogXCIwXCIgfV0pO1xyXG5cclxuICAgIGNvbnN0IHN1cHBsaWVyc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgICAgIHF1ZXJ5S2V5OiBbXCJzdXBwbGllcnNcIiwgY29tcGFueUlkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRTdXBwbGllcnNCeUNvbXBhbnkoY29tcGFueUlkID8/IDEpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgcHVyY2hhc2VzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcInB1cmNoYXNlc1wiLCBicmFuY2hJZF0sXHJcbiAgICAgICAgcXVlcnlGbjogKCkgPT4gZ2V0UHVyY2hhc2VzQnlCcmFuY2goYnJhbmNoSWQpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgbWVudVF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgICAgIHF1ZXJ5S2V5OiBbXCJtZW51XCIsIGNvbXBhbnlJZF0sXHJcbiAgICAgICAgcXVlcnlGbjogKCkgPT4gZ2V0TWVudShjb21wYW55SWQgPz8gMSksXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBwcm9kdWN0TmFtZSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XHJcbiAgICAgICAgZm9yIChjb25zdCBwIG9mIG1lbnVRdWVyeS5kYXRhID8/IFtdKSBtYXAuc2V0KHAuaWQsIHAubmFtZSk7XHJcbiAgICAgICAgcmV0dXJuIG1hcDtcclxuICAgIH0sIFttZW51UXVlcnkuZGF0YV0pO1xyXG5cclxuICAgIGNvbnN0IHN1cHBsaWVyTmFtZSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XHJcbiAgICAgICAgZm9yIChjb25zdCBzIG9mIHN1cHBsaWVyc1F1ZXJ5LmRhdGEgPz8gW10pIG1hcC5zZXQocy5pZCwgcy50cmFkZU5hbWUgPz8gcy5sZWdhbE5hbWUpO1xyXG4gICAgICAgIHJldHVybiBtYXA7XHJcbiAgICB9LCBbc3VwcGxpZXJzUXVlcnkuZGF0YV0pO1xyXG5cclxuICAgIGNvbnN0IHJlZnJlc2hTdXBwbGllcnMgPSAoKSA9PiB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcInN1cHBsaWVyc1wiXSB9KTtcclxuICAgIGNvbnN0IHJlZnJlc2hQdXJjaGFzZXMgPSAoKSA9PiB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcInB1cmNoYXNlc1wiXSB9KTtcclxuICAgIGNvbnN0IG9uQXBpRXJyb3IgPSAoZTogdW5rbm93bikgPT4gc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEFwaUVycm9yID8gZS5tZXNzYWdlIDogXCJPcGVyYcOnw6NvIGZhbGhvdS5cIik7XHJcblxyXG4gICAgY29uc3QgY3JlYXRlU3VwcGxpZXJNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICAgICAgICBjcmVhdGVTdXBwbGllcih7XHJcbiAgICAgICAgICAgICAgICBjb21wYW55SWQ6IGNvbXBhbnlJZCA/PyAxLFxyXG4gICAgICAgICAgICAgICAgbGVnYWxOYW1lOiBzdXBwbGllckZvcm0ubGVnYWxOYW1lLnRyaW0oKSxcclxuICAgICAgICAgICAgICAgIHRyYWRlTmFtZTogc3VwcGxpZXJGb3JtLnRyYWRlTmFtZS50cmltKCkgPT09IFwiXCIgPyBudWxsIDogc3VwcGxpZXJGb3JtLnRyYWRlTmFtZS50cmltKCksXHJcbiAgICAgICAgICAgICAgICBjbnBqOiBzdXBwbGllckZvcm0uY25wai50cmltKCkgPT09IFwiXCIgPyBudWxsIDogc3VwcGxpZXJGb3JtLmNucGoudHJpbSgpLFxyXG4gICAgICAgICAgICAgICAgZW1haWw6IHN1cHBsaWVyRm9ybS5lbWFpbC50cmltKCkgPT09IFwiXCIgPyBudWxsIDogc3VwcGxpZXJGb3JtLmVtYWlsLnRyaW0oKSxcclxuICAgICAgICAgICAgICAgIHBob25lOiBzdXBwbGllckZvcm0ucGhvbmUudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IHN1cHBsaWVyRm9ybS5waG9uZS50cmltKCksXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICAgICAgc2V0Q3JlYXRpbmdTdXBwbGllcihmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldFN1cHBsaWVyRm9ybSh7IGxlZ2FsTmFtZTogXCJcIiwgdHJhZGVOYW1lOiBcIlwiLCBjbnBqOiBcIlwiLCBlbWFpbDogXCJcIiwgcGhvbmU6IFwiXCIgfSk7XHJcbiAgICAgICAgICAgIHJlZnJlc2hTdXBwbGllcnMoKTtcclxuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIkZvcm5lY2Vkb3IgY3JpYWRvLlwiKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBkZWFjdGl2YXRlU3VwcGxpZXJNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAoaWQ6IG51bWJlcikgPT4gZGVhY3RpdmF0ZVN1cHBsaWVyKGlkKSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgICAgcmVmcmVzaFN1cHBsaWVycygpO1xyXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiRm9ybmVjZWRvciBkZXNhdGl2YWRvLlwiKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCB2YWxpZEl0ZW1zOiBQdXJjaGFzZUl0ZW1QYXlsb2FkW10gPSBpdGVtc1xyXG4gICAgICAgIC5maWx0ZXIoKGkpID0+IGkucHJvZHVjdElkID4gMCAmJiBwYXJzZU51bShpLnF1YW50aXR5KSA+IDApXHJcbiAgICAgICAgLm1hcCgoaSkgPT4gKHtcclxuICAgICAgICAgICAgcHJvZHVjdElkOiBpLnByb2R1Y3RJZCxcclxuICAgICAgICAgICAgcXVhbnRpdHk6IHBhcnNlTnVtKGkucXVhbnRpdHkpLFxyXG4gICAgICAgICAgICB1bml0Q29zdDogcGFyc2VOdW0oaS51bml0Q29zdCksXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgIGNvbnN0IHB1cmNoYXNlVG90YWwgPSB2YWxpZEl0ZW1zLnJlZHVjZSgoc3VtLCBpKSA9PiBzdW0gKyBpLnF1YW50aXR5ICogaS51bml0Q29zdCwgMCk7XHJcblxyXG4gICAgY29uc3QgcmVnaXN0ZXJQdXJjaGFzZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgICAgICAgIHJlZ2lzdGVyUHVyY2hhc2Uoe1xyXG4gICAgICAgICAgICAgICAgYnJhbmNoSWQsXHJcbiAgICAgICAgICAgICAgICBzdXBwbGllcklkOiBOdW1iZXIoc3VwcGxpZXJJZCksXHJcbiAgICAgICAgICAgICAgICBlbXBsb3llZUlkOiBlbXBsb3llZUlkID8/IDEsXHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudE51bWJlcjogZG9jdW1lbnROdW1iZXIudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IGRvY3VtZW50TnVtYmVyLnRyaW0oKSxcclxuICAgICAgICAgICAgICAgIHB1cmNoYXNlZEF0OiBuZXcgRGF0ZShwdXJjaGFzZWRBdCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgICAgICAgIG5vdGVzOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgaXRlbXM6IHZhbGlkSXRlbXMsXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICAgICAgc2V0UmVnaXN0ZXJpbmdQdXJjaGFzZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldFN1cHBsaWVySWQoXCJcIik7XHJcbiAgICAgICAgICAgIHNldERvY3VtZW50TnVtYmVyKFwiXCIpO1xyXG4gICAgICAgICAgICBzZXRJdGVtcyhbeyBwcm9kdWN0SWQ6IDAsIHF1YW50aXR5OiBcIjFcIiwgdW5pdENvc3Q6IFwiMFwiIH1dKTtcclxuICAgICAgICAgICAgcmVmcmVzaFB1cmNoYXNlcygpO1xyXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiQ29tcHJhIHJlZ2lzdHJhZGEgZSBlc3RvcXVlIGF0dWFsaXphZG8uXCIpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHNldEl0ZW0gPSAoaW5kZXg6IG51bWJlciwgcGF0Y2g6IFBhcnRpYWw8UHVyY2hhc2VJdGVtU3RhdGU+KSA9PlxyXG4gICAgICAgIHNldEl0ZW1zKChjdXJyZW50KSA9PiBjdXJyZW50Lm1hcCgoaXQsIGkpID0+IChpID09PSBpbmRleCA/IHsgLi4uaXQsIC4uLnBhdGNoIH0gOiBpdCkpKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxtYWluIHN0eWxlPXt7IHBhZGRpbmc6IDIyLCBtYXhXaWR0aDogMTEwMCwgbWFyZ2luOiBcIjAgYXV0b1wiLCBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiIH19PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2VcIiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJiYXNlbGluZVwiLCBnYXA6IDE0LCBtYXJnaW5Cb3R0b206IDYsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS43cmVtXCIgfX0+Rm9ybmVjZWRvcmVzIGUgQ29tcHJhczwvaDI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB7IHNldEVycm9yKG51bGwpOyBzZXRDcmVhdGluZ1N1cHBsaWVyKHRydWUpOyB9fT5cclxuICAgICAgICAgICAgICAgICAgICArIEZvcm5lY2Vkb3JcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB7IHNldEVycm9yKG51bGwpOyBzZXRSZWdpc3RlcmluZ1B1cmNoYXNlKHRydWUpOyB9fT5cclxuICAgICAgICAgICAgICAgICAgICArIFJlZ2lzdHJhciBjb21wcmFcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtzdXBwbGllcnNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtzdXBwbGllcnNRdWVyeS5lcnJvcn0gd2hhdD1cIm9zIGZvcm5lY2Vkb3Jlc1wiIC8+fVxyXG4gICAgICAgICAgICB7cHVyY2hhc2VzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17cHVyY2hhc2VzUXVlcnkuZXJyb3J9IHdoYXQ9XCJhcyBjb21wcmFzXCIgLz59XHJcbiAgICAgICAgICAgIHtlcnJvciAmJiAhY3JlYXRpbmdTdXBwbGllciAmJiAhcmVnaXN0ZXJpbmdQdXJjaGFzZSAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcblxyXG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMVwiIHN0eWxlPXt7IG1hcmdpblRvcDogMTggfX0+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMTVyZW1cIiwgbWFyZ2luQm90dG9tOiA4IH19PkZvcm5lY2Vkb3JlczwvaDM+XHJcbiAgICAgICAgICAgICAgICB7c3VwcGxpZXJzUXVlcnkuaXNMb2FkaW5nICYmIDxTa2VsZXRvbkxpc3Qgcm93cz17M30gcm93SGVpZ2h0PXs0OH0gLz59XHJcbiAgICAgICAgICAgICAgICB7IXN1cHBsaWVyc1F1ZXJ5LmlzTG9hZGluZyAmJiAoc3VwcGxpZXJzUXVlcnkuZGF0YSA/PyBbXSkubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8RW1wdHlTdGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uPVwi8J+amlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTmVuaHVtIGZvcm5lY2Vkb3IgY2FkYXN0cmFkb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiQ2FkYXN0cmUgdW0gZm9ybmVjZWRvciBwYXJhIHBvZGVyIHJlZ2lzdHJhciBjb21wcmFzLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbj17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RXJyb3IobnVsbCk7IHNldENyZWF0aW5nU3VwcGxpZXIodHJ1ZSk7IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICsgRm9ybmVjZWRvclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHshc3VwcGxpZXJzUXVlcnkuaXNMb2FkaW5nICYmIChzdXBwbGllcnNRdWVyeS5kYXRhID8/IFtdKS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsoc3VwcGxpZXJzUXVlcnkuZGF0YSA/PyBbXSkubWFwKChzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cy5pZH0gY2xhc3NOYW1lPVwidGlja2V0LXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3MudHJhZGVOYW1lID8/IHMubGVnYWxOYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzLmNucGogPz8gXCJzZW0gQ05QSlwifSB7cy5waG9uZSA/IGDCtyAke3MucGhvbmV9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cy5pc0FjdGl2ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1kYW5nZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTBweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYXdhaXQgZGlhbG9nLmNvbmZpcm0oeyB0aXRsZTogXCJEZXNhdGl2YXIgZm9ybmVjZWRvclwiLCBtZXNzYWdlOiBgRGVzYXRpdmFyIFwiJHtzLmxlZ2FsTmFtZX1cIj9gLCBjb25maXJtTGFiZWw6IFwiRGVzYXRpdmFyXCIsIGRhbmdlcjogdHJ1ZSB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVhY3RpdmF0ZVN1cHBsaWVyTXV0YXRpb24ubXV0YXRlKHMuaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGVzYXRpdmFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMlwiIHN0eWxlPXt7IG1hcmdpblRvcDogMjYgfX0+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMTVyZW1cIiwgbWFyZ2luQm90dG9tOiA4IH19PkNvbXByYXMgcmVnaXN0cmFkYXM8L2gzPlxyXG4gICAgICAgICAgICAgICAge3B1cmNoYXNlc1F1ZXJ5LmlzTG9hZGluZyAmJiA8U2tlbGV0b25MaXN0IHJvd3M9ezN9IHJvd0hlaWdodD17NzJ9IC8+fVxyXG4gICAgICAgICAgICAgICAgeyFwdXJjaGFzZXNRdWVyeS5pc0xvYWRpbmcgJiYgKHB1cmNoYXNlc1F1ZXJ5LmRhdGEgPz8gW10pLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj1cIvCfp75cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIk5lbmh1bWEgY29tcHJhIHJlZ2lzdHJhZGFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbj1cIlJlZ2lzdHJlIHVtYSBjb21wcmEgcGFyYSBkYXIgZW50cmFkYSBubyBlc3RvcXVlLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbj17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RXJyb3IobnVsbCk7IHNldFJlZ2lzdGVyaW5nUHVyY2hhc2UodHJ1ZSk7IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICsgUmVnaXN0cmFyIGNvbXByYVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHshcHVyY2hhc2VzUXVlcnkuaXNMb2FkaW5nICYmIChwdXJjaGFzZXNRdWVyeS5kYXRhID8/IFtdKS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsocHVyY2hhc2VzUXVlcnkuZGF0YSA/PyBbXSkubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cC5pZH0gY2xhc3NOYW1lPVwidGlja2V0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtaGVhZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57c3VwcGxpZXJOYW1lLmdldChwLnN1cHBsaWVySWQpID8/IGBGb3JuZWNlZG9yICR7cC5zdXBwbGllcklkfWB9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiPntmb3JtYXRCUkwocC50b3RhbEFtb3VudCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogXCI2cHggMTRweFwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKHAucHVyY2hhc2VkQXQpLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIpfSB7cC5kb2N1bWVudE51bWJlciA/IGDCtyBORiAke3AuZG9jdW1lbnROdW1iZXJ9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcIiDCtyBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3AuaXRlbXMubWFwKChpdCkgPT4gYCR7cHJvZHVjdE5hbWUuZ2V0KGl0LnByb2R1Y3RJZCkgPz8gaXQucHJvZHVjdElkfSAoJHtpdC5xdWFudGl0eX0pYCkuam9pbihcIiwgXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICAgICAge2NyZWF0aW5nU3VwcGxpZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPE1vZGFsIHRpdGxlPVwiTm92byBmb3JuZWNlZG9yXCIgb25DbG9zZT17KCkgPT4gc2V0Q3JlYXRpbmdTdXBwbGllcihmYWxzZSl9IHZhcmlhbnQ9XCJjZW50ZXJcIiB3aWRlPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJSYXrDo28gc29jaWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N1cHBsaWVyRm9ybS5sZWdhbE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VwcGxpZXJGb3JtKChmKSA9PiAoeyAuLi5mLCBsZWdhbE5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTm9tZSBmYW50YXNpYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdXBwbGllckZvcm0udHJhZGVOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN1cHBsaWVyRm9ybSgoZikgPT4gKHsgLi4uZiwgdHJhZGVOYW1lOiBlLnRhcmdldC52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNjAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJDTlBKXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VwcGxpZXJGb3JtLmNucGp9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdXBwbGllckZvcm0oKGYpID0+ICh7IC4uLmYsIGNucGo6IGUudGFyZ2V0LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezE0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlRlbGVmb25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VwcGxpZXJGb3JtLnBob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VwcGxpZXJGb3JtKChmKSA9PiAoeyAuLi5mLCBwaG9uZTogZS50YXJnZXQudmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkUtbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdXBwbGllckZvcm0uZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VwcGxpZXJGb3JtKChmKSA9PiAoeyAuLi5mLCBlbWFpbDogZS50YXJnZXQudmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17Y3JlYXRlU3VwcGxpZXJNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzdXBwbGllckZvcm0ubGVnYWxOYW1lLnRyaW0oKSA9PT0gXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY3JlYXRlU3VwcGxpZXJNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENyaWFyIGZvcm5lY2Vkb3JcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7cmVnaXN0ZXJpbmdQdXJjaGFzZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8TW9kYWwgdGl0bGU9XCJSZWdpc3RyYXIgY29tcHJhXCIgb25DbG9zZT17KCkgPT4gc2V0UmVnaXN0ZXJpbmdQdXJjaGFzZShmYWxzZSl9IHZhcmlhbnQ9XCJjZW50ZXJcIiB3aWRlPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RGaWVsZCBsYWJlbD1cIkZvcm5lY2Vkb3JcIiB2YWx1ZT17c3VwcGxpZXJJZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRTdXBwbGllcklkKGUudGFyZ2V0LnZhbHVlKX0gYXV0b0ZvY3VzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWNpb25l4oCmPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsoc3VwcGxpZXJzUXVlcnkuZGF0YSA/PyBbXSkuZmlsdGVyKChzKSA9PiBzLmlzQWN0aXZlKS5tYXAoKHMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtzLmlkfSB2YWx1ZT17cy5pZH0+e3MudHJhZGVOYW1lID8/IHMubGVnYWxOYW1lfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEZpZWxkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJOwrogZGEgbm90YVwiIHZhbHVlPXtkb2N1bWVudE51bWJlcn0gb25DaGFuZ2U9eyhlKSA9PiBzZXREb2N1bWVudE51bWJlcihlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNjAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJEYXRhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3B1cmNoYXNlZEF0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHVyY2hhc2VkQXQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktc3RhY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmllbGQtbGFiZWxcIj5JdGVuczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgYWxpZ25JdGVtczogXCJlbmRcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDIsIG1pbldpZHRoOiAxODAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQcm9kdXRvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnByb2R1Y3RJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SXRlbShpbmRleCwgeyBwcm9kdWN0SWQ6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezB9PlByb2R1dG/igKY8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsobWVudVF1ZXJ5LmRhdGEgPz8gW10pLm1hcCgocCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+e3AubmFtZX08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEZpZWxkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDkwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlF0ZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnF1YW50aXR5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRJdGVtKGluZGV4LCB7IHF1YW50aXR5OiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxMTAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ3VzdG8gdW5pdC5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS51bml0Q29zdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SXRlbShpbmRleCwgeyB1bml0Q29zdDogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiUmVtb3ZlciBpdGVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2l0ZW1zLmxlbmd0aCA9PT0gMX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXRlbXMoKGN1cnJlbnQpID0+IGN1cnJlbnQuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleCkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pyVXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEl0ZW1zKChjdXJyZW50KSA9PiBbLi4uY3VycmVudCwgeyBwcm9kdWN0SWQ6IDAsIHF1YW50aXR5OiBcIjFcIiwgdW5pdENvc3Q6IFwiMFwiIH1dKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKyBBZGljaW9uYXIgaXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Ub3RhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIj57Zm9ybWF0QlJMKHB1cmNoYXNlVG90YWwpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17cmVnaXN0ZXJQdXJjaGFzZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3N1cHBsaWVySWQgPT09IFwiXCIgfHwgdmFsaWRJdGVtcy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlZ2lzdGVyUHVyY2hhc2VNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlZ2lzdHJhciBjb21wcmEgZSBkYXIgZW50cmFkYSBubyBlc3RvcXVlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICk7XHJcbn0iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvcHVyY2hhc2luZy9QdXJjaGFzaW5nUGFnZS50c3gifQ==