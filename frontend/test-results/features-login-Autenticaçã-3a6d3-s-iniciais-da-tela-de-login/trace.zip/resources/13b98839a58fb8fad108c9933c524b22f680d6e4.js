import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { openOrder } from "/src/features/orders/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
export function WaiterOpenComandaModal({ comanda, onClose, onOpened }) {
  _s();
  const { branchId, employeeId } = useAuthStore();
  const [customerName, setCustomerName] = useState("");
  const mutation = useMutation({
    mutationFn: () => openOrder({
      branchId,
      diningTableId: null,
      comandaId: comanda.id,
      employeeId: employeeId ?? 1,
      guestCount: 1,
      notes: customerName.trim() === "" ? null : `Cliente: ${customerName.trim()}`
    }),
    onSuccess: (orderId) => onOpened(orderId)
  });
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "modal-backdrop is-center",
      onMouseDown: (e) => {
        if (e.target === e.currentTarget) onClose();
      },
      style: { position: "absolute" },
      children: /* @__PURE__ */ jsxDEV("div", { className: "modal-panel is-center", style: { width: "90%", maxWidth: "360px", padding: "24px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "modal-head", style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.25rem", fontWeight: "800", textTransform: "uppercase" }, children: [
            "Abrir Comanda ",
            comanda.code || comanda.id
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
            lineNumber: 60,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost btn-icon", onClick: onClose, "aria-label": "Fechar", children: "✕" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
            lineNumber: 63,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
          lineNumber: 59,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: "8px", marginBottom: "24px", textAlign: "left" }, children: [
          /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.9rem", fontWeight: "600", color: "var(--ink-dim)" }, children: "Nome do cliente" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
            lineNumber: 69,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              value: customerName,
              onChange: (e) => setCustomerName(e.target.value),
              autoFocus: true,
              placeholder: "ex.: João Furlaneti",
              style: {
                padding: "12px",
                borderRadius: "8px",
                border: "1px solid var(--border)",
                backgroundColor: "var(--bg-raise, #f3f4f6)",
                color: "var(--ink)",
                width: "100%",
                fontSize: "1rem"
              }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
              lineNumber: 72,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
          lineNumber: 68,
          columnNumber: 17
        }, this),
        mutation.isError && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--w-warn, #ef4444)", fontSize: "0.85rem", marginBottom: "16px", fontWeight: "500", textAlign: "left" }, children: mutation.error instanceof ApiError ? mutation.error.message : "Falha ao abrir comanda." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
          lineNumber: 90,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "12px", justifyContent: "flex-end" }, children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost",
              onClick: onClose,
              style: { padding: "10px 16px", borderRadius: "8px", fontWeight: "600" },
              children: "Voltar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
              lineNumber: 96,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "waiter-cta",
              onClick: () => mutation.mutate(),
              disabled: mutation.isPending,
              style: { margin: 0, padding: "10px 20px", borderRadius: "8px", fontWeight: "700" },
              children: mutation.isPending ? "Abrindo…" : "Abrir comanda"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
              lineNumber: 104,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
          lineNumber: 95,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
        lineNumber: 58,
        columnNumber: 13
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx",
      lineNumber: 51,
      columnNumber: 5
    },
    this
  );
}
_s(WaiterOpenComandaModal, "hbKjSomKQ09271folK43PQZrFuE=", false, function() {
  return [useAuthStore, useMutation];
});
_c = WaiterOpenComandaModal;
var _c;
$RefreshReg$(_c, "WaiterOpenComandaModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4Q25CLFNBQVNBLGdCQUFnQjtBQUMxQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFTbEIsZ0JBQVNDLHVCQUF1QixFQUFFQyxTQUFTQyxTQUFTQyxTQUFzQyxHQUFHO0FBQUFDLEtBQUE7QUFDaEcsUUFBTSxFQUFFQyxVQUFVQyxXQUFXLElBQUlSLGFBQWE7QUFDOUMsUUFBTSxDQUFDUyxjQUFjQyxlQUFlLElBQUliLFNBQVMsRUFBRTtBQUVuRCxRQUFNYyxXQUFXYixZQUFZO0FBQUEsSUFDekJjLFlBQVlBLE1BQ1JiLFVBQVU7QUFBQSxNQUNOUTtBQUFBQSxNQUNBTSxlQUFlO0FBQUEsTUFDZkMsV0FBV1gsUUFBUVk7QUFBQUEsTUFDbkJQLFlBQVlBLGNBQWM7QUFBQSxNQUMxQlEsWUFBWTtBQUFBLE1BQ1pDLE9BQU9SLGFBQWFTLEtBQUssTUFBTSxLQUFLLE9BQU8sWUFBWVQsYUFBYVMsS0FBSyxDQUFDO0FBQUEsSUFDOUUsQ0FBQztBQUFBLElBQ0xDLFdBQVdBLENBQUNDLFlBQVlmLFNBQVNlLE9BQU87QUFBQSxFQUM1QyxDQUFDO0FBRUQsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csV0FBVTtBQUFBLE1BQ1YsYUFBYSxDQUFDQyxNQUFNO0FBQ2hCLFlBQUlBLEVBQUVDLFdBQVdELEVBQUVFLGNBQWVuQixTQUFRO0FBQUEsTUFDOUM7QUFBQSxNQUNBLE9BQU8sRUFBRW9CLFVBQVUsV0FBVztBQUFBLE1BRTlCLGlDQUFDLFNBQUksV0FBVSx5QkFBd0IsT0FBTyxFQUFFQyxPQUFPLE9BQU9DLFVBQVUsU0FBU0MsU0FBUyxPQUFPLEdBQzdGO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFQyxTQUFTLFFBQVFDLGdCQUFnQixpQkFBaUJDLFlBQVksVUFBVUMsY0FBYyxPQUFPLEdBQzlIO0FBQUEsaUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFQyxVQUFVLFdBQVdDLFlBQVksT0FBT0MsZUFBZSxZQUFZLEdBQUc7QUFBQTtBQUFBLFlBQ3RGL0IsUUFBUWdDLFFBQVFoQyxRQUFRWTtBQUFBQSxlQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHNCQUFxQixTQUFTWCxTQUFTLGNBQVcsVUFBUyxpQkFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXdCLFNBQVMsUUFBUVEsS0FBSyxPQUFPTCxjQUFjLFFBQVFNLFdBQVcsT0FBTyxHQUMvRTtBQUFBLGlDQUFDLFdBQU0sT0FBTyxFQUFFTCxVQUFVLFVBQVVDLFlBQVksT0FBT0ssT0FBTyxpQkFBaUIsR0FBRywrQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE9BQU83QjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ1ksTUFBTVgsZ0JBQWdCVyxFQUFFQyxPQUFPaUIsS0FBSztBQUFBLGNBQy9DO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixPQUFPO0FBQUEsZ0JBQ0haLFNBQVM7QUFBQSxnQkFDVGEsY0FBYztBQUFBLGdCQUNkQyxRQUFRO0FBQUEsZ0JBQ1JDLGlCQUFpQjtBQUFBLGdCQUNqQkosT0FBTztBQUFBLGdCQUNQYixPQUFPO0FBQUEsZ0JBQ1BPLFVBQVU7QUFBQSxjQUNkO0FBQUE7QUFBQSxZQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFNO0FBQUEsYUFqQlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBRUNyQixTQUFTZ0MsV0FDTix1QkFBQyxPQUFFLE9BQU8sRUFBRUwsT0FBTywwQkFBMEJOLFVBQVUsV0FBV0QsY0FBYyxRQUFRRSxZQUFZLE9BQU9JLFdBQVcsT0FBTyxHQUN4SDFCLG1CQUFTaUMsaUJBQWlCM0MsV0FBV1UsU0FBU2lDLE1BQU1DLFVBQVUsNkJBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0osdUJBQUMsU0FBSSxPQUFPLEVBQUVqQixTQUFTLFFBQVFRLEtBQUssUUFBUVAsZ0JBQWdCLFdBQVcsR0FDbkU7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBU3pCO0FBQUFBLGNBQ1QsT0FBTyxFQUFFdUIsU0FBUyxhQUFhYSxjQUFjLE9BQU9QLFlBQVksTUFBTTtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSjVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNdEIsU0FBU21DLE9BQU87QUFBQSxjQUMvQixVQUFVbkMsU0FBU29DO0FBQUFBLGNBQ25CLE9BQU8sRUFBRUMsUUFBUSxHQUFHckIsU0FBUyxhQUFhYSxjQUFjLE9BQU9QLFlBQVksTUFBTTtBQUFBLGNBRWhGdEIsbUJBQVNvQyxZQUFZLGFBQWE7QUFBQTtBQUFBLFlBUHZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFdBdkRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3REE7QUFBQTtBQUFBLElBL0RKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWdFQTtBQUVSO0FBQUN6QyxHQXBGZUosd0JBQXNCO0FBQUEsVUFDREYsY0FHaEJGLFdBQVc7QUFBQTtBQUFBLEtBSmhCSTtBQUFzQixJQUFBK0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsIm9wZW5PcmRlciIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwiV2FpdGVyT3BlbkNvbWFuZGFNb2RhbCIsImNvbWFuZGEiLCJvbkNsb3NlIiwib25PcGVuZWQiLCJfcyIsImJyYW5jaElkIiwiZW1wbG95ZWVJZCIsImN1c3RvbWVyTmFtZSIsInNldEN1c3RvbWVyTmFtZSIsIm11dGF0aW9uIiwibXV0YXRpb25GbiIsImRpbmluZ1RhYmxlSWQiLCJjb21hbmRhSWQiLCJpZCIsImd1ZXN0Q291bnQiLCJub3RlcyIsInRyaW0iLCJvblN1Y2Nlc3MiLCJvcmRlcklkIiwiZSIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJwb3NpdGlvbiIsIndpZHRoIiwibWF4V2lkdGgiLCJwYWRkaW5nIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsIm1hcmdpbkJvdHRvbSIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsInRleHRUcmFuc2Zvcm0iLCJjb2RlIiwiZ2FwIiwidGV4dEFsaWduIiwiY29sb3IiLCJ2YWx1ZSIsImJvcmRlclJhZGl1cyIsImJvcmRlciIsImJhY2tncm91bmRDb2xvciIsImlzRXJyb3IiLCJlcnJvciIsIm1lc3NhZ2UiLCJtdXRhdGUiLCJpc1BlbmRpbmciLCJtYXJnaW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJXYWl0ZXJPcGVuQ29tYW5kYU1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgb3Blbk9yZGVyIH0gZnJvbSBcIi4uLy4uLy4uL29yZGVycy9hcGlcIjtcclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uLy4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tIFwiLi4vLi4vLi4vLi4vbGliL2FwaUNsaWVudFwiO1xyXG5pbXBvcnQgdHlwZSB7IENvbWFuZGFSZXNwb25zZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9saWIvdHlwZXNcIjtcclxuXHJcbmludGVyZmFjZSBXYWl0ZXJPcGVuQ29tYW5kYU1vZGFsUHJvcHMge1xyXG4gICAgY29tYW5kYTogQ29tYW5kYVJlc3BvbnNlO1xyXG4gICAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxuICAgIG9uT3BlbmVkOiAob3JkZXJJZDogbnVtYmVyKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gV2FpdGVyT3BlbkNvbWFuZGFNb2RhbCh7IGNvbWFuZGEsIG9uQ2xvc2UsIG9uT3BlbmVkIH06IFdhaXRlck9wZW5Db21hbmRhTW9kYWxQcm9wcykge1xyXG4gICAgY29uc3QgeyBicmFuY2hJZCwgZW1wbG95ZWVJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgICBjb25zdCBbY3VzdG9tZXJOYW1lLCBzZXRDdXN0b21lck5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gICAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgICAgICAgb3Blbk9yZGVyKHtcclxuICAgICAgICAgICAgICAgIGJyYW5jaElkLFxyXG4gICAgICAgICAgICAgICAgZGluaW5nVGFibGVJZDogbnVsbCxcclxuICAgICAgICAgICAgICAgIGNvbWFuZGFJZDogY29tYW5kYS5pZCxcclxuICAgICAgICAgICAgICAgIGVtcGxveWVlSWQ6IGVtcGxveWVlSWQgPz8gMSxcclxuICAgICAgICAgICAgICAgIGd1ZXN0Q291bnQ6IDEsXHJcbiAgICAgICAgICAgICAgICBub3RlczogY3VzdG9tZXJOYW1lLnRyaW0oKSA9PT0gXCJcIiA/IG51bGwgOiBgQ2xpZW50ZTogJHtjdXN0b21lck5hbWUudHJpbSgpfWAsXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgIG9uU3VjY2VzczogKG9yZGVySWQpID0+IG9uT3BlbmVkKG9yZGVySWQpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1vZGFsLWJhY2tkcm9wIGlzLWNlbnRlclwiXHJcbiAgICAgICAgICAgIG9uTW91c2VEb3duPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKGUudGFyZ2V0ID09PSBlLmN1cnJlbnRUYXJnZXQpIG9uQ2xvc2UoKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgc3R5bGU9e3sgcG9zaXRpb246IFwiYWJzb2x1dGVcIiB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1wYW5lbCBpcy1jZW50ZXJcIiBzdHlsZT17eyB3aWR0aDogXCI5MCVcIiwgbWF4V2lkdGg6IFwiMzYwcHhcIiwgcGFkZGluZzogXCIyNHB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRcIiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBtYXJnaW5Cb3R0b206IFwiMjBweFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjI1cmVtXCIsIGZvbnRXZWlnaHQ6IFwiODAwXCIsIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFicmlyIENvbWFuZGEge2NvbWFuZGEuY29kZSB8fCBjb21hbmRhLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3QgYnRuLWljb25cIiBvbkNsaWNrPXtvbkNsb3NlfSBhcmlhLWxhYmVsPVwiRmVjaGFyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKclVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiBcIjhweFwiLCBtYXJnaW5Cb3R0b206IFwiMjRweFwiLCB0ZXh0QWxpZ246IFwibGVmdFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiwgZm9udFdlaWdodDogXCI2MDBcIiwgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTm9tZSBkbyBjbGllbnRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbWVyTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21lck5hbWUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJleC46IEpvw6NvIEZ1cmxhbmV0aVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjEycHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCI4cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgdmFyKC0tYm9yZGVyKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcInZhcigtLWJnLXJhaXNlLCAjZjNmNGY2KVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwidmFyKC0taW5rKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMXJlbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHttdXRhdGlvbi5pc0Vycm9yICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS13LXdhcm4sICNlZjQ0NDQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgbWFyZ2luQm90dG9tOiBcIjE2cHhcIiwgZm9udFdlaWdodDogXCI1MDBcIiwgdGV4dEFsaWduOiBcImxlZnRcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge211dGF0aW9uLmVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBtdXRhdGlvbi5lcnJvci5tZXNzYWdlIDogXCJGYWxoYSBhbyBhYnJpciBjb21hbmRhLlwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiBcIjEycHhcIiwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjEwcHggMTZweFwiLCBib3JkZXJSYWRpdXM6IFwiOHB4XCIsIGZvbnRXZWlnaHQ6IFwiNjAwXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFZvbHRhclxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIndhaXRlci1jdGFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBtdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e211dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luOiAwLCBwYWRkaW5nOiBcIjEwcHggMjBweFwiLCBib3JkZXJSYWRpdXM6IFwiOHB4XCIsIGZvbnRXZWlnaHQ6IFwiNzAwXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHttdXRhdGlvbi5pc1BlbmRpbmcgPyBcIkFicmluZG/igKZcIiA6IFwiQWJyaXIgY29tYW5kYVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy93YWl0ZXIvY29tcG9uZW50cy9tb2RhbHMvV2FpdGVyT3BlbkNvbWFuZGFNb2RhbC50c3gifQ==