import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/ProductComplementLinkPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  getComplementGroups,
  getProductComplementGroups,
  linkProductComplementGroup,
  unlinkProductComplementGroup
} from "/src/features/catalog/complementsApi.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { complementGroupTypeLabel } from "/src/lib/types.ts";
import { Button } from "/src/ui/Button.tsx";
import { useToast } from "/src/ui/Toast.tsx";
import { useDialog } from "/src/ui/Dialog.tsx";
export function ProductComplementLinkPanel({ productId }) {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const dialog = useDialog();
  const { companyId } = useAuthStore();
  const [addGroupId, setAddGroupId] = useState("");
  const [error, setError] = useState(null);
  const linksQuery = useQuery({
    queryKey: ["product-complement-groups", productId],
    queryFn: () => getProductComplementGroups(productId)
  });
  const allGroupsQuery = useQuery({
    queryKey: ["complement-groups", companyId],
    queryFn: () => getComplementGroups(companyId ?? 1)
  });
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["product-complement-groups", productId] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const linkMutation = useMutation({
    mutationFn: () => linkProductComplementGroup(productId, Number(addGroupId), (linksQuery.data?.length ?? 0) + 1),
    onSuccess: () => {
      toast.success("Grupo vinculado ao produto.");
      setAddGroupId("");
      setError(null);
      refresh();
    },
    onError: onApiError
  });
  const unlinkMutation = useMutation({
    mutationFn: (productComplementGroupId) => unlinkProductComplementGroup(productComplementGroupId),
    onSuccess: () => {
      toast.success("Grupo desvinculado.");
      refresh();
    },
    onError: onApiError
  });
  const linkedGroupIds = new Set((linksQuery.data ?? []).map((l) => l.complementGroupId));
  const availableGroups = (allGroupsQuery.data ?? []).filter(
    (g) => g.isActive && !linkedGroupIds.has(g.id)
  );
  return /* @__PURE__ */ jsxDEV("div", { className: "field", style: { gap: 8 }, children: [
    /* @__PURE__ */ jsxDEV("span", { className: "field-label", children: "Grupos de complementos deste produto" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
      lineNumber: 88,
      columnNumber: 7
    }, this),
    linksQuery.isLoading && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "Carregando…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    !linksQuery.isLoading && (linksQuery.data?.length ?? 0) === 0 && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "Nenhum grupo vinculado — o produto não terá complementos ao ser lançado num pedido." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    (linksQuery.data ?? []).map(
      (link) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "ui-row",
          style: { justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid var(--line)" },
          children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              link.complementGroupName,
              " ",
              /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.8rem" }, children: [
                "(",
                complementGroupTypeLabel[link.complementGroupTypeId] ?? `Tipo ${link.complementGroupTypeId}`,
                link.minSelection === 0 ? ", opcional" : `, mín. ${link.minSelection}`,
                ", máx. ",
                link.maxSelection,
                ")"
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
                lineNumber: 108,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
              lineNumber: 106,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "sm",
                variant: "danger",
                loading: unlinkMutation.isPending,
                onClick: async () => {
                  if (await dialog.confirm({
                    title: "Desvincular grupo",
                    message: `Remover "${link.complementGroupName}" deste produto?`,
                    confirmLabel: "Remover",
                    danger: true
                  }))
                    unlinkMutation.mutate(link.productComplementGroupId);
                },
                children: "Remover"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
                lineNumber: 113,
                columnNumber: 11
              },
              this
            )
          ]
        },
        link.productComplementGroupId,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
          lineNumber: 101,
          columnNumber: 7
        },
        this
      )
    ),
    availableGroups.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 8, marginTop: 6 }, children: [
      /* @__PURE__ */ jsxDEV(
        "select",
        {
          value: addGroupId,
          onChange: (e) => setAddGroupId(e.target.value),
          "aria-label": "Selecionar grupo de complementos para vincular ao produto",
          style: { flex: 1, minWidth: 160 },
          children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: "Vincular grupo…" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
              lineNumber: 142,
              columnNumber: 13
            }, this),
            availableGroups.map(
              (g) => /* @__PURE__ */ jsxDEV("option", { value: g.id, children: g.name }, g.id, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
                lineNumber: 144,
                columnNumber: 11
              }, this)
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
          lineNumber: 136,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Button, { loading: linkMutation.isPending, disabled: addGroupId === "", onClick: () => linkMutation.mutate(), children: "Vincular" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
        lineNumber: 149,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
      lineNumber: 135,
      columnNumber: 7
    }, this) : allGroupsQuery.data !== void 0 && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.8rem", marginTop: 4 }, children: (allGroupsQuery.data ?? []).length === 0 ? "Nenhum grupo cadastrado ainda — crie um na tela Complementos." : "Todos os grupos já estão vinculados a este produto." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
      lineNumber: 155,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", role: "alert", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
      lineNumber: 164,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx",
    lineNumber: 87,
    columnNumber: 5
  }, this);
}
_s(ProductComplementLinkPanel, "PmtMXurj/OemPSadOGp0+KpC4FA=", false, function() {
  return [useQueryClient, useToast, useDialog, useAuthStore, useQuery, useQuery, useMutation, useMutation];
});
_c = ProductComplementLinkPanel;
var _c;
$RefreshReg$(_c, "ProductComplementLinkPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ProductComplementLinkPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0VNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBFTCxTQUFTQSxnQkFBZ0I7QUFDMUIsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3REO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZ0NBQWdDO0FBQ3pDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGlCQUFpQjtBQU1uQixnQkFBU0MsMkJBQTJCLEVBQUVDLFVBQWlCLEdBQUc7QUFBQUMsS0FBQTtBQUMvRCxRQUFNQyxjQUFjZCxlQUFlO0FBQ25DLFFBQU1lLFFBQVFOLFNBQVM7QUFDdkIsUUFBTU8sU0FBU04sVUFBVTtBQUN6QixRQUFNLEVBQUVPLFVBQVUsSUFBSVosYUFBYTtBQUNuQyxRQUFNLENBQUNhLFlBQVlDLGFBQWEsSUFBSXRCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN1QixPQUFPQyxRQUFRLElBQUl4QixTQUF3QixJQUFJO0FBRXRELFFBQU15QixhQUFhdkIsU0FBUztBQUFBLElBQzFCd0IsVUFBVSxDQUFDLDZCQUE2QlgsU0FBUztBQUFBLElBQ2pEWSxTQUFTQSxNQUFNdEIsMkJBQTJCVSxTQUFTO0FBQUEsRUFDckQsQ0FBQztBQUVELFFBQU1hLGlCQUFpQjFCLFNBQVM7QUFBQSxJQUM5QndCLFVBQVUsQ0FBQyxxQkFBcUJOLFNBQVM7QUFBQSxJQUN6Q08sU0FBU0EsTUFBTXZCLG9CQUFvQmdCLGFBQWEsQ0FBQztBQUFBLEVBQ25ELENBQUM7QUFFRCxRQUFNUyxVQUFVQSxNQUFNLEtBQUtaLFlBQVlhLGtCQUFrQixFQUFFSixVQUFVLENBQUMsNkJBQTZCWCxTQUFTLEVBQUUsQ0FBQztBQUMvRyxRQUFNZ0IsYUFBYUEsQ0FBQ0MsTUFBZVIsU0FBU1EsYUFBYXZCLFdBQVd1QixFQUFFQyxVQUFVLGtCQUFrQjtBQUVsRyxRQUFNQyxlQUFlakMsWUFBWTtBQUFBLElBQy9Ca0MsWUFBWUEsTUFDVjdCLDJCQUEyQlMsV0FBV3FCLE9BQU9mLFVBQVUsSUFBSUksV0FBV1ksTUFBTUMsVUFBVSxLQUFLLENBQUM7QUFBQSxJQUM5RkMsV0FBV0EsTUFBTTtBQUNmckIsWUFBTXNCLFFBQVEsNkJBQTZCO0FBQzNDbEIsb0JBQWMsRUFBRTtBQUNoQkUsZUFBUyxJQUFJO0FBQ2JLLGNBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQVksU0FBU1Y7QUFBQUEsRUFDWCxDQUFDO0FBRUQsUUFBTVcsaUJBQWlCekMsWUFBWTtBQUFBLElBQ2pDa0MsWUFBWUEsQ0FBQ1EsNkJBQXFDcEMsNkJBQTZCb0Msd0JBQXdCO0FBQUEsSUFDdkdKLFdBQVdBLE1BQU07QUFDZnJCLFlBQU1zQixRQUFRLHFCQUFxQjtBQUNuQ1gsY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBWSxTQUFTVjtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNYSxpQkFBaUIsSUFBSUMsS0FBS3BCLFdBQVdZLFFBQVEsSUFBSVMsSUFBSSxDQUFDQyxNQUFNQSxFQUFFQyxpQkFBaUIsQ0FBQztBQUN0RixRQUFNQyxtQkFBbUJyQixlQUFlUyxRQUFRLElBQUlhO0FBQUFBLElBQ2xELENBQUNDLE1BQU1BLEVBQUVDLFlBQVksQ0FBQ1IsZUFBZVMsSUFBSUYsRUFBRUcsRUFBRTtBQUFBLEVBQy9DO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsU0FBUSxPQUFPLEVBQUVDLEtBQUssRUFBRSxHQUNyQztBQUFBLDJCQUFDLFVBQUssV0FBVSxlQUFjLG9EQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtFO0FBQUEsSUFFakU5QixXQUFXK0IsYUFDVix1QkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxvQkFBb0JDLFVBQVUsVUFBVSxHQUFHLDJCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRFO0FBQUEsSUFHN0UsQ0FBQ2pDLFdBQVcrQixjQUFjL0IsV0FBV1ksTUFBTUMsVUFBVSxPQUFPLEtBQzNELHVCQUFDLFVBQUssT0FBTyxFQUFFbUIsT0FBTyxvQkFBb0JDLFVBQVUsVUFBVSxHQUFHLG1HQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxLQUdBakMsV0FBV1ksUUFBUSxJQUFJUztBQUFBQSxNQUFJLENBQUNhLFNBQzVCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxXQUFVO0FBQUEsVUFDVixPQUFPLEVBQUVDLGdCQUFnQixpQkFBaUJDLFNBQVMsU0FBU0MsY0FBYyx3QkFBd0I7QUFBQSxVQUVsRztBQUFBLG1DQUFDLFVBQ0VIO0FBQUFBLG1CQUFLSTtBQUFBQSxjQUFxQjtBQUFBLGNBQzNCLHVCQUFDLFVBQUssT0FBTyxFQUFFTixPQUFPLG9CQUFvQkMsVUFBVSxTQUFTLEdBQUc7QUFBQTtBQUFBLGdCQUM1RGhELHlCQUF5QmlELEtBQUtLLHFCQUFxQixLQUFLLFFBQVFMLEtBQUtLLHFCQUFxQjtBQUFBLGdCQUMzRkwsS0FBS00saUJBQWlCLElBQUksZUFBZSxVQUFVTixLQUFLTSxZQUFZO0FBQUEsZ0JBQUc7QUFBQSxnQkFBUU4sS0FBS087QUFBQUEsZ0JBQWE7QUFBQSxtQkFGcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVE7QUFBQSxnQkFDUixTQUFTeEIsZUFBZXlCO0FBQUFBLGdCQUN4QixTQUFTLFlBQVk7QUFDbkIsc0JBQ0UsTUFBTWhELE9BQU9pRCxRQUFRO0FBQUEsb0JBQ25CQyxPQUFPO0FBQUEsb0JBQ1BwQyxTQUFTLFlBQVkwQixLQUFLSSxtQkFBbUI7QUFBQSxvQkFDN0NPLGNBQWM7QUFBQSxvQkFDZEMsUUFBUTtBQUFBLGtCQUNWLENBQUM7QUFFRDdCLG1DQUFlOEIsT0FBT2IsS0FBS2hCLHdCQUF3QjtBQUFBLGdCQUN2RDtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlCQTtBQUFBO0FBQUE7QUFBQSxRQTVCS2dCLEtBQUtoQjtBQUFBQSxRQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUE4QkE7QUFBQSxJQUNEO0FBQUEsSUFFQU0sZ0JBQWdCWCxTQUFTLElBQ3hCLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFaUIsS0FBSyxHQUFHa0IsV0FBVyxFQUFFLEdBQ2hFO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU9wRDtBQUFBQSxVQUNQLFVBQVUsQ0FBQ1csTUFBTVYsY0FBY1UsRUFBRTBDLE9BQU9DLEtBQUs7QUFBQSxVQUM3QyxjQUFXO0FBQUEsVUFDWCxPQUFPLEVBQUVDLE1BQU0sR0FBR0MsVUFBVSxJQUFJO0FBQUEsVUFFaEM7QUFBQSxtQ0FBQyxZQUFPLE9BQU0sSUFBRywrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxZQUMvQjVCLGdCQUFnQkg7QUFBQUEsY0FBSSxDQUFDSyxNQUNwQix1QkFBQyxZQUFrQixPQUFPQSxFQUFFRyxJQUN6QkgsWUFBRTJCLFFBRFEzQixFQUFFRyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxZQUNEO0FBQUE7QUFBQTtBQUFBLFFBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BWUE7QUFBQSxNQUNBLHVCQUFDLFVBQU8sU0FBU3BCLGFBQWFpQyxXQUFXLFVBQVU5QyxlQUFlLElBQUksU0FBUyxNQUFNYSxhQUFhc0MsT0FBTyxHQUFHLHdCQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBLElBRUE1QyxlQUFlUyxTQUFTMEMsVUFDdEIsdUJBQUMsVUFBSyxPQUFPLEVBQUV0QixPQUFPLG9CQUFvQkMsVUFBVSxVQUFVZSxXQUFXLEVBQUUsR0FDdkU3QywwQkFBZVMsUUFBUSxJQUFJQyxXQUFXLElBQ3BDLGtFQUNBLHlEQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBSUhmLFNBQ0MsdUJBQUMsT0FBRSxXQUFVLGNBQWEsTUFBSyxTQUM1QkEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0EvRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlGQTtBQUVKO0FBQUNQLEdBbkllRiw0QkFBMEI7QUFBQSxVQUNwQlgsZ0JBQ05TLFVBQ0NDLFdBQ09MLGNBSUhOLFVBS0lBLFVBUUZELGFBWUVBLFdBQVc7QUFBQTtBQUFBLEtBakNwQmE7QUFBMEIsSUFBQWtFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiZ2V0Q29tcGxlbWVudEdyb3VwcyIsImdldFByb2R1Y3RDb21wbGVtZW50R3JvdXBzIiwibGlua1Byb2R1Y3RDb21wbGVtZW50R3JvdXAiLCJ1bmxpbmtQcm9kdWN0Q29tcGxlbWVudEdyb3VwIiwidXNlQXV0aFN0b3JlIiwiQXBpRXJyb3IiLCJjb21wbGVtZW50R3JvdXBUeXBlTGFiZWwiLCJCdXR0b24iLCJ1c2VUb2FzdCIsInVzZURpYWxvZyIsIlByb2R1Y3RDb21wbGVtZW50TGlua1BhbmVsIiwicHJvZHVjdElkIiwiX3MiLCJxdWVyeUNsaWVudCIsInRvYXN0IiwiZGlhbG9nIiwiY29tcGFueUlkIiwiYWRkR3JvdXBJZCIsInNldEFkZEdyb3VwSWQiLCJlcnJvciIsInNldEVycm9yIiwibGlua3NRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImFsbEdyb3Vwc1F1ZXJ5IiwicmVmcmVzaCIsImludmFsaWRhdGVRdWVyaWVzIiwib25BcGlFcnJvciIsImUiLCJtZXNzYWdlIiwibGlua011dGF0aW9uIiwibXV0YXRpb25GbiIsIk51bWJlciIsImRhdGEiLCJsZW5ndGgiLCJvblN1Y2Nlc3MiLCJzdWNjZXNzIiwib25FcnJvciIsInVubGlua011dGF0aW9uIiwicHJvZHVjdENvbXBsZW1lbnRHcm91cElkIiwibGlua2VkR3JvdXBJZHMiLCJTZXQiLCJtYXAiLCJsIiwiY29tcGxlbWVudEdyb3VwSWQiLCJhdmFpbGFibGVHcm91cHMiLCJmaWx0ZXIiLCJnIiwiaXNBY3RpdmUiLCJoYXMiLCJpZCIsImdhcCIsImlzTG9hZGluZyIsImNvbG9yIiwiZm9udFNpemUiLCJsaW5rIiwianVzdGlmeUNvbnRlbnQiLCJwYWRkaW5nIiwiYm9yZGVyQm90dG9tIiwiY29tcGxlbWVudEdyb3VwTmFtZSIsImNvbXBsZW1lbnRHcm91cFR5cGVJZCIsIm1pblNlbGVjdGlvbiIsIm1heFNlbGVjdGlvbiIsImlzUGVuZGluZyIsImNvbmZpcm0iLCJ0aXRsZSIsImNvbmZpcm1MYWJlbCIsImRhbmdlciIsIm11dGF0ZSIsIm1hcmdpblRvcCIsInRhcmdldCIsInZhbHVlIiwiZmxleCIsIm1pbldpZHRoIiwibmFtZSIsInVuZGVmaW5lZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByb2R1Y3RDb21wbGVtZW50TGlua1BhbmVsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQge1xyXG4gIGdldENvbXBsZW1lbnRHcm91cHMsXHJcbiAgZ2V0UHJvZHVjdENvbXBsZW1lbnRHcm91cHMsXHJcbiAgbGlua1Byb2R1Y3RDb21wbGVtZW50R3JvdXAsXHJcbiAgdW5saW5rUHJvZHVjdENvbXBsZW1lbnRHcm91cCxcclxufSBmcm9tIFwiLi9jb21wbGVtZW50c0FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IGNvbXBsZW1lbnRHcm91cFR5cGVMYWJlbCB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uLy4uL3VpL0J1dHRvblwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi8uLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyB1c2VEaWFsb2cgfSBmcm9tIFwiLi4vLi4vdWkvRGlhbG9nXCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gIHByb2R1Y3RJZDogbnVtYmVyO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUHJvZHVjdENvbXBsZW1lbnRMaW5rUGFuZWwoeyBwcm9kdWN0SWQgfTogUHJvcHMpIHtcclxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG4gIGNvbnN0IGRpYWxvZyA9IHVzZURpYWxvZygpO1xyXG4gIGNvbnN0IHsgY29tcGFueUlkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbYWRkR3JvdXBJZCwgc2V0QWRkR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBsaW5rc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcInByb2R1Y3QtY29tcGxlbWVudC1ncm91cHNcIiwgcHJvZHVjdElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldFByb2R1Y3RDb21wbGVtZW50R3JvdXBzKHByb2R1Y3RJZCksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGFsbEdyb3Vwc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImNvbXBsZW1lbnQtZ3JvdXBzXCIsIGNvbXBhbnlJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRDb21wbGVtZW50R3JvdXBzKGNvbXBhbnlJZCA/PyAxKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcmVmcmVzaCA9ICgpID0+IHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wicHJvZHVjdC1jb21wbGVtZW50LWdyb3Vwc1wiLCBwcm9kdWN0SWRdIH0pO1xyXG4gIGNvbnN0IG9uQXBpRXJyb3IgPSAoZTogdW5rbm93bikgPT4gc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEFwaUVycm9yID8gZS5tZXNzYWdlIDogXCJPcGVyYcOnw6NvIGZhbGhvdS5cIik7XHJcblxyXG4gIGNvbnN0IGxpbmtNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIGxpbmtQcm9kdWN0Q29tcGxlbWVudEdyb3VwKHByb2R1Y3RJZCwgTnVtYmVyKGFkZEdyb3VwSWQpLCAobGlua3NRdWVyeS5kYXRhPy5sZW5ndGggPz8gMCkgKyAxKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiR3J1cG8gdmluY3VsYWRvIGFvIHByb2R1dG8uXCIpO1xyXG4gICAgICBzZXRBZGRHcm91cElkKFwiXCIpO1xyXG4gICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgcmVmcmVzaCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHVubGlua011dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKHByb2R1Y3RDb21wbGVtZW50R3JvdXBJZDogbnVtYmVyKSA9PiB1bmxpbmtQcm9kdWN0Q29tcGxlbWVudEdyb3VwKHByb2R1Y3RDb21wbGVtZW50R3JvdXBJZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkdydXBvIGRlc3ZpbmN1bGFkby5cIik7XHJcbiAgICAgIHJlZnJlc2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBsaW5rZWRHcm91cElkcyA9IG5ldyBTZXQoKGxpbmtzUXVlcnkuZGF0YSA/PyBbXSkubWFwKChsKSA9PiBsLmNvbXBsZW1lbnRHcm91cElkKSk7XHJcbiAgY29uc3QgYXZhaWxhYmxlR3JvdXBzID0gKGFsbEdyb3Vwc1F1ZXJ5LmRhdGEgPz8gW10pLmZpbHRlcihcclxuICAgIChnKSA9PiBnLmlzQWN0aXZlICYmICFsaW5rZWRHcm91cElkcy5oYXMoZy5pZCksXHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmllbGRcIiBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZpZWxkLWxhYmVsXCI+R3J1cG9zIGRlIGNvbXBsZW1lbnRvcyBkZXN0ZSBwcm9kdXRvPC9zcGFuPlxyXG5cclxuICAgICAge2xpbmtzUXVlcnkuaXNMb2FkaW5nICYmIChcclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5DYXJyZWdhbmRv4oCmPC9zcGFuPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgeyFsaW5rc1F1ZXJ5LmlzTG9hZGluZyAmJiAobGlua3NRdWVyeS5kYXRhPy5sZW5ndGggPz8gMCkgPT09IDAgJiYgKFxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgTmVuaHVtIGdydXBvIHZpbmN1bGFkbyDigJQgbyBwcm9kdXRvIG7Do28gdGVyw6EgY29tcGxlbWVudG9zIGFvIHNlciBsYW7Dp2FkbyBudW0gcGVkaWRvLlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsobGlua3NRdWVyeS5kYXRhID8/IFtdKS5tYXAoKGxpbmspID0+IChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBrZXk9e2xpbmsucHJvZHVjdENvbXBsZW1lbnRHcm91cElkfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidWktcm93XCJcclxuICAgICAgICAgIHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgcGFkZGluZzogXCI2cHggMFwiLCBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkIHZhcigtLWxpbmUpXCIgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAge2xpbmsuY29tcGxlbWVudEdyb3VwTmFtZX17XCIgXCJ9XHJcbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgKHtjb21wbGVtZW50R3JvdXBUeXBlTGFiZWxbbGluay5jb21wbGVtZW50R3JvdXBUeXBlSWRdID8/IGBUaXBvICR7bGluay5jb21wbGVtZW50R3JvdXBUeXBlSWR9YH1cclxuICAgICAgICAgICAgICB7bGluay5taW5TZWxlY3Rpb24gPT09IDAgPyBcIiwgb3BjaW9uYWxcIiA6IGAsIG3DrW4uICR7bGluay5taW5TZWxlY3Rpb259YH0sIG3DoXguIHtsaW5rLm1heFNlbGVjdGlvbn0pXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgdmFyaWFudD1cImRhbmdlclwiXHJcbiAgICAgICAgICAgIGxvYWRpbmc9e3VubGlua011dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiRGVzdmluY3VsYXIgZ3J1cG9cIixcclxuICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYFJlbW92ZXIgXCIke2xpbmsuY29tcGxlbWVudEdyb3VwTmFtZX1cIiBkZXN0ZSBwcm9kdXRvP2AsXHJcbiAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJSZW1vdmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgIGRhbmdlcjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgdW5saW5rTXV0YXRpb24ubXV0YXRlKGxpbmsucHJvZHVjdENvbXBsZW1lbnRHcm91cElkKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUmVtb3ZlclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkpfVxyXG5cclxuICAgICAge2F2YWlsYWJsZUdyb3Vwcy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiA4LCBtYXJnaW5Ub3A6IDYgfX0+XHJcbiAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgIHZhbHVlPXthZGRHcm91cElkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFkZEdyb3VwSWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiU2VsZWNpb25hciBncnVwbyBkZSBjb21wbGVtZW50b3MgcGFyYSB2aW5jdWxhciBhbyBwcm9kdXRvXCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+VmluY3VsYXIgZ3J1cG/igKY8L29wdGlvbj5cclxuICAgICAgICAgICAge2F2YWlsYWJsZUdyb3Vwcy5tYXAoKGcpID0+IChcclxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Zy5pZH0gdmFsdWU9e2cuaWR9PlxyXG4gICAgICAgICAgICAgICAge2cubmFtZX1cclxuICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgIDxCdXR0b24gbG9hZGluZz17bGlua011dGF0aW9uLmlzUGVuZGluZ30gZGlzYWJsZWQ9e2FkZEdyb3VwSWQgPT09IFwiXCJ9IG9uQ2xpY2s9eygpID0+IGxpbmtNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgIFZpbmN1bGFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICBhbGxHcm91cHNRdWVyeS5kYXRhICE9PSB1bmRlZmluZWQgJiYgKFxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjhyZW1cIiwgbWFyZ2luVG9wOiA0IH19PlxyXG4gICAgICAgICAgICB7KGFsbEdyb3Vwc1F1ZXJ5LmRhdGEgPz8gW10pLmxlbmd0aCA9PT0gMFxyXG4gICAgICAgICAgICAgID8gXCJOZW5odW0gZ3J1cG8gY2FkYXN0cmFkbyBhaW5kYSDigJQgY3JpZSB1bSBuYSB0ZWxhIENvbXBsZW1lbnRvcy5cIlxyXG4gICAgICAgICAgICAgIDogXCJUb2RvcyBvcyBncnVwb3MgasOhIGVzdMOjbyB2aW5jdWxhZG9zIGEgZXN0ZSBwcm9kdXRvLlwifVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIClcclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiIHJvbGU9XCJhbGVydFwiPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvUHJvZHVjdENvbXBsZW1lbnRMaW5rUGFuZWwudHN4In0=