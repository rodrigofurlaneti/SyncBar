import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/ComplementGroupsPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  addComplement,
  createComplementGroup,
  deactivateComplementGroup,
  getComplementGroups,
  getComplementItems,
  removeComplement,
  updateComplementGroup,
  updateComplementPrice
} from "/src/features/catalog/complementsApi.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { complementGroupTypeLabel, formatBRL } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { Button } from "/src/ui/Button.tsx";
import { TextField, SelectField } from "/src/ui/Field.tsx";
import { useToast } from "/src/ui/Toast.tsx";
import { useDialog } from "/src/ui/Dialog.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
const emptyForm = { name: "", complementGroupTypeId: "1", minSelection: "0", maxSelection: "1" };
const parseInt0 = (raw) => {
  const value = Number(raw);
  return Number.isFinite(value) && value >= 0 ? Math.trunc(value) : 0;
};
export function ComplementGroupsPanel() {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const dialog = useDialog();
  const { companyId } = useAuthStore();
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [expandedId, setExpandedId] = useState(null);
  const [error, setError] = useState(null);
  const groupsQuery = useQuery({
    queryKey: ["complement-groups", companyId],
    queryFn: () => getComplementGroups(companyId ?? 1)
  });
  const itemsQuery = useQuery({
    queryKey: ["complement-items", companyId],
    queryFn: () => getComplementItems(companyId ?? 1)
  });
  const activeItems = useMemo(
    () => (itemsQuery.data ?? []).filter((i) => i.isActive),
    [itemsQuery.data]
  );
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["complement-groups"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const openEditor = (group) => {
    setError(null);
    setEditing(group);
    setForm(
      group === "new" ? emptyForm : {
        name: group.name,
        complementGroupTypeId: String(group.complementGroupTypeId),
        minSelection: String(group.minSelection),
        maxSelection: String(group.maxSelection)
      }
    );
  };
  const createMutation = useMutation({
    mutationFn: () => createComplementGroup(
      companyId ?? 1,
      form.name.trim(),
      Number(form.complementGroupTypeId),
      parseInt0(form.minSelection),
      parseInt0(form.maxSelection)
    ),
    onSuccess: () => {
      toast.success("Grupo criado.");
      setEditing(null);
      refresh();
    },
    onError: onApiError
  });
  const updateMutation = useMutation({
    mutationFn: () => updateComplementGroup(
      editing.id,
      form.name.trim(),
      Number(form.complementGroupTypeId),
      parseInt0(form.minSelection),
      parseInt0(form.maxSelection)
    ),
    onSuccess: () => {
      toast.success("Grupo atualizado.");
      setEditing(null);
      refresh();
    },
    onError: onApiError
  });
  const deactivateMutation = useMutation({
    mutationFn: (id) => deactivateComplementGroup(id),
    onSuccess: () => {
      toast.success("Grupo desativado.");
      refresh();
    },
    onError: onApiError
  });
  const maxBelowMin = parseInt0(form.maxSelection) < parseInt0(form.minSelection);
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: () => openEditor("new"), children: "+ Novo grupo" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
      lineNumber: 144,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
      lineNumber: 143,
      columnNumber: 7
    }, this),
    groupsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: groupsQuery.error, what: "os grupos de complementos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
      lineNumber: 149,
      columnNumber: 31
    }, this),
    groupsQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 3, rowHeight: 64 }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
      lineNumber: 150,
      columnNumber: 33
    }, this),
    !groupsQuery.isLoading && (groupsQuery.data?.length ?? 0) === 0 && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: "🍔",
        title: "Nenhum grupo de complementos",
        description: 'Crie um grupo (ex.: "Escolha uma bebida") e depois vincule opções da aba Itens a ele.',
        action: /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: () => openEditor("new"), children: "+ Novo grupo" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 158,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
        lineNumber: 153,
        columnNumber: 7
      },
      this
    ),
    (groupsQuery.data ?? []).map(
      (group) => /* @__PURE__ */ jsxDEV(
        GroupCard,
        {
          group,
          expanded: expandedId === group.id,
          onToggle: () => setExpandedId((id) => id === group.id ? null : group.id),
          onEdit: () => openEditor(group),
          onDeactivate: async () => {
            if (await dialog.confirm({
              title: "Desativar grupo",
              message: `Desativar "${group.name}"? Produtos vinculados deixam de oferecer este grupo.`,
              confirmLabel: "Desativar",
              danger: true
            }))
              deactivateMutation.mutate(group.id);
          },
          activeItems,
          onError: onApiError
        },
        group.id,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 166,
          columnNumber: 7
        },
        this
      )
    ),
    editing !== null && /* @__PURE__ */ jsxDEV(Modal, { title: editing === "new" ? "Novo grupo de complementos" : "Editar grupo", onClose: () => setEditing(null), children: [
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Nome do grupo",
          value: form.name,
          onChange: (e) => setForm({ ...form, name: e.target.value }),
          autoFocus: true,
          placeholder: "ex.: Escolha uma bebida"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 190,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        SelectField,
        {
          label: "Tipo",
          value: form.complementGroupTypeId,
          onChange: (e) => setForm({ ...form, complementGroupTypeId: e.target.value }),
          children: Object.entries(complementGroupTypeLabel).map(
            ([id, label]) => /* @__PURE__ */ jsxDEV("option", { value: id, children: label }, id, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
              lineNumber: 204,
              columnNumber: 11
            }, this)
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 198,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Mínimo de seleções",
            inputMode: "numeric",
            value: form.minSelection,
            onChange: (e) => setForm({ ...form, minSelection: e.target.value }),
            hint: "0 = grupo opcional"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 212,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 211,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Máximo de seleções",
            inputMode: "numeric",
            value: form.maxSelection,
            onChange: (e) => setForm({ ...form, maxSelection: e.target.value }),
            hint: "1 = escolha única (rádio)"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 221,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 220,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
        lineNumber: 210,
        columnNumber: 11
      }, this),
      maxBelowMin && /* @__PURE__ */ jsxDEV("p", { className: "error-text", role: "alert", children: "O máximo não pode ser menor que o mínimo." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
        lineNumber: 232,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", role: "alert", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
        lineNumber: 237,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          block: true,
          loading: createMutation.isPending || updateMutation.isPending,
          disabled: form.name.trim() === "" || maxBelowMin,
          onClick: () => editing === "new" ? createMutation.mutate() : updateMutation.mutate(),
          children: "Salvar"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 242,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
      lineNumber: 189,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
    lineNumber: 142,
    columnNumber: 5
  }, this);
}
_s(ComplementGroupsPanel, "q2OD7oq6liLxekf8yYJTo3YA47s=", false, function() {
  return [useQueryClient, useToast, useDialog, useAuthStore, useQuery, useQuery, useMutation, useMutation, useMutation];
});
_c = ComplementGroupsPanel;
function GroupCard({ group, expanded, onToggle, onEdit, onDeactivate, activeItems, onError }) {
  _s2();
  const queryClient = useQueryClient();
  const toast = useToast();
  const dialog = useDialog();
  const [addItemId, setAddItemId] = useState("");
  const [addPrice, setAddPrice] = useState("");
  const [editingPriceId, setEditingPriceId] = useState(null);
  const [editPrice, setEditPrice] = useState("");
  const availableItems = activeItems.filter(
    (item) => !group.complements.some((c) => c.complementItemId === item.id && c.isActive)
  );
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["complement-groups"] });
  const addMutation = useMutation({
    mutationFn: () => {
      const price = Number(addPrice.replace(",", ".")) || 0;
      return addComplement(group.id, Number(addItemId), price);
    },
    onSuccess: () => {
      toast.success("Opção adicionada ao grupo.");
      setAddItemId("");
      setAddPrice("");
      refresh();
    },
    onError
  });
  const updatePriceMutation = useMutation({
    mutationFn: (complementId) => {
      const price = Number(editPrice.replace(",", ".")) || 0;
      return updateComplementPrice(group.id, complementId, price);
    },
    onSuccess: () => {
      toast.success("Preço atualizado.");
      setEditingPriceId(null);
      refresh();
    },
    onError
  });
  const removeMutation = useMutation({
    mutationFn: (complementId) => removeComplement(group.id, complementId),
    onSuccess: () => {
      toast.success("Opção removida do grupo.");
      refresh();
    },
    onError
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "ticket rise", children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "ticket-row",
        style: { width: "100%", background: "transparent", border: "none", cursor: "pointer", textAlign: "left" },
        onClick: onToggle,
        "aria-expanded": expanded,
        "aria-controls": `complement-group-panel-${group.id}`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: group.name }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
              lineNumber: 329,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
              complementGroupTypeLabel[group.complementGroupTypeId] ?? `Tipo ${group.complementGroupTypeId}`,
              " ·",
              " ",
              group.minSelection === 0 ? "opcional" : `mín. ${group.minSelection}`,
              " · máx. ",
              group.maxSelection,
              " ·",
              " ",
              group.complements.filter((c) => c.isActive).length,
              " opção(ões)"
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
              lineNumber: 330,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 328,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: expanded ? "▲" : "▼" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 336,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
        lineNumber: 320,
        columnNumber: 7
      },
      this
    ),
    expanded && /* @__PURE__ */ jsxDEV("div", { id: `complement-group-panel-${group.id}`, style: { padding: "0 16px 14px", display: "grid", gap: 10 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, justifyContent: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { minHeight: 40, padding: "0 12px", fontSize: "0.85rem" }, onClick: onEdit, children: "Editar grupo" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 342,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-danger", style: { minHeight: 40, padding: "0 12px", fontSize: "0.85rem" }, onClick: onDeactivate, children: "Desativar grupo" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 345,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
        lineNumber: 341,
        columnNumber: 11
      }, this),
      group.complements.filter((c) => c.isActive).length === 0 && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)", margin: 0, fontSize: "0.9rem" }, children: "Nenhuma opção neste grupo ainda." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
        lineNumber: 351,
        columnNumber: 9
      }, this),
      group.complements.filter((c) => c.isActive).map(
        (c) => editingPriceId === c.id ? /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 }, children: c.complementItemName }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 361,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              autoFocus: true,
              inputMode: "decimal",
              "aria-label": `Preço extra de ${c.complementItemName} em reais`,
              value: editPrice,
              onChange: (e) => setEditPrice(e.target.value),
              style: { width: 110 },
              onKeyDown: (e) => {
                if (e.key === "Enter") updatePriceMutation.mutate(c.id);
                else if (e.key === "Escape") setEditingPriceId(null);
              }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
              lineNumber: 362,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", loading: updatePriceMutation.isPending, onClick: () => updatePriceMutation.mutate(c.id), children: "Salvar" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 374,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", iconOnly: true, "aria-label": "Cancelar", onClick: () => setEditingPriceId(null), children: "✕" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 377,
            columnNumber: 19
          }, this)
        ] }, c.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 360,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { justifyContent: "space-between" }, children: [
          /* @__PURE__ */ jsxDEV("span", { children: c.complementItemName }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 383,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8 }, children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--amber)" }, children: c.extraPrice > 0 ? `+ ${formatBRL(c.extraPrice)}` : "sem custo" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
              lineNumber: 385,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "btn-ghost",
                style: { minHeight: 36, padding: "0 10px", fontSize: "0.8rem" },
                onClick: () => {
                  setEditingPriceId(c.id);
                  setEditPrice(String(c.extraPrice));
                },
                children: "Preço"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
                lineNumber: 388,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "btn-danger",
                style: { minHeight: 36, padding: "0 10px", fontSize: "0.8rem" },
                onClick: async () => {
                  if (await dialog.confirm({
                    title: "Remover opção",
                    message: `Remover "${c.complementItemName}" deste grupo?`,
                    confirmLabel: "Remover",
                    danger: true
                  }))
                    removeMutation.mutate(c.id);
                },
                children: "Remover"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
                lineNumber: 399,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 384,
            columnNumber: 19
          }, this)
        ] }, c.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 382,
          columnNumber: 9
        }, this)
      ),
      availableItems.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 8, marginTop: 4 }, children: [
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: addItemId,
            onChange: (e) => setAddItemId(e.target.value),
            "aria-label": `Selecionar complemento para adicionar ao grupo ${group.name}`,
            style: { flex: 1, minWidth: 160 },
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "", children: "Adicionar opção…" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
                lineNumber: 430,
                columnNumber: 17
              }, this),
              availableItems.map(
                (item) => /* @__PURE__ */ jsxDEV("option", { value: item.id, children: item.name }, item.id, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
                  lineNumber: 432,
                  columnNumber: 13
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 424,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            placeholder: "Preço extra (R$)…",
            "aria-label": "Preço extra em reais",
            inputMode: "decimal",
            value: addPrice,
            onChange: (e) => setAddPrice(e.target.value),
            style: { width: 140 }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
            lineNumber: 437,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Button, { loading: addMutation.isPending, disabled: addItemId === "", onClick: () => addMutation.mutate(), children: "Adicionar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
          lineNumber: 445,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
        lineNumber: 423,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)", margin: 0, fontSize: "0.85rem" }, children: "Todos os complementos cadastrados já estão neste grupo — cadastre mais na aba Itens." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
        lineNumber: 450,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
      lineNumber: 340,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx",
    lineNumber: 319,
    columnNumber: 5
  }, this);
}
_s2(GroupCard, "/HT7yfbi9/NJEy5QgjONBmsuX6Q=", false, function() {
  return [useQueryClient, useToast, useDialog, useMutation, useMutation, useMutation];
});
_c2 = GroupCard;
var _c, _c2;
$RefreshReg$(_c, "ComplementGroupsPanel");
$RefreshReg$(_c2, "GroupCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementGroupsPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEhROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVIUCxTQUFTQSxTQUFTQyxnQkFBZ0I7QUFDbkMsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3REO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsMEJBQTBCQyxpQkFBaUI7QUFFcEQsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxXQUFXQyxtQkFBbUI7QUFDdkMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBRTdCLE1BQU1DLFlBQVksRUFBRUMsTUFBTSxJQUFJQyx1QkFBdUIsS0FBS0MsY0FBYyxLQUFLQyxjQUFjLElBQUk7QUFHL0YsTUFBTUMsWUFBWUEsQ0FBQ0MsUUFBd0I7QUFDekMsUUFBTUMsUUFBUUMsT0FBT0YsR0FBRztBQUN4QixTQUFPRSxPQUFPQyxTQUFTRixLQUFLLEtBQUtBLFNBQVMsSUFBSUcsS0FBS0MsTUFBTUosS0FBSyxJQUFJO0FBQ3BFO0FBRU8sZ0JBQVNLLHdCQUF3QjtBQUFBQyxLQUFBO0FBQ3RDLFFBQU1DLGNBQWNwQyxlQUFlO0FBQ25DLFFBQU1xQyxRQUFRbkIsU0FBUztBQUN2QixRQUFNb0IsU0FBU25CLFVBQVU7QUFDekIsUUFBTSxFQUFFb0IsVUFBVSxJQUFJOUIsYUFBYTtBQUNuQyxRQUFNLENBQUMrQixTQUFTQyxVQUFVLElBQUk1QyxTQUFpRCxJQUFJO0FBQ25GLFFBQU0sQ0FBQzZDLE1BQU1DLE9BQU8sSUFBSTlDLFNBQW9CeUIsU0FBUztBQUNyRCxRQUFNLENBQUNzQixZQUFZQyxhQUFhLElBQUloRCxTQUF3QixJQUFJO0FBQ2hFLFFBQU0sQ0FBQ2lELE9BQU9DLFFBQVEsSUFBSWxELFNBQXdCLElBQUk7QUFFdEQsUUFBTW1ELGNBQWNqRCxTQUFTO0FBQUEsSUFDM0JrRCxVQUFVLENBQUMscUJBQXFCVixTQUFTO0FBQUEsSUFDekNXLFNBQVNBLE1BQU05QyxvQkFBb0JtQyxhQUFhLENBQUM7QUFBQSxFQUNuRCxDQUFDO0FBRUQsUUFBTVksYUFBYXBELFNBQVM7QUFBQSxJQUMxQmtELFVBQVUsQ0FBQyxvQkFBb0JWLFNBQVM7QUFBQSxJQUN4Q1csU0FBU0EsTUFBTTdDLG1CQUFtQmtDLGFBQWEsQ0FBQztBQUFBLEVBQ2xELENBQUM7QUFFRCxRQUFNYSxjQUFjeEQ7QUFBQUEsSUFDbEIsT0FBT3VELFdBQVdFLFFBQVEsSUFBSUMsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxRQUFRO0FBQUEsSUFDdEQsQ0FBQ0wsV0FBV0UsSUFBSTtBQUFBLEVBQ2xCO0FBRUEsUUFBTUksVUFBVUEsTUFBTSxLQUFLckIsWUFBWXNCLGtCQUFrQixFQUFFVCxVQUFVLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztBQUM1RixRQUFNVSxhQUFhQSxDQUFDQyxNQUFlYixTQUFTYSxhQUFhbEQsV0FBV2tELEVBQUVDLFVBQVUsa0JBQWtCO0FBRWxHLFFBQU1DLGFBQWFBLENBQUNDLFVBQTJDO0FBQzdEaEIsYUFBUyxJQUFJO0FBQ2JOLGVBQVdzQixLQUFLO0FBQ2hCcEI7QUFBQUEsTUFDRW9CLFVBQVUsUUFDTnpDLFlBQ0E7QUFBQSxRQUNFQyxNQUFNd0MsTUFBTXhDO0FBQUFBLFFBQ1pDLHVCQUF1QndDLE9BQU9ELE1BQU12QyxxQkFBcUI7QUFBQSxRQUN6REMsY0FBY3VDLE9BQU9ELE1BQU10QyxZQUFZO0FBQUEsUUFDdkNDLGNBQWNzQyxPQUFPRCxNQUFNckMsWUFBWTtBQUFBLE1BQ3pDO0FBQUEsSUFDTjtBQUFBLEVBQ0Y7QUFFQSxRQUFNdUMsaUJBQWlCbkUsWUFBWTtBQUFBLElBQ2pDb0UsWUFBWUEsTUFDVmhFO0FBQUFBLE1BQ0VxQyxhQUFhO0FBQUEsTUFDYkcsS0FBS25CLEtBQUs0QyxLQUFLO0FBQUEsTUFDZnJDLE9BQU9ZLEtBQUtsQixxQkFBcUI7QUFBQSxNQUNqQ0csVUFBVWUsS0FBS2pCLFlBQVk7QUFBQSxNQUMzQkUsVUFBVWUsS0FBS2hCLFlBQVk7QUFBQSxJQUM3QjtBQUFBLElBQ0YwQyxXQUFXQSxNQUFNO0FBQ2YvQixZQUFNZ0MsUUFBUSxlQUFlO0FBQzdCNUIsaUJBQVcsSUFBSTtBQUNmZ0IsY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBYSxTQUFTWDtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNWSxpQkFBaUJ6RSxZQUFZO0FBQUEsSUFDakNvRSxZQUFZQSxNQUNWM0Q7QUFBQUEsTUFDR2lDLFFBQW9DZ0M7QUFBQUEsTUFDckM5QixLQUFLbkIsS0FBSzRDLEtBQUs7QUFBQSxNQUNmckMsT0FBT1ksS0FBS2xCLHFCQUFxQjtBQUFBLE1BQ2pDRyxVQUFVZSxLQUFLakIsWUFBWTtBQUFBLE1BQzNCRSxVQUFVZSxLQUFLaEIsWUFBWTtBQUFBLElBQzdCO0FBQUEsSUFDRjBDLFdBQVdBLE1BQU07QUFDZi9CLFlBQU1nQyxRQUFRLG1CQUFtQjtBQUNqQzVCLGlCQUFXLElBQUk7QUFDZmdCLGNBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQWEsU0FBU1g7QUFBQUEsRUFDWCxDQUFDO0FBRUQsUUFBTWMscUJBQXFCM0UsWUFBWTtBQUFBLElBQ3JDb0UsWUFBWUEsQ0FBQ00sT0FBZXJFLDBCQUEwQnFFLEVBQUU7QUFBQSxJQUN4REosV0FBV0EsTUFBTTtBQUNmL0IsWUFBTWdDLFFBQVEsbUJBQW1CO0FBQ2pDWixjQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0FhLFNBQVNYO0FBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1lLGNBQWMvQyxVQUFVZSxLQUFLaEIsWUFBWSxJQUFJQyxVQUFVZSxLQUFLakIsWUFBWTtBQUU5RSxTQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFa0QsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDckM7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVELFNBQVMsUUFBUUUsZ0JBQWdCLFdBQVcsR0FDekUsaUNBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxlQUFjLFNBQVMsTUFBTWYsV0FBVyxLQUFLLEdBQUcsNEJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUNkLFlBQVk4QixXQUFXLHVCQUFDLGNBQVcsT0FBTzlCLFlBQVlGLE9BQU8sTUFBSywrQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRTtBQUFBLElBQzdGRSxZQUFZK0IsYUFBYSx1QkFBQyxnQkFBYSxNQUFNLEdBQUcsV0FBVyxNQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFFOUQsQ0FBQy9CLFlBQVkrQixjQUFjL0IsWUFBWUssTUFBTTJCLFVBQVUsT0FBTyxLQUM3RDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsT0FBTTtBQUFBLFFBQ04sYUFBWTtBQUFBLFFBQ1osUUFDRSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGVBQWMsU0FBUyxNQUFNbEIsV0FBVyxLQUFLLEdBQUcsNEJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRRztBQUFBLEtBSUhkLFlBQVlLLFFBQVEsSUFBSTRCO0FBQUFBLE1BQUksQ0FBQ2xCLFVBQzdCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQztBQUFBLFVBQ0EsVUFBVW5CLGVBQWVtQixNQUFNUztBQUFBQSxVQUMvQixVQUFVLE1BQU0zQixjQUFjLENBQUMyQixPQUFRQSxPQUFPVCxNQUFNUyxLQUFLLE9BQU9ULE1BQU1TLEVBQUc7QUFBQSxVQUN6RSxRQUFRLE1BQU1WLFdBQVdDLEtBQUs7QUFBQSxVQUM5QixjQUFjLFlBQVk7QUFDeEIsZ0JBQ0UsTUFBTXpCLE9BQU80QyxRQUFRO0FBQUEsY0FDbkJDLE9BQU87QUFBQSxjQUNQdEIsU0FBUyxjQUFjRSxNQUFNeEMsSUFBSTtBQUFBLGNBQ2pDNkQsY0FBYztBQUFBLGNBQ2RDLFFBQVE7QUFBQSxZQUNWLENBQUM7QUFFRFosaUNBQW1CYSxPQUFPdkIsTUFBTVMsRUFBRTtBQUFBLFVBQ3RDO0FBQUEsVUFDQTtBQUFBLFVBQ0EsU0FBU2I7QUFBQUE7QUFBQUEsUUFqQkpJLE1BQU1TO0FBQUFBLFFBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWtCc0I7QUFBQSxJQUV2QjtBQUFBLElBRUFoQyxZQUFZLFFBQ1gsdUJBQUMsU0FBTSxPQUFPQSxZQUFZLFFBQVEsK0JBQStCLGdCQUFnQixTQUFTLE1BQU1DLFdBQVcsSUFBSSxHQUM3RztBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixPQUFPQyxLQUFLbkI7QUFBQUEsVUFDWixVQUFVLENBQUNxQyxNQUFNakIsUUFBUSxFQUFFLEdBQUdELE1BQU1uQixNQUFNcUMsRUFBRTJCLE9BQU8xRCxNQUFNLENBQUM7QUFBQSxVQUMxRDtBQUFBLFVBQ0EsYUFBWTtBQUFBO0FBQUEsUUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLdUM7QUFBQSxNQUd2QztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sT0FBT2EsS0FBS2xCO0FBQUFBLFVBQ1osVUFBVSxDQUFDb0MsTUFBTWpCLFFBQVEsRUFBRSxHQUFHRCxNQUFNbEIsdUJBQXVCb0MsRUFBRTJCLE9BQU8xRCxNQUFNLENBQUM7QUFBQSxVQUUxRTJELGlCQUFPQyxRQUFROUUsd0JBQXdCLEVBQUVzRTtBQUFBQSxZQUFJLENBQUMsQ0FBQ1QsSUFBSWtCLEtBQUssTUFDdkQsdUJBQUMsWUFBZ0IsT0FBT2xCLElBQ3JCa0IsbUJBRFVsQixJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNEO0FBQUE7QUFBQSxRQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRW1CLE1BQU0sR0FBR0MsVUFBVSxJQUFJLEdBQ25DO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixXQUFVO0FBQUEsWUFDVixPQUFPbEQsS0FBS2pCO0FBQUFBLFlBQ1osVUFBVSxDQUFDbUMsTUFBTWpCLFFBQVEsRUFBRSxHQUFHRCxNQUFNakIsY0FBY21DLEVBQUUyQixPQUFPMUQsTUFBTSxDQUFDO0FBQUEsWUFDbEUsTUFBSztBQUFBO0FBQUEsVUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLMkIsS0FON0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRThELE1BQU0sR0FBR0MsVUFBVSxJQUFJLEdBQ25DO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixXQUFVO0FBQUEsWUFDVixPQUFPbEQsS0FBS2hCO0FBQUFBLFlBQ1osVUFBVSxDQUFDa0MsTUFBTWpCLFFBQVEsRUFBRSxHQUFHRCxNQUFNaEIsY0FBY2tDLEVBQUUyQixPQUFPMUQsTUFBTSxDQUFDO0FBQUEsWUFDbEUsTUFBSztBQUFBO0FBQUEsVUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLa0MsS0FOcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLE1BRUM2QyxlQUNDLHVCQUFDLE9BQUUsV0FBVSxjQUFhLE1BQUssU0FBUSx5REFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRDVCLFNBQ0MsdUJBQUMsT0FBRSxXQUFVLGNBQWEsTUFBSyxTQUM1QkEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFHRjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1I7QUFBQSxVQUNBLFNBQVNtQixlQUFlNEIsYUFBYXRCLGVBQWVzQjtBQUFBQSxVQUNwRCxVQUFVbkQsS0FBS25CLEtBQUs0QyxLQUFLLE1BQU0sTUFBTU87QUFBQUEsVUFDckMsU0FBUyxNQUFPbEMsWUFBWSxRQUFReUIsZUFBZXFCLE9BQU8sSUFBSWYsZUFBZWUsT0FBTztBQUFBLFVBQUc7QUFBQTtBQUFBLFFBTHpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0E3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThEQTtBQUFBLE9BN0dKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErR0E7QUFFSjtBQUFDbkQsR0ExTWVELHVCQUFxQjtBQUFBLFVBQ2ZsQyxnQkFDTmtCLFVBQ0NDLFdBQ09WLGNBTUZWLFVBS0RBLFVBNEJJRCxhQWlCQUEsYUFpQklBLFdBQVc7QUFBQTtBQUFBLEtBN0V4Qm9DO0FBc05oQixTQUFTNEQsVUFBVSxFQUFFL0IsT0FBT2dDLFVBQVVDLFVBQVVDLFFBQVFDLGNBQWM5QyxhQUFha0IsUUFBd0IsR0FBRztBQUFBNkIsTUFBQTtBQUM1RyxRQUFNL0QsY0FBY3BDLGVBQWU7QUFDbkMsUUFBTXFDLFFBQVFuQixTQUFTO0FBQ3ZCLFFBQU1vQixTQUFTbkIsVUFBVTtBQUN6QixRQUFNLENBQUNpRixXQUFXQyxZQUFZLElBQUl4RyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDeUcsVUFBVUMsV0FBVyxJQUFJMUcsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQzJHLGdCQUFnQkMsaUJBQWlCLElBQUk1RyxTQUF3QixJQUFJO0FBQ3hFLFFBQU0sQ0FBQzZHLFdBQVdDLFlBQVksSUFBSTlHLFNBQVMsRUFBRTtBQUU3QyxRQUFNK0csaUJBQWlCeEQsWUFBWUU7QUFBQUEsSUFDakMsQ0FBQ3VELFNBQVMsQ0FBQzlDLE1BQU0rQyxZQUFZQyxLQUFLLENBQUNDLE1BQU1BLEVBQUVDLHFCQUFxQkosS0FBS3JDLE1BQU13QyxFQUFFeEQsUUFBUTtBQUFBLEVBQ3ZGO0FBRUEsUUFBTUMsVUFBVUEsTUFBTSxLQUFLckIsWUFBWXNCLGtCQUFrQixFQUFFVCxVQUFVLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztBQUU1RixRQUFNaUUsY0FBY3BILFlBQVk7QUFBQSxJQUM5Qm9FLFlBQVlBLE1BQU07QUFDaEIsWUFBTWlELFFBQVFyRixPQUFPd0UsU0FBU2MsUUFBUSxLQUFLLEdBQUcsQ0FBQyxLQUFLO0FBQ3BELGFBQU9uSCxjQUFjOEQsTUFBTVMsSUFBSTFDLE9BQU9zRSxTQUFTLEdBQUdlLEtBQUs7QUFBQSxJQUN6RDtBQUFBLElBQ0EvQyxXQUFXQSxNQUFNO0FBQ2YvQixZQUFNZ0MsUUFBUSw0QkFBNEI7QUFDMUNnQyxtQkFBYSxFQUFFO0FBQ2ZFLGtCQUFZLEVBQUU7QUFDZDlDLGNBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQWE7QUFBQUEsRUFDRixDQUFDO0FBRUQsUUFBTStDLHNCQUFzQnZILFlBQVk7QUFBQSxJQUN0Q29FLFlBQVlBLENBQUNvRCxpQkFBeUI7QUFDcEMsWUFBTUgsUUFBUXJGLE9BQU80RSxVQUFVVSxRQUFRLEtBQUssR0FBRyxDQUFDLEtBQUs7QUFDckQsYUFBTzVHLHNCQUFzQnVELE1BQU1TLElBQUk4QyxjQUFjSCxLQUFLO0FBQUEsSUFDNUQ7QUFBQSxJQUNBL0MsV0FBV0EsTUFBTTtBQUNmL0IsWUFBTWdDLFFBQVEsbUJBQW1CO0FBQ2pDb0Msd0JBQWtCLElBQUk7QUFDdEJoRCxjQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0FhO0FBQUFBLEVBQ0YsQ0FBQztBQUVELFFBQU1pRCxpQkFBaUJ6SCxZQUFZO0FBQUEsSUFDakNvRSxZQUFZQSxDQUFDb0QsaUJBQXlCaEgsaUJBQWlCeUQsTUFBTVMsSUFBSThDLFlBQVk7QUFBQSxJQUM3RWxELFdBQVdBLE1BQU07QUFDZi9CLFlBQU1nQyxRQUFRLDBCQUEwQjtBQUN4Q1osY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBYTtBQUFBQSxFQUNGLENBQUM7QUFFRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFdBQVU7QUFBQSxRQUNWLE9BQU8sRUFBRWtELE9BQU8sUUFBUUMsWUFBWSxlQUFlQyxRQUFRLFFBQVFDLFFBQVEsV0FBV0MsV0FBVyxPQUFPO0FBQUEsUUFDeEcsU0FBUzVCO0FBQUFBLFFBQ1QsaUJBQWVEO0FBQUFBLFFBQ2YsaUJBQWUsMEJBQTBCaEMsTUFBTVMsRUFBRTtBQUFBLFFBRWpEO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUVHLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsbUNBQUMsVUFBTWIsZ0JBQU14QyxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtCO0FBQUEsWUFDbEIsdUJBQUMsVUFBSyxPQUFPLEVBQUVzRyxVQUFVLFVBQVVDLE9BQU8sbUJBQW1CLEdBQzFEbkg7QUFBQUEsdUNBQXlCb0QsTUFBTXZDLHFCQUFxQixLQUFLLFFBQVF1QyxNQUFNdkMscUJBQXFCO0FBQUEsY0FBRztBQUFBLGNBQUc7QUFBQSxjQUNsR3VDLE1BQU10QyxpQkFBaUIsSUFBSSxhQUFhLFFBQVFzQyxNQUFNdEMsWUFBWTtBQUFBLGNBQUc7QUFBQSxjQUFTc0MsTUFBTXJDO0FBQUFBLGNBQWE7QUFBQSxjQUFHO0FBQUEsY0FDcEdxQyxNQUFNK0MsWUFBWXhELE9BQU8sQ0FBQzBELE1BQU1BLEVBQUV4RCxRQUFRLEVBQUV3QjtBQUFBQSxjQUFPO0FBQUEsaUJBSHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFOEMsT0FBTyxtQkFBbUIsR0FBSS9CLHFCQUFXLE1BQU0sT0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQTtBQUFBO0FBQUEsTUFoQnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlCQTtBQUFBLElBRUNBLFlBQ0MsdUJBQUMsU0FBSSxJQUFJLDBCQUEwQmhDLE1BQU1TLEVBQUUsSUFBSSxPQUFPLEVBQUV1RCxTQUFTLGVBQWVwRCxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUN2RztBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFRCxTQUFTLFFBQVFDLEtBQUssR0FBR0MsZ0JBQWdCLFdBQVcsR0FDaEU7QUFBQSwrQkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGFBQVksT0FBTyxFQUFFbUQsV0FBVyxJQUFJRCxTQUFTLFVBQVVGLFVBQVUsVUFBVSxHQUFHLFNBQVM1QixRQUFRLDRCQUEvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsY0FBYSxPQUFPLEVBQUUrQixXQUFXLElBQUlELFNBQVMsVUFBVUYsVUFBVSxVQUFVLEdBQUcsU0FBUzNCLGNBQWMsK0JBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFFQ25DLE1BQU0rQyxZQUFZeEQsT0FBTyxDQUFDMEQsTUFBTUEsRUFBRXhELFFBQVEsRUFBRXdCLFdBQVcsS0FDdEQsdUJBQUMsT0FBRSxPQUFPLEVBQUU4QyxPQUFPLG9CQUFvQkcsUUFBUSxHQUFHSixVQUFVLFNBQVMsR0FBRyxnREFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFHRDlELE1BQU0rQyxZQUNKeEQsT0FBTyxDQUFDMEQsTUFBTUEsRUFBRXhELFFBQVEsRUFDeEJ5QjtBQUFBQSxRQUFJLENBQUMrQixNQUNKUixtQkFBbUJRLEVBQUV4QyxLQUNuQix1QkFBQyxTQUFlLFdBQVUsVUFBUyxPQUFPLEVBQUVJLEtBQUssRUFBRSxHQUNqRDtBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFZSxNQUFNLEVBQUUsR0FBSXFCLFlBQUVrQixzQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUNoRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUNWLGNBQVksa0JBQWtCbEIsRUFBRWtCLGtCQUFrQjtBQUFBLGNBQ2xELE9BQU94QjtBQUFBQSxjQUNQLFVBQVUsQ0FBQzlDLE1BQU0rQyxhQUFhL0MsRUFBRTJCLE9BQU8xRCxLQUFLO0FBQUEsY0FDNUMsT0FBTyxFQUFFMkYsT0FBTyxJQUFJO0FBQUEsY0FDcEIsV0FBVyxDQUFDNUQsTUFBTTtBQUNoQixvQkFBSUEsRUFBRXVFLFFBQVEsUUFBU2QscUJBQW9CL0IsT0FBTzBCLEVBQUV4QyxFQUFFO0FBQUEseUJBQzdDWixFQUFFdUUsUUFBUSxTQUFVMUIsbUJBQWtCLElBQUk7QUFBQSxjQUNyRDtBQUFBO0FBQUEsWUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVSTtBQUFBLFVBRUosdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBU1ksb0JBQW9CeEIsV0FBVyxTQUFTLE1BQU13QixvQkFBb0IvQixPQUFPMEIsRUFBRXhDLEVBQUUsR0FBRyxzQkFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBTyxNQUFLLE1BQUssVUFBUSxNQUFDLGNBQVcsWUFBVyxTQUFTLE1BQU1pQyxrQkFBa0IsSUFBSSxHQUFHLGlCQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFuQlFPLEVBQUV4QyxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkEsSUFFQSx1QkFBQyxTQUFlLFdBQVUsVUFBUyxPQUFPLEVBQUVLLGdCQUFnQixnQkFBZ0IsR0FDMUU7QUFBQSxpQ0FBQyxVQUFNbUMsWUFBRWtCLHNCQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsVUFDNUIsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFdEQsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLFlBQVcsT0FBTyxFQUFFa0QsT0FBTyxlQUFlLEdBQ3ZEZCxZQUFFb0IsYUFBYSxJQUFJLEtBQUt4SCxVQUFVb0csRUFBRW9CLFVBQVUsQ0FBQyxLQUFLLGVBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixPQUFPLEVBQUVKLFdBQVcsSUFBSUQsU0FBUyxVQUFVRixVQUFVLFNBQVM7QUFBQSxnQkFDOUQsU0FBUyxNQUFNO0FBQ2JwQixvQ0FBa0JPLEVBQUV4QyxFQUFFO0FBQ3RCbUMsK0JBQWEzQyxPQUFPZ0QsRUFBRW9CLFVBQVUsQ0FBQztBQUFBLGdCQUNuQztBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFSixXQUFXLElBQUlELFNBQVMsVUFBVUYsVUFBVSxTQUFTO0FBQUEsZ0JBQzlELFNBQVMsWUFBWTtBQUNuQixzQkFDRSxNQUFNdkYsT0FBTzRDLFFBQVE7QUFBQSxvQkFDbkJDLE9BQU87QUFBQSxvQkFDUHRCLFNBQVMsWUFBWW1ELEVBQUVrQixrQkFBa0I7QUFBQSxvQkFDekM5QyxjQUFjO0FBQUEsb0JBQ2RDLFFBQVE7QUFBQSxrQkFDVixDQUFDO0FBRURrQyxtQ0FBZWpDLE9BQU8wQixFQUFFeEMsRUFBRTtBQUFBLGdCQUM5QjtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlCQTtBQUFBLGVBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsYUFuQ1F3QyxFQUFFeEMsSUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0NBO0FBQUEsTUFFSjtBQUFBLE1BRURvQyxlQUFlNUIsU0FBUyxJQUN2Qix1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUosS0FBSyxHQUFHeUQsV0FBVyxFQUFFLEdBQ2hFO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9qQztBQUFBQSxZQUNQLFVBQVUsQ0FBQ3hDLE1BQU15QyxhQUFhekMsRUFBRTJCLE9BQU8xRCxLQUFLO0FBQUEsWUFDNUMsY0FBWSxrREFBa0RrQyxNQUFNeEMsSUFBSTtBQUFBLFlBQ3hFLE9BQU8sRUFBRW9FLE1BQU0sR0FBR0MsVUFBVSxJQUFJO0FBQUEsWUFFaEM7QUFBQSxxQ0FBQyxZQUFPLE9BQU0sSUFBRyxnQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQSxjQUNoQ2dCLGVBQWUzQjtBQUFBQSxnQkFBSSxDQUFDNEIsU0FDbkIsdUJBQUMsWUFBcUIsT0FBT0EsS0FBS3JDLElBQy9CcUMsZUFBS3RGLFFBREtzRixLQUFLckMsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBO0FBQUEsVUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGFBQVk7QUFBQSxZQUNaLGNBQVc7QUFBQSxZQUNYLFdBQVU7QUFBQSxZQUNWLE9BQU84QjtBQUFBQSxZQUNQLFVBQVUsQ0FBQzFDLE1BQU0yQyxZQUFZM0MsRUFBRTJCLE9BQU8xRCxLQUFLO0FBQUEsWUFDM0MsT0FBTyxFQUFFMkYsT0FBTyxJQUFJO0FBQUE7QUFBQSxVQU50QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNd0I7QUFBQSxRQUV4Qix1QkFBQyxVQUFPLFNBQVNOLFlBQVlyQixXQUFXLFVBQVVPLGNBQWMsSUFBSSxTQUFTLE1BQU1jLFlBQVk1QixPQUFPLEdBQUcseUJBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkEsSUFFQSx1QkFBQyxPQUFFLE9BQU8sRUFBRXdDLE9BQU8sb0JBQW9CRyxRQUFRLEdBQUdKLFVBQVUsVUFBVSxHQUFHLG9HQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQWhISjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0hBO0FBQUEsT0F2SUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlJQTtBQUVKO0FBQUMxQixJQS9MUUwsV0FBUztBQUFBLFVBQ0k5RixnQkFDTmtCLFVBQ0NDLFdBWUtyQixhQWNRQSxhQWFMQSxXQUFXO0FBQUE7QUFBQSxNQTFDM0JnRztBQUFTLElBQUF3QyxJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiYWRkQ29tcGxlbWVudCIsImNyZWF0ZUNvbXBsZW1lbnRHcm91cCIsImRlYWN0aXZhdGVDb21wbGVtZW50R3JvdXAiLCJnZXRDb21wbGVtZW50R3JvdXBzIiwiZ2V0Q29tcGxlbWVudEl0ZW1zIiwicmVtb3ZlQ29tcGxlbWVudCIsInVwZGF0ZUNvbXBsZW1lbnRHcm91cCIsInVwZGF0ZUNvbXBsZW1lbnRQcmljZSIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwiY29tcGxlbWVudEdyb3VwVHlwZUxhYmVsIiwiZm9ybWF0QlJMIiwiUXVlcnlFcnJvciIsIk1vZGFsIiwiQnV0dG9uIiwiVGV4dEZpZWxkIiwiU2VsZWN0RmllbGQiLCJ1c2VUb2FzdCIsInVzZURpYWxvZyIsIkVtcHR5U3RhdGUiLCJTa2VsZXRvbkxpc3QiLCJlbXB0eUZvcm0iLCJuYW1lIiwiY29tcGxlbWVudEdyb3VwVHlwZUlkIiwibWluU2VsZWN0aW9uIiwibWF4U2VsZWN0aW9uIiwicGFyc2VJbnQwIiwicmF3IiwidmFsdWUiLCJOdW1iZXIiLCJpc0Zpbml0ZSIsIk1hdGgiLCJ0cnVuYyIsIkNvbXBsZW1lbnRHcm91cHNQYW5lbCIsIl9zIiwicXVlcnlDbGllbnQiLCJ0b2FzdCIsImRpYWxvZyIsImNvbXBhbnlJZCIsImVkaXRpbmciLCJzZXRFZGl0aW5nIiwiZm9ybSIsInNldEZvcm0iLCJleHBhbmRlZElkIiwic2V0RXhwYW5kZWRJZCIsImVycm9yIiwic2V0RXJyb3IiLCJncm91cHNRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsIml0ZW1zUXVlcnkiLCJhY3RpdmVJdGVtcyIsImRhdGEiLCJmaWx0ZXIiLCJpIiwiaXNBY3RpdmUiLCJyZWZyZXNoIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJvbkFwaUVycm9yIiwiZSIsIm1lc3NhZ2UiLCJvcGVuRWRpdG9yIiwiZ3JvdXAiLCJTdHJpbmciLCJjcmVhdGVNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJ0cmltIiwib25TdWNjZXNzIiwic3VjY2VzcyIsIm9uRXJyb3IiLCJ1cGRhdGVNdXRhdGlvbiIsImlkIiwiZGVhY3RpdmF0ZU11dGF0aW9uIiwibWF4QmVsb3dNaW4iLCJkaXNwbGF5IiwiZ2FwIiwianVzdGlmeUNvbnRlbnQiLCJpc0Vycm9yIiwiaXNMb2FkaW5nIiwibGVuZ3RoIiwibWFwIiwiY29uZmlybSIsInRpdGxlIiwiY29uZmlybUxhYmVsIiwiZGFuZ2VyIiwibXV0YXRlIiwidGFyZ2V0IiwiT2JqZWN0IiwiZW50cmllcyIsImxhYmVsIiwiZmxleCIsIm1pbldpZHRoIiwiaXNQZW5kaW5nIiwiR3JvdXBDYXJkIiwiZXhwYW5kZWQiLCJvblRvZ2dsZSIsIm9uRWRpdCIsIm9uRGVhY3RpdmF0ZSIsIl9zMiIsImFkZEl0ZW1JZCIsInNldEFkZEl0ZW1JZCIsImFkZFByaWNlIiwic2V0QWRkUHJpY2UiLCJlZGl0aW5nUHJpY2VJZCIsInNldEVkaXRpbmdQcmljZUlkIiwiZWRpdFByaWNlIiwic2V0RWRpdFByaWNlIiwiYXZhaWxhYmxlSXRlbXMiLCJpdGVtIiwiY29tcGxlbWVudHMiLCJzb21lIiwiYyIsImNvbXBsZW1lbnRJdGVtSWQiLCJhZGRNdXRhdGlvbiIsInByaWNlIiwicmVwbGFjZSIsInVwZGF0ZVByaWNlTXV0YXRpb24iLCJjb21wbGVtZW50SWQiLCJyZW1vdmVNdXRhdGlvbiIsIndpZHRoIiwiYmFja2dyb3VuZCIsImJvcmRlciIsImN1cnNvciIsInRleHRBbGlnbiIsImZvbnRTaXplIiwiY29sb3IiLCJwYWRkaW5nIiwibWluSGVpZ2h0IiwibWFyZ2luIiwiY29tcGxlbWVudEl0ZW1OYW1lIiwia2V5IiwiZXh0cmFQcmljZSIsIm1hcmdpblRvcCIsIl9jIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNvbXBsZW1lbnRHcm91cHNQYW5lbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHtcclxuICBhZGRDb21wbGVtZW50LFxyXG4gIGNyZWF0ZUNvbXBsZW1lbnRHcm91cCxcclxuICBkZWFjdGl2YXRlQ29tcGxlbWVudEdyb3VwLFxyXG4gIGdldENvbXBsZW1lbnRHcm91cHMsXHJcbiAgZ2V0Q29tcGxlbWVudEl0ZW1zLFxyXG4gIHJlbW92ZUNvbXBsZW1lbnQsXHJcbiAgdXBkYXRlQ29tcGxlbWVudEdyb3VwLFxyXG4gIHVwZGF0ZUNvbXBsZW1lbnRQcmljZSxcclxufSBmcm9tIFwiLi9jb21wbGVtZW50c0FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IGNvbXBsZW1lbnRHcm91cFR5cGVMYWJlbCwgZm9ybWF0QlJMIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IENvbXBsZW1lbnRHcm91cFJlc3BvbnNlIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xyXG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gXCIuLi8uLi91aS9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IFRleHRGaWVsZCwgU2VsZWN0RmllbGQgfSBmcm9tIFwiLi4vLi4vdWkvRmllbGRcIjtcclxuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vLi4vdWkvVG9hc3RcIjtcclxuaW1wb3J0IHsgdXNlRGlhbG9nIH0gZnJvbSBcIi4uLy4uL3VpL0RpYWxvZ1wiO1xyXG5pbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSBcIi4uLy4uL3VpL0VtcHR5U3RhdGVcIjtcclxuaW1wb3J0IHsgU2tlbGV0b25MaXN0IH0gZnJvbSBcIi4uLy4uL3VpL1NrZWxldG9uXCI7XHJcblxyXG5jb25zdCBlbXB0eUZvcm0gPSB7IG5hbWU6IFwiXCIsIGNvbXBsZW1lbnRHcm91cFR5cGVJZDogXCIxXCIsIG1pblNlbGVjdGlvbjogXCIwXCIsIG1heFNlbGVjdGlvbjogXCIxXCIgfTtcclxudHlwZSBGb3JtU3RhdGUgPSB0eXBlb2YgZW1wdHlGb3JtO1xyXG5cclxuY29uc3QgcGFyc2VJbnQwID0gKHJhdzogc3RyaW5nKTogbnVtYmVyID0+IHtcclxuICBjb25zdCB2YWx1ZSA9IE51bWJlcihyYXcpO1xyXG4gIHJldHVybiBOdW1iZXIuaXNGaW5pdGUodmFsdWUpICYmIHZhbHVlID49IDAgPyBNYXRoLnRydW5jKHZhbHVlKSA6IDA7XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ29tcGxlbWVudEdyb3Vwc1BhbmVsKCkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgZGlhbG9nID0gdXNlRGlhbG9nKCk7XHJcbiAgY29uc3QgeyBjb21wYW55SWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IFtlZGl0aW5nLCBzZXRFZGl0aW5nXSA9IHVzZVN0YXRlPENvbXBsZW1lbnRHcm91cFJlc3BvbnNlIHwgXCJuZXdcIiB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlPEZvcm1TdGF0ZT4oZW1wdHlGb3JtKTtcclxuICBjb25zdCBbZXhwYW5kZWRJZCwgc2V0RXhwYW5kZWRJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBncm91cHNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJjb21wbGVtZW50LWdyb3Vwc1wiLCBjb21wYW55SWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0Q29tcGxlbWVudEdyb3Vwcyhjb21wYW55SWQgPz8gMSksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGl0ZW1zUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiY29tcGxlbWVudC1pdGVtc1wiLCBjb21wYW55SWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0Q29tcGxlbWVudEl0ZW1zKGNvbXBhbnlJZCA/PyAxKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgYWN0aXZlSXRlbXMgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gKGl0ZW1zUXVlcnkuZGF0YSA/PyBbXSkuZmlsdGVyKChpKSA9PiBpLmlzQWN0aXZlKSxcclxuICAgIFtpdGVtc1F1ZXJ5LmRhdGFdLFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHJlZnJlc2ggPSAoKSA9PiB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImNvbXBsZW1lbnQtZ3JvdXBzXCJdIH0pO1xyXG4gIGNvbnN0IG9uQXBpRXJyb3IgPSAoZTogdW5rbm93bikgPT4gc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEFwaUVycm9yID8gZS5tZXNzYWdlIDogXCJPcGVyYcOnw6NvIGZhbGhvdS5cIik7XHJcblxyXG4gIGNvbnN0IG9wZW5FZGl0b3IgPSAoZ3JvdXA6IENvbXBsZW1lbnRHcm91cFJlc3BvbnNlIHwgXCJuZXdcIikgPT4ge1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICBzZXRFZGl0aW5nKGdyb3VwKTtcclxuICAgIHNldEZvcm0oXHJcbiAgICAgIGdyb3VwID09PSBcIm5ld1wiXHJcbiAgICAgICAgPyBlbXB0eUZvcm1cclxuICAgICAgICA6IHtcclxuICAgICAgICAgICAgbmFtZTogZ3JvdXAubmFtZSxcclxuICAgICAgICAgICAgY29tcGxlbWVudEdyb3VwVHlwZUlkOiBTdHJpbmcoZ3JvdXAuY29tcGxlbWVudEdyb3VwVHlwZUlkKSxcclxuICAgICAgICAgICAgbWluU2VsZWN0aW9uOiBTdHJpbmcoZ3JvdXAubWluU2VsZWN0aW9uKSxcclxuICAgICAgICAgICAgbWF4U2VsZWN0aW9uOiBTdHJpbmcoZ3JvdXAubWF4U2VsZWN0aW9uKSxcclxuICAgICAgICAgIH0sXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNyZWF0ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgY3JlYXRlQ29tcGxlbWVudEdyb3VwKFxyXG4gICAgICAgIGNvbXBhbnlJZCA/PyAxLFxyXG4gICAgICAgIGZvcm0ubmFtZS50cmltKCksXHJcbiAgICAgICAgTnVtYmVyKGZvcm0uY29tcGxlbWVudEdyb3VwVHlwZUlkKSxcclxuICAgICAgICBwYXJzZUludDAoZm9ybS5taW5TZWxlY3Rpb24pLFxyXG4gICAgICAgIHBhcnNlSW50MChmb3JtLm1heFNlbGVjdGlvbiksXHJcbiAgICAgICksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkdydXBvIGNyaWFkby5cIik7XHJcbiAgICAgIHNldEVkaXRpbmcobnVsbCk7XHJcbiAgICAgIHJlZnJlc2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB1cGRhdGVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIHVwZGF0ZUNvbXBsZW1lbnRHcm91cChcclxuICAgICAgICAoZWRpdGluZyBhcyBDb21wbGVtZW50R3JvdXBSZXNwb25zZSkuaWQsXHJcbiAgICAgICAgZm9ybS5uYW1lLnRyaW0oKSxcclxuICAgICAgICBOdW1iZXIoZm9ybS5jb21wbGVtZW50R3JvdXBUeXBlSWQpLFxyXG4gICAgICAgIHBhcnNlSW50MChmb3JtLm1pblNlbGVjdGlvbiksXHJcbiAgICAgICAgcGFyc2VJbnQwKGZvcm0ubWF4U2VsZWN0aW9uKSxcclxuICAgICAgKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiR3J1cG8gYXR1YWxpemFkby5cIik7XHJcbiAgICAgIHNldEVkaXRpbmcobnVsbCk7XHJcbiAgICAgIHJlZnJlc2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBkZWFjdGl2YXRlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoaWQ6IG51bWJlcikgPT4gZGVhY3RpdmF0ZUNvbXBsZW1lbnRHcm91cChpZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkdydXBvIGRlc2F0aXZhZG8uXCIpO1xyXG4gICAgICByZWZyZXNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgbWF4QmVsb3dNaW4gPSBwYXJzZUludDAoZm9ybS5tYXhTZWxlY3Rpb24pIDwgcGFyc2VJbnQwKGZvcm0ubWluU2VsZWN0aW9uKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgb25DbGljaz17KCkgPT4gb3BlbkVkaXRvcihcIm5ld1wiKX0+XHJcbiAgICAgICAgICArIE5vdm8gZ3J1cG9cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7Z3JvdXBzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17Z3JvdXBzUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBncnVwb3MgZGUgY29tcGxlbWVudG9zXCIgLz59XHJcbiAgICAgIHtncm91cHNRdWVyeS5pc0xvYWRpbmcgJiYgPFNrZWxldG9uTGlzdCByb3dzPXszfSByb3dIZWlnaHQ9ezY0fSAvPn1cclxuXHJcbiAgICAgIHshZ3JvdXBzUXVlcnkuaXNMb2FkaW5nICYmIChncm91cHNRdWVyeS5kYXRhPy5sZW5ndGggPz8gMCkgPT09IDAgJiYgKFxyXG4gICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICBpY29uPVwi8J+NlFwiXHJcbiAgICAgICAgICB0aXRsZT1cIk5lbmh1bSBncnVwbyBkZSBjb21wbGVtZW50b3NcIlxyXG4gICAgICAgICAgZGVzY3JpcHRpb249J0NyaWUgdW0gZ3J1cG8gKGV4LjogXCJFc2NvbGhhIHVtYSBiZWJpZGFcIikgZSBkZXBvaXMgdmluY3VsZSBvcMOnw7VlcyBkYSBhYmEgSXRlbnMgYSBlbGUuJ1xyXG4gICAgICAgICAgYWN0aW9uPXtcclxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIiBvbkNsaWNrPXsoKSA9PiBvcGVuRWRpdG9yKFwibmV3XCIpfT5cclxuICAgICAgICAgICAgICArIE5vdm8gZ3J1cG9cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsoZ3JvdXBzUXVlcnkuZGF0YSA/PyBbXSkubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgIDxHcm91cENhcmRcclxuICAgICAgICAgIGtleT17Z3JvdXAuaWR9XHJcbiAgICAgICAgICBncm91cD17Z3JvdXB9XHJcbiAgICAgICAgICBleHBhbmRlZD17ZXhwYW5kZWRJZCA9PT0gZ3JvdXAuaWR9XHJcbiAgICAgICAgICBvblRvZ2dsZT17KCkgPT4gc2V0RXhwYW5kZWRJZCgoaWQpID0+IChpZCA9PT0gZ3JvdXAuaWQgPyBudWxsIDogZ3JvdXAuaWQpKX1cclxuICAgICAgICAgIG9uRWRpdD17KCkgPT4gb3BlbkVkaXRvcihncm91cCl9XHJcbiAgICAgICAgICBvbkRlYWN0aXZhdGU9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgIGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBcIkRlc2F0aXZhciBncnVwb1wiLFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogYERlc2F0aXZhciBcIiR7Z3JvdXAubmFtZX1cIj8gUHJvZHV0b3MgdmluY3VsYWRvcyBkZWl4YW0gZGUgb2ZlcmVjZXIgZXN0ZSBncnVwby5gLFxyXG4gICAgICAgICAgICAgICAgY29uZmlybUxhYmVsOiBcIkRlc2F0aXZhclwiLFxyXG4gICAgICAgICAgICAgICAgZGFuZ2VyOiB0cnVlLFxyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICBkZWFjdGl2YXRlTXV0YXRpb24ubXV0YXRlKGdyb3VwLmlkKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBhY3RpdmVJdGVtcz17YWN0aXZlSXRlbXN9XHJcbiAgICAgICAgICBvbkVycm9yPXtvbkFwaUVycm9yfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICkpfVxyXG5cclxuICAgICAge2VkaXRpbmcgIT09IG51bGwgJiYgKFxyXG4gICAgICAgIDxNb2RhbCB0aXRsZT17ZWRpdGluZyA9PT0gXCJuZXdcIiA/IFwiTm92byBncnVwbyBkZSBjb21wbGVtZW50b3NcIiA6IFwiRWRpdGFyIGdydXBvXCJ9IG9uQ2xvc2U9eygpID0+IHNldEVkaXRpbmcobnVsbCl9PlxyXG4gICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICBsYWJlbD1cIk5vbWUgZG8gZ3J1cG9cIlxyXG4gICAgICAgICAgICB2YWx1ZT17Zm9ybS5uYW1lfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZXguOiBFc2NvbGhhIHVtYSBiZWJpZGFcIlxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8U2VsZWN0RmllbGRcclxuICAgICAgICAgICAgbGFiZWw9XCJUaXBvXCJcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm0uY29tcGxlbWVudEdyb3VwVHlwZUlkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBjb21wbGVtZW50R3JvdXBUeXBlSWQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoY29tcGxlbWVudEdyb3VwVHlwZUxhYmVsKS5tYXAoKFtpZCwgbGFiZWxdKSA9PiAoXHJcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2lkfSB2YWx1ZT17aWR9PlxyXG4gICAgICAgICAgICAgICAge2xhYmVsfVxyXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvU2VsZWN0RmllbGQ+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIj5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTQwIH19PlxyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiTcOtbmltbyBkZSBzZWxlw6fDtWVzXCJcclxuICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubWluU2VsZWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgbWluU2VsZWN0aW9uOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgIGhpbnQ9XCIwID0gZ3J1cG8gb3BjaW9uYWxcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNDAgfX0+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJNw6F4aW1vIGRlIHNlbGXDp8O1ZXNcIlxyXG4gICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwibnVtZXJpY1wiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5tYXhTZWxlY3Rpb259XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBtYXhTZWxlY3Rpb246IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgaGludD1cIjEgPSBlc2NvbGhhIMO6bmljYSAocsOhZGlvKVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7bWF4QmVsb3dNaW4gJiYgKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCIgcm9sZT1cImFsZXJ0XCI+XHJcbiAgICAgICAgICAgICAgTyBtw6F4aW1vIG7Do28gcG9kZSBzZXIgbWVub3IgcXVlIG8gbcOtbmltby5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgIGxvYWRpbmc9e2NyZWF0ZU11dGF0aW9uLmlzUGVuZGluZyB8fCB1cGRhdGVNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtmb3JtLm5hbWUudHJpbSgpID09PSBcIlwiIHx8IG1heEJlbG93TWlufVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiAoZWRpdGluZyA9PT0gXCJuZXdcIiA/IGNyZWF0ZU11dGF0aW9uLm11dGF0ZSgpIDogdXBkYXRlTXV0YXRpb24ubXV0YXRlKCkpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBTYWx2YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgR3JvdXBDYXJkUHJvcHMge1xyXG4gIGdyb3VwOiBDb21wbGVtZW50R3JvdXBSZXNwb25zZTtcclxuICBleHBhbmRlZDogYm9vbGVhbjtcclxuICBvblRvZ2dsZTogKCkgPT4gdm9pZDtcclxuICBvbkVkaXQ6ICgpID0+IHZvaWQ7XHJcbiAgb25EZWFjdGl2YXRlOiAoKSA9PiB2b2lkO1xyXG4gIGFjdGl2ZUl0ZW1zOiB7IGlkOiBudW1iZXI7IG5hbWU6IHN0cmluZzsgaXNBY3RpdmU6IGJvb2xlYW4gfVtdO1xyXG4gIG9uRXJyb3I6IChlOiB1bmtub3duKSA9PiB2b2lkO1xyXG59XHJcblxyXG5mdW5jdGlvbiBHcm91cENhcmQoeyBncm91cCwgZXhwYW5kZWQsIG9uVG9nZ2xlLCBvbkVkaXQsIG9uRGVhY3RpdmF0ZSwgYWN0aXZlSXRlbXMsIG9uRXJyb3IgfTogR3JvdXBDYXJkUHJvcHMpIHtcclxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG4gIGNvbnN0IGRpYWxvZyA9IHVzZURpYWxvZygpO1xyXG4gIGNvbnN0IFthZGRJdGVtSWQsIHNldEFkZEl0ZW1JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRkUHJpY2UsIHNldEFkZFByaWNlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlZGl0aW5nUHJpY2VJZCwgc2V0RWRpdGluZ1ByaWNlSWRdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2VkaXRQcmljZSwgc2V0RWRpdFByaWNlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBhdmFpbGFibGVJdGVtcyA9IGFjdGl2ZUl0ZW1zLmZpbHRlcihcclxuICAgIChpdGVtKSA9PiAhZ3JvdXAuY29tcGxlbWVudHMuc29tZSgoYykgPT4gYy5jb21wbGVtZW50SXRlbUlkID09PSBpdGVtLmlkICYmIGMuaXNBY3RpdmUpLFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHJlZnJlc2ggPSAoKSA9PiB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImNvbXBsZW1lbnQtZ3JvdXBzXCJdIH0pO1xyXG5cclxuICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHtcclxuICAgICAgY29uc3QgcHJpY2UgPSBOdW1iZXIoYWRkUHJpY2UucmVwbGFjZShcIixcIiwgXCIuXCIpKSB8fCAwO1xyXG4gICAgICByZXR1cm4gYWRkQ29tcGxlbWVudChncm91cC5pZCwgTnVtYmVyKGFkZEl0ZW1JZCksIHByaWNlKTtcclxuICAgIH0sXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIk9ww6fDo28gYWRpY2lvbmFkYSBhbyBncnVwby5cIik7XHJcbiAgICAgIHNldEFkZEl0ZW1JZChcIlwiKTtcclxuICAgICAgc2V0QWRkUHJpY2UoXCJcIik7XHJcbiAgICAgIHJlZnJlc2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB1cGRhdGVQcmljZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKGNvbXBsZW1lbnRJZDogbnVtYmVyKSA9PiB7XHJcbiAgICAgIGNvbnN0IHByaWNlID0gTnVtYmVyKGVkaXRQcmljZS5yZXBsYWNlKFwiLFwiLCBcIi5cIikpIHx8IDA7XHJcbiAgICAgIHJldHVybiB1cGRhdGVDb21wbGVtZW50UHJpY2UoZ3JvdXAuaWQsIGNvbXBsZW1lbnRJZCwgcHJpY2UpO1xyXG4gICAgfSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiUHJlw6dvIGF0dWFsaXphZG8uXCIpO1xyXG4gICAgICBzZXRFZGl0aW5nUHJpY2VJZChudWxsKTtcclxuICAgICAgcmVmcmVzaCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJlbW92ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKGNvbXBsZW1lbnRJZDogbnVtYmVyKSA9PiByZW1vdmVDb21wbGVtZW50KGdyb3VwLmlkLCBjb21wbGVtZW50SWQpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJPcMOnw6NvIHJlbW92aWRhIGRvIGdydXBvLlwiKTtcclxuICAgICAgcmVmcmVzaCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldCByaXNlXCI+XHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCJcclxuICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIGJhY2tncm91bmQ6IFwidHJhbnNwYXJlbnRcIiwgYm9yZGVyOiBcIm5vbmVcIiwgY3Vyc29yOiBcInBvaW50ZXJcIiwgdGV4dEFsaWduOiBcImxlZnRcIiB9fVxyXG4gICAgICAgIG9uQ2xpY2s9e29uVG9nZ2xlfVxyXG4gICAgICAgIGFyaWEtZXhwYW5kZWQ9e2V4cGFuZGVkfVxyXG4gICAgICAgIGFyaWEtY29udHJvbHM9e2Bjb21wbGVtZW50LWdyb3VwLXBhbmVsLSR7Z3JvdXAuaWR9YH1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgIDxzcGFuPntncm91cC5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgIHtjb21wbGVtZW50R3JvdXBUeXBlTGFiZWxbZ3JvdXAuY29tcGxlbWVudEdyb3VwVHlwZUlkXSA/PyBgVGlwbyAke2dyb3VwLmNvbXBsZW1lbnRHcm91cFR5cGVJZH1gfSDCt3tcIiBcIn1cclxuICAgICAgICAgICAge2dyb3VwLm1pblNlbGVjdGlvbiA9PT0gMCA/IFwib3BjaW9uYWxcIiA6IGBtw61uLiAke2dyb3VwLm1pblNlbGVjdGlvbn1gfSDCtyBtw6F4LiB7Z3JvdXAubWF4U2VsZWN0aW9ufSDCt3tcIiBcIn1cclxuICAgICAgICAgICAge2dyb3VwLmNvbXBsZW1lbnRzLmZpbHRlcigoYykgPT4gYy5pc0FjdGl2ZSkubGVuZ3RofSBvcMOnw6NvKMO1ZXMpXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PntleHBhbmRlZCA/IFwi4payXCIgOiBcIuKWvFwifTwvc3Bhbj5cclxuICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICB7ZXhwYW5kZWQgJiYgKFxyXG4gICAgICAgIDxkaXYgaWQ9e2Bjb21wbGVtZW50LWdyb3VwLXBhbmVsLSR7Z3JvdXAuaWR9YH0gc3R5bGU9e3sgcGFkZGluZzogXCIwIDE2cHggMTRweFwiLCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCB9fT5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogOCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCIgc3R5bGU9e3sgbWluSGVpZ2h0OiA0MCwgcGFkZGluZzogXCIwIDEycHhcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19IG9uQ2xpY2s9e29uRWRpdH0+XHJcbiAgICAgICAgICAgICAgRWRpdGFyIGdydXBvXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZGFuZ2VyXCIgc3R5bGU9e3sgbWluSGVpZ2h0OiA0MCwgcGFkZGluZzogXCIwIDEycHhcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19IG9uQ2xpY2s9e29uRGVhY3RpdmF0ZX0+XHJcbiAgICAgICAgICAgICAgRGVzYXRpdmFyIGdydXBvXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2dyb3VwLmNvbXBsZW1lbnRzLmZpbHRlcigoYykgPT4gYy5pc0FjdGl2ZSkubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgPHAgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBtYXJnaW46IDAsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgIE5lbmh1bWEgb3DDp8OjbyBuZXN0ZSBncnVwbyBhaW5kYS5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7Z3JvdXAuY29tcGxlbWVudHNcclxuICAgICAgICAgICAgLmZpbHRlcigoYykgPT4gYy5pc0FjdGl2ZSlcclxuICAgICAgICAgICAgLm1hcCgoYykgPT5cclxuICAgICAgICAgICAgICBlZGl0aW5nUHJpY2VJZCA9PT0gYy5pZCA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjLmlkfSBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZsZXg6IDEgfX0+e2MuY29tcGxlbWVudEl0ZW1OYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFByZcOnbyBleHRyYSBkZSAke2MuY29tcGxlbWVudEl0ZW1OYW1lfSBlbSByZWFpc2B9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRQcmljZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRQcmljZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDExMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB1cGRhdGVQcmljZU11dGF0aW9uLm11dGF0ZShjLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGUua2V5ID09PSBcIkVzY2FwZVwiKSBzZXRFZGl0aW5nUHJpY2VJZChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIGxvYWRpbmc9e3VwZGF0ZVByaWNlTXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB1cGRhdGVQcmljZU11dGF0aW9uLm11dGF0ZShjLmlkKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgU2FsdmFyXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIGljb25Pbmx5IGFyaWEtbGFiZWw9XCJDYW5jZWxhclwiIG9uQ2xpY2s9eygpID0+IHNldEVkaXRpbmdQcmljZUlkKG51bGwpfT5cclxuICAgICAgICAgICAgICAgICAgICDinJVcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2MuaWR9IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2MuY29tcGxlbWVudEl0ZW1OYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1hbWJlcilcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjLmV4dHJhUHJpY2UgPiAwID8gYCsgJHtmb3JtYXRCUkwoYy5leHRyYVByaWNlKX1gIDogXCJzZW0gY3VzdG9cIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWluSGVpZ2h0OiAzNiwgcGFkZGluZzogXCIwIDEwcHhcIiwgZm9udFNpemU6IFwiMC44cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1ByaWNlSWQoYy5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRQcmljZShTdHJpbmcoYy5leHRyYVByaWNlKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFByZcOnb1xyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDM2LCBwYWRkaW5nOiBcIjAgMTBweFwiLCBmb250U2l6ZTogXCIwLjhyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgZGlhbG9nLmNvbmZpcm0oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiUmVtb3ZlciBvcMOnw6NvXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBgUmVtb3ZlciBcIiR7Yy5jb21wbGVtZW50SXRlbU5hbWV9XCIgZGVzdGUgZ3J1cG8/YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJSZW1vdmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlbW92ZU11dGF0aW9uLm11dGF0ZShjLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUmVtb3ZlclxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAge2F2YWlsYWJsZUl0ZW1zLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiA4LCBtYXJnaW5Ub3A6IDQgfX0+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2FkZEl0ZW1JZH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QWRkSXRlbUlkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BTZWxlY2lvbmFyIGNvbXBsZW1lbnRvIHBhcmEgYWRpY2lvbmFyIGFvIGdydXBvICR7Z3JvdXAubmFtZX1gfVxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BZGljaW9uYXIgb3DDp8Ojb+KApjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAge2F2YWlsYWJsZUl0ZW1zLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17aXRlbS5pZH0gdmFsdWU9e2l0ZW0uaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlByZcOnbyBleHRyYSAoUiQp4oCmXCJcclxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJQcmXDp28gZXh0cmEgZW0gcmVhaXNcIlxyXG4gICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YWRkUHJpY2V9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFkZFByaWNlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAxNDAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxCdXR0b24gbG9hZGluZz17YWRkTXV0YXRpb24uaXNQZW5kaW5nfSBkaXNhYmxlZD17YWRkSXRlbUlkID09PSBcIlwifSBvbkNsaWNrPXsoKSA9PiBhZGRNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgICAgICBBZGljaW9uYXJcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8cCBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIG1hcmdpbjogMCwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgIFRvZG9zIG9zIGNvbXBsZW1lbnRvcyBjYWRhc3RyYWRvcyBqw6EgZXN0w6NvIG5lc3RlIGdydXBvIOKAlCBjYWRhc3RyZSBtYWlzIG5hIGFiYSBJdGVucy5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvQ29tcGxlbWVudEdyb3Vwc1BhbmVsLnRzeCJ9