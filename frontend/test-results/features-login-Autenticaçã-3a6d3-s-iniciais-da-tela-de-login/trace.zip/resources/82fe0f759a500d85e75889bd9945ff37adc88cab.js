import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/tabs/TabInicio.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { formatBRL } from "/src/lib/types.ts";
import { quickActions, deriveOrderBadge, badgeToneVar, orderLabel, elapsedLabel } from "/src/features/waiter/utils.ts";
export function TabInicio({ myOpenTablesCount, myTotalTables, comandaOrders, myOrders, totalTablesAmount, totalComandasAmount, latestOrders, tablesById, comandasById, canSeeCaixa, onTabChange, onQuickAction, onOrderClick }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "waiter-stats-row", style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "10px", marginBottom: "16px" }, children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "waiter-stat-card",
          onClick: () => onTabChange("mesas"),
          style: { cursor: "pointer", margin: 0 },
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "waiter-stat-value mono-num", children: [
              myOpenTablesCount,
              " ",
              /* @__PURE__ */ jsxDEV("small", { children: [
                "/",
                myTotalTables || "—"
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
                lineNumber: 51,
                columnNumber: 45
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
              lineNumber: 50,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "waiter-stat-label", children: "Mesas" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
              lineNumber: 53,
              columnNumber: 21
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 44,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "waiter-stat-card",
          onClick: () => onTabChange("comandas"),
          style: { cursor: "pointer", margin: 0 },
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "waiter-stat-value mono-num", children: comandaOrders.length }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
              lineNumber: 61,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "waiter-stat-label", children: "Comandas" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
              lineNumber: 62,
              columnNumber: 21
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 55,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "waiter-stat-card",
          onClick: () => onTabChange("pedidos"),
          style: { cursor: "pointer", margin: 0 },
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "waiter-stat-value mono-num", children: myOrders.length }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
              lineNumber: 70,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "waiter-stat-label", children: "Pedidos ativos" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
              lineNumber: 71,
              columnNumber: 21
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 64,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
      lineNumber: 43,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: "10px", marginBottom: "16px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "waiter-highlight-card", style: { margin: 0 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "waiter-highlight-label", children: "Mesas em aberto" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 77,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "waiter-highlight-value mono-num", children: formatBRL(totalTablesAmount) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 78,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
        lineNumber: 76,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "waiter-highlight-card", style: { margin: 0 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "waiter-highlight-label", children: "Comandas em aberto" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 81,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "waiter-highlight-value mono-num", children: formatBRL(totalComandasAmount) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 82,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
        lineNumber: 80,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
      lineNumber: 75,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("section", { id: "waiter-latest-orders", className: "waiter-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "waiter-section-head", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "waiter-section-title", children: "Últimos pedidos" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 88,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "waiter-link-btn", onClick: () => onTabChange("pedidos"), children: "Ver todos" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 89,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
        lineNumber: 87,
        columnNumber: 17
      }, this),
      latestOrders.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "waiter-empty", children: "Nenhum pedido em aberto na sua praça." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
        lineNumber: 92,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "waiter-order-list", children: latestOrders.map((order) => {
        const badge = deriveOrderBadge(order);
        return /* @__PURE__ */ jsxDEV("button", { type: "button", className: "waiter-order-row", onClick: () => onOrderClick(order.id), children: [
          /* @__PURE__ */ jsxDEV("span", { className: "waiter-order-info", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "waiter-order-title", children: orderLabel(order, tablesById, comandasById) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
              lineNumber: 100,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "waiter-order-meta", children: [
              order.items.length,
              " itens · ",
              elapsedLabel(order.openedAt)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
              lineNumber: 101,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
            lineNumber: 99,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "waiter-order-badge", style: { "--w-badge": badgeToneVar[badge.tone] }, children: badge.label }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
            lineNumber: 103,
            columnNumber: 37
          }, this)
        ] }, order.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 98,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
        lineNumber: 94,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
      lineNumber: 86,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "waiter-section", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "waiter-section-title", children: "Ações rápidas" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
        lineNumber: 112,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "waiter-quick-grid", children: quickActions.filter((action) => action.key !== "turno" || canSeeCaixa).map(
        (action, idx) => /* @__PURE__ */ jsxDEV("button", { type: "button", className: "waiter-quick-tile", onClick: () => onQuickAction(action.key), children: [
          /* @__PURE__ */ jsxDEV("span", { className: "waiter-quick-icon", "aria-hidden": "true", children: action.icon }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
            lineNumber: 116,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "waiter-quick-label", children: action.label }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
            lineNumber: 117,
            columnNumber: 29
          }, this)
        ] }, `${action.key}-${idx}`, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
          lineNumber: 115,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
        lineNumber: 113,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
      lineNumber: 111,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx",
    lineNumber: 42,
    columnNumber: 5
  }, this);
}
_c = TabInicio;
var _c;
$RefreshReg$(_c, "TabInicio");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabInicio.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JRLG1CQVNvQyxjQVRwQzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCUixTQUFTQSxpQkFBZ0U7QUFDekUsU0FBeUJDLGNBQXNCQyxrQkFBa0JDLGNBQWNDLFlBQVlDLG9CQUFvQjtBQWtCeEcsZ0JBQVNDLFVBQVUsRUFBRUMsbUJBQW1CQyxlQUFlQyxlQUFlQyxVQUFVQyxtQkFBbUJDLHFCQUFxQkMsY0FBY0MsWUFBWUMsY0FBY0MsYUFBYUMsYUFBYUMsZUFBZUMsYUFBNkIsR0FBRztBQUM1TyxTQUNJLG1DQUNJO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG9CQUFtQixPQUFPLEVBQUVDLFNBQVMsUUFBUUMscUJBQXFCLGtCQUFrQkMsS0FBSyxRQUFRQyxjQUFjLE9BQU8sR0FDakk7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsU0FBUyxNQUFNTixZQUFZLE9BQU87QUFBQSxVQUNsQyxPQUFPLEVBQUVPLFFBQVEsV0FBV0MsUUFBUSxFQUFFO0FBQUEsVUFFdEM7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsOEJBQ1hsQjtBQUFBQTtBQUFBQSxjQUFrQjtBQUFBLGNBQUMsdUJBQUMsV0FBTTtBQUFBO0FBQUEsZ0JBQUVDLGlCQUFpQjtBQUFBLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBLGlCQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUscUJBQW9CLHFCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBO0FBQUE7QUFBQSxRQVQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTVMsWUFBWSxVQUFVO0FBQUEsVUFDckMsT0FBTyxFQUFFTyxRQUFRLFdBQVdDLFFBQVEsRUFBRTtBQUFBLFVBRXRDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDhCQUE4QmhCLHdCQUFjaUIsVUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxZQUNuRSx1QkFBQyxVQUFLLFdBQVUscUJBQW9CLHdCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBO0FBQUE7QUFBQSxRQVBoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTVQsWUFBWSxTQUFTO0FBQUEsVUFDcEMsT0FBTyxFQUFFTyxRQUFRLFdBQVdDLFFBQVEsRUFBRTtBQUFBLFVBRXRDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDhCQUE4QmYsbUJBQVNnQixVQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzlELHVCQUFDLFVBQUssV0FBVSxxQkFBb0IsOEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUE7QUFBQTtBQUFBLFFBUHREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVOLFNBQVMsUUFBUUUsS0FBSyxRQUFRQyxjQUFjLE9BQU8sR0FDN0Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUseUJBQXdCLE9BQU8sRUFBRUUsUUFBUSxFQUFFLEdBQ3REO0FBQUEsK0JBQUMsVUFBSyxXQUFVLDBCQUF5QiwrQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQ3hELHVCQUFDLFVBQUssV0FBVSxtQ0FBbUN6QixvQkFBVVcsaUJBQWlCLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxXQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFBd0IsT0FBTyxFQUFFYyxRQUFRLEVBQUUsR0FDdEQ7QUFBQSwrQkFBQyxVQUFLLFdBQVUsMEJBQXlCLGtDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0QsdUJBQUMsVUFBSyxXQUFVLG1DQUFtQ3pCLG9CQUFVWSxtQkFBbUIsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRjtBQUFBLFdBRnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLElBQUcsd0JBQXVCLFdBQVUsa0JBQ3pDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHdCQUF1QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQ3BELHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsbUJBQWtCLFNBQVMsTUFBTUssWUFBWSxTQUFTLEdBQUcseUJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0c7QUFBQSxXQUZ0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNDSixhQUFhYSxXQUFXLElBQ3JCLHVCQUFDLE9BQUUsV0FBVSxnQkFBZSxxREFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRSxJQUVqRSx1QkFBQyxTQUFJLFdBQVUscUJBQ1ZiLHVCQUFhYyxJQUFJLENBQUNDLFVBQVU7QUFDekIsY0FBTUMsUUFBUTNCLGlCQUFpQjBCLEtBQUs7QUFDcEMsZUFDSSx1QkFBQyxZQUFzQixNQUFLLFVBQVMsV0FBVSxvQkFBbUIsU0FBUyxNQUFNVCxhQUFhUyxNQUFNRSxFQUFFLEdBQ2xHO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFCQUNaO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHNCQUFzQjFCLHFCQUFXd0IsT0FBT2QsWUFBWUMsWUFBWSxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLFlBQ2xGLHVCQUFDLFVBQUssV0FBVSxxQkFBcUJhO0FBQUFBLG9CQUFNRyxNQUFNTDtBQUFBQSxjQUFPO0FBQUEsY0FBVXJCLGFBQWF1QixNQUFNSSxRQUFRO0FBQUEsaUJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStGO0FBQUEsZUFGbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHNCQUFxQixPQUFPLEVBQUUsYUFBYTdCLGFBQWEwQixNQUFNSSxJQUFJLEVBQUUsR0FBcUJKLGdCQUFNSyxTQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxSDtBQUFBLGFBTDVHTixNQUFNRSxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxNQUVSLENBQUMsS0FaTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQXJCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsa0JBQ2Y7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0JBQXVCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtEO0FBQUEsTUFDbEQsdUJBQUMsU0FBSSxXQUFVLHFCQUNWN0IsdUJBQWFrQyxPQUFPLENBQUNDLFdBQVdBLE9BQU9DLFFBQVEsV0FBV3JCLFdBQVcsRUFBRVc7QUFBQUEsUUFBSSxDQUFDUyxRQUFRRSxRQUNqRix1QkFBQyxZQUFvQyxNQUFLLFVBQVMsV0FBVSxxQkFBb0IsU0FBUyxNQUFNcEIsY0FBY2tCLE9BQU9DLEdBQUcsR0FDcEg7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUJBQW9CLGVBQVksUUFBUUQsaUJBQU9HLFFBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDcEUsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQkgsaUJBQU9GLFNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsYUFGMUMsR0FBR0UsT0FBT0MsR0FBRyxJQUFJQyxHQUFHLElBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLE1BQ0gsS0FOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLE9BL0VKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnRkE7QUFFUjtBQUFDRSxLQXBGZWxDO0FBQVMsSUFBQWtDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImZvcm1hdEJSTCIsInF1aWNrQWN0aW9ucyIsImRlcml2ZU9yZGVyQmFkZ2UiLCJiYWRnZVRvbmVWYXIiLCJvcmRlckxhYmVsIiwiZWxhcHNlZExhYmVsIiwiVGFiSW5pY2lvIiwibXlPcGVuVGFibGVzQ291bnQiLCJteVRvdGFsVGFibGVzIiwiY29tYW5kYU9yZGVycyIsIm15T3JkZXJzIiwidG90YWxUYWJsZXNBbW91bnQiLCJ0b3RhbENvbWFuZGFzQW1vdW50IiwibGF0ZXN0T3JkZXJzIiwidGFibGVzQnlJZCIsImNvbWFuZGFzQnlJZCIsImNhblNlZUNhaXhhIiwib25UYWJDaGFuZ2UiLCJvblF1aWNrQWN0aW9uIiwib25PcmRlckNsaWNrIiwiZGlzcGxheSIsImdyaWRUZW1wbGF0ZUNvbHVtbnMiLCJnYXAiLCJtYXJnaW5Cb3R0b20iLCJjdXJzb3IiLCJtYXJnaW4iLCJsZW5ndGgiLCJtYXAiLCJvcmRlciIsImJhZGdlIiwiaWQiLCJpdGVtcyIsIm9wZW5lZEF0IiwidG9uZSIsImxhYmVsIiwiZmlsdGVyIiwiYWN0aW9uIiwia2V5IiwiaWR4IiwiaWNvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRhYkluaWNpby50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHR5cGUgeyBDU1NQcm9wZXJ0aWVzIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IGZvcm1hdEJSTCwgT3JkZXJSZXNwb25zZSwgVGFibGVSZXNwb25zZSwgQ29tYW5kYVJlc3BvbnNlIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgeyBRdWlja0FjdGlvbktleSwgcXVpY2tBY3Rpb25zLCBUYWJLZXksIGRlcml2ZU9yZGVyQmFkZ2UsIGJhZGdlVG9uZVZhciwgb3JkZXJMYWJlbCwgZWxhcHNlZExhYmVsIH0gZnJvbSBcIi4uLy4uL3V0aWxzXCI7XHJcblxyXG5pbnRlcmZhY2UgVGFiSW5pY2lvUHJvcHMge1xyXG4gICAgbXlPcGVuVGFibGVzQ291bnQ6IG51bWJlcjtcclxuICAgIG15VG90YWxUYWJsZXM6IG51bWJlcjtcclxuICAgIGNvbWFuZGFPcmRlcnM6IE9yZGVyUmVzcG9uc2VbXTtcclxuICAgIG15T3JkZXJzOiBPcmRlclJlc3BvbnNlW107XHJcbiAgICB0b3RhbFRhYmxlc0Ftb3VudDogbnVtYmVyO1xyXG4gICAgdG90YWxDb21hbmRhc0Ftb3VudDogbnVtYmVyO1xyXG4gICAgbGF0ZXN0T3JkZXJzOiBPcmRlclJlc3BvbnNlW107XHJcbiAgICB0YWJsZXNCeUlkOiBNYXA8bnVtYmVyLCBUYWJsZVJlc3BvbnNlPjtcclxuICAgIGNvbWFuZGFzQnlJZDogTWFwPG51bWJlciwgQ29tYW5kYVJlc3BvbnNlPjtcclxuICAgIGNhblNlZUNhaXhhOiBib29sZWFuO1xyXG4gICAgb25UYWJDaGFuZ2U6IChrZXk6IFRhYktleSkgPT4gdm9pZDtcclxuICAgIG9uUXVpY2tBY3Rpb246IChrZXk6IFF1aWNrQWN0aW9uS2V5KSA9PiB2b2lkO1xyXG4gICAgb25PcmRlckNsaWNrOiAob3JkZXJJZDogbnVtYmVyKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVGFiSW5pY2lvKHsgbXlPcGVuVGFibGVzQ291bnQsIG15VG90YWxUYWJsZXMsIGNvbWFuZGFPcmRlcnMsIG15T3JkZXJzLCB0b3RhbFRhYmxlc0Ftb3VudCwgdG90YWxDb21hbmRhc0Ftb3VudCwgbGF0ZXN0T3JkZXJzLCB0YWJsZXNCeUlkLCBjb21hbmRhc0J5SWQsIGNhblNlZUNhaXhhLCBvblRhYkNoYW5nZSwgb25RdWlja0FjdGlvbiwgb25PcmRlckNsaWNrIH06IFRhYkluaWNpb1Byb3BzKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2FpdGVyLXN0YXRzLXJvd1wiIHN0eWxlPXt7IGRpc3BsYXk6ICdncmlkJywgZ3JpZFRlbXBsYXRlQ29sdW1uczogJ3JlcGVhdCgzLCAxZnIpJywgZ2FwOiAnMTBweCcsIG1hcmdpbkJvdHRvbTogJzE2cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIndhaXRlci1zdGF0LWNhcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVGFiQ2hhbmdlKFwibWVzYXNcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY3Vyc29yOiBcInBvaW50ZXJcIiwgbWFyZ2luOiAwIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLXN0YXQtdmFsdWUgbW9uby1udW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge215T3BlblRhYmxlc0NvdW50fSA8c21hbGw+L3tteVRvdGFsVGFibGVzIHx8IFwi4oCUXCJ9PC9zbWFsbD5cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLXN0YXQtbGFiZWxcIj5NZXNhczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIndhaXRlci1zdGF0LWNhcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVGFiQ2hhbmdlKFwiY29tYW5kYXNcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY3Vyc29yOiBcInBvaW50ZXJcIiwgbWFyZ2luOiAwIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLXN0YXQtdmFsdWUgbW9uby1udW1cIj57Y29tYW5kYU9yZGVycy5sZW5ndGh9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIndhaXRlci1zdGF0LWxhYmVsXCI+Q29tYW5kYXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3YWl0ZXItc3RhdC1jYXJkXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblRhYkNoYW5nZShcInBlZGlkb3NcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY3Vyc29yOiBcInBvaW50ZXJcIiwgbWFyZ2luOiAwIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLXN0YXQtdmFsdWUgbW9uby1udW1cIj57bXlPcmRlcnMubGVuZ3RofTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3YWl0ZXItc3RhdC1sYWJlbFwiPlBlZGlkb3MgYXRpdm9zPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdhcDogJzEwcHgnLCBtYXJnaW5Cb3R0b206ICcxNnB4JyB9fT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2FpdGVyLWhpZ2hsaWdodC1jYXJkXCIgc3R5bGU9e3sgbWFyZ2luOiAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIndhaXRlci1oaWdobGlnaHQtbGFiZWxcIj5NZXNhcyBlbSBhYmVydG88L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLWhpZ2hsaWdodC12YWx1ZSBtb25vLW51bVwiPntmb3JtYXRCUkwodG90YWxUYWJsZXNBbW91bnQpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3YWl0ZXItaGlnaGxpZ2h0LWNhcmRcIiBzdHlsZT17eyBtYXJnaW46IDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLWhpZ2hsaWdodC1sYWJlbFwiPkNvbWFuZGFzIGVtIGFiZXJ0bzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3YWl0ZXItaGlnaGxpZ2h0LXZhbHVlIG1vbm8tbnVtXCI+e2Zvcm1hdEJSTCh0b3RhbENvbWFuZGFzQW1vdW50KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8c2VjdGlvbiBpZD1cIndhaXRlci1sYXRlc3Qtb3JkZXJzXCIgY2xhc3NOYW1lPVwid2FpdGVyLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2FpdGVyLXNlY3Rpb24taGVhZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ3YWl0ZXItc2VjdGlvbi10aXRsZVwiPsOabHRpbW9zIHBlZGlkb3M8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cIndhaXRlci1saW5rLWJ0blwiIG9uQ2xpY2s9eygpID0+IG9uVGFiQ2hhbmdlKFwicGVkaWRvc1wiKX0+VmVyIHRvZG9zPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHtsYXRlc3RPcmRlcnMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIndhaXRlci1lbXB0eVwiPk5lbmh1bSBwZWRpZG8gZW0gYWJlcnRvIG5hIHN1YSBwcmHDp2EuPC9wPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndhaXRlci1vcmRlci1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsYXRlc3RPcmRlcnMubWFwKChvcmRlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFkZ2UgPSBkZXJpdmVPcmRlckJhZGdlKG9yZGVyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e29yZGVyLmlkfSB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwid2FpdGVyLW9yZGVyLXJvd1wiIG9uQ2xpY2s9eygpID0+IG9uT3JkZXJDbGljayhvcmRlci5pZCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3YWl0ZXItb3JkZXItaW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLW9yZGVyLXRpdGxlXCI+e29yZGVyTGFiZWwob3JkZXIsIHRhYmxlc0J5SWQsIGNvbWFuZGFzQnlJZCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLW9yZGVyLW1ldGFcIj57b3JkZXIuaXRlbXMubGVuZ3RofSBpdGVucyDCtyB7ZWxhcHNlZExhYmVsKG9yZGVyLm9wZW5lZEF0KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid2FpdGVyLW9yZGVyLWJhZGdlXCIgc3R5bGU9e3sgXCItLXctYmFkZ2VcIjogYmFkZ2VUb25lVmFyW2JhZGdlLnRvbmVdIH0gYXMgQ1NTUHJvcGVydGllc30+e2JhZGdlLmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwid2FpdGVyLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ3YWl0ZXItc2VjdGlvbi10aXRsZVwiPkHDp8O1ZXMgcsOhcGlkYXM8L2gyPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3YWl0ZXItcXVpY2stZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtxdWlja0FjdGlvbnMuZmlsdGVyKChhY3Rpb24pID0+IGFjdGlvbi5rZXkgIT09IFwidHVybm9cIiB8fCBjYW5TZWVDYWl4YSkubWFwKChhY3Rpb24sIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGtleT17YCR7YWN0aW9uLmtleX0tJHtpZHh9YH0gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cIndhaXRlci1xdWljay10aWxlXCIgb25DbGljaz17KCkgPT4gb25RdWlja0FjdGlvbihhY3Rpb24ua2V5KX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3YWl0ZXItcXVpY2staWNvblwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPnthY3Rpb24uaWNvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3YWl0ZXItcXVpY2stbGFiZWxcIj57YWN0aW9uLmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy93YWl0ZXIvY29tcG9uZW50cy90YWJzL1RhYkluaWNpby50c3gifQ==