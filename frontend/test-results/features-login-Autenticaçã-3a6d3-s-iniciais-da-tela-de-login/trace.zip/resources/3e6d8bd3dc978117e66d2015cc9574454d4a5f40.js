import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Toast.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Toast.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { swalToast } from "/src/lib/swal.ts";
const iconByTone = {
  success: "success",
  error: "error",
  info: "info"
};
function push(tone, message) {
  void swalToast.fire({
    icon: iconByTone[tone],
    title: message,
    timer: tone === "error" ? 6e3 : 3500,
    customClass: {
      popup: `sb-swal-toast sb-swal-toast--${tone}`
    }
  });
}
const toastApi = {
  success: (m) => push("success", m),
  error: (m) => push("error", m),
  info: (m) => push("info", m)
};
export function ToastProvider({ children }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Toast.tsx",
    lineNumber: 60,
    columnNumber: 10
  }, this);
}
_c = ToastProvider;
export function useToast() {
  return toastApi;
}
var _c;
$RefreshReg$(_c, "ToastProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Toast.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Toast.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NTOzs7Ozs7Ozs7Ozs7Ozs7O0FBdkNULFNBQVNBLGlCQUFpQjtBQVUxQixNQUFNQyxhQUE4RDtBQUFBLEVBQ2xFQyxTQUFTO0FBQUEsRUFDVEMsT0FBTztBQUFBLEVBQ1BDLE1BQU07QUFDUjtBQUVBLFNBQVNDLEtBQUtDLE1BQWlCQyxTQUFpQjtBQUM5QyxPQUFLUCxVQUFVUSxLQUFLO0FBQUEsSUFDbEJDLE1BQU1SLFdBQVdLLElBQUk7QUFBQSxJQUNyQkksT0FBT0g7QUFBQUEsSUFDUEksT0FBT0wsU0FBUyxVQUFVLE1BQU87QUFBQSxJQUNqQ00sYUFBYTtBQUFBLE1BQ1hDLE9BQU8sZ0NBQWdDUCxJQUFJO0FBQUEsSUFDN0M7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUVBLE1BQU1RLFdBQXFCO0FBQUEsRUFDekJaLFNBQVNBLENBQUNhLE1BQU1WLEtBQUssV0FBV1UsQ0FBQztBQUFBLEVBQ2pDWixPQUFPQSxDQUFDWSxNQUFNVixLQUFLLFNBQVNVLENBQUM7QUFBQSxFQUM3QlgsTUFBTUEsQ0FBQ1csTUFBTVYsS0FBSyxRQUFRVSxDQUFDO0FBQzdCO0FBT08sZ0JBQVNDLGNBQWMsRUFBRUMsU0FBa0MsR0FBRztBQUNuRSxTQUFPLG1DQUFHQSxZQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBWTtBQUNyQjtBQUFDQyxLQUZlRjtBQUlULGdCQUFTRyxXQUFxQjtBQUNuQyxTQUFPTDtBQUNUO0FBQUMsSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsic3dhbFRvYXN0IiwiaWNvbkJ5VG9uZSIsInN1Y2Nlc3MiLCJlcnJvciIsImluZm8iLCJwdXNoIiwidG9uZSIsIm1lc3NhZ2UiLCJmaXJlIiwiaWNvbiIsInRpdGxlIiwidGltZXIiLCJjdXN0b21DbGFzcyIsInBvcHVwIiwidG9hc3RBcGkiLCJtIiwiVG9hc3RQcm92aWRlciIsImNoaWxkcmVuIiwiX2MiLCJ1c2VUb2FzdCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUb2FzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgc3dhbFRvYXN0IH0gZnJvbSBcIi4uL2xpYi9zd2FsXCI7XHJcblxyXG50eXBlIFRvYXN0VG9uZSA9IFwic3VjY2Vzc1wiIHwgXCJlcnJvclwiIHwgXCJpbmZvXCI7XHJcblxyXG5pbnRlcmZhY2UgVG9hc3RBcGkge1xyXG4gIHN1Y2Nlc3M6IChtZXNzYWdlOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgZXJyb3I6IChtZXNzYWdlOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgaW5mbzogKG1lc3NhZ2U6IHN0cmluZykgPT4gdm9pZDtcclxufVxyXG5cclxuY29uc3QgaWNvbkJ5VG9uZTogUmVjb3JkPFRvYXN0VG9uZSwgXCJzdWNjZXNzXCIgfCBcImVycm9yXCIgfCBcImluZm9cIj4gPSB7XHJcbiAgc3VjY2VzczogXCJzdWNjZXNzXCIsXHJcbiAgZXJyb3I6IFwiZXJyb3JcIixcclxuICBpbmZvOiBcImluZm9cIixcclxufTtcclxuXHJcbmZ1bmN0aW9uIHB1c2godG9uZTogVG9hc3RUb25lLCBtZXNzYWdlOiBzdHJpbmcpIHtcclxuICB2b2lkIHN3YWxUb2FzdC5maXJlKHtcclxuICAgIGljb246IGljb25CeVRvbmVbdG9uZV0sXHJcbiAgICB0aXRsZTogbWVzc2FnZSxcclxuICAgIHRpbWVyOiB0b25lID09PSBcImVycm9yXCIgPyA2MDAwIDogMzUwMCxcclxuICAgIGN1c3RvbUNsYXNzOiB7XHJcbiAgICAgIHBvcHVwOiBgc2Itc3dhbC10b2FzdCBzYi1zd2FsLXRvYXN0LS0ke3RvbmV9YCxcclxuICAgIH0sXHJcbiAgfSk7XHJcbn1cclxuXHJcbmNvbnN0IHRvYXN0QXBpOiBUb2FzdEFwaSA9IHtcclxuICBzdWNjZXNzOiAobSkgPT4gcHVzaChcInN1Y2Nlc3NcIiwgbSksXHJcbiAgZXJyb3I6IChtKSA9PiBwdXNoKFwiZXJyb3JcIiwgbSksXHJcbiAgaW5mbzogKG0pID0+IHB1c2goXCJpbmZvXCIsIG0pLFxyXG59O1xyXG5cclxuLyoqXHJcbiAqIE9zIHRvYXN0cyBkbyBTd2VldEFsZXJ0MiBzZSBlbXBpbGhhbSBlIHNlIHJlbW92ZW0gc296aW5ob3MgZm9yYSBkYSDDoXJ2b3JlXHJcbiAqIGRvIFJlYWN0IOKAlCBuw6NvIHByZWNpc2EgbWFpcyBkZSBlc3RhZG8vUHJvdmlkZXIuIE1hbnRpZG8gY29tbyBwYXNzdGhyb3VnaCBzw7NcclxuICogcGFyYSBuw6NvIHF1ZWJyYXIgcXVlbSBhaW5kYSBtb250YSA8VG9hc3RQcm92aWRlcj4gZW0gbWFpbi50c3guXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gVG9hc3RQcm92aWRlcih7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0Tm9kZSB9KSB7XHJcbiAgcmV0dXJuIDw+e2NoaWxkcmVufTwvPjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVzZVRvYXN0KCk6IFRvYXN0QXBpIHtcclxuICByZXR1cm4gdG9hc3RBcGk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL3VpL1RvYXN0LnRzeCJ9