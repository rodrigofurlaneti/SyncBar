import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=ca0b4140"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { BrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import App from "/src/App.tsx";
import { ToastProvider } from "/src/ui/Toast.tsx";
import { DialogProvider } from "/src/ui/Dialog.tsx";
import { ErrorBoundary } from "/src/components/ErrorBoundary.tsx";
import "/node_modules/sweetalert2/dist/sweetalert2.min.css";
import "/src/styles/global.css";
const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 1e4, refetchOnWindowFocus: true }
  }
});
ReactDOM.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(ErrorBoundary, { children: /* @__PURE__ */ jsxDEV(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxDEV(ToastProvider, { children: /* @__PURE__ */ jsxDEV(DialogProvider, { children: /* @__PURE__ */ jsxDEV(BrowserRouter, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/main.tsx",
    lineNumber: 25,
    columnNumber: 15
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/main.tsx",
    lineNumber: 24,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/main.tsx",
    lineNumber: 23,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/main.tsx",
    lineNumber: 22,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/main.tsx",
    lineNumber: 21,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/main.tsx",
    lineNumber: 20,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/main.tsx",
    lineNumber: 19,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JjO0FBeEJkLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQUNyQixTQUFTQyxhQUFhQywyQkFBMkI7QUFDakQsU0FBU0MscUJBQXFCO0FBQzlCLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxxQkFBcUI7QUFDOUIsT0FBTztBQUNQLE9BQU87QUFFUCxNQUFNQyxjQUFjLElBQUlQLFlBQVk7QUFBQSxFQUNsQ1EsZ0JBQWdCO0FBQUEsSUFDZEMsU0FBUyxFQUFFQyxPQUFPLEdBQUdDLFdBQVcsS0FBUUMsc0JBQXNCLEtBQUs7QUFBQSxFQUNyRTtBQUNGLENBQUM7QUFFRGIsU0FBU2MsV0FBV0MsU0FBU0MsZUFBZSxNQUFNLENBQUUsRUFBRUM7QUFBQUEsRUFDcEQsdUJBQUMsTUFBTSxZQUFOLEVBQ0MsaUNBQUMsaUJBQ0MsaUNBQUMsdUJBQW9CLFFBQVFULGFBQzNCLGlDQUFDLGlCQUNDLGlDQUFDLGtCQUNDLGlDQUFDLGlCQUNDLGlDQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFJLEtBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBQ0YiLCJuYW1lcyI6WyJSZWFjdCIsIlJlYWN0RE9NIiwiUXVlcnlDbGllbnQiLCJRdWVyeUNsaWVudFByb3ZpZGVyIiwiQnJvd3NlclJvdXRlciIsIkFwcCIsIlRvYXN0UHJvdmlkZXIiLCJEaWFsb2dQcm92aWRlciIsIkVycm9yQm91bmRhcnkiLCJxdWVyeUNsaWVudCIsImRlZmF1bHRPcHRpb25zIiwicXVlcmllcyIsInJldHJ5Iiwic3RhbGVUaW1lIiwicmVmZXRjaE9uV2luZG93Rm9jdXMiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJtYWluLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBSZWFjdERPTSBmcm9tIFwicmVhY3QtZG9tL2NsaWVudFwiO1xyXG5pbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgQnJvd3NlclJvdXRlciB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBBcHAgZnJvbSBcIi4vQXBwXCI7XHJcbmltcG9ydCB7IFRvYXN0UHJvdmlkZXIgfSBmcm9tIFwiLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyBEaWFsb2dQcm92aWRlciB9IGZyb20gXCIuL3VpL0RpYWxvZ1wiO1xyXG5pbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSBcIi4vY29tcG9uZW50cy9FcnJvckJvdW5kYXJ5XCI7XHJcbmltcG9ydCBcInN3ZWV0YWxlcnQyL2Rpc3Qvc3dlZXRhbGVydDIubWluLmNzc1wiO1xyXG5pbXBvcnQgXCIuL3N0eWxlcy9nbG9iYWwuY3NzXCI7XHJcblxyXG5jb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCh7XHJcbiAgZGVmYXVsdE9wdGlvbnM6IHtcclxuICAgIHF1ZXJpZXM6IHsgcmV0cnk6IDEsIHN0YWxlVGltZTogMTBfMDAwLCByZWZldGNoT25XaW5kb3dGb2N1czogdHJ1ZSB9LFxyXG4gIH0sXHJcbn0pO1xyXG5cclxuUmVhY3RET00uY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIikhKS5yZW5kZXIoXHJcbiAgPFJlYWN0LlN0cmljdE1vZGU+XHJcbiAgICA8RXJyb3JCb3VuZGFyeT5cclxuICAgICAgPFF1ZXJ5Q2xpZW50UHJvdmlkZXIgY2xpZW50PXtxdWVyeUNsaWVudH0+XHJcbiAgICAgICAgPFRvYXN0UHJvdmlkZXI+XHJcbiAgICAgICAgICA8RGlhbG9nUHJvdmlkZXI+XHJcbiAgICAgICAgICAgIDxCcm93c2VyUm91dGVyPlxyXG4gICAgICAgICAgICAgIDxBcHAgLz5cclxuICAgICAgICAgICAgPC9Ccm93c2VyUm91dGVyPlxyXG4gICAgICAgICAgPC9EaWFsb2dQcm92aWRlcj5cclxuICAgICAgICA8L1RvYXN0UHJvdmlkZXI+XHJcbiAgICAgIDwvUXVlcnlDbGllbnRQcm92aWRlcj5cclxuICAgIDwvRXJyb3JCb3VuZGFyeT5cclxuICA8L1JlYWN0LlN0cmljdE1vZGU+LFxyXG4pO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvbWFpbi50c3gifQ==