import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/access/FeatureGate.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/FeatureGate.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { featurePath, useMyFeatures } from "/src/features/access/hooks.ts";
export function FeatureGate({ code, children }) {
  _s();
  const featuresQuery = useMyFeatures();
  if (featuresQuery.isLoading) return null;
  const data = featuresQuery.data;
  const allowed = data?.canManageAccess || data?.features.includes(code);
  if (allowed) return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/FeatureGate.tsx",
    lineNumber: 36,
    columnNumber: 23
  }, this);
  const firstAllowed = data?.features.find((f) => featurePath[f] !== void 0);
  return /* @__PURE__ */ jsxDEV(Navigate, { to: firstAllowed ? featurePath[firstAllowed] : "/sem-acesso", replace: true }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/FeatureGate.tsx",
    lineNumber: 39,
    columnNumber: 10
  }, this);
}
_s(FeatureGate, "a5P5B565tUr9rZvlmICwiaUpNkU=", false, function() {
  return [useMyFeatures];
});
_c = FeatureGate;
export function NoAccessPage() {
  return /* @__PURE__ */ jsxDEV("main", { style: { display: "grid", placeItems: "center", minHeight: "60vh" }, children: /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", display: "grid", gap: 8 }, children: [
    /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "2rem" }, children: "Sem telas liberadas" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/FeatureGate.tsx",
      lineNumber: 46,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)" }, children: "Peça ao gerente para conceder acesso na tela Acessos." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/FeatureGate.tsx",
      lineNumber: 47,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/FeatureGate.tsx",
    lineNumber: 45,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/FeatureGate.tsx",
    lineNumber: 44,
    columnNumber: 5
  }, this);
}
_c2 = NoAccessPage;
var _c, _c2;
$RefreshReg$(_c, "FeatureGate");
$RefreshReg$(_c2, "NoAccessPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/FeatureGate.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/FeatureGate.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFmdEIsU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLGFBQWFDLHFCQUFxQjtBQU9wQyxnQkFBU0MsWUFBWSxFQUFFQyxNQUFNQyxTQUFnQixHQUFHO0FBQUFDLEtBQUE7QUFDckQsUUFBTUMsZ0JBQWdCTCxjQUFjO0FBRXBDLE1BQUlLLGNBQWNDLFVBQVcsUUFBTztBQUVwQyxRQUFNQyxPQUFPRixjQUFjRTtBQUMzQixRQUFNQyxVQUFVRCxNQUFNRSxtQkFBbUJGLE1BQU1HLFNBQVNDLFNBQVNULElBQUk7QUFDckUsTUFBSU0sUUFBUyxRQUFPLG1DQUFHTCxZQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBWTtBQUVoQyxRQUFNUyxlQUFlTCxNQUFNRyxTQUFTRyxLQUFLLENBQUNDLE1BQU1mLFlBQVllLENBQUMsTUFBTUMsTUFBUztBQUM1RSxTQUFPLHVCQUFDLFlBQVMsSUFBSUgsZUFBZWIsWUFBWWEsWUFBWSxJQUFJLGVBQWUsU0FBTyxRQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQStFO0FBQ3hGO0FBQUNSLEdBWGVILGFBQVc7QUFBQSxVQUNIRCxhQUFhO0FBQUE7QUFBQSxLQURyQkM7QUFhVCxnQkFBU2UsZUFBZTtBQUM3QixTQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxTQUFTLFFBQVFDLFlBQVksVUFBVUMsV0FBVyxPQUFPLEdBQ3RFLGlDQUFDLFNBQUksT0FBTyxFQUFFQyxXQUFXLFVBQVVILFNBQVMsUUFBUUksS0FBSyxFQUFFLEdBQ3pEO0FBQUEsMkJBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFQyxVQUFVLE9BQU8sR0FBRyxtQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRTtBQUFBLElBQzFFLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGlCQUFpQixHQUFHLHFFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQTtBQUVKO0FBQUNDLE1BWGVSO0FBQVksSUFBQVMsSUFBQUQ7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIk5hdmlnYXRlIiwiZmVhdHVyZVBhdGgiLCJ1c2VNeUZlYXR1cmVzIiwiRmVhdHVyZUdhdGUiLCJjb2RlIiwiY2hpbGRyZW4iLCJfcyIsImZlYXR1cmVzUXVlcnkiLCJpc0xvYWRpbmciLCJkYXRhIiwiYWxsb3dlZCIsImNhbk1hbmFnZUFjY2VzcyIsImZlYXR1cmVzIiwiaW5jbHVkZXMiLCJmaXJzdEFsbG93ZWQiLCJmaW5kIiwiZiIsInVuZGVmaW5lZCIsIk5vQWNjZXNzUGFnZSIsImRpc3BsYXkiLCJwbGFjZUl0ZW1zIiwibWluSGVpZ2h0IiwidGV4dEFsaWduIiwiZ2FwIiwiZm9udFNpemUiLCJjb2xvciIsIl9jMiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkZlYXR1cmVHYXRlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IGZlYXR1cmVQYXRoLCB1c2VNeUZlYXR1cmVzIH0gZnJvbSBcIi4vaG9va3NcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgY29kZTogc3RyaW5nO1xyXG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBGZWF0dXJlR2F0ZSh7IGNvZGUsIGNoaWxkcmVuIH06IFByb3BzKSB7XHJcbiAgY29uc3QgZmVhdHVyZXNRdWVyeSA9IHVzZU15RmVhdHVyZXMoKTtcclxuXHJcbiAgaWYgKGZlYXR1cmVzUXVlcnkuaXNMb2FkaW5nKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3QgZGF0YSA9IGZlYXR1cmVzUXVlcnkuZGF0YTtcclxuICBjb25zdCBhbGxvd2VkID0gZGF0YT8uY2FuTWFuYWdlQWNjZXNzIHx8IGRhdGE/LmZlYXR1cmVzLmluY2x1ZGVzKGNvZGUpO1xyXG4gIGlmIChhbGxvd2VkKSByZXR1cm4gPD57Y2hpbGRyZW59PC8+O1xyXG5cclxuICBjb25zdCBmaXJzdEFsbG93ZWQgPSBkYXRhPy5mZWF0dXJlcy5maW5kKChmKSA9PiBmZWF0dXJlUGF0aFtmXSAhPT0gdW5kZWZpbmVkKTtcclxuICByZXR1cm4gPE5hdmlnYXRlIHRvPXtmaXJzdEFsbG93ZWQgPyBmZWF0dXJlUGF0aFtmaXJzdEFsbG93ZWRdIDogXCIvc2VtLWFjZXNzb1wifSByZXBsYWNlIC8+O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gTm9BY2Nlc3NQYWdlKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgcGxhY2VJdGVtczogXCJjZW50ZXJcIiwgbWluSGVpZ2h0OiBcIjYwdmhcIiB9fT5cclxuICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjJyZW1cIiB9fT5TZW0gdGVsYXMgbGliZXJhZGFzPC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+XHJcbiAgICAgICAgICBQZcOnYSBhbyBnZXJlbnRlIHBhcmEgY29uY2VkZXIgYWNlc3NvIG5hIHRlbGEgQWNlc3Nvcy5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2FjY2Vzcy9GZWF0dXJlR2F0ZS50c3gifQ==