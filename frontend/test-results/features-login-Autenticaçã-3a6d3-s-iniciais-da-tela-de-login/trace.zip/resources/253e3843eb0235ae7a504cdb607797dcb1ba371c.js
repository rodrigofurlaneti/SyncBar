import { create } from "/node_modules/.vite/deps/zustand.js?v=ca0b4140";
import { persist } from "/node_modules/.vite/deps/zustand_middleware.js?v=ca0b4140";
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
}
export const useThemeStore = create()(
  persist(
    (set, get) => ({
      theme: "dark",
      setTheme: (theme) => {
        applyTheme(theme);
        set({ theme });
      },
      toggleTheme: () => {
        const next = get().theme === "dark" ? "light" : "dark";
        applyTheme(next);
        set({ theme: next });
      }
    }),
    {
      name: "syncbar-theme",
      onRehydrateStorage: () => (state) => {
        if (state) applyTheme(state.theme);
      }
    }
  )
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRoZW1lU3RvcmUudHMiXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgY3JlYXRlIH0gZnJvbSBcInp1c3RhbmRcIjtcclxuaW1wb3J0IHsgcGVyc2lzdCB9IGZyb20gXCJ6dXN0YW5kL21pZGRsZXdhcmVcIjtcclxuXHJcbmV4cG9ydCB0eXBlIFRoZW1lID0gXCJkYXJrXCIgfCBcImxpZ2h0XCI7XHJcblxyXG5pbnRlcmZhY2UgVGhlbWVTdGF0ZSB7XHJcbiAgdGhlbWU6IFRoZW1lO1xyXG4gIHNldFRoZW1lOiAodGhlbWU6IFRoZW1lKSA9PiB2b2lkO1xyXG4gIHRvZ2dsZVRoZW1lOiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5mdW5jdGlvbiBhcHBseVRoZW1lKHRoZW1lOiBUaGVtZSkge1xyXG4gIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5kYXRhc2V0LnRoZW1lID0gdGhlbWU7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCB1c2VUaGVtZVN0b3JlID0gY3JlYXRlPFRoZW1lU3RhdGU+KCkoXHJcbiAgcGVyc2lzdChcclxuICAgIChzZXQsIGdldCkgPT4gKHtcclxuICAgICAgdGhlbWU6IFwiZGFya1wiLFxyXG4gICAgICBzZXRUaGVtZTogKHRoZW1lKSA9PiB7XHJcbiAgICAgICAgYXBwbHlUaGVtZSh0aGVtZSk7XHJcbiAgICAgICAgc2V0KHsgdGhlbWUgfSk7XHJcbiAgICAgIH0sXHJcbiAgICAgIHRvZ2dsZVRoZW1lOiAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgbmV4dDogVGhlbWUgPSBnZXQoKS50aGVtZSA9PT0gXCJkYXJrXCIgPyBcImxpZ2h0XCIgOiBcImRhcmtcIjtcclxuICAgICAgICBhcHBseVRoZW1lKG5leHQpO1xyXG4gICAgICAgIHNldCh7IHRoZW1lOiBuZXh0IH0pO1xyXG4gICAgICB9LFxyXG4gICAgfSksXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6IFwic3luY2Jhci10aGVtZVwiLFxyXG4gICAgICBvblJlaHlkcmF0ZVN0b3JhZ2U6ICgpID0+IChzdGF0ZSkgPT4ge1xyXG4gICAgICAgIGlmIChzdGF0ZSkgYXBwbHlUaGVtZShzdGF0ZS50aGVtZSk7XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICksXHJcbik7XHJcbiJdLCJtYXBwaW5ncyI6IkFBQUMsU0FBUyxjQUFjO0FBQ3hCLFNBQVMsZUFBZTtBQVV4QixTQUFTLFdBQVcsT0FBYztBQUNoQyxXQUFTLGdCQUFnQixRQUFRLFFBQVE7QUFDM0M7QUFFTyxhQUFNLGdCQUFnQixPQUFtQjtBQUFBLEVBQzlDO0FBQUEsSUFDRSxDQUFDLEtBQUssU0FBUztBQUFBLE1BQ2IsT0FBTztBQUFBLE1BQ1AsVUFBVSxDQUFDLFVBQVU7QUFDbkIsbUJBQVcsS0FBSztBQUNoQixZQUFJLEVBQUUsTUFBTSxDQUFDO0FBQUEsTUFDZjtBQUFBLE1BQ0EsYUFBYSxNQUFNO0FBQ2pCLGNBQU0sT0FBYyxJQUFJLEVBQUUsVUFBVSxTQUFTLFVBQVU7QUFDdkQsbUJBQVcsSUFBSTtBQUNmLFlBQUksRUFBRSxPQUFPLEtBQUssQ0FBQztBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFBQSxNQUNFLE1BQU07QUFBQSxNQUNOLG9CQUFvQixNQUFNLENBQUMsVUFBVTtBQUNuQyxZQUFJLE1BQU8sWUFBVyxNQUFNLEtBQUs7QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7IiwibmFtZXMiOltdfQ==