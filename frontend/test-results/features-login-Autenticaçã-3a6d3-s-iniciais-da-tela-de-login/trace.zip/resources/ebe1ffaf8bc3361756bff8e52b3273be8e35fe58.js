import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/SignupPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { registerCompany } from "/src/features/auth/signupApi.ts";
import { ApiError } from "/src/lib/apiClient.ts";
export function SignupPage() {
  _s();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    legalName: "",
    tradeName: "",
    cpf: "",
    cnpj: "",
    branchName: "",
    adminName: "",
    adminCpf: "",
    adminUserName: "",
    adminEmail: "",
    adminPassword: ""
  });
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  const mutation = useMutation({
    mutationFn: () => registerCompany(form),
    onSuccess: () => navigate("/login", { replace: true })
  });
  const errorMessage = mutation.error instanceof ApiError ? mutation.error.message : mutation.isError ? "Não foi possível conectar à API." : null;
  return /* @__PURE__ */ jsxDEV("main", { style: { minHeight: "100%", display: "grid", placeItems: "center", padding: 24 }, children: /* @__PURE__ */ jsxDEV(
    "form",
    {
      className: "rise",
      onSubmit: (e) => {
        e.preventDefault();
        mutation.mutate();
      },
      style: {
        width: "min(440px, 100%)",
        background: "var(--bg-raise)",
        border: "1px solid var(--line)",
        borderRadius: 16,
        padding: "36px 32px 32px",
        display: "grid",
        gap: 14
      },
      children: [
        /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", marginBottom: 8 }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "brand", style: { fontSize: "2.4rem" }, children: [
            "SYNC",
            /* @__PURE__ */ jsxDEV("em", { children: "BAR" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
              lineNumber: 76,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 75,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                color: "var(--ink-faint)",
                fontFamily: "var(--font-cond)",
                letterSpacing: "0.22em",
                textTransform: "uppercase",
                fontSize: "0.78rem"
              },
              children: "cadastre seu bar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
              lineNumber: 78,
              columnNumber: 11
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 74,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Razão social" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 92,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("input", { value: form.legalName, onChange: set("legalName"), required: true, autoFocus: true }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 93,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 91,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Nome fantasia" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 97,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("input", { value: form.tradeName, onChange: set("tradeName"), required: true }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 98,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 96,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "CNPJ (só números)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 102,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("input", { value: form.cnpj, onChange: set("cnpj"), maxLength: 14, required: true }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 103,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 101,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Nome completo do administrador" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 107,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("input", { value: form.adminName, onChange: set("adminName"), required: true }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 108,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 106,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "CPF do administrador" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 112,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("input", { value: form.adminCpf, onChange: set("adminCpf"), maxLength: 11, required: true }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 113,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 111,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Nome da primeira filial" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 117,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("input", { value: form.branchName, onChange: set("branchName"), required: true }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 118,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 116,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("hr", { style: { border: "none", borderTop: "1px solid var(--line)", margin: "6px 0" } }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 121,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Usuário administrador" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 124,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("input", { value: form.adminUserName, onChange: set("adminUserName"), autoComplete: "username", required: true }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 125,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 123,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "E-mail do administrador" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 129,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "email", value: form.adminEmail, onChange: set("adminEmail"), autoComplete: "email", required: true }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 130,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 128,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Senha" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
            lineNumber: 134,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              value: form.adminPassword,
              onChange: set("adminPassword"),
              autoComplete: "new-password",
              minLength: 8,
              required: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
              lineNumber: 135,
              columnNumber: 11
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 133,
          columnNumber: 9
        }, this),
        errorMessage && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: errorMessage }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 145,
          columnNumber: 26
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "submit", disabled: mutation.isPending, children: mutation.isPending ? "Criando conta…" : "Criar minha conta" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 147,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/login", style: { textAlign: "center", color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Já tenho conta — entrar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
          lineNumber: 151,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
      lineNumber: 58,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx",
    lineNumber: 57,
    columnNumber: 5
  }, this);
}
_s(SignupPage, "UPVsR28CanvdvDphNvRR3b2/J7A=", false, function() {
  return [useNavigate, useMutation];
});
_c = SignupPage;
var _c;
$RefreshReg$(_c, "SignupPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/SignupPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4RGYsU0FBU0EsZ0JBQWdCO0FBQzFCLFNBQVNDLGFBQWFDLFlBQVk7QUFDbEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxnQkFBZ0I7QUFFbEIsZ0JBQVNDLGFBQWE7QUFBQUMsS0FBQTtBQUMzQixRQUFNQyxXQUFXUCxZQUFZO0FBQzdCLFFBQU0sQ0FBQ1EsTUFBTUMsT0FBTyxJQUFJVixTQUFTO0FBQUEsSUFDL0JXLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsS0FBSztBQUFBLElBQ0xDLE1BQU07QUFBQSxJQUNOQyxZQUFZO0FBQUEsSUFDWkMsV0FBVztBQUFBLElBQ1hDLFVBQVU7QUFBQSxJQUNWQyxlQUFlO0FBQUEsSUFDZkMsWUFBWTtBQUFBLElBQ1pDLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBRUQsUUFBTUMsTUFBTUEsQ0FBQ0MsUUFBMkIsQ0FBQ0MsTUFDdkNiLFFBQVEsQ0FBQ2MsT0FBTyxFQUFFLEdBQUdBLEdBQUcsQ0FBQ0YsR0FBRyxHQUFHQyxFQUFFRSxPQUFPQyxNQUFNLEVBQUU7QUFFbEQsUUFBTUMsV0FBV3hCLFlBQVk7QUFBQSxJQUMzQnlCLFlBQVlBLE1BQU14QixnQkFBZ0JLLElBQUk7QUFBQSxJQUN0Q29CLFdBQVdBLE1BQU1yQixTQUFTLFVBQVUsRUFBRXNCLFNBQVMsS0FBSyxDQUFDO0FBQUEsRUFDdkQsQ0FBQztBQUVELFFBQU1DLGVBQ0pKLFNBQVNLLGlCQUFpQjNCLFdBQ3RCc0IsU0FBU0ssTUFBTUMsVUFDZk4sU0FBU08sVUFDUCxxQ0FDQTtBQUVSLFNBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLFdBQVcsUUFBUUMsU0FBUyxRQUFRQyxZQUFZLFVBQVVDLFNBQVMsR0FBRyxHQUNuRjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVTtBQUFBLE1BQ1YsVUFBVSxDQUFDZixNQUFNO0FBQ2ZBLFVBQUVnQixlQUFlO0FBQ2pCWixpQkFBU2EsT0FBTztBQUFBLE1BQ2xCO0FBQUEsTUFDQSxPQUFPO0FBQUEsUUFDTEMsT0FBTztBQUFBLFFBQ1BDLFlBQVk7QUFBQSxRQUNaQyxRQUFRO0FBQUEsUUFDUkMsY0FBYztBQUFBLFFBQ2ROLFNBQVM7QUFBQSxRQUNURixTQUFTO0FBQUEsUUFDVFMsS0FBSztBQUFBLE1BQ1A7QUFBQSxNQUVBO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVDLFdBQVcsVUFBVUMsY0FBYyxFQUFFLEdBQ2pEO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQVEsT0FBTyxFQUFFQyxVQUFVLFNBQVMsR0FBRztBQUFBO0FBQUEsWUFDaEQsdUJBQUMsUUFBRyxtQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFPO0FBQUEsZUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTztBQUFBLGdCQUNMQyxPQUFPO0FBQUEsZ0JBQ1BDLFlBQVk7QUFBQSxnQkFDWkMsZUFBZTtBQUFBLGdCQUNmQyxlQUFlO0FBQUEsZ0JBQ2ZKLFVBQVU7QUFBQSxjQUNaO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFFQSx1QkFBQyxXQUFNLE9BQU8sRUFBRVosU0FBUyxRQUFRUyxLQUFLLEVBQUUsR0FDdEM7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUksT0FBTyxrQkFBa0JELFVBQVUsU0FBUyxHQUFHLDRCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRTtBQUFBLFVBQzFFLHVCQUFDLFdBQU0sT0FBT3ZDLEtBQUtFLFdBQVcsVUFBVVUsSUFBSSxXQUFXLEdBQUcsVUFBUSxNQUFDLFdBQVMsUUFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxhQUY5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFdBQU0sT0FBTyxFQUFFZSxTQUFTLFFBQVFTLEtBQUssRUFBRSxHQUN0QztBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFSSxPQUFPLGtCQUFrQkQsVUFBVSxTQUFTLEdBQUcsNkJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsV0FBTSxPQUFPdkMsS0FBS0csV0FBVyxVQUFVUyxJQUFJLFdBQVcsR0FBRyxVQUFRLFFBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUEsYUFGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxXQUFNLE9BQU8sRUFBRWUsU0FBUyxRQUFRUyxLQUFLLEVBQUUsR0FDcEM7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUksT0FBTyxrQkFBa0JELFVBQVUsU0FBUyxHQUFHLGlDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLFdBQU0sT0FBT3ZDLEtBQUtLLE1BQU0sVUFBVU8sSUFBSSxNQUFNLEdBQUcsV0FBVyxJQUFJLFVBQVEsUUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUU7QUFBQSxhQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFdBQU0sT0FBTyxFQUFFZSxTQUFTLFFBQVFTLEtBQUssRUFBRSxHQUNwQztBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFSSxPQUFPLGtCQUFrQkQsVUFBVSxTQUFTLEdBQUcsOENBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRGO0FBQUEsVUFDNUYsdUJBQUMsV0FBTSxPQUFPdkMsS0FBS08sV0FBVyxVQUFVSyxJQUFJLFdBQVcsR0FBRyxVQUFRLFFBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUEsYUFGdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxXQUFNLE9BQU8sRUFBRWUsU0FBUyxRQUFRUyxLQUFLLEVBQUUsR0FDcEM7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUksT0FBTyxrQkFBa0JELFVBQVUsU0FBUyxHQUFHLG9DQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQzVFLHVCQUFDLFdBQU0sT0FBT3ZDLEtBQUtRLFVBQVUsVUFBVUksSUFBSSxVQUFVLEdBQUcsV0FBVyxJQUFJLFVBQVEsUUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxhQUZ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFdBQU0sT0FBTyxFQUFFZSxTQUFTLFFBQVFTLEtBQUssRUFBRSxHQUN0QztBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFSSxPQUFPLGtCQUFrQkQsVUFBVSxTQUFTLEdBQUcsdUNBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGO0FBQUEsVUFDckYsdUJBQUMsV0FBTSxPQUFPdkMsS0FBS00sWUFBWSxVQUFVTSxJQUFJLFlBQVksR0FBRyxVQUFRLFFBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsYUFGdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxRQUFHLE9BQU8sRUFBRXNCLFFBQVEsUUFBUVUsV0FBVyx5QkFBeUJDLFFBQVEsUUFBUSxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsUUFFbkYsdUJBQUMsV0FBTSxPQUFPLEVBQUVsQixTQUFTLFFBQVFTLEtBQUssRUFBRSxHQUN0QztBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFSSxPQUFPLGtCQUFrQkQsVUFBVSxTQUFTLEdBQUcscUNBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFDbkYsdUJBQUMsV0FBTSxPQUFPdkMsS0FBS1MsZUFBZSxVQUFVRyxJQUFJLGVBQWUsR0FBRyxjQUFhLFlBQVcsVUFBUSxRQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRztBQUFBLGFBRnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsV0FBTSxPQUFPLEVBQUVlLFNBQVMsUUFBUVMsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsaUNBQUMsVUFBSyxPQUFPLEVBQUVJLE9BQU8sa0JBQWtCRCxVQUFVLFNBQVMsR0FBRyx1Q0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRix1QkFBQyxXQUFNLE1BQUssU0FBUSxPQUFPdkMsS0FBS1UsWUFBWSxVQUFVRSxJQUFJLFlBQVksR0FBRyxjQUFhLFNBQVEsVUFBUSxRQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRztBQUFBLGFBRnhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsV0FBTSxPQUFPLEVBQUVlLFNBQVMsUUFBUVMsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsaUNBQUMsVUFBSyxPQUFPLEVBQUVJLE9BQU8sa0JBQWtCRCxVQUFVLFNBQVMsR0FBRyxxQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUU7QUFBQSxVQUNuRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT3ZDLEtBQUtXO0FBQUFBLGNBQ1osVUFBVUMsSUFBSSxlQUFlO0FBQUEsY0FDN0IsY0FBYTtBQUFBLGNBQ2IsV0FBVztBQUFBLGNBQ1gsVUFBUTtBQUFBO0FBQUEsWUFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNVTtBQUFBLGFBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQ1UsZ0JBQWdCLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSwwQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QztBQUFBLFFBRXpELHVCQUFDLFlBQU8sV0FBVSxlQUFjLE1BQUssVUFBUyxVQUFVSixTQUFTNEIsV0FDOUQ1QixtQkFBUzRCLFlBQVksbUJBQW1CLHVCQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLFFBQUssSUFBRyxVQUFTLE9BQU8sRUFBRVQsV0FBVyxVQUFVRyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsdUNBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUE7QUFBQSxJQS9GRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnR0EsS0FqR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtHQTtBQUVKO0FBQUN6QyxHQW5JZUQsWUFBVTtBQUFBLFVBQ1BMLGFBaUJBRSxXQUFXO0FBQUE7QUFBQSxLQWxCZEc7QUFBVSxJQUFBa0Q7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VOYXZpZ2F0ZSIsIkxpbmsiLCJ1c2VNdXRhdGlvbiIsInJlZ2lzdGVyQ29tcGFueSIsIkFwaUVycm9yIiwiU2lnbnVwUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJmb3JtIiwic2V0Rm9ybSIsImxlZ2FsTmFtZSIsInRyYWRlTmFtZSIsImNwZiIsImNucGoiLCJicmFuY2hOYW1lIiwiYWRtaW5OYW1lIiwiYWRtaW5DcGYiLCJhZG1pblVzZXJOYW1lIiwiYWRtaW5FbWFpbCIsImFkbWluUGFzc3dvcmQiLCJzZXQiLCJrZXkiLCJlIiwiZiIsInRhcmdldCIsInZhbHVlIiwibXV0YXRpb24iLCJtdXRhdGlvbkZuIiwib25TdWNjZXNzIiwicmVwbGFjZSIsImVycm9yTWVzc2FnZSIsImVycm9yIiwibWVzc2FnZSIsImlzRXJyb3IiLCJtaW5IZWlnaHQiLCJkaXNwbGF5IiwicGxhY2VJdGVtcyIsInBhZGRpbmciLCJwcmV2ZW50RGVmYXVsdCIsIm11dGF0ZSIsIndpZHRoIiwiYmFja2dyb3VuZCIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsImdhcCIsInRleHRBbGlnbiIsIm1hcmdpbkJvdHRvbSIsImZvbnRTaXplIiwiY29sb3IiLCJmb250RmFtaWx5IiwibGV0dGVyU3BhY2luZyIsInRleHRUcmFuc2Zvcm0iLCJib3JkZXJUb3AiLCJtYXJnaW4iLCJpc1BlbmRpbmciLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTaWdudXBQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyByZWdpc3RlckNvbXBhbnkgfSBmcm9tIFwiLi9zaWdudXBBcGlcIjtcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tIFwiLi4vLi4vbGliL2FwaUNsaWVudFwiO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNpZ251cFBhZ2UoKSB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKHtcclxuICAgIGxlZ2FsTmFtZTogXCJcIixcclxuICAgIHRyYWRlTmFtZTogXCJcIixcclxuICAgIGNwZjogXCJcIixcclxuICAgIGNucGo6IFwiXCIsXHJcbiAgICBicmFuY2hOYW1lOiBcIlwiLFxyXG4gICAgYWRtaW5OYW1lOiBcIlwiLFxyXG4gICAgYWRtaW5DcGY6IFwiXCIsXHJcbiAgICBhZG1pblVzZXJOYW1lOiBcIlwiLFxyXG4gICAgYWRtaW5FbWFpbDogXCJcIixcclxuICAgIGFkbWluUGFzc3dvcmQ6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHNldCA9IChrZXk6IGtleW9mIHR5cGVvZiBmb3JtKSA9PiAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+XHJcbiAgICBzZXRGb3JtKChmKSA9PiAoeyAuLi5mLCBba2V5XTogZS50YXJnZXQudmFsdWUgfSkpO1xyXG5cclxuICBjb25zdCBtdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHJlZ2lzdGVyQ29tcGFueShmb3JtKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4gbmF2aWdhdGUoXCIvbG9naW5cIiwgeyByZXBsYWNlOiB0cnVlIH0pLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBlcnJvck1lc3NhZ2UgPVxyXG4gICAgbXV0YXRpb24uZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvclxyXG4gICAgICA/IG11dGF0aW9uLmVycm9yLm1lc3NhZ2VcclxuICAgICAgOiBtdXRhdGlvbi5pc0Vycm9yXHJcbiAgICAgICAgPyBcIk7Do28gZm9pIHBvc3PDrXZlbCBjb25lY3RhciDDoCBBUEkuXCJcclxuICAgICAgICA6IG51bGw7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBzdHlsZT17eyBtaW5IZWlnaHQ6IFwiMTAwJVwiLCBkaXNwbGF5OiBcImdyaWRcIiwgcGxhY2VJdGVtczogXCJjZW50ZXJcIiwgcGFkZGluZzogMjQgfX0+XHJcbiAgICAgIDxmb3JtXHJcbiAgICAgICAgY2xhc3NOYW1lPVwicmlzZVwiXHJcbiAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICBtdXRhdGlvbi5tdXRhdGUoKTtcclxuICAgICAgICB9fVxyXG4gICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICB3aWR0aDogXCJtaW4oNDQwcHgsIDEwMCUpXCIsXHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLWJnLXJhaXNlKVwiLFxyXG4gICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lKVwiLFxyXG4gICAgICAgICAgYm9yZGVyUmFkaXVzOiAxNixcclxuICAgICAgICAgIHBhZGRpbmc6IFwiMzZweCAzMnB4IDMycHhcIixcclxuICAgICAgICAgIGRpc3BsYXk6IFwiZ3JpZFwiLFxyXG4gICAgICAgICAgZ2FwOiAxNCxcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIG1hcmdpbkJvdHRvbTogOCB9fT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnJhbmRcIiBzdHlsZT17eyBmb250U2l6ZTogXCIyLjRyZW1cIiB9fT5cclxuICAgICAgICAgICAgU1lOQzxlbT5CQVI8L2VtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLFxyXG4gICAgICAgICAgICAgIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1jb25kKVwiLFxyXG4gICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4yMmVtXCIsXHJcbiAgICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIixcclxuICAgICAgICAgICAgICBmb250U2l6ZTogXCIwLjc4cmVtXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIGNhZGFzdHJlIHNldSBiYXJcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlJhesOjbyBzb2NpYWw8L3NwYW4+XHJcbiAgICAgICAgICA8aW5wdXQgdmFsdWU9e2Zvcm0ubGVnYWxOYW1lfSBvbkNoYW5nZT17c2V0KFwibGVnYWxOYW1lXCIpfSByZXF1aXJlZCBhdXRvRm9jdXMgLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19Pk5vbWUgZmFudGFzaWE8L3NwYW4+XHJcbiAgICAgICAgICA8aW5wdXQgdmFsdWU9e2Zvcm0udHJhZGVOYW1lfSBvbkNoYW5nZT17c2V0KFwidHJhZGVOYW1lXCIpfSByZXF1aXJlZCAvPlxyXG4gICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA2IH19PlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5DTlBKIChzw7MgbsO6bWVyb3MpPC9zcGFuPlxyXG4gICAgICAgICAgICA8aW5wdXQgdmFsdWU9e2Zvcm0uY25wan0gb25DaGFuZ2U9e3NldChcImNucGpcIil9IG1heExlbmd0aD17MTR9IHJlcXVpcmVkIC8+XHJcbiAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDYgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19Pk5vbWUgY29tcGxldG8gZG8gYWRtaW5pc3RyYWRvcjwvc3Bhbj5cclxuICAgICAgICAgICAgPGlucHV0IHZhbHVlPXtmb3JtLmFkbWluTmFtZX0gb25DaGFuZ2U9e3NldChcImFkbWluTmFtZVwiKX0gcmVxdWlyZWQgLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+Q1BGIGRvIGFkbWluaXN0cmFkb3I8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB2YWx1ZT17Zm9ybS5hZG1pbkNwZn0gb25DaGFuZ2U9e3NldChcImFkbWluQ3BmXCIpfSBtYXhMZW5ndGg9ezExfSByZXF1aXJlZCAvPlxyXG4gICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA2IH19PlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+Tm9tZSBkYSBwcmltZWlyYSBmaWxpYWw8L3NwYW4+XHJcbiAgICAgICAgICA8aW5wdXQgdmFsdWU9e2Zvcm0uYnJhbmNoTmFtZX0gb25DaGFuZ2U9e3NldChcImJyYW5jaE5hbWVcIil9IHJlcXVpcmVkIC8+XHJcbiAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgPGhyIHN0eWxlPXt7IGJvcmRlcjogXCJub25lXCIsIGJvcmRlclRvcDogXCIxcHggc29saWQgdmFyKC0tbGluZSlcIiwgbWFyZ2luOiBcIjZweCAwXCIgfX0gLz5cclxuXHJcbiAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDYgfX0+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5Vc3XDoXJpbyBhZG1pbmlzdHJhZG9yPC9zcGFuPlxyXG4gICAgICAgICAgPGlucHV0IHZhbHVlPXtmb3JtLmFkbWluVXNlck5hbWV9IG9uQ2hhbmdlPXtzZXQoXCJhZG1pblVzZXJOYW1lXCIpfSBhdXRvQ29tcGxldGU9XCJ1c2VybmFtZVwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDYgfX0+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5FLW1haWwgZG8gYWRtaW5pc3RyYWRvcjwvc3Bhbj5cclxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiB2YWx1ZT17Zm9ybS5hZG1pbkVtYWlsfSBvbkNoYW5nZT17c2V0KFwiYWRtaW5FbWFpbFwiKX0gYXV0b0NvbXBsZXRlPVwiZW1haWxcIiByZXF1aXJlZCAvPlxyXG4gICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA2IH19PlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+U2VuaGE8L3NwYW4+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm0uYWRtaW5QYXNzd29yZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9e3NldChcImFkbWluUGFzc3dvcmRcIil9XHJcbiAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiXHJcbiAgICAgICAgICAgIG1pbkxlbmd0aD17OH1cclxuICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAge2Vycm9yTWVzc2FnZSAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yTWVzc2FnZX08L3A+fVxyXG5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXttdXRhdGlvbi5pc1BlbmRpbmd9PlxyXG4gICAgICAgICAge211dGF0aW9uLmlzUGVuZGluZyA/IFwiQ3JpYW5kbyBjb250YeKAplwiIDogXCJDcmlhciBtaW5oYSBjb250YVwifVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICA8TGluayB0bz1cIi9sb2dpblwiIHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgSsOhIHRlbmhvIGNvbnRhIOKAlCBlbnRyYXJcclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9hdXRoL1NpZ251cFBhZ2UudHN4In0=