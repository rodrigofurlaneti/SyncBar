import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/stock/InventoryOverlay.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { adjustInventory } from "/src/features/stock/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { Overlay } from "/src/features/orders/Overlay.tsx";
const parseNum = (raw) => {
  if (raw.trim() === "") return null;
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) && value >= 0 ? value : null;
};
export function InventoryOverlay({ items, productName, onClose, onDone }) {
  _s();
  const { branchId, employeeId } = useAuthStore();
  const [counts, setCounts] = useState({});
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const filled = useMemo(
    () => items.filter((item) => parseNum(counts[item.productId] ?? "") !== null),
    [items, counts]
  );
  const mutation = useMutation({
    mutationFn: () => adjustInventory(
      branchId,
      employeeId ?? 1,
      filled.map((item) => ({
        productId: item.productId,
        countedQuantity: parseNum(counts[item.productId] ?? "")
      }))
    ),
    onSuccess: (adjustments) => {
      setError(null);
      setResult(adjustments);
      onDone();
    },
    onError: (e) => setError(e instanceof ApiError ? e.message : "Falha ao registrar o inventário.")
  });
  if (result !== null)
    return /* @__PURE__ */ jsxDEV(Overlay, { title: "Inventário registrado", onClose, children: [
      result.length === 0 ? /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ok)" }, children: "Todas as contagens bateram com o sistema — nenhum ajuste necessário." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
        lineNumber: 74,
        columnNumber: 7
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: result.map(
        (adjustment) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: productName.get(adjustment.productId) ?? `Produto ${adjustment.productId}` }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
              lineNumber: 80,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
              "sistema ",
              adjustment.previousQuantity,
              " → contado ",
              adjustment.countedQuantity
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
              lineNumber: 81,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
            lineNumber: 79,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: "mono-num",
              style: { color: adjustment.difference > 0 ? "var(--ok)" : "var(--danger)" },
              children: [
                adjustment.difference > 0 ? "+" : "",
                adjustment.difference
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
              lineNumber: 85,
              columnNumber: 17
            },
            this
          )
        ] }, adjustment.productId, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
          lineNumber: 78,
          columnNumber: 9
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
        lineNumber: 76,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: onClose, children: "Fechar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
        lineNumber: 95,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
      lineNumber: 72,
      columnNumber: 5
    }, this);
  return /* @__PURE__ */ jsxDEV(Overlay, { title: "Inventário — contagem física", onClose, wide: true, children: [
    /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)", fontSize: "0.9rem", margin: 0 }, children: "Digite a quantidade CONTADA de cada produto. Itens em branco não são ajustados. As diferenças viram ajustes de entrada/saída no extrato." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: [
      items.map(
        (item) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: productName.get(item.productId) ?? `Produto ${item.productId}` }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
              lineNumber: 110,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
              "sistema: ",
              item.currentQuantity
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
              lineNumber: 111,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
            lineNumber: 109,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              inputMode: "decimal",
              placeholder: "contagem",
              style: { width: 110, textAlign: "right" },
              value: counts[item.productId] ?? "",
              onChange: (e) => setCounts((current) => ({ ...current, [item.productId]: e.target.value }))
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
              lineNumber: 115,
              columnNumber: 13
            },
            this
          )
        ] }, item.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
          lineNumber: 108,
          columnNumber: 9
        }, this)
      ),
      items.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-faint)" }, children: "Nenhum item de estoque para contar." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
        lineNumber: 127,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
      lineNumber: 106,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
      lineNumber: 133,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "btn-primary",
        disabled: filled.length === 0 || mutation.isPending,
        onClick: () => mutation.mutate(),
        children: mutation.isPending ? "Registrando…" : `Registrar inventário (${filled.length} itens contados)`
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
        lineNumber: 135,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx",
    lineNumber: 100,
    columnNumber: 5
  }, this);
}
_s(InventoryOverlay, "ILYXIhvVN8UQ0CRR+hM4815HE1o=", false, function() {
  return [useAuthStore, useMutation];
});
_c = InventoryOverlay;
var _c;
$RefreshReg$(_c, "InventoryOverlay");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/stock/InventoryOverlay.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXREVCxTQUFTQSxTQUFTQyxnQkFBZ0I7QUFDbkMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHVCQUFpRDtBQUMxRCxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLGVBQWU7QUFTeEIsTUFBTUMsV0FBV0EsQ0FBQ0MsUUFBK0I7QUFDL0MsTUFBSUEsSUFBSUMsS0FBSyxNQUFNLEdBQUksUUFBTztBQUM5QixRQUFNQyxRQUFRQyxPQUFPSCxJQUFJSSxRQUFRLEtBQUssR0FBRyxDQUFDO0FBQzFDLFNBQU9ELE9BQU9FLFNBQVNILEtBQUssS0FBS0EsU0FBUyxJQUFJQSxRQUFRO0FBQ3hEO0FBRU8sZ0JBQVNJLGlCQUFpQixFQUFFQyxPQUFPQyxhQUFhQyxTQUFTQyxPQUFjLEdBQUc7QUFBQUMsS0FBQTtBQUMvRSxRQUFNLEVBQUVDLFVBQVVDLFdBQVcsSUFBSWpCLGFBQWE7QUFDOUMsUUFBTSxDQUFDa0IsUUFBUUMsU0FBUyxJQUFJdEIsU0FBaUMsQ0FBQyxDQUFDO0FBQy9ELFFBQU0sQ0FBQ3VCLFFBQVFDLFNBQVMsSUFBSXhCLFNBQXVDLElBQUk7QUFDdkUsUUFBTSxDQUFDeUIsT0FBT0MsUUFBUSxJQUFJMUIsU0FBd0IsSUFBSTtBQUV0RCxRQUFNMkIsU0FBUzVCO0FBQUFBLElBQ2IsTUFBTWUsTUFBTWMsT0FBTyxDQUFDQyxTQUFTdkIsU0FBU2UsT0FBT1EsS0FBS0MsU0FBUyxLQUFLLEVBQUUsTUFBTSxJQUFJO0FBQUEsSUFDNUUsQ0FBQ2hCLE9BQU9PLE1BQU07QUFBQSxFQUNoQjtBQUVBLFFBQU1VLFdBQVc5QixZQUFZO0FBQUEsSUFDM0IrQixZQUFZQSxNQUNWOUI7QUFBQUEsTUFDRWlCO0FBQUFBLE1BQ0FDLGNBQWM7QUFBQSxNQUNkTyxPQUFPTSxJQUFJLENBQUNKLFVBQVU7QUFBQSxRQUNwQkMsV0FBV0QsS0FBS0M7QUFBQUEsUUFDaEJJLGlCQUFpQjVCLFNBQVNlLE9BQU9RLEtBQUtDLFNBQVMsS0FBSyxFQUFFO0FBQUEsTUFDeEQsRUFBRTtBQUFBLElBQ0o7QUFBQSxJQUNGSyxXQUFXQSxDQUFDQyxnQkFBZ0I7QUFDMUJWLGVBQVMsSUFBSTtBQUNiRixnQkFBVVksV0FBVztBQUNyQm5CLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQW9CLFNBQVNBLENBQUNDLE1BQU1aLFNBQVNZLGFBQWFsQyxXQUFXa0MsRUFBRUMsVUFBVSxrQ0FBa0M7QUFBQSxFQUNqRyxDQUFDO0FBRUQsTUFBSWhCLFdBQVc7QUFDYixXQUNFLHVCQUFDLFdBQVEsT0FBTSx5QkFBd0IsU0FDcENBO0FBQUFBLGFBQU9pQixXQUFXLElBQ2pCLHVCQUFDLE9BQUUsT0FBTyxFQUFFQyxPQUFPLFlBQVksR0FBRyxvRkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRyxJQUV0Ryx1QkFBQyxTQUFJLFdBQVUsVUFDWmxCLGlCQUFPVTtBQUFBQSxRQUFJLENBQUNTLGVBQ1gsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSxtQ0FBQyxVQUFNN0Isc0JBQVk4QixJQUFJSCxXQUFXWixTQUFTLEtBQUssV0FBV1ksV0FBV1osU0FBUyxNQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLFlBQ2xGLHVCQUFDLFVBQUssT0FBTyxFQUFFZ0IsVUFBVSxVQUFVTCxPQUFPLG1CQUFtQixHQUFHO0FBQUE7QUFBQSxjQUNyREMsV0FBV0s7QUFBQUEsY0FBaUI7QUFBQSxjQUFZTCxXQUFXUjtBQUFBQSxpQkFEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRU8sT0FBT0MsV0FBV00sYUFBYSxJQUFJLGNBQWMsZ0JBQWdCO0FBQUEsY0FFekVOO0FBQUFBLDJCQUFXTSxhQUFhLElBQUksTUFBTTtBQUFBLGdCQUFJTixXQUFXTTtBQUFBQTtBQUFBQTtBQUFBQSxZQUpwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBWitCTixXQUFXWixXQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxNQUNELEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUVGLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsZUFBYyxTQUFTZCxTQUFTLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNFO0FBQUEsU0F2QnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkE7QUFHSixTQUNFLHVCQUFDLFdBQVEsT0FBTSxnQ0FBK0IsU0FBa0IsTUFBSSxNQUNsRTtBQUFBLDJCQUFDLE9BQUUsT0FBTyxFQUFFeUIsT0FBTyxrQkFBa0JLLFVBQVUsVUFBVUcsUUFBUSxFQUFFLEdBQUcsd0pBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLFVBQ1puQztBQUFBQSxZQUFNbUI7QUFBQUEsUUFBSSxDQUFDSixTQUNWLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUVjLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsbUNBQUMsVUFBTTdCLHNCQUFZOEIsSUFBSWhCLEtBQUtDLFNBQVMsS0FBSyxXQUFXRCxLQUFLQyxTQUFTLE1BQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsVUFBSyxXQUFVLFlBQVcsT0FBTyxFQUFFZ0IsVUFBVSxVQUFVTCxPQUFPLG1CQUFtQixHQUFHO0FBQUE7QUFBQSxjQUN6RVosS0FBS3FCO0FBQUFBLGlCQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osT0FBTyxFQUFFQyxPQUFPLEtBQUtDLFdBQVcsUUFBUTtBQUFBLGNBQ3hDLE9BQU8vQixPQUFPUSxLQUFLQyxTQUFTLEtBQUs7QUFBQSxjQUNqQyxVQUFVLENBQUNRLE1BQ1RoQixVQUFVLENBQUMrQixhQUFhLEVBQUUsR0FBR0EsU0FBUyxDQUFDeEIsS0FBS0MsU0FBUyxHQUFHUSxFQUFFZ0IsT0FBTzdDLE1BQU0sRUFBRTtBQUFBO0FBQUEsWUFON0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0c7QUFBQSxhQWQ0Qm9CLEtBQUswQixJQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsTUFDRDtBQUFBLE1BQ0F6QyxNQUFNMEIsV0FBVyxLQUNoQix1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVDLE9BQU8sbUJBQW1CLEdBQUcsbURBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUVDaEIsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUUzQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsVUFBVUUsT0FBT2EsV0FBVyxLQUFLVCxTQUFTeUI7QUFBQUEsUUFDMUMsU0FBUyxNQUFNekIsU0FBUzBCLE9BQU87QUFBQSxRQUU5QjFCLG1CQUFTeUIsWUFBWSxpQkFBaUIseUJBQXlCN0IsT0FBT2EsTUFBTTtBQUFBO0FBQUEsTUFOL0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0E7QUFBQSxPQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkNBO0FBRUo7QUFBQ3RCLEdBeEdlTCxrQkFBZ0I7QUFBQSxVQUNHVixjQVVoQkYsV0FBVztBQUFBO0FBQUEsS0FYZFk7QUFBZ0IsSUFBQTZDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwiYWRqdXN0SW52ZW50b3J5IiwidXNlQXV0aFN0b3JlIiwiQXBpRXJyb3IiLCJPdmVybGF5IiwicGFyc2VOdW0iLCJyYXciLCJ0cmltIiwidmFsdWUiLCJOdW1iZXIiLCJyZXBsYWNlIiwiaXNGaW5pdGUiLCJJbnZlbnRvcnlPdmVybGF5IiwiaXRlbXMiLCJwcm9kdWN0TmFtZSIsIm9uQ2xvc2UiLCJvbkRvbmUiLCJfcyIsImJyYW5jaElkIiwiZW1wbG95ZWVJZCIsImNvdW50cyIsInNldENvdW50cyIsInJlc3VsdCIsInNldFJlc3VsdCIsImVycm9yIiwic2V0RXJyb3IiLCJmaWxsZWQiLCJmaWx0ZXIiLCJpdGVtIiwicHJvZHVjdElkIiwibXV0YXRpb24iLCJtdXRhdGlvbkZuIiwibWFwIiwiY291bnRlZFF1YW50aXR5Iiwib25TdWNjZXNzIiwiYWRqdXN0bWVudHMiLCJvbkVycm9yIiwiZSIsIm1lc3NhZ2UiLCJsZW5ndGgiLCJjb2xvciIsImFkanVzdG1lbnQiLCJkaXNwbGF5IiwiZ2FwIiwiZ2V0IiwiZm9udFNpemUiLCJwcmV2aW91c1F1YW50aXR5IiwiZGlmZmVyZW5jZSIsIm1hcmdpbiIsImN1cnJlbnRRdWFudGl0eSIsIndpZHRoIiwidGV4dEFsaWduIiwiY3VycmVudCIsInRhcmdldCIsImlkIiwiaXNQZW5kaW5nIiwibXV0YXRlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSW52ZW50b3J5T3ZlcmxheS50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24gfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IGFkanVzdEludmVudG9yeSwgdHlwZSBJbnZlbnRvcnlBZGp1c3RtZW50IH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHR5cGUgeyBTdG9ja0l0ZW1SZXNwb25zZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgT3ZlcmxheSB9IGZyb20gXCIuLi9vcmRlcnMvT3ZlcmxheVwiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHtcclxuICBpdGVtczogU3RvY2tJdGVtUmVzcG9uc2VbXTtcclxuICBwcm9kdWN0TmFtZTogTWFwPG51bWJlciwgc3RyaW5nPjtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIG9uRG9uZTogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuY29uc3QgcGFyc2VOdW0gPSAocmF3OiBzdHJpbmcpOiBudW1iZXIgfCBudWxsID0+IHtcclxuICBpZiAocmF3LnRyaW0oKSA9PT0gXCJcIikgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgdmFsdWUgPSBOdW1iZXIocmF3LnJlcGxhY2UoXCIsXCIsIFwiLlwiKSk7XHJcbiAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgJiYgdmFsdWUgPj0gMCA/IHZhbHVlIDogbnVsbDtcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJbnZlbnRvcnlPdmVybGF5KHsgaXRlbXMsIHByb2R1Y3ROYW1lLCBvbkNsb3NlLCBvbkRvbmUgfTogUHJvcHMpIHtcclxuICBjb25zdCB7IGJyYW5jaElkLCBlbXBsb3llZUlkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbY291bnRzLCBzZXRDb3VudHNdID0gdXNlU3RhdGU8UmVjb3JkPG51bWJlciwgc3RyaW5nPj4oe30pO1xyXG4gIGNvbnN0IFtyZXN1bHQsIHNldFJlc3VsdF0gPSB1c2VTdGF0ZTxJbnZlbnRvcnlBZGp1c3RtZW50W10gfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBmaWxsZWQgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gaXRlbXMuZmlsdGVyKChpdGVtKSA9PiBwYXJzZU51bShjb3VudHNbaXRlbS5wcm9kdWN0SWRdID8/IFwiXCIpICE9PSBudWxsKSxcclxuICAgIFtpdGVtcywgY291bnRzXSxcclxuICApO1xyXG5cclxuICBjb25zdCBtdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIGFkanVzdEludmVudG9yeShcclxuICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICBlbXBsb3llZUlkID8/IDEsXHJcbiAgICAgICAgZmlsbGVkLm1hcCgoaXRlbSkgPT4gKHtcclxuICAgICAgICAgIHByb2R1Y3RJZDogaXRlbS5wcm9kdWN0SWQsXHJcbiAgICAgICAgICBjb3VudGVkUXVhbnRpdHk6IHBhcnNlTnVtKGNvdW50c1tpdGVtLnByb2R1Y3RJZF0gPz8gXCJcIikhLFxyXG4gICAgICAgIH0pKSxcclxuICAgICAgKSxcclxuICAgIG9uU3VjY2VzczogKGFkanVzdG1lbnRzKSA9PiB7XHJcbiAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICBzZXRSZXN1bHQoYWRqdXN0bWVudHMpO1xyXG4gICAgICBvbkRvbmUoKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoZSkgPT4gc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEFwaUVycm9yID8gZS5tZXNzYWdlIDogXCJGYWxoYSBhbyByZWdpc3RyYXIgbyBpbnZlbnTDoXJpby5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGlmIChyZXN1bHQgIT09IG51bGwpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8T3ZlcmxheSB0aXRsZT1cIkludmVudMOhcmlvIHJlZ2lzdHJhZG9cIiBvbkNsb3NlPXtvbkNsb3NlfT5cclxuICAgICAgICB7cmVzdWx0Lmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLW9rKVwiIH19PlRvZGFzIGFzIGNvbnRhZ2VucyBiYXRlcmFtIGNvbSBvIHNpc3RlbWEg4oCUIG5lbmh1bSBhanVzdGUgbmVjZXNzw6FyaW8uPC9wPlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiPlxyXG4gICAgICAgICAgICB7cmVzdWx0Lm1hcCgoYWRqdXN0bWVudCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LXJvd1wiIGtleT17YWRqdXN0bWVudC5wcm9kdWN0SWR9PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj57cHJvZHVjdE5hbWUuZ2V0KGFkanVzdG1lbnQucHJvZHVjdElkKSA/PyBgUHJvZHV0byAke2FkanVzdG1lbnQucHJvZHVjdElkfWB9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHNpc3RlbWEge2FkanVzdG1lbnQucHJldmlvdXNRdWFudGl0eX0g4oaSIGNvbnRhZG8ge2FkanVzdG1lbnQuY291bnRlZFF1YW50aXR5fVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IGFkanVzdG1lbnQuZGlmZmVyZW5jZSA+IDAgPyBcInZhcigtLW9rKVwiIDogXCJ2YXIoLS1kYW5nZXIpXCIgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2FkanVzdG1lbnQuZGlmZmVyZW5jZSA+IDAgPyBcIitcIiA6IFwiXCJ9e2FkanVzdG1lbnQuZGlmZmVyZW5jZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgb25DbGljaz17b25DbG9zZX0+RmVjaGFyPC9idXR0b24+XHJcbiAgICAgIDwvT3ZlcmxheT5cclxuICAgICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8T3ZlcmxheSB0aXRsZT1cIkludmVudMOhcmlvIOKAlCBjb250YWdlbSBmw61zaWNhXCIgb25DbG9zZT17b25DbG9zZX0gd2lkZT5cclxuICAgICAgPHAgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIsIG1hcmdpbjogMCB9fT5cclxuICAgICAgICBEaWdpdGUgYSBxdWFudGlkYWRlIENPTlRBREEgZGUgY2FkYSBwcm9kdXRvLiBJdGVucyBlbSBicmFuY28gbsOjbyBzw6NvIGFqdXN0YWRvcy5cclxuICAgICAgICBBcyBkaWZlcmVuw6dhcyB2aXJhbSBhanVzdGVzIGRlIGVudHJhZGEvc2HDrWRhIG5vIGV4dHJhdG8uXHJcbiAgICAgIDwvcD5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0XCI+XHJcbiAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIga2V5PXtpdGVtLmlkfT5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgIDxzcGFuPntwcm9kdWN0TmFtZS5nZXQoaXRlbS5wcm9kdWN0SWQpID8/IGBQcm9kdXRvICR7aXRlbS5wcm9kdWN0SWR9YH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgc2lzdGVtYToge2l0ZW0uY3VycmVudFF1YW50aXR5fVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiY29udGFnZW1cIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAxMTAsIHRleHRBbGlnbjogXCJyaWdodFwiIH19XHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvdW50c1tpdGVtLnByb2R1Y3RJZF0gPz8gXCJcIn1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICBzZXRDb3VudHMoKGN1cnJlbnQpID0+ICh7IC4uLmN1cnJlbnQsIFtpdGVtLnByb2R1Y3RJZF06IGUudGFyZ2V0LnZhbHVlIH0pKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICAgIHtpdGVtcy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICBOZW5odW0gaXRlbSBkZSBlc3RvcXVlIHBhcmEgY29udGFyLlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCJcclxuICAgICAgICBkaXNhYmxlZD17ZmlsbGVkLmxlbmd0aCA9PT0gMCB8fCBtdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gbXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgID5cclxuICAgICAgICB7bXV0YXRpb24uaXNQZW5kaW5nID8gXCJSZWdpc3RyYW5kb+KAplwiIDogYFJlZ2lzdHJhciBpbnZlbnTDoXJpbyAoJHtmaWxsZWQubGVuZ3RofSBpdGVucyBjb250YWRvcylgfVxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgIDwvT3ZlcmxheT5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9zdG9jay9JbnZlbnRvcnlPdmVybGF5LnRzeCJ9