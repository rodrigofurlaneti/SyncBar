import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/tabs/TabMensagens.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { QueryError } from "/src/components/QueryError.tsx";
import { parseApiDate } from "/src/lib/types.ts";
export function TabMensagens({ activeAreaId, isLoading, isError, error, messages }) {
  _s();
  const sortedMessages = useMemo(() => {
    return [...messages].sort(
      (a, b) => parseApiDate(b.createdAt).getTime() - parseApiDate(a.createdAt).getTime()
    );
  }, [messages]);
  return /* @__PURE__ */ jsxDEV("section", { className: "waiter-section", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "waiter-section-title", style: { marginBottom: 16 }, children: "Mensagens e Avisos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
      lineNumber: 52,
      columnNumber: 13
    }, this),
    !activeAreaId ? /* @__PURE__ */ jsxDEV("p", { className: "waiter-empty", children: "Atribua-se a uma praça para visualizar as mensagens locais." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
      lineNumber: 55,
      columnNumber: 7
    }, this) : isLoading ? /* @__PURE__ */ jsxDEV("p", { className: "waiter-empty", children: "Carregando mensagens..." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this) : isError ? /* @__PURE__ */ jsxDEV(QueryError, { error, what: "as mensagens" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
      lineNumber: 59,
      columnNumber: 7
    }, this) : sortedMessages.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "waiter-empty", children: "Nenhuma mensagem registrada na sua praça no momento." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
      lineNumber: 61,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "waiter-order-list", style: { display: "grid", gap: "10px" }, children: sortedMessages.map(
      (msg) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          style: {
            backgroundColor: "var(--w-bg-card)",
            borderRadius: "14px",
            padding: "14px",
            border: "1px solid var(--w-line)",
            borderLeft: `6px solid ${msg.isRead ? "var(--w-ink-faint)" : "var(--w-accent-2)"}`,
            display: "grid",
            gap: "6px"
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.75rem", fontWeight: "700", color: "var(--w-ink-dim)" }, children: "Aviso Operacional" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
                lineNumber: 78,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.75rem", color: "var(--w-ink-faint)" }, children: [
                parseApiDate(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                " - ",
                parseApiDate(msg.createdAt).toLocaleDateString()
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
                lineNumber: 81,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
              lineNumber: 77,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.95rem", color: "var(--w-ink)", margin: 0, fontWeight: 500 }, children: msg.message }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
              lineNumber: 85,
              columnNumber: 29
            }, this)
          ]
        },
        msg.id,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
          lineNumber: 65,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
      lineNumber: 63,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx",
    lineNumber: 51,
    columnNumber: 5
  }, this);
}
_s(TabMensagens, "9+5nT/MDe6DFOPla2Uth9hUp7qk=");
_c = TabMensagens;
var _c;
$RefreshReg$(_c, "TabMensagens");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/tabs/TabMensagens.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NZOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhDWCxTQUFTQSxlQUFlO0FBQ3pCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxvQkFBb0I7QUFxQnRCLGdCQUFTQyxhQUFhLEVBQUVDLGNBQWNDLFdBQVdDLFNBQVNDLE9BQU9DLFNBQTRCLEdBQUc7QUFBQUMsS0FBQTtBQUNuRyxRQUFNQyxpQkFBaUJWLFFBQVEsTUFBTTtBQUNqQyxXQUFPLENBQUMsR0FBR1EsUUFBUSxFQUFFRztBQUFBQSxNQUFLLENBQUNDLEdBQUdDLE1BQzFCWCxhQUFhVyxFQUFFQyxTQUFTLEVBQUVDLFFBQVEsSUFBSWIsYUFBYVUsRUFBRUUsU0FBUyxFQUFFQyxRQUFRO0FBQUEsSUFDNUU7QUFBQSxFQUNKLEdBQUcsQ0FBQ1AsUUFBUSxDQUFDO0FBRWIsU0FDSSx1QkFBQyxhQUFRLFdBQVUsa0JBQ2Y7QUFBQSwyQkFBQyxRQUFHLFdBQVUsd0JBQXVCLE9BQU8sRUFBRVEsY0FBYyxHQUFHLEdBQUcsa0NBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0Y7QUFBQSxJQUVuRixDQUFDWixlQUNFLHVCQUFDLE9BQUUsV0FBVSxnQkFBZSwyRUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RixJQUN2RkMsWUFDQSx1QkFBQyxPQUFFLFdBQVUsZ0JBQWUsdUNBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUQsSUFDbkRDLFVBQ0EsdUJBQUMsY0FBVyxPQUFjLE1BQUssa0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkMsSUFDN0NJLGVBQWVPLFdBQVcsSUFDMUIsdUJBQUMsT0FBRSxXQUFVLGdCQUFlLG9FQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdGLElBRWhGLHVCQUFDLFNBQUksV0FBVSxxQkFBb0IsT0FBTyxFQUFFQyxTQUFTLFFBQVFDLEtBQUssT0FBTyxHQUNwRVQseUJBQWVVO0FBQUFBLE1BQUksQ0FBQ0MsUUFDakI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVHLE9BQU87QUFBQSxZQUNIQyxpQkFBaUI7QUFBQSxZQUNqQkMsY0FBYztBQUFBLFlBQ2RDLFNBQVM7QUFBQSxZQUNUQyxRQUFRO0FBQUEsWUFDUkMsWUFBWSxhQUFhTCxJQUFJTSxTQUFTLHVCQUF1QixtQkFBbUI7QUFBQSxZQUNoRlQsU0FBUztBQUFBLFlBQ1RDLEtBQUs7QUFBQSxVQUNUO0FBQUEsVUFFQTtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFRCxTQUFTLFFBQVFVLGdCQUFnQixpQkFBaUJDLFlBQVksU0FBUyxHQUNqRjtBQUFBLHFDQUFDLFVBQUssT0FBTyxFQUFFQyxVQUFVLFdBQVdDLFlBQVksT0FBT0MsT0FBTyxtQkFBbUIsR0FBRyxpQ0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVGLFVBQVUsV0FBV0UsT0FBTyxxQkFBcUIsR0FDM0Q5QjtBQUFBQSw2QkFBYW1CLElBQUlQLFNBQVMsRUFBRW1CLG1CQUFtQixJQUFJLEVBQUVDLE1BQU0sV0FBV0MsUUFBUSxVQUFVLENBQUM7QUFBQSxnQkFBRTtBQUFBLGdCQUFJakMsYUFBYW1CLElBQUlQLFNBQVMsRUFBRXNCLG1CQUFtQjtBQUFBLG1CQURuSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVOLFVBQVUsV0FBV0UsT0FBTyxnQkFBZ0JLLFFBQVEsR0FBR04sWUFBWSxJQUFJLEdBQzlFVixjQUFJaUIsV0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQTtBQUFBLFFBckJLakIsSUFBSWtCO0FBQUFBLFFBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXVCQTtBQUFBLElBQ0gsS0ExQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLE9BdkNSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5Q0E7QUFFUjtBQUFDOUIsR0FuRGVOLGNBQVk7QUFBQSxLQUFaQTtBQUFZLElBQUFxQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwiUXVlcnlFcnJvciIsInBhcnNlQXBpRGF0ZSIsIlRhYk1lbnNhZ2VucyIsImFjdGl2ZUFyZWFJZCIsImlzTG9hZGluZyIsImlzRXJyb3IiLCJlcnJvciIsIm1lc3NhZ2VzIiwiX3MiLCJzb3J0ZWRNZXNzYWdlcyIsInNvcnQiLCJhIiwiYiIsImNyZWF0ZWRBdCIsImdldFRpbWUiLCJtYXJnaW5Cb3R0b20iLCJsZW5ndGgiLCJkaXNwbGF5IiwiZ2FwIiwibWFwIiwibXNnIiwiYmFja2dyb3VuZENvbG9yIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsImJvcmRlciIsImJvcmRlckxlZnQiLCJpc1JlYWQiLCJqdXN0aWZ5Q29udGVudCIsImFsaWduSXRlbXMiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJjb2xvciIsInRvTG9jYWxlVGltZVN0cmluZyIsImhvdXIiLCJtaW51dGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJtYXJnaW4iLCJtZXNzYWdlIiwiaWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYWJNZW5zYWdlbnMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuaW1wb3J0IHsgcGFyc2VBcGlEYXRlIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2xpYi90eXBlc1wiO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBXYWl0ZXJNZXNzYWdlUmVzcG9uc2Uge1xyXG4gICAgaWQ6IG51bWJlcjtcclxuICAgIGJyYW5jaElkOiBudW1iZXI7XHJcbiAgICBzZW5kZXJFbXBsb3llZUlkOiBudW1iZXI7XHJcbiAgICByZWNpcGllbnRFbXBsb3llZUlkOiBudW1iZXIgfCBudWxsO1xyXG4gICAgZGluaW5nQXJlYUlkOiBudW1iZXIgfCBudWxsO1xyXG4gICAgbWVzc2FnZTogc3RyaW5nO1xyXG4gICAgaXNSZWFkOiBib29sZWFuO1xyXG4gICAgY3JlYXRlZEF0OiBzdHJpbmc7XHJcbn1cclxuXHJcbmludGVyZmFjZSBUYWJNZW5zYWdlbnNQcm9wcyB7XHJcbiAgICBhY3RpdmVBcmVhSWQ6IG51bWJlciB8IG51bGw7XHJcbiAgICBpc0xvYWRpbmc6IGJvb2xlYW47XHJcbiAgICBpc0Vycm9yOiBib29sZWFuO1xyXG4gICAgZXJyb3I6IHVua25vd247XHJcbiAgICBtZXNzYWdlczogV2FpdGVyTWVzc2FnZVJlc3BvbnNlW107XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBUYWJNZW5zYWdlbnMoeyBhY3RpdmVBcmVhSWQsIGlzTG9hZGluZywgaXNFcnJvciwgZXJyb3IsIG1lc3NhZ2VzIH06IFRhYk1lbnNhZ2Vuc1Byb3BzKSB7XHJcbiAgICBjb25zdCBzb3J0ZWRNZXNzYWdlcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBbLi4ubWVzc2FnZXNdLnNvcnQoKGEsIGIpID0+XHJcbiAgICAgICAgICAgIHBhcnNlQXBpRGF0ZShiLmNyZWF0ZWRBdCkuZ2V0VGltZSgpIC0gcGFyc2VBcGlEYXRlKGEuY3JlYXRlZEF0KS5nZXRUaW1lKClcclxuICAgICAgICApO1xyXG4gICAgfSwgW21lc3NhZ2VzXSk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ3YWl0ZXItc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwid2FpdGVyLXNlY3Rpb24tdGl0bGVcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDE2IH19Pk1lbnNhZ2VucyBlIEF2aXNvczwvaDI+XHJcblxyXG4gICAgICAgICAgICB7IWFjdGl2ZUFyZWFJZCA/IChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIndhaXRlci1lbXB0eVwiPkF0cmlidWEtc2UgYSB1bWEgcHJhw6dhIHBhcmEgdmlzdWFsaXphciBhcyBtZW5zYWdlbnMgbG9jYWlzLjwvcD5cclxuICAgICAgICAgICAgKSA6IGlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIndhaXRlci1lbXB0eVwiPkNhcnJlZ2FuZG8gbWVuc2FnZW5zLi4uPC9wPlxyXG4gICAgICAgICAgICApIDogaXNFcnJvciA/IChcclxuICAgICAgICAgICAgICAgIDxRdWVyeUVycm9yIGVycm9yPXtlcnJvcn0gd2hhdD1cImFzIG1lbnNhZ2Vuc1wiIC8+XHJcbiAgICAgICAgICAgICkgOiBzb3J0ZWRNZXNzYWdlcy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ3YWl0ZXItZW1wdHlcIj5OZW5odW1hIG1lbnNhZ2VtIHJlZ2lzdHJhZGEgbmEgc3VhIHByYcOnYSBubyBtb21lbnRvLjwvcD5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2FpdGVyLW9yZGVyLWxpc3RcIiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiBcIjEwcHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7c29ydGVkTWVzc2FnZXMubWFwKChtc2cpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXttc2cuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCJ2YXIoLS13LWJnLWNhcmQpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjE0cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjE0cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHZhcigtLXctbGluZSlcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJMZWZ0OiBgNnB4IHNvbGlkICR7bXNnLmlzUmVhZCA/IFwidmFyKC0tdy1pbmstZmFpbnQpXCIgOiBcInZhcigtLXctYWNjZW50LTIpXCJ9YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImdyaWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnYXA6IFwiNnB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjc1cmVtXCIsIGZvbnRXZWlnaHQ6IFwiNzAwXCIsIGNvbG9yOiBcInZhcigtLXctaW5rLWRpbSlcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQXZpc28gT3BlcmFjaW9uYWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC43NXJlbVwiLCBjb2xvcjogXCJ2YXIoLS13LWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BhcnNlQXBpRGF0ZShtc2cuY3JlYXRlZEF0KS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KX0gLSB7cGFyc2VBcGlEYXRlKG1zZy5jcmVhdGVkQXQpLnRvTG9jYWxlRGF0ZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45NXJlbVwiLCBjb2xvcjogXCJ2YXIoLS13LWluaylcIiwgbWFyZ2luOiAwLCBmb250V2VpZ2h0OiA1MDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge21zZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbn0iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvd2FpdGVyL2NvbXBvbmVudHMvdGFicy9UYWJNZW5zYWdlbnMudHN4In0=