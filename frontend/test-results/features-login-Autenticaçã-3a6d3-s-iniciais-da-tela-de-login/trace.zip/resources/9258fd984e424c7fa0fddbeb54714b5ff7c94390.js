import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/ComplementsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { ComplementItemsPanel } from "/src/features/catalog/ComplementItemsPanel.tsx";
import { ComplementGroupsPanel } from "/src/features/catalog/ComplementGroupsPanel.tsx";
export function ComplementsPage() {
  _s();
  const [tab, setTab] = useState("groups");
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 900, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 16 }, children: /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Complementos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx",
      lineNumber: 32,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rise rise-1", style: { display: "flex", gap: 8, marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: tab === "groups" ? "btn-primary" : "btn-ghost",
          onClick: () => setTab("groups"),
          children: "Grupos"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx",
          lineNumber: 38,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: tab === "items" ? "btn-primary" : "btn-ghost",
          onClick: () => setTab("items"),
          children: "Itens"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx",
          lineNumber: 45,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    tab === "groups" ? /* @__PURE__ */ jsxDEV(ComplementGroupsPanel, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx",
      lineNumber: 54,
      columnNumber: 27
    }, this) : /* @__PURE__ */ jsxDEV(ComplementItemsPanel, {}, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx",
      lineNumber: 54,
      columnNumber: 55
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
}
_s(ComplementsPage, "Fl/Ux5k0TOZfaApvxKCGCKC2I4U=");
_c = ComplementsPage;
var _c;
$RefreshReg$(_c, "ComplementsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWlAsU0FBU0EsZ0JBQWdCO0FBQzFCLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyw2QkFBNkI7QUFJL0IsZ0JBQVNDLGtCQUFrQjtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sQ0FBQ0MsS0FBS0MsTUFBTSxJQUFJTixTQUFjLFFBQVE7QUFFNUMsU0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRU8sU0FBUyxJQUFJQyxVQUFVLEtBQUtDLFFBQVEsU0FBUyxHQUMxRDtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxZQUFZLFlBQVlDLEtBQUssSUFBSUMsY0FBYyxHQUFHLEdBQ2hHLGlDQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxTQUFTLEdBQUcsNEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQWMsT0FBTyxFQUFFSixTQUFTLFFBQVFFLEtBQUssR0FBR0MsY0FBYyxHQUFHLEdBQzlFO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVdSLFFBQVEsV0FBVyxnQkFBZ0I7QUFBQSxVQUM5QyxTQUFTLE1BQU1DLE9BQU8sUUFBUTtBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBV0QsUUFBUSxVQUFVLGdCQUFnQjtBQUFBLFVBQzdDLFNBQVMsTUFBTUMsT0FBTyxPQUFPO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFIakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBRUNELFFBQVEsV0FBVyx1QkFBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNCLElBQU0sdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLE9BeEJ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUJBO0FBRUo7QUFBQ0QsR0EvQmVELGlCQUFlO0FBQUEsS0FBZkE7QUFBZSxJQUFBWTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbXBsZW1lbnRJdGVtc1BhbmVsIiwiQ29tcGxlbWVudEdyb3Vwc1BhbmVsIiwiQ29tcGxlbWVudHNQYWdlIiwiX3MiLCJ0YWIiLCJzZXRUYWIiLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsIm1hcmdpbkJvdHRvbSIsImZvbnRTaXplIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29tcGxlbWVudHNQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBDb21wbGVtZW50SXRlbXNQYW5lbCB9IGZyb20gXCIuL0NvbXBsZW1lbnRJdGVtc1BhbmVsXCI7XHJcbmltcG9ydCB7IENvbXBsZW1lbnRHcm91cHNQYW5lbCB9IGZyb20gXCIuL0NvbXBsZW1lbnRHcm91cHNQYW5lbFwiO1xyXG5cclxudHlwZSBUYWIgPSBcImdyb3Vwc1wiIHwgXCJpdGVtc1wiO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIENvbXBsZW1lbnRzUGFnZSgpIHtcclxuICBjb25zdCBbdGFiLCBzZXRUYWJdID0gdXNlU3RhdGU8VGFiPihcImdyb3Vwc1wiKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIHN0eWxlPXt7IHBhZGRpbmc6IDIyLCBtYXhXaWR0aDogOTAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImJhc2VsaW5lXCIsIGdhcDogMTQsIG1hcmdpbkJvdHRvbTogMTYgfX0+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjdyZW1cIiB9fT5cclxuICAgICAgICAgIENvbXBsZW1lbnRvc1xyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDgsIG1hcmdpbkJvdHRvbTogMTggfX0+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9e3RhYiA9PT0gXCJncm91cHNcIiA/IFwiYnRuLXByaW1hcnlcIiA6IFwiYnRuLWdob3N0XCJ9XHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWIoXCJncm91cHNcIil9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgR3J1cG9zXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9e3RhYiA9PT0gXCJpdGVtc1wiID8gXCJidG4tcHJpbWFyeVwiIDogXCJidG4tZ2hvc3RcIn1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRhYihcIml0ZW1zXCIpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIEl0ZW5zXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge3RhYiA9PT0gXCJncm91cHNcIiA/IDxDb21wbGVtZW50R3JvdXBzUGFuZWwgLz4gOiA8Q29tcGxlbWVudEl0ZW1zUGFuZWwgLz59XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvY2F0YWxvZy9Db21wbGVtZW50c1BhZ2UudHN4In0=