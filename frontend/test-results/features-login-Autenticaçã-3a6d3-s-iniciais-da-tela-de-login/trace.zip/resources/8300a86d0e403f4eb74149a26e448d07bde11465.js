import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/PartialPaymentDialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getOpenSession } from "/src/features/cash/api.ts";
import { registerPartialPayment } from "/src/features/billing/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import {
  DEFAULT_CASH_REGISTER_ID,
  PaymentMethod,
  formatBRL,
  paymentMethodLabel
} from "/src/lib/types.ts";
import { Overlay } from "/src/features/orders/Overlay.tsx";
const parseNum = (raw) => {
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) && value > 0 ? value : null;
};
const needsReceipt = (methodId) => methodId === PaymentMethod.CartaoCredito || methodId === PaymentMethod.CartaoDebito || methodId === PaymentMethod.Pix;
export function PartialPaymentDialog({ order, onClose, onRegistered }) {
  _s();
  const { employeeId } = useAuthStore();
  const [amount, setAmount] = useState("");
  const [methodId, setMethodId] = useState(PaymentMethod.Dinheiro);
  const [authorizationCode, setAuthorizationCode] = useState("");
  const [payerName, setPayerName] = useState("");
  const [error, setError] = useState(null);
  const remaining = order.totalAmount - order.partialPaidAmount;
  const sessionQuery = useQuery({
    queryKey: ["cash", "open", DEFAULT_CASH_REGISTER_ID],
    queryFn: () => getOpenSession(DEFAULT_CASH_REGISTER_ID),
    retry: false
  });
  const noSession = sessionQuery.isError && sessionQuery.error instanceof ApiError && (sessionQuery.error.status === 404 || sessionQuery.error.status === 403);
  const value = parseNum(amount);
  const mutation = useMutation({
    mutationFn: () => registerPartialPayment({
      customerOrderId: order.id,
      cashSessionId: sessionQuery.data.id,
      employeeId: employeeId ?? 1,
      paymentMethodId: methodId,
      amount: value ?? 0,
      authorizationCode: authorizationCode.trim() === "" ? null : authorizationCode.trim(),
      payerName: payerName.trim() === "" ? null : payerName.trim()
    }),
    onSuccess: onRegistered,
    onError: (e) => setError(e instanceof ApiError ? e.message : "Falha ao registrar o pagamento parcial.")
  });
  return /* @__PURE__ */ jsxDEV(Overlay, { title: "Pagamento parcial", onClose, children: [
    /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)", fontSize: "0.9rem", margin: 0 }, children: [
      "Cliente saindo antes? Registre o valor pago — a mesa continua aberta e o restante é cobrado no fechamento. Restante atual:",
      " ",
      /* @__PURE__ */ jsxDEV("strong", { className: "mono-num", style: { color: "var(--amber)" }, children: formatBRL(remaining) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
        lineNumber: 94,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    noSession && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: "O caixa está fechado — abra uma sessão (botão Caixa no topo) para receber." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
      lineNumber: 98,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Quem pagou (opcional)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
        lineNumber: 104,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { placeholder: "ex.: Carlos", value: payerName, onChange: (e) => setPayerName(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
      lineNumber: 103,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8, gridTemplateColumns: "1.3fr 1fr" }, children: [
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Forma de pagamento" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
          lineNumber: 110,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("select", { value: methodId, onChange: (e) => setMethodId(Number(e.target.value)), children: Object.entries(paymentMethodLabel).map(
          ([id, label]) => /* @__PURE__ */ jsxDEV("option", { value: id, children: label }, id, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
            lineNumber: 113,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
          lineNumber: 111,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
        lineNumber: 109,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Valor (R$)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
          lineNumber: 118,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { inputMode: "decimal", placeholder: "65,55", value: amount, onChange: (e) => setAmount(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
          lineNumber: 119,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
        lineNumber: 117,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    needsReceipt(methodId) && /* @__PURE__ */ jsxDEV(
      "input",
      {
        placeholder: "Comprovante / autorização",
        value: authorizationCode,
        onChange: (e) => setAuthorizationCode(e.target.value)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
        lineNumber: 124,
        columnNumber: 7
      },
      this
    ),
    value !== null && value > remaining && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: [
      "O valor excede o restante da conta (",
      formatBRL(remaining),
      ")."
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
      lineNumber: 132,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
      lineNumber: 134,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "btn-primary",
        disabled: value === null || value > remaining || noSession || sessionQuery.isLoading || mutation.isPending,
        onClick: () => mutation.mutate(),
        children: mutation.isPending ? "Registrando…" : "Registrar pagamento parcial"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
        lineNumber: 136,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx",
    lineNumber: 90,
    columnNumber: 5
  }, this);
}
_s(PartialPaymentDialog, "iD6ogI91ocpig7PpHW8vNSb8R2I=", false, function() {
  return [useAuthStore, useQuery, useMutation];
});
_c = PartialPaymentDialog;
var _c;
$RefreshReg$(_c, "PartialPaymentDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PartialPaymentDialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEVROzs7Ozs7Ozs7Ozs7Ozs7OztBQTFFUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxTQUFTQyxlQUFlO0FBUXhCLE1BQU1DLFdBQVdBLENBQUNDLFFBQStCO0FBQy9DLFFBQU1DLFFBQVFDLE9BQU9GLElBQUlHLFFBQVEsS0FBSyxHQUFHLENBQUM7QUFDMUMsU0FBT0QsT0FBT0UsU0FBU0gsS0FBSyxLQUFLQSxRQUFRLElBQUlBLFFBQVE7QUFDdkQ7QUFFQSxNQUFNSSxlQUFlQSxDQUFDQyxhQUNwQkEsYUFBYVgsY0FBY1ksaUJBQzNCRCxhQUFhWCxjQUFjYSxnQkFDM0JGLGFBQWFYLGNBQWNjO0FBRXRCLGdCQUFTQyxxQkFBcUIsRUFBRUMsT0FBT0MsU0FBU0MsYUFBb0IsR0FBRztBQUFBQyxLQUFBO0FBQzVFLFFBQU0sRUFBRUMsV0FBVyxJQUFJdkIsYUFBYTtBQUNwQyxRQUFNLENBQUN3QixRQUFRQyxTQUFTLElBQUk5QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDbUIsVUFBVVksV0FBVyxJQUFJL0IsU0FBaUJRLGNBQWN3QixRQUFRO0FBQ3ZFLFFBQU0sQ0FBQ0MsbUJBQW1CQyxvQkFBb0IsSUFBSWxDLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNtQyxXQUFXQyxZQUFZLElBQUlwQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDcUMsT0FBT0MsUUFBUSxJQUFJdEMsU0FBd0IsSUFBSTtBQUV0RCxRQUFNdUMsWUFBWWYsTUFBTWdCLGNBQWNoQixNQUFNaUI7QUFFNUMsUUFBTUMsZUFBZXhDLFNBQVM7QUFBQSxJQUM1QnlDLFVBQVUsQ0FBQyxRQUFRLFFBQVFwQyx3QkFBd0I7QUFBQSxJQUNuRHFDLFNBQVNBLE1BQU16QyxlQUFlSSx3QkFBd0I7QUFBQSxJQUN0RHNDLE9BQU87QUFBQSxFQUNULENBQUM7QUFFRCxRQUFNQyxZQUNKSixhQUFhSyxXQUNiTCxhQUFhTCxpQkFBaUIvQixhQUM3Qm9DLGFBQWFMLE1BQU1XLFdBQVcsT0FBT04sYUFBYUwsTUFBTVcsV0FBVztBQUV0RSxRQUFNbEMsUUFBUUYsU0FBU2lCLE1BQU07QUFFN0IsUUFBTW9CLFdBQVdoRCxZQUFZO0FBQUEsSUFDM0JpRCxZQUFZQSxNQUNWOUMsdUJBQXVCO0FBQUEsTUFDckIrQyxpQkFBaUIzQixNQUFNNEI7QUFBQUEsTUFDdkJDLGVBQWVYLGFBQWFZLEtBQU1GO0FBQUFBLE1BQ2xDeEIsWUFBWUEsY0FBYztBQUFBLE1BQzFCMkIsaUJBQWlCcEM7QUFBQUEsTUFDakJVLFFBQVFmLFNBQVM7QUFBQSxNQUNqQm1CLG1CQUFtQkEsa0JBQWtCdUIsS0FBSyxNQUFNLEtBQUssT0FBT3ZCLGtCQUFrQnVCLEtBQUs7QUFBQSxNQUNuRnJCLFdBQVdBLFVBQVVxQixLQUFLLE1BQU0sS0FBSyxPQUFPckIsVUFBVXFCLEtBQUs7QUFBQSxJQUM3RCxDQUFDO0FBQUEsSUFDSEMsV0FBVy9CO0FBQUFBLElBQ1hnQyxTQUFTQSxDQUFDQyxNQUFNckIsU0FBU3FCLGFBQWFyRCxXQUFXcUQsRUFBRUMsVUFBVSx5Q0FBeUM7QUFBQSxFQUN4RyxDQUFDO0FBRUQsU0FDRSx1QkFBQyxXQUFRLE9BQU0scUJBQW9CLFNBQ2pDO0FBQUEsMkJBQUMsT0FBRSxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCQyxVQUFVLFVBQVVDLFFBQVEsRUFBRSxHQUFHO0FBQUE7QUFBQSxNQUVsQjtBQUFBLE1BQ2xELHVCQUFDLFlBQU8sV0FBVSxZQUFXLE9BQU8sRUFBRUYsT0FBTyxlQUFlLEdBQUlwRCxvQkFBVThCLFNBQVMsS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRjtBQUFBLFNBSHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUNPLGFBQ0MsdUJBQUMsT0FBRSxXQUFVLGNBQWEsMEZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBR0YsdUJBQUMsV0FBTSxPQUFPLEVBQUVrQixTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUN0QztBQUFBLDZCQUFDLFVBQUssT0FBTyxFQUFFSixPQUFPLGtCQUFrQkMsVUFBVSxVQUFVLEdBQUcscUNBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Y7QUFBQSxNQUNwRix1QkFBQyxXQUFNLGFBQVksZUFBYyxPQUFPM0IsV0FBVyxVQUFVLENBQUN3QixNQUFNdkIsYUFBYXVCLEVBQUVPLE9BQU9wRCxLQUFLLEtBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUc7QUFBQSxTQUZuRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFa0QsU0FBUyxRQUFRQyxLQUFLLEdBQUdFLHFCQUFxQixZQUFZLEdBQ3RFO0FBQUEsNkJBQUMsV0FBTSxPQUFPLEVBQUVILFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVKLE9BQU8sa0JBQWtCQyxVQUFVLFVBQVUsR0FBRyxrQ0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFFBQ2pGLHVCQUFDLFlBQU8sT0FBTzNDLFVBQVUsVUFBVSxDQUFDd0MsTUFBTTVCLFlBQVloQixPQUFPNEMsRUFBRU8sT0FBT3BELEtBQUssQ0FBQyxHQUN6RXNELGlCQUFPQyxRQUFRM0Qsa0JBQWtCLEVBQUU0RDtBQUFBQSxVQUFJLENBQUMsQ0FBQ2xCLElBQUltQixLQUFLLE1BQ2pELHVCQUFDLFlBQWdCLE9BQU9uQixJQUFLbUIsbUJBQWhCbkIsSUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQztBQUFBLFFBQ3BDLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFdBQU0sT0FBTyxFQUFFWSxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUN0QztBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFSixPQUFPLGtCQUFrQkMsVUFBVSxVQUFVLEdBQUcsMEJBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxRQUN6RSx1QkFBQyxXQUFNLFdBQVUsV0FBVSxhQUFZLFNBQVEsT0FBT2pDLFFBQVEsVUFBVSxDQUFDOEIsTUFBTTdCLFVBQVU2QixFQUFFTyxPQUFPcEQsS0FBSyxLQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlHO0FBQUEsV0FGM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUVDSSxhQUFhQyxRQUFRLEtBQ3BCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxhQUFZO0FBQUEsUUFDWixPQUFPYztBQUFBQSxRQUNQLFVBQVUsQ0FBQzBCLE1BQU16QixxQkFBcUJ5QixFQUFFTyxPQUFPcEQsS0FBSztBQUFBO0FBQUEsTUFIdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR3dEO0FBQUEsSUFJekRBLFVBQVUsUUFBUUEsUUFBUXlCLGFBQ3pCLHVCQUFDLE9BQUUsV0FBVSxjQUFhO0FBQUE7QUFBQSxNQUFxQzlCLFVBQVU4QixTQUFTO0FBQUEsTUFBRTtBQUFBLFNBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0Y7QUFBQSxJQUV2RkYsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUUzQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsVUFBVXZCLFVBQVUsUUFBUUEsUUFBUXlCLGFBQWFPLGFBQWFKLGFBQWE4QixhQUFhdkIsU0FBU3dCO0FBQUFBLFFBQ2pHLFNBQVMsTUFBTXhCLFNBQVN5QixPQUFPO0FBQUEsUUFFOUJ6QixtQkFBU3dCLFlBQVksaUJBQWlCO0FBQUE7QUFBQSxNQU56QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQTtBQUFBLE9BckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzREE7QUFFSjtBQUFDOUMsR0EvRmVKLHNCQUFvQjtBQUFBLFVBQ1hsQixjQVNGSCxVQWFKRCxXQUFXO0FBQUE7QUFBQSxLQXZCZHNCO0FBQW9CLElBQUFvRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJnZXRPcGVuU2Vzc2lvbiIsInJlZ2lzdGVyUGFydGlhbFBheW1lbnQiLCJ1c2VBdXRoU3RvcmUiLCJBcGlFcnJvciIsIkRFRkFVTFRfQ0FTSF9SRUdJU1RFUl9JRCIsIlBheW1lbnRNZXRob2QiLCJmb3JtYXRCUkwiLCJwYXltZW50TWV0aG9kTGFiZWwiLCJPdmVybGF5IiwicGFyc2VOdW0iLCJyYXciLCJ2YWx1ZSIsIk51bWJlciIsInJlcGxhY2UiLCJpc0Zpbml0ZSIsIm5lZWRzUmVjZWlwdCIsIm1ldGhvZElkIiwiQ2FydGFvQ3JlZGl0byIsIkNhcnRhb0RlYml0byIsIlBpeCIsIlBhcnRpYWxQYXltZW50RGlhbG9nIiwib3JkZXIiLCJvbkNsb3NlIiwib25SZWdpc3RlcmVkIiwiX3MiLCJlbXBsb3llZUlkIiwiYW1vdW50Iiwic2V0QW1vdW50Iiwic2V0TWV0aG9kSWQiLCJEaW5oZWlybyIsImF1dGhvcml6YXRpb25Db2RlIiwic2V0QXV0aG9yaXphdGlvbkNvZGUiLCJwYXllck5hbWUiLCJzZXRQYXllck5hbWUiLCJlcnJvciIsInNldEVycm9yIiwicmVtYWluaW5nIiwidG90YWxBbW91bnQiLCJwYXJ0aWFsUGFpZEFtb3VudCIsInNlc3Npb25RdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInJldHJ5Iiwibm9TZXNzaW9uIiwiaXNFcnJvciIsInN0YXR1cyIsIm11dGF0aW9uIiwibXV0YXRpb25GbiIsImN1c3RvbWVyT3JkZXJJZCIsImlkIiwiY2FzaFNlc3Npb25JZCIsImRhdGEiLCJwYXltZW50TWV0aG9kSWQiLCJ0cmltIiwib25TdWNjZXNzIiwib25FcnJvciIsImUiLCJtZXNzYWdlIiwiY29sb3IiLCJmb250U2l6ZSIsIm1hcmdpbiIsImRpc3BsYXkiLCJnYXAiLCJ0YXJnZXQiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwiT2JqZWN0IiwiZW50cmllcyIsIm1hcCIsImxhYmVsIiwiaXNMb2FkaW5nIiwiaXNQZW5kaW5nIiwibXV0YXRlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGFydGlhbFBheW1lbnREaWFsb2cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgZ2V0T3BlblNlc3Npb24gfSBmcm9tIFwiLi4vY2FzaC9hcGlcIjtcclxuaW1wb3J0IHsgcmVnaXN0ZXJQYXJ0aWFsUGF5bWVudCB9IGZyb20gXCIuLi9iaWxsaW5nL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7XHJcbiAgREVGQVVMVF9DQVNIX1JFR0lTVEVSX0lELFxyXG4gIFBheW1lbnRNZXRob2QsXHJcbiAgZm9ybWF0QlJMLFxyXG4gIHBheW1lbnRNZXRob2RMYWJlbCxcclxufSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB0eXBlIHsgT3JkZXJSZXNwb25zZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgT3ZlcmxheSB9IGZyb20gXCIuL092ZXJsYXlcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgb3JkZXI6IE9yZGVyUmVzcG9uc2U7XHJcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxuICBvblJlZ2lzdGVyZWQ6ICgpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmNvbnN0IHBhcnNlTnVtID0gKHJhdzogc3RyaW5nKTogbnVtYmVyIHwgbnVsbCA9PiB7XHJcbiAgY29uc3QgdmFsdWUgPSBOdW1iZXIocmF3LnJlcGxhY2UoXCIsXCIsIFwiLlwiKSk7XHJcbiAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgJiYgdmFsdWUgPiAwID8gdmFsdWUgOiBudWxsO1xyXG59O1xyXG5cclxuY29uc3QgbmVlZHNSZWNlaXB0ID0gKG1ldGhvZElkOiBudW1iZXIpOiBib29sZWFuID0+XHJcbiAgbWV0aG9kSWQgPT09IFBheW1lbnRNZXRob2QuQ2FydGFvQ3JlZGl0byB8fFxyXG4gIG1ldGhvZElkID09PSBQYXltZW50TWV0aG9kLkNhcnRhb0RlYml0byB8fFxyXG4gIG1ldGhvZElkID09PSBQYXltZW50TWV0aG9kLlBpeDtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBQYXJ0aWFsUGF5bWVudERpYWxvZyh7IG9yZGVyLCBvbkNsb3NlLCBvblJlZ2lzdGVyZWQgfTogUHJvcHMpIHtcclxuICBjb25zdCB7IGVtcGxveWVlSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IFthbW91bnQsIHNldEFtb3VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbWV0aG9kSWQsIHNldE1ldGhvZElkXSA9IHVzZVN0YXRlPG51bWJlcj4oUGF5bWVudE1ldGhvZC5EaW5oZWlybyk7XHJcbiAgY29uc3QgW2F1dGhvcml6YXRpb25Db2RlLCBzZXRBdXRob3JpemF0aW9uQ29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcGF5ZXJOYW1lLCBzZXRQYXllck5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3QgcmVtYWluaW5nID0gb3JkZXIudG90YWxBbW91bnQgLSBvcmRlci5wYXJ0aWFsUGFpZEFtb3VudDtcclxuXHJcbiAgY29uc3Qgc2Vzc2lvblF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImNhc2hcIiwgXCJvcGVuXCIsIERFRkFVTFRfQ0FTSF9SRUdJU1RFUl9JRF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRPcGVuU2Vzc2lvbihERUZBVUxUX0NBU0hfUkVHSVNURVJfSUQpLFxyXG4gICAgcmV0cnk6IGZhbHNlLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBub1Nlc3Npb24gPVxyXG4gICAgc2Vzc2lvblF1ZXJ5LmlzRXJyb3IgJiZcclxuICAgIHNlc3Npb25RdWVyeS5lcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yICYmXHJcbiAgICAoc2Vzc2lvblF1ZXJ5LmVycm9yLnN0YXR1cyA9PT0gNDA0IHx8IHNlc3Npb25RdWVyeS5lcnJvci5zdGF0dXMgPT09IDQwMyk7XHJcblxyXG4gIGNvbnN0IHZhbHVlID0gcGFyc2VOdW0oYW1vdW50KTtcclxuXHJcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICByZWdpc3RlclBhcnRpYWxQYXltZW50KHtcclxuICAgICAgICBjdXN0b21lck9yZGVySWQ6IG9yZGVyLmlkLFxyXG4gICAgICAgIGNhc2hTZXNzaW9uSWQ6IHNlc3Npb25RdWVyeS5kYXRhIS5pZCxcclxuICAgICAgICBlbXBsb3llZUlkOiBlbXBsb3llZUlkID8/IDEsXHJcbiAgICAgICAgcGF5bWVudE1ldGhvZElkOiBtZXRob2RJZCxcclxuICAgICAgICBhbW91bnQ6IHZhbHVlID8/IDAsXHJcbiAgICAgICAgYXV0aG9yaXphdGlvbkNvZGU6IGF1dGhvcml6YXRpb25Db2RlLnRyaW0oKSA9PT0gXCJcIiA/IG51bGwgOiBhdXRob3JpemF0aW9uQ29kZS50cmltKCksXHJcbiAgICAgICAgcGF5ZXJOYW1lOiBwYXllck5hbWUudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IHBheWVyTmFtZS50cmltKCksXHJcbiAgICAgIH0pLFxyXG4gICAgb25TdWNjZXNzOiBvblJlZ2lzdGVyZWQsXHJcbiAgICBvbkVycm9yOiAoZSkgPT4gc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEFwaUVycm9yID8gZS5tZXNzYWdlIDogXCJGYWxoYSBhbyByZWdpc3RyYXIgbyBwYWdhbWVudG8gcGFyY2lhbC5cIiksXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8T3ZlcmxheSB0aXRsZT1cIlBhZ2FtZW50byBwYXJjaWFsXCIgb25DbG9zZT17b25DbG9zZX0+XHJcbiAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiLCBtYXJnaW46IDAgfX0+XHJcbiAgICAgICAgQ2xpZW50ZSBzYWluZG8gYW50ZXM/IFJlZ2lzdHJlIG8gdmFsb3IgcGFnbyDigJQgYSBtZXNhIGNvbnRpbnVhIGFiZXJ0YSBlIG9cclxuICAgICAgICByZXN0YW50ZSDDqSBjb2JyYWRvIG5vIGZlY2hhbWVudG8uIFJlc3RhbnRlIGF0dWFsOntcIiBcIn1cclxuICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tYW1iZXIpXCIgfX0+e2Zvcm1hdEJSTChyZW1haW5pbmcpfTwvc3Ryb25nPlxyXG4gICAgICA8L3A+XHJcblxyXG4gICAgICB7bm9TZXNzaW9uICYmIChcclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+XHJcbiAgICAgICAgICBPIGNhaXhhIGVzdMOhIGZlY2hhZG8g4oCUIGFicmEgdW1hIHNlc3PDo28gKGJvdMOjbyBDYWl4YSBubyB0b3BvKSBwYXJhIHJlY2ViZXIuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlF1ZW0gcGFnb3UgKG9wY2lvbmFsKTwvc3Bhbj5cclxuICAgICAgICA8aW5wdXQgcGxhY2Vob2xkZXI9XCJleC46IENhcmxvc1wiIHZhbHVlPXtwYXllck5hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGF5ZXJOYW1lKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCwgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCIxLjNmciAxZnJcIiB9fT5cclxuICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5Gb3JtYSBkZSBwYWdhbWVudG88L3NwYW4+XHJcbiAgICAgICAgICA8c2VsZWN0IHZhbHVlPXttZXRob2RJZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRNZXRob2RJZChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX0+XHJcbiAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhwYXltZW50TWV0aG9kTGFiZWwpLm1hcCgoW2lkLCBsYWJlbF0pID0+IChcclxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17aWR9IHZhbHVlPXtpZH0+e2xhYmVsfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+VmFsb3IgKFIkKTwvc3Bhbj5cclxuICAgICAgICAgIDxpbnB1dCBpbnB1dE1vZGU9XCJkZWNpbWFsXCIgcGxhY2Vob2xkZXI9XCI2NSw1NVwiIHZhbHVlPXthbW91bnR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QW1vdW50KGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtuZWVkc1JlY2VpcHQobWV0aG9kSWQpICYmIChcclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ29tcHJvdmFudGUgLyBhdXRvcml6YcOnw6NvXCJcclxuICAgICAgICAgIHZhbHVlPXthdXRob3JpemF0aW9uQ29kZX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QXV0aG9yaXphdGlvbkNvZGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7dmFsdWUgIT09IG51bGwgJiYgdmFsdWUgPiByZW1haW5pbmcgJiYgKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj5PIHZhbG9yIGV4Y2VkZSBvIHJlc3RhbnRlIGRhIGNvbnRhICh7Zm9ybWF0QlJMKHJlbWFpbmluZyl9KS48L3A+XHJcbiAgICAgICl9XHJcbiAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcblxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIlxyXG4gICAgICAgIGRpc2FibGVkPXt2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA+IHJlbWFpbmluZyB8fCBub1Nlc3Npb24gfHwgc2Vzc2lvblF1ZXJ5LmlzTG9hZGluZyB8fCBtdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gbXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgID5cclxuICAgICAgICB7bXV0YXRpb24uaXNQZW5kaW5nID8gXCJSZWdpc3RyYW5kb+KAplwiIDogXCJSZWdpc3RyYXIgcGFnYW1lbnRvIHBhcmNpYWxcIn1cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L092ZXJsYXk+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvb3JkZXJzL1BhcnRpYWxQYXltZW50RGlhbG9nLnRzeCJ9