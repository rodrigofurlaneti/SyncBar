import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Modal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Modal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useId = __vite__cjsImport3_react["useId"]; const useRef = __vite__cjsImport3_react["useRef"];
import { Button } from "/src/ui/Button.tsx";
const FOCUSABLE = 'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';
export function Modal({
  onClose,
  children,
  title,
  variant = "center",
  wide = false,
  dismissable = true,
  ariaLabel
}) {
  _s();
  const panelRef = useRef(null);
  const titleId = useId();
  const isDrawer = variant === "drawer";
  const onCloseRef = useRef(onClose);
  useEffect(() => {
    onCloseRef.current = onClose;
  }, [onClose]);
  const dismissableRef = useRef(dismissable);
  useEffect(() => {
    dismissableRef.current = dismissable;
  }, [dismissable]);
  useEffect(() => {
    const previouslyFocused = document.activeElement;
    const panel = panelRef.current;
    const focusables = panel?.querySelectorAll(FOCUSABLE);
    (focusables && focusables.length ? focusables[0] : panel)?.focus();
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKeyDown = (e) => {
      if (e.key === "Escape") {
        if (!dismissableRef.current) return;
        e.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (e.key === "Tab" && panel) {
        const items = Array.from(panel.querySelectorAll(FOCUSABLE)).filter(
          (el) => el.offsetParent !== null
        );
        if (items.length === 0) {
          e.preventDefault();
          return;
        }
        const first = items[0];
        const last = items[items.length - 1];
        const active = document.activeElement;
        if (e.shiftKey && active === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && active === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKeyDown, true);
    return () => {
      document.removeEventListener("keydown", onKeyDown, true);
      document.body.style.overflow = prevOverflow;
      previouslyFocused?.focus?.();
    };
  }, []);
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `modal-backdrop ${isDrawer ? "is-drawer" : "is-center"}`,
      onMouseDown: (e) => {
        if (dismissable && e.target === e.currentTarget) onClose();
      },
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          ref: panelRef,
          className: `modal-panel rise ${isDrawer ? "is-drawer" : "is-center"} ${wide ? "is-wide" : ""}`,
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": title ? titleId : void 0,
          "aria-label": title ? void 0 : ariaLabel,
          tabIndex: -1,
          children: [
            title && /* @__PURE__ */ jsxDEV("div", { className: "modal-head", children: [
              /* @__PURE__ */ jsxDEV("h3", { id: titleId, className: "display", style: { fontSize: "1.5rem" }, children: title }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Modal.tsx",
                lineNumber: 146,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { iconOnly: true, "aria-label": "Fechar", size: "sm", onClick: onClose, children: "✕" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Modal.tsx",
                lineNumber: 149,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Modal.tsx",
              lineNumber: 145,
              columnNumber: 9
            }, this),
            children
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Modal.tsx",
          lineNumber: 135,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Modal.tsx",
      lineNumber: 129,
      columnNumber: 5
    },
    this
  );
}
_s(Modal, "9zzh9ELNGfrg0qcPWulJLE+u+e4=");
_c = Modal;
var _c;
$RefreshReg$(_c, "Modal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Modal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Modal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEhZOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlIWixTQUFTQSxXQUFXQyxPQUFPQyxjQUFjO0FBRXpDLFNBQVNDLGNBQWM7QUFjdkIsTUFBTUMsWUFDSjtBQU1LLGdCQUFTQyxNQUFNO0FBQUEsRUFDcEJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWQyxPQUFPO0FBQUEsRUFDUEMsY0FBYztBQUFBLEVBQ2RDO0FBQ0ssR0FBRztBQUFBQyxLQUFBO0FBQ1IsUUFBTUMsV0FBV1osT0FBdUIsSUFBSTtBQUM1QyxRQUFNYSxVQUFVZCxNQUFNO0FBQ3RCLFFBQU1lLFdBQVdQLFlBQVk7QUFTN0IsUUFBTVEsYUFBYWYsT0FBT0ksT0FBTztBQUNqQ04sWUFBVSxNQUFNO0FBQ2RpQixlQUFXQyxVQUFVWjtBQUFBQSxFQUN2QixHQUFHLENBQUNBLE9BQU8sQ0FBQztBQVFaLFFBQU1hLGlCQUFpQmpCLE9BQU9TLFdBQVc7QUFDekNYLFlBQVUsTUFBTTtBQUNkbUIsbUJBQWVELFVBQVVQO0FBQUFBLEVBQzNCLEdBQUcsQ0FBQ0EsV0FBVyxDQUFDO0FBRWhCWCxZQUFVLE1BQU07QUFDZCxVQUFNb0Isb0JBQW9CQyxTQUFTQztBQUNuQyxVQUFNQyxRQUFRVCxTQUFTSTtBQUd2QixVQUFNTSxhQUFhRCxPQUFPRSxpQkFBOEJyQixTQUFTO0FBQ2pFLEtBQUNvQixjQUFjQSxXQUFXRSxTQUFTRixXQUFXLENBQUMsSUFBSUQsUUFBUUksTUFBTTtBQUdqRSxVQUFNQyxlQUFlUCxTQUFTUSxLQUFLQyxNQUFNQztBQUN6Q1YsYUFBU1EsS0FBS0MsTUFBTUMsV0FBVztBQUUvQixVQUFNQyxZQUFZQSxDQUFDQyxNQUFxQjtBQUN0QyxVQUFJQSxFQUFFQyxRQUFRLFVBQVU7QUFDdEIsWUFBSSxDQUFDZixlQUFlRCxRQUFTO0FBQzdCZSxVQUFFRSxnQkFBZ0I7QUFDbEJsQixtQkFBV0MsUUFBUTtBQUNuQjtBQUFBLE1BQ0Y7QUFDQSxVQUFJZSxFQUFFQyxRQUFRLFNBQVNYLE9BQU87QUFDNUIsY0FBTWEsUUFBUUMsTUFBTUMsS0FBS2YsTUFBTUUsaUJBQThCckIsU0FBUyxDQUFDLEVBQUVtQztBQUFBQSxVQUN2RSxDQUFDQyxPQUFPQSxHQUFHQyxpQkFBaUI7QUFBQSxRQUM5QjtBQUNBLFlBQUlMLE1BQU1WLFdBQVcsR0FBRztBQUN0Qk8sWUFBRVMsZUFBZTtBQUNqQjtBQUFBLFFBQ0Y7QUFDQSxjQUFNQyxRQUFRUCxNQUFNLENBQUM7QUFDckIsY0FBTVEsT0FBT1IsTUFBTUEsTUFBTVYsU0FBUyxDQUFDO0FBQ25DLGNBQU1tQixTQUFTeEIsU0FBU0M7QUFDeEIsWUFBSVcsRUFBRWEsWUFBWUQsV0FBV0YsT0FBTztBQUNsQ1YsWUFBRVMsZUFBZTtBQUNqQkUsZUFBS2pCLE1BQU07QUFBQSxRQUNiLFdBQVcsQ0FBQ00sRUFBRWEsWUFBWUQsV0FBV0QsTUFBTTtBQUN6Q1gsWUFBRVMsZUFBZTtBQUNqQkMsZ0JBQU1oQixNQUFNO0FBQUEsUUFDZDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUFOLGFBQVMwQixpQkFBaUIsV0FBV2YsV0FBVyxJQUFJO0FBQ3BELFdBQU8sTUFBTTtBQUNYWCxlQUFTMkIsb0JBQW9CLFdBQVdoQixXQUFXLElBQUk7QUFDdkRYLGVBQVNRLEtBQUtDLE1BQU1DLFdBQVdIO0FBQy9CUix5QkFBbUJPLFFBQVE7QUFBQSxJQUM3QjtBQUFBLEVBRUYsR0FBRyxFQUFFO0FBRUwsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVyxrQkFBa0JYLFdBQVcsY0FBYyxXQUFXO0FBQUEsTUFDakUsYUFBYSxDQUFDaUIsTUFBTTtBQUNsQixZQUFJdEIsZUFBZXNCLEVBQUVnQixXQUFXaEIsRUFBRWlCLGNBQWU1QyxTQUFRO0FBQUEsTUFDM0Q7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxLQUFLUTtBQUFBQSxVQUNMLFdBQVcsb0JBQW9CRSxXQUFXLGNBQWMsV0FBVyxJQUFJTixPQUFPLFlBQVksRUFBRTtBQUFBLFVBQzVGLE1BQUs7QUFBQSxVQUNMLGNBQVc7QUFBQSxVQUNYLG1CQUFpQkYsUUFBUU8sVUFBVW9DO0FBQUFBLFVBQ25DLGNBQVkzQyxRQUFRMkMsU0FBWXZDO0FBQUFBLFVBQ2hDLFVBQVU7QUFBQSxVQUVUSjtBQUFBQSxxQkFDQyx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFFBQUcsSUFBSU8sU0FBUyxXQUFVLFdBQVUsT0FBTyxFQUFFcUMsVUFBVSxTQUFTLEdBQzlENUMsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsVUFBTyxVQUFRLE1BQUMsY0FBVyxVQUFTLE1BQUssTUFBSyxTQUFTRixTQUFTLGlCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBRURDO0FBQUFBO0FBQUFBO0FBQUFBLFFBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQW9CQTtBQUFBO0FBQUEsSUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMkJBO0FBRUo7QUFBQ00sR0FuSGVSLE9BQUs7QUFBQSxLQUFMQTtBQUFLLElBQUFnRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VJZCIsInVzZVJlZiIsIkJ1dHRvbiIsIkZPQ1VTQUJMRSIsIk1vZGFsIiwib25DbG9zZSIsImNoaWxkcmVuIiwidGl0bGUiLCJ2YXJpYW50Iiwid2lkZSIsImRpc21pc3NhYmxlIiwiYXJpYUxhYmVsIiwiX3MiLCJwYW5lbFJlZiIsInRpdGxlSWQiLCJpc0RyYXdlciIsIm9uQ2xvc2VSZWYiLCJjdXJyZW50IiwiZGlzbWlzc2FibGVSZWYiLCJwcmV2aW91c2x5Rm9jdXNlZCIsImRvY3VtZW50IiwiYWN0aXZlRWxlbWVudCIsInBhbmVsIiwiZm9jdXNhYmxlcyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJsZW5ndGgiLCJmb2N1cyIsInByZXZPdmVyZmxvdyIsImJvZHkiLCJzdHlsZSIsIm92ZXJmbG93Iiwib25LZXlEb3duIiwiZSIsImtleSIsInN0b3BQcm9wYWdhdGlvbiIsIml0ZW1zIiwiQXJyYXkiLCJmcm9tIiwiZmlsdGVyIiwiZWwiLCJvZmZzZXRQYXJlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImZpcnN0IiwibGFzdCIsImFjdGl2ZSIsInNoaWZ0S2V5IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwidW5kZWZpbmVkIiwiZm9udFNpemUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VJZCwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCIuL0J1dHRvblwiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XHJcbiAgdGl0bGU/OiBSZWFjdE5vZGU7XHJcbiAgdmFyaWFudD86IFwiY2VudGVyXCIgfCBcImRyYXdlclwiO1xyXG4gIHdpZGU/OiBib29sZWFuO1xyXG4gIC8qKiBmZWNoYSBhbyBjbGljYXIgbm8gZnVuZG8gKGRlZmF1bHQ6IHRydWUpICovXHJcbiAgZGlzbWlzc2FibGU/OiBib29sZWFuO1xyXG4gIC8qKiByw7N0dWxvIGFjZXNzw612ZWwgcXVhbmRvIG7Do28gaMOhIHRpdGxlIHZpc8OtdmVsICovXHJcbiAgYXJpYUxhYmVsPzogc3RyaW5nO1xyXG59XHJcblxyXG5jb25zdCBGT0NVU0FCTEUgPVxyXG4gICdhW2hyZWZdLCBidXR0b246bm90KFtkaXNhYmxlZF0pLCB0ZXh0YXJlYSwgaW5wdXQsIHNlbGVjdCwgW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVwiLTFcIl0pJztcclxuXHJcbi8qKlxyXG4gKiBNb2RhbC9EcmF3ZXIgYWNlc3PDrXZlbDogcm9sZT1cImRpYWxvZ1wiLCBhcmlhLW1vZGFsLCB0cmFwIGRlIGZvY28sXHJcbiAqIEVzYyBwYXJhIGZlY2hhciwgcmV0b3JubyBkZSBmb2NvIGFvIGVsZW1lbnRvIGFudGVyaW9yIGUgc2Nyb2xsIGxvY2suXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gTW9kYWwoe1xyXG4gIG9uQ2xvc2UsXHJcbiAgY2hpbGRyZW4sXHJcbiAgdGl0bGUsXHJcbiAgdmFyaWFudCA9IFwiY2VudGVyXCIsXHJcbiAgd2lkZSA9IGZhbHNlLFxyXG4gIGRpc21pc3NhYmxlID0gdHJ1ZSxcclxuICBhcmlhTGFiZWwsXHJcbn06IFByb3BzKSB7XHJcbiAgY29uc3QgcGFuZWxSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xyXG4gIGNvbnN0IHRpdGxlSWQgPSB1c2VJZCgpO1xyXG4gIGNvbnN0IGlzRHJhd2VyID0gdmFyaWFudCA9PT0gXCJkcmF3ZXJcIjtcclxuXHJcbiAgLy8gb25DbG9zZSBxdWFzZSBzZW1wcmUgY2hlZ2EgY29tbyB1bWEgYXJyb3cgZnVuY3Rpb24gbm92YSBhIGNhZGEgcmVuZGVyIGRvXHJcbiAgLy8gcGFpIChleC46IG9uQ2xvc2U9eygpID0+IHNldENyZWF0aW5nKGZhbHNlKX0pLiBHdWFyZGFtb3MgYSB2ZXJzw6NvIG1haXNcclxuICAvLyByZWNlbnRlIG51bWEgcmVmIGUgbWFudGVtb3MgbyBlZmVpdG8gYWJhaXhvIGNvbSBkZXBzIFtdIChyb2RhIHPDsyBub1xyXG4gIC8vIG1vdW50L3VubW91bnQpIOKAlCBzZW7Do28sIGEgY2FkYSB0ZWNsYSBkaWdpdGFkYSBudW0gY2FtcG8gZG8gZm9ybXVsw6FyaW8gb1xyXG4gIC8vIGNvbXBvbmVudGUgcGFpIHJlLXJlbmRlcml6YSwgYG9uQ2xvc2VgIG11ZGEgZGUgaWRlbnRpZGFkZSwgbyBlZmVpdG9cclxuICAvLyByZWV4ZWN1dGEgZSByb3ViYSBvIGZvY28gZGUgdm9sdGEgcHJvIHByaW1laXJvIGVsZW1lbnRvIGZvY8OhdmVsIGRvIHBhaW5lbFxyXG4gIC8vIChvIGJvdMOjbyDinJUpLCB0aXJhbmRvIG8gY3Vyc29yIGRvIGNhbXBvIHF1ZSBhIHBlc3NvYSBlc3RhdmEgZGlnaXRhbmRvLlxyXG4gIGNvbnN0IG9uQ2xvc2VSZWYgPSB1c2VSZWYob25DbG9zZSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIG9uQ2xvc2VSZWYuY3VycmVudCA9IG9uQ2xvc2U7XHJcbiAgfSwgW29uQ2xvc2VdKTtcclxuXHJcbiAgLy8gTWVzbWEgcmF6w6NvIGRvIG9uQ2xvc2VSZWYgYWNpbWE6IG8gaGFuZGxlciBkZSB0ZWNsYWRvIMOpIG1vbnRhZG8gdW1hIHZleiAoZGVwcyBbXSksIGVudMOjb1xyXG4gIC8vIHByZWNpc2EgbGVyIGEgdmVyc8OjbyBtYWlzIHJlY2VudGUgZGUgYGRpc21pc3NhYmxlYCB2aWEgcmVmIOKAlCBzZW7Do28gdW0gbW9kYWwgYWJlcnRvIGNvbW9cclxuICAvLyBkaXNtaXNzYWJsZSBlIGRlcG9pcyB0cm9jYWRvIHByYSBuw6NvLWRpc21pc3NhYmxlIChvdSB2aWNlLXZlcnNhKSBtYW50ZXJpYSBvIGNvbXBvcnRhbWVudG9cclxuICAvLyBkZSBFc2MgZGEgcmVuZGVyaXphw6fDo28gaW5pY2lhbC4gQWNoYWRvIGRlIHJldmlzw6NvICh3ZWItZGVzaWduLWd1aWRlbGluZXMpOiBhbnRlcywgbyBjbGlxdWVcclxuICAvLyBubyBmdW5kbyByZXNwZWl0YXZhIGBkaXNtaXNzYWJsZWAgbWFzIGEgdGVjbGEgRXNjIGZlY2hhdmEgc2VtcHJlLCBpbmNvbmRpY2lvbmFsbWVudGUg4oCUXHJcbiAgLy8gaW5jb25zaXN0w6puY2lhIHF1ZSBxdWVicmF2YSBtb2RhaXMgbsOjby1kaXNtaXNzYWJsZSAoZXguOiBmbHV4byBjb20gYWx0ZXJhw6fDo28gbsOjbyBzYWx2YSkuXHJcbiAgY29uc3QgZGlzbWlzc2FibGVSZWYgPSB1c2VSZWYoZGlzbWlzc2FibGUpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBkaXNtaXNzYWJsZVJlZi5jdXJyZW50ID0gZGlzbWlzc2FibGU7XHJcbiAgfSwgW2Rpc21pc3NhYmxlXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBwcmV2aW91c2x5Rm9jdXNlZCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgYXMgSFRNTEVsZW1lbnQgfCBudWxsO1xyXG4gICAgY29uc3QgcGFuZWwgPSBwYW5lbFJlZi5jdXJyZW50O1xyXG5cclxuICAgIC8vIGZvY2EgbyBwcmltZWlybyBlbGVtZW50byBmb2PDoXZlbCAob3UgbyBwYWluZWwpIOKAlCBzw7MgbmEgYWJlcnR1cmFcclxuICAgIGNvbnN0IGZvY3VzYWJsZXMgPSBwYW5lbD8ucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oRk9DVVNBQkxFKTtcclxuICAgIChmb2N1c2FibGVzICYmIGZvY3VzYWJsZXMubGVuZ3RoID8gZm9jdXNhYmxlc1swXSA6IHBhbmVsKT8uZm9jdXMoKTtcclxuXHJcbiAgICAvLyBzY3JvbGwgbG9ja1xyXG4gICAgY29uc3QgcHJldk92ZXJmbG93ID0gZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdztcclxuICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSBcImhpZGRlblwiO1xyXG5cclxuICAgIGNvbnN0IG9uS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XHJcbiAgICAgIGlmIChlLmtleSA9PT0gXCJFc2NhcGVcIikge1xyXG4gICAgICAgIGlmICghZGlzbWlzc2FibGVSZWYuY3VycmVudCkgcmV0dXJuO1xyXG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgb25DbG9zZVJlZi5jdXJyZW50KCk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChlLmtleSA9PT0gXCJUYWJcIiAmJiBwYW5lbCkge1xyXG4gICAgICAgIGNvbnN0IGl0ZW1zID0gQXJyYXkuZnJvbShwYW5lbC5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PihGT0NVU0FCTEUpKS5maWx0ZXIoXHJcbiAgICAgICAgICAoZWwpID0+IGVsLm9mZnNldFBhcmVudCAhPT0gbnVsbCxcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChpdGVtcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgZmlyc3QgPSBpdGVtc1swXTtcclxuICAgICAgICBjb25zdCBsYXN0ID0gaXRlbXNbaXRlbXMubGVuZ3RoIC0gMV07XHJcbiAgICAgICAgY29uc3QgYWN0aXZlID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudDtcclxuICAgICAgICBpZiAoZS5zaGlmdEtleSAmJiBhY3RpdmUgPT09IGZpcnN0KSB7XHJcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICBsYXN0LmZvY3VzKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmICghZS5zaGlmdEtleSAmJiBhY3RpdmUgPT09IGxhc3QpIHtcclxuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgIGZpcnN0LmZvY3VzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIG9uS2V5RG93biwgdHJ1ZSk7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBvbktleURvd24sIHRydWUpO1xyXG4gICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gcHJldk92ZXJmbG93O1xyXG4gICAgICBwcmV2aW91c2x5Rm9jdXNlZD8uZm9jdXM/LigpO1xyXG4gICAgfTtcclxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHMgLS0gaW50ZW5jaW9uYWw6IHPDsyBubyBtb3VudC91bm1vdW50LCB2ZXIgY29tZW50w6FyaW8gYWNpbWFcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzTmFtZT17YG1vZGFsLWJhY2tkcm9wICR7aXNEcmF3ZXIgPyBcImlzLWRyYXdlclwiIDogXCJpcy1jZW50ZXJcIn1gfVxyXG4gICAgICBvbk1vdXNlRG93bj17KGUpID0+IHtcclxuICAgICAgICBpZiAoZGlzbWlzc2FibGUgJiYgZS50YXJnZXQgPT09IGUuY3VycmVudFRhcmdldCkgb25DbG9zZSgpO1xyXG4gICAgICB9fVxyXG4gICAgPlxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgcmVmPXtwYW5lbFJlZn1cclxuICAgICAgICBjbGFzc05hbWU9e2Btb2RhbC1wYW5lbCByaXNlICR7aXNEcmF3ZXIgPyBcImlzLWRyYXdlclwiIDogXCJpcy1jZW50ZXJcIn0gJHt3aWRlID8gXCJpcy13aWRlXCIgOiBcIlwifWB9XHJcbiAgICAgICAgcm9sZT1cImRpYWxvZ1wiXHJcbiAgICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxyXG4gICAgICAgIGFyaWEtbGFiZWxsZWRieT17dGl0bGUgPyB0aXRsZUlkIDogdW5kZWZpbmVkfVxyXG4gICAgICAgIGFyaWEtbGFiZWw9e3RpdGxlID8gdW5kZWZpbmVkIDogYXJpYUxhYmVsfVxyXG4gICAgICAgIHRhYkluZGV4PXstMX1cclxuICAgICAgPlxyXG4gICAgICAgIHt0aXRsZSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRcIj5cclxuICAgICAgICAgICAgPGgzIGlkPXt0aXRsZUlkfSBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS41cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAge3RpdGxlfVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8QnV0dG9uIGljb25Pbmx5IGFyaWEtbGFiZWw9XCJGZWNoYXJcIiBzaXplPVwic21cIiBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgICAgICDinJVcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy91aS9Nb2RhbC50c3gifQ==