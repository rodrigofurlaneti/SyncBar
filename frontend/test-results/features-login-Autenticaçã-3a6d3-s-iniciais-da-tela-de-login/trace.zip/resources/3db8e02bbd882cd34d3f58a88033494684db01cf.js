import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodOrdersPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  acceptIFoodDeliveryAddressChange,
  acceptIFoodDispute,
  assignIFoodDriver,
  cancelIFoodOrder,
  cancelIFoodOrderDriverRequest,
  confirmIFoodUserAddress,
  denyIFoodDeliveryAddressChange,
  dispatchIFoodLogistics,
  getIFoodCancellationReasons,
  getIFoodLogisticsDeliveries,
  getIFoodOrderTracking,
  getIFoodOrders,
  getIFoodOrderVirtualBag,
  markIFoodArrivedAtDestination,
  markIFoodArrivedAtOrigin,
  markIFoodGoingToOrigin,
  markIFoodOrderReady,
  rejectIFoodDispute,
  requestIFoodDeliveryAddressChange,
  requestIFoodDisputeAlternative,
  requestIFoodOrderDriver,
  startIFoodOrderPreparation,
  validateIFoodPickupCode,
  verifyIFoodDeliveryCode,
  verifyIFoodOrderDeliveryCode
} from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useToast } from "/src/ui/Toast.tsx";
import { Button } from "/src/ui/Button.tsx";
import { StatusBadge } from "/src/ui/StatusBadge.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { SelectField, TextField } from "/src/ui/Field.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
const REFRESH_INTERVAL_MS = 15e3;
const STATUS_LABEL = {
  PLACED: "Recebido",
  CONFIRMED: "Confirmado",
  PREPARATION_STARTED: "Em preparo",
  READY_TO_PICKUP: "Pronto",
  DISPATCHED: "Despachado",
  CONCLUDED: "Concluído",
  CANCELLED: "Cancelado"
};
const STATUS_COLOR = {
  PLACED: "var(--ink-faint)",
  CONFIRMED: "var(--info, #3b82f6)",
  PREPARATION_STARTED: "var(--warn, #d97706)",
  READY_TO_PICKUP: "var(--ok)",
  DISPATCHED: "var(--ok)",
  CONCLUDED: "var(--ink-faint)",
  CANCELLED: "var(--danger)"
};
const TYPE_LABEL = {
  DELIVERY: "Delivery",
  TAKEOUT: "Retirada",
  DINE_IN: "Consumo no local"
};
const isOwnFleetEligible = (order) => order.ifoodOrderType === "DELIVERY" && !!order.deliveredBy && order.deliveredBy !== "IFOOD" && order.status !== "CANCELLED";
const isIFoodTrackingEligible = (order) => order.ifoodOrderType === "DELIVERY" && order.deliveredBy === "IFOOD" && (order.status === "DISPATCHED" || order.status === "READY_TO_PICKUP");
const isPickupCodeEligible = (order) => order.ifoodOrderType === "TAKEOUT" && order.status === "READY_TO_PICKUP";
const LOGISTICS_STATUS_LABEL = {
  DRIVER_ASSIGNED: "Entregador atribuído",
  GOING_TO_ORIGIN: "A caminho da loja",
  ARRIVED_AT_ORIGIN: "Na loja",
  DISPATCHED: "A caminho do cliente",
  ARRIVED_AT_DESTINATION: "No endereço do cliente",
  DELIVERY_CODE_VERIFIED: "Entrega concluída"
};
const LOGISTICS_STATUS_COLOR = {
  DRIVER_ASSIGNED: "var(--ink-faint)",
  GOING_TO_ORIGIN: "var(--info, #3b82f6)",
  ARRIVED_AT_ORIGIN: "var(--info, #3b82f6)",
  DISPATCHED: "var(--warn, #d97706)",
  ARRIVED_AT_DESTINATION: "var(--warn, #d97706)",
  DELIVERY_CODE_VERIFIED: "var(--ok)"
};
function playNewOrderChime() {
  try {
    const AudioCtxCtor = window.AudioContext ?? window.webkitAudioContext;
    if (!AudioCtxCtor) return;
    const ctx = new AudioCtxCtor();
    const playBeep = (startTime, frequency) => {
      const oscillator = ctx.createOscillator();
      const gain = ctx.createGain();
      oscillator.type = "sine";
      oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(1e-4, startTime);
      gain.gain.exponentialRampToValueAtTime(0.3, startTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(1e-4, startTime + 0.25);
      oscillator.connect(gain);
      gain.connect(ctx.destination);
      oscillator.start(startTime);
      oscillator.stop(startTime + 0.3);
    };
    const now = ctx.currentTime;
    playBeep(now, 880);
    playBeep(now + 0.3, 1046.5);
    setTimeout(() => void ctx.close(), 800);
  } catch {
  }
}
export function IFoodOrdersPage() {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { branchId } = useAuthStore();
  const [cancellingOrder, setCancellingOrder] = useState(null);
  const [trackingOrder, setTrackingOrder] = useState(null);
  const [pickupCodeOrder, setPickupCodeOrder] = useState(null);
  const [advancedOrder, setAdvancedOrder] = useState(null);
  const ordersQuery = useQuery({
    queryKey: ["integrations", "ifood", "orders", branchId],
    queryFn: () => getIFoodOrders(branchId),
    refetchInterval: REFRESH_INTERVAL_MS
  });
  const knownOrderIdsRef = useRef(null);
  useEffect(() => {
    knownOrderIdsRef.current = null;
  }, [branchId]);
  useEffect(() => {
    const orders2 = ordersQuery.data;
    if (!orders2) return;
    const currentIds = new Set(orders2.map((order) => order.id));
    if (knownOrderIdsRef.current === null) {
      knownOrderIdsRef.current = currentIds;
      return;
    }
    const previouslyKnown = knownOrderIdsRef.current;
    const newOrders = orders2.filter((order) => !previouslyKnown.has(order.id));
    knownOrderIdsRef.current = currentIds;
    if (newOrders.length === 0) return;
    playNewOrderChime();
    for (const order of newOrders) {
      const typeLabel = TYPE_LABEL[order.ifoodOrderType] ?? order.ifoodOrderType;
      toast.info(
        `🔔 Novo pedido iFood — ${order.customerName} · ${typeLabel} · R$ ${order.totalAmount.toFixed(2)}`
      );
    }
  }, [ordersQuery.data, toast]);
  const deliveriesQuery = useQuery({
    queryKey: ["integrations", "ifood", "logistics", branchId],
    queryFn: () => getIFoodLogisticsDeliveries(branchId),
    refetchInterval: REFRESH_INTERVAL_MS
  });
  const invalidateOrders = () => void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "orders"] });
  const startPreparationMutation = useMutation({
    mutationFn: (id) => startIFoodOrderPreparation(id),
    onSuccess: () => {
      toast.success("Preparo iniciado no iFood.");
      invalidateOrders();
    },
    onError: () => toast.error("Não foi possível iniciar o preparo no iFood.")
  });
  const markReadyMutation = useMutation({
    mutationFn: (id) => markIFoodOrderReady(id),
    onSuccess: () => {
      toast.success("Pedido marcado como pronto no iFood.");
      invalidateOrders();
    },
    onError: () => toast.error("Não foi possível marcar como pronto no iFood.")
  });
  const orders = ordersQuery.data ?? [];
  const deliveries = deliveriesQuery.data ?? [];
  const deliveriesByIFoodOrderId = new Map(deliveries.map((d) => [d.ifoodOrderId, d]));
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1e3, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood", style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "← Integração iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 247,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Pedidos iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 250,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "novos pedidos chegam sozinhos e já são confirmados automaticamente — aqui você acompanha e avança o preparo (e, para entregas por frota própria, a logística)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 253,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 246,
      columnNumber: 7
    }, this),
    ordersQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: ordersQuery.error, what: "os pedidos do iFood" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 259,
      columnNumber: 31
    }, this),
    !ordersQuery.isLoading && orders.length === 0 && !ordersQuery.isError && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        title: "Nenhum pedido iFood em aberto",
        description: "Assim que um pedido novo chegar do iFood, ele aparece aqui automaticamente."
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 262,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12 }, children: orders.map(
      (order) => /* @__PURE__ */ jsxDEV(
        IFoodOrderCard,
        {
          order,
          delivery: deliveriesByIFoodOrderId.get(order.id),
          onStartPreparation: () => startPreparationMutation.mutate(order.id),
          onMarkReady: () => markReadyMutation.mutate(order.id),
          onCancel: () => setCancellingOrder(order),
          onTrack: () => setTrackingOrder(order),
          onValidatePickupCode: () => setPickupCodeOrder(order),
          onAdvanced: () => setAdvancedOrder(order),
          startPending: startPreparationMutation.isPending && startPreparationMutation.variables === order.id,
          readyPending: markReadyMutation.isPending && markReadyMutation.variables === order.id
        },
        order.id,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 270,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 268,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DisputesSection, { branchId }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 286,
      columnNumber: 7
    }, this),
    cancellingOrder && /* @__PURE__ */ jsxDEV(
      CancelOrderModal,
      {
        order: cancellingOrder,
        onClose: () => setCancellingOrder(null),
        onCancelled: () => {
          setCancellingOrder(null);
          invalidateOrders();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 289,
        columnNumber: 7
      },
      this
    ),
    trackingOrder && /* @__PURE__ */ jsxDEV(TrackOrderModal, { order: trackingOrder, onClose: () => setTrackingOrder(null) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 299,
      columnNumber: 25
    }, this),
    pickupCodeOrder && /* @__PURE__ */ jsxDEV(
      ValidatePickupCodeModal,
      {
        order: pickupCodeOrder,
        onClose: () => setPickupCodeOrder(null),
        onValidated: () => setPickupCodeOrder(null)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 302,
        columnNumber: 7
      },
      this
    ),
    advancedOrder && /* @__PURE__ */ jsxDEV(OrderAdvancedActionsModal, { order: advancedOrder, onClose: () => setAdvancedOrder(null) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 309,
      columnNumber: 25
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 245,
    columnNumber: 5
  }, this);
}
_s(IFoodOrdersPage, "lDXuQFSyag0GTdBxsrn7ta+9vGo=", false, function() {
  return [useQueryClient, useToast, useAuthStore, useQuery, useQuery, useMutation, useMutation];
});
_c = IFoodOrdersPage;
function IFoodOrderCard({
  order,
  delivery,
  onStartPreparation,
  onMarkReady,
  onCancel,
  onTrack,
  onValidatePickupCode,
  onAdvanced,
  startPending,
  readyPending
}) {
  const canStartPreparation = order.status === "CONFIRMED";
  const canMarkReady = order.status === "CONFIRMED" || order.status === "PREPARATION_STARTED";
  const canCancel = order.status !== "CANCELLED" && order.status !== "CONCLUDED";
  return /* @__PURE__ */ jsxDEV("section", { className: "ticket rise", style: { padding: 18, display: "grid", gap: 10 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 700, fontSize: "1.05rem" }, children: [
          "#",
          order.displayId ?? order.ifoodOrderId,
          " — ",
          order.customerName
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 345,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
          TYPE_LABEL[order.ifoodOrderType] ?? order.ifoodOrderType,
          order.customerPhone ? ` · ${order.customerPhone}` : ""
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 348,
          columnNumber: 11
        }, this),
        order.deliveryAddress && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: order.deliveryAddress }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 353,
          columnNumber: 11
        }, this),
        order.orderTiming === "SCHEDULED" && order.preparationStartDateTime && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--info, #3b82f6)", fontSize: "0.85rem", fontWeight: 600 }, children: [
          "📅 Agendado para",
          " ",
          new Date(order.preparationStartDateTime).toLocaleString("pt-BR", {
            day: "2-digit",
            month: "2-digit",
            hour: "2-digit",
            minute: "2-digit"
          })
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 356,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 344,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 6, justifyItems: "end" }, children: [
        /* @__PURE__ */ jsxDEV(StatusBadge, { color: STATUS_COLOR[order.status] ?? "var(--ink-faint)", children: STATUS_LABEL[order.status] ?? order.status }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 368,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: order.totalAmount.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 371,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 367,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 343,
      columnNumber: 7
    }, this),
    order.hasUnmappedItems && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--warn, #d97706)", fontSize: "0.85rem" }, children: "⚠ Este pedido tem itens que não foram encontrados no cardápio (código de barras não cadastrado) — confira o pedido na tela normal de Pedidos antes de preparar." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 378,
      columnNumber: 7
    }, this),
    isOwnFleetEligible(order) && /* @__PURE__ */ jsxDEV(LogisticsPanel, { ifoodOrderId: order.id, delivery }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 384,
      columnNumber: 37
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8, justifyContent: "flex-end" }, children: [
      isIFoodTrackingEligible(order) && /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: onTrack, children: "Rastrear entregador" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 388,
        columnNumber: 9
      }, this),
      isPickupCodeEligible(order) && /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: onValidatePickupCode, children: "Validar código de retirada" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 393,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: onAdvanced, children: "Mais ações" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 397,
        columnNumber: 9
      }, this),
      canStartPreparation && /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", loading: startPending, onClick: onStartPreparation, children: "Iniciar preparo" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 401,
        columnNumber: 9
      }, this),
      canMarkReady && /* @__PURE__ */ jsxDEV(Button, { variant: "primary", size: "sm", loading: readyPending, onClick: onMarkReady, children: "Marcar pronto" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 406,
        columnNumber: 9
      }, this),
      canCancel && /* @__PURE__ */ jsxDEV(Button, { variant: "danger", size: "sm", onClick: onCancel, children: "Cancelar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 411,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 386,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 342,
    columnNumber: 5
  }, this);
}
_c2 = IFoodOrderCard;
function LogisticsPanel({
  ifoodOrderId,
  delivery
}) {
  _s2();
  const queryClient = useQueryClient();
  const toast = useToast();
  const [assigning, setAssigning] = useState(false);
  const [verifyingCode, setVerifyingCode] = useState(false);
  const invalidateDeliveries = () => void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "logistics"] });
  const goingToOriginMutation = useMutation({
    mutationFn: () => markIFoodGoingToOrigin(ifoodOrderId),
    onSuccess: () => {
      toast.success("Entregador a caminho da loja.");
      invalidateDeliveries();
    },
    onError: () => toast.error("Não foi possível registrar a saída para a origem.")
  });
  const arrivedAtOriginMutation = useMutation({
    mutationFn: () => markIFoodArrivedAtOrigin(ifoodOrderId),
    onSuccess: () => {
      toast.success("Chegada na loja registrada.");
      invalidateDeliveries();
    },
    onError: () => toast.error("Não foi possível registrar a chegada na loja.")
  });
  const dispatchMutation = useMutation({
    mutationFn: () => dispatchIFoodLogistics(ifoodOrderId),
    onSuccess: () => {
      toast.success("Entrega despachada.");
      invalidateDeliveries();
    },
    onError: () => toast.error("Não foi possível despachar a entrega.")
  });
  const arrivedAtDestinationMutation = useMutation({
    mutationFn: () => markIFoodArrivedAtDestination(ifoodOrderId),
    onSuccess: () => {
      toast.success("Chegada no destino registrada.");
      invalidateDeliveries();
    },
    onError: () => toast.error("Não foi possível registrar a chegada no destino.")
  });
  if (!delivery) {
    return /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => setAssigning(true), children: "🛵 Atribuir entregador" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 478,
        columnNumber: 9
      }, this),
      assigning && /* @__PURE__ */ jsxDEV(
        AssignDriverModal,
        {
          ifoodOrderId,
          onClose: () => setAssigning(false),
          onAssigned: () => {
            setAssigning(false);
            invalidateDeliveries();
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 482,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 477,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(
    "section",
    {
      style: {
        display: "grid",
        gap: 8,
        padding: 10,
        borderRadius: 10,
        border: "1px dashed var(--border, rgba(0,0,0,0.12))"
      },
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
            /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600, fontSize: "0.9rem" }, children: [
              "🛵 ",
              delivery.driverName,
              " · ",
              delivery.driverPhone
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
              lineNumber: 507,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.8rem" }, children: delivery.driverVehicleType }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
              lineNumber: 510,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 506,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(StatusBadge, { color: LOGISTICS_STATUS_COLOR[delivery.status] ?? "var(--ink-faint)", children: LOGISTICS_STATUS_LABEL[delivery.status] ?? delivery.status }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 512,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 505,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8, justifyContent: "flex-end" }, children: [
          delivery.status === "DRIVER_ASSIGNED" && /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              loading: goingToOriginMutation.isPending,
              onClick: () => goingToOriginMutation.mutate(),
              children: "Saiu para retirada"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
              lineNumber: 519,
              columnNumber: 9
            },
            this
          ),
          delivery.status === "GOING_TO_ORIGIN" && /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              loading: arrivedAtOriginMutation.isPending,
              onClick: () => arrivedAtOriginMutation.mutate(),
              children: "Chegou na loja"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
              lineNumber: 529,
              columnNumber: 9
            },
            this
          ),
          delivery.status === "ARRIVED_AT_ORIGIN" && /* @__PURE__ */ jsxDEV(Button, { variant: "primary", size: "sm", loading: dispatchMutation.isPending, onClick: () => dispatchMutation.mutate(), children: "Despachar" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 539,
            columnNumber: 9
          }, this),
          delivery.status === "DISPATCHED" && /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              loading: arrivedAtDestinationMutation.isPending,
              onClick: () => arrivedAtDestinationMutation.mutate(),
              children: "Chegou no destino"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
              lineNumber: 544,
              columnNumber: 9
            },
            this
          ),
          delivery.status === "ARRIVED_AT_DESTINATION" && /* @__PURE__ */ jsxDEV(Button, { variant: "primary", size: "sm", onClick: () => setVerifyingCode(true), children: "Verificar código de entrega" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 554,
            columnNumber: 9
          }, this),
          delivery.status === "DELIVERY_CODE_VERIFIED" && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ok)", fontSize: "0.85rem", fontWeight: 600 }, children: "✓ Entrega concluída" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 559,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 517,
          columnNumber: 7
        }, this),
        verifyingCode && /* @__PURE__ */ jsxDEV(
          VerifyDeliveryCodeModal,
          {
            ifoodOrderId,
            onClose: () => setVerifyingCode(false),
            onVerified: () => {
              setVerifyingCode(false);
              invalidateDeliveries();
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 564,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 496,
      columnNumber: 5
    },
    this
  );
}
_s2(LogisticsPanel, "MMCgQpUBtuyjjKHx1NKi9OQX2vU=", false, function() {
  return [useQueryClient, useToast, useMutation, useMutation, useMutation, useMutation];
});
_c3 = LogisticsPanel;
function AssignDriverModal({
  ifoodOrderId,
  onClose,
  onAssigned
}) {
  _s3();
  const toast = useToast();
  const [driverName, setDriverName] = useState("");
  const [driverPhone, setDriverPhone] = useState("");
  const [driverVehicleType, setDriverVehicleType] = useState("");
  const assignMutation = useMutation({
    mutationFn: () => assignIFoodDriver(ifoodOrderId, { driverName, driverPhone, driverVehicleType }),
    onSuccess: () => {
      toast.success("Entregador atribuído no iFood.");
      onAssigned();
    },
    onError: () => toast.error("Não foi possível atribuir o entregador — confira os dados e tente de novo.")
  });
  const canSubmit = driverName.trim().length > 0 && driverPhone.trim().length > 0 && driverVehicleType.trim().length > 0;
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: "Atribuir entregador", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 320 }, children: [
    /* @__PURE__ */ jsxDEV(
      TextField,
      {
        label: "Nome do entregador",
        value: driverName,
        onChange: (e) => setDriverName(e.target.value),
        autoFocus: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 605,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Telefone", value: driverPhone, onChange: (e) => setDriverPhone(e.target.value) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 611,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      TextField,
      {
        label: "Veículo",
        placeholder: "ex.: moto, bike, carro",
        value: driverVehicleType,
        onChange: (e) => setDriverVehicleType(e.target.value)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 612,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 619,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          disabled: !canSubmit,
          loading: assignMutation.isPending,
          onClick: () => assignMutation.mutate(),
          children: "Atribuir"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 622,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 618,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 604,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 603,
    columnNumber: 5
  }, this);
}
_s3(AssignDriverModal, "fP+AeqHvxkyhY0lFb9c6larMD4U=", false, function() {
  return [useToast, useMutation];
});
_c4 = AssignDriverModal;
function VerifyDeliveryCodeModal({
  ifoodOrderId,
  onClose,
  onVerified
}) {
  _s4();
  const toast = useToast();
  const [code, setCode] = useState("");
  const verifyMutation = useMutation({
    mutationFn: () => verifyIFoodDeliveryCode(ifoodOrderId, code),
    onSuccess: (result) => {
      if (result.codeMatched) {
        toast.success("Código confirmado — entrega concluída.");
        onVerified();
      } else {
        toast.error("Código incorreto — confira com o cliente e tente de novo.");
      }
    },
    onError: () => toast.error("Não foi possível verificar o código no iFood.")
  });
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: "Verificar código de entrega", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 280 }, children: [
    /* @__PURE__ */ jsxDEV(
      TextField,
      {
        label: "Código informado pelo cliente",
        value: code,
        onChange: (e) => setCode(e.target.value),
        autoFocus: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 664,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 671,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          disabled: !code.trim(),
          loading: verifyMutation.isPending,
          onClick: () => verifyMutation.mutate(),
          children: "Verificar"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 674,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 670,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 663,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 662,
    columnNumber: 5
  }, this);
}
_s4(VerifyDeliveryCodeModal, "w0FdKlr8A5y7jbjA/X/jqcUagXo=", false, function() {
  return [useToast, useMutation];
});
_c5 = VerifyDeliveryCodeModal;
function CancelOrderModal({
  order,
  onClose,
  onCancelled
}) {
  _s5();
  const toast = useToast();
  const [reasonCode, setReasonCode] = useState("");
  const reasonsQuery = useQuery({
    queryKey: ["integrations", "ifood", "cancellation-reasons", order.id],
    queryFn: () => getIFoodCancellationReasons(order.id)
  });
  const cancelMutation = useMutation({
    mutationFn: () => cancelIFoodOrder(order.id, reasonCode),
    onSuccess: () => {
      toast.success("Cancelamento solicitado ao iFood — o pedido some da lista quando o iFood confirmar.");
      onCancelled();
    },
    onError: () => toast.error("Não foi possível solicitar o cancelamento.")
  });
  const reasons = reasonsQuery.data ?? [];
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: `Cancelar pedido #${order.displayId ?? order.ifoodOrderId}`, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 320 }, children: [
    reasonsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: reasonsQuery.error, what: "os motivos de cancelamento" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 719,
      columnNumber: 34
    }, this),
    /* @__PURE__ */ jsxDEV(
      SelectField,
      {
        label: "Motivo do cancelamento",
        value: reasonCode,
        onChange: (e) => setReasonCode(e.target.value),
        disabled: reasonsQuery.isLoading,
        children: [
          /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione um motivo…" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 727,
            columnNumber: 11
          }, this),
          reasons.map(
            (reason) => /* @__PURE__ */ jsxDEV("option", { value: reason.code, children: reason.description }, reason.code, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
              lineNumber: 729,
              columnNumber: 11
            }, this)
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 721,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 736,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "danger",
          disabled: !reasonCode,
          loading: cancelMutation.isPending,
          onClick: () => cancelMutation.mutate(),
          children: "Confirmar cancelamento"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 739,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 735,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 718,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 717,
    columnNumber: 5
  }, this);
}
_s5(CancelOrderModal, "Pg4A2gHbNhILsOy2EnYKC3NYDo4=", false, function() {
  return [useToast, useQuery, useMutation];
});
_c6 = CancelOrderModal;
function TrackOrderModal({ order, onClose }) {
  _s6();
  const trackingQuery = useQuery({
    queryKey: ["integrations", "ifood", "order-tracking", order.id],
    queryFn: () => getIFoodOrderTracking(order.id),
    refetchInterval: 15e3
  });
  const tracking = trackingQuery.data;
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: `Rastrear #${order.displayId ?? order.ifoodOrderId}`, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12, minWidth: 300 }, children: [
    trackingQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: trackingQuery.error, what: "o rastreamento" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 768,
      columnNumber: 35
    }, this),
    trackingQuery.isLoading && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "Carregando…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 769,
      columnNumber: 37
    }, this),
    tracking && /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 14, display: "grid", gap: 6 }, children: [
      tracking.latitude != null && tracking.longitude != null ? /* @__PURE__ */ jsxDEV("span", { children: [
        "Posição do entregador: ",
        tracking.latitude.toFixed(5),
        ", ",
        tracking.longitude.toFixed(5)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 773,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "Posição ainda não disponível." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 777,
        columnNumber: 11
      }, this),
      tracking.expectedDelivery && /* @__PURE__ */ jsxDEV("span", { children: [
        "Previsão de entrega: ",
        new Date(tracking.expectedDelivery).toLocaleTimeString("pt-BR")
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 780,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 771,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Fechar" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 785,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 784,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 767,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 766,
    columnNumber: 5
  }, this);
}
_s6(TrackOrderModal, "E/YKow2D2caO2lbk6MZo5T8NH0s=", false, function() {
  return [useQuery];
});
_c7 = TrackOrderModal;
function ValidatePickupCodeModal({
  order,
  onClose,
  onValidated
}) {
  _s7();
  const toast = useToast();
  const [code, setCode] = useState("");
  const mutation = useMutation({
    mutationFn: () => validateIFoodPickupCode(order.id, code.trim()),
    onSuccess: (result) => {
      if (result.codeMatched) {
        toast.success("Código confirmado — pode entregar o pedido.");
        onValidated();
      } else {
        toast.error("Código incorreto — confira com o cliente e tente de novo.");
      }
    },
    onError: () => toast.error("Não foi possível validar o código no iFood.")
  });
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: `Validar retirada — #${order.displayId ?? order.ifoodOrderId}`, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14, minWidth: 280 }, children: [
    /* @__PURE__ */ jsxDEV(TextField, { label: "Código informado pelo cliente", value: code, onChange: (e) => setCode(e.target.value), autoFocus: true }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 823,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 825,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", disabled: !code.trim(), loading: mutation.isPending, onClick: () => mutation.mutate(), children: "Validar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 828,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 824,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 822,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 821,
    columnNumber: 5
  }, this);
}
_s7(ValidatePickupCodeModal, "+mJWAmAhFVe5ZdIXm1EJ2Hkhez0=", false, function() {
  return [useToast, useMutation];
});
_c8 = ValidatePickupCodeModal;
function OrderAdvancedActionsModal({ order, onClose }) {
  _s8();
  const toast = useToast();
  const [showBag, setShowBag] = useState(false);
  const [verifyingCode, setVerifyingCode] = useState(false);
  const [code, setCode] = useState("");
  const [showAddressChangeForm, setShowAddressChangeForm] = useState(false);
  const [addrStreetNumber, setAddrStreetNumber] = useState("");
  const [addrStreetName, setAddrStreetName] = useState("");
  const [addrComplement, setAddrComplement] = useState("");
  const [addrNeighborhood, setAddrNeighborhood] = useState("");
  const [addrCity, setAddrCity] = useState("");
  const [addrState, setAddrState] = useState("");
  const [addrReference, setAddrReference] = useState("");
  const bagQuery = useQuery({
    queryKey: ["integrations", "ifood", "virtual-bag", order.id],
    queryFn: () => getIFoodOrderVirtualBag(order.id),
    enabled: showBag
  });
  const requestDriverMutation = useMutation({
    mutationFn: () => requestIFoodOrderDriver(order.id),
    onSuccess: () => toast.success("Entregador solicitado (módulo Order) no iFood."),
    onError: () => toast.error("Não foi possível solicitar o entregador no iFood.")
  });
  const cancelDriverMutation = useMutation({
    mutationFn: () => cancelIFoodOrderDriverRequest(order.id),
    onSuccess: () => toast.success("Solicitação de entregador cancelada (módulo Order) no iFood."),
    onError: () => toast.error("Não foi possível cancelar a solicitação no iFood.")
  });
  const verifyCodeMutation = useMutation({
    mutationFn: () => verifyIFoodOrderDeliveryCode(order.id, code.trim()),
    onSuccess: (result) => {
      if (result.codeMatched) {
        toast.success("Código confirmado no iFood.");
        setVerifyingCode(false);
        setCode("");
      } else {
        toast.error("Código incorreto — confira com o cliente e tente de novo.");
      }
    },
    onError: () => toast.error("Não foi possível verificar o código no iFood.")
  });
  const requestAddressChangeMutation = useMutation({
    mutationFn: () => requestIFoodDeliveryAddressChange(order.id, {
      streetNumber: addrStreetNumber.trim(),
      streetName: addrStreetName.trim(),
      complement: addrComplement.trim() || void 0,
      neighborhood: addrNeighborhood.trim(),
      city: addrCity.trim(),
      state: addrState.trim(),
      reference: addrReference.trim() || void 0
    }),
    onSuccess: () => {
      toast.success("Troca de endereço solicitada ao iFood.");
      setShowAddressChangeForm(false);
      setAddrStreetNumber("");
      setAddrStreetName("");
      setAddrComplement("");
      setAddrNeighborhood("");
      setAddrCity("");
      setAddrState("");
      setAddrReference("");
    },
    onError: () => toast.error("Não foi possível solicitar a troca de endereço no iFood.")
  });
  const acceptAddressChangeMutation = useMutation({
    mutationFn: () => acceptIFoodDeliveryAddressChange(order.id),
    onSuccess: () => toast.success("Troca de endereço aceita no iFood."),
    onError: () => toast.error("Não foi possível aceitar a troca de endereço no iFood.")
  });
  const denyAddressChangeMutation = useMutation({
    mutationFn: () => denyIFoodDeliveryAddressChange(order.id),
    onSuccess: () => toast.success("Troca de endereço recusada no iFood."),
    onError: () => toast.error("Não foi possível recusar a troca de endereço no iFood.")
  });
  const confirmUserAddressMutation = useMutation({
    mutationFn: () => confirmIFoodUserAddress(order.id),
    onSuccess: () => toast.success("Endereço do usuário confirmado no iFood."),
    onError: () => toast.error("Não foi possível confirmar o endereço do usuário no iFood.")
  });
  const bag = bagQuery.data;
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, title: `Mais ações — #${order.displayId ?? order.ifoodOrderId}`, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 16, minWidth: 340 }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600, fontSize: "0.9rem" }, children: "Sacola virtual (Grocery)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 939,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => setShowBag(true), loading: showBag && bagQuery.isLoading, children: "Consultar sacola" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 940,
        columnNumber: 11
      }, this),
      showBag && bagQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: bagQuery.error, what: "a sacola do pedido" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 943,
        columnNumber: 43
      }, this),
      showBag && bag && /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 12, display: "grid", gap: 4, fontSize: "0.85rem" }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Status: ",
          bag.status ?? "—"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 946,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Itens: ",
          bag.items.length
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 947,
          columnNumber: 15
        }, this),
        bag.grossValueAmount && /* @__PURE__ */ jsxDEV("span", { children: [
          "Valor bruto: ",
          bag.grossValueAmount,
          " ",
          bag.grossValueCurrency ?? ""
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 949,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 945,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 938,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600, fontSize: "0.9rem" }, children: "Entregador (endpoint próprio do módulo Order)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 958,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8 }, children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", loading: requestDriverMutation.isPending, onClick: () => requestDriverMutation.mutate(), children: "Solicitar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 960,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", loading: cancelDriverMutation.isPending, onClick: () => cancelDriverMutation.mutate(), children: "Cancelar solicitação" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 963,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 959,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 957,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600, fontSize: "0.9rem" }, children: "Verificar código de entrega (módulo Order)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 970,
        columnNumber: 11
      }, this),
      !verifyingCode ? /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => setVerifyingCode(true), children: "Informar código" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 972,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Código", value: code, onChange: (e) => setCode(e.target.value), autoFocus: true }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 978,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 977,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "primary",
            size: "sm",
            disabled: !code.trim(),
            loading: verifyCodeMutation.isPending,
            onClick: () => verifyCodeMutation.mutate(),
            children: "Verificar"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 980,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 976,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 969,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600, fontSize: "0.9rem" }, children: "Troca de endereço de entrega (módulo Shipping)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 994,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.8rem" }, children: "fluxo bidirecional — solicite um novo endereço pra propor a troca, ou aceite/recuse/confirme quando é o cliente quem propõe pelo app dele" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 995,
        columnNumber: 11
      }, this),
      !showAddressChangeForm ? /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => setShowAddressChangeForm(true), children: "Solicitar novo endereço" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1001,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 100 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Número", value: addrStreetNumber, onChange: (e) => setAddrStreetNumber(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1008,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1007,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { flex: 2, minWidth: 180 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Rua", value: addrStreetName, onChange: (e) => setAddrStreetName(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1011,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1010,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1006,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Complemento", value: addrComplement, onChange: (e) => setAddrComplement(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1016,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1015,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Bairro", value: addrNeighborhood, onChange: (e) => setAddrNeighborhood(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1019,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1018,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1014,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { flex: 2, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Cidade", value: addrCity, onChange: (e) => setAddrCity(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1024,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1023,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 100 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Estado (UF)", value: addrState, onChange: (e) => setAddrState(e.target.value) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1027,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1026,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1022,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Referência (opcional)", value: addrReference, onChange: (e) => setAddrReference(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1030,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8, justifyContent: "flex-end" }, children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => setShowAddressChangeForm(false), children: "Cancelar" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
            lineNumber: 1032,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "primary",
              size: "sm",
              disabled: !addrStreetNumber.trim() || !addrStreetName.trim() || !addrNeighborhood.trim() || !addrCity.trim() || !addrState.trim(),
              loading: requestAddressChangeMutation.isPending,
              onClick: () => requestAddressChangeMutation.mutate(),
              children: "Enviar solicitação"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
              lineNumber: 1035,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1031,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1005,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 8 }, children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", loading: acceptAddressChangeMutation.isPending, onClick: () => acceptAddressChangeMutation.mutate(), children: "Aceitar troca" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1049,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", loading: denyAddressChangeMutation.isPending, onClick: () => denyAddressChangeMutation.mutate(), children: "Recusar troca" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1052,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", loading: confirmUserAddressMutation.isPending, onClick: () => confirmUserAddressMutation.mutate(), children: "Confirmar endereço do usuário" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1055,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1048,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 993,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Fechar" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 1062,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 1061,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 937,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 936,
    columnNumber: 5
  }, this);
}
_s8(OrderAdvancedActionsModal, "WvTfKbQX+kJBTqKYxWPoaQ63vCM=", false, function() {
  return [useToast, useQuery, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation];
});
_c9 = OrderAdvancedActionsModal;
function DisputesSection({ branchId }) {
  _s9();
  const toast = useToast();
  const [disputeId, setDisputeId] = useState("");
  const [reason, setReason] = useState("");
  const [lastResult, setLastResult] = useState(null);
  const [alternativeId, setAlternativeId] = useState("");
  const [alternativeType, setAlternativeType] = useState("");
  const [alternativeAmount, setAlternativeAmount] = useState("");
  const acceptMutation = useMutation({
    mutationFn: () => acceptIFoodDispute(branchId, disputeId.trim()),
    onSuccess: (result) => {
      toast.success("Disputa aceita no iFood.");
      setLastResult(result.status ?? "aceita");
      setDisputeId("");
    },
    onError: () => toast.error("Não foi possível aceitar a disputa — confira o ID e tente de novo.")
  });
  const rejectMutation = useMutation({
    mutationFn: () => rejectIFoodDispute(branchId, disputeId.trim(), reason.trim()),
    onSuccess: (result) => {
      toast.success("Disputa rejeitada no iFood.");
      setLastResult(result.status ?? "rejeitada");
      setDisputeId("");
      setReason("");
    },
    onError: () => toast.error("Não foi possível rejeitar a disputa — confira o ID, o motivo e tente de novo.")
  });
  const alternativeMutation = useMutation({
    mutationFn: () => requestIFoodDisputeAlternative(
      branchId,
      disputeId.trim(),
      alternativeId.trim(),
      alternativeType.trim(),
      alternativeAmount.trim() ? Number(alternativeAmount.trim().replace(",", ".")) : void 0,
      alternativeAmount.trim() ? "BRL" : void 0
    ),
    onSuccess: (result) => {
      toast.success("Alternativa proposta no iFood.");
      setLastResult(result.status ?? "alternativa proposta");
      setAlternativeId("");
      setAlternativeType("");
      setAlternativeAmount("");
    },
    onError: () => toast.error("Não foi possível propor a alternativa — confira os dados e tente de novo.")
  });
  return /* @__PURE__ */ jsxDEV("section", { className: "ticket", style: { padding: 18, display: "grid", gap: 12, marginTop: 22 }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
      /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.05rem" }, children: "Disputas (Handshake)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1129,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "quando o cliente abre uma disputa pós-entrega, o iFood avisa a equipe fora do SyncBar — informe aqui o ID da disputa pra aceitar, rejeitar ou propor uma alternativa" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1132,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 1128,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "end" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 200 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "ID da disputa", value: disputeId, onChange: (e) => setDisputeId(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1140,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1139,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 2, minWidth: 220 }, children: /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Motivo (obrigatório para rejeitar)",
          value: reason,
          onChange: (e) => setReason(e.target.value),
          placeholder: "ex.: cliente recebeu o pedido corretamente"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1143,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1142,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", disabled: !disputeId.trim(), loading: acceptMutation.isPending, onClick: () => acceptMutation.mutate(), children: "Aceitar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1150,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "danger",
          disabled: !disputeId.trim() || !reason.trim(),
          loading: rejectMutation.isPending,
          onClick: () => rejectMutation.mutate(),
          children: "Rejeitar"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1153,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 1138,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "end" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(TextField, { label: "ID da alternativa", value: alternativeId, onChange: (e) => setAlternativeId(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1165,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1164,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Tipo da alternativa",
          value: alternativeType,
          onChange: (e) => setAlternativeType(e.target.value),
          placeholder: "ex.: REFUND_ITEMS"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1168,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1167,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 120 }, children: /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Valor (opcional)",
          value: alternativeAmount,
          onChange: (e) => setAlternativeAmount(e.target.value),
          placeholder: "ex.: 10,00"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1176,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
        lineNumber: 1175,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "ghost",
          disabled: !disputeId.trim() || !alternativeId.trim() || !alternativeType.trim(),
          loading: alternativeMutation.isPending,
          onClick: () => alternativeMutation.mutate(),
          children: "Propor alternativa"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
          lineNumber: 1183,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 1163,
      columnNumber: 7
    }, this),
    lastResult && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.82rem" }, children: [
      "Última ação registrada — status no iFood: ",
      lastResult
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
      lineNumber: 1194,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx",
    lineNumber: 1127,
    columnNumber: 5
  }, this);
}
_s9(DisputesSection, "5giRLfbvDkO5hYsU7zONSAXu/1g=", false, function() {
  return [useToast, useMutation, useMutation, useMutation];
});
_c0 = DisputesSection;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0;
$RefreshReg$(_c, "IFoodOrdersPage");
$RefreshReg$(_c2, "IFoodOrderCard");
$RefreshReg$(_c3, "LogisticsPanel");
$RefreshReg$(_c4, "AssignDriverModal");
$RefreshReg$(_c5, "VerifyDeliveryCodeModal");
$RefreshReg$(_c6, "CancelOrderModal");
$RefreshReg$(_c7, "TrackOrderModal");
$RefreshReg$(_c8, "ValidatePickupCodeModal");
$RefreshReg$(_c9, "OrderAdvancedActionsModal");
$RefreshReg$(_c0, "DisputesSection");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodOrdersPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbU9ROzs7Ozs7Ozs7Ozs7Ozs7OztBQW5PUixTQUFTQSxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUdLO0FBQ1AsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBSTNCLE1BQU1DLHNCQUFzQjtBQUU1QixNQUFNQyxlQUF1QztBQUFBLEVBQzNDQyxRQUFRO0FBQUEsRUFDUkMsV0FBVztBQUFBLEVBQ1hDLHFCQUFxQjtBQUFBLEVBQ3JCQyxpQkFBaUI7QUFBQSxFQUNqQkMsWUFBWTtBQUFBLEVBQ1pDLFdBQVc7QUFBQSxFQUNYQyxXQUFXO0FBQ2I7QUFFQSxNQUFNQyxlQUF1QztBQUFBLEVBQzNDUCxRQUFRO0FBQUEsRUFDUkMsV0FBVztBQUFBLEVBQ1hDLHFCQUFxQjtBQUFBLEVBQ3JCQyxpQkFBaUI7QUFBQSxFQUNqQkMsWUFBWTtBQUFBLEVBQ1pDLFdBQVc7QUFBQSxFQUNYQyxXQUFXO0FBQ2I7QUFFQSxNQUFNRSxhQUFxQztBQUFBLEVBQ3pDQyxVQUFVO0FBQUEsRUFDVkMsU0FBUztBQUFBLEVBQ1RDLFNBQVM7QUFDWDtBQUlBLE1BQU1DLHFCQUFxQkEsQ0FBQ0MsVUFDMUJBLE1BQU1DLG1CQUFtQixjQUN6QixDQUFDLENBQUNELE1BQU1FLGVBQ1JGLE1BQU1FLGdCQUFnQixXQUN0QkYsTUFBTUcsV0FBVztBQUtuQixNQUFNQywwQkFBMEJBLENBQUNKLFVBQy9CQSxNQUFNQyxtQkFBbUIsY0FDekJELE1BQU1FLGdCQUFnQixZQUNyQkYsTUFBTUcsV0FBVyxnQkFBZ0JILE1BQU1HLFdBQVc7QUFHckQsTUFBTUUsdUJBQXVCQSxDQUFDTCxVQUM1QkEsTUFBTUMsbUJBQW1CLGFBQWFELE1BQU1HLFdBQVc7QUFFekQsTUFBTUcseUJBQWlEO0FBQUEsRUFDckRDLGlCQUFpQjtBQUFBLEVBQ2pCQyxpQkFBaUI7QUFBQSxFQUNqQkMsbUJBQW1CO0FBQUEsRUFDbkJsQixZQUFZO0FBQUEsRUFDWm1CLHdCQUF3QjtBQUFBLEVBQ3hCQyx3QkFBd0I7QUFDMUI7QUFFQSxNQUFNQyx5QkFBaUQ7QUFBQSxFQUNyREwsaUJBQWlCO0FBQUEsRUFDakJDLGlCQUFpQjtBQUFBLEVBQ2pCQyxtQkFBbUI7QUFBQSxFQUNuQmxCLFlBQVk7QUFBQSxFQUNabUIsd0JBQXdCO0FBQUEsRUFDeEJDLHdCQUF3QjtBQUMxQjtBQVFBLFNBQVNFLG9CQUFvQjtBQUMzQixNQUFJO0FBQ0YsVUFBTUMsZUFBZUMsT0FBT0MsZ0JBQWlCRCxPQUFtRUU7QUFDaEgsUUFBSSxDQUFDSCxhQUFjO0FBQ25CLFVBQU1JLE1BQU0sSUFBSUosYUFBYTtBQUM3QixVQUFNSyxXQUFXQSxDQUFDQyxXQUFtQkMsY0FBc0I7QUFDekQsWUFBTUMsYUFBYUosSUFBSUssaUJBQWlCO0FBQ3hDLFlBQU1DLE9BQU9OLElBQUlPLFdBQVc7QUFDNUJILGlCQUFXSSxPQUFPO0FBQ2xCSixpQkFBV0QsVUFBVU0sUUFBUU47QUFDN0JHLFdBQUtBLEtBQUtJLGVBQWUsTUFBUVIsU0FBUztBQUMxQ0ksV0FBS0EsS0FBS0ssNkJBQTZCLEtBQUtULFlBQVksSUFBSTtBQUM1REksV0FBS0EsS0FBS0ssNkJBQTZCLE1BQVFULFlBQVksSUFBSTtBQUMvREUsaUJBQVdRLFFBQVFOLElBQUk7QUFDdkJBLFdBQUtNLFFBQVFaLElBQUlhLFdBQVc7QUFDNUJULGlCQUFXVSxNQUFNWixTQUFTO0FBQzFCRSxpQkFBV1csS0FBS2IsWUFBWSxHQUFHO0FBQUEsSUFDakM7QUFDQSxVQUFNYyxNQUFNaEIsSUFBSWlCO0FBQ2hCaEIsYUFBU2UsS0FBSyxHQUFHO0FBQ2pCZixhQUFTZSxNQUFNLEtBQUssTUFBTTtBQUMxQkUsZUFBVyxNQUFNLEtBQUtsQixJQUFJbUIsTUFBTSxHQUFHLEdBQUc7QUFBQSxFQUN4QyxRQUFRO0FBQUEsRUFDTjtBQUVKO0FBRU8sZ0JBQVNDLGtCQUFrQjtBQUFBQyxLQUFBO0FBQ2hDLFFBQU1DLGNBQWMxRixlQUFlO0FBQ25DLFFBQU0yRixRQUFRaEUsU0FBUztBQUN2QixRQUFNLEVBQUVpRSxTQUFTLElBQUlsRSxhQUFhO0FBQ2xDLFFBQU0sQ0FBQ21FLGlCQUFpQkMsa0JBQWtCLElBQUlsRyxTQUFvQyxJQUFJO0FBQ3RGLFFBQU0sQ0FBQ21HLGVBQWVDLGdCQUFnQixJQUFJcEcsU0FBb0MsSUFBSTtBQUNsRixRQUFNLENBQUNxRyxpQkFBaUJDLGtCQUFrQixJQUFJdEcsU0FBb0MsSUFBSTtBQUN0RixRQUFNLENBQUN1RyxlQUFlQyxnQkFBZ0IsSUFBSXhHLFNBQW9DLElBQUk7QUFFbEYsUUFBTXlHLGNBQWN0RyxTQUFTO0FBQUEsSUFDM0J1RyxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsVUFBVVYsUUFBUTtBQUFBLElBQ3REVyxTQUFTQSxNQUFNM0YsZUFBZWdGLFFBQVE7QUFBQSxJQUN0Q1ksaUJBQWlCckU7QUFBQUEsRUFDbkIsQ0FBQztBQUtELFFBQU1zRSxtQkFBbUI5RyxPQUEyQixJQUFJO0FBR3hERCxZQUFVLE1BQU07QUFDZCtHLHFCQUFpQkMsVUFBVTtBQUFBLEVBQzdCLEdBQUcsQ0FBQ2QsUUFBUSxDQUFDO0FBRWJsRyxZQUFVLE1BQU07QUFDZCxVQUFNaUgsVUFBU04sWUFBWU87QUFDM0IsUUFBSSxDQUFDRCxRQUFRO0FBRWIsVUFBTUUsYUFBYSxJQUFJQyxJQUFJSCxRQUFPSSxJQUFJLENBQUM3RCxVQUFVQSxNQUFNOEQsRUFBRSxDQUFDO0FBRTFELFFBQUlQLGlCQUFpQkMsWUFBWSxNQUFNO0FBQ3JDRCx1QkFBaUJDLFVBQVVHO0FBQzNCO0FBQUEsSUFDRjtBQUVBLFVBQU1JLGtCQUFrQlIsaUJBQWlCQztBQUN6QyxVQUFNUSxZQUFZUCxRQUFPUSxPQUFPLENBQUNqRSxVQUFVLENBQUMrRCxnQkFBZ0JHLElBQUlsRSxNQUFNOEQsRUFBRSxDQUFDO0FBQ3pFUCxxQkFBaUJDLFVBQVVHO0FBRTNCLFFBQUlLLFVBQVVHLFdBQVcsRUFBRztBQUU1QnRELHNCQUFrQjtBQUNsQixlQUFXYixTQUFTZ0UsV0FBVztBQUM3QixZQUFNSSxZQUFZekUsV0FBV0ssTUFBTUMsY0FBYyxLQUFLRCxNQUFNQztBQUM1RHdDLFlBQU00QjtBQUFBQSxRQUNKLDBCQUEwQnJFLE1BQU1zRSxZQUFZLE1BQU1GLFNBQVMsU0FBU3BFLE1BQU11RSxZQUFZQyxRQUFRLENBQUMsQ0FBQztBQUFBLE1BQ2xHO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDckIsWUFBWU8sTUFBTWpCLEtBQUssQ0FBQztBQUU1QixRQUFNZ0Msa0JBQWtCNUgsU0FBUztBQUFBLElBQy9CdUcsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGFBQWFWLFFBQVE7QUFBQSxJQUN6RFcsU0FBU0EsTUFBTTdGLDRCQUE0QmtGLFFBQVE7QUFBQSxJQUNuRFksaUJBQWlCckU7QUFBQUEsRUFDbkIsQ0FBQztBQUVELFFBQU15RixtQkFBbUJBLE1BQ3ZCLEtBQUtsQyxZQUFZbUMsa0JBQWtCLEVBQUV2QixVQUFVLENBQUMsZ0JBQWdCLFNBQVMsUUFBUSxFQUFFLENBQUM7QUFFdEYsUUFBTXdCLDJCQUEyQmhJLFlBQVk7QUFBQSxJQUMzQ2lJLFlBQVlBLENBQUNmLE9BQWUxRiwyQkFBMkIwRixFQUFFO0FBQUEsSUFDekRnQixXQUFXQSxNQUFNO0FBQ2ZyQyxZQUFNc0MsUUFBUSw0QkFBNEI7QUFDMUNMLHVCQUFpQjtBQUFBLElBQ25CO0FBQUEsSUFDQU0sU0FBU0EsTUFBTXZDLE1BQU13QyxNQUFNLDhDQUE4QztBQUFBLEVBQzNFLENBQUM7QUFFRCxRQUFNQyxvQkFBb0J0SSxZQUFZO0FBQUEsSUFDcENpSSxZQUFZQSxDQUFDZixPQUFlL0Ysb0JBQW9CK0YsRUFBRTtBQUFBLElBQ2xEZ0IsV0FBV0EsTUFBTTtBQUNmckMsWUFBTXNDLFFBQVEsc0NBQXNDO0FBQ3BETCx1QkFBaUI7QUFBQSxJQUNuQjtBQUFBLElBQ0FNLFNBQVNBLE1BQU12QyxNQUFNd0MsTUFBTSwrQ0FBK0M7QUFBQSxFQUM1RSxDQUFDO0FBRUQsUUFBTXhCLFNBQVNOLFlBQVlPLFFBQVE7QUFDbkMsUUFBTXlCLGFBQWFWLGdCQUFnQmYsUUFBUTtBQUMzQyxRQUFNMEIsMkJBQTJCLElBQUlDLElBQUlGLFdBQVd0QixJQUFJLENBQUN5QixNQUFNLENBQUNBLEVBQUVDLGNBQWNELENBQUMsQ0FBQyxDQUFDO0FBRW5GLFNBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUVFLFNBQVMsSUFBSUMsVUFBVSxLQUFNQyxRQUFRLFNBQVMsR0FDM0Q7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVDLGNBQWMsR0FBRyxHQUM5QztBQUFBLDZCQUFDLFFBQUssSUFBRyxzQkFBcUIsT0FBTyxFQUFFQyxPQUFPLG9CQUFvQkMsVUFBVSxVQUFVLEdBQUcsa0NBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBRyxXQUFVLFdBQVUsT0FBTyxFQUFFQSxVQUFVLFNBQVMsR0FBRyw2QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUQsT0FBTyxvQkFBb0JDLFVBQVUsU0FBUyxHQUFHLDZLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBRUMxQyxZQUFZMkMsV0FBVyx1QkFBQyxjQUFXLE9BQU8zQyxZQUFZOEIsT0FBTyxNQUFLLHlCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdFO0FBQUEsSUFFdkYsQ0FBQzlCLFlBQVk0QyxhQUFhdEMsT0FBT1UsV0FBVyxLQUFLLENBQUNoQixZQUFZMkMsV0FDN0Q7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRTJGO0FBQUEsSUFJN0YsdUJBQUMsU0FBSSxPQUFPLEVBQUVFLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ3BDeEMsaUJBQU9JO0FBQUFBLE1BQUksQ0FBQzdELFVBQ1g7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDO0FBQUEsVUFDQSxVQUFVb0YseUJBQXlCYyxJQUFJbEcsTUFBTThELEVBQUU7QUFBQSxVQUMvQyxvQkFBb0IsTUFBTWMseUJBQXlCdUIsT0FBT25HLE1BQU04RCxFQUFFO0FBQUEsVUFDbEUsYUFBYSxNQUFNb0Isa0JBQWtCaUIsT0FBT25HLE1BQU04RCxFQUFFO0FBQUEsVUFDcEQsVUFBVSxNQUFNbEIsbUJBQW1CNUMsS0FBSztBQUFBLFVBQ3hDLFNBQVMsTUFBTThDLGlCQUFpQjlDLEtBQUs7QUFBQSxVQUNyQyxzQkFBc0IsTUFBTWdELG1CQUFtQmhELEtBQUs7QUFBQSxVQUNwRCxZQUFZLE1BQU1rRCxpQkFBaUJsRCxLQUFLO0FBQUEsVUFDeEMsY0FBYzRFLHlCQUF5QndCLGFBQWF4Qix5QkFBeUJ5QixjQUFjckcsTUFBTThEO0FBQUFBLFVBQ2pHLGNBQWNvQixrQkFBa0JrQixhQUFhbEIsa0JBQWtCbUIsY0FBY3JHLE1BQU04RDtBQUFBQTtBQUFBQSxRQVY5RTlELE1BQU04RDtBQUFBQSxRQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFXd0Y7QUFBQSxJQUV6RixLQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUVBLHVCQUFDLG1CQUFnQixZQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9DO0FBQUEsSUFFbkNuQixtQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBT0E7QUFBQUEsUUFDUCxTQUFTLE1BQU1DLG1CQUFtQixJQUFJO0FBQUEsUUFDdEMsYUFBYSxNQUFNO0FBQ2pCQSw2QkFBbUIsSUFBSTtBQUN2QjhCLDJCQUFpQjtBQUFBLFFBQ25CO0FBQUE7QUFBQSxNQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1JO0FBQUEsSUFJTDdCLGlCQUFpQix1QkFBQyxtQkFBZ0IsT0FBT0EsZUFBZSxTQUFTLE1BQU1DLGlCQUFpQixJQUFJLEtBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkU7QUFBQSxJQUU5RkMsbUJBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU9BO0FBQUFBLFFBQ1AsU0FBUyxNQUFNQyxtQkFBbUIsSUFBSTtBQUFBLFFBQ3RDLGFBQWEsTUFBTUEsbUJBQW1CLElBQUk7QUFBQTtBQUFBLE1BSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUc4QztBQUFBLElBSS9DQyxpQkFBaUIsdUJBQUMsNkJBQTBCLE9BQU9BLGVBQWUsU0FBUyxNQUFNQyxpQkFBaUIsSUFBSSxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVGO0FBQUEsT0FoRTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpRUE7QUFFSjtBQUFDWCxHQXRKZUQsaUJBQWU7QUFBQSxVQUNUeEYsZ0JBQ04yQixVQUNPRCxjQU1EM0IsVUEwQ0lBLFVBU1NELGFBU1BBLFdBQVc7QUFBQTtBQUFBLEtBckV2QjBGO0FBd0poQixTQUFTZ0UsZUFBZTtBQUFBLEVBQ3RCdEc7QUFBQUEsRUFDQXVHO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBWUYsR0FBRztBQUNELFFBQU1DLHNCQUFzQmhILE1BQU1HLFdBQVc7QUFDN0MsUUFBTThHLGVBQWVqSCxNQUFNRyxXQUFXLGVBQWVILE1BQU1HLFdBQVc7QUFDdEUsUUFBTStHLFlBQVlsSCxNQUFNRyxXQUFXLGVBQWVILE1BQU1HLFdBQVc7QUFFbkUsU0FDRSx1QkFBQyxhQUFRLFdBQVUsZUFBYyxPQUFPLEVBQUVxRixTQUFTLElBQUlRLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQzlFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVrQixnQkFBZ0IsaUJBQWlCbEIsS0FBSyxHQUFHLEdBQ3BGO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVELFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVtQixZQUFZLEtBQUt2QixVQUFVLFVBQVUsR0FBRztBQUFBO0FBQUEsVUFDbkQ3RixNQUFNcUgsYUFBYXJILE1BQU11RjtBQUFBQSxVQUFhO0FBQUEsVUFBSXZGLE1BQU1zRTtBQUFBQSxhQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFc0IsT0FBTyxvQkFBb0JDLFVBQVUsVUFBVSxHQUMzRGxHO0FBQUFBLHFCQUFXSyxNQUFNQyxjQUFjLEtBQUtELE1BQU1DO0FBQUFBLFVBQzFDRCxNQUFNc0gsZ0JBQWdCLE1BQU10SCxNQUFNc0gsYUFBYSxLQUFLO0FBQUEsYUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQ3RILE1BQU11SCxtQkFDTCx1QkFBQyxVQUFLLE9BQU8sRUFBRTNCLE9BQU8sa0JBQWtCQyxVQUFVLFVBQVUsR0FBSTdGLGdCQUFNdUgsbUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Y7QUFBQSxRQUV2RnZILE1BQU13SCxnQkFBZ0IsZUFBZXhILE1BQU15SCw0QkFDMUMsdUJBQUMsVUFBSyxPQUFPLEVBQUU3QixPQUFPLHdCQUF3QkMsVUFBVSxXQUFXdUIsWUFBWSxJQUFJLEdBQUc7QUFBQTtBQUFBLFVBQ25FO0FBQUEsVUFDaEIsSUFBSU0sS0FBSzFILE1BQU15SCx3QkFBd0IsRUFBRUUsZUFBZSxTQUFTO0FBQUEsWUFDaEVDLEtBQUs7QUFBQSxZQUNMQyxPQUFPO0FBQUEsWUFDUEMsTUFBTTtBQUFBLFlBQ05DLFFBQVE7QUFBQSxVQUNWLENBQUM7QUFBQSxhQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFL0IsU0FBUyxRQUFRQyxLQUFLLEdBQUcrQixjQUFjLE1BQU0sR0FDekQ7QUFBQSwrQkFBQyxlQUFZLE9BQU90SSxhQUFhTSxNQUFNRyxNQUFNLEtBQUssb0JBQy9DakIsdUJBQWFjLE1BQU1HLE1BQU0sS0FBS0gsTUFBTUcsVUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRWlILFlBQVksSUFBSSxHQUM1QnBILGdCQUFNdUUsWUFBWW9ELGVBQWUsU0FBUyxFQUFFTSxPQUFPLFlBQVlDLFVBQVUsTUFBTSxDQUFDLEtBRG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdDQTtBQUFBLElBRUNsSSxNQUFNbUksb0JBQ0wsdUJBQUMsVUFBSyxPQUFPLEVBQUV2QyxPQUFPLHdCQUF3QkMsVUFBVSxVQUFVLEdBQUcsK0tBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBR0Q5RixtQkFBbUJDLEtBQUssS0FBSyx1QkFBQyxrQkFBZSxjQUFjQSxNQUFNOEQsSUFBSSxZQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJEO0FBQUEsSUFFekYsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFbUMsS0FBSyxHQUFHa0IsZ0JBQWdCLFdBQVcsR0FDakUvRztBQUFBQSw4QkFBd0JKLEtBQUssS0FDNUIsdUJBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFNBQVMyRyxTQUFTLG1DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVEdEcscUJBQXFCTCxLQUFLLEtBQ3pCLHVCQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTNEcsc0JBQXNCLDBDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVGLHVCQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTQyxZQUFZLDBCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDRyx1QkFDQyx1QkFBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLE1BQUssU0FBU0YsY0FBYyxTQUFTTixvQkFBb0IsK0JBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRURTLGdCQUNDLHVCQUFDLFVBQU8sU0FBUSxXQUFVLE1BQUssTUFBSyxTQUFTRixjQUFjLFNBQVNOLGFBQWEsNkJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRURTLGFBQ0MsdUJBQUMsVUFBTyxTQUFRLFVBQVMsTUFBSyxNQUFLLFNBQVNSLFVBQVUsd0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxPQXpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEVBO0FBRUo7QUFLQTBCLE1BN0dTOUI7QUE4R1QsU0FBUytCLGVBQWU7QUFBQSxFQUN0QjlDO0FBQUFBLEVBQ0FnQjtBQUlGLEdBQUc7QUFBQStCLE1BQUE7QUFDRCxRQUFNOUYsY0FBYzFGLGVBQWU7QUFDbkMsUUFBTTJGLFFBQVFoRSxTQUFTO0FBQ3ZCLFFBQU0sQ0FBQzhKLFdBQVdDLFlBQVksSUFBSTlMLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMrTCxlQUFlQyxnQkFBZ0IsSUFBSWhNLFNBQVMsS0FBSztBQUV4RCxRQUFNaU0sdUJBQXVCQSxNQUMzQixLQUFLbkcsWUFBWW1DLGtCQUFrQixFQUFFdkIsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFdBQVcsRUFBRSxDQUFDO0FBRXpGLFFBQU13Rix3QkFBd0JoTSxZQUFZO0FBQUEsSUFDeENpSSxZQUFZQSxNQUFNL0csdUJBQXVCeUgsWUFBWTtBQUFBLElBQ3JEVCxXQUFXQSxNQUFNO0FBQ2ZyQyxZQUFNc0MsUUFBUSwrQkFBK0I7QUFDN0M0RCwyQkFBcUI7QUFBQSxJQUN2QjtBQUFBLElBQ0EzRCxTQUFTQSxNQUFNdkMsTUFBTXdDLE1BQU0sbURBQW1EO0FBQUEsRUFDaEYsQ0FBQztBQUVELFFBQU00RCwwQkFBMEJqTSxZQUFZO0FBQUEsSUFDMUNpSSxZQUFZQSxNQUFNaEgseUJBQXlCMEgsWUFBWTtBQUFBLElBQ3ZEVCxXQUFXQSxNQUFNO0FBQ2ZyQyxZQUFNc0MsUUFBUSw2QkFBNkI7QUFDM0M0RCwyQkFBcUI7QUFBQSxJQUN2QjtBQUFBLElBQ0EzRCxTQUFTQSxNQUFNdkMsTUFBTXdDLE1BQU0sK0NBQStDO0FBQUEsRUFDNUUsQ0FBQztBQUVELFFBQU02RCxtQkFBbUJsTSxZQUFZO0FBQUEsSUFDbkNpSSxZQUFZQSxNQUFNdkgsdUJBQXVCaUksWUFBWTtBQUFBLElBQ3JEVCxXQUFXQSxNQUFNO0FBQ2ZyQyxZQUFNc0MsUUFBUSxxQkFBcUI7QUFDbkM0RCwyQkFBcUI7QUFBQSxJQUN2QjtBQUFBLElBQ0EzRCxTQUFTQSxNQUFNdkMsTUFBTXdDLE1BQU0sdUNBQXVDO0FBQUEsRUFDcEUsQ0FBQztBQUVELFFBQU04RCwrQkFBK0JuTSxZQUFZO0FBQUEsSUFDL0NpSSxZQUFZQSxNQUFNakgsOEJBQThCMkgsWUFBWTtBQUFBLElBQzVEVCxXQUFXQSxNQUFNO0FBQ2ZyQyxZQUFNc0MsUUFBUSxnQ0FBZ0M7QUFDOUM0RCwyQkFBcUI7QUFBQSxJQUN2QjtBQUFBLElBQ0EzRCxTQUFTQSxNQUFNdkMsTUFBTXdDLE1BQU0sa0RBQWtEO0FBQUEsRUFDL0UsQ0FBQztBQUVELE1BQUksQ0FBQ3NCLFVBQVU7QUFDYixXQUNFLHVCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRU4sS0FBSyxHQUFHa0IsZ0JBQWdCLFdBQVcsR0FDbEU7QUFBQSw2QkFBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLE1BQUssU0FBUyxNQUFNcUIsYUFBYSxJQUFJLEdBQUcsc0NBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0NELGFBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxTQUFTLE1BQU1DLGFBQWEsS0FBSztBQUFBLFVBQ2pDLFlBQVksTUFBTTtBQUNoQkEseUJBQWEsS0FBSztBQUNsQkcsaUNBQXFCO0FBQUEsVUFDdkI7QUFBQTtBQUFBLFFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUk7QUFBQSxTQVhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLEVBRUo7QUFFQSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxPQUFPO0FBQUEsUUFDTDNDLFNBQVM7QUFBQSxRQUNUQyxLQUFLO0FBQUEsUUFDTFQsU0FBUztBQUFBLFFBQ1R3RCxjQUFjO0FBQUEsUUFDZEMsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxNQUVBO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUU5QixnQkFBZ0IsaUJBQWlCbEIsS0FBSyxFQUFFLEdBQ25GO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUVELFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsbUNBQUMsVUFBSyxPQUFPLEVBQUVtQixZQUFZLEtBQUt2QixVQUFVLFNBQVMsR0FBRztBQUFBO0FBQUEsY0FDaERVLFNBQVMyQztBQUFBQSxjQUFXO0FBQUEsY0FBSTNDLFNBQVM0QztBQUFBQSxpQkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUV2RCxPQUFPLG9CQUFvQkMsVUFBVSxTQUFTLEdBQUlVLG1CQUFTNkMscUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRGO0FBQUEsZUFKOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsZUFBWSxPQUFPeEksdUJBQXVCMkYsU0FBU3BHLE1BQU0sS0FBSyxvQkFDNURHLGlDQUF1QmlHLFNBQVNwRyxNQUFNLEtBQUtvRyxTQUFTcEcsVUFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUU4RixLQUFLLEdBQUdrQixnQkFBZ0IsV0FBVyxHQUNqRVo7QUFBQUEsbUJBQVNwRyxXQUFXLHFCQUNuQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsU0FBU3lJLHNCQUFzQnhDO0FBQUFBLGNBQy9CLFNBQVMsTUFBTXdDLHNCQUFzQnpDLE9BQU87QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBRURJLFNBQVNwRyxXQUFXLHFCQUNuQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsU0FBUzBJLHdCQUF3QnpDO0FBQUFBLGNBQ2pDLFNBQVMsTUFBTXlDLHdCQUF3QjFDLE9BQU87QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBRURJLFNBQVNwRyxXQUFXLHVCQUNuQix1QkFBQyxVQUFPLFNBQVEsV0FBVSxNQUFLLE1BQUssU0FBUzJJLGlCQUFpQjFDLFdBQVcsU0FBUyxNQUFNMEMsaUJBQWlCM0MsT0FBTyxHQUFHLHlCQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFREksU0FBU3BHLFdBQVcsZ0JBQ25CO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixNQUFLO0FBQUEsY0FDTCxTQUFTNEksNkJBQTZCM0M7QUFBQUEsY0FDdEMsU0FBUyxNQUFNMkMsNkJBQTZCNUMsT0FBTztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFFREksU0FBU3BHLFdBQVcsNEJBQ25CLHVCQUFDLFVBQU8sU0FBUSxXQUFVLE1BQUssTUFBSyxTQUFTLE1BQU11SSxpQkFBaUIsSUFBSSxHQUFHLDJDQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFRG5DLFNBQVNwRyxXQUFXLDRCQUNuQix1QkFBQyxVQUFLLE9BQU8sRUFBRXlGLE9BQU8sYUFBYUMsVUFBVSxXQUFXdUIsWUFBWSxJQUFJLEdBQUcsbUNBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThGO0FBQUEsYUExQ2xHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxRQUVDcUIsaUJBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTLE1BQU1DLGlCQUFpQixLQUFLO0FBQUEsWUFDckMsWUFBWSxNQUFNO0FBQ2hCQSwrQkFBaUIsS0FBSztBQUN0QkMsbUNBQXFCO0FBQUEsWUFDdkI7QUFBQTtBQUFBLFVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUk7QUFBQTtBQUFBO0FBQUEsSUExRVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBNkVBO0FBRUo7QUFBQ0wsSUF2SlFELGdCQUFjO0FBQUEsVUFPRHZMLGdCQUNOMkIsVUFPZ0I3QixhQVNFQSxhQVNQQSxhQVNZQSxXQUFXO0FBQUE7QUFBQSxNQTFDekN5TDtBQXlKVCxTQUFTZ0Isa0JBQWtCO0FBQUEsRUFDekI5RDtBQUFBQSxFQUNBK0Q7QUFBQUEsRUFDQUM7QUFLRixHQUFHO0FBQUFDLE1BQUE7QUFDRCxRQUFNL0csUUFBUWhFLFNBQVM7QUFDdkIsUUFBTSxDQUFDeUssWUFBWU8sYUFBYSxJQUFJL00sU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3lNLGFBQWFPLGNBQWMsSUFBSWhOLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUMwTSxtQkFBbUJPLG9CQUFvQixJQUFJak4sU0FBUyxFQUFFO0FBRTdELFFBQU1rTixpQkFBaUJoTixZQUFZO0FBQUEsSUFDakNpSSxZQUFZQSxNQUFNNUgsa0JBQWtCc0ksY0FBYyxFQUFFMkQsWUFBWUMsYUFBYUMsa0JBQWtCLENBQUM7QUFBQSxJQUNoR3RFLFdBQVdBLE1BQU07QUFDZnJDLFlBQU1zQyxRQUFRLGdDQUFnQztBQUM5Q3dFLGlCQUFXO0FBQUEsSUFDYjtBQUFBLElBQ0F2RSxTQUFTQSxNQUFNdkMsTUFBTXdDLE1BQU0sNEVBQTRFO0FBQUEsRUFDekcsQ0FBQztBQUVELFFBQU00RSxZQUFZWCxXQUFXWSxLQUFLLEVBQUUzRixTQUFTLEtBQUtnRixZQUFZVyxLQUFLLEVBQUUzRixTQUFTLEtBQUtpRixrQkFBa0JVLEtBQUssRUFBRTNGLFNBQVM7QUFFckgsU0FDRSx1QkFBQyxTQUFNLFNBQWtCLE9BQU0sdUJBQzdCLGlDQUFDLFNBQUksT0FBTyxFQUFFNkIsU0FBUyxRQUFRQyxLQUFLLElBQUk4RCxVQUFVLElBQUksR0FDcEQ7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sT0FBT2I7QUFBQUEsUUFDUCxVQUFVLENBQUNjLE1BQU1QLGNBQWNPLEVBQUVDLE9BQU90SSxLQUFLO0FBQUEsUUFDN0MsV0FBUztBQUFBO0FBQUEsTUFKWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJVztBQUFBLElBRVgsdUJBQUMsYUFBVSxPQUFNLFlBQVcsT0FBT3dILGFBQWEsVUFBVSxDQUFDYSxNQUFNTixlQUFlTSxFQUFFQyxPQUFPdEksS0FBSyxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdHO0FBQUEsSUFDaEc7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLE9BQU95SDtBQUFBQSxRQUNQLFVBQVUsQ0FBQ1ksTUFBTUwscUJBQXFCSyxFQUFFQyxPQUFPdEksS0FBSztBQUFBO0FBQUEsTUFKdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXdEO0FBQUEsSUFFeEQsdUJBQUMsU0FBSSxPQUFPLEVBQUVxRSxTQUFTLFFBQVFDLEtBQUssSUFBSWtCLGdCQUFnQixXQUFXLEdBQ2pFO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBU21DLFNBQVMsc0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVE7QUFBQSxVQUNSLFVBQVUsQ0FBQ087QUFBQUEsVUFDWCxTQUFTRCxlQUFleEQ7QUFBQUEsVUFDeEIsU0FBUyxNQUFNd0QsZUFBZXpELE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsT0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkJBO0FBRUo7QUFBQ3FELElBekRRSCxtQkFBaUI7QUFBQSxVQVNWNUssVUFLUzdCLFdBQVc7QUFBQTtBQUFBLE1BZDNCeU07QUEyRFQsU0FBU2Esd0JBQXdCO0FBQUEsRUFDL0IzRTtBQUFBQSxFQUNBK0Q7QUFBQUEsRUFDQWE7QUFLRixHQUFHO0FBQUFDLE1BQUE7QUFDRCxRQUFNM0gsUUFBUWhFLFNBQVM7QUFDdkIsUUFBTSxDQUFDNEwsTUFBTUMsT0FBTyxJQUFJNU4sU0FBUyxFQUFFO0FBRW5DLFFBQU02TixpQkFBaUIzTixZQUFZO0FBQUEsSUFDakNpSSxZQUFZQSxNQUFNdkcsd0JBQXdCaUgsY0FBYzhFLElBQUk7QUFBQSxJQUM1RHZGLFdBQVdBLENBQUMwRixXQUFXO0FBQ3JCLFVBQUlBLE9BQU9DLGFBQWE7QUFDdEJoSSxjQUFNc0MsUUFBUSx3Q0FBd0M7QUFDdERvRixtQkFBVztBQUFBLE1BQ2IsT0FBTztBQUNMMUgsY0FBTXdDLE1BQU0sMkRBQTJEO0FBQUEsTUFDekU7QUFBQSxJQUNGO0FBQUEsSUFDQUQsU0FBU0EsTUFBTXZDLE1BQU13QyxNQUFNLCtDQUErQztBQUFBLEVBQzVFLENBQUM7QUFFRCxTQUNFLHVCQUFDLFNBQU0sU0FBa0IsT0FBTSwrQkFDN0IsaUNBQUMsU0FBSSxPQUFPLEVBQUVlLFNBQVMsUUFBUUMsS0FBSyxJQUFJOEQsVUFBVSxJQUFJLEdBQ3BEO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLE9BQU9NO0FBQUFBLFFBQ1AsVUFBVSxDQUFDTCxNQUFNTSxRQUFRTixFQUFFQyxPQUFPdEksS0FBSztBQUFBLFFBQ3ZDLFdBQVM7QUFBQTtBQUFBLE1BSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSVc7QUFBQSxJQUVYLHVCQUFDLFNBQUksT0FBTyxFQUFFcUUsU0FBUyxRQUFRQyxLQUFLLElBQUlrQixnQkFBZ0IsV0FBVyxHQUNqRTtBQUFBLDZCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVNtQyxTQUFTLHNCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixVQUFVLENBQUNlLEtBQUtQLEtBQUs7QUFBQSxVQUNyQixTQUFTUyxlQUFlbkU7QUFBQUEsVUFDeEIsU0FBUyxNQUFNbUUsZUFBZXBFLE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsT0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9CQSxLQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0JBO0FBRUo7QUFBQ2lFLElBbERRRix5QkFBdUI7QUFBQSxVQVNoQnpMLFVBR1M3QixXQUFXO0FBQUE7QUFBQSxNQVozQnNOO0FBb0RULFNBQVNRLGlCQUFpQjtBQUFBLEVBQ3hCMUs7QUFBQUEsRUFDQXNKO0FBQUFBLEVBQ0FxQjtBQUtGLEdBQUc7QUFBQUMsTUFBQTtBQUNELFFBQU1uSSxRQUFRaEUsU0FBUztBQUN2QixRQUFNLENBQUNvTSxZQUFZQyxhQUFhLElBQUlwTyxTQUFTLEVBQUU7QUFFL0MsUUFBTXFPLGVBQWVsTyxTQUFTO0FBQUEsSUFDNUJ1RyxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsd0JBQXdCcEQsTUFBTThELEVBQUU7QUFBQSxJQUNwRVQsU0FBU0EsTUFBTTlGLDRCQUE0QnlDLE1BQU04RCxFQUFFO0FBQUEsRUFDckQsQ0FBQztBQUVELFFBQU1rSCxpQkFBaUJwTyxZQUFZO0FBQUEsSUFDakNpSSxZQUFZQSxNQUFNM0gsaUJBQWlCOEMsTUFBTThELElBQUkrRyxVQUFVO0FBQUEsSUFDdkQvRixXQUFXQSxNQUFNO0FBQ2ZyQyxZQUFNc0MsUUFBUSxxRkFBcUY7QUFDbkc0RixrQkFBWTtBQUFBLElBQ2Q7QUFBQSxJQUNBM0YsU0FBU0EsTUFBTXZDLE1BQU13QyxNQUFNLDRDQUE0QztBQUFBLEVBQ3pFLENBQUM7QUFFRCxRQUFNZ0csVUFBVUYsYUFBYXJILFFBQVE7QUFFckMsU0FDRSx1QkFBQyxTQUFNLFNBQWtCLE9BQU8sb0JBQW9CMUQsTUFBTXFILGFBQWFySCxNQUFNdUYsWUFBWSxJQUN2RixpQ0FBQyxTQUFJLE9BQU8sRUFBRVMsU0FBUyxRQUFRQyxLQUFLLElBQUk4RCxVQUFVLElBQUksR0FDbkRnQjtBQUFBQSxpQkFBYWpGLFdBQVcsdUJBQUMsY0FBVyxPQUFPaUYsYUFBYTlGLE9BQU8sTUFBSyxnQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RTtBQUFBLElBRWpHO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixPQUFPNEY7QUFBQUEsUUFDUCxVQUFVLENBQUNiLE1BQU1jLGNBQWNkLEVBQUVDLE9BQU90SSxLQUFLO0FBQUEsUUFDN0MsVUFBVW9KLGFBQWFoRjtBQUFBQSxRQUV2QjtBQUFBLGlDQUFDLFlBQU8sT0FBTSxJQUFHLG9DQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBLFVBQ3BDa0YsUUFBUXBIO0FBQUFBLFlBQUksQ0FBQ3FILFdBQ1osdUJBQUMsWUFBeUIsT0FBT0EsT0FBT2IsTUFDckNhLGlCQUFPQyxlQURHRCxPQUFPYixNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsVUFDRDtBQUFBO0FBQUE7QUFBQSxNQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVlBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXJFLFNBQVMsUUFBUUMsS0FBSyxJQUFJa0IsZ0JBQWdCLFdBQVcsR0FDakU7QUFBQSw2QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTbUMsU0FBUyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsVUFBVSxDQUFDdUI7QUFBQUEsVUFDWCxTQUFTRyxlQUFlNUU7QUFBQUEsVUFDeEIsU0FBUyxNQUFNNEUsZUFBZTdFLE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsT0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQSxLQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0NBO0FBRUo7QUFJQXlFLElBbkVTRixrQkFBZ0I7QUFBQSxVQVNUak0sVUFHTzVCLFVBS0VELFdBQVc7QUFBQTtBQUFBLE1BakIzQjhOO0FBb0VULFNBQVNVLGdCQUFnQixFQUFFcEwsT0FBT3NKLFFBQTRELEdBQUc7QUFBQStCLE1BQUE7QUFDL0YsUUFBTUMsZ0JBQWdCek8sU0FBUztBQUFBLElBQzdCdUcsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGtCQUFrQnBELE1BQU04RCxFQUFFO0FBQUEsSUFDOURULFNBQVNBLE1BQU01RixzQkFBc0J1QyxNQUFNOEQsRUFBRTtBQUFBLElBQzdDUixpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTWlJLFdBQVdELGNBQWM1SDtBQUUvQixTQUNFLHVCQUFDLFNBQU0sU0FBa0IsT0FBTyxhQUFhMUQsTUFBTXFILGFBQWFySCxNQUFNdUYsWUFBWSxJQUNoRixpQ0FBQyxTQUFJLE9BQU8sRUFBRVMsU0FBUyxRQUFRQyxLQUFLLElBQUk4RCxVQUFVLElBQUksR0FDbkR1QjtBQUFBQSxrQkFBY3hGLFdBQVcsdUJBQUMsY0FBVyxPQUFPd0YsY0FBY3JHLE9BQU8sTUFBSyxvQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RDtBQUFBLElBQ3RGcUcsY0FBY3ZGLGFBQWEsdUJBQUMsVUFBSyxPQUFPLEVBQUVILE9BQU8sbUJBQW1CLEdBQUcsMkJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUQ7QUFBQSxJQUNsRjJGLFlBQ0MsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFL0YsU0FBUyxJQUFJUSxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNuRXNGO0FBQUFBLGVBQVNDLFlBQVksUUFBUUQsU0FBU0UsYUFBYSxPQUNsRCx1QkFBQyxVQUFLO0FBQUE7QUFBQSxRQUNvQkYsU0FBU0MsU0FBU2hILFFBQVEsQ0FBQztBQUFBLFFBQUU7QUFBQSxRQUFHK0csU0FBU0UsVUFBVWpILFFBQVEsQ0FBQztBQUFBLFdBRHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBLHVCQUFDLFVBQUssT0FBTyxFQUFFb0IsT0FBTyxtQkFBbUIsR0FBRyw2Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLE1BRTFFMkYsU0FBU0csb0JBQ1IsdUJBQUMsVUFBSztBQUFBO0FBQUEsUUFBc0IsSUFBSWhFLEtBQUs2RCxTQUFTRyxnQkFBZ0IsRUFBRUMsbUJBQW1CLE9BQU87QUFBQSxXQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRGO0FBQUEsU0FUaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFFRix1QkFBQyxTQUFJLE9BQU8sRUFBRTNGLFNBQVMsUUFBUW1CLGdCQUFnQixXQUFXLEdBQ3hELGlDQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVNtQyxTQUFTLHNCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFSjtBQUVBK0IsSUF0Q1NELGlCQUFlO0FBQUEsVUFDQXZPLFFBQVE7QUFBQTtBQUFBLE1BRHZCdU87QUF1Q1QsU0FBU1Esd0JBQXdCO0FBQUEsRUFDL0I1TDtBQUFBQSxFQUNBc0o7QUFBQUEsRUFDQXVDO0FBS0YsR0FBRztBQUFBQyxNQUFBO0FBQ0QsUUFBTXJKLFFBQVFoRSxTQUFTO0FBQ3ZCLFFBQU0sQ0FBQzRMLE1BQU1DLE9BQU8sSUFBSTVOLFNBQVMsRUFBRTtBQUVuQyxRQUFNcVAsV0FBV25QLFlBQVk7QUFBQSxJQUMzQmlJLFlBQVlBLE1BQU14Ryx3QkFBd0IyQixNQUFNOEQsSUFBSXVHLEtBQUtQLEtBQUssQ0FBQztBQUFBLElBQy9EaEYsV0FBV0EsQ0FBQzBGLFdBQVc7QUFDckIsVUFBSUEsT0FBT0MsYUFBYTtBQUN0QmhJLGNBQU1zQyxRQUFRLDZDQUE2QztBQUMzRDhHLG9CQUFZO0FBQUEsTUFDZCxPQUFPO0FBQ0xwSixjQUFNd0MsTUFBTSwyREFBMkQ7QUFBQSxNQUN6RTtBQUFBLElBQ0Y7QUFBQSxJQUNBRCxTQUFTQSxNQUFNdkMsTUFBTXdDLE1BQU0sNkNBQTZDO0FBQUEsRUFDMUUsQ0FBQztBQUVELFNBQ0UsdUJBQUMsU0FBTSxTQUFrQixPQUFPLHVCQUF1QmpGLE1BQU1xSCxhQUFhckgsTUFBTXVGLFlBQVksSUFDMUYsaUNBQUMsU0FBSSxPQUFPLEVBQUVTLFNBQVMsUUFBUUMsS0FBSyxJQUFJOEQsVUFBVSxJQUFJLEdBQ3BEO0FBQUEsMkJBQUMsYUFBVSxPQUFNLGlDQUFnQyxPQUFPTSxNQUFNLFVBQVUsQ0FBQ0wsTUFBTU0sUUFBUU4sRUFBRUMsT0FBT3RJLEtBQUssR0FBRyxXQUFTLFFBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUg7QUFBQSxJQUNqSCx1QkFBQyxTQUFJLE9BQU8sRUFBRXFFLFNBQVMsUUFBUUMsS0FBSyxJQUFJa0IsZ0JBQWdCLFdBQVcsR0FDakU7QUFBQSw2QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTbUMsU0FBUyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFPLFNBQVEsV0FBVSxVQUFVLENBQUNlLEtBQUtQLEtBQUssR0FBRyxTQUFTaUMsU0FBUzNGLFdBQVcsU0FBUyxNQUFNMkYsU0FBUzVGLE9BQU8sR0FBRyx1QkFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZQTtBQUVKO0FBTUEyRixJQTlDU0YseUJBQXVCO0FBQUEsVUFTaEJuTixVQUdHN0IsV0FBVztBQUFBO0FBQUEsTUFackJnUDtBQStDVCxTQUFTSSwwQkFBMEIsRUFBRWhNLE9BQU9zSixRQUE0RCxHQUFHO0FBQUEyQyxNQUFBO0FBQ3pHLFFBQU14SixRQUFRaEUsU0FBUztBQUN2QixRQUFNLENBQUN5TixTQUFTQyxVQUFVLElBQUl6UCxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDK0wsZUFBZUMsZ0JBQWdCLElBQUloTSxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDMk4sTUFBTUMsT0FBTyxJQUFJNU4sU0FBUyxFQUFFO0FBR25DLFFBQU0sQ0FBQzBQLHVCQUF1QkMsd0JBQXdCLElBQUkzUCxTQUFTLEtBQUs7QUFDeEUsUUFBTSxDQUFDNFAsa0JBQWtCQyxtQkFBbUIsSUFBSTdQLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUM4UCxnQkFBZ0JDLGlCQUFpQixJQUFJL1AsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ2dRLGdCQUFnQkMsaUJBQWlCLElBQUlqUSxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDa1Esa0JBQWtCQyxtQkFBbUIsSUFBSW5RLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUNvUSxVQUFVQyxXQUFXLElBQUlyUSxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDc1EsV0FBV0MsWUFBWSxJQUFJdlEsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3dRLGVBQWVDLGdCQUFnQixJQUFJelEsU0FBUyxFQUFFO0FBRXJELFFBQU0wUSxXQUFXdlEsU0FBUztBQUFBLElBQ3hCdUcsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGVBQWVwRCxNQUFNOEQsRUFBRTtBQUFBLElBQzNEVCxTQUFTQSxNQUFNMUYsd0JBQXdCcUMsTUFBTThELEVBQUU7QUFBQSxJQUMvQ3VKLFNBQVNuQjtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNb0Isd0JBQXdCMVEsWUFBWTtBQUFBLElBQ3hDaUksWUFBWUEsTUFBTTFHLHdCQUF3QjZCLE1BQU04RCxFQUFFO0FBQUEsSUFDbERnQixXQUFXQSxNQUFNckMsTUFBTXNDLFFBQVEsZ0RBQWdEO0FBQUEsSUFDL0VDLFNBQVNBLE1BQU12QyxNQUFNd0MsTUFBTSxtREFBbUQ7QUFBQSxFQUNoRixDQUFDO0FBRUQsUUFBTXNJLHVCQUF1QjNRLFlBQVk7QUFBQSxJQUN2Q2lJLFlBQVlBLE1BQU0xSCw4QkFBOEI2QyxNQUFNOEQsRUFBRTtBQUFBLElBQ3hEZ0IsV0FBV0EsTUFBTXJDLE1BQU1zQyxRQUFRLDhEQUE4RDtBQUFBLElBQzdGQyxTQUFTQSxNQUFNdkMsTUFBTXdDLE1BQU0sbURBQW1EO0FBQUEsRUFDaEYsQ0FBQztBQUVELFFBQU11SSxxQkFBcUI1USxZQUFZO0FBQUEsSUFDckNpSSxZQUFZQSxNQUFNdEcsNkJBQTZCeUIsTUFBTThELElBQUl1RyxLQUFLUCxLQUFLLENBQUM7QUFBQSxJQUNwRWhGLFdBQVdBLENBQUMwRixXQUFXO0FBQ3JCLFVBQUlBLE9BQU9DLGFBQWE7QUFDdEJoSSxjQUFNc0MsUUFBUSw2QkFBNkI7QUFDM0MyRCx5QkFBaUIsS0FBSztBQUN0QjRCLGdCQUFRLEVBQUU7QUFBQSxNQUNaLE9BQU87QUFDTDdILGNBQU13QyxNQUFNLDJEQUEyRDtBQUFBLE1BQ3pFO0FBQUEsSUFDRjtBQUFBLElBQ0FELFNBQVNBLE1BQU12QyxNQUFNd0MsTUFBTSwrQ0FBK0M7QUFBQSxFQUM1RSxDQUFDO0FBRUQsUUFBTXdJLCtCQUErQjdRLFlBQVk7QUFBQSxJQUMvQ2lJLFlBQVlBLE1BQ1Y1RyxrQ0FBa0MrQixNQUFNOEQsSUFBSTtBQUFBLE1BQzFDNEosY0FBY3BCLGlCQUFpQnhDLEtBQUs7QUFBQSxNQUNwQzZELFlBQVluQixlQUFlMUMsS0FBSztBQUFBLE1BQ2hDOEQsWUFBWWxCLGVBQWU1QyxLQUFLLEtBQUsrRDtBQUFBQSxNQUNyQ0MsY0FBY2xCLGlCQUFpQjlDLEtBQUs7QUFBQSxNQUNwQ2lFLE1BQU1qQixTQUFTaEQsS0FBSztBQUFBLE1BQ3BCa0UsT0FBT2hCLFVBQVVsRCxLQUFLO0FBQUEsTUFDdEJtRSxXQUFXZixjQUFjcEQsS0FBSyxLQUFLK0Q7QUFBQUEsSUFDckMsQ0FBQztBQUFBLElBQ0gvSSxXQUFXQSxNQUFNO0FBQ2ZyQyxZQUFNc0MsUUFBUSx3Q0FBd0M7QUFDdERzSCwrQkFBeUIsS0FBSztBQUM5QkUsMEJBQW9CLEVBQUU7QUFDdEJFLHdCQUFrQixFQUFFO0FBQ3BCRSx3QkFBa0IsRUFBRTtBQUNwQkUsMEJBQW9CLEVBQUU7QUFDdEJFLGtCQUFZLEVBQUU7QUFDZEUsbUJBQWEsRUFBRTtBQUNmRSx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCO0FBQUEsSUFDQW5JLFNBQVNBLE1BQU12QyxNQUFNd0MsTUFBTSwwREFBMEQ7QUFBQSxFQUN2RixDQUFDO0FBRUQsUUFBTWlKLDhCQUE4QnRSLFlBQVk7QUFBQSxJQUM5Q2lJLFlBQVlBLE1BQU05SCxpQ0FBaUNpRCxNQUFNOEQsRUFBRTtBQUFBLElBQzNEZ0IsV0FBV0EsTUFBTXJDLE1BQU1zQyxRQUFRLG9DQUFvQztBQUFBLElBQ25FQyxTQUFTQSxNQUFNdkMsTUFBTXdDLE1BQU0sd0RBQXdEO0FBQUEsRUFDckYsQ0FBQztBQUVELFFBQU1rSiw0QkFBNEJ2UixZQUFZO0FBQUEsSUFDNUNpSSxZQUFZQSxNQUFNeEgsK0JBQStCMkMsTUFBTThELEVBQUU7QUFBQSxJQUN6RGdCLFdBQVdBLE1BQU1yQyxNQUFNc0MsUUFBUSxzQ0FBc0M7QUFBQSxJQUNyRUMsU0FBU0EsTUFBTXZDLE1BQU13QyxNQUFNLHdEQUF3RDtBQUFBLEVBQ3JGLENBQUM7QUFFRCxRQUFNbUosNkJBQTZCeFIsWUFBWTtBQUFBLElBQzdDaUksWUFBWUEsTUFBTXpILHdCQUF3QjRDLE1BQU04RCxFQUFFO0FBQUEsSUFDbERnQixXQUFXQSxNQUFNckMsTUFBTXNDLFFBQVEsMENBQTBDO0FBQUEsSUFDekVDLFNBQVNBLE1BQU12QyxNQUFNd0MsTUFBTSw0REFBNEQ7QUFBQSxFQUN6RixDQUFDO0FBRUQsUUFBTW9KLE1BQU1qQixTQUFTMUo7QUFFckIsU0FDRSx1QkFBQyxTQUFNLFNBQWtCLE9BQU8saUJBQWlCMUQsTUFBTXFILGFBQWFySCxNQUFNdUYsWUFBWSxJQUNwRixpQ0FBQyxTQUFJLE9BQU8sRUFBRVMsU0FBUyxRQUFRQyxLQUFLLElBQUk4RCxVQUFVLElBQUksR0FDcEQ7QUFBQSwyQkFBQyxTQUFJLE9BQU8sRUFBRS9ELFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsNkJBQUMsVUFBSyxPQUFPLEVBQUVtQixZQUFZLEtBQUt2QixVQUFVLFNBQVMsR0FBRyx3Q0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RTtBQUFBLE1BQzlFLHVCQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTLE1BQU1zRyxXQUFXLElBQUksR0FBRyxTQUFTRCxXQUFXa0IsU0FBU3JILFdBQVcsZ0NBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0NtRyxXQUFXa0IsU0FBU3RILFdBQVcsdUJBQUMsY0FBVyxPQUFPc0gsU0FBU25JLE9BQU8sTUFBSyx3QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQzNGaUgsV0FBV21DLE9BQ1YsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFN0ksU0FBUyxJQUFJUSxTQUFTLFFBQVFDLEtBQUssR0FBR0osVUFBVSxVQUFVLEdBQ3pGO0FBQUEsK0JBQUMsVUFBSztBQUFBO0FBQUEsVUFBU3dJLElBQUlsTyxVQUFVO0FBQUEsYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2pDLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFVBQVFrTyxJQUFJQyxNQUFNbks7QUFBQUEsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFFBQzlCa0ssSUFBSUUsb0JBQ0gsdUJBQUMsVUFBSztBQUFBO0FBQUEsVUFDVUYsSUFBSUU7QUFBQUEsVUFBaUI7QUFBQSxVQUFFRixJQUFJRyxzQkFBc0I7QUFBQSxhQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLFNBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUV4SSxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLDZCQUFDLFVBQUssT0FBTyxFQUFFbUIsWUFBWSxLQUFLdkIsVUFBVSxTQUFTLEdBQUcsNkRBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUc7QUFBQSxNQUNuRyx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVJLEtBQUssRUFBRSxHQUN0QztBQUFBLCtCQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTcUgsc0JBQXNCbEgsV0FBVyxTQUFTLE1BQU1rSCxzQkFBc0JuSCxPQUFPLEdBQUcseUJBQTNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFNBQVNvSCxxQkFBcUJuSCxXQUFXLFNBQVMsTUFBTW1ILHFCQUFxQnBILE9BQU8sR0FBRyxvQ0FBekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVILFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsNkJBQUMsVUFBSyxPQUFPLEVBQUVtQixZQUFZLEtBQUt2QixVQUFVLFNBQVMsR0FBRywwREFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRztBQUFBLE1BQy9GLENBQUM0QyxnQkFDQSx1QkFBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLE1BQUssU0FBUyxNQUFNQyxpQkFBaUIsSUFBSSxHQUFHLCtCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUV6QyxLQUFLLEVBQUUsR0FDdEM7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRXdJLE1BQU0sRUFBRSxHQUNwQixpQ0FBQyxhQUFVLE9BQU0sVUFBUyxPQUFPcEUsTUFBTSxVQUFVLENBQUNMLE1BQU1NLFFBQVFOLEVBQUVDLE9BQU90SSxLQUFLLEdBQUcsV0FBUyxRQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGLEtBRDVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLE1BQUs7QUFBQSxZQUNMLFVBQVUsQ0FBQzBJLEtBQUtQLEtBQUs7QUFBQSxZQUNyQixTQUFTMEQsbUJBQW1CcEg7QUFBQUEsWUFDNUIsU0FBUyxNQUFNb0gsbUJBQW1CckgsT0FBTztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBTDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUgsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSw2QkFBQyxVQUFLLE9BQU8sRUFBRW1CLFlBQVksS0FBS3ZCLFVBQVUsU0FBUyxHQUFHLDhEQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9HO0FBQUEsTUFDcEcsdUJBQUMsVUFBSyxPQUFPLEVBQUVELE9BQU8sb0JBQW9CQyxVQUFVLFNBQVMsR0FBRyx5SkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQyxDQUFDdUcsd0JBQ0EsdUJBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFNBQVMsTUFBTUMseUJBQXlCLElBQUksR0FBRyx1Q0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVyRyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLCtCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFQSxLQUFLLEVBQUUsR0FDbEQ7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRXdJLE1BQU0sR0FBRzFFLFVBQVUsSUFBSSxHQUNuQyxpQ0FBQyxhQUFVLE9BQU0sVUFBUyxPQUFPdUMsa0JBQWtCLFVBQVUsQ0FBQ3RDLE1BQU11QyxvQkFBb0J2QyxFQUFFQyxPQUFPdEksS0FBSyxLQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RyxLQUQxRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRThNLE1BQU0sR0FBRzFFLFVBQVUsSUFBSSxHQUNuQyxpQ0FBQyxhQUFVLE9BQU0sT0FBTSxPQUFPeUMsZ0JBQWdCLFVBQVUsQ0FBQ3hDLE1BQU15QyxrQkFBa0J6QyxFQUFFQyxPQUFPdEksS0FBSyxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRyxLQURuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFc0UsS0FBSyxFQUFFLEdBQ2xEO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUV3SSxNQUFNLEdBQUcxRSxVQUFVLElBQUksR0FDbkMsaUNBQUMsYUFBVSxPQUFNLGVBQWMsT0FBTzJDLGdCQUFnQixVQUFVLENBQUMxQyxNQUFNMkMsa0JBQWtCM0MsRUFBRUMsT0FBT3RJLEtBQUssS0FBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUcsS0FEM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUU4TSxNQUFNLEdBQUcxRSxVQUFVLElBQUksR0FDbkMsaUNBQUMsYUFBVSxPQUFNLFVBQVMsT0FBTzZDLGtCQUFrQixVQUFVLENBQUM1QyxNQUFNNkMsb0JBQW9CN0MsRUFBRUMsT0FBT3RJLEtBQUssS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0csS0FEMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRXNFLEtBQUssRUFBRSxHQUNsRDtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFd0ksTUFBTSxHQUFHMUUsVUFBVSxJQUFJLEdBQ25DLGlDQUFDLGFBQVUsT0FBTSxVQUFTLE9BQU8rQyxVQUFVLFVBQVUsQ0FBQzlDLE1BQU0rQyxZQUFZL0MsRUFBRUMsT0FBT3RJLEtBQUssS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0YsS0FEMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUU4TSxNQUFNLEdBQUcxRSxVQUFVLElBQUksR0FDbkMsaUNBQUMsYUFBVSxPQUFNLGVBQWMsT0FBT2lELFdBQVcsVUFBVSxDQUFDaEQsTUFBTWlELGFBQWFqRCxFQUFFQyxPQUFPdEksS0FBSyxLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRixLQURqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLGFBQVUsT0FBTSx5QkFBd0IsT0FBT3VMLGVBQWUsVUFBVSxDQUFDbEQsTUFBTW1ELGlCQUFpQm5ELEVBQUVDLE9BQU90SSxLQUFLLEtBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUg7QUFBQSxRQUNqSCx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVzRSxLQUFLLEdBQUdrQixnQkFBZ0IsV0FBVyxHQUNsRTtBQUFBLGlDQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTLE1BQU1rRix5QkFBeUIsS0FBSyxHQUFHLHdCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsVUFBVSxDQUFDQyxpQkFBaUJ4QyxLQUFLLEtBQUssQ0FBQzBDLGVBQWUxQyxLQUFLLEtBQUssQ0FBQzhDLGlCQUFpQjlDLEtBQUssS0FBSyxDQUFDZ0QsU0FBU2hELEtBQUssS0FBSyxDQUFDa0QsVUFBVWxELEtBQUs7QUFBQSxjQUNoSSxTQUFTMkQsNkJBQTZCckg7QUFBQUEsY0FDdEMsU0FBUyxNQUFNcUgsNkJBQTZCdEgsT0FBTztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBTHZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxXQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUYsS0FBSyxFQUFFLEdBQ2xEO0FBQUEsK0JBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFNBQVNpSSw0QkFBNEI5SCxXQUFXLFNBQVMsTUFBTThILDRCQUE0Qi9ILE9BQU8sR0FBRyw2QkFBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLE1BQUssU0FBU2dJLDBCQUEwQi9ILFdBQVcsU0FBUyxNQUFNK0gsMEJBQTBCaEksT0FBTyxHQUFHLDZCQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTaUksMkJBQTJCaEksV0FBVyxTQUFTLE1BQU1nSSwyQkFBMkJqSSxPQUFPLEdBQUcsNkNBQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsU0FqRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVILFNBQVMsUUFBUW1CLGdCQUFnQixXQUFXLEdBQ3hELGlDQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVNtQyxTQUFTLHNCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQWhJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUlBLEtBbElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtSUE7QUFFSjtBQUlBMkMsSUF2T1NELDJCQUF5QjtBQUFBLFVBQ2xCdk4sVUFlRzVCLFVBTWFELGFBTURBLGFBTUZBLGFBY1VBLGFBeUJEQSxhQU1GQSxhQU1DQSxXQUFXO0FBQUE7QUFBQSxNQXJGdkNvUDtBQXdPVCxTQUFTMEMsZ0JBQWdCLEVBQUVoTSxTQUErQixHQUFHO0FBQUFpTSxNQUFBO0FBQzNELFFBQU1sTSxRQUFRaEUsU0FBUztBQUN2QixRQUFNLENBQUNtUSxXQUFXQyxZQUFZLElBQUluUyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDd08sUUFBUTRELFNBQVMsSUFBSXBTLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNxUyxZQUFZQyxhQUFhLElBQUl0UyxTQUF3QixJQUFJO0FBR2hFLFFBQU0sQ0FBQ3VTLGVBQWVDLGdCQUFnQixJQUFJeFMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3lTLGlCQUFpQkMsa0JBQWtCLElBQUkxUyxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDMlMsbUJBQW1CQyxvQkFBb0IsSUFBSTVTLFNBQVMsRUFBRTtBQUU3RCxRQUFNNlMsaUJBQWlCM1MsWUFBWTtBQUFBLElBQ2pDaUksWUFBWUEsTUFBTTdILG1CQUFtQjBGLFVBQVVrTSxVQUFVOUUsS0FBSyxDQUFDO0FBQUEsSUFDL0RoRixXQUFXQSxDQUFDMEYsV0FBVztBQUNyQi9ILFlBQU1zQyxRQUFRLDBCQUEwQjtBQUN4Q2lLLG9CQUFjeEUsT0FBT3JLLFVBQVUsUUFBUTtBQUN2QzBPLG1CQUFhLEVBQUU7QUFBQSxJQUNqQjtBQUFBLElBQ0E3SixTQUFTQSxNQUFNdkMsTUFBTXdDLE1BQU0sb0VBQW9FO0FBQUEsRUFDakcsQ0FBQztBQUVELFFBQU11SyxpQkFBaUI1UyxZQUFZO0FBQUEsSUFDakNpSSxZQUFZQSxNQUFNN0csbUJBQW1CMEUsVUFBVWtNLFVBQVU5RSxLQUFLLEdBQUdvQixPQUFPcEIsS0FBSyxDQUFDO0FBQUEsSUFDOUVoRixXQUFXQSxDQUFDMEYsV0FBVztBQUNyQi9ILFlBQU1zQyxRQUFRLDZCQUE2QjtBQUMzQ2lLLG9CQUFjeEUsT0FBT3JLLFVBQVUsV0FBVztBQUMxQzBPLG1CQUFhLEVBQUU7QUFDZkMsZ0JBQVUsRUFBRTtBQUFBLElBQ2Q7QUFBQSxJQUNBOUosU0FBU0EsTUFBTXZDLE1BQU13QyxNQUFNLCtFQUErRTtBQUFBLEVBQzVHLENBQUM7QUFFRCxRQUFNd0ssc0JBQXNCN1MsWUFBWTtBQUFBLElBQ3RDaUksWUFBWUEsTUFDVjNHO0FBQUFBLE1BQ0V3RTtBQUFBQSxNQUNBa00sVUFBVTlFLEtBQUs7QUFBQSxNQUNmbUYsY0FBY25GLEtBQUs7QUFBQSxNQUNuQnFGLGdCQUFnQnJGLEtBQUs7QUFBQSxNQUNyQnVGLGtCQUFrQnZGLEtBQUssSUFBSTRGLE9BQU9MLGtCQUFrQnZGLEtBQUssRUFBRTZGLFFBQVEsS0FBSyxHQUFHLENBQUMsSUFBSTlCO0FBQUFBLE1BQ2hGd0Isa0JBQWtCdkYsS0FBSyxJQUFJLFFBQVErRDtBQUFBQSxJQUNyQztBQUFBLElBQ0YvSSxXQUFXQSxDQUFDMEYsV0FBVztBQUNyQi9ILFlBQU1zQyxRQUFRLGdDQUFnQztBQUM5Q2lLLG9CQUFjeEUsT0FBT3JLLFVBQVUsc0JBQXNCO0FBQ3JEK08sdUJBQWlCLEVBQUU7QUFDbkJFLHlCQUFtQixFQUFFO0FBQ3JCRSwyQkFBcUIsRUFBRTtBQUFBLElBQ3pCO0FBQUEsSUFDQXRLLFNBQVNBLE1BQU12QyxNQUFNd0MsTUFBTSwyRUFBMkU7QUFBQSxFQUN4RyxDQUFDO0FBRUQsU0FDRSx1QkFBQyxhQUFRLFdBQVUsVUFBUyxPQUFPLEVBQUVPLFNBQVMsSUFBSVEsU0FBUyxRQUFRQyxLQUFLLElBQUkySixXQUFXLEdBQUcsR0FDeEY7QUFBQSwyQkFBQyxTQUFJLE9BQU8sRUFBRTVKLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsNkJBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFSixVQUFVLFVBQVUsR0FBRyxvQ0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUQsT0FBTyxvQkFBb0JDLFVBQVUsVUFBVSxHQUFHLG9MQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVJLEtBQUssSUFBSTRKLFlBQVksTUFBTSxHQUN0RTtBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFcEIsTUFBTSxHQUFHMUUsVUFBVSxJQUFJLEdBQ25DLGlDQUFDLGFBQVUsT0FBTSxpQkFBZ0IsT0FBTzZFLFdBQVcsVUFBVSxDQUFDNUUsTUFBTTZFLGFBQWE3RSxFQUFFQyxPQUFPdEksS0FBSyxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlHLEtBRG5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUU4TSxNQUFNLEdBQUcxRSxVQUFVLElBQUksR0FDbkM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLE9BQU9tQjtBQUFBQSxVQUNQLFVBQVUsQ0FBQ2xCLE1BQU04RSxVQUFVOUUsRUFBRUMsT0FBT3RJLEtBQUs7QUFBQSxVQUN6QyxhQUFZO0FBQUE7QUFBQSxRQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUkwRCxLQUw1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFVBQU8sU0FBUSxTQUFRLFVBQVUsQ0FBQ2lOLFVBQVU5RSxLQUFLLEdBQUcsU0FBU3lGLGVBQWVuSixXQUFXLFNBQVMsTUFBTW1KLGVBQWVwSixPQUFPLEdBQUcsdUJBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVE7QUFBQSxVQUNSLFVBQVUsQ0FBQ3lJLFVBQVU5RSxLQUFLLEtBQUssQ0FBQ29CLE9BQU9wQixLQUFLO0FBQUEsVUFDNUMsU0FBUzBGLGVBQWVwSjtBQUFBQSxVQUN4QixTQUFTLE1BQU1vSixlQUFlckosT0FBTztBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVGLEtBQUssSUFBSTRKLFlBQVksTUFBTSxHQUN0RTtBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFcEIsTUFBTSxHQUFHMUUsVUFBVSxJQUFJLEdBQ25DLGlDQUFDLGFBQVUsT0FBTSxxQkFBb0IsT0FBT2tGLGVBQWUsVUFBVSxDQUFDakYsTUFBTWtGLGlCQUFpQmxGLEVBQUVDLE9BQU90SSxLQUFLLEtBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkcsS0FEL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRThNLE1BQU0sR0FBRzFFLFVBQVUsSUFBSSxHQUNuQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sT0FBT29GO0FBQUFBLFVBQ1AsVUFBVSxDQUFDbkYsTUFBTW9GLG1CQUFtQnBGLEVBQUVDLE9BQU90SSxLQUFLO0FBQUEsVUFDbEQsYUFBWTtBQUFBO0FBQUEsUUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJaUMsS0FMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRThNLE1BQU0sR0FBRzFFLFVBQVUsSUFBSSxHQUNuQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sT0FBT3NGO0FBQUFBLFVBQ1AsVUFBVSxDQUFDckYsTUFBTXNGLHFCQUFxQnRGLEVBQUVDLE9BQU90SSxLQUFLO0FBQUEsVUFDcEQsYUFBWTtBQUFBO0FBQUEsUUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJMEIsS0FMNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsVUFBVSxDQUFDaU4sVUFBVTlFLEtBQUssS0FBSyxDQUFDbUYsY0FBY25GLEtBQUssS0FBSyxDQUFDcUYsZ0JBQWdCckYsS0FBSztBQUFBLFVBQzlFLFNBQVMyRixvQkFBb0JySjtBQUFBQSxVQUM3QixTQUFTLE1BQU1xSixvQkFBb0J0SixPQUFPO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBO0FBQUEsSUFFQzRJLGNBQ0MsdUJBQUMsVUFBSyxPQUFPLEVBQUVuSixPQUFPLG9CQUFvQkMsVUFBVSxVQUFVLEdBQUc7QUFBQTtBQUFBLE1BQTJDa0o7QUFBQUEsU0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SDtBQUFBLE9BbkUzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUVBO0FBRUo7QUFBQ0osSUE1SFFELGlCQUFlO0FBQUEsVUFDUmpRLFVBVVM3QixhQVVBQSxhQVdLQSxXQUFXO0FBQUE7QUFBQSxNQWhDaEM4UjtBQUFlLElBQUFvQixJQUFBMUgsS0FBQTJILEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDO0FBQUEsYUFBQVIsSUFBQTtBQUFBLGFBQUExSCxLQUFBO0FBQUEsYUFBQTJILEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJMaW5rIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiYWNjZXB0SUZvb2REZWxpdmVyeUFkZHJlc3NDaGFuZ2UiLCJhY2NlcHRJRm9vZERpc3B1dGUiLCJhc3NpZ25JRm9vZERyaXZlciIsImNhbmNlbElGb29kT3JkZXIiLCJjYW5jZWxJRm9vZE9yZGVyRHJpdmVyUmVxdWVzdCIsImNvbmZpcm1JRm9vZFVzZXJBZGRyZXNzIiwiZGVueUlGb29kRGVsaXZlcnlBZGRyZXNzQ2hhbmdlIiwiZGlzcGF0Y2hJRm9vZExvZ2lzdGljcyIsImdldElGb29kQ2FuY2VsbGF0aW9uUmVhc29ucyIsImdldElGb29kTG9naXN0aWNzRGVsaXZlcmllcyIsImdldElGb29kT3JkZXJUcmFja2luZyIsImdldElGb29kT3JkZXJzIiwiZ2V0SUZvb2RPcmRlclZpcnR1YWxCYWciLCJtYXJrSUZvb2RBcnJpdmVkQXREZXN0aW5hdGlvbiIsIm1hcmtJRm9vZEFycml2ZWRBdE9yaWdpbiIsIm1hcmtJRm9vZEdvaW5nVG9PcmlnaW4iLCJtYXJrSUZvb2RPcmRlclJlYWR5IiwicmVqZWN0SUZvb2REaXNwdXRlIiwicmVxdWVzdElGb29kRGVsaXZlcnlBZGRyZXNzQ2hhbmdlIiwicmVxdWVzdElGb29kRGlzcHV0ZUFsdGVybmF0aXZlIiwicmVxdWVzdElGb29kT3JkZXJEcml2ZXIiLCJzdGFydElGb29kT3JkZXJQcmVwYXJhdGlvbiIsInZhbGlkYXRlSUZvb2RQaWNrdXBDb2RlIiwidmVyaWZ5SUZvb2REZWxpdmVyeUNvZGUiLCJ2ZXJpZnlJRm9vZE9yZGVyRGVsaXZlcnlDb2RlIiwidXNlQXV0aFN0b3JlIiwidXNlVG9hc3QiLCJCdXR0b24iLCJTdGF0dXNCYWRnZSIsIk1vZGFsIiwiU2VsZWN0RmllbGQiLCJUZXh0RmllbGQiLCJRdWVyeUVycm9yIiwiRW1wdHlTdGF0ZSIsIlJFRlJFU0hfSU5URVJWQUxfTVMiLCJTVEFUVVNfTEFCRUwiLCJQTEFDRUQiLCJDT05GSVJNRUQiLCJQUkVQQVJBVElPTl9TVEFSVEVEIiwiUkVBRFlfVE9fUElDS1VQIiwiRElTUEFUQ0hFRCIsIkNPTkNMVURFRCIsIkNBTkNFTExFRCIsIlNUQVRVU19DT0xPUiIsIlRZUEVfTEFCRUwiLCJERUxJVkVSWSIsIlRBS0VPVVQiLCJESU5FX0lOIiwiaXNPd25GbGVldEVsaWdpYmxlIiwib3JkZXIiLCJpZm9vZE9yZGVyVHlwZSIsImRlbGl2ZXJlZEJ5Iiwic3RhdHVzIiwiaXNJRm9vZFRyYWNraW5nRWxpZ2libGUiLCJpc1BpY2t1cENvZGVFbGlnaWJsZSIsIkxPR0lTVElDU19TVEFUVVNfTEFCRUwiLCJEUklWRVJfQVNTSUdORUQiLCJHT0lOR19UT19PUklHSU4iLCJBUlJJVkVEX0FUX09SSUdJTiIsIkFSUklWRURfQVRfREVTVElOQVRJT04iLCJERUxJVkVSWV9DT0RFX1ZFUklGSUVEIiwiTE9HSVNUSUNTX1NUQVRVU19DT0xPUiIsInBsYXlOZXdPcmRlckNoaW1lIiwiQXVkaW9DdHhDdG9yIiwid2luZG93IiwiQXVkaW9Db250ZXh0Iiwid2Via2l0QXVkaW9Db250ZXh0IiwiY3R4IiwicGxheUJlZXAiLCJzdGFydFRpbWUiLCJmcmVxdWVuY3kiLCJvc2NpbGxhdG9yIiwiY3JlYXRlT3NjaWxsYXRvciIsImdhaW4iLCJjcmVhdGVHYWluIiwidHlwZSIsInZhbHVlIiwic2V0VmFsdWVBdFRpbWUiLCJleHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lIiwiY29ubmVjdCIsImRlc3RpbmF0aW9uIiwic3RhcnQiLCJzdG9wIiwibm93IiwiY3VycmVudFRpbWUiLCJzZXRUaW1lb3V0IiwiY2xvc2UiLCJJRm9vZE9yZGVyc1BhZ2UiLCJfcyIsInF1ZXJ5Q2xpZW50IiwidG9hc3QiLCJicmFuY2hJZCIsImNhbmNlbGxpbmdPcmRlciIsInNldENhbmNlbGxpbmdPcmRlciIsInRyYWNraW5nT3JkZXIiLCJzZXRUcmFja2luZ09yZGVyIiwicGlja3VwQ29kZU9yZGVyIiwic2V0UGlja3VwQ29kZU9yZGVyIiwiYWR2YW5jZWRPcmRlciIsInNldEFkdmFuY2VkT3JkZXIiLCJvcmRlcnNRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInJlZmV0Y2hJbnRlcnZhbCIsImtub3duT3JkZXJJZHNSZWYiLCJjdXJyZW50Iiwib3JkZXJzIiwiZGF0YSIsImN1cnJlbnRJZHMiLCJTZXQiLCJtYXAiLCJpZCIsInByZXZpb3VzbHlLbm93biIsIm5ld09yZGVycyIsImZpbHRlciIsImhhcyIsImxlbmd0aCIsInR5cGVMYWJlbCIsImluZm8iLCJjdXN0b21lck5hbWUiLCJ0b3RhbEFtb3VudCIsInRvRml4ZWQiLCJkZWxpdmVyaWVzUXVlcnkiLCJpbnZhbGlkYXRlT3JkZXJzIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJzdGFydFByZXBhcmF0aW9uTXV0YXRpb24iLCJtdXRhdGlvbkZuIiwib25TdWNjZXNzIiwic3VjY2VzcyIsIm9uRXJyb3IiLCJlcnJvciIsIm1hcmtSZWFkeU11dGF0aW9uIiwiZGVsaXZlcmllcyIsImRlbGl2ZXJpZXNCeUlGb29kT3JkZXJJZCIsIk1hcCIsImQiLCJpZm9vZE9yZGVySWQiLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJtYXJnaW5Cb3R0b20iLCJjb2xvciIsImZvbnRTaXplIiwiaXNFcnJvciIsImlzTG9hZGluZyIsImRpc3BsYXkiLCJnYXAiLCJnZXQiLCJtdXRhdGUiLCJpc1BlbmRpbmciLCJ2YXJpYWJsZXMiLCJJRm9vZE9yZGVyQ2FyZCIsImRlbGl2ZXJ5Iiwib25TdGFydFByZXBhcmF0aW9uIiwib25NYXJrUmVhZHkiLCJvbkNhbmNlbCIsIm9uVHJhY2siLCJvblZhbGlkYXRlUGlja3VwQ29kZSIsIm9uQWR2YW5jZWQiLCJzdGFydFBlbmRpbmciLCJyZWFkeVBlbmRpbmciLCJjYW5TdGFydFByZXBhcmF0aW9uIiwiY2FuTWFya1JlYWR5IiwiY2FuQ2FuY2VsIiwianVzdGlmeUNvbnRlbnQiLCJmb250V2VpZ2h0IiwiZGlzcGxheUlkIiwiY3VzdG9tZXJQaG9uZSIsImRlbGl2ZXJ5QWRkcmVzcyIsIm9yZGVyVGltaW5nIiwicHJlcGFyYXRpb25TdGFydERhdGVUaW1lIiwiRGF0ZSIsInRvTG9jYWxlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJob3VyIiwibWludXRlIiwianVzdGlmeUl0ZW1zIiwic3R5bGUiLCJjdXJyZW5jeSIsImhhc1VubWFwcGVkSXRlbXMiLCJfYzIiLCJMb2dpc3RpY3NQYW5lbCIsIl9zMiIsImFzc2lnbmluZyIsInNldEFzc2lnbmluZyIsInZlcmlmeWluZ0NvZGUiLCJzZXRWZXJpZnlpbmdDb2RlIiwiaW52YWxpZGF0ZURlbGl2ZXJpZXMiLCJnb2luZ1RvT3JpZ2luTXV0YXRpb24iLCJhcnJpdmVkQXRPcmlnaW5NdXRhdGlvbiIsImRpc3BhdGNoTXV0YXRpb24iLCJhcnJpdmVkQXREZXN0aW5hdGlvbk11dGF0aW9uIiwiYm9yZGVyUmFkaXVzIiwiYm9yZGVyIiwiZHJpdmVyTmFtZSIsImRyaXZlclBob25lIiwiZHJpdmVyVmVoaWNsZVR5cGUiLCJBc3NpZ25Ecml2ZXJNb2RhbCIsIm9uQ2xvc2UiLCJvbkFzc2lnbmVkIiwiX3MzIiwic2V0RHJpdmVyTmFtZSIsInNldERyaXZlclBob25lIiwic2V0RHJpdmVyVmVoaWNsZVR5cGUiLCJhc3NpZ25NdXRhdGlvbiIsImNhblN1Ym1pdCIsInRyaW0iLCJtaW5XaWR0aCIsImUiLCJ0YXJnZXQiLCJWZXJpZnlEZWxpdmVyeUNvZGVNb2RhbCIsIm9uVmVyaWZpZWQiLCJfczQiLCJjb2RlIiwic2V0Q29kZSIsInZlcmlmeU11dGF0aW9uIiwicmVzdWx0IiwiY29kZU1hdGNoZWQiLCJDYW5jZWxPcmRlck1vZGFsIiwib25DYW5jZWxsZWQiLCJfczUiLCJyZWFzb25Db2RlIiwic2V0UmVhc29uQ29kZSIsInJlYXNvbnNRdWVyeSIsImNhbmNlbE11dGF0aW9uIiwicmVhc29ucyIsInJlYXNvbiIsImRlc2NyaXB0aW9uIiwiVHJhY2tPcmRlck1vZGFsIiwiX3M2IiwidHJhY2tpbmdRdWVyeSIsInRyYWNraW5nIiwibGF0aXR1ZGUiLCJsb25naXR1ZGUiLCJleHBlY3RlZERlbGl2ZXJ5IiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwiVmFsaWRhdGVQaWNrdXBDb2RlTW9kYWwiLCJvblZhbGlkYXRlZCIsIl9zNyIsIm11dGF0aW9uIiwiT3JkZXJBZHZhbmNlZEFjdGlvbnNNb2RhbCIsIl9zOCIsInNob3dCYWciLCJzZXRTaG93QmFnIiwic2hvd0FkZHJlc3NDaGFuZ2VGb3JtIiwic2V0U2hvd0FkZHJlc3NDaGFuZ2VGb3JtIiwiYWRkclN0cmVldE51bWJlciIsInNldEFkZHJTdHJlZXROdW1iZXIiLCJhZGRyU3RyZWV0TmFtZSIsInNldEFkZHJTdHJlZXROYW1lIiwiYWRkckNvbXBsZW1lbnQiLCJzZXRBZGRyQ29tcGxlbWVudCIsImFkZHJOZWlnaGJvcmhvb2QiLCJzZXRBZGRyTmVpZ2hib3Job29kIiwiYWRkckNpdHkiLCJzZXRBZGRyQ2l0eSIsImFkZHJTdGF0ZSIsInNldEFkZHJTdGF0ZSIsImFkZHJSZWZlcmVuY2UiLCJzZXRBZGRyUmVmZXJlbmNlIiwiYmFnUXVlcnkiLCJlbmFibGVkIiwicmVxdWVzdERyaXZlck11dGF0aW9uIiwiY2FuY2VsRHJpdmVyTXV0YXRpb24iLCJ2ZXJpZnlDb2RlTXV0YXRpb24iLCJyZXF1ZXN0QWRkcmVzc0NoYW5nZU11dGF0aW9uIiwic3RyZWV0TnVtYmVyIiwic3RyZWV0TmFtZSIsImNvbXBsZW1lbnQiLCJ1bmRlZmluZWQiLCJuZWlnaGJvcmhvb2QiLCJjaXR5Iiwic3RhdGUiLCJyZWZlcmVuY2UiLCJhY2NlcHRBZGRyZXNzQ2hhbmdlTXV0YXRpb24iLCJkZW55QWRkcmVzc0NoYW5nZU11dGF0aW9uIiwiY29uZmlybVVzZXJBZGRyZXNzTXV0YXRpb24iLCJiYWciLCJpdGVtcyIsImdyb3NzVmFsdWVBbW91bnQiLCJncm9zc1ZhbHVlQ3VycmVuY3kiLCJmbGV4IiwiRGlzcHV0ZXNTZWN0aW9uIiwiX3M5IiwiZGlzcHV0ZUlkIiwic2V0RGlzcHV0ZUlkIiwic2V0UmVhc29uIiwibGFzdFJlc3VsdCIsInNldExhc3RSZXN1bHQiLCJhbHRlcm5hdGl2ZUlkIiwic2V0QWx0ZXJuYXRpdmVJZCIsImFsdGVybmF0aXZlVHlwZSIsInNldEFsdGVybmF0aXZlVHlwZSIsImFsdGVybmF0aXZlQW1vdW50Iiwic2V0QWx0ZXJuYXRpdmVBbW91bnQiLCJhY2NlcHRNdXRhdGlvbiIsInJlamVjdE11dGF0aW9uIiwiYWx0ZXJuYXRpdmVNdXRhdGlvbiIsIk51bWJlciIsInJlcGxhY2UiLCJtYXJnaW5Ub3AiLCJhbGlnbkl0ZW1zIiwiX2MiLCJfYzMiLCJfYzQiLCJfYzUiLCJfYzYiLCJfYzciLCJfYzgiLCJfYzkiLCJfYzAiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSUZvb2RPcmRlcnNQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7XHJcbiAgYWNjZXB0SUZvb2REZWxpdmVyeUFkZHJlc3NDaGFuZ2UsXHJcbiAgYWNjZXB0SUZvb2REaXNwdXRlLFxyXG4gIGFzc2lnbklGb29kRHJpdmVyLFxyXG4gIGNhbmNlbElGb29kT3JkZXIsXHJcbiAgY2FuY2VsSUZvb2RPcmRlckRyaXZlclJlcXVlc3QsXHJcbiAgY29uZmlybUlGb29kVXNlckFkZHJlc3MsXHJcbiAgZGVueUlGb29kRGVsaXZlcnlBZGRyZXNzQ2hhbmdlLFxyXG4gIGRpc3BhdGNoSUZvb2RMb2dpc3RpY3MsXHJcbiAgZ2V0SUZvb2RDYW5jZWxsYXRpb25SZWFzb25zLFxyXG4gIGdldElGb29kTG9naXN0aWNzRGVsaXZlcmllcyxcclxuICBnZXRJRm9vZE9yZGVyVHJhY2tpbmcsXHJcbiAgZ2V0SUZvb2RPcmRlcnMsXHJcbiAgZ2V0SUZvb2RPcmRlclZpcnR1YWxCYWcsXHJcbiAgbWFya0lGb29kQXJyaXZlZEF0RGVzdGluYXRpb24sXHJcbiAgbWFya0lGb29kQXJyaXZlZEF0T3JpZ2luLFxyXG4gIG1hcmtJRm9vZEdvaW5nVG9PcmlnaW4sXHJcbiAgbWFya0lGb29kT3JkZXJSZWFkeSxcclxuICByZWplY3RJRm9vZERpc3B1dGUsXHJcbiAgcmVxdWVzdElGb29kRGVsaXZlcnlBZGRyZXNzQ2hhbmdlLFxyXG4gIHJlcXVlc3RJRm9vZERpc3B1dGVBbHRlcm5hdGl2ZSxcclxuICByZXF1ZXN0SUZvb2RPcmRlckRyaXZlcixcclxuICBzdGFydElGb29kT3JkZXJQcmVwYXJhdGlvbixcclxuICB2YWxpZGF0ZUlGb29kUGlja3VwQ29kZSxcclxuICB2ZXJpZnlJRm9vZERlbGl2ZXJ5Q29kZSxcclxuICB2ZXJpZnlJRm9vZE9yZGVyRGVsaXZlcnlDb2RlLFxyXG4gIHR5cGUgSUZvb2RMb2dpc3RpY3NEZWxpdmVyeVJlc3BvbnNlLFxyXG4gIHR5cGUgSUZvb2RPcmRlclJlc3BvbnNlLFxyXG59IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi8uLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSBcIi4uLy4uL3VpL1N0YXR1c0JhZGdlXCI7XHJcbmltcG9ydCB7IE1vZGFsIH0gZnJvbSBcIi4uLy4uL3VpL01vZGFsXCI7XHJcbmltcG9ydCB7IFNlbGVjdEZpZWxkLCBUZXh0RmllbGQgfSBmcm9tIFwiLi4vLi4vdWkvRmllbGRcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCIuLi8uLi91aS9FbXB0eVN0YXRlXCI7XHJcblxyXG4vLyBTaW5jcm9uaXphw6fDo28gcm9kYSBzb3ppbmhhIG5vIGJhY2tlbmQgKHBvbGxpbmcgYSBjYWRhIDMwcykg4oCUIGVzdGEgdGVsYSBzw7MgcmVmYXogZmV0Y2ggY29tXHJcbi8vIGZyZXF1w6puY2lhIHByYSBhY29tcGFuaGFyIHNlbSBwcmVjaXNhciByZWNhcnJlZ2FyIGEgcMOhZ2luYSBtYW51YWxtZW50ZS5cclxuY29uc3QgUkVGUkVTSF9JTlRFUlZBTF9NUyA9IDE1XzAwMDtcclxuXHJcbmNvbnN0IFNUQVRVU19MQUJFTDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcclxuICBQTEFDRUQ6IFwiUmVjZWJpZG9cIixcclxuICBDT05GSVJNRUQ6IFwiQ29uZmlybWFkb1wiLFxyXG4gIFBSRVBBUkFUSU9OX1NUQVJURUQ6IFwiRW0gcHJlcGFyb1wiLFxyXG4gIFJFQURZX1RPX1BJQ0tVUDogXCJQcm9udG9cIixcclxuICBESVNQQVRDSEVEOiBcIkRlc3BhY2hhZG9cIixcclxuICBDT05DTFVERUQ6IFwiQ29uY2x1w61kb1wiLFxyXG4gIENBTkNFTExFRDogXCJDYW5jZWxhZG9cIixcclxufTtcclxuXHJcbmNvbnN0IFNUQVRVU19DT0xPUjogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcclxuICBQTEFDRUQ6IFwidmFyKC0taW5rLWZhaW50KVwiLFxyXG4gIENPTkZJUk1FRDogXCJ2YXIoLS1pbmZvLCAjM2I4MmY2KVwiLFxyXG4gIFBSRVBBUkFUSU9OX1NUQVJURUQ6IFwidmFyKC0td2FybiwgI2Q5NzcwNilcIixcclxuICBSRUFEWV9UT19QSUNLVVA6IFwidmFyKC0tb2spXCIsXHJcbiAgRElTUEFUQ0hFRDogXCJ2YXIoLS1vaylcIixcclxuICBDT05DTFVERUQ6IFwidmFyKC0taW5rLWZhaW50KVwiLFxyXG4gIENBTkNFTExFRDogXCJ2YXIoLS1kYW5nZXIpXCIsXHJcbn07XHJcblxyXG5jb25zdCBUWVBFX0xBQkVMOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gIERFTElWRVJZOiBcIkRlbGl2ZXJ5XCIsXHJcbiAgVEFLRU9VVDogXCJSZXRpcmFkYVwiLFxyXG4gIERJTkVfSU46IFwiQ29uc3VtbyBubyBsb2NhbFwiLFxyXG59O1xyXG5cclxuLy8gTG9nw61zdGljYSBwb3IgZnJvdGEgcHLDs3ByaWEgKGZhc2UgNykg4oCUIHPDsyBvZmVyZWNpZGEgcXVhbmRvIG8gcGVkaWRvIMOpIERFTElWRVJZIGUgYSBlbnRyZWdhIG7Do29cclxuLy8gw6kgZmVpdGEgcGVsYSBsb2fDrXN0aWNhIGRvIHByw7NwcmlvIGlGb29kIChkZWxpdmVyZWRCeSBkaWZlcmVudGUgZGUgXCJJRk9PRFwiIGUgZGlmZXJlbnRlIGRlIG51bG8pLlxyXG5jb25zdCBpc093bkZsZWV0RWxpZ2libGUgPSAob3JkZXI6IElGb29kT3JkZXJSZXNwb25zZSkgPT5cclxuICBvcmRlci5pZm9vZE9yZGVyVHlwZSA9PT0gXCJERUxJVkVSWVwiICYmXHJcbiAgISFvcmRlci5kZWxpdmVyZWRCeSAmJlxyXG4gIG9yZGVyLmRlbGl2ZXJlZEJ5ICE9PSBcIklGT09EXCIgJiZcclxuICBvcmRlci5zdGF0dXMgIT09IFwiQ0FOQ0VMTEVEXCI7XHJcblxyXG4vLyBGYXNlIDliIOKAlCByYXN0cmVhbWVudG8gc8OzIGZheiBzZW50aWRvIHByYSBlbnRyZWdhcyBmZWl0YXMgcGVsYSBsb2fDrXN0aWNhIGRvIFBSw5NQUklPIGlGb29kXHJcbi8vIChkZWxpdmVyZWRCeSA9PT0gXCJJRk9PRFwiKTsgZnJvdGEgcHLDs3ByaWEgasOhIHRlbSBzZXUgcHLDs3ByaW8gcGFpbmVsIGRlIHN0YXR1cyAoTG9naXN0aWNzUGFuZWxcclxuLy8gYWNpbWEpIGUgbsOjbyB1c2EgbyBlbmRwb2ludCBkZSB0cmFja2luZyBkbyBtw7NkdWxvIE9yZGVyLlxyXG5jb25zdCBpc0lGb29kVHJhY2tpbmdFbGlnaWJsZSA9IChvcmRlcjogSUZvb2RPcmRlclJlc3BvbnNlKSA9PlxyXG4gIG9yZGVyLmlmb29kT3JkZXJUeXBlID09PSBcIkRFTElWRVJZXCIgJiZcclxuICBvcmRlci5kZWxpdmVyZWRCeSA9PT0gXCJJRk9PRFwiICYmXHJcbiAgKG9yZGVyLnN0YXR1cyA9PT0gXCJESVNQQVRDSEVEXCIgfHwgb3JkZXIuc3RhdHVzID09PSBcIlJFQURZX1RPX1BJQ0tVUFwiKTtcclxuXHJcbi8vIEPDs2RpZ28gZGUgcmV0aXJhZGEg4oCUIHBlZGlkb3MgZGUgcmV0aXJhZGEgbm8gYmFsY8OjbyAoVEFLRU9VVCksIHF1YW5kbyBqw6EgZXN0w6NvIHByb250b3MuXHJcbmNvbnN0IGlzUGlja3VwQ29kZUVsaWdpYmxlID0gKG9yZGVyOiBJRm9vZE9yZGVyUmVzcG9uc2UpID0+XHJcbiAgb3JkZXIuaWZvb2RPcmRlclR5cGUgPT09IFwiVEFLRU9VVFwiICYmIG9yZGVyLnN0YXR1cyA9PT0gXCJSRUFEWV9UT19QSUNLVVBcIjtcclxuXHJcbmNvbnN0IExPR0lTVElDU19TVEFUVVNfTEFCRUw6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XHJcbiAgRFJJVkVSX0FTU0lHTkVEOiBcIkVudHJlZ2Fkb3IgYXRyaWJ1w61kb1wiLFxyXG4gIEdPSU5HX1RPX09SSUdJTjogXCJBIGNhbWluaG8gZGEgbG9qYVwiLFxyXG4gIEFSUklWRURfQVRfT1JJR0lOOiBcIk5hIGxvamFcIixcclxuICBESVNQQVRDSEVEOiBcIkEgY2FtaW5obyBkbyBjbGllbnRlXCIsXHJcbiAgQVJSSVZFRF9BVF9ERVNUSU5BVElPTjogXCJObyBlbmRlcmXDp28gZG8gY2xpZW50ZVwiLFxyXG4gIERFTElWRVJZX0NPREVfVkVSSUZJRUQ6IFwiRW50cmVnYSBjb25jbHXDrWRhXCIsXHJcbn07XHJcblxyXG5jb25zdCBMT0dJU1RJQ1NfU1RBVFVTX0NPTE9SOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gIERSSVZFUl9BU1NJR05FRDogXCJ2YXIoLS1pbmstZmFpbnQpXCIsXHJcbiAgR09JTkdfVE9fT1JJR0lOOiBcInZhcigtLWluZm8sICMzYjgyZjYpXCIsXHJcbiAgQVJSSVZFRF9BVF9PUklHSU46IFwidmFyKC0taW5mbywgIzNiODJmNilcIixcclxuICBESVNQQVRDSEVEOiBcInZhcigtLXdhcm4sICNkOTc3MDYpXCIsXHJcbiAgQVJSSVZFRF9BVF9ERVNUSU5BVElPTjogXCJ2YXIoLS13YXJuLCAjZDk3NzA2KVwiLFxyXG4gIERFTElWRVJZX0NPREVfVkVSSUZJRUQ6IFwidmFyKC0tb2spXCIsXHJcbn07XHJcblxyXG4vLyBGYXNlIDEyIOKAlCBhdmlzbyBzb25vcm8vdmlzdWFsIGRlIHBlZGlkbyBub3ZvLiBBIHNpbmNyb25pemHDp8OjbyBlbSBzaSBqw6Egcm9kYSBubyBiYWNrZW5kXHJcbi8vIChJRm9vZE9yZGVyUG9sbGluZ0JhY2tncm91bmRTZXJ2aWNlLCBhIGNhZGEgMzBzKSBlIGVzdGEgdGVsYSBqw6EgcmVjb25zdWx0YSBhIGxpc3RhIGEgY2FkYSAxNXNcclxuLy8gKFJFRlJFU0hfSU5URVJWQUxfTVMpOyBmYWx0YXZhIHPDsyBhdmlzYXIgbyBvcGVyYWRvciBxdWFuZG8gdW0gcGVkaWRvIG5vdm8gYXBhcmVjZSBuYSBsaXN0YSwgZW1cclxuLy8gdmV6IGRlIGRlcGVuZGVyIGRlIGFsZ3XDqW0gZmljYXIgb2xoYW5kbyBhIHRlbGEuIFRvY2EgZG9pcyBiZWVwcyBjdXJ0b3MgdmlhIFdlYiBBdWRpbyBBUEkg4oCUIHNlbVxyXG4vLyBkZXBlbmRlciBkZSBuZW5odW0gYXJxdWl2byBkZSDDoXVkaW8gZXh0ZXJuby4gRmFsaGEgc2lsZW5jaW9zYW1lbnRlIHNlIG8gbmF2ZWdhZG9yIGJsb3F1ZWFyXHJcbi8vIMOhdWRpbyAoZXguOiBhbnRlcyBkZSBxdWFscXVlciBpbnRlcmHDp8OjbyBkbyB1c3XDoXJpbyBuYSBww6FnaW5hKSDigJQgbyB0b2FzdCB2aXN1YWwgYWluZGEgYXZpc2EuXHJcbmZ1bmN0aW9uIHBsYXlOZXdPcmRlckNoaW1lKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBBdWRpb0N0eEN0b3IgPSB3aW5kb3cuQXVkaW9Db250ZXh0ID8/ICh3aW5kb3cgYXMgdW5rbm93biBhcyB7IHdlYmtpdEF1ZGlvQ29udGV4dD86IHR5cGVvZiBBdWRpb0NvbnRleHQgfSkud2Via2l0QXVkaW9Db250ZXh0O1xyXG4gICAgaWYgKCFBdWRpb0N0eEN0b3IpIHJldHVybjtcclxuICAgIGNvbnN0IGN0eCA9IG5ldyBBdWRpb0N0eEN0b3IoKTtcclxuICAgIGNvbnN0IHBsYXlCZWVwID0gKHN0YXJ0VGltZTogbnVtYmVyLCBmcmVxdWVuY3k6IG51bWJlcikgPT4ge1xyXG4gICAgICBjb25zdCBvc2NpbGxhdG9yID0gY3R4LmNyZWF0ZU9zY2lsbGF0b3IoKTtcclxuICAgICAgY29uc3QgZ2FpbiA9IGN0eC5jcmVhdGVHYWluKCk7XHJcbiAgICAgIG9zY2lsbGF0b3IudHlwZSA9IFwic2luZVwiO1xyXG4gICAgICBvc2NpbGxhdG9yLmZyZXF1ZW5jeS52YWx1ZSA9IGZyZXF1ZW5jeTtcclxuICAgICAgZ2Fpbi5nYWluLnNldFZhbHVlQXRUaW1lKDAuMDAwMSwgc3RhcnRUaW1lKTtcclxuICAgICAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4zLCBzdGFydFRpbWUgKyAwLjAyKTtcclxuICAgICAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4wMDAxLCBzdGFydFRpbWUgKyAwLjI1KTtcclxuICAgICAgb3NjaWxsYXRvci5jb25uZWN0KGdhaW4pO1xyXG4gICAgICBnYWluLmNvbm5lY3QoY3R4LmRlc3RpbmF0aW9uKTtcclxuICAgICAgb3NjaWxsYXRvci5zdGFydChzdGFydFRpbWUpO1xyXG4gICAgICBvc2NpbGxhdG9yLnN0b3Aoc3RhcnRUaW1lICsgMC4zKTtcclxuICAgIH07XHJcbiAgICBjb25zdCBub3cgPSBjdHguY3VycmVudFRpbWU7XHJcbiAgICBwbGF5QmVlcChub3csIDg4MCk7XHJcbiAgICBwbGF5QmVlcChub3cgKyAwLjMsIDEwNDYuNSk7XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHZvaWQgY3R4LmNsb3NlKCksIDgwMCk7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyBBbWJpZW50ZSBzZW0gc3Vwb3J0ZSBhIFdlYiBBdWRpbywgb3Ugw6F1ZGlvIGJsb3F1ZWFkbyDigJQgc2VndWUgc8OzIGNvbSBvIHRvYXN0IHZpc3VhbC5cclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJRm9vZE9yZGVyc1BhZ2UoKSB7XHJcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbY2FuY2VsbGluZ09yZGVyLCBzZXRDYW5jZWxsaW5nT3JkZXJdID0gdXNlU3RhdGU8SUZvb2RPcmRlclJlc3BvbnNlIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW3RyYWNraW5nT3JkZXIsIHNldFRyYWNraW5nT3JkZXJdID0gdXNlU3RhdGU8SUZvb2RPcmRlclJlc3BvbnNlIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW3BpY2t1cENvZGVPcmRlciwgc2V0UGlja3VwQ29kZU9yZGVyXSA9IHVzZVN0YXRlPElGb29kT3JkZXJSZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFthZHZhbmNlZE9yZGVyLCBzZXRBZHZhbmNlZE9yZGVyXSA9IHVzZVN0YXRlPElGb29kT3JkZXJSZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBvcmRlcnNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcIm9yZGVyc1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZE9yZGVycyhicmFuY2hJZCksXHJcbiAgICByZWZldGNoSW50ZXJ2YWw6IFJFRlJFU0hfSU5URVJWQUxfTVMsXHJcbiAgfSk7XHJcblxyXG4gIC8vIFNuYXBzaG90IGRvcyBJRHMgZGUgcGVkaWRvIGrDoSB2aXN0b3Mg4oCUIG51bGwgZW5xdWFudG8gYSB0ZWxhIGFpbmRhIG7Do28gdGVybWlub3UgbyBwcmltZWlyb1xyXG4gIC8vIGNhcnJlZ2FtZW50byAobmVzc2UgY2FzbyBuw6NvIGFsZXJ0YSBuYWRhLCBzZW7Do28gdG9kbyBwZWRpZG8gZW0gYWJlcnRvIHZpcmFyaWEgdW0gXCJwZWRpZG9cclxuICAvLyBub3ZvXCIgYXNzaW0gcXVlIGEgdGVsYSBhYnJlKS5cclxuICBjb25zdCBrbm93bk9yZGVySWRzUmVmID0gdXNlUmVmPFNldDxudW1iZXI+IHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIC8vIFRyb2NhIGRlIGZpbGlhbDogZGVzY2FydGEgbyBzbmFwc2hvdCBhbnRpZ28gcHJhIG7Do28gY29tcGFyYXIgcGVkaWRvcyBkZSBsb2phcyBkaWZlcmVudGVzLlxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBrbm93bk9yZGVySWRzUmVmLmN1cnJlbnQgPSBudWxsO1xyXG4gIH0sIFticmFuY2hJZF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3Qgb3JkZXJzID0gb3JkZXJzUXVlcnkuZGF0YTtcclxuICAgIGlmICghb3JkZXJzKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgY3VycmVudElkcyA9IG5ldyBTZXQob3JkZXJzLm1hcCgob3JkZXIpID0+IG9yZGVyLmlkKSk7XHJcblxyXG4gICAgaWYgKGtub3duT3JkZXJJZHNSZWYuY3VycmVudCA9PT0gbnVsbCkge1xyXG4gICAgICBrbm93bk9yZGVySWRzUmVmLmN1cnJlbnQgPSBjdXJyZW50SWRzO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcHJldmlvdXNseUtub3duID0ga25vd25PcmRlcklkc1JlZi5jdXJyZW50O1xyXG4gICAgY29uc3QgbmV3T3JkZXJzID0gb3JkZXJzLmZpbHRlcigob3JkZXIpID0+ICFwcmV2aW91c2x5S25vd24uaGFzKG9yZGVyLmlkKSk7XHJcbiAgICBrbm93bk9yZGVySWRzUmVmLmN1cnJlbnQgPSBjdXJyZW50SWRzO1xyXG5cclxuICAgIGlmIChuZXdPcmRlcnMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gICAgcGxheU5ld09yZGVyQ2hpbWUoKTtcclxuICAgIGZvciAoY29uc3Qgb3JkZXIgb2YgbmV3T3JkZXJzKSB7XHJcbiAgICAgIGNvbnN0IHR5cGVMYWJlbCA9IFRZUEVfTEFCRUxbb3JkZXIuaWZvb2RPcmRlclR5cGVdID8/IG9yZGVyLmlmb29kT3JkZXJUeXBlO1xyXG4gICAgICB0b2FzdC5pbmZvKFxyXG4gICAgICAgIGDwn5SUIE5vdm8gcGVkaWRvIGlGb29kIOKAlCAke29yZGVyLmN1c3RvbWVyTmFtZX0gwrcgJHt0eXBlTGFiZWx9IMK3IFIkICR7b3JkZXIudG90YWxBbW91bnQudG9GaXhlZCgyKX1gLFxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH0sIFtvcmRlcnNRdWVyeS5kYXRhLCB0b2FzdF0pO1xyXG5cclxuICBjb25zdCBkZWxpdmVyaWVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJsb2dpc3RpY3NcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RMb2dpc3RpY3NEZWxpdmVyaWVzKGJyYW5jaElkKSxcclxuICAgIHJlZmV0Y2hJbnRlcnZhbDogUkVGUkVTSF9JTlRFUlZBTF9NUyxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgaW52YWxpZGF0ZU9yZGVycyA9ICgpID0+XHJcbiAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwib3JkZXJzXCJdIH0pO1xyXG5cclxuICBjb25zdCBzdGFydFByZXBhcmF0aW9uTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoaWQ6IG51bWJlcikgPT4gc3RhcnRJRm9vZE9yZGVyUHJlcGFyYXRpb24oaWQpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJQcmVwYXJvIGluaWNpYWRvIG5vIGlGb29kLlwiKTtcclxuICAgICAgaW52YWxpZGF0ZU9yZGVycygpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIGluaWNpYXIgbyBwcmVwYXJvIG5vIGlGb29kLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgbWFya1JlYWR5TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoaWQ6IG51bWJlcikgPT4gbWFya0lGb29kT3JkZXJSZWFkeShpZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIlBlZGlkbyBtYXJjYWRvIGNvbW8gcHJvbnRvIG5vIGlGb29kLlwiKTtcclxuICAgICAgaW52YWxpZGF0ZU9yZGVycygpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIG1hcmNhciBjb21vIHByb250byBubyBpRm9vZC5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IG9yZGVycyA9IG9yZGVyc1F1ZXJ5LmRhdGEgPz8gW107XHJcbiAgY29uc3QgZGVsaXZlcmllcyA9IGRlbGl2ZXJpZXNRdWVyeS5kYXRhID8/IFtdO1xyXG4gIGNvbnN0IGRlbGl2ZXJpZXNCeUlGb29kT3JkZXJJZCA9IG5ldyBNYXAoZGVsaXZlcmllcy5tYXAoKGQpID0+IFtkLmlmb29kT3JkZXJJZCwgZF0pKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIHN0eWxlPXt7IHBhZGRpbmc6IDIyLCBtYXhXaWR0aDogMTAwMCwgbWFyZ2luOiBcIjAgYXV0b1wiIH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2VcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDE4IH19PlxyXG4gICAgICAgIDxMaW5rIHRvPVwiL2ludGVncmFjb2VzL2lmb29kXCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+XHJcbiAgICAgICAgICDihpAgSW50ZWdyYcOnw6NvIGlGb29kXHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS43cmVtXCIgfX0+XHJcbiAgICAgICAgICBQZWRpZG9zIGlGb29kXHJcbiAgICAgICAgPC9oMj5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgbm92b3MgcGVkaWRvcyBjaGVnYW0gc296aW5ob3MgZSBqw6Egc8OjbyBjb25maXJtYWRvcyBhdXRvbWF0aWNhbWVudGUg4oCUIGFxdWkgdm9jw6pcclxuICAgICAgICAgIGFjb21wYW5oYSBlIGF2YW7Dp2EgbyBwcmVwYXJvIChlLCBwYXJhIGVudHJlZ2FzIHBvciBmcm90YSBwcsOzcHJpYSwgYSBsb2fDrXN0aWNhKVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7b3JkZXJzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17b3JkZXJzUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBwZWRpZG9zIGRvIGlGb29kXCIgLz59XHJcblxyXG4gICAgICB7IW9yZGVyc1F1ZXJ5LmlzTG9hZGluZyAmJiBvcmRlcnMubGVuZ3RoID09PSAwICYmICFvcmRlcnNRdWVyeS5pc0Vycm9yICYmIChcclxuICAgICAgICA8RW1wdHlTdGF0ZVxyXG4gICAgICAgICAgdGl0bGU9XCJOZW5odW0gcGVkaWRvIGlGb29kIGVtIGFiZXJ0b1wiXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbj1cIkFzc2ltIHF1ZSB1bSBwZWRpZG8gbm92byBjaGVnYXIgZG8gaUZvb2QsIGVsZSBhcGFyZWNlIGFxdWkgYXV0b21hdGljYW1lbnRlLlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAge29yZGVycy5tYXAoKG9yZGVyKSA9PiAoXHJcbiAgICAgICAgICA8SUZvb2RPcmRlckNhcmRcclxuICAgICAgICAgICAga2V5PXtvcmRlci5pZH1cclxuICAgICAgICAgICAgb3JkZXI9e29yZGVyfVxyXG4gICAgICAgICAgICBkZWxpdmVyeT17ZGVsaXZlcmllc0J5SUZvb2RPcmRlcklkLmdldChvcmRlci5pZCl9XHJcbiAgICAgICAgICAgIG9uU3RhcnRQcmVwYXJhdGlvbj17KCkgPT4gc3RhcnRQcmVwYXJhdGlvbk11dGF0aW9uLm11dGF0ZShvcmRlci5pZCl9XHJcbiAgICAgICAgICAgIG9uTWFya1JlYWR5PXsoKSA9PiBtYXJrUmVhZHlNdXRhdGlvbi5tdXRhdGUob3JkZXIuaWQpfVxyXG4gICAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0Q2FuY2VsbGluZ09yZGVyKG9yZGVyKX1cclxuICAgICAgICAgICAgb25UcmFjaz17KCkgPT4gc2V0VHJhY2tpbmdPcmRlcihvcmRlcil9XHJcbiAgICAgICAgICAgIG9uVmFsaWRhdGVQaWNrdXBDb2RlPXsoKSA9PiBzZXRQaWNrdXBDb2RlT3JkZXIob3JkZXIpfVxyXG4gICAgICAgICAgICBvbkFkdmFuY2VkPXsoKSA9PiBzZXRBZHZhbmNlZE9yZGVyKG9yZGVyKX1cclxuICAgICAgICAgICAgc3RhcnRQZW5kaW5nPXtzdGFydFByZXBhcmF0aW9uTXV0YXRpb24uaXNQZW5kaW5nICYmIHN0YXJ0UHJlcGFyYXRpb25NdXRhdGlvbi52YXJpYWJsZXMgPT09IG9yZGVyLmlkfVxyXG4gICAgICAgICAgICByZWFkeVBlbmRpbmc9e21hcmtSZWFkeU11dGF0aW9uLmlzUGVuZGluZyAmJiBtYXJrUmVhZHlNdXRhdGlvbi52YXJpYWJsZXMgPT09IG9yZGVyLmlkfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8RGlzcHV0ZXNTZWN0aW9uIGJyYW5jaElkPXticmFuY2hJZH0gLz5cclxuXHJcbiAgICAgIHtjYW5jZWxsaW5nT3JkZXIgJiYgKFxyXG4gICAgICAgIDxDYW5jZWxPcmRlck1vZGFsXHJcbiAgICAgICAgICBvcmRlcj17Y2FuY2VsbGluZ09yZGVyfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0Q2FuY2VsbGluZ09yZGVyKG51bGwpfVxyXG4gICAgICAgICAgb25DYW5jZWxsZWQ9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0Q2FuY2VsbGluZ09yZGVyKG51bGwpO1xyXG4gICAgICAgICAgICBpbnZhbGlkYXRlT3JkZXJzKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7dHJhY2tpbmdPcmRlciAmJiA8VHJhY2tPcmRlck1vZGFsIG9yZGVyPXt0cmFja2luZ09yZGVyfSBvbkNsb3NlPXsoKSA9PiBzZXRUcmFja2luZ09yZGVyKG51bGwpfSAvPn1cclxuXHJcbiAgICAgIHtwaWNrdXBDb2RlT3JkZXIgJiYgKFxyXG4gICAgICAgIDxWYWxpZGF0ZVBpY2t1cENvZGVNb2RhbFxyXG4gICAgICAgICAgb3JkZXI9e3BpY2t1cENvZGVPcmRlcn1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFBpY2t1cENvZGVPcmRlcihudWxsKX1cclxuICAgICAgICAgIG9uVmFsaWRhdGVkPXsoKSA9PiBzZXRQaWNrdXBDb2RlT3JkZXIobnVsbCl9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHthZHZhbmNlZE9yZGVyICYmIDxPcmRlckFkdmFuY2VkQWN0aW9uc01vZGFsIG9yZGVyPXthZHZhbmNlZE9yZGVyfSBvbkNsb3NlPXsoKSA9PiBzZXRBZHZhbmNlZE9yZGVyKG51bGwpfSAvPn1cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBJRm9vZE9yZGVyQ2FyZCh7XHJcbiAgb3JkZXIsXHJcbiAgZGVsaXZlcnksXHJcbiAgb25TdGFydFByZXBhcmF0aW9uLFxyXG4gIG9uTWFya1JlYWR5LFxyXG4gIG9uQ2FuY2VsLFxyXG4gIG9uVHJhY2ssXHJcbiAgb25WYWxpZGF0ZVBpY2t1cENvZGUsXHJcbiAgb25BZHZhbmNlZCxcclxuICBzdGFydFBlbmRpbmcsXHJcbiAgcmVhZHlQZW5kaW5nLFxyXG59OiB7XHJcbiAgb3JkZXI6IElGb29kT3JkZXJSZXNwb25zZTtcclxuICBkZWxpdmVyeTogSUZvb2RMb2dpc3RpY3NEZWxpdmVyeVJlc3BvbnNlIHwgdW5kZWZpbmVkO1xyXG4gIG9uU3RhcnRQcmVwYXJhdGlvbjogKCkgPT4gdm9pZDtcclxuICBvbk1hcmtSZWFkeTogKCkgPT4gdm9pZDtcclxuICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcclxuICBvblRyYWNrOiAoKSA9PiB2b2lkO1xyXG4gIG9uVmFsaWRhdGVQaWNrdXBDb2RlOiAoKSA9PiB2b2lkO1xyXG4gIG9uQWR2YW5jZWQ6ICgpID0+IHZvaWQ7XHJcbiAgc3RhcnRQZW5kaW5nOiBib29sZWFuO1xyXG4gIHJlYWR5UGVuZGluZzogYm9vbGVhbjtcclxufSkge1xyXG4gIGNvbnN0IGNhblN0YXJ0UHJlcGFyYXRpb24gPSBvcmRlci5zdGF0dXMgPT09IFwiQ09ORklSTUVEXCI7XHJcbiAgY29uc3QgY2FuTWFya1JlYWR5ID0gb3JkZXIuc3RhdHVzID09PSBcIkNPTkZJUk1FRFwiIHx8IG9yZGVyLnN0YXR1cyA9PT0gXCJQUkVQQVJBVElPTl9TVEFSVEVEXCI7XHJcbiAgY29uc3QgY2FuQ2FuY2VsID0gb3JkZXIuc3RhdHVzICE9PSBcIkNBTkNFTExFRFwiICYmIG9yZGVyLnN0YXR1cyAhPT0gXCJDT05DTFVERURcIjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInRpY2tldCByaXNlXCIgc3R5bGU9e3sgcGFkZGluZzogMTgsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEwIH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDIgfX0+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA3MDAsIGZvbnRTaXplOiBcIjEuMDVyZW1cIiB9fT5cclxuICAgICAgICAgICAgI3tvcmRlci5kaXNwbGF5SWQgPz8gb3JkZXIuaWZvb2RPcmRlcklkfSDigJQge29yZGVyLmN1c3RvbWVyTmFtZX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgICB7VFlQRV9MQUJFTFtvcmRlci5pZm9vZE9yZGVyVHlwZV0gPz8gb3JkZXIuaWZvb2RPcmRlclR5cGV9XHJcbiAgICAgICAgICAgIHtvcmRlci5jdXN0b21lclBob25lID8gYCDCtyAke29yZGVyLmN1c3RvbWVyUGhvbmV9YCA6IFwiXCJ9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICB7b3JkZXIuZGVsaXZlcnlBZGRyZXNzICYmIChcclxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PntvcmRlci5kZWxpdmVyeUFkZHJlc3N9PC9zcGFuPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIHtvcmRlci5vcmRlclRpbWluZyA9PT0gXCJTQ0hFRFVMRURcIiAmJiBvcmRlci5wcmVwYXJhdGlvblN0YXJ0RGF0ZVRpbWUgJiYgKFxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmZvLCAjM2I4MmY2KVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCB9fT5cclxuICAgICAgICAgICAgICDwn5OFIEFnZW5kYWRvIHBhcmF7XCIgXCJ9XHJcbiAgICAgICAgICAgICAge25ldyBEYXRlKG9yZGVyLnByZXBhcmF0aW9uU3RhcnREYXRlVGltZSkudG9Mb2NhbGVTdHJpbmcoXCJwdC1CUlwiLCB7XHJcbiAgICAgICAgICAgICAgICBkYXk6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgICAgICAgbW9udGg6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgICAgICAgaG91cjogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgICAgICBtaW51dGU6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiwganVzdGlmeUl0ZW1zOiBcImVuZFwiIH19PlxyXG4gICAgICAgICAgPFN0YXR1c0JhZGdlIGNvbG9yPXtTVEFUVVNfQ09MT1Jbb3JkZXIuc3RhdHVzXSA/PyBcInZhcigtLWluay1mYWludClcIn0+XHJcbiAgICAgICAgICAgIHtTVEFUVVNfTEFCRUxbb3JkZXIuc3RhdHVzXSA/PyBvcmRlci5zdGF0dXN9XHJcbiAgICAgICAgICA8L1N0YXR1c0JhZGdlPlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19PlxyXG4gICAgICAgICAgICB7b3JkZXIudG90YWxBbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJwdC1CUlwiLCB7IHN0eWxlOiBcImN1cnJlbmN5XCIsIGN1cnJlbmN5OiBcIkJSTFwiIH0pfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtvcmRlci5oYXNVbm1hcHBlZEl0ZW1zICYmIChcclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS13YXJuLCAjZDk3NzA2KVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+XHJcbiAgICAgICAgICDimqAgRXN0ZSBwZWRpZG8gdGVtIGl0ZW5zIHF1ZSBuw6NvIGZvcmFtIGVuY29udHJhZG9zIG5vIGNhcmTDoXBpbyAoY8OzZGlnbyBkZSBiYXJyYXMgbsOjb1xyXG4gICAgICAgICAgY2FkYXN0cmFkbykg4oCUIGNvbmZpcmEgbyBwZWRpZG8gbmEgdGVsYSBub3JtYWwgZGUgUGVkaWRvcyBhbnRlcyBkZSBwcmVwYXJhci5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7aXNPd25GbGVldEVsaWdpYmxlKG9yZGVyKSAmJiA8TG9naXN0aWNzUGFuZWwgaWZvb2RPcmRlcklkPXtvcmRlci5pZH0gZGVsaXZlcnk9e2RlbGl2ZXJ5fSAvPn1cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93XCIgc3R5bGU9e3sgZ2FwOiA4LCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgIHtpc0lGb29kVHJhY2tpbmdFbGlnaWJsZShvcmRlcikgJiYgKFxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBzaXplPVwic21cIiBvbkNsaWNrPXtvblRyYWNrfT5cclxuICAgICAgICAgICAgUmFzdHJlYXIgZW50cmVnYWRvclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7aXNQaWNrdXBDb2RlRWxpZ2libGUob3JkZXIpICYmIChcclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17b25WYWxpZGF0ZVBpY2t1cENvZGV9PlxyXG4gICAgICAgICAgICBWYWxpZGFyIGPDs2RpZ28gZGUgcmV0aXJhZGFcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBzaXplPVwic21cIiBvbkNsaWNrPXtvbkFkdmFuY2VkfT5cclxuICAgICAgICAgIE1haXMgYcOnw7Vlc1xyXG4gICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIHtjYW5TdGFydFByZXBhcmF0aW9uICYmIChcclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgbG9hZGluZz17c3RhcnRQZW5kaW5nfSBvbkNsaWNrPXtvblN0YXJ0UHJlcGFyYXRpb259PlxyXG4gICAgICAgICAgICBJbmljaWFyIHByZXBhcm9cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge2Nhbk1hcmtSZWFkeSAmJiAoXHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCIgbG9hZGluZz17cmVhZHlQZW5kaW5nfSBvbkNsaWNrPXtvbk1hcmtSZWFkeX0+XHJcbiAgICAgICAgICAgIE1hcmNhciBwcm9udG9cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge2NhbkNhbmNlbCAmJiAoXHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYW5nZXJcIiBzaXplPVwic21cIiBvbkNsaWNrPXtvbkNhbmNlbH0+XHJcbiAgICAgICAgICAgIENhbmNlbGFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcblxyXG4vLyBMb2fDrXN0aWNhIHBvciBmcm90YSBwcsOzcHJpYSAoZmFzZSA3KSDigJQgYXRyaWJ1aXIgZW50cmVnYWRvciBlIGFjb21wYW5oYXIgb3MgcGFzc29zIChzYWl1IHByYVxyXG4vLyBvcmlnZW0g4oaSIGNoZWdvdSBuYSBvcmlnZW0g4oaSIGRlc3BhY2hvdSDihpIgY2hlZ291IG5vIGRlc3Rpbm8g4oaSIHZlcmlmaWNhciBjw7NkaWdvIGRlIGVudHJlZ2EpLlxyXG4vLyBTZW0gZW50cmVnYWRvciBhdHJpYnXDrWRvIGFpbmRhLCBvZmVyZWNlIHPDsyBvIGJvdMOjbyBkZSBhdHJpYnVpw6fDo287IGNvbSBlbnRyZWdhZG9yLCBtb3N0cmEgb1xyXG4vLyBzdGF0dXMgYXR1YWwgZSBvIHByw7N4aW1vIHBhc3NvIGRpc3BvbsOtdmVsLlxyXG5mdW5jdGlvbiBMb2dpc3RpY3NQYW5lbCh7XHJcbiAgaWZvb2RPcmRlcklkLFxyXG4gIGRlbGl2ZXJ5LFxyXG59OiB7XHJcbiAgaWZvb2RPcmRlcklkOiBudW1iZXI7XHJcbiAgZGVsaXZlcnk6IElGb29kTG9naXN0aWNzRGVsaXZlcnlSZXNwb25zZSB8IHVuZGVmaW5lZDtcclxufSkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgW2Fzc2lnbmluZywgc2V0QXNzaWduaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdmVyaWZ5aW5nQ29kZSwgc2V0VmVyaWZ5aW5nQ29kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGludmFsaWRhdGVEZWxpdmVyaWVzID0gKCkgPT5cclxuICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJsb2dpc3RpY3NcIl0gfSk7XHJcblxyXG4gIGNvbnN0IGdvaW5nVG9PcmlnaW5NdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IG1hcmtJRm9vZEdvaW5nVG9PcmlnaW4oaWZvb2RPcmRlcklkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiRW50cmVnYWRvciBhIGNhbWluaG8gZGEgbG9qYS5cIik7XHJcbiAgICAgIGludmFsaWRhdGVEZWxpdmVyaWVzKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgcmVnaXN0cmFyIGEgc2HDrWRhIHBhcmEgYSBvcmlnZW0uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBhcnJpdmVkQXRPcmlnaW5NdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IG1hcmtJRm9vZEFycml2ZWRBdE9yaWdpbihpZm9vZE9yZGVySWQpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJDaGVnYWRhIG5hIGxvamEgcmVnaXN0cmFkYS5cIik7XHJcbiAgICAgIGludmFsaWRhdGVEZWxpdmVyaWVzKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgcmVnaXN0cmFyIGEgY2hlZ2FkYSBuYSBsb2phLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZGlzcGF0Y2hNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IGRpc3BhdGNoSUZvb2RMb2dpc3RpY3MoaWZvb2RPcmRlcklkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiRW50cmVnYSBkZXNwYWNoYWRhLlwiKTtcclxuICAgICAgaW52YWxpZGF0ZURlbGl2ZXJpZXMoKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBkZXNwYWNoYXIgYSBlbnRyZWdhLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgYXJyaXZlZEF0RGVzdGluYXRpb25NdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IG1hcmtJRm9vZEFycml2ZWRBdERlc3RpbmF0aW9uKGlmb29kT3JkZXJJZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNoZWdhZGEgbm8gZGVzdGlubyByZWdpc3RyYWRhLlwiKTtcclxuICAgICAgaW52YWxpZGF0ZURlbGl2ZXJpZXMoKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCByZWdpc3RyYXIgYSBjaGVnYWRhIG5vIGRlc3Rpbm8uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBpZiAoIWRlbGl2ZXJ5KSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogOCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHNpemU9XCJzbVwiIG9uQ2xpY2s9eygpID0+IHNldEFzc2lnbmluZyh0cnVlKX0+XHJcbiAgICAgICAgICDwn5u1IEF0cmlidWlyIGVudHJlZ2Fkb3JcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICB7YXNzaWduaW5nICYmIChcclxuICAgICAgICAgIDxBc3NpZ25Ecml2ZXJNb2RhbFxyXG4gICAgICAgICAgICBpZm9vZE9yZGVySWQ9e2lmb29kT3JkZXJJZH1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QXNzaWduaW5nKGZhbHNlKX1cclxuICAgICAgICAgICAgb25Bc3NpZ25lZD17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldEFzc2lnbmluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgaW52YWxpZGF0ZURlbGl2ZXJpZXMoKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uXHJcbiAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgZGlzcGxheTogXCJncmlkXCIsXHJcbiAgICAgICAgZ2FwOiA4LFxyXG4gICAgICAgIHBhZGRpbmc6IDEwLFxyXG4gICAgICAgIGJvcmRlclJhZGl1czogMTAsXHJcbiAgICAgICAgYm9yZGVyOiBcIjFweCBkYXNoZWQgdmFyKC0tYm9yZGVyLCByZ2JhKDAsMCwwLDAuMTIpKVwiLFxyXG4gICAgICB9fVxyXG4gICAgPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+XHJcbiAgICAgICAgICAgIPCfm7Uge2RlbGl2ZXJ5LmRyaXZlck5hbWV9IMK3IHtkZWxpdmVyeS5kcml2ZXJQaG9uZX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44cmVtXCIgfX0+e2RlbGl2ZXJ5LmRyaXZlclZlaGljbGVUeXBlfTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8U3RhdHVzQmFkZ2UgY29sb3I9e0xPR0lTVElDU19TVEFUVVNfQ09MT1JbZGVsaXZlcnkuc3RhdHVzXSA/PyBcInZhcigtLWluay1mYWludClcIn0+XHJcbiAgICAgICAgICB7TE9HSVNUSUNTX1NUQVRVU19MQUJFTFtkZWxpdmVyeS5zdGF0dXNdID8/IGRlbGl2ZXJ5LnN0YXR1c31cclxuICAgICAgICA8L1N0YXR1c0JhZGdlPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93XCIgc3R5bGU9e3sgZ2FwOiA4LCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgIHtkZWxpdmVyeS5zdGF0dXMgPT09IFwiRFJJVkVSX0FTU0lHTkVEXCIgJiYgKFxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICBsb2FkaW5nPXtnb2luZ1RvT3JpZ2luTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBnb2luZ1RvT3JpZ2luTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFNhaXUgcGFyYSByZXRpcmFkYVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7ZGVsaXZlcnkuc3RhdHVzID09PSBcIkdPSU5HX1RPX09SSUdJTlwiICYmIChcclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgbG9hZGluZz17YXJyaXZlZEF0T3JpZ2luTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhcnJpdmVkQXRPcmlnaW5NdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQ2hlZ291IG5hIGxvamFcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge2RlbGl2ZXJ5LnN0YXR1cyA9PT0gXCJBUlJJVkVEX0FUX09SSUdJTlwiICYmIChcclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBzaXplPVwic21cIiBsb2FkaW5nPXtkaXNwYXRjaE11dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gZGlzcGF0Y2hNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgIERlc3BhY2hhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7ZGVsaXZlcnkuc3RhdHVzID09PSBcIkRJU1BBVENIRURcIiAmJiAoXHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXHJcbiAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgIGxvYWRpbmc9e2Fycml2ZWRBdERlc3RpbmF0aW9uTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhcnJpdmVkQXREZXN0aW5hdGlvbk11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBDaGVnb3Ugbm8gZGVzdGlub1xyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7ZGVsaXZlcnkuc3RhdHVzID09PSBcIkFSUklWRURfQVRfREVTVElOQVRJT05cIiAmJiAoXHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gc2V0VmVyaWZ5aW5nQ29kZSh0cnVlKX0+XHJcbiAgICAgICAgICAgIFZlcmlmaWNhciBjw7NkaWdvIGRlIGVudHJlZ2FcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge2RlbGl2ZXJ5LnN0YXR1cyA9PT0gXCJERUxJVkVSWV9DT0RFX1ZFUklGSUVEXCIgJiYgKFxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tb2spXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgZm9udFdlaWdodDogNjAwIH19PuKckyBFbnRyZWdhIGNvbmNsdcOtZGE8L3NwYW4+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7dmVyaWZ5aW5nQ29kZSAmJiAoXHJcbiAgICAgICAgPFZlcmlmeURlbGl2ZXJ5Q29kZU1vZGFsXHJcbiAgICAgICAgICBpZm9vZE9yZGVySWQ9e2lmb29kT3JkZXJJZH1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFZlcmlmeWluZ0NvZGUoZmFsc2UpfVxyXG4gICAgICAgICAgb25WZXJpZmllZD17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRWZXJpZnlpbmdDb2RlKGZhbHNlKTtcclxuICAgICAgICAgICAgaW52YWxpZGF0ZURlbGl2ZXJpZXMoKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBBc3NpZ25Ecml2ZXJNb2RhbCh7XHJcbiAgaWZvb2RPcmRlcklkLFxyXG4gIG9uQ2xvc2UsXHJcbiAgb25Bc3NpZ25lZCxcclxufToge1xyXG4gIGlmb29kT3JkZXJJZDogbnVtYmVyO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25Bc3NpZ25lZDogKCkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbZHJpdmVyTmFtZSwgc2V0RHJpdmVyTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZHJpdmVyUGhvbmUsIHNldERyaXZlclBob25lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtkcml2ZXJWZWhpY2xlVHlwZSwgc2V0RHJpdmVyVmVoaWNsZVR5cGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IGFzc2lnbk11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gYXNzaWduSUZvb2REcml2ZXIoaWZvb2RPcmRlcklkLCB7IGRyaXZlck5hbWUsIGRyaXZlclBob25lLCBkcml2ZXJWZWhpY2xlVHlwZSB9KSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiRW50cmVnYWRvciBhdHJpYnXDrWRvIG5vIGlGb29kLlwiKTtcclxuICAgICAgb25Bc3NpZ25lZCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIGF0cmlidWlyIG8gZW50cmVnYWRvciDigJQgY29uZmlyYSBvcyBkYWRvcyBlIHRlbnRlIGRlIG5vdm8uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjYW5TdWJtaXQgPSBkcml2ZXJOYW1lLnRyaW0oKS5sZW5ndGggPiAwICYmIGRyaXZlclBob25lLnRyaW0oKS5sZW5ndGggPiAwICYmIGRyaXZlclZlaGljbGVUeXBlLnRyaW0oKS5sZW5ndGggPiAwO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsIG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPVwiQXRyaWJ1aXIgZW50cmVnYWRvclwiPlxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE0LCBtaW5XaWR0aDogMzIwIH19PlxyXG4gICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgIGxhYmVsPVwiTm9tZSBkbyBlbnRyZWdhZG9yXCJcclxuICAgICAgICAgIHZhbHVlPXtkcml2ZXJOYW1lfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREcml2ZXJOYW1lKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlRlbGVmb25lXCIgdmFsdWU9e2RyaXZlclBob25lfSBvbkNoYW5nZT17KGUpID0+IHNldERyaXZlclBob25lKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICBsYWJlbD1cIlZlw61jdWxvXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZXguOiBtb3RvLCBiaWtlLCBjYXJyb1wiXHJcbiAgICAgICAgICB2YWx1ZT17ZHJpdmVyVmVoaWNsZVR5cGV9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERyaXZlclZlaGljbGVUeXBlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTAsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICBWb2x0YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB2YXJpYW50PVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXshY2FuU3VibWl0fVxyXG4gICAgICAgICAgICBsb2FkaW5nPXthc3NpZ25NdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFzc2lnbk11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBBdHJpYnVpclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9Nb2RhbD5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBWZXJpZnlEZWxpdmVyeUNvZGVNb2RhbCh7XHJcbiAgaWZvb2RPcmRlcklkLFxyXG4gIG9uQ2xvc2UsXHJcbiAgb25WZXJpZmllZCxcclxufToge1xyXG4gIGlmb29kT3JkZXJJZDogbnVtYmVyO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25WZXJpZmllZDogKCkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbY29kZSwgc2V0Q29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgdmVyaWZ5TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiB2ZXJpZnlJRm9vZERlbGl2ZXJ5Q29kZShpZm9vZE9yZGVySWQsIGNvZGUpLFxyXG4gICAgb25TdWNjZXNzOiAocmVzdWx0KSA9PiB7XHJcbiAgICAgIGlmIChyZXN1bHQuY29kZU1hdGNoZWQpIHtcclxuICAgICAgICB0b2FzdC5zdWNjZXNzKFwiQ8OzZGlnbyBjb25maXJtYWRvIOKAlCBlbnRyZWdhIGNvbmNsdcOtZGEuXCIpO1xyXG4gICAgICAgIG9uVmVyaWZpZWQoKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0b2FzdC5lcnJvcihcIkPDs2RpZ28gaW5jb3JyZXRvIOKAlCBjb25maXJhIGNvbSBvIGNsaWVudGUgZSB0ZW50ZSBkZSBub3ZvLlwiKTtcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHZlcmlmaWNhciBvIGPDs2RpZ28gbm8gaUZvb2QuXCIpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsIG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPVwiVmVyaWZpY2FyIGPDs2RpZ28gZGUgZW50cmVnYVwiPlxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE0LCBtaW5XaWR0aDogMjgwIH19PlxyXG4gICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgIGxhYmVsPVwiQ8OzZGlnbyBpbmZvcm1hZG8gcGVsbyBjbGllbnRlXCJcclxuICAgICAgICAgIHZhbHVlPXtjb2RlfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb2RlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DbG9zZX0+XHJcbiAgICAgICAgICAgIFZvbHRhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgZGlzYWJsZWQ9eyFjb2RlLnRyaW0oKX1cclxuICAgICAgICAgICAgbG9hZGluZz17dmVyaWZ5TXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2ZXJpZnlNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgVmVyaWZpY2FyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L01vZGFsPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIENhbmNlbE9yZGVyTW9kYWwoe1xyXG4gIG9yZGVyLFxyXG4gIG9uQ2xvc2UsXHJcbiAgb25DYW5jZWxsZWQsXHJcbn06IHtcclxuICBvcmRlcjogSUZvb2RPcmRlclJlc3BvbnNlO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25DYW5jZWxsZWQ6ICgpID0+IHZvaWQ7XHJcbn0pIHtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgW3JlYXNvbkNvZGUsIHNldFJlYXNvbkNvZGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IHJlYXNvbnNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImNhbmNlbGxhdGlvbi1yZWFzb25zXCIsIG9yZGVyLmlkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldElGb29kQ2FuY2VsbGF0aW9uUmVhc29ucyhvcmRlci5pZCksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGNhbmNlbE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gY2FuY2VsSUZvb2RPcmRlcihvcmRlci5pZCwgcmVhc29uQ29kZSksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNhbmNlbGFtZW50byBzb2xpY2l0YWRvIGFvIGlGb29kIOKAlCBvIHBlZGlkbyBzb21lIGRhIGxpc3RhIHF1YW5kbyBvIGlGb29kIGNvbmZpcm1hci5cIik7XHJcbiAgICAgIG9uQ2FuY2VsbGVkKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgc29saWNpdGFyIG8gY2FuY2VsYW1lbnRvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcmVhc29ucyA9IHJlYXNvbnNRdWVyeS5kYXRhID8/IFtdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsIG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPXtgQ2FuY2VsYXIgcGVkaWRvICMke29yZGVyLmRpc3BsYXlJZCA/PyBvcmRlci5pZm9vZE9yZGVySWR9YH0+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQsIG1pbldpZHRoOiAzMjAgfX0+XHJcbiAgICAgICAge3JlYXNvbnNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtyZWFzb25zUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBtb3Rpdm9zIGRlIGNhbmNlbGFtZW50b1wiIC8+fVxyXG5cclxuICAgICAgICA8U2VsZWN0RmllbGRcclxuICAgICAgICAgIGxhYmVsPVwiTW90aXZvIGRvIGNhbmNlbGFtZW50b1wiXHJcbiAgICAgICAgICB2YWx1ZT17cmVhc29uQ29kZX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVhc29uQ29kZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBkaXNhYmxlZD17cmVhc29uc1F1ZXJ5LmlzTG9hZGluZ31cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWNpb25lIHVtIG1vdGl2b+KApjwvb3B0aW9uPlxyXG4gICAgICAgICAge3JlYXNvbnMubWFwKChyZWFzb24pID0+IChcclxuICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3JlYXNvbi5jb2RlfSB2YWx1ZT17cmVhc29uLmNvZGV9PlxyXG4gICAgICAgICAgICAgIHtyZWFzb24uZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9TZWxlY3RGaWVsZD5cclxuXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DbG9zZX0+XHJcbiAgICAgICAgICAgIFZvbHRhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJkYW5nZXJcIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17IXJlYXNvbkNvZGV9XHJcbiAgICAgICAgICAgIGxvYWRpbmc9e2NhbmNlbE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY2FuY2VsTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENvbmZpcm1hciBjYW5jZWxhbWVudG9cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvTW9kYWw+XHJcbiAgKTtcclxufVxyXG5cclxuLy8gRmFzZSA5YiDigJQgcmFzdHJlYW1lbnRvIChwb3Npw6fDo28gZG8gZW50cmVnYWRvcikgcHJhIHBlZGlkb3MgZW50cmVndWVzIHBlbGEgbG9nw61zdGljYSBkbyBwcsOzcHJpb1xyXG4vLyBpRm9vZC4gTWVzbW8gcGFkcsOjbyBkZSB0ZWxhIHVzYWRvIGVtIFRyYWNraW5nTW9kYWwgKElGb29kU2hpcHBpbmdQYWdlLnRzeCksIG1hcyBsZW5kbyBkZVxyXG4vLyBHRVQgb3JkZXIvdjEuMC9vcmRlcnMve2lkfS90cmFja2luZy5cclxuZnVuY3Rpb24gVHJhY2tPcmRlck1vZGFsKHsgb3JkZXIsIG9uQ2xvc2UgfTogeyBvcmRlcjogSUZvb2RPcmRlclJlc3BvbnNlOyBvbkNsb3NlOiAoKSA9PiB2b2lkIH0pIHtcclxuICBjb25zdCB0cmFja2luZ1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwib3JkZXItdHJhY2tpbmdcIiwgb3JkZXIuaWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RPcmRlclRyYWNraW5nKG9yZGVyLmlkKSxcclxuICAgIHJlZmV0Y2hJbnRlcnZhbDogMTVfMDAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB0cmFja2luZyA9IHRyYWNraW5nUXVlcnkuZGF0YTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxNb2RhbCBvbkNsb3NlPXtvbkNsb3NlfSB0aXRsZT17YFJhc3RyZWFyICMke29yZGVyLmRpc3BsYXlJZCA/PyBvcmRlci5pZm9vZE9yZGVySWR9YH0+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIsIG1pbldpZHRoOiAzMDAgfX0+XHJcbiAgICAgICAge3RyYWNraW5nUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17dHJhY2tpbmdRdWVyeS5lcnJvcn0gd2hhdD1cIm8gcmFzdHJlYW1lbnRvXCIgLz59XHJcbiAgICAgICAge3RyYWNraW5nUXVlcnkuaXNMb2FkaW5nICYmIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5DYXJyZWdhbmRv4oCmPC9zcGFuPn1cclxuICAgICAgICB7dHJhY2tpbmcgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAge3RyYWNraW5nLmxhdGl0dWRlICE9IG51bGwgJiYgdHJhY2tpbmcubG9uZ2l0dWRlICE9IG51bGwgPyAoXHJcbiAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICBQb3Npw6fDo28gZG8gZW50cmVnYWRvcjoge3RyYWNraW5nLmxhdGl0dWRlLnRvRml4ZWQoNSl9LCB7dHJhY2tpbmcubG9uZ2l0dWRlLnRvRml4ZWQoNSl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5Qb3Npw6fDo28gYWluZGEgbsOjbyBkaXNwb27DrXZlbC48L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHt0cmFja2luZy5leHBlY3RlZERlbGl2ZXJ5ICYmIChcclxuICAgICAgICAgICAgICA8c3Bhbj5QcmV2aXPDo28gZGUgZW50cmVnYToge25ldyBEYXRlKHRyYWNraW5nLmV4cGVjdGVkRGVsaXZlcnkpLnRvTG9jYWxlVGltZVN0cmluZyhcInB0LUJSXCIpfTwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DbG9zZX0+XHJcbiAgICAgICAgICAgIEZlY2hhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9Nb2RhbD5cclxuICApO1xyXG59XHJcblxyXG4vLyBGYXNlIDliIOKAlCBjb25maXJtYSBvIGPDs2RpZ28gZGUgcmV0aXJhZGEgaW5mb3JtYWRvIHBlbG8gY2xpZW50ZSBubyBiYWxjw6NvIChwZWRpZG9zIFRBS0VPVVQpLlxyXG5mdW5jdGlvbiBWYWxpZGF0ZVBpY2t1cENvZGVNb2RhbCh7XHJcbiAgb3JkZXIsXHJcbiAgb25DbG9zZSxcclxuICBvblZhbGlkYXRlZCxcclxufToge1xyXG4gIG9yZGVyOiBJRm9vZE9yZGVyUmVzcG9uc2U7XHJcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxuICBvblZhbGlkYXRlZDogKCkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbY29kZSwgc2V0Q29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiB2YWxpZGF0ZUlGb29kUGlja3VwQ29kZShvcmRlci5pZCwgY29kZS50cmltKCkpLFxyXG4gICAgb25TdWNjZXNzOiAocmVzdWx0KSA9PiB7XHJcbiAgICAgIGlmIChyZXN1bHQuY29kZU1hdGNoZWQpIHtcclxuICAgICAgICB0b2FzdC5zdWNjZXNzKFwiQ8OzZGlnbyBjb25maXJtYWRvIOKAlCBwb2RlIGVudHJlZ2FyIG8gcGVkaWRvLlwiKTtcclxuICAgICAgICBvblZhbGlkYXRlZCgpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRvYXN0LmVycm9yKFwiQ8OzZGlnbyBpbmNvcnJldG8g4oCUIGNvbmZpcmEgY29tIG8gY2xpZW50ZSBlIHRlbnRlIGRlIG5vdm8uXCIpO1xyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgdmFsaWRhciBvIGPDs2RpZ28gbm8gaUZvb2QuXCIpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsIG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPXtgVmFsaWRhciByZXRpcmFkYSDigJQgIyR7b3JkZXIuZGlzcGxheUlkID8/IG9yZGVyLmlmb29kT3JkZXJJZH1gfT5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxNCwgbWluV2lkdGg6IDI4MCB9fT5cclxuICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiQ8OzZGlnbyBpbmZvcm1hZG8gcGVsbyBjbGllbnRlXCIgdmFsdWU9e2NvZGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29kZShlLnRhcmdldC52YWx1ZSl9IGF1dG9Gb2N1cyAvPlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTAsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIgfX0+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICBWb2x0YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIGRpc2FibGVkPXshY29kZS50cmltKCl9IGxvYWRpbmc9e211dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gbXV0YXRpb24ubXV0YXRlKCl9PlxyXG4gICAgICAgICAgICBWYWxpZGFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L01vZGFsPlxyXG4gICk7XHJcbn1cclxuXHJcbi8vIEZhc2UgOWMg4oCUIHJlw7puZSBudW0gc8OzIGx1Z2FyIG9zIGdhcHMgZG8gbcOzZHVsbyBPcmRlciBmZWNoYWRvcyBuYSBhdWRpdG9yaWEgZGUgMjAyNi0wOC0yMC8yMTpcclxuLy8gdmlydHVhbCBiYWcgKEdyb2NlcnkpLCByZXF1ZXN0RHJpdmVyL2NhbmNlbFJlcXVlc3REcml2ZXIvdmVyaWZ5RGVsaXZlcnlDb2RlIGRvIFBSw5NQUklPIG3Ds2R1bG9cclxuLy8gT3JkZXIgKGRpc3RpbnRvcyBkb3MgaG9tw7RuaW1vcyBlbSBTaGlwcGluZy9Mb2dpc3RpY3MgasOhIGNvYmVydG9zIG5vIHJlc3RvIGRhIHRlbGEpLiBTw6NvXHJcbi8vIGVuZHBvaW50cyBwb3VjbyB1c2Fkb3Mgbm8gZmx1eG8gZG8gZGlhIGEgZGlhIGRvIFN5bmNCYXIgKHPDsyB2ZW5kZSBGT09EL0ZPT0RfU0VMRl9TRVJWSUNFLCBuw6NvXHJcbi8vIEdyb2NlcnkpLCBwb3IgaXNzbyBmaWNhbSBhZ3J1cGFkb3MgYXF1aSBlbSB2ZXogZGUgZXNwYWxoYWRvcyBwZWxvIGNhcmQgZG8gcGVkaWRvLlxyXG5mdW5jdGlvbiBPcmRlckFkdmFuY2VkQWN0aW9uc01vZGFsKHsgb3JkZXIsIG9uQ2xvc2UgfTogeyBvcmRlcjogSUZvb2RPcmRlclJlc3BvbnNlOyBvbkNsb3NlOiAoKSA9PiB2b2lkIH0pIHtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgW3Nob3dCYWcsIHNldFNob3dCYWddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt2ZXJpZnlpbmdDb2RlLCBzZXRWZXJpZnlpbmdDb2RlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY29kZSwgc2V0Q29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgLy8gRmFzZSAxMSDigJQgdHJvY2EgZGUgZW5kZXJlw6dvIGRlIGVudHJlZ2EgZW0gYW5kYW1lbnRvIChtw7NkdWxvIFNoaXBwaW5nKS5cclxuICBjb25zdCBbc2hvd0FkZHJlc3NDaGFuZ2VGb3JtLCBzZXRTaG93QWRkcmVzc0NoYW5nZUZvcm1dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZGRyU3RyZWV0TnVtYmVyLCBzZXRBZGRyU3RyZWV0TnVtYmVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthZGRyU3RyZWV0TmFtZSwgc2V0QWRkclN0cmVldE5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FkZHJDb21wbGVtZW50LCBzZXRBZGRyQ29tcGxlbWVudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRkck5laWdoYm9yaG9vZCwgc2V0QWRkck5laWdoYm9yaG9vZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRkckNpdHksIHNldEFkZHJDaXR5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthZGRyU3RhdGUsIHNldEFkZHJTdGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRkclJlZmVyZW5jZSwgc2V0QWRkclJlZmVyZW5jZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgYmFnUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJ2aXJ0dWFsLWJhZ1wiLCBvcmRlci5pZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZE9yZGVyVmlydHVhbEJhZyhvcmRlci5pZCksXHJcbiAgICBlbmFibGVkOiBzaG93QmFnLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByZXF1ZXN0RHJpdmVyTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiByZXF1ZXN0SUZvb2RPcmRlckRyaXZlcihvcmRlci5pZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHRvYXN0LnN1Y2Nlc3MoXCJFbnRyZWdhZG9yIHNvbGljaXRhZG8gKG3Ds2R1bG8gT3JkZXIpIG5vIGlGb29kLlwiKSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHNvbGljaXRhciBvIGVudHJlZ2Fkb3Igbm8gaUZvb2QuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjYW5jZWxEcml2ZXJNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IGNhbmNlbElGb29kT3JkZXJEcml2ZXJSZXF1ZXN0KG9yZGVyLmlkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4gdG9hc3Quc3VjY2VzcyhcIlNvbGljaXRhw6fDo28gZGUgZW50cmVnYWRvciBjYW5jZWxhZGEgKG3Ds2R1bG8gT3JkZXIpIG5vIGlGb29kLlwiKSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIGNhbmNlbGFyIGEgc29saWNpdGHDp8OjbyBubyBpRm9vZC5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHZlcmlmeUNvZGVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHZlcmlmeUlGb29kT3JkZXJEZWxpdmVyeUNvZGUob3JkZXIuaWQsIGNvZGUudHJpbSgpKSxcclxuICAgIG9uU3VjY2VzczogKHJlc3VsdCkgPT4ge1xyXG4gICAgICBpZiAocmVzdWx0LmNvZGVNYXRjaGVkKSB7XHJcbiAgICAgICAgdG9hc3Quc3VjY2VzcyhcIkPDs2RpZ28gY29uZmlybWFkbyBubyBpRm9vZC5cIik7XHJcbiAgICAgICAgc2V0VmVyaWZ5aW5nQ29kZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q29kZShcIlwiKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0b2FzdC5lcnJvcihcIkPDs2RpZ28gaW5jb3JyZXRvIOKAlCBjb25maXJhIGNvbSBvIGNsaWVudGUgZSB0ZW50ZSBkZSBub3ZvLlwiKTtcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHZlcmlmaWNhciBvIGPDs2RpZ28gbm8gaUZvb2QuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByZXF1ZXN0QWRkcmVzc0NoYW5nZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgcmVxdWVzdElGb29kRGVsaXZlcnlBZGRyZXNzQ2hhbmdlKG9yZGVyLmlkLCB7XHJcbiAgICAgICAgc3RyZWV0TnVtYmVyOiBhZGRyU3RyZWV0TnVtYmVyLnRyaW0oKSxcclxuICAgICAgICBzdHJlZXROYW1lOiBhZGRyU3RyZWV0TmFtZS50cmltKCksXHJcbiAgICAgICAgY29tcGxlbWVudDogYWRkckNvbXBsZW1lbnQudHJpbSgpIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICBuZWlnaGJvcmhvb2Q6IGFkZHJOZWlnaGJvcmhvb2QudHJpbSgpLFxyXG4gICAgICAgIGNpdHk6IGFkZHJDaXR5LnRyaW0oKSxcclxuICAgICAgICBzdGF0ZTogYWRkclN0YXRlLnRyaW0oKSxcclxuICAgICAgICByZWZlcmVuY2U6IGFkZHJSZWZlcmVuY2UudHJpbSgpIHx8IHVuZGVmaW5lZCxcclxuICAgICAgfSksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIlRyb2NhIGRlIGVuZGVyZcOnbyBzb2xpY2l0YWRhIGFvIGlGb29kLlwiKTtcclxuICAgICAgc2V0U2hvd0FkZHJlc3NDaGFuZ2VGb3JtKGZhbHNlKTtcclxuICAgICAgc2V0QWRkclN0cmVldE51bWJlcihcIlwiKTtcclxuICAgICAgc2V0QWRkclN0cmVldE5hbWUoXCJcIik7XHJcbiAgICAgIHNldEFkZHJDb21wbGVtZW50KFwiXCIpO1xyXG4gICAgICBzZXRBZGRyTmVpZ2hib3Job29kKFwiXCIpO1xyXG4gICAgICBzZXRBZGRyQ2l0eShcIlwiKTtcclxuICAgICAgc2V0QWRkclN0YXRlKFwiXCIpO1xyXG4gICAgICBzZXRBZGRyUmVmZXJlbmNlKFwiXCIpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHNvbGljaXRhciBhIHRyb2NhIGRlIGVuZGVyZcOnbyBubyBpRm9vZC5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGFjY2VwdEFkZHJlc3NDaGFuZ2VNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IGFjY2VwdElGb29kRGVsaXZlcnlBZGRyZXNzQ2hhbmdlKG9yZGVyLmlkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4gdG9hc3Quc3VjY2VzcyhcIlRyb2NhIGRlIGVuZGVyZcOnbyBhY2VpdGEgbm8gaUZvb2QuXCIpLFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgYWNlaXRhciBhIHRyb2NhIGRlIGVuZGVyZcOnbyBubyBpRm9vZC5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGRlbnlBZGRyZXNzQ2hhbmdlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBkZW55SUZvb2REZWxpdmVyeUFkZHJlc3NDaGFuZ2Uob3JkZXIuaWQpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB0b2FzdC5zdWNjZXNzKFwiVHJvY2EgZGUgZW5kZXJlw6dvIHJlY3VzYWRhIG5vIGlGb29kLlwiKSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHJlY3VzYXIgYSB0cm9jYSBkZSBlbmRlcmXDp28gbm8gaUZvb2QuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjb25maXJtVXNlckFkZHJlc3NNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IGNvbmZpcm1JRm9vZFVzZXJBZGRyZXNzKG9yZGVyLmlkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4gdG9hc3Quc3VjY2VzcyhcIkVuZGVyZcOnbyBkbyB1c3XDoXJpbyBjb25maXJtYWRvIG5vIGlGb29kLlwiKSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIGNvbmZpcm1hciBvIGVuZGVyZcOnbyBkbyB1c3XDoXJpbyBubyBpRm9vZC5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGJhZyA9IGJhZ1F1ZXJ5LmRhdGE7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TW9kYWwgb25DbG9zZT17b25DbG9zZX0gdGl0bGU9e2BNYWlzIGHDp8O1ZXMg4oCUICMke29yZGVyLmRpc3BsYXlJZCA/PyBvcmRlci5pZm9vZE9yZGVySWR9YH0+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTYsIG1pbldpZHRoOiAzNDAgfX0+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5TYWNvbGEgdmlydHVhbCAoR3JvY2VyeSk8L3NwYW4+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHNpemU9XCJzbVwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dCYWcodHJ1ZSl9IGxvYWRpbmc9e3Nob3dCYWcgJiYgYmFnUXVlcnkuaXNMb2FkaW5nfT5cclxuICAgICAgICAgICAgQ29uc3VsdGFyIHNhY29sYVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICB7c2hvd0JhZyAmJiBiYWdRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtiYWdRdWVyeS5lcnJvcn0gd2hhdD1cImEgc2Fjb2xhIGRvIHBlZGlkb1wiIC8+fVxyXG4gICAgICAgICAge3Nob3dCYWcgJiYgYmFnICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIiBzdHlsZT17eyBwYWRkaW5nOiAxMiwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgIDxzcGFuPlN0YXR1czoge2JhZy5zdGF0dXMgPz8gXCLigJRcIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4+SXRlbnM6IHtiYWcuaXRlbXMubGVuZ3RofTwvc3Bhbj5cclxuICAgICAgICAgICAgICB7YmFnLmdyb3NzVmFsdWVBbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgIFZhbG9yIGJydXRvOiB7YmFnLmdyb3NzVmFsdWVBbW91bnR9IHtiYWcuZ3Jvc3NWYWx1ZUN1cnJlbmN5ID8/IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PkVudHJlZ2Fkb3IgKGVuZHBvaW50IHByw7NwcmlvIGRvIG3Ds2R1bG8gT3JkZXIpPC9zcGFuPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgbG9hZGluZz17cmVxdWVzdERyaXZlck11dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gcmVxdWVzdERyaXZlck11dGF0aW9uLm11dGF0ZSgpfT5cclxuICAgICAgICAgICAgICBTb2xpY2l0YXJcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgbG9hZGluZz17Y2FuY2VsRHJpdmVyTXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBjYW5jZWxEcml2ZXJNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgICAgQ2FuY2VsYXIgc29saWNpdGHDp8Ojb1xyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlZlcmlmaWNhciBjw7NkaWdvIGRlIGVudHJlZ2EgKG3Ds2R1bG8gT3JkZXIpPC9zcGFuPlxyXG4gICAgICAgICAgeyF2ZXJpZnlpbmdDb2RlID8gKFxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHNpemU9XCJzbVwiIG9uQ2xpY2s9eygpID0+IHNldFZlcmlmeWluZ0NvZGUodHJ1ZSl9PlxyXG4gICAgICAgICAgICAgIEluZm9ybWFyIGPDs2RpZ29cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiQ8OzZGlnb1wiIHZhbHVlPXtjb2RlfSBvbkNoYW5nZT17KGUpID0+IHNldENvZGUoZS50YXJnZXQudmFsdWUpfSBhdXRvRm9jdXMgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjb2RlLnRyaW0oKX1cclxuICAgICAgICAgICAgICAgIGxvYWRpbmc9e3ZlcmlmeUNvZGVNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2ZXJpZnlDb2RlTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgVmVyaWZpY2FyXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5Ucm9jYSBkZSBlbmRlcmXDp28gZGUgZW50cmVnYSAobcOzZHVsbyBTaGlwcGluZyk8L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOHJlbVwiIH19PlxyXG4gICAgICAgICAgICBmbHV4byBiaWRpcmVjaW9uYWwg4oCUIHNvbGljaXRlIHVtIG5vdm8gZW5kZXJlw6dvIHByYSBwcm9wb3IgYSB0cm9jYSwgb3UgYWNlaXRlL3JlY3VzZS9jb25maXJtZVxyXG4gICAgICAgICAgICBxdWFuZG8gw6kgbyBjbGllbnRlIHF1ZW0gcHJvcMO1ZSBwZWxvIGFwcCBkZWxlXHJcbiAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgeyFzaG93QWRkcmVzc0NoYW5nZUZvcm0gPyAoXHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZHJlc3NDaGFuZ2VGb3JtKHRydWUpfT5cclxuICAgICAgICAgICAgICBTb2xpY2l0YXIgbm92byBlbmRlcmXDp29cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxMDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJOw7ptZXJvXCIgdmFsdWU9e2FkZHJTdHJlZXROdW1iZXJ9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QWRkclN0cmVldE51bWJlcihlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMiwgbWluV2lkdGg6IDE4MCB9fT5cclxuICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlJ1YVwiIHZhbHVlPXthZGRyU3RyZWV0TmFtZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRBZGRyU3RyZWV0TmFtZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkNvbXBsZW1lbnRvXCIgdmFsdWU9e2FkZHJDb21wbGVtZW50fSBvbkNoYW5nZT17KGUpID0+IHNldEFkZHJDb21wbGVtZW50KGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTYwIH19PlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiQmFpcnJvXCIgdmFsdWU9e2FkZHJOZWlnaGJvcmhvb2R9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QWRkck5laWdoYm9yaG9vZChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMiwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkNpZGFkZVwiIHZhbHVlPXthZGRyQ2l0eX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRBZGRyQ2l0eShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDEwMCB9fT5cclxuICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkVzdGFkbyAoVUYpXCIgdmFsdWU9e2FkZHJTdGF0ZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRBZGRyU3RhdGUoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlJlZmVyw6puY2lhIChvcGNpb25hbClcIiB2YWx1ZT17YWRkclJlZmVyZW5jZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRBZGRyUmVmZXJlbmNlKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogOCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZHJlc3NDaGFuZ2VGb3JtKGZhbHNlKX0+XHJcbiAgICAgICAgICAgICAgICAgIENhbmNlbGFyXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWFkZHJTdHJlZXROdW1iZXIudHJpbSgpIHx8ICFhZGRyU3RyZWV0TmFtZS50cmltKCkgfHwgIWFkZHJOZWlnaGJvcmhvb2QudHJpbSgpIHx8ICFhZGRyQ2l0eS50cmltKCkgfHwgIWFkZHJTdGF0ZS50cmltKCl9XHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e3JlcXVlc3RBZGRyZXNzQ2hhbmdlTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZXF1ZXN0QWRkcmVzc0NoYW5nZU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBFbnZpYXIgc29saWNpdGHDp8Ojb1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogOCB9fT5cclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBzaXplPVwic21cIiBsb2FkaW5nPXthY2NlcHRBZGRyZXNzQ2hhbmdlTXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBhY2NlcHRBZGRyZXNzQ2hhbmdlTXV0YXRpb24ubXV0YXRlKCl9PlxyXG4gICAgICAgICAgICAgIEFjZWl0YXIgdHJvY2FcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgbG9hZGluZz17ZGVueUFkZHJlc3NDaGFuZ2VNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IGRlbnlBZGRyZXNzQ2hhbmdlTXV0YXRpb24ubXV0YXRlKCl9PlxyXG4gICAgICAgICAgICAgIFJlY3VzYXIgdHJvY2FcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgbG9hZGluZz17Y29uZmlybVVzZXJBZGRyZXNzTXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBjb25maXJtVXNlckFkZHJlc3NNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgICAgQ29uZmlybWFyIGVuZGVyZcOnbyBkbyB1c3XDoXJpb1xyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgICAgRmVjaGFyXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L01vZGFsPlxyXG4gICk7XHJcbn1cclxuXHJcbi8vIEZhc2UgOWIg4oCUIGRpc3B1dGFzIEhhbmRzaGFrZSAoYWNlaXRhci9yZWplaXRhcikuIE8gU3luY0JhciBhaW5kYSBuw6NvIGluZ2VyZSBvcyBldmVudG9zIGRlXHJcbi8vIGRpc3B1dGEgYXV0b21hdGljYW1lbnRlICh2ZXIgcmVzc2FsdmEgbm8gYmFja2VuZCkg4oCUIGEgZXF1aXBlIGluZm9ybWEgbyBEaXNwdXRlSWQgcmVjZWJpZG8gbm9cclxuLy8gYXBwL3BhaW5lbCBkbyBpRm9vZCBxdWFuZG8gbyBjbGllbnRlIGFicmUgdW1hIGRpc3B1dGEgcMOzcy1lbnRyZWdhLlxyXG5mdW5jdGlvbiBEaXNwdXRlc1NlY3Rpb24oeyBicmFuY2hJZCB9OiB7IGJyYW5jaElkOiBudW1iZXIgfSkge1xyXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICBjb25zdCBbZGlzcHV0ZUlkLCBzZXREaXNwdXRlSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtsYXN0UmVzdWx0LCBzZXRMYXN0UmVzdWx0XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICAvLyBGYXNlIDljIOKAlCBwcm9wb3N0YSBkZSBhbHRlcm5hdGl2YSAoUE9TVCBkaXNwdXRlcy97aWR9L2FsdGVybmF0aXZlcy97YWx0ZXJuYXRpdmVJZH0pLlxyXG4gIGNvbnN0IFthbHRlcm5hdGl2ZUlkLCBzZXRBbHRlcm5hdGl2ZUlkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthbHRlcm5hdGl2ZVR5cGUsIHNldEFsdGVybmF0aXZlVHlwZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWx0ZXJuYXRpdmVBbW91bnQsIHNldEFsdGVybmF0aXZlQW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBhY2NlcHRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IGFjY2VwdElGb29kRGlzcHV0ZShicmFuY2hJZCwgZGlzcHV0ZUlkLnRyaW0oKSksXHJcbiAgICBvblN1Y2Nlc3M6IChyZXN1bHQpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkRpc3B1dGEgYWNlaXRhIG5vIGlGb29kLlwiKTtcclxuICAgICAgc2V0TGFzdFJlc3VsdChyZXN1bHQuc3RhdHVzID8/IFwiYWNlaXRhXCIpO1xyXG4gICAgICBzZXREaXNwdXRlSWQoXCJcIik7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgYWNlaXRhciBhIGRpc3B1dGEg4oCUIGNvbmZpcmEgbyBJRCBlIHRlbnRlIGRlIG5vdm8uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByZWplY3RNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHJlamVjdElGb29kRGlzcHV0ZShicmFuY2hJZCwgZGlzcHV0ZUlkLnRyaW0oKSwgcmVhc29uLnRyaW0oKSksXHJcbiAgICBvblN1Y2Nlc3M6IChyZXN1bHQpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkRpc3B1dGEgcmVqZWl0YWRhIG5vIGlGb29kLlwiKTtcclxuICAgICAgc2V0TGFzdFJlc3VsdChyZXN1bHQuc3RhdHVzID8/IFwicmVqZWl0YWRhXCIpO1xyXG4gICAgICBzZXREaXNwdXRlSWQoXCJcIik7XHJcbiAgICAgIHNldFJlYXNvbihcIlwiKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCByZWplaXRhciBhIGRpc3B1dGEg4oCUIGNvbmZpcmEgbyBJRCwgbyBtb3Rpdm8gZSB0ZW50ZSBkZSBub3ZvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgYWx0ZXJuYXRpdmVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIHJlcXVlc3RJRm9vZERpc3B1dGVBbHRlcm5hdGl2ZShcclxuICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICBkaXNwdXRlSWQudHJpbSgpLFxyXG4gICAgICAgIGFsdGVybmF0aXZlSWQudHJpbSgpLFxyXG4gICAgICAgIGFsdGVybmF0aXZlVHlwZS50cmltKCksXHJcbiAgICAgICAgYWx0ZXJuYXRpdmVBbW91bnQudHJpbSgpID8gTnVtYmVyKGFsdGVybmF0aXZlQW1vdW50LnRyaW0oKS5yZXBsYWNlKFwiLFwiLCBcIi5cIikpIDogdW5kZWZpbmVkLFxyXG4gICAgICAgIGFsdGVybmF0aXZlQW1vdW50LnRyaW0oKSA/IFwiQlJMXCIgOiB1bmRlZmluZWQsXHJcbiAgICAgICksXHJcbiAgICBvblN1Y2Nlc3M6IChyZXN1bHQpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkFsdGVybmF0aXZhIHByb3Bvc3RhIG5vIGlGb29kLlwiKTtcclxuICAgICAgc2V0TGFzdFJlc3VsdChyZXN1bHQuc3RhdHVzID8/IFwiYWx0ZXJuYXRpdmEgcHJvcG9zdGFcIik7XHJcbiAgICAgIHNldEFsdGVybmF0aXZlSWQoXCJcIik7XHJcbiAgICAgIHNldEFsdGVybmF0aXZlVHlwZShcIlwiKTtcclxuICAgICAgc2V0QWx0ZXJuYXRpdmVBbW91bnQoXCJcIik7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgcHJvcG9yIGEgYWx0ZXJuYXRpdmEg4oCUIGNvbmZpcmEgb3MgZGFkb3MgZSB0ZW50ZSBkZSBub3ZvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInRpY2tldFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE4LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiwgbWFyZ2luVG9wOiAyMiB9fT5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjA1cmVtXCIgfX0+XHJcbiAgICAgICAgICBEaXNwdXRhcyAoSGFuZHNoYWtlKVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5cclxuICAgICAgICAgIHF1YW5kbyBvIGNsaWVudGUgYWJyZSB1bWEgZGlzcHV0YSBww7NzLWVudHJlZ2EsIG8gaUZvb2QgYXZpc2EgYSBlcXVpcGUgZm9yYSBkbyBTeW5jQmFyIOKAlFxyXG4gICAgICAgICAgaW5mb3JtZSBhcXVpIG8gSUQgZGEgZGlzcHV0YSBwcmEgYWNlaXRhciwgcmVqZWl0YXIgb3UgcHJvcG9yIHVtYSBhbHRlcm5hdGl2YVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAsIGFsaWduSXRlbXM6IFwiZW5kXCIgfX0+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMjAwIH19PlxyXG4gICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIklEIGRhIGRpc3B1dGFcIiB2YWx1ZT17ZGlzcHV0ZUlkfSBvbkNoYW5nZT17KGUpID0+IHNldERpc3B1dGVJZChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAyLCBtaW5XaWR0aDogMjIwIH19PlxyXG4gICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICBsYWJlbD1cIk1vdGl2byAob2JyaWdhdMOzcmlvIHBhcmEgcmVqZWl0YXIpXCJcclxuICAgICAgICAgICAgdmFsdWU9e3JlYXNvbn1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWFzb24oZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4LjogY2xpZW50ZSByZWNlYmV1IG8gcGVkaWRvIGNvcnJldGFtZW50ZVwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgZGlzYWJsZWQ9eyFkaXNwdXRlSWQudHJpbSgpfSBsb2FkaW5nPXthY2NlcHRNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IGFjY2VwdE11dGF0aW9uLm11dGF0ZSgpfT5cclxuICAgICAgICAgIEFjZWl0YXJcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICB2YXJpYW50PVwiZGFuZ2VyXCJcclxuICAgICAgICAgIGRpc2FibGVkPXshZGlzcHV0ZUlkLnRyaW0oKSB8fCAhcmVhc29uLnRyaW0oKX1cclxuICAgICAgICAgIGxvYWRpbmc9e3JlamVjdE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlamVjdE11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIFJlamVpdGFyXHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwLCBhbGlnbkl0ZW1zOiBcImVuZFwiIH19PlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJJRCBkYSBhbHRlcm5hdGl2YVwiIHZhbHVlPXthbHRlcm5hdGl2ZUlkfSBvbkNoYW5nZT17KGUpID0+IHNldEFsdGVybmF0aXZlSWQoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgbGFiZWw9XCJUaXBvIGRhIGFsdGVybmF0aXZhXCJcclxuICAgICAgICAgICAgdmFsdWU9e2FsdGVybmF0aXZlVHlwZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBbHRlcm5hdGl2ZVR5cGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4LjogUkVGVU5EX0lURU1TXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTIwIH19PlxyXG4gICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICBsYWJlbD1cIlZhbG9yIChvcGNpb25hbClcIlxyXG4gICAgICAgICAgICB2YWx1ZT17YWx0ZXJuYXRpdmVBbW91bnR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QWx0ZXJuYXRpdmVBbW91bnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4LjogMTAsMDBcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgZGlzYWJsZWQ9eyFkaXNwdXRlSWQudHJpbSgpIHx8ICFhbHRlcm5hdGl2ZUlkLnRyaW0oKSB8fCAhYWx0ZXJuYXRpdmVUeXBlLnRyaW0oKX1cclxuICAgICAgICAgIGxvYWRpbmc9e2FsdGVybmF0aXZlTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gYWx0ZXJuYXRpdmVNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBQcm9wb3IgYWx0ZXJuYXRpdmFcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7bGFzdFJlc3VsdCAmJiAoXHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjgycmVtXCIgfX0+w5psdGltYSBhw6fDo28gcmVnaXN0cmFkYSDigJQgc3RhdHVzIG5vIGlGb29kOiB7bGFzdFJlc3VsdH08L3NwYW4+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvaW50ZWdyYXRpb25zL0lGb29kT3JkZXJzUGFnZS50c3gifQ==