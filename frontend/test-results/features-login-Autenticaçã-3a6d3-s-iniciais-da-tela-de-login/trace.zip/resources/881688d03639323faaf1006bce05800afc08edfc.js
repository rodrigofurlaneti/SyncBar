import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/PaymentPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getOpenSession, openCashSession } from "/src/features/cash/api.ts";
import { registerSale } from "/src/features/billing/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import {
  DEFAULT_CASH_REGISTER_ID,
  PaymentMethod,
  formatBRL,
  paymentMethodLabel
} from "/src/lib/types.ts";
const needsReceipt = (methodId) => methodId === PaymentMethod.CartaoCredito || methodId === PaymentMethod.CartaoDebito || methodId === PaymentMethod.Pix;
const parseAmount = (raw) => {
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) ? value : 0;
};
export function PaymentPanel({ order, onPaid }) {
  _s();
  const queryClient = useQueryClient();
  const { employeeId } = useAuthStore();
  const [rows, setRows] = useState(
    [
      { paymentMethodId: PaymentMethod.Dinheiro, amount: "", authorizationCode: "" }
    ]
  );
  const [openingAmount, setOpeningAmount] = useState("");
  const [error, setError] = useState(null);
  const [splitCount, setSplitCount] = useState("2");
  const sessionQuery = useQuery({
    queryKey: ["cash", "open", DEFAULT_CASH_REGISTER_ID],
    queryFn: () => getOpenSession(DEFAULT_CASH_REGISTER_ID),
    retry: false
  });
  const noSession = sessionQuery.isError && sessionQuery.error instanceof ApiError && sessionQuery.error.status === 404;
  const noCashAccess = sessionQuery.isError && sessionQuery.error instanceof ApiError && sessionQuery.error.status === 403;
  const openSessionMutation = useMutation({
    mutationFn: () => openCashSession(DEFAULT_CASH_REGISTER_ID, employeeId ?? 1, parseAmount(openingAmount)),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ["cash"] }),
    onError: (e) => setError(e instanceof ApiError ? e.message : "Falha ao abrir o caixa.")
  });
  const amountDue = order.totalAmount - order.partialPaidAmount;
  const totalPaid = rows.reduce((sum, row) => sum + parseAmount(row.amount), 0);
  const cashPaid = rows.filter((row) => row.paymentMethodId === PaymentMethod.Dinheiro).reduce((sum, row) => sum + parseAmount(row.amount), 0);
  const change = Math.max(0, Number((totalPaid - amountDue).toFixed(2)));
  const changeValid = change === 0 || cashPaid >= change;
  const canConfirm = totalPaid >= amountDue && changeValid && rows.every((r) => parseAmount(r.amount) > 0);
  const payMutation = useMutation({
    mutationFn: () => {
      let changeLeft = change;
      const payments = rows.map((row) => {
        const amount = parseAmount(row.amount);
        let changeAmount = null;
        if (row.paymentMethodId === PaymentMethod.Dinheiro && changeLeft > 0) {
          changeAmount = Math.min(changeLeft, amount);
          changeLeft = Number((changeLeft - changeAmount).toFixed(2));
        }
        return {
          paymentMethodId: row.paymentMethodId,
          amount,
          changeAmount,
          authorizationCode: row.authorizationCode.trim() === "" ? null : row.authorizationCode.trim()
        };
      });
      return registerSale(order.id, sessionQuery.data.id, employeeId ?? 1, payments);
    },
    onSuccess: () => {
      setError(null);
      onPaid();
    },
    onError: (e) => setError(e instanceof ApiError ? e.message : "Falha ao registrar pagamento.")
  });
  const setRow = (index, patch) => setRows((current) => current.map((row, i) => i === index ? { ...row, ...patch } : row));
  const applySplit = () => {
    const people = Math.max(1, Math.trunc(Number(splitCount) || 1));
    const totalCents = Math.round(amountDue * 100);
    const baseCents = Math.floor(totalCents / people);
    const remainder = totalCents % people;
    setRows(
      Array.from({ length: people }, (_, i) => ({
        paymentMethodId: PaymentMethod.Dinheiro,
        amount: ((baseCents + (i < remainder ? 1 : 0)) / 100).toFixed(2).replace(".", ","),
        authorizationCode: ""
      }))
    );
  };
  if (sessionQuery.isLoading)
    return /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)" }, children: "Verificando caixa…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
      lineNumber: 143,
      columnNumber: 10
    }, this);
  if (noCashAccess)
    return /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 18, display: "grid", gap: 6 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Conta fechada — aguardando pagamento." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 148,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Você não tem acesso ao caixa. Chame o operador de caixa ou o gerente para registrar o pagamento." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 149,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
      lineNumber: 147,
      columnNumber: 5
    }, this);
  if (noSession)
    return /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 18, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "O caixa está fechado." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 159,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Abra uma sessão de caixa para receber pagamentos." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 160,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          placeholder: "Fundo de troco (R$)",
          inputMode: "decimal",
          value: openingAmount,
          onChange: (e) => setOpeningAmount(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
          lineNumber: 163,
          columnNumber: 9
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 169,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          disabled: openSessionMutation.isPending,
          onClick: () => openSessionMutation.mutate(),
          children: "Abrir caixa"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
          lineNumber: 170,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
      lineNumber: 158,
      columnNumber: 5
    }, this);
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "display", style: { fontSize: "1.2rem" }, children: [
      "Pagamento — ",
      formatBRL(amountDue)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
      lineNumber: 183,
      columnNumber: 7
    }, this),
    order.partialPaidAmount > 0 && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)", fontSize: "0.85rem", margin: 0 }, children: [
      "Conta de ",
      formatBRL(order.totalAmount),
      " com",
      " ",
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ok)" }, children: [
        formatBRL(order.partialPaidAmount),
        " já pagos parcialmente"
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 189,
        columnNumber: 11
      }, this),
      "."
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
      lineNumber: 187,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8, gridTemplateColumns: "1fr auto", alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          placeholder: "Dividir entre quantas pessoas?",
          inputMode: "numeric",
          value: splitCount,
          onChange: (e) => setSplitCount(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
          lineNumber: 194,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("button", { className: "btn-ghost", type: "button", onClick: applySplit, children: "Dividir conta" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 200,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
      lineNumber: 193,
      columnNumber: 7
    }, this),
    rows.map(
      (row, index) => /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { alignItems: "center" }, children: [
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            style: { flex: 2, minWidth: 170 },
            value: row.paymentMethodId,
            onChange: (e) => setRow(index, { paymentMethodId: Number(e.target.value) }),
            children: Object.entries(paymentMethodLabel).map(
              ([id, label]) => /* @__PURE__ */ jsxDEV("option", { value: id, children: label }, id, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
                lineNumber: 213,
                columnNumber: 11
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
            lineNumber: 207,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            style: { flex: 1, minWidth: 110 },
            placeholder: "Valor",
            inputMode: "decimal",
            value: row.amount,
            onChange: (e) => setRow(index, { amount: e.target.value })
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
            lineNumber: 218,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "btn-ghost btn-icon",
            "aria-label": "Remover forma de pagamento",
            title: "Remover forma de pagamento",
            disabled: rows.length === 1,
            onClick: () => setRows((current) => current.filter((_, i) => i !== index)),
            children: "✕"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
            lineNumber: 225,
            columnNumber: 11
          },
          this
        ),
        needsReceipt(row.paymentMethodId) && /* @__PURE__ */ jsxDEV(
          "input",
          {
            style: { flex: "1 1 100%" },
            placeholder: "Comprovante / autorização (ex.: AUT-123456)",
            value: row.authorizationCode,
            onChange: (e) => setRow(index, { authorizationCode: e.target.value })
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
            lineNumber: 236,
            columnNumber: 9
          },
          this
        )
      ] }, index, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 206,
        columnNumber: 7
      }, this)
    ),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "btn-ghost",
        onClick: () => setRows(
          (current) => [
            ...current,
            { paymentMethodId: PaymentMethod.CartaoCredito, amount: "", authorizationCode: "" }
          ]
        ),
        children: "+ Adicionar forma de pagamento"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 246,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: "12px 16px", display: "grid", gap: 4 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", color: "var(--ink-dim)" }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Pago" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
          lineNumber: 261,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(totalPaid) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
          lineNumber: 262,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 260,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", color: "var(--ink-dim)" }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Restante" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
          lineNumber: 265,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(Math.max(0, amountDue - totalPaid)) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
          lineNumber: 266,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 264,
        columnNumber: 9
      }, this),
      change > 0 && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", color: "var(--amber)" }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Troco (dinheiro)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
          lineNumber: 272,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(change) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
          lineNumber: 273,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 271,
        columnNumber: 9
      }, this),
      !changeValid && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: "O troco excede o valor pago em dinheiro." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 277,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
      lineNumber: 259,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
      lineNumber: 281,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "btn-primary",
        disabled: !canConfirm || payMutation.isPending,
        onClick: () => payMutation.mutate(),
        children: payMutation.isPending ? "Registrando…" : "Confirmar pagamento"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
        lineNumber: 283,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx",
    lineNumber: 182,
    columnNumber: 5
  }, this);
}
_s(PaymentPanel, "jsVKmhaCbJ3bbme6kHZ6AzH8yTA=", false, function() {
  return [useQueryClient, useAuthStore, useQuery, useMutation, useMutation];
});
_c = PaymentPanel;
var _c;
$RefreshReg$(_c, "PaymentPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/PaymentPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkhXOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNIVixTQUFTQSxnQkFBZ0I7QUFDMUIsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLGdCQUFnQkMsdUJBQXVCO0FBQ2hELFNBQVNDLG9CQUEyQztBQUNwRCxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQWNQLE1BQU1DLGVBQWVBLENBQUNDLGFBQ3BCQSxhQUFhSixjQUFjSyxpQkFDM0JELGFBQWFKLGNBQWNNLGdCQUMzQkYsYUFBYUosY0FBY087QUFFN0IsTUFBTUMsY0FBY0EsQ0FBQ0MsUUFBd0I7QUFDM0MsUUFBTUMsUUFBUUMsT0FBT0YsSUFBSUcsUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUMxQyxTQUFPRCxPQUFPRSxTQUFTSCxLQUFLLElBQUlBLFFBQVE7QUFDMUM7QUFFTyxnQkFBU0ksYUFBYSxFQUFFQyxPQUFPQyxPQUFjLEdBQUc7QUFBQUMsS0FBQTtBQUNyRCxRQUFNQyxjQUFjekIsZUFBZTtBQUNuQyxRQUFNLEVBQUUwQixXQUFXLElBQUl0QixhQUFhO0FBQ3BDLFFBQU0sQ0FBQ3VCLE1BQU1DLE9BQU8sSUFBSS9CO0FBQUFBLElBQXVCO0FBQUEsTUFDN0MsRUFBRWdDLGlCQUFpQnRCLGNBQWN1QixVQUFVQyxRQUFRLElBQUlDLG1CQUFtQixHQUFHO0FBQUEsSUFBQztBQUFBLEVBQy9FO0FBQ0QsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSXJDLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNzQyxPQUFPQyxRQUFRLElBQUl2QyxTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQ3dDLFlBQVlDLGFBQWEsSUFBSXpDLFNBQVMsR0FBRztBQUVoRCxRQUFNMEMsZUFBZXhDLFNBQVM7QUFBQSxJQUM1QnlDLFVBQVUsQ0FBQyxRQUFRLFFBQVFsQyx3QkFBd0I7QUFBQSxJQUNuRG1DLFNBQVNBLE1BQU14QyxlQUFlSyx3QkFBd0I7QUFBQSxJQUN0RG9DLE9BQU87QUFBQSxFQUNULENBQUM7QUFFRCxRQUFNQyxZQUNKSixhQUFhSyxXQUNiTCxhQUFhSixpQkFBaUI5QixZQUM5QmtDLGFBQWFKLE1BQU1VLFdBQVc7QUFFaEMsUUFBTUMsZUFDSlAsYUFBYUssV0FDYkwsYUFBYUosaUJBQWlCOUIsWUFDOUJrQyxhQUFhSixNQUFNVSxXQUFXO0FBRWhDLFFBQU1FLHNCQUFzQmpELFlBQVk7QUFBQSxJQUN0Q2tELFlBQVlBLE1BQ1Y5QyxnQkFBZ0JJLDBCQUEwQm9CLGNBQWMsR0FBR1gsWUFBWWtCLGFBQWEsQ0FBQztBQUFBLElBQ3ZGZ0IsV0FBV0EsTUFBTSxLQUFLeEIsWUFBWXlCLGtCQUFrQixFQUFFVixVQUFVLENBQUMsTUFBTSxFQUFFLENBQUM7QUFBQSxJQUMxRVcsU0FBU0EsQ0FBQ0MsTUFBTWhCLFNBQVNnQixhQUFhL0MsV0FBVytDLEVBQUVDLFVBQVUseUJBQXlCO0FBQUEsRUFDeEYsQ0FBQztBQUVELFFBQU1DLFlBQVloQyxNQUFNaUMsY0FBY2pDLE1BQU1rQztBQUM1QyxRQUFNQyxZQUFZOUIsS0FBSytCLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsTUFBTTVDLFlBQVk2QyxJQUFJN0IsTUFBTSxHQUFHLENBQUM7QUFDNUUsUUFBTThCLFdBQVdsQyxLQUNkbUMsT0FBTyxDQUFDRixRQUFRQSxJQUFJL0Isb0JBQW9CdEIsY0FBY3VCLFFBQVEsRUFDOUQ0QixPQUFPLENBQUNDLEtBQUtDLFFBQVFELE1BQU01QyxZQUFZNkMsSUFBSTdCLE1BQU0sR0FBRyxDQUFDO0FBQ3hELFFBQU1nQyxTQUFTQyxLQUFLQyxJQUFJLEdBQUcvQyxRQUFRdUMsWUFBWUgsV0FBV1ksUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNyRSxRQUFNQyxjQUFjSixXQUFXLEtBQUtGLFlBQVlFO0FBQ2hELFFBQU1LLGFBQWFYLGFBQWFILGFBQWFhLGVBQWV4QyxLQUFLMEMsTUFBTSxDQUFDQyxNQUFNdkQsWUFBWXVELEVBQUV2QyxNQUFNLElBQUksQ0FBQztBQUV2RyxRQUFNd0MsY0FBY3pFLFlBQVk7QUFBQSxJQUM5QmtELFlBQVlBLE1BQU07QUFFaEIsVUFBSXdCLGFBQWFUO0FBQ2pCLFlBQU1VLFdBQStCOUMsS0FBSytDLElBQUksQ0FBQ2QsUUFBUTtBQUNyRCxjQUFNN0IsU0FBU2hCLFlBQVk2QyxJQUFJN0IsTUFBTTtBQUNyQyxZQUFJNEMsZUFBOEI7QUFDbEMsWUFBSWYsSUFBSS9CLG9CQUFvQnRCLGNBQWN1QixZQUFZMEMsYUFBYSxHQUFHO0FBQ3BFRyx5QkFBZVgsS0FBS1ksSUFBSUosWUFBWXpDLE1BQU07QUFDMUN5Qyx1QkFBYXRELFFBQVFzRCxhQUFhRyxjQUFjVCxRQUFRLENBQUMsQ0FBQztBQUFBLFFBQzVEO0FBQ0EsZUFBTztBQUFBLFVBQ0xyQyxpQkFBaUIrQixJQUFJL0I7QUFBQUEsVUFDckJFO0FBQUFBLFVBQ0E0QztBQUFBQSxVQUNBM0MsbUJBQW1CNEIsSUFBSTVCLGtCQUFrQjZDLEtBQUssTUFBTSxLQUFLLE9BQU9qQixJQUFJNUIsa0JBQWtCNkMsS0FBSztBQUFBLFFBQzdGO0FBQUEsTUFDRixDQUFDO0FBQ0QsYUFBTzFFLGFBQWFtQixNQUFNd0QsSUFBSXZDLGFBQWF3QyxLQUFNRCxJQUFJcEQsY0FBYyxHQUFHK0MsUUFBUTtBQUFBLElBQ2hGO0FBQUEsSUFDQXhCLFdBQVdBLE1BQU07QUFDZmIsZUFBUyxJQUFJO0FBQ2JiLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQTRCLFNBQVNBLENBQUNDLE1BQU1oQixTQUFTZ0IsYUFBYS9DLFdBQVcrQyxFQUFFQyxVQUFVLCtCQUErQjtBQUFBLEVBQzlGLENBQUM7QUFFRCxRQUFNMkIsU0FBU0EsQ0FBQ0MsT0FBZUMsVUFDN0J0RCxRQUFRLENBQUN1RCxZQUFZQSxRQUFRVCxJQUFJLENBQUNkLEtBQUt3QixNQUFPQSxNQUFNSCxRQUFRLEVBQUUsR0FBR3JCLEtBQUssR0FBR3NCLE1BQU0sSUFBSXRCLEdBQUksQ0FBQztBQUUxRixRQUFNeUIsYUFBYUEsTUFBTTtBQUN2QixVQUFNQyxTQUFTdEIsS0FBS0MsSUFBSSxHQUFHRCxLQUFLdUIsTUFBTXJFLE9BQU9tQixVQUFVLEtBQUssQ0FBQyxDQUFDO0FBQzlELFVBQU1tRCxhQUFheEIsS0FBS3lCLE1BQU1uQyxZQUFZLEdBQUc7QUFDN0MsVUFBTW9DLFlBQVkxQixLQUFLMkIsTUFBTUgsYUFBYUYsTUFBTTtBQUNoRCxVQUFNTSxZQUFZSixhQUFhRjtBQUUvQjFEO0FBQUFBLE1BQ0VpRSxNQUFNQyxLQUFLLEVBQUVDLFFBQVFULE9BQU8sR0FBRyxDQUFDVSxHQUFHWixPQUFPO0FBQUEsUUFDeEN2RCxpQkFBaUJ0QixjQUFjdUI7QUFBQUEsUUFDL0JDLFVBQVUyRCxhQUFhTixJQUFJUSxZQUFZLElBQUksTUFBTSxLQUFLMUIsUUFBUSxDQUFDLEVBQUUvQyxRQUFRLEtBQUssR0FBRztBQUFBLFFBQ2pGYSxtQkFBbUI7QUFBQSxNQUNyQixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFQSxNQUFJTyxhQUFhMEQ7QUFDZixXQUFPLHVCQUFDLE9BQUUsT0FBTyxFQUFFQyxPQUFPLGlCQUFpQixHQUFHLGtDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlEO0FBRWxFLE1BQUlwRDtBQUNGLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFcUQsU0FBUyxJQUFJQyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwRTtBQUFBLDZCQUFDLFlBQU8scURBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QztBQUFBLE1BQzdDLHVCQUFDLFVBQUssT0FBTyxFQUFFSCxPQUFPLGtCQUFrQkksVUFBVSxTQUFTLEdBQUcsZ0hBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBR0osTUFBSTNEO0FBQ0YsV0FDRSx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUV3RCxTQUFTLElBQUlDLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ3JFO0FBQUEsNkJBQUMsWUFBTyxxQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsTUFDN0IsdUJBQUMsVUFBSyxPQUFPLEVBQUVILE9BQU8sa0JBQWtCSSxVQUFVLFNBQVMsR0FBRyxpRUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsYUFBWTtBQUFBLFVBQ1osV0FBVTtBQUFBLFVBQ1YsT0FBT3JFO0FBQUFBLFVBQ1AsVUFBVSxDQUFDbUIsTUFBTWxCLGlCQUFpQmtCLEVBQUVtRCxPQUFPdEYsS0FBSztBQUFBO0FBQUEsUUFKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSW9EO0FBQUEsTUFFbkRrQixTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQzNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFDVixVQUFVWSxvQkFBb0J5RDtBQUFBQSxVQUM5QixTQUFTLE1BQU16RCxvQkFBb0IwRCxPQUFPO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBR0osU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRUwsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDckM7QUFBQSwyQkFBQyxTQUFJLFdBQVUsV0FBVSxPQUFPLEVBQUVDLFVBQVUsU0FBUyxHQUFHO0FBQUE7QUFBQSxNQUN6QzlGLFVBQVU4QyxTQUFTO0FBQUEsU0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ2hDLE1BQU1rQyxvQkFBb0IsS0FDekIsdUJBQUMsT0FBRSxPQUFPLEVBQUUwQyxPQUFPLGtCQUFrQkksVUFBVSxXQUFXSSxRQUFRLEVBQUUsR0FBRztBQUFBO0FBQUEsTUFDM0RsRyxVQUFVYyxNQUFNaUMsV0FBVztBQUFBLE1BQUU7QUFBQSxNQUFLO0FBQUEsTUFDNUMsdUJBQUMsVUFBSyxPQUFPLEVBQUUyQyxPQUFPLFlBQVksR0FBSTFGO0FBQUFBLGtCQUFVYyxNQUFNa0MsaUJBQWlCO0FBQUEsUUFBRTtBQUFBLFdBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Y7QUFBQSxNQUFPO0FBQUEsU0FGeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFHRix1QkFBQyxTQUFJLE9BQU8sRUFBRTRDLFNBQVMsUUFBUUMsS0FBSyxHQUFHTSxxQkFBcUIsWUFBWUMsWUFBWSxTQUFTLEdBQzNGO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLGFBQVk7QUFBQSxVQUNaLFdBQVU7QUFBQSxVQUNWLE9BQU92RTtBQUFBQSxVQUNQLFVBQVUsQ0FBQ2UsTUFBTWQsY0FBY2MsRUFBRW1ELE9BQU90RixLQUFLO0FBQUE7QUFBQSxRQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJaUQ7QUFBQSxNQUVqRCx1QkFBQyxZQUFPLFdBQVUsYUFBWSxNQUFLLFVBQVMsU0FBU29FLFlBQVksNkJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQzFELEtBQUsrQztBQUFBQSxNQUFJLENBQUNkLEtBQUtxQixVQUNkLHVCQUFDLFNBQWdCLFdBQVUsc0JBQXFCLE9BQU8sRUFBRTJCLFlBQVksU0FBUyxHQUM1RTtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPLEVBQUVDLE1BQU0sR0FBR0MsVUFBVSxJQUFJO0FBQUEsWUFDaEMsT0FBT2xELElBQUkvQjtBQUFBQSxZQUNYLFVBQVUsQ0FBQ3VCLE1BQU00QixPQUFPQyxPQUFPLEVBQUVwRCxpQkFBaUJYLE9BQU9rQyxFQUFFbUQsT0FBT3RGLEtBQUssRUFBRSxDQUFDO0FBQUEsWUFFekU4RixpQkFBT0MsUUFBUXZHLGtCQUFrQixFQUFFaUU7QUFBQUEsY0FBSSxDQUFDLENBQUNJLElBQUltQyxLQUFLLE1BQ2pELHVCQUFDLFlBQWdCLE9BQU9uQyxJQUNyQm1DLG1CQURVbkMsSUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFDRDtBQUFBO0FBQUEsVUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU8sRUFBRStCLE1BQU0sR0FBR0MsVUFBVSxJQUFJO0FBQUEsWUFDaEMsYUFBWTtBQUFBLFlBQ1osV0FBVTtBQUFBLFlBQ1YsT0FBT2xELElBQUk3QjtBQUFBQSxZQUNYLFVBQVUsQ0FBQ3FCLE1BQU00QixPQUFPQyxPQUFPLEVBQUVsRCxRQUFRcUIsRUFBRW1ELE9BQU90RixNQUFNLENBQUM7QUFBQTtBQUFBLFVBTDNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUs2RDtBQUFBLFFBRTdEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixjQUFXO0FBQUEsWUFDWCxPQUFNO0FBQUEsWUFDTixVQUFVVSxLQUFLb0UsV0FBVztBQUFBLFlBQzFCLFNBQVMsTUFBTW5FLFFBQVEsQ0FBQ3VELFlBQVlBLFFBQVFyQixPQUFPLENBQUNrQyxHQUFHWixNQUFNQSxNQUFNSCxLQUFLLENBQUM7QUFBQSxZQUFFO0FBQUE7QUFBQSxVQU43RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFFBQ0N2RSxhQUFha0QsSUFBSS9CLGVBQWUsS0FDL0I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU8sRUFBRWdGLE1BQU0sV0FBVztBQUFBLFlBQzFCLGFBQVk7QUFBQSxZQUNaLE9BQU9qRCxJQUFJNUI7QUFBQUEsWUFDWCxVQUFVLENBQUNvQixNQUFNNEIsT0FBT0MsT0FBTyxFQUFFakQsbUJBQW1Cb0IsRUFBRW1ELE9BQU90RixNQUFNLENBQUM7QUFBQTtBQUFBLFVBSnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl3RTtBQUFBLFdBbENsRWdFLE9BQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFDQTtBQUFBLElBQ0Q7QUFBQSxJQUVEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxXQUFVO0FBQUEsUUFDVixTQUFTLE1BQ1ByRDtBQUFBQSxVQUFRLENBQUN1RCxZQUFZO0FBQUEsWUFDbkIsR0FBR0E7QUFBQUEsWUFDSCxFQUFFdEQsaUJBQWlCdEIsY0FBY0ssZUFBZW1CLFFBQVEsSUFBSUMsbUJBQW1CLEdBQUc7QUFBQSxVQUFDO0FBQUEsUUFDcEY7QUFBQSxRQUNGO0FBQUE7QUFBQSxNQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVdBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVtRSxTQUFTLGFBQWFDLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQzdFO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVELFNBQVMsUUFBUWMsZ0JBQWdCLGlCQUFpQmhCLE9BQU8saUJBQWlCLEdBQ3RGO0FBQUEsK0JBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVU7QUFBQSxRQUNWLHVCQUFDLFVBQUssV0FBVSxZQUFZMUYsb0JBQVVpRCxTQUFTLEtBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxXQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFMkMsU0FBUyxRQUFRYyxnQkFBZ0IsaUJBQWlCaEIsT0FBTyxpQkFBaUIsR0FDdEY7QUFBQSwrQkFBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBQ2QsdUJBQUMsVUFBSyxXQUFVLFlBQ2IxRixvQkFBVXdELEtBQUtDLElBQUksR0FBR1gsWUFBWUcsU0FBUyxDQUFDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQ00sU0FBUyxLQUNSLHVCQUFDLFNBQUksT0FBTyxFQUFFcUMsU0FBUyxRQUFRYyxnQkFBZ0IsaUJBQWlCaEIsT0FBTyxlQUFlLEdBQ3BGO0FBQUEsK0JBQUMsVUFBSyxnQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNCO0FBQUEsUUFDdEIsdUJBQUMsVUFBSyxXQUFVLFlBQVkxRixvQkFBVXVELE1BQU0sS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFdBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUQsQ0FBQ0ksZUFDQSx1QkFBQyxPQUFFLFdBQVUsY0FBYSx3REFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLFNBbEJ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFFQ2hDLFNBQVMsdUJBQUMsT0FBRSxXQUFVLGNBQWNBLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFFM0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFdBQVU7QUFBQSxRQUNWLFVBQVUsQ0FBQ2lDLGNBQWNHLFlBQVlpQztBQUFBQSxRQUNyQyxTQUFTLE1BQU1qQyxZQUFZa0MsT0FBTztBQUFBLFFBRWpDbEMsc0JBQVlpQyxZQUFZLGlCQUFpQjtBQUFBO0FBQUEsTUFONUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0E7QUFBQSxPQTVHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkdBO0FBRUo7QUFBQ2hGLEdBOU9lSCxjQUFZO0FBQUEsVUFDTnJCLGdCQUNHSSxjQVFGTCxVQWdCT0QsYUFnQlJBLFdBQVc7QUFBQTtBQUFBLEtBMUNqQnVCO0FBQVksSUFBQThGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiZ2V0T3BlblNlc3Npb24iLCJvcGVuQ2FzaFNlc3Npb24iLCJyZWdpc3RlclNhbGUiLCJ1c2VBdXRoU3RvcmUiLCJBcGlFcnJvciIsIkRFRkFVTFRfQ0FTSF9SRUdJU1RFUl9JRCIsIlBheW1lbnRNZXRob2QiLCJmb3JtYXRCUkwiLCJwYXltZW50TWV0aG9kTGFiZWwiLCJuZWVkc1JlY2VpcHQiLCJtZXRob2RJZCIsIkNhcnRhb0NyZWRpdG8iLCJDYXJ0YW9EZWJpdG8iLCJQaXgiLCJwYXJzZUFtb3VudCIsInJhdyIsInZhbHVlIiwiTnVtYmVyIiwicmVwbGFjZSIsImlzRmluaXRlIiwiUGF5bWVudFBhbmVsIiwib3JkZXIiLCJvblBhaWQiLCJfcyIsInF1ZXJ5Q2xpZW50IiwiZW1wbG95ZWVJZCIsInJvd3MiLCJzZXRSb3dzIiwicGF5bWVudE1ldGhvZElkIiwiRGluaGVpcm8iLCJhbW91bnQiLCJhdXRob3JpemF0aW9uQ29kZSIsIm9wZW5pbmdBbW91bnQiLCJzZXRPcGVuaW5nQW1vdW50IiwiZXJyb3IiLCJzZXRFcnJvciIsInNwbGl0Q291bnQiLCJzZXRTcGxpdENvdW50Iiwic2Vzc2lvblF1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicmV0cnkiLCJub1Nlc3Npb24iLCJpc0Vycm9yIiwic3RhdHVzIiwibm9DYXNoQWNjZXNzIiwib3BlblNlc3Npb25NdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJvblN1Y2Nlc3MiLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uRXJyb3IiLCJlIiwibWVzc2FnZSIsImFtb3VudER1ZSIsInRvdGFsQW1vdW50IiwicGFydGlhbFBhaWRBbW91bnQiLCJ0b3RhbFBhaWQiLCJyZWR1Y2UiLCJzdW0iLCJyb3ciLCJjYXNoUGFpZCIsImZpbHRlciIsImNoYW5nZSIsIk1hdGgiLCJtYXgiLCJ0b0ZpeGVkIiwiY2hhbmdlVmFsaWQiLCJjYW5Db25maXJtIiwiZXZlcnkiLCJyIiwicGF5TXV0YXRpb24iLCJjaGFuZ2VMZWZ0IiwicGF5bWVudHMiLCJtYXAiLCJjaGFuZ2VBbW91bnQiLCJtaW4iLCJ0cmltIiwiaWQiLCJkYXRhIiwic2V0Um93IiwiaW5kZXgiLCJwYXRjaCIsImN1cnJlbnQiLCJpIiwiYXBwbHlTcGxpdCIsInBlb3BsZSIsInRydW5jIiwidG90YWxDZW50cyIsInJvdW5kIiwiYmFzZUNlbnRzIiwiZmxvb3IiLCJyZW1haW5kZXIiLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJfIiwiaXNMb2FkaW5nIiwiY29sb3IiLCJwYWRkaW5nIiwiZGlzcGxheSIsImdhcCIsImZvbnRTaXplIiwidGFyZ2V0IiwiaXNQZW5kaW5nIiwibXV0YXRlIiwibWFyZ2luIiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImFsaWduSXRlbXMiLCJmbGV4IiwibWluV2lkdGgiLCJPYmplY3QiLCJlbnRyaWVzIiwibGFiZWwiLCJqdXN0aWZ5Q29udGVudCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBheW1lbnRQYW5lbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgZ2V0T3BlblNlc3Npb24sIG9wZW5DYXNoU2Vzc2lvbiB9IGZyb20gXCIuLi9jYXNoL2FwaVwiO1xyXG5pbXBvcnQgeyByZWdpc3RlclNhbGUsIHR5cGUgU2FsZVBheW1lbnRJbnB1dCB9IGZyb20gXCIuLi9iaWxsaW5nL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7XHJcbiAgREVGQVVMVF9DQVNIX1JFR0lTVEVSX0lELFxyXG4gIFBheW1lbnRNZXRob2QsXHJcbiAgZm9ybWF0QlJMLFxyXG4gIHBheW1lbnRNZXRob2RMYWJlbCxcclxufSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB0eXBlIHsgT3JkZXJSZXNwb25zZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuXHJcbmludGVyZmFjZSBQYXltZW50Um93IHtcclxuICBwYXltZW50TWV0aG9kSWQ6IG51bWJlcjtcclxuICBhbW91bnQ6IHN0cmluZztcclxuICBhdXRob3JpemF0aW9uQ29kZTogc3RyaW5nO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gIG9yZGVyOiBPcmRlclJlc3BvbnNlO1xyXG4gIG9uUGFpZDogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuY29uc3QgbmVlZHNSZWNlaXB0ID0gKG1ldGhvZElkOiBudW1iZXIpOiBib29sZWFuID0+XHJcbiAgbWV0aG9kSWQgPT09IFBheW1lbnRNZXRob2QuQ2FydGFvQ3JlZGl0byB8fFxyXG4gIG1ldGhvZElkID09PSBQYXltZW50TWV0aG9kLkNhcnRhb0RlYml0byB8fFxyXG4gIG1ldGhvZElkID09PSBQYXltZW50TWV0aG9kLlBpeDtcclxuXHJcbmNvbnN0IHBhcnNlQW1vdW50ID0gKHJhdzogc3RyaW5nKTogbnVtYmVyID0+IHtcclxuICBjb25zdCB2YWx1ZSA9IE51bWJlcihyYXcucmVwbGFjZShcIixcIiwgXCIuXCIpKTtcclxuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHZhbHVlKSA/IHZhbHVlIDogMDtcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBQYXltZW50UGFuZWwoeyBvcmRlciwgb25QYWlkIH06IFByb3BzKSB7XHJcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgZW1wbG95ZWVJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgY29uc3QgW3Jvd3MsIHNldFJvd3NdID0gdXNlU3RhdGU8UGF5bWVudFJvd1tdPihbXHJcbiAgICB7IHBheW1lbnRNZXRob2RJZDogUGF5bWVudE1ldGhvZC5EaW5oZWlybywgYW1vdW50OiBcIlwiLCBhdXRob3JpemF0aW9uQ29kZTogXCJcIiB9LFxyXG4gIF0pO1xyXG4gIGNvbnN0IFtvcGVuaW5nQW1vdW50LCBzZXRPcGVuaW5nQW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW3NwbGl0Q291bnQsIHNldFNwbGl0Q291bnRdID0gdXNlU3RhdGUoXCIyXCIpO1xyXG5cclxuICBjb25zdCBzZXNzaW9uUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiY2FzaFwiLCBcIm9wZW5cIiwgREVGQVVMVF9DQVNIX1JFR0lTVEVSX0lEXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldE9wZW5TZXNzaW9uKERFRkFVTFRfQ0FTSF9SRUdJU1RFUl9JRCksXHJcbiAgICByZXRyeTogZmFsc2UsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IG5vU2Vzc2lvbiA9XHJcbiAgICBzZXNzaW9uUXVlcnkuaXNFcnJvciAmJlxyXG4gICAgc2Vzc2lvblF1ZXJ5LmVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiZcclxuICAgIHNlc3Npb25RdWVyeS5lcnJvci5zdGF0dXMgPT09IDQwNDtcclxuXHJcbiAgY29uc3Qgbm9DYXNoQWNjZXNzID1cclxuICAgIHNlc3Npb25RdWVyeS5pc0Vycm9yICYmXHJcbiAgICBzZXNzaW9uUXVlcnkuZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvciAmJlxyXG4gICAgc2Vzc2lvblF1ZXJ5LmVycm9yLnN0YXR1cyA9PT0gNDAzO1xyXG5cclxuICBjb25zdCBvcGVuU2Vzc2lvbk11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgb3BlbkNhc2hTZXNzaW9uKERFRkFVTFRfQ0FTSF9SRUdJU1RFUl9JRCwgZW1wbG95ZWVJZCA/PyAxLCBwYXJzZUFtb3VudChvcGVuaW5nQW1vdW50KSksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiY2FzaFwiXSB9KSxcclxuICAgIG9uRXJyb3I6IChlKSA9PiBzZXRFcnJvcihlIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkZhbGhhIGFvIGFicmlyIG8gY2FpeGEuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBhbW91bnREdWUgPSBvcmRlci50b3RhbEFtb3VudCAtIG9yZGVyLnBhcnRpYWxQYWlkQW1vdW50O1xyXG4gIGNvbnN0IHRvdGFsUGFpZCA9IHJvd3MucmVkdWNlKChzdW0sIHJvdykgPT4gc3VtICsgcGFyc2VBbW91bnQocm93LmFtb3VudCksIDApO1xyXG4gIGNvbnN0IGNhc2hQYWlkID0gcm93c1xyXG4gICAgLmZpbHRlcigocm93KSA9PiByb3cucGF5bWVudE1ldGhvZElkID09PSBQYXltZW50TWV0aG9kLkRpbmhlaXJvKVxyXG4gICAgLnJlZHVjZSgoc3VtLCByb3cpID0+IHN1bSArIHBhcnNlQW1vdW50KHJvdy5hbW91bnQpLCAwKTtcclxuICBjb25zdCBjaGFuZ2UgPSBNYXRoLm1heCgwLCBOdW1iZXIoKHRvdGFsUGFpZCAtIGFtb3VudER1ZSkudG9GaXhlZCgyKSkpO1xyXG4gIGNvbnN0IGNoYW5nZVZhbGlkID0gY2hhbmdlID09PSAwIHx8IGNhc2hQYWlkID49IGNoYW5nZTtcclxuICBjb25zdCBjYW5Db25maXJtID0gdG90YWxQYWlkID49IGFtb3VudER1ZSAmJiBjaGFuZ2VWYWxpZCAmJiByb3dzLmV2ZXJ5KChyKSA9PiBwYXJzZUFtb3VudChyLmFtb3VudCkgPiAwKTtcclxuXHJcbiAgY29uc3QgcGF5TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiB7XHJcbiAgICAgIC8vIFRyb2NvIMOpIGFiYXRpZG8gZG8gKHByaW1laXJvKSBwYWdhbWVudG8gZW0gZGluaGVpcm8uXHJcbiAgICAgIGxldCBjaGFuZ2VMZWZ0ID0gY2hhbmdlO1xyXG4gICAgICBjb25zdCBwYXltZW50czogU2FsZVBheW1lbnRJbnB1dFtdID0gcm93cy5tYXAoKHJvdykgPT4ge1xyXG4gICAgICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlQW1vdW50KHJvdy5hbW91bnQpO1xyXG4gICAgICAgIGxldCBjaGFuZ2VBbW91bnQ6IG51bWJlciB8IG51bGwgPSBudWxsO1xyXG4gICAgICAgIGlmIChyb3cucGF5bWVudE1ldGhvZElkID09PSBQYXltZW50TWV0aG9kLkRpbmhlaXJvICYmIGNoYW5nZUxlZnQgPiAwKSB7XHJcbiAgICAgICAgICBjaGFuZ2VBbW91bnQgPSBNYXRoLm1pbihjaGFuZ2VMZWZ0LCBhbW91bnQpO1xyXG4gICAgICAgICAgY2hhbmdlTGVmdCA9IE51bWJlcigoY2hhbmdlTGVmdCAtIGNoYW5nZUFtb3VudCkudG9GaXhlZCgyKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBwYXltZW50TWV0aG9kSWQ6IHJvdy5wYXltZW50TWV0aG9kSWQsXHJcbiAgICAgICAgICBhbW91bnQsXHJcbiAgICAgICAgICBjaGFuZ2VBbW91bnQsXHJcbiAgICAgICAgICBhdXRob3JpemF0aW9uQ29kZTogcm93LmF1dGhvcml6YXRpb25Db2RlLnRyaW0oKSA9PT0gXCJcIiA/IG51bGwgOiByb3cuYXV0aG9yaXphdGlvbkNvZGUudHJpbSgpLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gcmVnaXN0ZXJTYWxlKG9yZGVyLmlkLCBzZXNzaW9uUXVlcnkuZGF0YSEuaWQsIGVtcGxveWVlSWQgPz8gMSwgcGF5bWVudHMpO1xyXG4gICAgfSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgb25QYWlkKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKGUpID0+IHNldEVycm9yKGUgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGUubWVzc2FnZSA6IFwiRmFsaGEgYW8gcmVnaXN0cmFyIHBhZ2FtZW50by5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHNldFJvdyA9IChpbmRleDogbnVtYmVyLCBwYXRjaDogUGFydGlhbDxQYXltZW50Um93PikgPT5cclxuICAgIHNldFJvd3MoKGN1cnJlbnQpID0+IGN1cnJlbnQubWFwKChyb3csIGkpID0+IChpID09PSBpbmRleCA/IHsgLi4ucm93LCAuLi5wYXRjaCB9IDogcm93KSkpO1xyXG5cclxuICBjb25zdCBhcHBseVNwbGl0ID0gKCkgPT4ge1xyXG4gICAgY29uc3QgcGVvcGxlID0gTWF0aC5tYXgoMSwgTWF0aC50cnVuYyhOdW1iZXIoc3BsaXRDb3VudCkgfHwgMSkpO1xyXG4gICAgY29uc3QgdG90YWxDZW50cyA9IE1hdGgucm91bmQoYW1vdW50RHVlICogMTAwKTtcclxuICAgIGNvbnN0IGJhc2VDZW50cyA9IE1hdGguZmxvb3IodG90YWxDZW50cyAvIHBlb3BsZSk7XHJcbiAgICBjb25zdCByZW1haW5kZXIgPSB0b3RhbENlbnRzICUgcGVvcGxlO1xyXG5cclxuICAgIHNldFJvd3MoXHJcbiAgICAgIEFycmF5LmZyb20oeyBsZW5ndGg6IHBlb3BsZSB9LCAoXywgaSkgPT4gKHtcclxuICAgICAgICBwYXltZW50TWV0aG9kSWQ6IFBheW1lbnRNZXRob2QuRGluaGVpcm8sXHJcbiAgICAgICAgYW1vdW50OiAoKGJhc2VDZW50cyArIChpIDwgcmVtYWluZGVyID8gMSA6IDApKSAvIDEwMCkudG9GaXhlZCgyKS5yZXBsYWNlKFwiLlwiLCBcIixcIiksXHJcbiAgICAgICAgYXV0aG9yaXphdGlvbkNvZGU6IFwiXCIsXHJcbiAgICAgIH0pKSxcclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgaWYgKHNlc3Npb25RdWVyeS5pc0xvYWRpbmcpXHJcbiAgICByZXR1cm4gPHAgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT5WZXJpZmljYW5kbyBjYWl4YeKApjwvcD47XHJcblxyXG4gIGlmIChub0Nhc2hBY2Nlc3MpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE4LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA2IH19PlxyXG4gICAgICAgIDxzdHJvbmc+Q29udGEgZmVjaGFkYSDigJQgYWd1YXJkYW5kbyBwYWdhbWVudG8uPC9zdHJvbmc+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+XHJcbiAgICAgICAgICBWb2PDqiBuw6NvIHRlbSBhY2Vzc28gYW8gY2FpeGEuIENoYW1lIG8gb3BlcmFkb3IgZGUgY2FpeGEgb3UgbyBnZXJlbnRlIHBhcmFcclxuICAgICAgICAgIHJlZ2lzdHJhciBvIHBhZ2FtZW50by5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuXHJcbiAgaWYgKG5vU2Vzc2lvbilcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0XCIgc3R5bGU9e3sgcGFkZGluZzogMTgsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgIDxzdHJvbmc+TyBjYWl4YSBlc3TDoSBmZWNoYWRvLjwvc3Ryb25nPlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgQWJyYSB1bWEgc2Vzc8OjbyBkZSBjYWl4YSBwYXJhIHJlY2ViZXIgcGFnYW1lbnRvcy5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkZ1bmRvIGRlIHRyb2NvIChSJClcIlxyXG4gICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICB2YWx1ZT17b3BlbmluZ0Ftb3VudH1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0T3BlbmluZ0Ftb3VudChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgLz5cclxuICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIlxyXG4gICAgICAgICAgZGlzYWJsZWQ9e29wZW5TZXNzaW9uTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlblNlc3Npb25NdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBBYnJpciBjYWl4YVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyIH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5cclxuICAgICAgICBQYWdhbWVudG8g4oCUIHtmb3JtYXRCUkwoYW1vdW50RHVlKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHtvcmRlci5wYXJ0aWFsUGFpZEFtb3VudCA+IDAgJiYgKFxyXG4gICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgbWFyZ2luOiAwIH19PlxyXG4gICAgICAgICAgQ29udGEgZGUge2Zvcm1hdEJSTChvcmRlci50b3RhbEFtb3VudCl9IGNvbXtcIiBcIn1cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLW9rKVwiIH19Pntmb3JtYXRCUkwob3JkZXIucGFydGlhbFBhaWRBbW91bnQpfSBqw6EgcGFnb3MgcGFyY2lhbG1lbnRlPC9zcGFuPi5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDgsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwiMWZyIGF1dG9cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGl2aWRpciBlbnRyZSBxdWFudGFzIHBlc3NvYXM/XCJcclxuICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxyXG4gICAgICAgICAgdmFsdWU9e3NwbGl0Q291bnR9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNwbGl0Q291bnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17YXBwbHlTcGxpdH0+XHJcbiAgICAgICAgICBEaXZpZGlyIGNvbnRhXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge3Jvd3MubWFwKChyb3csIGluZGV4KSA9PiAoXHJcbiAgICAgICAgPGRpdiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAyLCBtaW5XaWR0aDogMTcwIH19XHJcbiAgICAgICAgICAgIHZhbHVlPXtyb3cucGF5bWVudE1ldGhvZElkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJvdyhpbmRleCwgeyBwYXltZW50TWV0aG9kSWQ6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhwYXltZW50TWV0aG9kTGFiZWwpLm1hcCgoW2lkLCBsYWJlbF0pID0+IChcclxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17aWR9IHZhbHVlPXtpZH0+XHJcbiAgICAgICAgICAgICAgICB7bGFiZWx9XHJcbiAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDExMCB9fVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlZhbG9yXCJcclxuICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtyb3cuYW1vdW50fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJvdyhpbmRleCwgeyBhbW91bnQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdCBidG4taWNvblwiXHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJSZW1vdmVyIGZvcm1hIGRlIHBhZ2FtZW50b1wiXHJcbiAgICAgICAgICAgIHRpdGxlPVwiUmVtb3ZlciBmb3JtYSBkZSBwYWdhbWVudG9cIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17cm93cy5sZW5ndGggPT09IDF9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJvd3MoKGN1cnJlbnQpID0+IGN1cnJlbnQuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleCkpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICDinJVcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAge25lZWRzUmVjZWlwdChyb3cucGF5bWVudE1ldGhvZElkKSAmJiAoXHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGZsZXg6IFwiMSAxIDEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ29tcHJvdmFudGUgLyBhdXRvcml6YcOnw6NvIChleC46IEFVVC0xMjM0NTYpXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17cm93LmF1dGhvcml6YXRpb25Db2RlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Um93KGluZGV4LCB7IGF1dGhvcml6YXRpb25Db2RlOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkpfVxyXG5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiXHJcbiAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgIHNldFJvd3MoKGN1cnJlbnQpID0+IFtcclxuICAgICAgICAgICAgLi4uY3VycmVudCxcclxuICAgICAgICAgICAgeyBwYXltZW50TWV0aG9kSWQ6IFBheW1lbnRNZXRob2QuQ2FydGFvQ3JlZGl0bywgYW1vdW50OiBcIlwiLCBhdXRob3JpemF0aW9uQ29kZTogXCJcIiB9LFxyXG4gICAgICAgICAgXSlcclxuICAgICAgICB9XHJcbiAgICAgID5cclxuICAgICAgICArIEFkaWNpb25hciBmb3JtYSBkZSBwYWdhbWVudG9cclxuICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiIHN0eWxlPXt7IHBhZGRpbmc6IFwiMTJweCAxNnB4XCIsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiIH19PlxyXG4gICAgICAgICAgPHNwYW4+UGFnbzwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+e2Zvcm1hdEJSTCh0b3RhbFBhaWQpfTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+XHJcbiAgICAgICAgICA8c3Bhbj5SZXN0YW50ZTwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+XHJcbiAgICAgICAgICAgIHtmb3JtYXRCUkwoTWF0aC5tYXgoMCwgYW1vdW50RHVlIC0gdG90YWxQYWlkKSl9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge2NoYW5nZSA+IDAgJiYgKFxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBjb2xvcjogXCJ2YXIoLS1hbWJlcilcIiB9fT5cclxuICAgICAgICAgICAgPHNwYW4+VHJvY28gKGRpbmhlaXJvKTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIj57Zm9ybWF0QlJMKGNoYW5nZSl9PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7IWNoYW5nZVZhbGlkICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj5PIHRyb2NvIGV4Y2VkZSBvIHZhbG9yIHBhZ28gZW0gZGluaGVpcm8uPC9wPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuXHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgZGlzYWJsZWQ9eyFjYW5Db25maXJtIHx8IHBheU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBwYXlNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgPlxyXG4gICAgICAgIHtwYXlNdXRhdGlvbi5pc1BlbmRpbmcgPyBcIlJlZ2lzdHJhbmRv4oCmXCIgOiBcIkNvbmZpcm1hciBwYWdhbWVudG9cIn1cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9vcmRlcnMvUGF5bWVudFBhbmVsLnRzeCJ9