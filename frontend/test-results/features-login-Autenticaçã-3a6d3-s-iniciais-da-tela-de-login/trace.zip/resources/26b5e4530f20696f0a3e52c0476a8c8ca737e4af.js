import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/ComplementSelectorModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Modal } from "/src/ui/Modal.tsx";
import { Button } from "/src/ui/Button.tsx";
import { formatBRL } from "/src/lib/types.ts";
export function ComplementSelectorModal({
  productName,
  groups,
  onCancel,
  onConfirm,
  confirmLabel = "Adicionar",
  submitting = false
}) {
  _s();
  const [selected, setSelected] = useState({});
  const toggle = (group, complementId) => {
    setSelected((current) => {
      const chosen = current[group.id] ?? [];
      const isSingle = group.maxSelection <= 1;
      if (chosen.includes(complementId)) {
        return { ...current, [group.id]: chosen.filter((id) => id !== complementId) };
      }
      if (isSingle) return { ...current, [group.id]: [complementId] };
      if (chosen.length >= group.maxSelection) return current;
      return { ...current, [group.id]: [...chosen, complementId] };
    });
  };
  const countFor = (group) => (selected[group.id] ?? []).length;
  const groupSatisfied = (group) => {
    const count = countFor(group);
    return count >= group.minSelection && count <= group.maxSelection;
  };
  const allSatisfied = groups.every(groupSatisfied);
  const handleConfirm = () => {
    const selections = groups.flatMap(
      (group) => (selected[group.id] ?? []).map((complementId) => ({ complementGroupId: group.id, complementId }))
    );
    onConfirm(selections);
  };
  return /* @__PURE__ */ jsxDEV(Modal, { title: `Complementos — ${productName}`, onClose: onCancel, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 18 }, children: [
    groups.map((group) => {
      const chosen = selected[group.id] ?? [];
      const isSingle = group.maxSelection <= 1;
      const satisfied = groupSatisfied(group);
      const activeComplements = group.complements.filter((c) => c.isActive);
      return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "baseline" }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: group.name }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
            lineNumber: 85,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: satisfied ? "var(--ink-faint)" : "var(--danger)" }, children: group.minSelection === 0 ? `opcional · até ${group.maxSelection}` : group.minSelection === group.maxSelection ? `escolha ${group.minSelection}` : `escolha de ${group.minSelection} a ${group.maxSelection}` }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
            lineNumber: 86,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
          lineNumber: 84,
          columnNumber: 15
        }, this),
        activeComplements.length === 0 && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "Nenhuma opção ativa neste grupo." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
          lineNumber: 96,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 6 }, children: activeComplements.map((c) => {
          const isChosen = chosen.includes(c.id);
          return /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "ui-row",
              style: {
                justifyContent: "space-between",
                padding: "8px 10px",
                borderRadius: 8,
                border: `1px solid ${isChosen ? "var(--amber)" : "var(--line)"}`,
                cursor: "pointer"
              },
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "ui-row", style: { gap: 8 }, children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: isSingle ? "radio" : "checkbox",
                      name: `complement-group-${group.id}`,
                      checked: isChosen,
                      onChange: () => toggle(group, c.id)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
                      lineNumber: 117,
                      columnNumber: 25
                    },
                    this
                  ),
                  c.complementItemName
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
                  lineNumber: 116,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--ink-faint)" }, children: c.extraPrice > 0 ? `+ ${formatBRL(c.extraPrice)}` : "sem custo" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
                  lineNumber: 125,
                  columnNumber: 23
                }, this)
              ]
            },
            c.id,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
              lineNumber: 105,
              columnNumber: 21
            },
            this
          );
        }) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
          lineNumber: 101,
          columnNumber: 15
        }, this)
      ] }, group.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
        lineNumber: 83,
        columnNumber: 13
      }, this);
    }),
    /* @__PURE__ */ jsxDEV(Button, { variant: "primary", block: true, loading: submitting, disabled: !allSatisfied, onClick: handleConfirm, children: confirmLabel }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
      lineNumber: 136,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
    lineNumber: 75,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx",
    lineNumber: 74,
    columnNumber: 5
  }, this);
}
_s(ComplementSelectorModal, "Gk1ihxo6C0QmBTOHyMJ50k0sYrc=");
_c = ComplementSelectorModal;
var _c;
$RefreshReg$(_c, "ComplementSelectorModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/ComplementSelectorModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUVnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqRWYsU0FBU0EsZ0JBQWdCO0FBQzFCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxpQkFBaUI7QUFZbkIsZ0JBQVNDLHdCQUF3QjtBQUFBLEVBQ3RDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxlQUFlO0FBQUEsRUFDZkMsYUFBYTtBQUNSLEdBQUc7QUFBQUMsS0FBQTtBQUNSLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJYixTQUFtQyxDQUFDLENBQUM7QUFFckUsUUFBTWMsU0FBU0EsQ0FBQ0MsT0FBZ0NDLGlCQUF5QjtBQUN2RUgsZ0JBQVksQ0FBQ0ksWUFBWTtBQUN2QixZQUFNQyxTQUFTRCxRQUFRRixNQUFNSSxFQUFFLEtBQUs7QUFDcEMsWUFBTUMsV0FBV0wsTUFBTU0sZ0JBQWdCO0FBRXZDLFVBQUlILE9BQU9JLFNBQVNOLFlBQVksR0FBRztBQUNqQyxlQUFPLEVBQUUsR0FBR0MsU0FBUyxDQUFDRixNQUFNSSxFQUFFLEdBQUdELE9BQU9LLE9BQU8sQ0FBQ0osT0FBT0EsT0FBT0gsWUFBWSxFQUFFO0FBQUEsTUFDOUU7QUFDQSxVQUFJSSxTQUFVLFFBQU8sRUFBRSxHQUFHSCxTQUFTLENBQUNGLE1BQU1JLEVBQUUsR0FBRyxDQUFDSCxZQUFZLEVBQUU7QUFDOUQsVUFBSUUsT0FBT00sVUFBVVQsTUFBTU0sYUFBYyxRQUFPSjtBQUNoRCxhQUFPLEVBQUUsR0FBR0EsU0FBUyxDQUFDRixNQUFNSSxFQUFFLEdBQUcsQ0FBQyxHQUFHRCxRQUFRRixZQUFZLEVBQUU7QUFBQSxJQUM3RCxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1TLFdBQVdBLENBQUNWLFdBQW9DSCxTQUFTRyxNQUFNSSxFQUFFLEtBQUssSUFBSUs7QUFDaEYsUUFBTUUsaUJBQWlCQSxDQUFDWCxVQUFtQztBQUN6RCxVQUFNWSxRQUFRRixTQUFTVixLQUFLO0FBQzVCLFdBQU9ZLFNBQVNaLE1BQU1hLGdCQUFnQkQsU0FBU1osTUFBTU07QUFBQUEsRUFDdkQ7QUFDQSxRQUFNUSxlQUFldkIsT0FBT3dCLE1BQU1KLGNBQWM7QUFFaEQsUUFBTUssZ0JBQWdCQSxNQUFNO0FBQzFCLFVBQU1DLGFBQTZDMUIsT0FBTzJCO0FBQUFBLE1BQVEsQ0FBQ2xCLFdBQ2hFSCxTQUFTRyxNQUFNSSxFQUFFLEtBQUssSUFBSWUsSUFBSSxDQUFDbEIsa0JBQWtCLEVBQUVtQixtQkFBbUJwQixNQUFNSSxJQUFJSCxhQUFhLEVBQUU7QUFBQSxJQUNsRztBQUNBUixjQUFVd0IsVUFBVTtBQUFBLEVBQ3RCO0FBRUEsU0FDRSx1QkFBQyxTQUFNLE9BQU8sa0JBQWtCM0IsV0FBVyxJQUFJLFNBQVNFLFVBQ3RELGlDQUFDLFNBQUksT0FBTyxFQUFFNkIsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDcEMvQjtBQUFBQSxXQUFPNEIsSUFBSSxDQUFDbkIsVUFBVTtBQUNyQixZQUFNRyxTQUFTTixTQUFTRyxNQUFNSSxFQUFFLEtBQUs7QUFDckMsWUFBTUMsV0FBV0wsTUFBTU0sZ0JBQWdCO0FBQ3ZDLFlBQU1pQixZQUFZWixlQUFlWCxLQUFLO0FBQ3RDLFlBQU13QixvQkFBb0J4QixNQUFNeUIsWUFBWWpCLE9BQU8sQ0FBQ2tCLE1BQU1BLEVBQUVDLFFBQVE7QUFFcEUsYUFDRSx1QkFBQyxTQUFtQixPQUFPLEVBQUVOLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ25EO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVELFNBQVMsUUFBUU8sZ0JBQWdCLGlCQUFpQkMsWUFBWSxXQUFXLEdBQ3JGO0FBQUEsaUNBQUMsVUFBSyxPQUFPLEVBQUVDLFlBQVksSUFBSSxHQUFJOUIsZ0JBQU0rQixRQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QztBQUFBLFVBQzlDLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxVQUFVLFVBQVVDLE9BQU9WLFlBQVkscUJBQXFCLGdCQUFnQixHQUN4RnZCLGdCQUFNYSxpQkFBaUIsSUFDcEIsa0JBQWtCYixNQUFNTSxZQUFZLEtBQ3BDTixNQUFNYSxpQkFBaUJiLE1BQU1NLGVBQzNCLFdBQVdOLE1BQU1hLFlBQVksS0FDN0IsY0FBY2IsTUFBTWEsWUFBWSxNQUFNYixNQUFNTSxZQUFZLE1BTGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxhQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUNrQixrQkFBa0JmLFdBQVcsS0FDNUIsdUJBQUMsVUFBSyxPQUFPLEVBQUV3QixPQUFPLG9CQUFvQkQsVUFBVSxVQUFVLEdBQUcsZ0RBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxPQUFPLEVBQUVYLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ25DRSw0QkFBa0JMLElBQUksQ0FBQ08sTUFBTTtBQUM1QixnQkFBTVEsV0FBVy9CLE9BQU9JLFNBQVNtQixFQUFFdEIsRUFBRTtBQUNyQyxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVTtBQUFBLGNBQ1YsT0FBTztBQUFBLGdCQUNMd0IsZ0JBQWdCO0FBQUEsZ0JBQ2hCTyxTQUFTO0FBQUEsZ0JBQ1RDLGNBQWM7QUFBQSxnQkFDZEMsUUFBUSxhQUFhSCxXQUFXLGlCQUFpQixhQUFhO0FBQUEsZ0JBQzlESSxRQUFRO0FBQUEsY0FDVjtBQUFBLGNBRUE7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsVUFBUyxPQUFPLEVBQUVoQixLQUFLLEVBQUUsR0FDdkM7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFNakIsV0FBVyxVQUFVO0FBQUEsc0JBQzNCLE1BQU0sb0JBQW9CTCxNQUFNSSxFQUFFO0FBQUEsc0JBQ2xDLFNBQVM4QjtBQUFBQSxzQkFDVCxVQUFVLE1BQU1uQyxPQUFPQyxPQUFPMEIsRUFBRXRCLEVBQUU7QUFBQTtBQUFBLG9CQUpwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSXNDO0FBQUEsa0JBRXJDc0IsRUFBRWE7QUFBQUEscUJBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSxZQUFXLE9BQU8sRUFBRU4sT0FBTyxtQkFBbUIsR0FDM0RQLFlBQUVjLGFBQWEsSUFBSSxLQUFLcEQsVUFBVXNDLEVBQUVjLFVBQVUsQ0FBQyxLQUFLLGVBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUFyQktkLEVBQUV0QjtBQUFBQSxZQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUF1QkE7QUFBQSxRQUVKLENBQUMsS0E3Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThCQTtBQUFBLFdBaERRSixNQUFNSSxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaURBO0FBQUEsSUFFSixDQUFDO0FBQUEsSUFFRCx1QkFBQyxVQUFPLFNBQVEsV0FBVSxPQUFLLE1BQUMsU0FBU1QsWUFBWSxVQUFVLENBQUNtQixjQUFjLFNBQVNFLGVBQ3BGdEIsMEJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0EvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdFQSxLQWpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0VBO0FBRUo7QUFBQ0UsR0EzR2VQLHlCQUF1QjtBQUFBLEtBQXZCQTtBQUF1QixJQUFBb0Q7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJNb2RhbCIsIkJ1dHRvbiIsImZvcm1hdEJSTCIsIkNvbXBsZW1lbnRTZWxlY3Rvck1vZGFsIiwicHJvZHVjdE5hbWUiLCJncm91cHMiLCJvbkNhbmNlbCIsIm9uQ29uZmlybSIsImNvbmZpcm1MYWJlbCIsInN1Ym1pdHRpbmciLCJfcyIsInNlbGVjdGVkIiwic2V0U2VsZWN0ZWQiLCJ0b2dnbGUiLCJncm91cCIsImNvbXBsZW1lbnRJZCIsImN1cnJlbnQiLCJjaG9zZW4iLCJpZCIsImlzU2luZ2xlIiwibWF4U2VsZWN0aW9uIiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJsZW5ndGgiLCJjb3VudEZvciIsImdyb3VwU2F0aXNmaWVkIiwiY291bnQiLCJtaW5TZWxlY3Rpb24iLCJhbGxTYXRpc2ZpZWQiLCJldmVyeSIsImhhbmRsZUNvbmZpcm0iLCJzZWxlY3Rpb25zIiwiZmxhdE1hcCIsIm1hcCIsImNvbXBsZW1lbnRHcm91cElkIiwiZGlzcGxheSIsImdhcCIsInNhdGlzZmllZCIsImFjdGl2ZUNvbXBsZW1lbnRzIiwiY29tcGxlbWVudHMiLCJjIiwiaXNBY3RpdmUiLCJqdXN0aWZ5Q29udGVudCIsImFsaWduSXRlbXMiLCJmb250V2VpZ2h0IiwibmFtZSIsImZvbnRTaXplIiwiY29sb3IiLCJpc0Nob3NlbiIsInBhZGRpbmciLCJib3JkZXJSYWRpdXMiLCJib3JkZXIiLCJjdXJzb3IiLCJjb21wbGVtZW50SXRlbU5hbWUiLCJleHRyYVByaWNlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29tcGxlbWVudFNlbGVjdG9yTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IE1vZGFsIH0gZnJvbSBcIi4uLy4uL3VpL01vZGFsXCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCIuLi8uLi91aS9CdXR0b25cIjtcclxuaW1wb3J0IHsgZm9ybWF0QlJMIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IENvbXBsZW1lbnRHcm91cFJlc3BvbnNlLCBPcmRlckl0ZW1Db21wbGVtZW50U2VsZWN0aW9uIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHtcclxuICBwcm9kdWN0TmFtZTogc3RyaW5nO1xyXG4gIGdyb3VwczogQ29tcGxlbWVudEdyb3VwUmVzcG9uc2VbXTtcclxuICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcclxuICBvbkNvbmZpcm06IChzZWxlY3Rpb25zOiBPcmRlckl0ZW1Db21wbGVtZW50U2VsZWN0aW9uW10pID0+IHZvaWQ7XHJcbiAgY29uZmlybUxhYmVsPzogc3RyaW5nO1xyXG4gIHN1Ym1pdHRpbmc/OiBib29sZWFuO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ29tcGxlbWVudFNlbGVjdG9yTW9kYWwoe1xyXG4gIHByb2R1Y3ROYW1lLFxyXG4gIGdyb3VwcyxcclxuICBvbkNhbmNlbCxcclxuICBvbkNvbmZpcm0sXHJcbiAgY29uZmlybUxhYmVsID0gXCJBZGljaW9uYXJcIixcclxuICBzdWJtaXR0aW5nID0gZmFsc2UsXHJcbn06IFByb3BzKSB7XHJcbiAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxSZWNvcmQ8bnVtYmVyLCBudW1iZXJbXT4+KHt9KTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlID0gKGdyb3VwOiBDb21wbGVtZW50R3JvdXBSZXNwb25zZSwgY29tcGxlbWVudElkOiBudW1iZXIpID0+IHtcclxuICAgIHNldFNlbGVjdGVkKChjdXJyZW50KSA9PiB7XHJcbiAgICAgIGNvbnN0IGNob3NlbiA9IGN1cnJlbnRbZ3JvdXAuaWRdID8/IFtdO1xyXG4gICAgICBjb25zdCBpc1NpbmdsZSA9IGdyb3VwLm1heFNlbGVjdGlvbiA8PSAxO1xyXG5cclxuICAgICAgaWYgKGNob3Nlbi5pbmNsdWRlcyhjb21wbGVtZW50SWQpKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgLi4uY3VycmVudCwgW2dyb3VwLmlkXTogY2hvc2VuLmZpbHRlcigoaWQpID0+IGlkICE9PSBjb21wbGVtZW50SWQpIH07XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGlzU2luZ2xlKSByZXR1cm4geyAuLi5jdXJyZW50LCBbZ3JvdXAuaWRdOiBbY29tcGxlbWVudElkXSB9O1xyXG4gICAgICBpZiAoY2hvc2VuLmxlbmd0aCA+PSBncm91cC5tYXhTZWxlY3Rpb24pIHJldHVybiBjdXJyZW50OyAvLyBqw6EgYXRpbmdpdSBvIG3DoXhpbW8gZG8gZ3J1cG9cclxuICAgICAgcmV0dXJuIHsgLi4uY3VycmVudCwgW2dyb3VwLmlkXTogWy4uLmNob3NlbiwgY29tcGxlbWVudElkXSB9O1xyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY291bnRGb3IgPSAoZ3JvdXA6IENvbXBsZW1lbnRHcm91cFJlc3BvbnNlKSA9PiAoc2VsZWN0ZWRbZ3JvdXAuaWRdID8/IFtdKS5sZW5ndGg7XHJcbiAgY29uc3QgZ3JvdXBTYXRpc2ZpZWQgPSAoZ3JvdXA6IENvbXBsZW1lbnRHcm91cFJlc3BvbnNlKSA9PiB7XHJcbiAgICBjb25zdCBjb3VudCA9IGNvdW50Rm9yKGdyb3VwKTtcclxuICAgIHJldHVybiBjb3VudCA+PSBncm91cC5taW5TZWxlY3Rpb24gJiYgY291bnQgPD0gZ3JvdXAubWF4U2VsZWN0aW9uO1xyXG4gIH07XHJcbiAgY29uc3QgYWxsU2F0aXNmaWVkID0gZ3JvdXBzLmV2ZXJ5KGdyb3VwU2F0aXNmaWVkKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29uZmlybSA9ICgpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGlvbnM6IE9yZGVySXRlbUNvbXBsZW1lbnRTZWxlY3Rpb25bXSA9IGdyb3Vwcy5mbGF0TWFwKChncm91cCkgPT5cclxuICAgICAgKHNlbGVjdGVkW2dyb3VwLmlkXSA/PyBbXSkubWFwKChjb21wbGVtZW50SWQpID0+ICh7IGNvbXBsZW1lbnRHcm91cElkOiBncm91cC5pZCwgY29tcGxlbWVudElkIH0pKSxcclxuICAgICk7XHJcbiAgICBvbkNvbmZpcm0oc2VsZWN0aW9ucyk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxNb2RhbCB0aXRsZT17YENvbXBsZW1lbnRvcyDigJQgJHtwcm9kdWN0TmFtZX1gfSBvbkNsb3NlPXtvbkNhbmNlbH0+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTggfX0+XHJcbiAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBjaG9zZW4gPSBzZWxlY3RlZFtncm91cC5pZF0gPz8gW107XHJcbiAgICAgICAgICBjb25zdCBpc1NpbmdsZSA9IGdyb3VwLm1heFNlbGVjdGlvbiA8PSAxO1xyXG4gICAgICAgICAgY29uc3Qgc2F0aXNmaWVkID0gZ3JvdXBTYXRpc2ZpZWQoZ3JvdXApO1xyXG4gICAgICAgICAgY29uc3QgYWN0aXZlQ29tcGxlbWVudHMgPSBncm91cC5jb21wbGVtZW50cy5maWx0ZXIoKGMpID0+IGMuaXNBY3RpdmUpO1xyXG5cclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxkaXYga2V5PXtncm91cC5pZH0gc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiYmFzZWxpbmVcIiB9fT5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCB9fT57Z3JvdXAubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IHNhdGlzZmllZCA/IFwidmFyKC0taW5rLWZhaW50KVwiIDogXCJ2YXIoLS1kYW5nZXIpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIHtncm91cC5taW5TZWxlY3Rpb24gPT09IDBcclxuICAgICAgICAgICAgICAgICAgICA/IGBvcGNpb25hbCDCtyBhdMOpICR7Z3JvdXAubWF4U2VsZWN0aW9ufWBcclxuICAgICAgICAgICAgICAgICAgICA6IGdyb3VwLm1pblNlbGVjdGlvbiA9PT0gZ3JvdXAubWF4U2VsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IGBlc2NvbGhhICR7Z3JvdXAubWluU2VsZWN0aW9ufWBcclxuICAgICAgICAgICAgICAgICAgICAgIDogYGVzY29saGEgZGUgJHtncm91cC5taW5TZWxlY3Rpb259IGEgJHtncm91cC5tYXhTZWxlY3Rpb259YH1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge2FjdGl2ZUNvbXBsZW1lbnRzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgTmVuaHVtYSBvcMOnw6NvIGF0aXZhIG5lc3RlIGdydXBvLlxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAgICAgIHthY3RpdmVDb21wbGVtZW50cy5tYXAoKGMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNDaG9zZW4gPSBjaG9zZW4uaW5jbHVkZXMoYy5pZCk7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2MuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1aS1yb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjhweCAxMHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7aXNDaG9zZW4gPyBcInZhcigtLWFtYmVyKVwiIDogXCJ2YXIoLS1saW5lKVwifWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT17aXNTaW5nbGUgPyBcInJhZGlvXCIgOiBcImNoZWNrYm94XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17YGNvbXBsZW1lbnQtZ3JvdXAtJHtncm91cC5pZH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2lzQ2hvc2VufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB0b2dnbGUoZ3JvdXAsIGMuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Yy5jb21wbGVtZW50SXRlbU5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2MuZXh0cmFQcmljZSA+IDAgPyBgKyAke2Zvcm1hdEJSTChjLmV4dHJhUHJpY2UpfWAgOiBcInNlbSBjdXN0b1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0pfVxyXG5cclxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgYmxvY2sgbG9hZGluZz17c3VibWl0dGluZ30gZGlzYWJsZWQ9eyFhbGxTYXRpc2ZpZWR9IG9uQ2xpY2s9e2hhbmRsZUNvbmZpcm19PlxyXG4gICAgICAgICAge2NvbmZpcm1MYWJlbH1cclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L01vZGFsPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL29yZGVycy9Db21wbGVtZW50U2VsZWN0b3JNb2RhbC50c3gifQ==