import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Tabs.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Tabs.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function Tabs({ tabs, activeTab, onTabChange, children }) {
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 16 }, children: [
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          display: "flex",
          gap: 0,
          borderBottom: "1px solid var(--border)",
          overflowX: "auto"
        },
        role: "tablist",
        children: tabs.map(
          (tab) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              role: "tab",
              "aria-selected": activeTab === tab.id,
              "aria-controls": `panel-${tab.id}`,
              disabled: tab.disabled,
              onClick: () => !tab.disabled && onTabChange(tab.id),
              style: {
                padding: "12px 16px",
                fontSize: "0.95rem",
                fontWeight: activeTab === tab.id ? 600 : 400,
                color: activeTab === tab.id ? "var(--ink)" : "var(--ink-faint)",
                background: "transparent",
                border: "none",
                borderBottom: activeTab === tab.id ? "2px solid var(--accent)" : "none",
                cursor: tab.disabled ? "not-allowed" : "pointer",
                transition: "color 0.2s, border-color 0.2s",
                opacity: tab.disabled ? 0.5 : 1,
                whiteSpace: "nowrap",
                display: "flex",
                gap: 8,
                alignItems: "center"
              },
              children: [
                tab.label,
                tab.badge && /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    style: {
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      minWidth: 20,
                      height: 20,
                      borderRadius: 10,
                      background: activeTab === tab.id ? "var(--accent)" : "var(--surface-2)",
                      color: activeTab === tab.id ? "white" : "var(--ink)",
                      fontSize: "0.75rem",
                      fontWeight: 600
                    },
                    children: tab.badge
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Tabs.tsx",
                    lineNumber: 74,
                    columnNumber: 11
                  },
                  this
                )
              ]
            },
            tab.id,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Tabs.tsx",
              lineNumber: 47,
              columnNumber: 9
            },
            this
          )
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Tabs.tsx",
        lineNumber: 37,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        id: `panel-${activeTab}`,
        role: "tabpanel",
        "aria-labelledby": activeTab,
        children
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Tabs.tsx",
        lineNumber: 95,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Tabs.tsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
}
_c = Tabs;
var _c;
$RefreshReg$(_c, "Tabs");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Tabs.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/Tabs.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RjOzs7Ozs7Ozs7Ozs7Ozs7O0FBeENQLGdCQUFTQSxLQUFLLEVBQUVDLE1BQU1DLFdBQVdDLGFBQWFDLFNBQW9CLEdBQUc7QUFDMUUsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDckM7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFVBQ0xELFNBQVM7QUFBQSxVQUNUQyxLQUFLO0FBQUEsVUFDTEMsY0FBYztBQUFBLFVBQ2RDLFdBQVc7QUFBQSxRQUNiO0FBQUEsUUFDQSxNQUFLO0FBQUEsUUFFSlAsZUFBS1E7QUFBQUEsVUFBSSxDQUFDQyxRQUNUO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxpQkFBZVIsY0FBY1EsSUFBSUM7QUFBQUEsY0FDakMsaUJBQWUsU0FBU0QsSUFBSUMsRUFBRTtBQUFBLGNBQzlCLFVBQVVELElBQUlFO0FBQUFBLGNBQ2QsU0FBUyxNQUFNLENBQUNGLElBQUlFLFlBQVlULFlBQVlPLElBQUlDLEVBQUU7QUFBQSxjQUNsRCxPQUFPO0FBQUEsZ0JBQ0xFLFNBQVM7QUFBQSxnQkFDVEMsVUFBVTtBQUFBLGdCQUNWQyxZQUFZYixjQUFjUSxJQUFJQyxLQUFLLE1BQU07QUFBQSxnQkFDekNLLE9BQU9kLGNBQWNRLElBQUlDLEtBQUssZUFBZTtBQUFBLGdCQUM3Q00sWUFBWTtBQUFBLGdCQUNaQyxRQUFRO0FBQUEsZ0JBQ1JYLGNBQWNMLGNBQWNRLElBQUlDLEtBQUssNEJBQTRCO0FBQUEsZ0JBQ2pFUSxRQUFRVCxJQUFJRSxXQUFXLGdCQUFnQjtBQUFBLGdCQUN2Q1EsWUFBWTtBQUFBLGdCQUNaQyxTQUFTWCxJQUFJRSxXQUFXLE1BQU07QUFBQSxnQkFDOUJVLFlBQVk7QUFBQSxnQkFDWmpCLFNBQVM7QUFBQSxnQkFDVEMsS0FBSztBQUFBLGdCQUNMaUIsWUFBWTtBQUFBLGNBQ2Q7QUFBQSxjQUVDYjtBQUFBQSxvQkFBSWM7QUFBQUEsZ0JBQ0pkLElBQUllLFNBQ0g7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBTztBQUFBLHNCQUNMcEIsU0FBUztBQUFBLHNCQUNUa0IsWUFBWTtBQUFBLHNCQUNaRyxnQkFBZ0I7QUFBQSxzQkFDaEJDLFVBQVU7QUFBQSxzQkFDVkMsUUFBUTtBQUFBLHNCQUNSQyxjQUFjO0FBQUEsc0JBQ2RaLFlBQVlmLGNBQWNRLElBQUlDLEtBQUssa0JBQWtCO0FBQUEsc0JBQ3JESyxPQUFPZCxjQUFjUSxJQUFJQyxLQUFLLFVBQVU7QUFBQSxzQkFDeENHLFVBQVU7QUFBQSxzQkFDVkMsWUFBWTtBQUFBLG9CQUNkO0FBQUEsb0JBRUNMLGNBQUllO0FBQUFBO0FBQUFBLGtCQWRQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFlQTtBQUFBO0FBQUE7QUFBQSxZQXpDR2YsSUFBSUM7QUFBQUEsWUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBNENBO0FBQUEsUUFDRDtBQUFBO0FBQUEsTUF2REg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBd0RBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBSSxTQUFTVCxTQUFTO0FBQUEsUUFDdEIsTUFBSztBQUFBLFFBQ0wsbUJBQWlCQTtBQUFBQSxRQUVoQkU7QUFBQUE7QUFBQUEsTUFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNQTtBQUFBLE9BakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrRUE7QUFFSjtBQUFDMEIsS0F0RWU5QjtBQUFJLElBQUE4QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJUYWJzIiwidGFicyIsImFjdGl2ZVRhYiIsIm9uVGFiQ2hhbmdlIiwiY2hpbGRyZW4iLCJkaXNwbGF5IiwiZ2FwIiwiYm9yZGVyQm90dG9tIiwib3ZlcmZsb3dYIiwibWFwIiwidGFiIiwiaWQiLCJkaXNhYmxlZCIsInBhZGRpbmciLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJjb2xvciIsImJhY2tncm91bmQiLCJib3JkZXIiLCJjdXJzb3IiLCJ0cmFuc2l0aW9uIiwib3BhY2l0eSIsIndoaXRlU3BhY2UiLCJhbGlnbkl0ZW1zIiwibGFiZWwiLCJiYWRnZSIsImp1c3RpZnlDb250ZW50IiwibWluV2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYWJzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmludGVyZmFjZSBUYWJzUHJvcHMge1xyXG4gIHRhYnM6IEFycmF5PHtcclxuICAgIGlkOiBzdHJpbmc7XHJcbiAgICBsYWJlbDogc3RyaW5nO1xyXG4gICAgYmFkZ2U/OiBzdHJpbmcgfCBudW1iZXI7XHJcbiAgICBkaXNhYmxlZD86IGJvb2xlYW47XHJcbiAgfT47XHJcbiAgYWN0aXZlVGFiOiBzdHJpbmc7XHJcbiAgb25UYWJDaGFuZ2U6ICh0YWJJZDogc3RyaW5nKSA9PiB2b2lkO1xyXG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBUYWJzKHsgdGFicywgYWN0aXZlVGFiLCBvblRhYkNoYW5nZSwgY2hpbGRyZW4gfTogVGFic1Byb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTYgfX0+XHJcbiAgICAgIDxkaXZcclxuICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICBnYXA6IDAsXHJcbiAgICAgICAgICBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkIHZhcigtLWJvcmRlcilcIixcclxuICAgICAgICAgIG92ZXJmbG93WDogXCJhdXRvXCIsXHJcbiAgICAgICAgfX1cclxuICAgICAgICByb2xlPVwidGFibGlzdFwiXHJcbiAgICAgID5cclxuICAgICAgICB7dGFicy5tYXAoKHRhYikgPT4gKFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBrZXk9e3RhYi5pZH1cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIHJvbGU9XCJ0YWJcIlxyXG4gICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXthY3RpdmVUYWIgPT09IHRhYi5pZH1cclxuICAgICAgICAgICAgYXJpYS1jb250cm9scz17YHBhbmVsLSR7dGFiLmlkfWB9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXt0YWIuZGlzYWJsZWR9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+ICF0YWIuZGlzYWJsZWQgJiYgb25UYWJDaGFuZ2UodGFiLmlkKX1cclxuICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICBwYWRkaW5nOiBcIjEycHggMTZweFwiLFxyXG4gICAgICAgICAgICAgIGZvbnRTaXplOiBcIjAuOTVyZW1cIixcclxuICAgICAgICAgICAgICBmb250V2VpZ2h0OiBhY3RpdmVUYWIgPT09IHRhYi5pZCA/IDYwMCA6IDQwMCxcclxuICAgICAgICAgICAgICBjb2xvcjogYWN0aXZlVGFiID09PSB0YWIuaWQgPyBcInZhcigtLWluaylcIiA6IFwidmFyKC0taW5rLWZhaW50KVwiLFxyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwidHJhbnNwYXJlbnRcIixcclxuICAgICAgICAgICAgICBib3JkZXI6IFwibm9uZVwiLFxyXG4gICAgICAgICAgICAgIGJvcmRlckJvdHRvbTogYWN0aXZlVGFiID09PSB0YWIuaWQgPyBcIjJweCBzb2xpZCB2YXIoLS1hY2NlbnQpXCIgOiBcIm5vbmVcIixcclxuICAgICAgICAgICAgICBjdXJzb3I6IHRhYi5kaXNhYmxlZCA/IFwibm90LWFsbG93ZWRcIiA6IFwicG9pbnRlclwiLFxyXG4gICAgICAgICAgICAgIHRyYW5zaXRpb246IFwiY29sb3IgMC4ycywgYm9yZGVyLWNvbG9yIDAuMnNcIixcclxuICAgICAgICAgICAgICBvcGFjaXR5OiB0YWIuZGlzYWJsZWQgPyAwLjUgOiAxLFxyXG4gICAgICAgICAgICAgIHdoaXRlU3BhY2U6IFwibm93cmFwXCIsXHJcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAgZ2FwOiA4LFxyXG4gICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHt0YWIubGFiZWx9XHJcbiAgICAgICAgICAgIHt0YWIuYmFkZ2UgJiYgKFxyXG4gICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImlubGluZS1mbGV4XCIsXHJcbiAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgICBtaW5XaWR0aDogMjAsXHJcbiAgICAgICAgICAgICAgICAgIGhlaWdodDogMjAsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMTAsXHJcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGFjdGl2ZVRhYiA9PT0gdGFiLmlkID8gXCJ2YXIoLS1hY2NlbnQpXCIgOiBcInZhcigtLXN1cmZhY2UtMilcIixcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IGFjdGl2ZVRhYiA9PT0gdGFiLmlkID8gXCJ3aGl0ZVwiIDogXCJ2YXIoLS1pbmspXCIsXHJcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjAuNzVyZW1cIixcclxuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNjAwLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7dGFiLmJhZGdlfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXZcclxuICAgICAgICBpZD17YHBhbmVsLSR7YWN0aXZlVGFifWB9XHJcbiAgICAgICAgcm9sZT1cInRhYnBhbmVsXCJcclxuICAgICAgICBhcmlhLWxhYmVsbGVkYnk9e2FjdGl2ZVRhYn1cclxuICAgICAgPlxyXG4gICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1RhYnMudHN4In0=