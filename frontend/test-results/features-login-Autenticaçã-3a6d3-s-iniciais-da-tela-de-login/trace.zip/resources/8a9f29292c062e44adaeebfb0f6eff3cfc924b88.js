import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/printing/PrintingPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { useDialog } from "/src/ui/Dialog.tsx";
import {
  createPrinter,
  deactivatePrinter,
  getPrinters,
  getPrintSettings,
  setPrintSettings,
  testPrinter
} from "/src/features/printing/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { Overlay } from "/src/features/orders/Overlay.tsx";
const emptyForm = {
  name: "",
  connectionType: 1,
  printerName: "ELGIN i9(USB)",
  ipAddress: "",
  port: "9100",
  printsOrders: false,
  printsBills: false
};
export function PrintingPage() {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const { branchId } = useAuthStore();
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState(null);
  const [feedback, setFeedback] = useState(null);
  const settingsQuery = useQuery({
    queryKey: ["printing", "settings", branchId],
    queryFn: () => getPrintSettings(branchId)
  });
  const printersQuery = useQuery({
    queryKey: ["printing", "printers", branchId],
    queryFn: () => getPrinters(branchId)
  });
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["printing"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const settingsMutation = useMutation({
    mutationFn: (next) => setPrintSettings({ branchId, ...next }),
    onSuccess: () => {
      setError(null);
      refresh();
    },
    onError: onApiError
  });
  const createMutation = useMutation({
    mutationFn: () => createPrinter({
      branchId,
      name: form.name.trim(),
      connectionType: form.connectionType,
      printerName: form.connectionType === 1 ? form.printerName.trim() : null,
      ipAddress: form.connectionType === 2 ? form.ipAddress.trim() : null,
      port: form.connectionType === 2 ? Number(form.port) : null,
      printsOrders: form.printsOrders,
      printsBills: form.printsBills
    }),
    onSuccess: () => {
      setError(null);
      setCreating(false);
      setForm(emptyForm);
      refresh();
    },
    onError: onApiError
  });
  const removeMutation = useMutation({
    mutationFn: (id) => deactivatePrinter(id),
    onSuccess: refresh,
    onError: onApiError
  });
  const testMutation = useMutation({
    mutationFn: (id) => testPrinter(id),
    onSuccess: () => {
      setError(null);
      setFeedback("Cupom de teste enviado — confira a impressora.");
      setTimeout(() => setFeedback(null), 4e3);
    },
    onError: onApiError
  });
  const settings = settingsQuery.data;
  const Toggle = ({
    label,
    hint,
    value,
    onChange
  }) => /* @__PURE__ */ jsxDEV("label", { className: "ticket", style: { padding: 16, display: "flex", gap: 14, alignItems: "center", cursor: "pointer" }, children: [
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "checkbox",
        style: { width: 26, minHeight: 26 },
        checked: value,
        onChange: (e) => onChange(e.target.checked),
        disabled: settingsMutation.isPending
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 122,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("span", { style: { display: "grid", gap: 2 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: label }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 130,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.82rem", color: "var(--ink-faint)" }, children: hint }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 131,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
      lineNumber: 129,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
    lineNumber: 121,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 900, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 16 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Impressão" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 139,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 140,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-primary", onClick: () => {
        setError(null);
        setCreating(true);
      }, children: "+ Nova impressora" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 141,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
      lineNumber: 138,
      columnNumber: 7
    }, this),
    settingsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: settingsQuery.error, what: "as configurações" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
      lineNumber: 146,
      columnNumber: 33
    }, this),
    printersQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: printersQuery.error, what: "as impressoras" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
      lineNumber: 147,
      columnNumber: 33
    }, this),
    error && !creating && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
      lineNumber: 148,
      columnNumber: 30
    }, this),
    feedback && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ok)" }, children: feedback }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
      lineNumber: 149,
      columnNumber: 20
    }, this),
    settings && /* @__PURE__ */ jsxDEV("div", { className: "rise rise-1", style: { display: "grid", gap: 10, gridTemplateColumns: "1fr 1fr", marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV(
        Toggle,
        {
          label: "Imprimir pedidos",
          hint: "Cupom automático na cozinha/bar a cada lançamento",
          value: settings.printOrdersEnabled,
          onChange: (v) => settingsMutation.mutate({ printOrdersEnabled: v, printBillsEnabled: settings.printBillsEnabled })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 153,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Toggle,
        {
          label: "Imprimir contas",
          hint: "Habilita o 'Deseja imprimir?' no fechamento e o cupom de caixa",
          value: settings.printBillsEnabled,
          onChange: (v) => settingsMutation.mutate({ printOrdersEnabled: settings.printOrdersEnabled, printBillsEnabled: v })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 159,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
      lineNumber: 152,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ticket rise rise-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Impressoras" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 170,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 169,
        columnNumber: 9
      }, this),
      (printersQuery.data ?? []).map(
        (printer) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { flexWrap: "wrap", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: printer.name }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
              lineNumber: 175,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
              printer.connectionType === 1 ? `USB/Windows · driver "${printer.printerName}"` : `Rede · ${printer.ipAddress}:${printer.port}`,
              " · ",
              [printer.printsOrders ? "pedidos" : null, printer.printsBills ? "contas/fechamentos" : null].filter(Boolean).join(" + ")
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
              lineNumber: 176,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
            lineNumber: 174,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, marginLeft: "auto" }, children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "btn-ghost",
                style: { minHeight: 44, padding: "0 12px", fontSize: "0.85rem" },
                disabled: testMutation.isPending,
                onClick: () => testMutation.mutate(printer.id),
                children: "Testar"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
                lineNumber: 187,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "btn-danger",
                style: { minHeight: 44, padding: "0 12px", fontSize: "0.85rem" },
                onClick: async () => {
                  if (await dialog.confirm({
                    title: "Remover impressora",
                    message: `Remover a impressora "${printer.name}"?`,
                    confirmLabel: "Remover",
                    danger: true
                  }))
                    removeMutation.mutate(printer.id);
                },
                children: "Remover"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
                lineNumber: 196,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
            lineNumber: 186,
            columnNumber: 13
          }, this)
        ] }, printer.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 173,
          columnNumber: 9
        }, this)
      ),
      printersQuery.data?.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-faint)" }, children: "Nenhuma impressora cadastrada." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 218,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
      lineNumber: 168,
      columnNumber: 7
    }, this),
    creating && /* @__PURE__ */ jsxDEV(Overlay, { title: "Nova impressora", onClose: () => setCreating(false), children: [
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Nome (identificação)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 227,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("input", { placeholder: "ex.: Cozinha, Bar, Caixa", value: form.name, onChange: (e) => setForm({ ...form, name: e.target.value }) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 228,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 226,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Conexão" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 231,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: form.connectionType,
            onChange: (e) => setForm({ ...form, connectionType: Number(e.target.value) }),
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: 1, children: "USB — driver instalado no Windows" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
                lineNumber: 236,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: 2, children: "Rede — TCP (porta 9100)" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
                lineNumber: 237,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
            lineNumber: 232,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 230,
        columnNumber: 11
      }, this),
      form.connectionType === 1 ? /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Nome exato do driver (Configurações do Windows → Impressoras)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 242,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("input", { value: form.printerName, onChange: (e) => setForm({ ...form, printerName: e.target.value }) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 245,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 241,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8, gridTemplateColumns: "2fr 1fr" }, children: [
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Endereço IP" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
            lineNumber: 250,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { placeholder: "192.168.0.50", value: form.ipAddress, onChange: (e) => setForm({ ...form, ipAddress: e.target.value }) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
            lineNumber: 251,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 249,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 4 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Porta" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
            lineNumber: 254,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { inputMode: "numeric", value: form.port, onChange: (e) => setForm({ ...form, port: e.target.value }) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
            lineNumber: 255,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 253,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 248,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 6 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "O que esta impressora imprime?" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 260,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", gap: 10, alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              style: { width: 20, minHeight: 20 },
              checked: form.printsOrders,
              onChange: (e) => setForm({ ...form, printsOrders: e.target.checked })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
              lineNumber: 262,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { children: "Pedidos (cozinha/bar)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
            lineNumber: 264,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 261,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", gap: 10, alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              style: { width: 20, minHeight: 20 },
              checked: form.printsBills,
              onChange: (e) => setForm({ ...form, printsBills: e.target.checked })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
              lineNumber: 267,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { children: "Contas e fechamentos (caixa)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
            lineNumber: 269,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 266,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 259,
        columnNumber: 11
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
        lineNumber: 272,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          disabled: form.name.trim() === "" || !form.printsOrders && !form.printsBills || form.connectionType === 1 && form.printerName.trim() === "" || form.connectionType === 2 && (form.ipAddress.trim() === "" || form.port.trim() === "") || createMutation.isPending,
          onClick: () => createMutation.mutate(),
          children: createMutation.isPending ? "Salvando…" : "Salvar impressora"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
          lineNumber: 273,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
      lineNumber: 225,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx",
    lineNumber: 137,
    columnNumber: 5
  }, this);
}
_s(PrintingPage, "hoz03AriliRvCmpLt57nncYUCDc=", false, function() {
  return [useQueryClient, useDialog, useAuthStore, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation];
});
_c = PrintingPage;
var _c;
$RefreshReg$(_c, "PrintingPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/printing/PrintingPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0dNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRHTixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLGlCQUFpQjtBQUMxQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLFlBQVk7QUFBQSxFQUNoQkMsTUFBTTtBQUFBLEVBQ05DLGdCQUFnQjtBQUFBLEVBQ2hCQyxhQUFhO0FBQUEsRUFDYkMsV0FBVztBQUFBLEVBQ1hDLE1BQU07QUFBQSxFQUNOQyxjQUFjO0FBQUEsRUFDZEMsYUFBYTtBQUNmO0FBRU8sZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUM3QixRQUFNQyxjQUFjdEIsZUFBZTtBQUNuQyxRQUFNdUIsU0FBU3RCLFVBQVU7QUFDekIsUUFBTSxFQUFFdUIsU0FBUyxJQUFJaEIsYUFBYTtBQUNsQyxRQUFNLENBQUNpQixVQUFVQyxXQUFXLElBQUk3QixTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDOEIsTUFBTUMsT0FBTyxJQUFJL0IsU0FBU2UsU0FBUztBQUMxQyxRQUFNLENBQUNpQixPQUFPQyxRQUFRLElBQUlqQyxTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQ2tDLFVBQVVDLFdBQVcsSUFBSW5DLFNBQXdCLElBQUk7QUFFNUQsUUFBTW9DLGdCQUFnQmxDLFNBQVM7QUFBQSxJQUM3Qm1DLFVBQVUsQ0FBQyxZQUFZLFlBQVlWLFFBQVE7QUFBQSxJQUMzQ1csU0FBU0EsTUFBTTlCLGlCQUFpQm1CLFFBQVE7QUFBQSxFQUMxQyxDQUFDO0FBRUQsUUFBTVksZ0JBQWdCckMsU0FBUztBQUFBLElBQzdCbUMsVUFBVSxDQUFDLFlBQVksWUFBWVYsUUFBUTtBQUFBLElBQzNDVyxTQUFTQSxNQUFNL0IsWUFBWW9CLFFBQVE7QUFBQSxFQUNyQyxDQUFDO0FBRUQsUUFBTWEsVUFBVUEsTUFBTSxLQUFLZixZQUFZZ0Isa0JBQWtCLEVBQUVKLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztBQUNuRixRQUFNSyxhQUFhQSxDQUFDQyxNQUNsQlYsU0FBU1UsYUFBYS9CLFdBQVcrQixFQUFFQyxVQUFVLGtCQUFrQjtBQUVqRSxRQUFNQyxtQkFBbUI1QyxZQUFZO0FBQUEsSUFDbkM2QyxZQUFZQSxDQUFDQyxTQUNYdEMsaUJBQWlCLEVBQUVrQixVQUFVLEdBQUdvQixLQUFLLENBQUM7QUFBQSxJQUN4Q0MsV0FBV0EsTUFBTTtBQUNmZixlQUFTLElBQUk7QUFDYk8sY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBUyxTQUFTUDtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNUSxpQkFBaUJqRCxZQUFZO0FBQUEsSUFDakM2QyxZQUFZQSxNQUNWekMsY0FBYztBQUFBLE1BQ1pzQjtBQUFBQSxNQUNBWCxNQUFNYyxLQUFLZCxLQUFLbUMsS0FBSztBQUFBLE1BQ3JCbEMsZ0JBQWdCYSxLQUFLYjtBQUFBQSxNQUNyQkMsYUFBYVksS0FBS2IsbUJBQW1CLElBQUlhLEtBQUtaLFlBQVlpQyxLQUFLLElBQUk7QUFBQSxNQUNuRWhDLFdBQVdXLEtBQUtiLG1CQUFtQixJQUFJYSxLQUFLWCxVQUFVZ0MsS0FBSyxJQUFJO0FBQUEsTUFDL0QvQixNQUFNVSxLQUFLYixtQkFBbUIsSUFBSW1DLE9BQU90QixLQUFLVixJQUFJLElBQUk7QUFBQSxNQUN0REMsY0FBY1MsS0FBS1Q7QUFBQUEsTUFDbkJDLGFBQWFRLEtBQUtSO0FBQUFBLElBQ3BCLENBQUM7QUFBQSxJQUNIMEIsV0FBV0EsTUFBTTtBQUNmZixlQUFTLElBQUk7QUFDYkosa0JBQVksS0FBSztBQUNqQkUsY0FBUWhCLFNBQVM7QUFDakJ5QixjQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0FTLFNBQVNQO0FBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1XLGlCQUFpQnBELFlBQVk7QUFBQSxJQUNqQzZDLFlBQVlBLENBQUNRLE9BQWVoRCxrQkFBa0JnRCxFQUFFO0FBQUEsSUFDaEROLFdBQVdSO0FBQUFBLElBQ1hTLFNBQVNQO0FBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1hLGVBQWV0RCxZQUFZO0FBQUEsSUFDL0I2QyxZQUFZQSxDQUFDUSxPQUFlNUMsWUFBWTRDLEVBQUU7QUFBQSxJQUMxQ04sV0FBV0EsTUFBTTtBQUNmZixlQUFTLElBQUk7QUFDYkUsa0JBQVksZ0RBQWdEO0FBQzVEcUIsaUJBQVcsTUFBTXJCLFlBQVksSUFBSSxHQUFHLEdBQUk7QUFBQSxJQUMxQztBQUFBLElBQ0FjLFNBQVNQO0FBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1lLFdBQVdyQixjQUFjc0I7QUFFL0IsUUFBTUMsU0FBU0EsQ0FBQztBQUFBLElBQUVDO0FBQUFBLElBQU9DO0FBQUFBLElBQU1DO0FBQUFBLElBQU9DO0FBQUFBLEVBRXRDLE1BQ0UsdUJBQUMsV0FBTSxXQUFVLFVBQVMsT0FBTyxFQUFFQyxTQUFTLElBQUlDLFNBQVMsUUFBUUMsS0FBSyxJQUFJQyxZQUFZLFVBQVVDLFFBQVEsVUFBVSxHQUNoSDtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxPQUFPLEVBQUVDLE9BQU8sSUFBSUMsV0FBVyxHQUFHO0FBQUEsUUFDbEMsU0FBU1I7QUFBQUEsUUFDVCxVQUFVLENBQUNuQixNQUFNb0IsU0FBU3BCLEVBQUU0QixPQUFPQyxPQUFPO0FBQUEsUUFDMUMsVUFBVTNCLGlCQUFpQjRCO0FBQUFBO0FBQUFBLE1BTDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUt1QztBQUFBLElBRXZDLHVCQUFDLFVBQUssT0FBTyxFQUFFUixTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNyQztBQUFBLDZCQUFDLFlBQVFOLG1CQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsVUFBSyxPQUFPLEVBQUVjLFVBQVUsV0FBV0MsT0FBTyxtQkFBbUIsR0FBSWQsa0JBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUU7QUFBQSxTQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZQTtBQUdGLFNBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUVHLFNBQVMsSUFBSVksVUFBVSxLQUFLQyxRQUFRLFNBQVMsR0FDMUQ7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVaLFNBQVMsUUFBUUUsWUFBWSxZQUFZRCxLQUFLLElBQUlZLGNBQWMsR0FBRyxHQUNoRztBQUFBLDZCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUosVUFBVSxTQUFTLEdBQUcseUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUNoRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUssTUFBTSxFQUFFLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGVBQWMsU0FBUyxNQUFNO0FBQUU5QyxpQkFBUyxJQUFJO0FBQUdKLG9CQUFZLElBQUk7QUFBQSxNQUFHLEdBQUcsaUNBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQ08sY0FBYzRDLFdBQVcsdUJBQUMsY0FBVyxPQUFPNUMsY0FBY0osT0FBTyxNQUFLLHNCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStEO0FBQUEsSUFDeEZPLGNBQWN5QyxXQUFXLHVCQUFDLGNBQVcsT0FBT3pDLGNBQWNQLE9BQU8sTUFBSyxvQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RDtBQUFBLElBQ3RGQSxTQUFTLENBQUNKLFlBQVksdUJBQUMsT0FBRSxXQUFVLGNBQWNJLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDdkRFLFlBQVksdUJBQUMsT0FBRSxPQUFPLEVBQUV5QyxPQUFPLFlBQVksR0FBSXpDLHNCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDO0FBQUEsSUFFeER1QixZQUNDLHVCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU8sRUFBRVEsU0FBUyxRQUFRQyxLQUFLLElBQUllLHFCQUFxQixXQUFXSCxjQUFjLEdBQUcsR0FDL0c7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sTUFBSztBQUFBLFVBQ0wsT0FBT3JCLFNBQVN5QjtBQUFBQSxVQUNoQixVQUFVLENBQUNDLE1BQU10QyxpQkFBaUJ1QyxPQUFPLEVBQUVGLG9CQUFvQkMsR0FBR0UsbUJBQW1CNUIsU0FBUzRCLGtCQUFrQixDQUFDO0FBQUE7QUFBQSxRQUpuSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJcUg7QUFBQSxNQUVySDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sTUFBSztBQUFBLFVBQ0wsT0FBTzVCLFNBQVM0QjtBQUFBQSxVQUNoQixVQUFVLENBQUNGLE1BQU10QyxpQkFBaUJ1QyxPQUFPLEVBQUVGLG9CQUFvQnpCLFNBQVN5QixvQkFBb0JHLG1CQUFtQkYsRUFBRSxDQUFDO0FBQUE7QUFBQSxRQUpwSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJc0g7QUFBQSxTQVh4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUdGLHVCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUNiLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRVQsVUFBVSxTQUFTLEdBQUcsMkJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0UsS0FEdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsT0FDRW5DLGNBQWNtQixRQUFRLElBQUk0QjtBQUFBQSxRQUFJLENBQUNDLFlBQy9CLHVCQUFDLFNBQUksV0FBVSxjQUE4QixPQUFPLEVBQUVDLFVBQVUsUUFBUXRCLEtBQUssRUFBRSxHQUM3RTtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFRCxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLG1DQUFDLFVBQU1xQixrQkFBUXZFLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0I7QUFBQSxZQUNwQix1QkFBQyxVQUFLLE9BQU8sRUFBRTBELFVBQVUsVUFBVUMsT0FBTyxtQkFBbUIsR0FDMURZO0FBQUFBLHNCQUFRdEUsbUJBQW1CLElBQ3hCLHlCQUF5QnNFLFFBQVFyRSxXQUFXLE1BQzVDLFVBQVVxRSxRQUFRcEUsU0FBUyxJQUFJb0UsUUFBUW5FLElBQUk7QUFBQSxjQUM5QztBQUFBLGNBQ0EsQ0FBQ21FLFFBQVFsRSxlQUFlLFlBQVksTUFBTWtFLFFBQVFqRSxjQUFjLHVCQUF1QixJQUFJLEVBQ3pGbUUsT0FBT0MsT0FBTyxFQUNkQyxLQUFLLEtBQUs7QUFBQSxpQkFQZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRTFCLFNBQVMsUUFBUUMsS0FBSyxHQUFHMEIsWUFBWSxPQUFPLEdBQ3hEO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRXRCLFdBQVcsSUFBSU4sU0FBUyxVQUFVVSxVQUFVLFVBQVU7QUFBQSxnQkFDL0QsVUFBVW5CLGFBQWFrQjtBQUFBQSxnQkFDdkIsU0FBUyxNQUFNbEIsYUFBYTZCLE9BQU9HLFFBQVFqQyxFQUFFO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBTGpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFZ0IsV0FBVyxJQUFJTixTQUFTLFVBQVVVLFVBQVUsVUFBVTtBQUFBLGdCQUMvRCxTQUFTLFlBQVk7QUFDbkIsc0JBQ0UsTUFBTWhELE9BQU9tRSxRQUFRO0FBQUEsb0JBQ25CQyxPQUFPO0FBQUEsb0JBQ1BsRCxTQUFTLHlCQUF5QjJDLFFBQVF2RSxJQUFJO0FBQUEsb0JBQzlDK0UsY0FBYztBQUFBLG9CQUNkQyxRQUFRO0FBQUEsa0JBQ1YsQ0FBQztBQUVEM0MsbUNBQWUrQixPQUFPRyxRQUFRakMsRUFBRTtBQUFBLGdCQUNwQztBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlCQTtBQUFBLGVBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsYUF6QytCaUMsUUFBUWpDLElBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQ0E7QUFBQSxNQUNEO0FBQUEsTUFDQWYsY0FBY21CLE1BQU11QyxXQUFXLEtBQzlCLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRXRCLE9BQU8sbUJBQW1CLEdBQUcsOENBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBcERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzREE7QUFBQSxJQUVDL0MsWUFDQyx1QkFBQyxXQUFRLE9BQU0sbUJBQWtCLFNBQVMsTUFBTUMsWUFBWSxLQUFLLEdBQy9EO0FBQUEsNkJBQUMsV0FBTSxPQUFPLEVBQUVvQyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUN0QztBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFUyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsb0NBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUNuRix1QkFBQyxXQUFNLGFBQVksNEJBQTJCLE9BQU81QyxLQUFLZCxNQUFNLFVBQVUsQ0FBQzJCLE1BQU1aLFFBQVEsRUFBRSxHQUFHRCxNQUFNZCxNQUFNMkIsRUFBRTRCLE9BQU9ULE1BQU0sQ0FBQyxLQUExSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRIO0FBQUEsV0FGOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxXQUFNLE9BQU8sRUFBRUcsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDdEM7QUFBQSwrQkFBQyxVQUFLLE9BQU8sRUFBRVMsT0FBTyxrQkFBa0JELFVBQVUsVUFBVSxHQUFHLHVCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsUUFDdEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU81QyxLQUFLYjtBQUFBQSxZQUNaLFVBQVUsQ0FBQzBCLE1BQU1aLFFBQVEsRUFBRSxHQUFHRCxNQUFNYixnQkFBZ0JtQyxPQUFPVCxFQUFFNEIsT0FBT1QsS0FBSyxFQUFFLENBQUM7QUFBQSxZQUU1RTtBQUFBLHFDQUFDLFlBQU8sT0FBTyxHQUFHLGlEQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRDtBQUFBLGNBQ25ELHVCQUFDLFlBQU8sT0FBTyxHQUFHLHVDQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBO0FBQUE7QUFBQSxVQUwzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQ2hDLEtBQUtiLG1CQUFtQixJQUN2Qix1QkFBQyxXQUFNLE9BQU8sRUFBRWdELFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVTLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBRyw2RUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLE9BQU81QyxLQUFLWixhQUFhLFVBQVUsQ0FBQ3lCLE1BQU1aLFFBQVEsRUFBRSxHQUFHRCxNQUFNWixhQUFheUIsRUFBRTRCLE9BQU9ULE1BQU0sQ0FBQyxLQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1HO0FBQUEsV0FKckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVHLFNBQVMsUUFBUUMsS0FBSyxHQUFHZSxxQkFBcUIsVUFBVSxHQUNwRTtBQUFBLCtCQUFDLFdBQU0sT0FBTyxFQUFFaEIsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDdEM7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRVMsT0FBTyxrQkFBa0JELFVBQVUsVUFBVSxHQUFHLDJCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRTtBQUFBLFVBQzFFLHVCQUFDLFdBQU0sYUFBWSxnQkFBZSxPQUFPNUMsS0FBS1gsV0FBVyxVQUFVLENBQUN3QixNQUFNWixRQUFRLEVBQUUsR0FBR0QsTUFBTVgsV0FBV3dCLEVBQUU0QixPQUFPVCxNQUFNLENBQUMsS0FBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEg7QUFBQSxhQUY1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sT0FBTyxFQUFFRyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUN0QztBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFUyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcscUJBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDcEUsdUJBQUMsV0FBTSxXQUFVLFdBQVUsT0FBTzVDLEtBQUtWLE1BQU0sVUFBVSxDQUFDdUIsTUFBTVosUUFBUSxFQUFFLEdBQUdELE1BQU1WLE1BQU11QixFQUFFNEIsT0FBT1QsTUFBTSxDQUFDLEtBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlHO0FBQUEsYUFGM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVGLHVCQUFDLFNBQUksT0FBTyxFQUFFRyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFUyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsOENBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxRQUM3Rix1QkFBQyxXQUFNLE9BQU8sRUFBRVQsU0FBUyxRQUFRQyxLQUFLLElBQUlDLFlBQVksU0FBUyxHQUM3RDtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FBTSxNQUFLO0FBQUEsY0FBVyxPQUFPLEVBQUVFLE9BQU8sSUFBSUMsV0FBVyxHQUFHO0FBQUEsY0FBRyxTQUFTeEMsS0FBS1Q7QUFBQUEsY0FDeEUsVUFBVSxDQUFDc0IsTUFBTVosUUFBUSxFQUFFLEdBQUdELE1BQU1ULGNBQWNzQixFQUFFNEIsT0FBT0MsUUFBUSxDQUFDO0FBQUE7QUFBQSxZQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDd0U7QUFBQSxVQUN4RSx1QkFBQyxVQUFLLHFDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUEsYUFIN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLE9BQU8sRUFBRVAsU0FBUyxRQUFRQyxLQUFLLElBQUlDLFlBQVksU0FBUyxHQUM3RDtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FBTSxNQUFLO0FBQUEsY0FBVyxPQUFPLEVBQUVFLE9BQU8sSUFBSUMsV0FBVyxHQUFHO0FBQUEsY0FBRyxTQUFTeEMsS0FBS1I7QUFBQUEsY0FDeEUsVUFBVSxDQUFDcUIsTUFBTVosUUFBUSxFQUFFLEdBQUdELE1BQU1SLGFBQWFxQixFQUFFNEIsT0FBT0MsUUFBUSxDQUFDO0FBQUE7QUFBQSxZQURyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDdUU7QUFBQSxVQUN2RSx1QkFBQyxVQUFLLDRDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtDO0FBQUEsYUFIcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUNDeEMsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUMzQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsVUFDRUYsS0FBS2QsS0FBS21DLEtBQUssTUFBTSxNQUNwQixDQUFDckIsS0FBS1QsZ0JBQWdCLENBQUNTLEtBQUtSLGVBQzVCUSxLQUFLYixtQkFBbUIsS0FBS2EsS0FBS1osWUFBWWlDLEtBQUssTUFBTSxNQUN6RHJCLEtBQUtiLG1CQUFtQixNQUFNYSxLQUFLWCxVQUFVZ0MsS0FBSyxNQUFNLE1BQU1yQixLQUFLVixLQUFLK0IsS0FBSyxNQUFNLE9BQ3BGRCxlQUFldUI7QUFBQUEsVUFFakIsU0FBUyxNQUFNdkIsZUFBZWtDLE9BQU87QUFBQSxVQUVwQ2xDLHlCQUFldUIsWUFBWSxjQUFjO0FBQUE7QUFBQSxRQVo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFhQTtBQUFBLFNBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4REE7QUFBQSxPQXRKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0pBO0FBRUo7QUFBQ2pELEdBclBlRCxjQUFZO0FBQUEsVUFDTnBCLGdCQUNMQyxXQUNNTyxjQU1DVCxVQUtBQSxVQVNHRCxhQVVGQSxhQXFCQUEsYUFNRkEsV0FBVztBQUFBO0FBQUEsS0E1RGxCc0I7QUFBWSxJQUFBMkU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJ1c2VEaWFsb2ciLCJjcmVhdGVQcmludGVyIiwiZGVhY3RpdmF0ZVByaW50ZXIiLCJnZXRQcmludGVycyIsImdldFByaW50U2V0dGluZ3MiLCJzZXRQcmludFNldHRpbmdzIiwidGVzdFByaW50ZXIiLCJ1c2VBdXRoU3RvcmUiLCJBcGlFcnJvciIsIlF1ZXJ5RXJyb3IiLCJPdmVybGF5IiwiZW1wdHlGb3JtIiwibmFtZSIsImNvbm5lY3Rpb25UeXBlIiwicHJpbnRlck5hbWUiLCJpcEFkZHJlc3MiLCJwb3J0IiwicHJpbnRzT3JkZXJzIiwicHJpbnRzQmlsbHMiLCJQcmludGluZ1BhZ2UiLCJfcyIsInF1ZXJ5Q2xpZW50IiwiZGlhbG9nIiwiYnJhbmNoSWQiLCJjcmVhdGluZyIsInNldENyZWF0aW5nIiwiZm9ybSIsInNldEZvcm0iLCJlcnJvciIsInNldEVycm9yIiwiZmVlZGJhY2siLCJzZXRGZWVkYmFjayIsInNldHRpbmdzUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJwcmludGVyc1F1ZXJ5IiwicmVmcmVzaCIsImludmFsaWRhdGVRdWVyaWVzIiwib25BcGlFcnJvciIsImUiLCJtZXNzYWdlIiwic2V0dGluZ3NNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJuZXh0Iiwib25TdWNjZXNzIiwib25FcnJvciIsImNyZWF0ZU11dGF0aW9uIiwidHJpbSIsIk51bWJlciIsInJlbW92ZU11dGF0aW9uIiwiaWQiLCJ0ZXN0TXV0YXRpb24iLCJzZXRUaW1lb3V0Iiwic2V0dGluZ3MiLCJkYXRhIiwiVG9nZ2xlIiwibGFiZWwiLCJoaW50IiwidmFsdWUiLCJvbkNoYW5nZSIsInBhZGRpbmciLCJkaXNwbGF5IiwiZ2FwIiwiYWxpZ25JdGVtcyIsImN1cnNvciIsIndpZHRoIiwibWluSGVpZ2h0IiwidGFyZ2V0IiwiY2hlY2tlZCIsImlzUGVuZGluZyIsImZvbnRTaXplIiwiY29sb3IiLCJtYXhXaWR0aCIsIm1hcmdpbiIsIm1hcmdpbkJvdHRvbSIsImZsZXgiLCJpc0Vycm9yIiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsInByaW50T3JkZXJzRW5hYmxlZCIsInYiLCJtdXRhdGUiLCJwcmludEJpbGxzRW5hYmxlZCIsIm1hcCIsInByaW50ZXIiLCJmbGV4V3JhcCIsImZpbHRlciIsIkJvb2xlYW4iLCJqb2luIiwibWFyZ2luTGVmdCIsImNvbmZpcm0iLCJ0aXRsZSIsImNvbmZpcm1MYWJlbCIsImRhbmdlciIsImxlbmd0aCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByaW50aW5nUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgdXNlRGlhbG9nIH0gZnJvbSBcIi4uLy4uL3VpL0RpYWxvZ1wiO1xyXG5pbXBvcnQge1xyXG4gIGNyZWF0ZVByaW50ZXIsXHJcbiAgZGVhY3RpdmF0ZVByaW50ZXIsXHJcbiAgZ2V0UHJpbnRlcnMsXHJcbiAgZ2V0UHJpbnRTZXR0aW5ncyxcclxuICBzZXRQcmludFNldHRpbmdzLFxyXG4gIHRlc3RQcmludGVyLFxyXG59IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcbmltcG9ydCB7IE92ZXJsYXkgfSBmcm9tIFwiLi4vb3JkZXJzL092ZXJsYXlcIjtcclxuXHJcbmNvbnN0IGVtcHR5Rm9ybSA9IHtcclxuICBuYW1lOiBcIlwiLFxyXG4gIGNvbm5lY3Rpb25UeXBlOiAxLFxyXG4gIHByaW50ZXJOYW1lOiBcIkVMR0lOIGk5KFVTQilcIixcclxuICBpcEFkZHJlc3M6IFwiXCIsXHJcbiAgcG9ydDogXCI5MTAwXCIsXHJcbiAgcHJpbnRzT3JkZXJzOiBmYWxzZSxcclxuICBwcmludHNCaWxsczogZmFsc2UsXHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUHJpbnRpbmdQYWdlKCkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCBkaWFsb2cgPSB1c2VEaWFsb2coKTtcclxuICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbY3JlYXRpbmcsIHNldENyZWF0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZm9ybSwgc2V0Rm9ybV0gPSB1c2VTdGF0ZShlbXB0eUZvcm0pO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2ZlZWRiYWNrLCBzZXRGZWVkYmFja10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3Qgc2V0dGluZ3NRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJwcmludGluZ1wiLCBcInNldHRpbmdzXCIsIGJyYW5jaElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldFByaW50U2V0dGluZ3MoYnJhbmNoSWQpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBwcmludGVyc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcInByaW50aW5nXCIsIFwicHJpbnRlcnNcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0UHJpbnRlcnMoYnJhbmNoSWQpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByZWZyZXNoID0gKCkgPT4gdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJwcmludGluZ1wiXSB9KTtcclxuICBjb25zdCBvbkFwaUVycm9yID0gKGU6IHVua25vd24pID0+XHJcbiAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIk9wZXJhw6fDo28gZmFsaG91LlwiKTtcclxuXHJcbiAgY29uc3Qgc2V0dGluZ3NNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46IChuZXh0OiB7IHByaW50T3JkZXJzRW5hYmxlZDogYm9vbGVhbjsgcHJpbnRCaWxsc0VuYWJsZWQ6IGJvb2xlYW4gfSkgPT5cclxuICAgICAgc2V0UHJpbnRTZXR0aW5ncyh7IGJyYW5jaElkLCAuLi5uZXh0IH0pLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICByZWZyZXNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgY3JlYXRlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICBjcmVhdGVQcmludGVyKHtcclxuICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICBuYW1lOiBmb3JtLm5hbWUudHJpbSgpLFxyXG4gICAgICAgIGNvbm5lY3Rpb25UeXBlOiBmb3JtLmNvbm5lY3Rpb25UeXBlLFxyXG4gICAgICAgIHByaW50ZXJOYW1lOiBmb3JtLmNvbm5lY3Rpb25UeXBlID09PSAxID8gZm9ybS5wcmludGVyTmFtZS50cmltKCkgOiBudWxsLFxyXG4gICAgICAgIGlwQWRkcmVzczogZm9ybS5jb25uZWN0aW9uVHlwZSA9PT0gMiA/IGZvcm0uaXBBZGRyZXNzLnRyaW0oKSA6IG51bGwsXHJcbiAgICAgICAgcG9ydDogZm9ybS5jb25uZWN0aW9uVHlwZSA9PT0gMiA/IE51bWJlcihmb3JtLnBvcnQpIDogbnVsbCxcclxuICAgICAgICBwcmludHNPcmRlcnM6IGZvcm0ucHJpbnRzT3JkZXJzLFxyXG4gICAgICAgIHByaW50c0JpbGxzOiBmb3JtLnByaW50c0JpbGxzLFxyXG4gICAgICB9KSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgc2V0Q3JlYXRpbmcoZmFsc2UpO1xyXG4gICAgICBzZXRGb3JtKGVtcHR5Rm9ybSk7XHJcbiAgICAgIHJlZnJlc2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByZW1vdmVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46IChpZDogbnVtYmVyKSA9PiBkZWFjdGl2YXRlUHJpbnRlcihpZCksXHJcbiAgICBvblN1Y2Nlc3M6IHJlZnJlc2gsXHJcbiAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB0ZXN0TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoaWQ6IG51bWJlcikgPT4gdGVzdFByaW50ZXIoaWQpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICBzZXRGZWVkYmFjayhcIkN1cG9tIGRlIHRlc3RlIGVudmlhZG8g4oCUIGNvbmZpcmEgYSBpbXByZXNzb3JhLlwiKTtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRGZWVkYmFjayhudWxsKSwgNDAwMCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBzZXR0aW5nc1F1ZXJ5LmRhdGE7XHJcblxyXG4gIGNvbnN0IFRvZ2dsZSA9ICh7IGxhYmVsLCBoaW50LCB2YWx1ZSwgb25DaGFuZ2UgfToge1xyXG4gICAgbGFiZWw6IHN0cmluZzsgaGludDogc3RyaW5nOyB2YWx1ZTogYm9vbGVhbjsgb25DaGFuZ2U6ICh2OiBib29sZWFuKSA9PiB2b2lkO1xyXG4gIH0pID0+IChcclxuICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0aWNrZXRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNiwgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTQsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGN1cnNvcjogXCJwb2ludGVyXCIgfX0+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDI2LCBtaW5IZWlnaHQ6IDI2IH19XHJcbiAgICAgICAgY2hlY2tlZD17dmFsdWV9XHJcbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShlLnRhcmdldC5jaGVja2VkKX1cclxuICAgICAgICBkaXNhYmxlZD17c2V0dGluZ3NNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxzcGFuIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDIgfX0+XHJcbiAgICAgICAgPHN0cm9uZz57bGFiZWx9PC9zdHJvbmc+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44MnJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+e2hpbnR9PC9zcGFuPlxyXG4gICAgICA8L3NwYW4+XHJcbiAgICA8L2xhYmVsPlxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDkwMCwgbWFyZ2luOiBcIjAgYXV0b1wiIH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2VcIiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJiYXNlbGluZVwiLCBnYXA6IDE0LCBtYXJnaW5Cb3R0b206IDE2IH19PlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS43cmVtXCIgfX0+SW1wcmVzc8OjbzwvaDI+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSB9fSAvPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgb25DbGljaz17KCkgPT4geyBzZXRFcnJvcihudWxsKTsgc2V0Q3JlYXRpbmcodHJ1ZSk7IH19PlxyXG4gICAgICAgICAgKyBOb3ZhIGltcHJlc3NvcmFcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7c2V0dGluZ3NRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtzZXR0aW5nc1F1ZXJ5LmVycm9yfSB3aGF0PVwiYXMgY29uZmlndXJhw6fDtWVzXCIgLz59XHJcbiAgICAgIHtwcmludGVyc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e3ByaW50ZXJzUXVlcnkuZXJyb3J9IHdoYXQ9XCJhcyBpbXByZXNzb3Jhc1wiIC8+fVxyXG4gICAgICB7ZXJyb3IgJiYgIWNyZWF0aW5nICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuICAgICAge2ZlZWRiYWNrICYmIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLW9rKVwiIH19PntmZWVkYmFja308L3A+fVxyXG5cclxuICAgICAge3NldHRpbmdzICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2UgcmlzZS0xXCIgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwiMWZyIDFmclwiLCBtYXJnaW5Cb3R0b206IDE4IH19PlxyXG4gICAgICAgICAgPFRvZ2dsZVxyXG4gICAgICAgICAgICBsYWJlbD1cIkltcHJpbWlyIHBlZGlkb3NcIlxyXG4gICAgICAgICAgICBoaW50PVwiQ3Vwb20gYXV0b23DoXRpY28gbmEgY296aW5oYS9iYXIgYSBjYWRhIGxhbsOnYW1lbnRvXCJcclxuICAgICAgICAgICAgdmFsdWU9e3NldHRpbmdzLnByaW50T3JkZXJzRW5hYmxlZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyh2KSA9PiBzZXR0aW5nc011dGF0aW9uLm11dGF0ZSh7IHByaW50T3JkZXJzRW5hYmxlZDogdiwgcHJpbnRCaWxsc0VuYWJsZWQ6IHNldHRpbmdzLnByaW50QmlsbHNFbmFibGVkIH0pfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxUb2dnbGVcclxuICAgICAgICAgICAgbGFiZWw9XCJJbXByaW1pciBjb250YXNcIlxyXG4gICAgICAgICAgICBoaW50PVwiSGFiaWxpdGEgbyAnRGVzZWphIGltcHJpbWlyPycgbm8gZmVjaGFtZW50byBlIG8gY3Vwb20gZGUgY2FpeGFcIlxyXG4gICAgICAgICAgICB2YWx1ZT17c2V0dGluZ3MucHJpbnRCaWxsc0VuYWJsZWR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0dGluZ3NNdXRhdGlvbi5tdXRhdGUoeyBwcmludE9yZGVyc0VuYWJsZWQ6IHNldHRpbmdzLnByaW50T3JkZXJzRW5hYmxlZCwgcHJpbnRCaWxsc0VuYWJsZWQ6IHYgfSl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1oZWFkXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+SW1wcmVzc29yYXM8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgeyhwcmludGVyc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgocHJpbnRlcikgPT4gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIga2V5PXtwcmludGVyLmlkfSBzdHlsZT17eyBmbGV4V3JhcDogXCJ3cmFwXCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgIDxzcGFuPntwcmludGVyLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICB7cHJpbnRlci5jb25uZWN0aW9uVHlwZSA9PT0gMVxyXG4gICAgICAgICAgICAgICAgICA/IGBVU0IvV2luZG93cyDCtyBkcml2ZXIgXCIke3ByaW50ZXIucHJpbnRlck5hbWV9XCJgXHJcbiAgICAgICAgICAgICAgICAgIDogYFJlZGUgwrcgJHtwcmludGVyLmlwQWRkcmVzc306JHtwcmludGVyLnBvcnR9YH1cclxuICAgICAgICAgICAgICAgIHtcIiDCtyBcIn1cclxuICAgICAgICAgICAgICAgIHtbcHJpbnRlci5wcmludHNPcmRlcnMgPyBcInBlZGlkb3NcIiA6IG51bGwsIHByaW50ZXIucHJpbnRzQmlsbHMgPyBcImNvbnRhcy9mZWNoYW1lbnRvc1wiIDogbnVsbF1cclxuICAgICAgICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKVxyXG4gICAgICAgICAgICAgICAgICAuam9pbihcIiArIFwiKX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDgsIG1hcmdpbkxlZnQ6IFwiYXV0b1wiIH19PlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1pbkhlaWdodDogNDQsIHBhZGRpbmc6IFwiMCAxMnB4XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Rlc3RNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0ZXN0TXV0YXRpb24ubXV0YXRlKHByaW50ZXIuaWQpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFRlc3RhclxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTJweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlJlbW92ZXIgaW1wcmVzc29yYVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYFJlbW92ZXIgYSBpbXByZXNzb3JhIFwiJHtwcmludGVyLm5hbWV9XCI/YCxcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJSZW1vdmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBkYW5nZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgIHJlbW92ZU11dGF0aW9uLm11dGF0ZShwcmludGVyLmlkKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgUmVtb3ZlclxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICAgIHtwcmludGVyc1F1ZXJ5LmRhdGE/Lmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgIE5lbmh1bWEgaW1wcmVzc29yYSBjYWRhc3RyYWRhLlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7Y3JlYXRpbmcgJiYgKFxyXG4gICAgICAgIDxPdmVybGF5IHRpdGxlPVwiTm92YSBpbXByZXNzb3JhXCIgb25DbG9zZT17KCkgPT4gc2V0Q3JlYXRpbmcoZmFsc2UpfT5cclxuICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+Tm9tZSAoaWRlbnRpZmljYcOnw6NvKTwvc3Bhbj5cclxuICAgICAgICAgICAgPGlucHV0IHBsYWNlaG9sZGVyPVwiZXguOiBDb3ppbmhhLCBCYXIsIENhaXhhXCIgdmFsdWU9e2Zvcm0ubmFtZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9IC8+XHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5Db25leMOjbzwvc3Bhbj5cclxuICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmNvbm5lY3Rpb25UeXBlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGNvbm5lY3Rpb25UeXBlOiBOdW1iZXIoZS50YXJnZXQudmFsdWUpIH0pfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17MX0+VVNCIOKAlCBkcml2ZXIgaW5zdGFsYWRvIG5vIFdpbmRvd3M8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXsyfT5SZWRlIOKAlCBUQ1AgKHBvcnRhIDkxMDApPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIHtmb3JtLmNvbm5lY3Rpb25UeXBlID09PSAxID8gKFxyXG4gICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICBOb21lIGV4YXRvIGRvIGRyaXZlciAoQ29uZmlndXJhw6fDtWVzIGRvIFdpbmRvd3Mg4oaSIEltcHJlc3NvcmFzKVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8aW5wdXQgdmFsdWU9e2Zvcm0ucHJpbnRlck5hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHByaW50ZXJOYW1lOiBlLnRhcmdldC52YWx1ZSB9KX0gLz5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCwgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCIyZnIgMWZyXCIgfX0+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+RW5kZXJlw6dvIElQPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0IHBsYWNlaG9sZGVyPVwiMTkyLjE2OC4wLjUwXCIgdmFsdWU9e2Zvcm0uaXBBZGRyZXNzfSBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBpcEFkZHJlc3M6IGUudGFyZ2V0LnZhbHVlIH0pfSAvPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+UG9ydGE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgaW5wdXRNb2RlPVwibnVtZXJpY1wiIHZhbHVlPXtmb3JtLnBvcnR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHBvcnQ6IGUudGFyZ2V0LnZhbHVlIH0pfSAvPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19Pk8gcXVlIGVzdGEgaW1wcmVzc29yYSBpbXByaW1lPzwvc3Bhbj5cclxuICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEwLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBzdHlsZT17eyB3aWR0aDogMjAsIG1pbkhlaWdodDogMjAgfX0gY2hlY2tlZD17Zm9ybS5wcmludHNPcmRlcnN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBwcmludHNPcmRlcnM6IGUudGFyZ2V0LmNoZWNrZWQgfSl9IC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+UGVkaWRvcyAoY296aW5oYS9iYXIpPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTAsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIHN0eWxlPXt7IHdpZHRoOiAyMCwgbWluSGVpZ2h0OiAyMCB9fSBjaGVja2VkPXtmb3JtLnByaW50c0JpbGxzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgcHJpbnRzQmlsbHM6IGUudGFyZ2V0LmNoZWNrZWQgfSl9IC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+Q29udGFzIGUgZmVjaGFtZW50b3MgKGNhaXhhKTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCJcclxuICAgICAgICAgICAgZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAgIGZvcm0ubmFtZS50cmltKCkgPT09IFwiXCIgfHxcclxuICAgICAgICAgICAgICAoIWZvcm0ucHJpbnRzT3JkZXJzICYmICFmb3JtLnByaW50c0JpbGxzKSB8fFxyXG4gICAgICAgICAgICAgIChmb3JtLmNvbm5lY3Rpb25UeXBlID09PSAxICYmIGZvcm0ucHJpbnRlck5hbWUudHJpbSgpID09PSBcIlwiKSB8fFxyXG4gICAgICAgICAgICAgIChmb3JtLmNvbm5lY3Rpb25UeXBlID09PSAyICYmIChmb3JtLmlwQWRkcmVzcy50cmltKCkgPT09IFwiXCIgfHwgZm9ybS5wb3J0LnRyaW0oKSA9PT0gXCJcIikpIHx8XHJcbiAgICAgICAgICAgICAgY3JlYXRlTXV0YXRpb24uaXNQZW5kaW5nXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY3JlYXRlTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtjcmVhdGVNdXRhdGlvbi5pc1BlbmRpbmcgPyBcIlNhbHZhbmRv4oCmXCIgOiBcIlNhbHZhciBpbXByZXNzb3JhXCJ9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L092ZXJsYXk+XHJcbiAgICAgICl9XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvcHJpbnRpbmcvUHJpbnRpbmdQYWdlLnRzeCJ9