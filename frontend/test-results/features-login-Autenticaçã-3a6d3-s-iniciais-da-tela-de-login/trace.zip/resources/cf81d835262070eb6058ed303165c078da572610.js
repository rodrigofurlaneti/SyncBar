import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/ComplementItemsPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  createComplementItem,
  deactivateComplementItem,
  getComplementItems,
  updateComplementItem
} from "/src/features/catalog/complementsApi.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { Button } from "/src/ui/Button.tsx";
import { useToast } from "/src/ui/Toast.tsx";
import { useDialog } from "/src/ui/Dialog.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
export function ComplementItemsPanel() {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const dialog = useDialog();
  const { companyId } = useAuthStore();
  const [newName, setNewName] = useState("");
  const [editing, setEditing] = useState(null);
  const [editName, setEditName] = useState("");
  const [error, setError] = useState(null);
  const itemsQuery = useQuery({
    queryKey: ["complement-items", companyId],
    queryFn: () => getComplementItems(companyId ?? 1)
  });
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["complement-items"] });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const createMutation = useMutation({
    mutationFn: () => createComplementItem(companyId ?? 1, newName.trim()),
    onSuccess: () => {
      toast.success("Complemento criado.");
      setNewName("");
      setError(null);
      refresh();
    },
    onError: onApiError
  });
  const updateMutation = useMutation({
    mutationFn: () => updateComplementItem(editing.id, editName.trim()),
    onSuccess: () => {
      toast.success("Complemento atualizado.");
      setEditing(null);
      refresh();
    },
    onError: onApiError
  });
  const deactivateMutation = useMutation({
    mutationFn: (id) => deactivateComplementItem(id),
    onSuccess: () => {
      toast.success("Complemento desativado.");
      refresh();
    },
    onError: onApiError
  });
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 14 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", gap: 8, maxWidth: 460 }, children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          placeholder: "Nome do complemento (ex.: Bacon, Coca-Cola)…",
          value: newName,
          onChange: (e) => setNewName(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter" && newName.trim() !== "") createMutation.mutate();
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
          lineNumber: 89,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          loading: createMutation.isPending,
          disabled: newName.trim() === "",
          onClick: () => createMutation.mutate(),
          children: "+ Criar"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
          lineNumber: 97,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
      lineNumber: 88,
      columnNumber: 7
    }, this),
    error && !editing && /* @__PURE__ */ jsxDEV("p", { className: "error-text", role: "alert", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
      lineNumber: 107,
      columnNumber: 7
    }, this),
    itemsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: itemsQuery.error, what: "os complementos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
      lineNumber: 111,
      columnNumber: 30
    }, this),
    itemsQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 4, rowHeight: 52 }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
      lineNumber: 112,
      columnNumber: 32
    }, this),
    !itemsQuery.isLoading && (itemsQuery.data?.length ?? 0) === 0 && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: "🧂",
        title: "Nenhum complemento cadastrado",
        description: "Cadastre as opções (ex.: Bacon, Coca-Cola, Sem cebola) que depois entram em um grupo, na aba Grupos."
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
        lineNumber: 115,
        columnNumber: 7
      },
      this
    ),
    (itemsQuery.data?.length ?? 0) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: (itemsQuery.data ?? []).map(
      (item) => editing?.id === item.id ? /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { gap: 8 }, children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            autoFocus: true,
            value: editName,
            onChange: (e) => setEditName(e.target.value),
            style: { flex: 1 },
            onKeyDown: (e) => {
              if (e.key === "Enter" && editName.trim() !== "") updateMutation.mutate();
              else if (e.key === "Escape") setEditing(null);
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
            lineNumber: 127,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            size: "sm",
            loading: updateMutation.isPending,
            disabled: editName.trim() === "",
            onClick: () => updateMutation.mutate(),
            children: "Salvar"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
            lineNumber: 137,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Button, { size: "sm", iconOnly: true, "aria-label": "Cancelar edição", onClick: () => setEditing(null), children: "✕" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
          lineNumber: 145,
          columnNumber: 17
        }, this)
      ] }, item.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
        lineNumber: 126,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
        /* @__PURE__ */ jsxDEV("span", { children: item.name }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
          lineNumber: 151,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost",
              style: { minHeight: 44, padding: "0 12px", fontSize: "0.85rem" },
              onClick: () => {
                setEditing(item);
                setEditName(item.name);
              },
              children: "Editar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
              lineNumber: 153,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-danger",
              style: { minHeight: 44, padding: "0 12px", fontSize: "0.85rem" },
              onClick: async () => {
                if (await dialog.confirm({
                  title: "Desativar complemento",
                  message: `Desativar "${item.name}"? Ele deixa de poder ser adicionado a novos grupos.`,
                  confirmLabel: "Desativar",
                  danger: true
                }))
                  deactivateMutation.mutate(item.id);
              },
              children: "Desativar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
              lineNumber: 164,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
          lineNumber: 152,
          columnNumber: 17
        }, this)
      ] }, item.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
        lineNumber: 150,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
      lineNumber: 123,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx",
    lineNumber: 87,
    columnNumber: 5
  }, this);
}
_s(ComplementItemsPanel, "8etVEuLcvSfH5JvaxoJ+ljSe3ho=", false, function() {
  return [useQueryClient, useToast, useDialog, useAuthStore, useQuery, useMutation, useMutation, useMutation];
});
_c = ComplementItemsPanel;
var _c;
$RefreshReg$(_c, "ComplementItemsPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/catalog/ComplementItemsPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUVROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJFUCxTQUFTQSxnQkFBZ0I7QUFDMUIsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3REO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFFekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBRXRCLGdCQUFTQyx1QkFBdUI7QUFBQUMsS0FBQTtBQUNyQyxRQUFNQyxjQUFjZixlQUFlO0FBQ25DLFFBQU1nQixRQUFRUCxTQUFTO0FBQ3ZCLFFBQU1RLFNBQVNQLFVBQVU7QUFDekIsUUFBTSxFQUFFUSxVQUFVLElBQUliLGFBQWE7QUFDbkMsUUFBTSxDQUFDYyxTQUFTQyxVQUFVLElBQUl2QixTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDd0IsU0FBU0MsVUFBVSxJQUFJekIsU0FBd0MsSUFBSTtBQUMxRSxRQUFNLENBQUMwQixVQUFVQyxXQUFXLElBQUkzQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDNEIsT0FBT0MsUUFBUSxJQUFJN0IsU0FBd0IsSUFBSTtBQUV0RCxRQUFNOEIsYUFBYTVCLFNBQVM7QUFBQSxJQUMxQjZCLFVBQVUsQ0FBQyxvQkFBb0JWLFNBQVM7QUFBQSxJQUN4Q1csU0FBU0EsTUFBTTFCLG1CQUFtQmUsYUFBYSxDQUFDO0FBQUEsRUFDbEQsQ0FBQztBQUVELFFBQU1ZLFVBQVVBLE1BQU0sS0FBS2YsWUFBWWdCLGtCQUFrQixFQUFFSCxVQUFVLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztBQUMzRixRQUFNSSxhQUFhQSxDQUFDQyxNQUFlUCxTQUFTTyxhQUFhM0IsV0FBVzJCLEVBQUVDLFVBQVUsa0JBQWtCO0FBRWxHLFFBQU1DLGlCQUFpQnJDLFlBQVk7QUFBQSxJQUNqQ3NDLFlBQVlBLE1BQU1uQyxxQkFBcUJpQixhQUFhLEdBQUdDLFFBQVFrQixLQUFLLENBQUM7QUFBQSxJQUNyRUMsV0FBV0EsTUFBTTtBQUNmdEIsWUFBTXVCLFFBQVEscUJBQXFCO0FBQ25DbkIsaUJBQVcsRUFBRTtBQUNiTSxlQUFTLElBQUk7QUFDYkksY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBVSxTQUFTUjtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNUyxpQkFBaUIzQyxZQUFZO0FBQUEsSUFDakNzQyxZQUFZQSxNQUFNaEMscUJBQXFCaUIsUUFBU3FCLElBQUluQixTQUFTYyxLQUFLLENBQUM7QUFBQSxJQUNuRUMsV0FBV0EsTUFBTTtBQUNmdEIsWUFBTXVCLFFBQVEseUJBQXlCO0FBQ3ZDakIsaUJBQVcsSUFBSTtBQUNmUSxjQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0FVLFNBQVNSO0FBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1XLHFCQUFxQjdDLFlBQVk7QUFBQSxJQUNyQ3NDLFlBQVlBLENBQUNNLE9BQWV4Qyx5QkFBeUJ3QyxFQUFFO0FBQUEsSUFDdkRKLFdBQVdBLE1BQU07QUFDZnRCLFlBQU11QixRQUFRLHlCQUF5QjtBQUN2Q1QsY0FBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBVSxTQUFTUjtBQUFBQSxFQUNYLENBQUM7QUFFRCxTQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFWSxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNyQztBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRUQsU0FBUyxRQUFRQyxLQUFLLEdBQUdDLFVBQVUsSUFBSSxHQUNwRTtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxhQUFZO0FBQUEsVUFDWixPQUFPM0I7QUFBQUEsVUFDUCxVQUFVLENBQUNjLE1BQU1iLFdBQVdhLEVBQUVjLE9BQU9DLEtBQUs7QUFBQSxVQUMxQyxXQUFXLENBQUNmLE1BQU07QUFDaEIsZ0JBQUlBLEVBQUVnQixRQUFRLFdBQVc5QixRQUFRa0IsS0FBSyxNQUFNLEdBQUlGLGdCQUFlZSxPQUFPO0FBQUEsVUFDeEU7QUFBQTtBQUFBLFFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUk7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTZixlQUFlZ0I7QUFBQUEsVUFDeEIsVUFBVWhDLFFBQVFrQixLQUFLLE1BQU07QUFBQSxVQUM3QixTQUFTLE1BQU1GLGVBQWVlLE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUh6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLElBRUN6QixTQUFTLENBQUNKLFdBQ1QsdUJBQUMsT0FBRSxXQUFVLGNBQWEsTUFBSyxTQUM1QkksbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFREUsV0FBV3lCLFdBQVcsdUJBQUMsY0FBVyxPQUFPekIsV0FBV0YsT0FBTyxNQUFLLHFCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJEO0FBQUEsSUFDakZFLFdBQVcwQixhQUFhLHVCQUFDLGdCQUFhLE1BQU0sR0FBRyxXQUFXLE1BQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUM7QUFBQSxJQUU3RCxDQUFDMUIsV0FBVzBCLGNBQWMxQixXQUFXMkIsTUFBTUMsVUFBVSxPQUFPLEtBQzNEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxPQUFNO0FBQUEsUUFDTixhQUFZO0FBQUE7QUFBQSxNQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdvSDtBQUFBLEtBSXBINUIsV0FBVzJCLE1BQU1DLFVBQVUsS0FBSyxLQUNoQyx1QkFBQyxTQUFJLFdBQVUsVUFDWDVCLHNCQUFXMkIsUUFBUSxJQUFJRTtBQUFBQSxNQUFJLENBQUNDLFNBQzVCcEMsU0FBU3FCLE9BQU9lLEtBQUtmLEtBQ25CLHVCQUFDLFNBQUksV0FBVSxjQUEyQixPQUFPLEVBQUVHLEtBQUssRUFBRSxHQUN4RDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsT0FBT3RCO0FBQUFBLFlBQ1AsVUFBVSxDQUFDVSxNQUFNVCxZQUFZUyxFQUFFYyxPQUFPQyxLQUFLO0FBQUEsWUFDM0MsT0FBTyxFQUFFVSxNQUFNLEVBQUU7QUFBQSxZQUNqQixXQUFXLENBQUN6QixNQUFNO0FBQ2hCLGtCQUFJQSxFQUFFZ0IsUUFBUSxXQUFXMUIsU0FBU2MsS0FBSyxNQUFNLEdBQUlJLGdCQUFlUyxPQUFPO0FBQUEsdUJBQzlEakIsRUFBRWdCLFFBQVEsU0FBVTNCLFlBQVcsSUFBSTtBQUFBLFlBQzlDO0FBQUE7QUFBQSxVQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFJO0FBQUEsUUFFSjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU21CLGVBQWVVO0FBQUFBLFlBQ3hCLFVBQVU1QixTQUFTYyxLQUFLLE1BQU07QUFBQSxZQUM5QixTQUFTLE1BQU1JLGVBQWVTLE9BQU87QUFBQSxZQUFFO0FBQUE7QUFBQSxVQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFFBQ0EsdUJBQUMsVUFBTyxNQUFLLE1BQUssVUFBUSxNQUFDLGNBQVcsbUJBQWtCLFNBQVMsTUFBTTVCLFdBQVcsSUFBSSxHQUFHLGlCQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQXJCK0JtQyxLQUFLZixJQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQkFBQyxVQUFNZSxlQUFLRSxRQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUI7QUFBQSxRQUNqQix1QkFBQyxTQUFJLE9BQU8sRUFBRWYsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFZSxXQUFXLElBQUlDLFNBQVMsVUFBVUMsVUFBVSxVQUFVO0FBQUEsY0FDL0QsU0FBUyxNQUFNO0FBQ2J4QywyQkFBV21DLElBQUk7QUFDZmpDLDRCQUFZaUMsS0FBS0UsSUFBSTtBQUFBLGNBQ3ZCO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRUMsV0FBVyxJQUFJQyxTQUFTLFVBQVVDLFVBQVUsVUFBVTtBQUFBLGNBQy9ELFNBQVMsWUFBWTtBQUNuQixvQkFDRSxNQUFNN0MsT0FBTzhDLFFBQVE7QUFBQSxrQkFDbkJDLE9BQU87QUFBQSxrQkFDUDlCLFNBQVMsY0FBY3VCLEtBQUtFLElBQUk7QUFBQSxrQkFDaENNLGNBQWM7QUFBQSxrQkFDZEMsUUFBUTtBQUFBLGdCQUNWLENBQUM7QUFFRHZCLHFDQUFtQk8sT0FBT08sS0FBS2YsRUFBRTtBQUFBLGNBQ3JDO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQkE7QUFBQSxhQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUEsV0FoQytCZSxLQUFLZixJQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsSUFFSixLQTlERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0RBO0FBQUEsT0FuR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFHQTtBQUVKO0FBQUM1QixHQXhKZUQsc0JBQW9CO0FBQUEsVUFDZGIsZ0JBQ05TLFVBQ0NDLFdBQ09MLGNBTUhOLFVBUUlELGFBV0FBLGFBVUlBLFdBQVc7QUFBQTtBQUFBLEtBdkN4QmU7QUFBb0IsSUFBQXNEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiY3JlYXRlQ29tcGxlbWVudEl0ZW0iLCJkZWFjdGl2YXRlQ29tcGxlbWVudEl0ZW0iLCJnZXRDb21wbGVtZW50SXRlbXMiLCJ1cGRhdGVDb21wbGVtZW50SXRlbSIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwiUXVlcnlFcnJvciIsIkJ1dHRvbiIsInVzZVRvYXN0IiwidXNlRGlhbG9nIiwiRW1wdHlTdGF0ZSIsIlNrZWxldG9uTGlzdCIsIkNvbXBsZW1lbnRJdGVtc1BhbmVsIiwiX3MiLCJxdWVyeUNsaWVudCIsInRvYXN0IiwiZGlhbG9nIiwiY29tcGFueUlkIiwibmV3TmFtZSIsInNldE5ld05hbWUiLCJlZGl0aW5nIiwic2V0RWRpdGluZyIsImVkaXROYW1lIiwic2V0RWRpdE5hbWUiLCJlcnJvciIsInNldEVycm9yIiwiaXRlbXNRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInJlZnJlc2giLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uQXBpRXJyb3IiLCJlIiwibWVzc2FnZSIsImNyZWF0ZU11dGF0aW9uIiwibXV0YXRpb25GbiIsInRyaW0iLCJvblN1Y2Nlc3MiLCJzdWNjZXNzIiwib25FcnJvciIsInVwZGF0ZU11dGF0aW9uIiwiaWQiLCJkZWFjdGl2YXRlTXV0YXRpb24iLCJkaXNwbGF5IiwiZ2FwIiwibWF4V2lkdGgiLCJ0YXJnZXQiLCJ2YWx1ZSIsImtleSIsIm11dGF0ZSIsImlzUGVuZGluZyIsImlzRXJyb3IiLCJpc0xvYWRpbmciLCJkYXRhIiwibGVuZ3RoIiwibWFwIiwiaXRlbSIsImZsZXgiLCJuYW1lIiwibWluSGVpZ2h0IiwicGFkZGluZyIsImZvbnRTaXplIiwiY29uZmlybSIsInRpdGxlIiwiY29uZmlybUxhYmVsIiwiZGFuZ2VyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29tcGxlbWVudEl0ZW1zUGFuZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7XHJcbiAgY3JlYXRlQ29tcGxlbWVudEl0ZW0sXHJcbiAgZGVhY3RpdmF0ZUNvbXBsZW1lbnRJdGVtLFxyXG4gIGdldENvbXBsZW1lbnRJdGVtcyxcclxuICB1cGRhdGVDb21wbGVtZW50SXRlbSxcclxufSBmcm9tIFwiLi9jb21wbGVtZW50c0FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB0eXBlIHsgQ29tcGxlbWVudEl0ZW1SZXNwb25zZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uLy4uL3VpL0J1dHRvblwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi8uLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyB1c2VEaWFsb2cgfSBmcm9tIFwiLi4vLi4vdWkvRGlhbG9nXCI7XHJcbmltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tIFwiLi4vLi4vdWkvRW1wdHlTdGF0ZVwiO1xyXG5pbXBvcnQgeyBTa2VsZXRvbkxpc3QgfSBmcm9tIFwiLi4vLi4vdWkvU2tlbGV0b25cIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBDb21wbGVtZW50SXRlbXNQYW5lbCgpIHtcclxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG4gIGNvbnN0IGRpYWxvZyA9IHVzZURpYWxvZygpO1xyXG4gIGNvbnN0IHsgY29tcGFueUlkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbbmV3TmFtZSwgc2V0TmV3TmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZTxDb21wbGVtZW50SXRlbVJlc3BvbnNlIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2VkaXROYW1lLCBzZXRFZGl0TmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBpdGVtc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImNvbXBsZW1lbnQtaXRlbXNcIiwgY29tcGFueUlkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldENvbXBsZW1lbnRJdGVtcyhjb21wYW55SWQgPz8gMSksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJlZnJlc2ggPSAoKSA9PiB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImNvbXBsZW1lbnQtaXRlbXNcIl0gfSk7XHJcbiAgY29uc3Qgb25BcGlFcnJvciA9IChlOiB1bmtub3duKSA9PiBzZXRFcnJvcihlIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIk9wZXJhw6fDo28gZmFsaG91LlwiKTtcclxuXHJcbiAgY29uc3QgY3JlYXRlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBjcmVhdGVDb21wbGVtZW50SXRlbShjb21wYW55SWQgPz8gMSwgbmV3TmFtZS50cmltKCkpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJDb21wbGVtZW50byBjcmlhZG8uXCIpO1xyXG4gICAgICBzZXROZXdOYW1lKFwiXCIpO1xyXG4gICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgcmVmcmVzaCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHVwZGF0ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gdXBkYXRlQ29tcGxlbWVudEl0ZW0oZWRpdGluZyEuaWQsIGVkaXROYW1lLnRyaW0oKSksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNvbXBsZW1lbnRvIGF0dWFsaXphZG8uXCIpO1xyXG4gICAgICBzZXRFZGl0aW5nKG51bGwpO1xyXG4gICAgICByZWZyZXNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZGVhY3RpdmF0ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKGlkOiBudW1iZXIpID0+IGRlYWN0aXZhdGVDb21wbGVtZW50SXRlbShpZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNvbXBsZW1lbnRvIGRlc2F0aXZhZG8uXCIpO1xyXG4gICAgICByZWZyZXNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDgsIG1heFdpZHRoOiA0NjAgfX0+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWUgZG8gY29tcGxlbWVudG8gKGV4LjogQmFjb24sIENvY2EtQ29sYSnigKZcIlxyXG4gICAgICAgICAgdmFsdWU9e25ld05hbWV9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld05hbWUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIiAmJiBuZXdOYW1lLnRyaW0oKSAhPT0gXCJcIikgY3JlYXRlTXV0YXRpb24ubXV0YXRlKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgbG9hZGluZz17Y3JlYXRlTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e25ld05hbWUudHJpbSgpID09PSBcIlwifVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gY3JlYXRlTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgKyBDcmlhclxyXG4gICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtlcnJvciAmJiAhZWRpdGluZyAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiIHJvbGU9XCJhbGVydFwiPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgICAge2l0ZW1zUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17aXRlbXNRdWVyeS5lcnJvcn0gd2hhdD1cIm9zIGNvbXBsZW1lbnRvc1wiIC8+fVxyXG4gICAgICB7aXRlbXNRdWVyeS5pc0xvYWRpbmcgJiYgPFNrZWxldG9uTGlzdCByb3dzPXs0fSByb3dIZWlnaHQ9ezUyfSAvPn1cclxuXHJcbiAgICAgIHshaXRlbXNRdWVyeS5pc0xvYWRpbmcgJiYgKGl0ZW1zUXVlcnkuZGF0YT8ubGVuZ3RoID8/IDApID09PSAwICYmIChcclxuICAgICAgICA8RW1wdHlTdGF0ZVxyXG4gICAgICAgICAgaWNvbj1cIvCfp4JcIlxyXG4gICAgICAgICAgdGl0bGU9XCJOZW5odW0gY29tcGxlbWVudG8gY2FkYXN0cmFkb1wiXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbj1cIkNhZGFzdHJlIGFzIG9ww6fDtWVzIChleC46IEJhY29uLCBDb2NhLUNvbGEsIFNlbSBjZWJvbGEpIHF1ZSBkZXBvaXMgZW50cmFtIGVtIHVtIGdydXBvLCBuYSBhYmEgR3J1cG9zLlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsoaXRlbXNRdWVyeS5kYXRhPy5sZW5ndGggPz8gMCkgPiAwICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiPlxyXG4gICAgICAgICAgeyhpdGVtc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgoaXRlbSkgPT5cclxuICAgICAgICAgICAgZWRpdGluZz8uaWQgPT09IGl0ZW0uaWQgPyAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIga2V5PXtpdGVtLmlkfSBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0TmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0TmFtZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGZsZXg6IDEgfX1cclxuICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiICYmIGVkaXROYW1lLnRyaW0oKSAhPT0gXCJcIikgdXBkYXRlTXV0YXRpb24ubXV0YXRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIpIHNldEVkaXRpbmcobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXt1cGRhdGVNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0TmFtZS50cmltKCkgPT09IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTYWx2YXJcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBpY29uT25seSBhcmlhLWxhYmVsPVwiQ2FuY2VsYXIgZWRpw6fDo29cIiBvbkNsaWNrPXsoKSA9PiBzZXRFZGl0aW5nKG51bGwpfT5cclxuICAgICAgICAgICAgICAgICAg4pyVXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBrZXk9e2l0ZW0uaWR9PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0ubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1pbkhlaWdodDogNDQsIHBhZGRpbmc6IFwiMCAxMnB4XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRpbmcoaXRlbSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0TmFtZShpdGVtLm5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBFZGl0YXJcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5IZWlnaHQ6IDQ0LCBwYWRkaW5nOiBcIjAgMTJweFwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJEZXNhdGl2YXIgY29tcGxlbWVudG9cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBgRGVzYXRpdmFyIFwiJHtpdGVtLm5hbWV9XCI/IEVsZSBkZWl4YSBkZSBwb2RlciBzZXIgYWRpY2lvbmFkbyBhIG5vdm9zIGdydXBvcy5gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJEZXNhdGl2YXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlYWN0aXZhdGVNdXRhdGlvbi5tdXRhdGUoaXRlbS5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIERlc2F0aXZhclxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvQ29tcGxlbWVudEl0ZW1zUGFuZWwudHN4In0=