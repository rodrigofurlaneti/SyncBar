import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/settings/SettingsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  getServiceFeeSetting,
  setSelfServiceEmployee,
  setServiceFeeEnabled,
  getQrViewSetting,
  setQrViewEnabled,
  getTableReadingValidationSetting,
  setTableReadingValidation
} from "/src/features/settings/api.ts";
import { getComandaSetting, setComandaDefaultLimit } from "/src/features/comandas/api.ts";
import { getEmployeesByBranch } from "/src/features/employees/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useToast } from "/src/ui/Toast.tsx";
import { Switch } from "/src/ui/Switch.tsx";
import { formatBRL } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
const cards = [
  { to: "/", label: "Pedidos", desc: "Controle de mesas e comandas" },
  { to: "/delivery", label: "Delivery", desc: "Painel de entregas e expedição" },
  { to: "/preparo", label: "Preparo (KDS)", desc: "Monitor de cozinha e produção" },
  { to: "/garcom", label: "Visão do Garçom", desc: "Interface de atendimento no salão" },
  { to: "/pracas", label: "Praças e Salões", desc: "Gestão de áreas, mesas e turnos de garçons" },
  { to: "/produtos", label: "Produtos", desc: "Catálogo e preços do cardápio" },
  { to: "/complementos", label: "Complementos", desc: "Adicionais, bordas e variações" },
  { to: "/estoque", label: "Estoque", desc: "Controle de inventário e insumos" },
  { to: "/compras", label: "Compras", desc: "Fornecedores e entrada de estoque" },
  { to: "/clientes", label: "Clientes", desc: "Cadastro e fidelidade" },
  { to: "/reservas", label: "Reservas", desc: "Agenda de reservas de mesa" },
  { to: "/equipe", label: "Equipe", desc: "Funcionários e cargos" },
  { to: "/usuarios", label: "Usuários", desc: "Contas de acesso ao sistema" },
  { to: "/acessos", label: "Acessos", desc: "Papéis e permissões dos usuários" },
  { to: "/faturamento", label: "Faturamento", desc: "Custos e metas do mês" },
  { to: "/fechamentos", label: "Fechamentos", desc: "Histórico de sessões de caixa" },
  { to: "/relatorios", label: "Relatórios", desc: "Vendas, produtos e taxa de serviço" },
  { to: "/cenarios", label: "Cenários", desc: "Projeções e simulações" },
  { to: "/promocoes", label: "Promoções", desc: "Ofertas e descontos ativos" },
  { to: "/impressao", label: "Impressão", desc: "Impressoras e cupons" },
  { to: "/integracoes/ifood", label: "Integração iFood", desc: "Credenciais e conexão com o iFood" }
];
export function SettingsPage() {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { branchId } = useAuthStore();
  const [limitInput, setLimitInput] = useState("");
  const [selfServiceEmployeeId, setSelfServiceEmployeeId] = useState("");
  const feeQuery = useQuery({
    queryKey: ["orders", "service-fee-setting", branchId],
    queryFn: () => getServiceFeeSetting(branchId)
  });
  const feeEnabled = feeQuery.data?.enabled ?? true;
  const feeMutation = useMutation({
    mutationFn: (next) => setServiceFeeEnabled(branchId, next),
    onSuccess: (_data, next) => {
      toast.success(next ? "Taxa de serviço (10%) LIGADA." : "Taxa de serviço (10%) DESLIGADA.");
      void queryClient.invalidateQueries({ queryKey: ["orders", "service-fee-setting"] });
    },
    onError: () => toast.error("Não foi possível alterar a taxa de serviço.")
  });
  const qrViewQuery = useQuery({
    queryKey: ["orders", "qr-view-setting", branchId],
    queryFn: () => getQrViewSetting(branchId)
  });
  const qrViewEnabled = qrViewQuery.data?.enabled ?? true;
  const qrViewMutation = useMutation({
    mutationFn: (next) => setQrViewEnabled(branchId, next),
    onSuccess: (_data, next) => {
      toast.success(next ? "Visualização do cliente LIGADA." : "Visualização do cliente DESLIGADA.");
      void queryClient.invalidateQueries({ queryKey: ["orders", "qr-view-setting"] });
    },
    onError: () => toast.error("Não foi possível alterar a visualização.")
  });
  const readingValidationQuery = useQuery({
    queryKey: ["orders", "table-reading-validation-setting", branchId],
    queryFn: () => getTableReadingValidationSetting(branchId)
  });
  const readingValidation = readingValidationQuery.data ?? {
    isCameraInputEnabled: false,
    isBarcodeEnabled: false,
    isQrCodeEnabled: false
  };
  const readingValidationMutation = useMutation({
    mutationFn: (next) => setTableReadingValidation(branchId, next),
    onSuccess: () => {
      toast.success("Validação de leitura da comanda atualizada.");
      void queryClient.invalidateQueries({ queryKey: ["orders", "table-reading-validation-setting"] });
    },
    onError: () => toast.error("Não foi possível alterar a validação de leitura.")
  });
  const toggleReadingValidation = (field, next) => readingValidationMutation.mutate({ ...readingValidation, [field]: next });
  const comandaQuery = useQuery({
    queryKey: ["comandas", "setting", branchId],
    queryFn: () => getComandaSetting(branchId)
  });
  const limitMutation = useMutation({
    mutationFn: (value) => setComandaDefaultLimit(branchId, value),
    onSuccess: () => {
      setLimitInput("");
      toast.success("Limite de comanda atualizado.");
      void queryClient.invalidateQueries({ queryKey: ["comandas", "setting"] });
    },
    onError: () => toast.error("Não foi possível salvar o limite.")
  });
  const employeesQuery = useQuery({
    queryKey: ["employees", branchId],
    queryFn: () => getEmployeesByBranch(branchId)
  });
  const selfServiceMutation = useMutation({
    mutationFn: (employeeId) => setSelfServiceEmployee(branchId, employeeId),
    onSuccess: () => toast.success("Funcionário de autoatendimento atualizado."),
    onError: () => toast.error("Não foi possível salvar — confirme que você é administrador.")
  });
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Configurações" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 149,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "gestão da filial — somente gerente/administrador" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 150,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
      lineNumber: 148,
      columnNumber: 13
    }, this),
    (feeQuery.isError || qrViewQuery.isError || readingValidationQuery.isError) && /* @__PURE__ */ jsxDEV(QueryError, { error: feeQuery.error || qrViewQuery.error || readingValidationQuery.error, what: "as configurações" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
      lineNumber: 156,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-1", style: { padding: 20, display: "grid", gap: 18 }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Taxa de serviço (10%)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 162,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Quando desligada, as contas fechadas nesta filial não cobram os 10% e a taxa nem aparece na conta impressa. Ideal para eventos sem taxa — vale para o dia inteiro." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 163,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 161,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 12 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": feeEnabled ? "var(--ok)" : "var(--ink-faint)" }, children: feeEnabled ? "Ligada" : "Desligada" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 169,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            Switch,
            {
              checked: feeEnabled,
              disabled: feeQuery.isLoading || feeMutation.isPending,
              onChange: (next) => feeMutation.mutate(next),
              label: "Cobrar taxa de serviço de 10%"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 172,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 168,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 160,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { borderTop: "1px solid var(--line-soft)" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 181,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Visualização do cliente (QR Code)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 185,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Cliente pode consultar o valor total da comanda e os pedidos lançados via QR Code na mesa." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 186,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 184,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 12 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": qrViewEnabled ? "var(--ok)" : "var(--ink-faint)" }, children: qrViewEnabled ? "Ligada" : "Desligada" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 191,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            Switch,
            {
              checked: qrViewEnabled,
              disabled: qrViewQuery.isLoading || qrViewMutation.isPending,
              onChange: (next) => qrViewMutation.mutate(next),
              label: "Aparece a opção de mesa ou comanda"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 194,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 190,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 183,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { borderTop: "1px solid var(--line-soft)" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 203,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Validação de leitura da comanda" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 207,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Exige uma confirmação extra ao abrir a comanda/mesa, pelos cenários ligados abaixo. Vale para todas as mesas desta filial." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 208,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 206,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10 }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 12, justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink)", fontSize: "0.92rem", minWidth: 130 }, children: "Câmera" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 215,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": readingValidation.isCameraInputEnabled ? "var(--ok)" : "var(--ink-faint)" }, children: readingValidation.isCameraInputEnabled ? "Ligada" : "Desligada" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 216,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              Switch,
              {
                checked: readingValidation.isCameraInputEnabled,
                disabled: readingValidationQuery.isLoading || readingValidationMutation.isPending,
                onChange: (next) => toggleReadingValidation("isCameraInputEnabled", next),
                label: "Exigir captura por câmera na leitura da comanda"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
                lineNumber: 219,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 214,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 12, justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink)", fontSize: "0.92rem", minWidth: 130 }, children: "Código de barras" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 227,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": readingValidation.isBarcodeEnabled ? "var(--ok)" : "var(--ink-faint)" }, children: readingValidation.isBarcodeEnabled ? "Ligada" : "Desligada" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 228,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              Switch,
              {
                checked: readingValidation.isBarcodeEnabled,
                disabled: readingValidationQuery.isLoading || readingValidationMutation.isPending,
                onChange: (next) => toggleReadingValidation("isBarcodeEnabled", next),
                label: "Exigir leitura de código de barras na leitura da comanda"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
                lineNumber: 231,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 226,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 12, justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink)", fontSize: "0.92rem", minWidth: 130 }, children: "QR Code" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 239,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": readingValidation.isQrCodeEnabled ? "var(--ok)" : "var(--ink-faint)" }, children: readingValidation.isQrCodeEnabled ? "Ligada" : "Desligada" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 240,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              Switch,
              {
                checked: readingValidation.isQrCodeEnabled,
                disabled: readingValidationQuery.isLoading || readingValidationMutation.isPending,
                onChange: (next) => toggleReadingValidation("isQrCodeEnabled", next),
                label: "Exigir leitura de QR Code na leitura da comanda"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
                lineNumber: 243,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 238,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 213,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 205,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { borderTop: "1px solid var(--line-soft)" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 253,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Limite de comanda" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 257,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Valor máximo de consumo padrão para novas comandas desta filial." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 258,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 256,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8 }, children: [
          comandaQuery.data && /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": "var(--busy)" }, children: [
            "atual ",
            formatBRL(comandaQuery.data.defaultLimitAmount)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 264,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              placeholder: "novo limite",
              inputMode: "decimal",
              value: limitInput,
              onChange: (e) => setLimitInput(e.target.value),
              style: { width: 130 }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 268,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost",
              disabled: limitMutation.isPending || limitInput.trim() === "",
              onClick: () => {
                const value = Number(limitInput.replace(",", "."));
                if (Number.isFinite(value) && value > 0) limitMutation.mutate(value);
              },
              children: "Salvar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 275,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 262,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 255,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { borderTop: "1px solid var(--line-soft)" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 289,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Autoatendimento (QR Code)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 293,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: 'Funcionário que "abre" os pedidos lançados por clientes via QR Code na mesa. Obrigatório configurar antes de gerar QR Codes em Salão.' }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
            lineNumber: 294,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 292,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: selfServiceEmployeeId,
              onChange: (e) => setSelfServiceEmployeeId(e.target.value),
              style: { width: 200 },
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione…" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
                  lineNumber: 305,
                  columnNumber: 29
                }, this),
                (employeesQuery.data ?? []).filter((e) => e.isActive).map(
                  (e) => /* @__PURE__ */ jsxDEV("option", { value: e.id, children: e.name }, e.id, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
                    lineNumber: 307,
                    columnNumber: 15
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 300,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost",
              disabled: selfServiceEmployeeId === "" || selfServiceMutation.isPending,
              onClick: () => selfServiceMutation.mutate(Number(selfServiceEmployeeId)),
              children: "Salvar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
              lineNumber: 310,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 299,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 291,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
      lineNumber: 159,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { className: "display rise rise-2", style: { fontSize: "1.2rem", margin: "26px 0 12px" }, children: "Navegação do Sistema" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
      lineNumber: 322,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rise rise-2", style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(230px, 1fr))", gap: 12 }, children: cards.map(
      (card) => /* @__PURE__ */ jsxDEV(Link, { to: card.to, className: "ticket", style: { padding: "16px 18px", display: "grid", gap: 4, textDecoration: "none", minHeight: 84 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.05rem", color: "var(--ink)" }, children: card.label }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 328,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.86rem" }, children: card.desc }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
          lineNumber: 329,
          columnNumber: 25
        }, this)
      ] }, card.to, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
        lineNumber: 327,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
      lineNumber: 325,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx",
    lineNumber: 147,
    columnNumber: 5
  }, this);
}
_s(SettingsPage, "ZPT1BqvxxFf7AOWxSDVkrUPKfEw=", false, function() {
  return [useQueryClient, useToast, useAuthStore, useQuery, useMutation, useQuery, useMutation, useQuery, useMutation, useQuery, useMutation, useQuery, useMutation];
});
_c = SettingsPage;
var _c;
$RefreshReg$(_c, "SettingsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/settings/SettingsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUlnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqSWYsU0FBU0EsZ0JBQW9DO0FBQzlDLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3REO0FBQUEsRUFDSUM7QUFBQUEsRUFBc0JDO0FBQUFBLEVBQXdCQztBQUFBQSxFQUFzQkM7QUFBQUEsRUFBa0JDO0FBQUFBLEVBQ3RGQztBQUFBQSxFQUFrQ0M7QUFBQUEsT0FDL0I7QUFDUCxTQUFTQyxtQkFBbUJDLDhCQUE4QjtBQUMxRCxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxrQkFBa0I7QUFFM0IsTUFBTUMsUUFBUTtBQUFBLEVBQ1YsRUFBRUMsSUFBSSxLQUFLQyxPQUFPLFdBQVdDLE1BQU0sK0JBQStCO0FBQUEsRUFDbEUsRUFBRUYsSUFBSSxhQUFhQyxPQUFPLFlBQVlDLE1BQU0saUNBQWlDO0FBQUEsRUFDN0UsRUFBRUYsSUFBSSxZQUFZQyxPQUFPLGlCQUFpQkMsTUFBTSxnQ0FBZ0M7QUFBQSxFQUNoRixFQUFFRixJQUFJLFdBQVdDLE9BQU8sbUJBQW1CQyxNQUFNLG9DQUFvQztBQUFBLEVBQ3JGLEVBQUVGLElBQUksV0FBV0MsT0FBTyxtQkFBbUJDLE1BQU0sNkNBQTZDO0FBQUEsRUFDOUYsRUFBRUYsSUFBSSxhQUFhQyxPQUFPLFlBQVlDLE1BQU0sZ0NBQWdDO0FBQUEsRUFDNUUsRUFBRUYsSUFBSSxpQkFBaUJDLE9BQU8sZ0JBQWdCQyxNQUFNLGlDQUFpQztBQUFBLEVBQ3JGLEVBQUVGLElBQUksWUFBWUMsT0FBTyxXQUFXQyxNQUFNLG1DQUFtQztBQUFBLEVBQzdFLEVBQUVGLElBQUksWUFBWUMsT0FBTyxXQUFXQyxNQUFNLG9DQUFvQztBQUFBLEVBQzlFLEVBQUVGLElBQUksYUFBYUMsT0FBTyxZQUFZQyxNQUFNLHdCQUF3QjtBQUFBLEVBQ3BFLEVBQUVGLElBQUksYUFBYUMsT0FBTyxZQUFZQyxNQUFNLDZCQUE2QjtBQUFBLEVBQ3pFLEVBQUVGLElBQUksV0FBV0MsT0FBTyxVQUFVQyxNQUFNLHdCQUF3QjtBQUFBLEVBQ2hFLEVBQUVGLElBQUksYUFBYUMsT0FBTyxZQUFZQyxNQUFNLDhCQUE4QjtBQUFBLEVBQzFFLEVBQUVGLElBQUksWUFBWUMsT0FBTyxXQUFXQyxNQUFNLG1DQUFtQztBQUFBLEVBQzdFLEVBQUVGLElBQUksZ0JBQWdCQyxPQUFPLGVBQWVDLE1BQU0sd0JBQXdCO0FBQUEsRUFDMUUsRUFBRUYsSUFBSSxnQkFBZ0JDLE9BQU8sZUFBZUMsTUFBTSxnQ0FBZ0M7QUFBQSxFQUNsRixFQUFFRixJQUFJLGVBQWVDLE9BQU8sY0FBY0MsTUFBTSxxQ0FBcUM7QUFBQSxFQUNyRixFQUFFRixJQUFJLGFBQWFDLE9BQU8sWUFBWUMsTUFBTSx5QkFBeUI7QUFBQSxFQUNyRSxFQUFFRixJQUFJLGNBQWNDLE9BQU8sYUFBYUMsTUFBTSw2QkFBNkI7QUFBQSxFQUMzRSxFQUFFRixJQUFJLGNBQWNDLE9BQU8sYUFBYUMsTUFBTSx1QkFBdUI7QUFBQSxFQUNyRSxFQUFFRixJQUFJLHNCQUFzQkMsT0FBTyxvQkFBb0JDLE1BQU0sb0NBQW9DO0FBQUM7QUFHL0YsZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUMzQixRQUFNQyxjQUFjdEIsZUFBZTtBQUNuQyxRQUFNdUIsUUFBUVgsU0FBUztBQUN2QixRQUFNLEVBQUVZLFNBQVMsSUFBSWIsYUFBYTtBQUNsQyxRQUFNLENBQUNjLFlBQVlDLGFBQWEsSUFBSTlCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMrQix1QkFBdUJDLHdCQUF3QixJQUFJaEMsU0FBUyxFQUFFO0FBRXJFLFFBQU1pQyxXQUFXOUIsU0FBUztBQUFBLElBQ3RCK0IsVUFBVSxDQUFDLFVBQVUsdUJBQXVCTixRQUFRO0FBQUEsSUFDcERPLFNBQVNBLE1BQU05QixxQkFBcUJ1QixRQUFRO0FBQUEsRUFDaEQsQ0FBQztBQUNELFFBQU1RLGFBQWFILFNBQVNJLE1BQU1DLFdBQVc7QUFFN0MsUUFBTUMsY0FBY3JDLFlBQVk7QUFBQSxJQUM1QnNDLFlBQVlBLENBQUNDLFNBQWtCbEMscUJBQXFCcUIsVUFBVWEsSUFBSTtBQUFBLElBQ2xFQyxXQUFXQSxDQUFDQyxPQUFPRixTQUFTO0FBQ3hCZCxZQUFNaUIsUUFBUUgsT0FBTyxrQ0FBa0Msa0NBQWtDO0FBQ3pGLFdBQUtmLFlBQVltQixrQkFBa0IsRUFBRVgsVUFBVSxDQUFDLFVBQVUscUJBQXFCLEVBQUUsQ0FBQztBQUFBLElBQ3RGO0FBQUEsSUFDQVksU0FBU0EsTUFBTW5CLE1BQU1vQixNQUFNLDZDQUE2QztBQUFBLEVBQzVFLENBQUM7QUFFRCxRQUFNQyxjQUFjN0MsU0FBUztBQUFBLElBQ3pCK0IsVUFBVSxDQUFDLFVBQVUsbUJBQW1CTixRQUFRO0FBQUEsSUFDaERPLFNBQVNBLE1BQU0zQixpQkFBaUJvQixRQUFRO0FBQUEsRUFDNUMsQ0FBQztBQUNELFFBQU1xQixnQkFBZ0JELFlBQVlYLE1BQU1DLFdBQVc7QUFFbkQsUUFBTVksaUJBQWlCaEQsWUFBWTtBQUFBLElBQy9Cc0MsWUFBWUEsQ0FBQ0MsU0FBa0JoQyxpQkFBaUJtQixVQUFVYSxJQUFJO0FBQUEsSUFDOURDLFdBQVdBLENBQUNDLE9BQU9GLFNBQVM7QUFDeEJkLFlBQU1pQixRQUFRSCxPQUFPLG9DQUFvQyxvQ0FBb0M7QUFDN0YsV0FBS2YsWUFBWW1CLGtCQUFrQixFQUFFWCxVQUFVLENBQUMsVUFBVSxpQkFBaUIsRUFBRSxDQUFDO0FBQUEsSUFDbEY7QUFBQSxJQUNBWSxTQUFTQSxNQUFNbkIsTUFBTW9CLE1BQU0sMENBQTBDO0FBQUEsRUFDekUsQ0FBQztBQUVELFFBQU1JLHlCQUF5QmhELFNBQVM7QUFBQSxJQUNwQytCLFVBQVUsQ0FBQyxVQUFVLG9DQUFvQ04sUUFBUTtBQUFBLElBQ2pFTyxTQUFTQSxNQUFNekIsaUNBQWlDa0IsUUFBUTtBQUFBLEVBQzVELENBQUM7QUFDRCxRQUFNd0Isb0JBQW9CRCx1QkFBdUJkLFFBQVE7QUFBQSxJQUNyRGdCLHNCQUFzQjtBQUFBLElBQ3RCQyxrQkFBa0I7QUFBQSxJQUNsQkMsaUJBQWlCO0FBQUEsRUFDckI7QUFFQSxRQUFNQyw0QkFBNEJ0RCxZQUFZO0FBQUEsSUFDMUNzQyxZQUFZQSxDQUFDQyxTQUFtQzlCLDBCQUEwQmlCLFVBQVVhLElBQUk7QUFBQSxJQUN4RkMsV0FBV0EsTUFBTTtBQUNiZixZQUFNaUIsUUFBUSw2Q0FBNkM7QUFDM0QsV0FBS2xCLFlBQVltQixrQkFBa0IsRUFBRVgsVUFBVSxDQUFDLFVBQVUsa0NBQWtDLEVBQUUsQ0FBQztBQUFBLElBQ25HO0FBQUEsSUFDQVksU0FBU0EsTUFBTW5CLE1BQU1vQixNQUFNLGtEQUFrRDtBQUFBLEVBQ2pGLENBQUM7QUFFRCxRQUFNVSwwQkFBMEJBLENBQzVCQyxPQUNBakIsU0FDQ2UsMEJBQTBCRyxPQUFPLEVBQUUsR0FBR1AsbUJBQW1CLENBQUNNLEtBQUssR0FBR2pCLEtBQUssQ0FBQztBQUU3RSxRQUFNbUIsZUFBZXpELFNBQVM7QUFBQSxJQUMxQitCLFVBQVUsQ0FBQyxZQUFZLFdBQVdOLFFBQVE7QUFBQSxJQUMxQ08sU0FBU0EsTUFBTXZCLGtCQUFrQmdCLFFBQVE7QUFBQSxFQUM3QyxDQUFDO0FBRUQsUUFBTWlDLGdCQUFnQjNELFlBQVk7QUFBQSxJQUM5QnNDLFlBQVlBLENBQUNzQixVQUFrQmpELHVCQUF1QmUsVUFBVWtDLEtBQUs7QUFBQSxJQUNyRXBCLFdBQVdBLE1BQU07QUFDYlosb0JBQWMsRUFBRTtBQUNoQkgsWUFBTWlCLFFBQVEsK0JBQStCO0FBQzdDLFdBQUtsQixZQUFZbUIsa0JBQWtCLEVBQUVYLFVBQVUsQ0FBQyxZQUFZLFNBQVMsRUFBRSxDQUFDO0FBQUEsSUFDNUU7QUFBQSxJQUNBWSxTQUFTQSxNQUFNbkIsTUFBTW9CLE1BQU0sbUNBQW1DO0FBQUEsRUFDbEUsQ0FBQztBQUVELFFBQU1nQixpQkFBaUI1RCxTQUFTO0FBQUEsSUFDNUIrQixVQUFVLENBQUMsYUFBYU4sUUFBUTtBQUFBLElBQ2hDTyxTQUFTQSxNQUFNckIscUJBQXFCYyxRQUFRO0FBQUEsRUFDaEQsQ0FBQztBQUVELFFBQU1vQyxzQkFBc0I5RCxZQUFZO0FBQUEsSUFDcENzQyxZQUFZQSxDQUFDeUIsZUFBOEIzRCx1QkFBdUJzQixVQUFVcUMsVUFBVTtBQUFBLElBQ3RGdkIsV0FBV0EsTUFBTWYsTUFBTWlCLFFBQVEsNENBQTRDO0FBQUEsSUFDM0VFLFNBQVNBLE1BQU1uQixNQUFNb0IsTUFBTSw4REFBOEQ7QUFBQSxFQUM3RixDQUFDO0FBRUQsU0FDSSx1QkFBQyxVQUFLLE9BQU8sRUFBRW1CLFNBQVMsSUFBSUMsVUFBVSxNQUFNQyxRQUFRLFNBQVMsR0FDekQ7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVDLGNBQWMsR0FBRyxHQUM1QztBQUFBLDZCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxTQUFTLEdBQUcsNkJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0U7QUFBQSxNQUNwRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxvQkFBb0JELFVBQVUsU0FBUyxHQUFHLGdFQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLEtBRUVyQyxTQUFTdUMsV0FBV3hCLFlBQVl3QixXQUFXckIsdUJBQXVCcUIsWUFDaEUsdUJBQUMsY0FBVyxPQUFPdkMsU0FBU2MsU0FBU0MsWUFBWUQsU0FBU0ksdUJBQXVCSixPQUFPLE1BQUssc0JBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0c7QUFBQSxJQUduSCx1QkFBQyxhQUFRLFdBQVUsc0JBQXFCLE9BQU8sRUFBRW1CLFNBQVMsSUFBSU8sU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDbkY7QUFBQSw2QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUMsZ0JBQWdCLGlCQUFpQkQsS0FBSyxHQUFHLEdBQ2xGO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVELFNBQVMsUUFBUUMsS0FBSyxHQUFHUCxVQUFVLElBQUksR0FDakQ7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVHLFVBQVUsU0FBUyxHQUFHLHFDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLFVBQzlFLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsa0xBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFSSxLQUFLLEdBQUcsR0FDckM7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsUUFBTyxPQUFPLEVBQUUsU0FBU3RDLGFBQWEsY0FBYyxtQkFBbUIsR0FDbEZBLHVCQUFhLFdBQVcsZUFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVNBO0FBQUFBLGNBQ1QsVUFBVUgsU0FBUzJDLGFBQWFyQyxZQUFZc0M7QUFBQUEsY0FDNUMsVUFBVSxDQUFDcEMsU0FBU0YsWUFBWW9CLE9BQU9sQixJQUFJO0FBQUEsY0FDM0MsT0FBTTtBQUFBO0FBQUEsWUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJeUM7QUFBQSxhQVI3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxXQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXFDLFdBQVcsNkJBQTZCLEtBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxNQUV4RCx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUgsZ0JBQWdCLGlCQUFpQkQsS0FBSyxHQUFHLEdBQ2xGO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVELFNBQVMsUUFBUUMsS0FBSyxHQUFHUCxVQUFVLElBQUksR0FDakQ7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVHLFVBQVUsU0FBUyxHQUFHLGlEQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLFVBQzFGLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsMEdBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFSSxLQUFLLEdBQUcsR0FDckM7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsUUFBTyxPQUFPLEVBQUUsU0FBU3pCLGdCQUFnQixjQUFjLG1CQUFtQixHQUNyRkEsMEJBQWdCLFdBQVcsZUFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVNBO0FBQUFBLGNBQ1QsVUFBVUQsWUFBWTRCLGFBQWExQixlQUFlMkI7QUFBQUEsY0FDbEQsVUFBVSxDQUFDcEMsU0FBU1MsZUFBZVMsT0FBT2xCLElBQUk7QUFBQSxjQUM5QyxPQUFNO0FBQUE7QUFBQSxZQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUk4QztBQUFBLGFBUmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFcUMsV0FBVyw2QkFBNkIsS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RDtBQUFBLE1BRXhELHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFSCxnQkFBZ0IsaUJBQWlCRCxLQUFLLEdBQUcsR0FDbEY7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRUQsU0FBUyxRQUFRQyxLQUFLLEdBQUdQLFVBQVUsSUFBSSxHQUNqRDtBQUFBLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUcsVUFBVSxTQUFTLEdBQUcsK0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEYsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBRywwSUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUcsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDbkM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVBLEtBQUssSUFBSUMsZ0JBQWdCLGdCQUFnQixHQUN0RTtBQUFBLG1DQUFDLFVBQUssT0FBTyxFQUFFSixPQUFPLGNBQWNELFVBQVUsV0FBV1MsVUFBVSxJQUFJLEdBQUcsc0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsWUFDaEYsdUJBQUMsVUFBSyxXQUFVLFFBQU8sT0FBTyxFQUFFLFNBQVMzQixrQkFBa0JDLHVCQUF1QixjQUFjLG1CQUFtQixHQUM5R0QsNEJBQWtCQyx1QkFBdUIsV0FBVyxlQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFNBQVNELGtCQUFrQkM7QUFBQUEsZ0JBQzNCLFVBQVVGLHVCQUF1QnlCLGFBQWFwQiwwQkFBMEJxQjtBQUFBQSxnQkFDeEUsVUFBVSxDQUFDcEMsU0FBU2dCLHdCQUF3Qix3QkFBd0JoQixJQUFJO0FBQUEsZ0JBQ3hFLE9BQU07QUFBQTtBQUFBLGNBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTJEO0FBQUEsZUFUL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFaUMsS0FBSyxJQUFJQyxnQkFBZ0IsZ0JBQWdCLEdBQ3RFO0FBQUEsbUNBQUMsVUFBSyxPQUFPLEVBQUVKLE9BQU8sY0FBY0QsVUFBVSxXQUFXUyxVQUFVLElBQUksR0FBRyxnQ0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxZQUMxRix1QkFBQyxVQUFLLFdBQVUsUUFBTyxPQUFPLEVBQUUsU0FBUzNCLGtCQUFrQkUsbUJBQW1CLGNBQWMsbUJBQW1CLEdBQzFHRiw0QkFBa0JFLG1CQUFtQixXQUFXLGVBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csU0FBU0Ysa0JBQWtCRTtBQUFBQSxnQkFDM0IsVUFBVUgsdUJBQXVCeUIsYUFBYXBCLDBCQUEwQnFCO0FBQUFBLGdCQUN4RSxVQUFVLENBQUNwQyxTQUFTZ0Isd0JBQXdCLG9CQUFvQmhCLElBQUk7QUFBQSxnQkFDcEUsT0FBTTtBQUFBO0FBQUEsY0FKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJb0U7QUFBQSxlQVR4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVpQyxLQUFLLElBQUlDLGdCQUFnQixnQkFBZ0IsR0FDdEU7QUFBQSxtQ0FBQyxVQUFLLE9BQU8sRUFBRUosT0FBTyxjQUFjRCxVQUFVLFdBQVdTLFVBQVUsSUFBSSxHQUFHLHVCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRjtBQUFBLFlBQ2pGLHVCQUFDLFVBQUssV0FBVSxRQUFPLE9BQU8sRUFBRSxTQUFTM0Isa0JBQWtCRyxrQkFBa0IsY0FBYyxtQkFBbUIsR0FDekdILDRCQUFrQkcsa0JBQWtCLFdBQVcsZUFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxTQUFTSCxrQkFBa0JHO0FBQUFBLGdCQUMzQixVQUFVSix1QkFBdUJ5QixhQUFhcEIsMEJBQTBCcUI7QUFBQUEsZ0JBQ3hFLFVBQVUsQ0FBQ3BDLFNBQVNnQix3QkFBd0IsbUJBQW1CaEIsSUFBSTtBQUFBLGdCQUNuRSxPQUFNO0FBQUE7QUFBQSxjQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUkyRDtBQUFBLGVBVC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxhQXBDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUNBO0FBQUEsV0E3Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVxQyxXQUFXLDZCQUE2QixLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFFeEQsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVILGdCQUFnQixpQkFBaUJELEtBQUssR0FBRyxHQUNsRjtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFRCxTQUFTLFFBQVFDLEtBQUssR0FBR1AsVUFBVSxJQUFJLEdBQ2pEO0FBQUEsaUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFRyxVQUFVLFNBQVMsR0FBRyxpQ0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxrQkFBa0JELFVBQVUsVUFBVSxHQUFHLGdGQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRUksS0FBSyxFQUFFLEdBQ25DZDtBQUFBQSx1QkFBYXZCLFFBQ1YsdUJBQUMsVUFBSyxXQUFVLFFBQU8sT0FBTyxFQUFFLFNBQVMsY0FBYyxHQUFvQjtBQUFBO0FBQUEsWUFDaEVuQixVQUFVMEMsYUFBYXZCLEtBQUsyQyxrQkFBa0I7QUFBQSxlQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFSjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBLGNBQ1YsT0FBT25EO0FBQUFBLGNBQ1AsVUFBVSxDQUFDb0QsTUFBTW5ELGNBQWNtRCxFQUFFQyxPQUFPcEIsS0FBSztBQUFBLGNBQzdDLE9BQU8sRUFBRXFCLE9BQU8sSUFBSTtBQUFBO0FBQUEsWUFMeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSzBCO0FBQUEsVUFFMUI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLFVBQVV0QixjQUFjZ0IsYUFBYWhELFdBQVd1RCxLQUFLLE1BQU07QUFBQSxjQUMzRCxTQUFTLE1BQU07QUFDWCxzQkFBTXRCLFFBQVF1QixPQUFPeEQsV0FBV3lELFFBQVEsS0FBSyxHQUFHLENBQUM7QUFDakQsb0JBQUlELE9BQU9FLFNBQVN6QixLQUFLLEtBQUtBLFFBQVEsRUFBR0QsZUFBY0YsT0FBT0csS0FBSztBQUFBLGNBQ3ZFO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFQTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxXQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWdCLFdBQVcsNkJBQTZCLEtBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxNQUV4RCx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUgsZ0JBQWdCLGlCQUFpQkQsS0FBSyxHQUFHLEdBQ2xGO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVELFNBQVMsUUFBUUMsS0FBSyxHQUFHUCxVQUFVLElBQUksR0FDakQ7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVHLFVBQVUsU0FBUyxHQUFHLHlDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQ2xGLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcscUpBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFSSxLQUFLLEVBQUUsR0FDcEM7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csT0FBTzNDO0FBQUFBLGNBQ1AsVUFBVSxDQUFDa0QsTUFBTWpELHlCQUF5QmlELEVBQUVDLE9BQU9wQixLQUFLO0FBQUEsY0FDeEQsT0FBTyxFQUFFcUIsT0FBTyxJQUFJO0FBQUEsY0FFcEI7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sSUFBRywwQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQSxpQkFDekJwQixlQUFlMUIsUUFBUSxJQUFJbUQsT0FBTyxDQUFDUCxNQUFNQSxFQUFFUSxRQUFRLEVBQUVDO0FBQUFBLGtCQUFJLENBQUNULE1BQ3hELHVCQUFDLFlBQWtCLE9BQU9BLEVBQUVVLElBQUtWLFlBQUVXLFFBQXRCWCxFQUFFVSxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdDO0FBQUEsZ0JBQzNDO0FBQUE7QUFBQTtBQUFBLFlBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixVQUFVNUQsMEJBQTBCLE1BQU1pQyxvQkFBb0JhO0FBQUFBLGNBQzlELFNBQVMsTUFBTWIsb0JBQW9CTCxPQUFPMEIsT0FBT3RELHFCQUFxQixDQUFDO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFKN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsV0EzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRCQTtBQUFBLFNBaEtKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpS0E7QUFBQSxJQUVBLHVCQUFDLFFBQUcsV0FBVSx1QkFBc0IsT0FBTyxFQUFFdUMsVUFBVSxVQUFVRixRQUFRLGNBQWMsR0FBRyxvQ0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFBYyxPQUFPLEVBQUVLLFNBQVMsUUFBUW9CLHFCQUFxQix5Q0FBeUNuQixLQUFLLEdBQUcsR0FDeEh0RCxnQkFBTXNFO0FBQUFBLE1BQUksQ0FBQ0ksU0FDUix1QkFBQyxRQUFtQixJQUFJQSxLQUFLekUsSUFBSSxXQUFVLFVBQVMsT0FBTyxFQUFFNkMsU0FBUyxhQUFhTyxTQUFTLFFBQVFDLEtBQUssR0FBR3FCLGdCQUFnQixRQUFRQyxXQUFXLEdBQUcsR0FDOUk7QUFBQSwrQkFBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUUxQixVQUFVLFdBQVdDLE9BQU8sYUFBYSxHQUFJdUIsZUFBS3hFLFNBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkY7QUFBQSxRQUMzRix1QkFBQyxVQUFLLE9BQU8sRUFBRWlELE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBSXdCLGVBQUt2RSxRQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsV0FGbkV1RSxLQUFLekUsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsSUFDSCxLQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BekxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwTEE7QUFFUjtBQUFDSSxHQXBSZUQsY0FBWTtBQUFBLFVBQ0pwQixnQkFDTlksVUFDT0QsY0FJSlosVUFNR0QsYUFTQUMsVUFNR0QsYUFTUUMsVUFVR0QsYUFjYkMsVUFLQ0QsYUFVQ0MsVUFLS0QsV0FBVztBQUFBO0FBQUEsS0FqRjNCc0I7QUFBWSxJQUFBeUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJMaW5rIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiZ2V0U2VydmljZUZlZVNldHRpbmciLCJzZXRTZWxmU2VydmljZUVtcGxveWVlIiwic2V0U2VydmljZUZlZUVuYWJsZWQiLCJnZXRRclZpZXdTZXR0aW5nIiwic2V0UXJWaWV3RW5hYmxlZCIsImdldFRhYmxlUmVhZGluZ1ZhbGlkYXRpb25TZXR0aW5nIiwic2V0VGFibGVSZWFkaW5nVmFsaWRhdGlvbiIsImdldENvbWFuZGFTZXR0aW5nIiwic2V0Q29tYW5kYURlZmF1bHRMaW1pdCIsImdldEVtcGxveWVlc0J5QnJhbmNoIiwidXNlQXV0aFN0b3JlIiwidXNlVG9hc3QiLCJTd2l0Y2giLCJmb3JtYXRCUkwiLCJRdWVyeUVycm9yIiwiY2FyZHMiLCJ0byIsImxhYmVsIiwiZGVzYyIsIlNldHRpbmdzUGFnZSIsIl9zIiwicXVlcnlDbGllbnQiLCJ0b2FzdCIsImJyYW5jaElkIiwibGltaXRJbnB1dCIsInNldExpbWl0SW5wdXQiLCJzZWxmU2VydmljZUVtcGxveWVlSWQiLCJzZXRTZWxmU2VydmljZUVtcGxveWVlSWQiLCJmZWVRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImZlZUVuYWJsZWQiLCJkYXRhIiwiZW5hYmxlZCIsImZlZU11dGF0aW9uIiwibXV0YXRpb25GbiIsIm5leHQiLCJvblN1Y2Nlc3MiLCJfZGF0YSIsInN1Y2Nlc3MiLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uRXJyb3IiLCJlcnJvciIsInFyVmlld1F1ZXJ5IiwicXJWaWV3RW5hYmxlZCIsInFyVmlld011dGF0aW9uIiwicmVhZGluZ1ZhbGlkYXRpb25RdWVyeSIsInJlYWRpbmdWYWxpZGF0aW9uIiwiaXNDYW1lcmFJbnB1dEVuYWJsZWQiLCJpc0JhcmNvZGVFbmFibGVkIiwiaXNRckNvZGVFbmFibGVkIiwicmVhZGluZ1ZhbGlkYXRpb25NdXRhdGlvbiIsInRvZ2dsZVJlYWRpbmdWYWxpZGF0aW9uIiwiZmllbGQiLCJtdXRhdGUiLCJjb21hbmRhUXVlcnkiLCJsaW1pdE11dGF0aW9uIiwidmFsdWUiLCJlbXBsb3llZXNRdWVyeSIsInNlbGZTZXJ2aWNlTXV0YXRpb24iLCJlbXBsb3llZUlkIiwicGFkZGluZyIsIm1heFdpZHRoIiwibWFyZ2luIiwibWFyZ2luQm90dG9tIiwiZm9udFNpemUiLCJjb2xvciIsImlzRXJyb3IiLCJkaXNwbGF5IiwiZ2FwIiwianVzdGlmeUNvbnRlbnQiLCJpc0xvYWRpbmciLCJpc1BlbmRpbmciLCJib3JkZXJUb3AiLCJtaW5XaWR0aCIsImRlZmF1bHRMaW1pdEFtb3VudCIsImUiLCJ0YXJnZXQiLCJ3aWR0aCIsInRyaW0iLCJOdW1iZXIiLCJyZXBsYWNlIiwiaXNGaW5pdGUiLCJmaWx0ZXIiLCJpc0FjdGl2ZSIsIm1hcCIsImlkIiwibmFtZSIsImdyaWRUZW1wbGF0ZUNvbHVtbnMiLCJjYXJkIiwidGV4dERlY29yYXRpb24iLCJtaW5IZWlnaHQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZXR0aW5nc1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZVN0YXRlLCB0eXBlIENTU1Byb3BlcnRpZXMgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7XHJcbiAgICBnZXRTZXJ2aWNlRmVlU2V0dGluZywgc2V0U2VsZlNlcnZpY2VFbXBsb3llZSwgc2V0U2VydmljZUZlZUVuYWJsZWQsIGdldFFyVmlld1NldHRpbmcsIHNldFFyVmlld0VuYWJsZWQsXHJcbiAgICBnZXRUYWJsZVJlYWRpbmdWYWxpZGF0aW9uU2V0dGluZywgc2V0VGFibGVSZWFkaW5nVmFsaWRhdGlvbixcclxufSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgZ2V0Q29tYW5kYVNldHRpbmcsIHNldENvbWFuZGFEZWZhdWx0TGltaXQgfSBmcm9tIFwiLi4vY29tYW5kYXMvYXBpXCI7XHJcbmltcG9ydCB7IGdldEVtcGxveWVlc0J5QnJhbmNoIH0gZnJvbSBcIi4uL2VtcGxveWVlcy9hcGlcIjtcclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcclxuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vLi4vdWkvVG9hc3RcIjtcclxuaW1wb3J0IHsgU3dpdGNoIH0gZnJvbSBcIi4uLy4uL3VpL1N3aXRjaFwiO1xyXG5pbXBvcnQgeyBmb3JtYXRCUkwgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcblxyXG5jb25zdCBjYXJkcyA9IFtcclxuICAgIHsgdG86IFwiL1wiLCBsYWJlbDogXCJQZWRpZG9zXCIsIGRlc2M6IFwiQ29udHJvbGUgZGUgbWVzYXMgZSBjb21hbmRhc1wiIH0sXHJcbiAgICB7IHRvOiBcIi9kZWxpdmVyeVwiLCBsYWJlbDogXCJEZWxpdmVyeVwiLCBkZXNjOiBcIlBhaW5lbCBkZSBlbnRyZWdhcyBlIGV4cGVkacOnw6NvXCIgfSxcclxuICAgIHsgdG86IFwiL3ByZXBhcm9cIiwgbGFiZWw6IFwiUHJlcGFybyAoS0RTKVwiLCBkZXNjOiBcIk1vbml0b3IgZGUgY296aW5oYSBlIHByb2R1w6fDo29cIiB9LFxyXG4gICAgeyB0bzogXCIvZ2FyY29tXCIsIGxhYmVsOiBcIlZpc8OjbyBkbyBHYXLDp29tXCIsIGRlc2M6IFwiSW50ZXJmYWNlIGRlIGF0ZW5kaW1lbnRvIG5vIHNhbMOjb1wiIH0sXHJcbiAgICB7IHRvOiBcIi9wcmFjYXNcIiwgbGFiZWw6IFwiUHJhw6dhcyBlIFNhbMO1ZXNcIiwgZGVzYzogXCJHZXN0w6NvIGRlIMOhcmVhcywgbWVzYXMgZSB0dXJub3MgZGUgZ2Fyw6dvbnNcIiB9LFxyXG4gICAgeyB0bzogXCIvcHJvZHV0b3NcIiwgbGFiZWw6IFwiUHJvZHV0b3NcIiwgZGVzYzogXCJDYXTDoWxvZ28gZSBwcmXDp29zIGRvIGNhcmTDoXBpb1wiIH0sXHJcbiAgICB7IHRvOiBcIi9jb21wbGVtZW50b3NcIiwgbGFiZWw6IFwiQ29tcGxlbWVudG9zXCIsIGRlc2M6IFwiQWRpY2lvbmFpcywgYm9yZGFzIGUgdmFyaWHDp8O1ZXNcIiB9LFxyXG4gICAgeyB0bzogXCIvZXN0b3F1ZVwiLCBsYWJlbDogXCJFc3RvcXVlXCIsIGRlc2M6IFwiQ29udHJvbGUgZGUgaW52ZW50w6FyaW8gZSBpbnN1bW9zXCIgfSxcclxuICAgIHsgdG86IFwiL2NvbXByYXNcIiwgbGFiZWw6IFwiQ29tcHJhc1wiLCBkZXNjOiBcIkZvcm5lY2Vkb3JlcyBlIGVudHJhZGEgZGUgZXN0b3F1ZVwiIH0sXHJcbiAgICB7IHRvOiBcIi9jbGllbnRlc1wiLCBsYWJlbDogXCJDbGllbnRlc1wiLCBkZXNjOiBcIkNhZGFzdHJvIGUgZmlkZWxpZGFkZVwiIH0sXHJcbiAgICB7IHRvOiBcIi9yZXNlcnZhc1wiLCBsYWJlbDogXCJSZXNlcnZhc1wiLCBkZXNjOiBcIkFnZW5kYSBkZSByZXNlcnZhcyBkZSBtZXNhXCIgfSxcclxuICAgIHsgdG86IFwiL2VxdWlwZVwiLCBsYWJlbDogXCJFcXVpcGVcIiwgZGVzYzogXCJGdW5jaW9uw6FyaW9zIGUgY2FyZ29zXCIgfSxcclxuICAgIHsgdG86IFwiL3VzdWFyaW9zXCIsIGxhYmVsOiBcIlVzdcOhcmlvc1wiLCBkZXNjOiBcIkNvbnRhcyBkZSBhY2Vzc28gYW8gc2lzdGVtYVwiIH0sXHJcbiAgICB7IHRvOiBcIi9hY2Vzc29zXCIsIGxhYmVsOiBcIkFjZXNzb3NcIiwgZGVzYzogXCJQYXDDqWlzIGUgcGVybWlzc8O1ZXMgZG9zIHVzdcOhcmlvc1wiIH0sXHJcbiAgICB7IHRvOiBcIi9mYXR1cmFtZW50b1wiLCBsYWJlbDogXCJGYXR1cmFtZW50b1wiLCBkZXNjOiBcIkN1c3RvcyBlIG1ldGFzIGRvIG3DqnNcIiB9LFxyXG4gICAgeyB0bzogXCIvZmVjaGFtZW50b3NcIiwgbGFiZWw6IFwiRmVjaGFtZW50b3NcIiwgZGVzYzogXCJIaXN0w7NyaWNvIGRlIHNlc3PDtWVzIGRlIGNhaXhhXCIgfSxcclxuICAgIHsgdG86IFwiL3JlbGF0b3Jpb3NcIiwgbGFiZWw6IFwiUmVsYXTDs3Jpb3NcIiwgZGVzYzogXCJWZW5kYXMsIHByb2R1dG9zIGUgdGF4YSBkZSBzZXJ2acOnb1wiIH0sXHJcbiAgICB7IHRvOiBcIi9jZW5hcmlvc1wiLCBsYWJlbDogXCJDZW7DoXJpb3NcIiwgZGVzYzogXCJQcm9qZcOnw7VlcyBlIHNpbXVsYcOnw7Vlc1wiIH0sXHJcbiAgICB7IHRvOiBcIi9wcm9tb2NvZXNcIiwgbGFiZWw6IFwiUHJvbW/Dp8O1ZXNcIiwgZGVzYzogXCJPZmVydGFzIGUgZGVzY29udG9zIGF0aXZvc1wiIH0sXHJcbiAgICB7IHRvOiBcIi9pbXByZXNzYW9cIiwgbGFiZWw6IFwiSW1wcmVzc8Ojb1wiLCBkZXNjOiBcIkltcHJlc3NvcmFzIGUgY3Vwb25zXCIgfSxcclxuICAgIHsgdG86IFwiL2ludGVncmFjb2VzL2lmb29kXCIsIGxhYmVsOiBcIkludGVncmHDp8OjbyBpRm9vZFwiLCBkZXNjOiBcIkNyZWRlbmNpYWlzIGUgY29uZXjDo28gY29tIG8gaUZvb2RcIiB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNldHRpbmdzUGFnZSgpIHtcclxuICAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICAgIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICAgIGNvbnN0IHsgYnJhbmNoSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gICAgY29uc3QgW2xpbWl0SW5wdXQsIHNldExpbWl0SW5wdXRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbc2VsZlNlcnZpY2VFbXBsb3llZUlkLCBzZXRTZWxmU2VydmljZUVtcGxveWVlSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gICAgY29uc3QgZmVlUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcIm9yZGVyc1wiLCBcInNlcnZpY2UtZmVlLXNldHRpbmdcIiwgYnJhbmNoSWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldFNlcnZpY2VGZWVTZXR0aW5nKGJyYW5jaElkKSxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgZmVlRW5hYmxlZCA9IGZlZVF1ZXJ5LmRhdGE/LmVuYWJsZWQgPz8gdHJ1ZTtcclxuXHJcbiAgICBjb25zdCBmZWVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAobmV4dDogYm9vbGVhbikgPT4gc2V0U2VydmljZUZlZUVuYWJsZWQoYnJhbmNoSWQsIG5leHQpLFxyXG4gICAgICAgIG9uU3VjY2VzczogKF9kYXRhLCBuZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MobmV4dCA/IFwiVGF4YSBkZSBzZXJ2acOnbyAoMTAlKSBMSUdBREEuXCIgOiBcIlRheGEgZGUgc2VydmnDp28gKDEwJSkgREVTTElHQURBLlwiKTtcclxuICAgICAgICAgICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJvcmRlcnNcIiwgXCJzZXJ2aWNlLWZlZS1zZXR0aW5nXCJdIH0pO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgYWx0ZXJhciBhIHRheGEgZGUgc2VydmnDp28uXCIpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgcXJWaWV3UXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcIm9yZGVyc1wiLCBcInFyLXZpZXctc2V0dGluZ1wiLCBicmFuY2hJZF0sXHJcbiAgICAgICAgcXVlcnlGbjogKCkgPT4gZ2V0UXJWaWV3U2V0dGluZyhicmFuY2hJZCksXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IHFyVmlld0VuYWJsZWQgPSBxclZpZXdRdWVyeS5kYXRhPy5lbmFibGVkID8/IHRydWU7XHJcblxyXG4gICAgY29uc3QgcXJWaWV3TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKG5leHQ6IGJvb2xlYW4pID0+IHNldFFyVmlld0VuYWJsZWQoYnJhbmNoSWQsIG5leHQpLFxyXG4gICAgICAgIG9uU3VjY2VzczogKF9kYXRhLCBuZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MobmV4dCA/IFwiVmlzdWFsaXphw6fDo28gZG8gY2xpZW50ZSBMSUdBREEuXCIgOiBcIlZpc3VhbGl6YcOnw6NvIGRvIGNsaWVudGUgREVTTElHQURBLlwiKTtcclxuICAgICAgICAgICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJvcmRlcnNcIiwgXCJxci12aWV3LXNldHRpbmdcIl0gfSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBhbHRlcmFyIGEgdmlzdWFsaXphw6fDo28uXCIpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgcmVhZGluZ1ZhbGlkYXRpb25RdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgICAgICBxdWVyeUtleTogW1wib3JkZXJzXCIsIFwidGFibGUtcmVhZGluZy12YWxpZGF0aW9uLXNldHRpbmdcIiwgYnJhbmNoSWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldFRhYmxlUmVhZGluZ1ZhbGlkYXRpb25TZXR0aW5nKGJyYW5jaElkKSxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgcmVhZGluZ1ZhbGlkYXRpb24gPSByZWFkaW5nVmFsaWRhdGlvblF1ZXJ5LmRhdGEgPz8ge1xyXG4gICAgICAgIGlzQ2FtZXJhSW5wdXRFbmFibGVkOiBmYWxzZSxcclxuICAgICAgICBpc0JhcmNvZGVFbmFibGVkOiBmYWxzZSxcclxuICAgICAgICBpc1FyQ29kZUVuYWJsZWQ6IGZhbHNlLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCByZWFkaW5nVmFsaWRhdGlvbk11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46IChuZXh0OiB0eXBlb2YgcmVhZGluZ1ZhbGlkYXRpb24pID0+IHNldFRhYmxlUmVhZGluZ1ZhbGlkYXRpb24oYnJhbmNoSWQsIG5leHQpLFxyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiVmFsaWRhw6fDo28gZGUgbGVpdHVyYSBkYSBjb21hbmRhIGF0dWFsaXphZGEuXCIpO1xyXG4gICAgICAgICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcIm9yZGVyc1wiLCBcInRhYmxlLXJlYWRpbmctdmFsaWRhdGlvbi1zZXR0aW5nXCJdIH0pO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgYWx0ZXJhciBhIHZhbGlkYcOnw6NvIGRlIGxlaXR1cmEuXCIpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgdG9nZ2xlUmVhZGluZ1ZhbGlkYXRpb24gPSAoXHJcbiAgICAgICAgZmllbGQ6IGtleW9mIHR5cGVvZiByZWFkaW5nVmFsaWRhdGlvbixcclxuICAgICAgICBuZXh0OiBib29sZWFuLFxyXG4gICAgKSA9PiByZWFkaW5nVmFsaWRhdGlvbk11dGF0aW9uLm11dGF0ZSh7IC4uLnJlYWRpbmdWYWxpZGF0aW9uLCBbZmllbGRdOiBuZXh0IH0pO1xyXG5cclxuICAgIGNvbnN0IGNvbWFuZGFRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgICAgICBxdWVyeUtleTogW1wiY29tYW5kYXNcIiwgXCJzZXR0aW5nXCIsIGJyYW5jaElkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRDb21hbmRhU2V0dGluZyhicmFuY2hJZCksXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBsaW1pdE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46ICh2YWx1ZTogbnVtYmVyKSA9PiBzZXRDb21hbmRhRGVmYXVsdExpbWl0KGJyYW5jaElkLCB2YWx1ZSksXHJcbiAgICAgICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldExpbWl0SW5wdXQoXCJcIik7XHJcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJMaW1pdGUgZGUgY29tYW5kYSBhdHVhbGl6YWRvLlwiKTtcclxuICAgICAgICAgICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJjb21hbmRhc1wiLCBcInNldHRpbmdcIl0gfSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBzYWx2YXIgbyBsaW1pdGUuXCIpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgZW1wbG95ZWVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcImVtcGxveWVlc1wiLCBicmFuY2hJZF0sXHJcbiAgICAgICAgcXVlcnlGbjogKCkgPT4gZ2V0RW1wbG95ZWVzQnlCcmFuY2goYnJhbmNoSWQpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3Qgc2VsZlNlcnZpY2VNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAoZW1wbG95ZWVJZDogbnVtYmVyIHwgbnVsbCkgPT4gc2V0U2VsZlNlcnZpY2VFbXBsb3llZShicmFuY2hJZCwgZW1wbG95ZWVJZCksXHJcbiAgICAgICAgb25TdWNjZXNzOiAoKSA9PiB0b2FzdC5zdWNjZXNzKFwiRnVuY2lvbsOhcmlvIGRlIGF1dG9hdGVuZGltZW50byBhdHVhbGl6YWRvLlwiKSxcclxuICAgICAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBzYWx2YXIg4oCUIGNvbmZpcm1lIHF1ZSB2b2PDqiDDqSBhZG1pbmlzdHJhZG9yLlwiKSxcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMTAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMTggfX0+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuN3JlbVwiIH19PkNvbmZpZ3VyYcOnw7VlczwvaDI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIGdlc3TDo28gZGEgZmlsaWFsIOKAlCBzb21lbnRlIGdlcmVudGUvYWRtaW5pc3RyYWRvclxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsoZmVlUXVlcnkuaXNFcnJvciB8fCBxclZpZXdRdWVyeS5pc0Vycm9yIHx8IHJlYWRpbmdWYWxpZGF0aW9uUXVlcnkuaXNFcnJvcikgJiYgKFxyXG4gICAgICAgICAgICAgICAgPFF1ZXJ5RXJyb3IgZXJyb3I9e2ZlZVF1ZXJ5LmVycm9yIHx8IHFyVmlld1F1ZXJ5LmVycm9yIHx8IHJlYWRpbmdWYWxpZGF0aW9uUXVlcnkuZXJyb3J9IHdoYXQ9XCJhcyBjb25maWd1cmHDp8O1ZXNcIiAvPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidGlja2V0IHJpc2UgcmlzZS0xXCIgc3R5bGU9e3sgcGFkZGluZzogMjAsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE4IH19PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0LCBtYXhXaWR0aDogNTIwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+VGF4YSBkZSBzZXJ2acOnbyAoMTAlKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45MnJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUXVhbmRvIGRlc2xpZ2FkYSwgYXMgY29udGFzIGZlY2hhZGFzIG5lc3RhIGZpbGlhbCBuw6NvIGNvYnJhbSBvcyAxMCUgZSBhIHRheGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5lbSBhcGFyZWNlIG5hIGNvbnRhIGltcHJlc3NhLiBJZGVhbCBwYXJhIGV2ZW50b3Mgc2VtIHRheGEg4oCUIHZhbGUgcGFyYSBvIGRpYSBpbnRlaXJvLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDEyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGlwXCIgc3R5bGU9e3sgXCItLWRvdFwiOiBmZWVFbmFibGVkID8gXCJ2YXIoLS1vaylcIiA6IFwidmFyKC0taW5rLWZhaW50KVwiIH0gYXMgQ1NTUHJvcGVydGllc30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmVlRW5hYmxlZCA/IFwiTGlnYWRhXCIgOiBcIkRlc2xpZ2FkYVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTd2l0Y2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2ZlZUVuYWJsZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZmVlUXVlcnkuaXNMb2FkaW5nIHx8IGZlZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsobmV4dCkgPT4gZmVlTXV0YXRpb24ubXV0YXRlKG5leHQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJDb2JyYXIgdGF4YSBkZSBzZXJ2acOnbyBkZSAxMCVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBib3JkZXJUb3A6IFwiMXB4IHNvbGlkIHZhcigtLWxpbmUtc29mdClcIiB9fSAvPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBnYXA6IDE2IH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCwgbWF4V2lkdGg6IDUyMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMnJlbVwiIH19PlZpc3VhbGl6YcOnw6NvIGRvIGNsaWVudGUgKFFSIENvZGUpPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGllbnRlIHBvZGUgY29uc3VsdGFyIG8gdmFsb3IgdG90YWwgZGEgY29tYW5kYSBlIG9zIHBlZGlkb3MgbGFuw6dhZG9zIHZpYSBRUiBDb2RlIG5hIG1lc2EuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogMTIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNoaXBcIiBzdHlsZT17eyBcIi0tZG90XCI6IHFyVmlld0VuYWJsZWQgPyBcInZhcigtLW9rKVwiIDogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfSBhcyBDU1NQcm9wZXJ0aWVzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtxclZpZXdFbmFibGVkID8gXCJMaWdhZGFcIiA6IFwiRGVzbGlnYWRhXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFN3aXRjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cXJWaWV3RW5hYmxlZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtxclZpZXdRdWVyeS5pc0xvYWRpbmcgfHwgcXJWaWV3TXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhuZXh0KSA9PiBxclZpZXdNdXRhdGlvbi5tdXRhdGUobmV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkFwYXJlY2UgYSBvcMOnw6NvIGRlIG1lc2Egb3UgY29tYW5kYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJvcmRlclRvcDogXCIxcHggc29saWQgdmFyKC0tbGluZS1zb2Z0KVwiIH19IC8+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0LCBtYXhXaWR0aDogNTIwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+VmFsaWRhw6fDo28gZGUgbGVpdHVyYSBkYSBjb21hbmRhPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFeGlnZSB1bWEgY29uZmlybWHDp8OjbyBleHRyYSBhbyBhYnJpciBhIGNvbWFuZGEvbWVzYSwgcGVsb3MgY2Vuw6FyaW9zIGxpZ2Fkb3MgYWJhaXhvLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmFsZSBwYXJhIHRvZGFzIGFzIG1lc2FzIGRlc3RhIGZpbGlhbC5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93XCIgc3R5bGU9e3sgZ2FwOiAxMiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIsIG1pbldpZHRoOiAxMzAgfX0+Q8OibWVyYTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNoaXBcIiBzdHlsZT17eyBcIi0tZG90XCI6IHJlYWRpbmdWYWxpZGF0aW9uLmlzQ2FtZXJhSW5wdXRFbmFibGVkID8gXCJ2YXIoLS1vaylcIiA6IFwidmFyKC0taW5rLWZhaW50KVwiIH0gYXMgQ1NTUHJvcGVydGllc30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlYWRpbmdWYWxpZGF0aW9uLmlzQ2FtZXJhSW5wdXRFbmFibGVkID8gXCJMaWdhZGFcIiA6IFwiRGVzbGlnYWRhXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3dpdGNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cmVhZGluZ1ZhbGlkYXRpb24uaXNDYW1lcmFJbnB1dEVuYWJsZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRpbmdWYWxpZGF0aW9uUXVlcnkuaXNMb2FkaW5nIHx8IHJlYWRpbmdWYWxpZGF0aW9uTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsobmV4dCkgPT4gdG9nZ2xlUmVhZGluZ1ZhbGlkYXRpb24oXCJpc0NhbWVyYUlucHV0RW5hYmxlZFwiLCBuZXh0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkV4aWdpciBjYXB0dXJhIHBvciBjw6JtZXJhIG5hIGxlaXR1cmEgZGEgY29tYW5kYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDEyLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmspXCIsIGZvbnRTaXplOiBcIjAuOTJyZW1cIiwgbWluV2lkdGg6IDEzMCB9fT5Dw7NkaWdvIGRlIGJhcnJhczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNoaXBcIiBzdHlsZT17eyBcIi0tZG90XCI6IHJlYWRpbmdWYWxpZGF0aW9uLmlzQmFyY29kZUVuYWJsZWQgPyBcInZhcigtLW9rKVwiIDogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfSBhcyBDU1NQcm9wZXJ0aWVzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVhZGluZ1ZhbGlkYXRpb24uaXNCYXJjb2RlRW5hYmxlZCA/IFwiTGlnYWRhXCIgOiBcIkRlc2xpZ2FkYVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFN3aXRjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3JlYWRpbmdWYWxpZGF0aW9uLmlzQmFyY29kZUVuYWJsZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRpbmdWYWxpZGF0aW9uUXVlcnkuaXNMb2FkaW5nIHx8IHJlYWRpbmdWYWxpZGF0aW9uTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsobmV4dCkgPT4gdG9nZ2xlUmVhZGluZ1ZhbGlkYXRpb24oXCJpc0JhcmNvZGVFbmFibGVkXCIsIG5leHQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiRXhpZ2lyIGxlaXR1cmEgZGUgY8OzZGlnbyBkZSBiYXJyYXMgbmEgbGVpdHVyYSBkYSBjb21hbmRhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogMTIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluaylcIiwgZm9udFNpemU6IFwiMC45MnJlbVwiLCBtaW5XaWR0aDogMTMwIH19PlFSIENvZGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGlwXCIgc3R5bGU9e3sgXCItLWRvdFwiOiByZWFkaW5nVmFsaWRhdGlvbi5pc1FyQ29kZUVuYWJsZWQgPyBcInZhcigtLW9rKVwiIDogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfSBhcyBDU1NQcm9wZXJ0aWVzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVhZGluZ1ZhbGlkYXRpb24uaXNRckNvZGVFbmFibGVkID8gXCJMaWdhZGFcIiA6IFwiRGVzbGlnYWRhXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3dpdGNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cmVhZGluZ1ZhbGlkYXRpb24uaXNRckNvZGVFbmFibGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkaW5nVmFsaWRhdGlvblF1ZXJ5LmlzTG9hZGluZyB8fCByZWFkaW5nVmFsaWRhdGlvbk11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KG5leHQpID0+IHRvZ2dsZVJlYWRpbmdWYWxpZGF0aW9uKFwiaXNRckNvZGVFbmFibGVkXCIsIG5leHQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiRXhpZ2lyIGxlaXR1cmEgZGUgUVIgQ29kZSBuYSBsZWl0dXJhIGRhIGNvbWFuZGFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJvcmRlclRvcDogXCIxcHggc29saWQgdmFyKC0tbGluZS1zb2Z0KVwiIH19IC8+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0LCBtYXhXaWR0aDogNTIwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+TGltaXRlIGRlIGNvbWFuZGE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuOTJyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhbG9yIG3DoXhpbW8gZGUgY29uc3VtbyBwYWRyw6NvIHBhcmEgbm92YXMgY29tYW5kYXMgZGVzdGEgZmlsaWFsLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjb21hbmRhUXVlcnkuZGF0YSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGlwXCIgc3R5bGU9e3sgXCItLWRvdFwiOiBcInZhcigtLWJ1c3kpXCIgfSBhcyBDU1NQcm9wZXJ0aWVzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHVhbCB7Zm9ybWF0QlJMKGNvbWFuZGFRdWVyeS5kYXRhLmRlZmF1bHRMaW1pdEFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJub3ZvIGxpbWl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtsaW1pdElucHV0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRMaW1pdElucHV0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAxMzAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xpbWl0TXV0YXRpb24uaXNQZW5kaW5nIHx8IGxpbWl0SW5wdXQudHJpbSgpID09PSBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gTnVtYmVyKGxpbWl0SW5wdXQucmVwbGFjZShcIixcIiwgXCIuXCIpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoTnVtYmVyLmlzRmluaXRlKHZhbHVlKSAmJiB2YWx1ZSA+IDApIGxpbWl0TXV0YXRpb24ubXV0YXRlKHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNhbHZhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lLXNvZnQpXCIgfX0gLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgZ2FwOiAxNiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIG1heFdpZHRoOiA1MjAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5BdXRvYXRlbmRpbWVudG8gKFFSIENvZGUpPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBGdW5jaW9uw6FyaW8gcXVlIFwiYWJyZVwiIG9zIHBlZGlkb3MgbGFuw6dhZG9zIHBvciBjbGllbnRlcyB2aWEgUVIgQ29kZSBuYSBtZXNhLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgT2JyaWdhdMOzcmlvIGNvbmZpZ3VyYXIgYW50ZXMgZGUgZ2VyYXIgUVIgQ29kZXMgZW0gU2Fsw6NvLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxmU2VydmljZUVtcGxveWVlSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGZTZXJ2aWNlRW1wbG95ZWVJZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2lvbmXigKY8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoZW1wbG95ZWVzUXVlcnkuZGF0YSA/PyBbXSkuZmlsdGVyKChlKSA9PiBlLmlzQWN0aXZlKS5tYXAoKGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZS5pZH0gdmFsdWU9e2UuaWR9PntlLm5hbWV9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZWxmU2VydmljZUVtcGxveWVlSWQgPT09IFwiXCIgfHwgc2VsZlNlcnZpY2VNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZWxmU2VydmljZU11dGF0aW9uLm11dGF0ZShOdW1iZXIoc2VsZlNlcnZpY2VFbXBsb3llZUlkKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNhbHZhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZGlzcGxheSByaXNlIHJpc2UtMlwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMnJlbVwiLCBtYXJnaW46IFwiMjZweCAwIDEycHhcIiB9fT5cclxuICAgICAgICAgICAgICAgIE5hdmVnYcOnw6NvIGRvIFNpc3RlbWFcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMlwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBncmlkVGVtcGxhdGVDb2x1bW5zOiBcInJlcGVhdChhdXRvLWZpbGwsIG1pbm1heCgyMzBweCwgMWZyKSlcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICAgICAgICAgIHtjYXJkcy5tYXAoKGNhcmQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8TGluayBrZXk9e2NhcmQudG99IHRvPXtjYXJkLnRvfSBjbGFzc05hbWU9XCJ0aWNrZXRcIiBzdHlsZT17eyBwYWRkaW5nOiBcIjE2cHggMThweFwiLCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0LCB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsIG1pbkhlaWdodDogODQgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjA1cmVtXCIsIGNvbG9yOiBcInZhcigtLWluaylcIiB9fT57Y2FyZC5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODZyZW1cIiB9fT57Y2FyZC5kZXNjfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9tYWluPlxyXG4gICAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9zZXR0aW5ncy9TZXR0aW5nc1BhZ2UudHN4In0=