import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/access/AccessPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  getFeatures,
  getJobTitleFeatures,
  getUserFeatures,
  setJobTitleFeatures,
  setUserFeatures
} from "/src/features/access/api.ts";
import { getJobTitles } from "/src/features/employees/api.ts";
import { getUsersByCompany } from "/src/features/users/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { QueryError } from "/src/components/QueryError.tsx";
export function AccessPage() {
  _s();
  const queryClient = useQueryClient();
  const { companyId } = useAuthStore();
  const [mode, setMode] = useState("cargo");
  const [targetId, setTargetId] = useState("");
  const [selected, setSelected] = useState([]);
  const [error, setError] = useState(null);
  const [saved, setSaved] = useState(false);
  const featuresQuery = useQuery({ queryKey: ["access", "features"], queryFn: getFeatures });
  const jobTitlesQuery = useQuery({
    queryKey: ["jobtitles", companyId],
    queryFn: () => getJobTitles(companyId ?? 1),
    enabled: mode === "cargo"
  });
  const usersQuery = useQuery({
    queryKey: ["users", companyId],
    queryFn: () => getUsersByCompany(companyId ?? 1),
    enabled: mode === "pessoa"
  });
  const grantsQuery = useQuery({
    queryKey: ["access", mode, targetId],
    queryFn: () => mode === "cargo" ? getJobTitleFeatures(Number(targetId)) : getUserFeatures(Number(targetId)),
    enabled: targetId !== ""
  });
  const grants = grantsQuery.data;
  const [loadedFor, setLoadedFor] = useState("");
  if (grants !== void 0 && loadedFor !== `${mode}:${targetId}`) {
    setSelected(grants);
    setLoadedFor(`${mode}:${targetId}`);
  }
  const saveMutation = useMutation({
    mutationFn: () => mode === "cargo" ? setJobTitleFeatures(Number(targetId), selected) : setUserFeatures(Number(targetId), selected),
    onSuccess: () => {
      setError(null);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
      void queryClient.invalidateQueries({ queryKey: ["access"] });
    },
    onError: (e) => setError(e instanceof ApiError ? e.message : "Falha ao salvar.")
  });
  const switchMode = (next) => {
    setMode(next);
    setTargetId("");
    setSelected([]);
    setLoadedFor("");
    setError(null);
  };
  const toggle = (featureId) => setSelected(
    (current) => current.includes(featureId) ? current.filter((id) => id !== featureId) : [...current, featureId]
  );
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 760, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "grid", gap: 6, marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Acessos" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
        lineNumber: 104,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "O acesso efetivo de cada pessoa é a união do que o cargo dá com o que foi concedido individualmente. Gerente e Administrador sempre veem tudo." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
      lineNumber: 103,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rise rise-1", style: { display: "flex", gap: 8, marginBottom: 14 }, children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: mode === "cargo" ? "btn-primary" : "btn-ghost",
          onClick: () => switchMode("cargo"),
          children: "Por cargo"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
          lineNumber: 112,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: mode === "pessoa" ? "btn-primary" : "btn-ghost",
          onClick: () => switchMode("pessoa"),
          children: "Por pessoa"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
          lineNumber: 119,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
      lineNumber: 111,
      columnNumber: 7
    }, this),
    featuresQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: featuresQuery.error, what: "as telas" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
      lineNumber: 128,
      columnNumber: 33
    }, this),
    jobTitlesQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: jobTitlesQuery.error, what: "os cargos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
      lineNumber: 129,
      columnNumber: 34
    }, this),
    usersQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: usersQuery.error, what: "os usuários" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
      lineNumber: 130,
      columnNumber: 30
    }, this),
    grantsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: grantsQuery.error, what: "os acessos atuais" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
      lineNumber: 131,
      columnNumber: 31
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rise rise-2", style: { display: "grid", gap: 14 }, children: [
      /* @__PURE__ */ jsxDEV("select", { value: targetId, onChange: (e) => {
        setTargetId(e.target.value);
        setLoadedFor("");
      }, children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: mode === "cargo" ? "Selecione o cargo…" : "Selecione a pessoa…" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
          lineNumber: 135,
          columnNumber: 11
        }, this),
        mode === "cargo" ? (jobTitlesQuery.data ?? []).map(
          (j) => /* @__PURE__ */ jsxDEV("option", { value: j.id, children: j.name }, j.id, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
            lineNumber: 138,
            columnNumber: 11
          }, this)
        ) : (usersQuery.data ?? []).filter((u) => u.isActive).map(
          (u) => /* @__PURE__ */ jsxDEV("option", { value: u.id, children: [
            u.userName,
            " (",
            u.email,
            ")"
          ] }, u.id, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
            lineNumber: 143,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
        lineNumber: 134,
        columnNumber: 9
      }, this),
      targetId !== "" && /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 18, display: "grid", gap: 10 }, children: [
        (featuresQuery.data ?? []).map(
          (feature) => /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", gap: 12, alignItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                style: { width: 22, minHeight: 22 },
                checked: selected.includes(feature.id),
                onChange: () => toggle(feature.id)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
                lineNumber: 151,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { children: feature.name }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
              lineNumber: 157,
              columnNumber: 17
            }, this)
          ] }, feature.id, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
            lineNumber: 150,
            columnNumber: 11
          }, this)
        ),
        mode === "pessoa" && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.82rem" }, children: "Marque apenas os EXTRAS desta pessoa — o que vem do cargo já está garantido." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
          lineNumber: 161,
          columnNumber: 11
        }, this),
        error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
          lineNumber: 165,
          columnNumber: 23
        }, this),
        saved && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ok)", margin: 0 }, children: "Acessos salvos." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
          lineNumber: 166,
          columnNumber: 23
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "btn-primary",
            disabled: saveMutation.isPending || grantsQuery.isLoading,
            onClick: () => saveMutation.mutate(),
            children: saveMutation.isPending ? "Salvando…" : "Salvar acessos"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
            lineNumber: 167,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
        lineNumber: 148,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
      lineNumber: 133,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx",
    lineNumber: 102,
    columnNumber: 5
  }, this);
}
_s(AccessPage, "7LkrtDOK2iyB6eoseveT1lAbLng=", false, function() {
  return [useQueryClient, useAuthStore, useQuery, useQuery, useQuery, useQuery, useMutation];
});
_c = AccessPage;
var _c;
$RefreshReg$(_c, "AccessPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/access/AccessPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0ZROzs7Ozs7Ozs7Ozs7Ozs7OztBQXBGUCxTQUFTQSxnQkFBZ0I7QUFDMUIsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3REO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxrQkFBa0I7QUFJcEIsZ0JBQVNDLGFBQWE7QUFBQUMsS0FBQTtBQUMzQixRQUFNQyxjQUFjYixlQUFlO0FBQ25DLFFBQU0sRUFBRWMsVUFBVSxJQUFJTixhQUFhO0FBQ25DLFFBQU0sQ0FBQ08sTUFBTUMsT0FBTyxJQUFJbkIsU0FBZSxPQUFPO0FBQzlDLFFBQU0sQ0FBQ29CLFVBQVVDLFdBQVcsSUFBSXJCLFNBQWlCLEVBQUU7QUFDbkQsUUFBTSxDQUFDc0IsVUFBVUMsV0FBVyxJQUFJdkIsU0FBbUIsRUFBRTtBQUNyRCxRQUFNLENBQUN3QixPQUFPQyxRQUFRLElBQUl6QixTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQzBCLE9BQU9DLFFBQVEsSUFBSTNCLFNBQVMsS0FBSztBQUV4QyxRQUFNNEIsZ0JBQWdCMUIsU0FBUyxFQUFFMkIsVUFBVSxDQUFDLFVBQVUsVUFBVSxHQUFHQyxTQUFTMUIsWUFBWSxDQUFDO0FBRXpGLFFBQU0yQixpQkFBaUI3QixTQUFTO0FBQUEsSUFDOUIyQixVQUFVLENBQUMsYUFBYVosU0FBUztBQUFBLElBQ2pDYSxTQUFTQSxNQUFNckIsYUFBYVEsYUFBYSxDQUFDO0FBQUEsSUFDMUNlLFNBQVNkLFNBQVM7QUFBQSxFQUNwQixDQUFDO0FBRUQsUUFBTWUsYUFBYS9CLFNBQVM7QUFBQSxJQUMxQjJCLFVBQVUsQ0FBQyxTQUFTWixTQUFTO0FBQUEsSUFDN0JhLFNBQVNBLE1BQU1wQixrQkFBa0JPLGFBQWEsQ0FBQztBQUFBLElBQy9DZSxTQUFTZCxTQUFTO0FBQUEsRUFDcEIsQ0FBQztBQUVELFFBQU1nQixjQUFjaEMsU0FBUztBQUFBLElBQzNCMkIsVUFBVSxDQUFDLFVBQVVYLE1BQU1FLFFBQVE7QUFBQSxJQUNuQ1UsU0FBU0EsTUFDUFosU0FBUyxVQUFVYixvQkFBb0I4QixPQUFPZixRQUFRLENBQUMsSUFBSWQsZ0JBQWdCNkIsT0FBT2YsUUFBUSxDQUFDO0FBQUEsSUFDN0ZZLFNBQVNaLGFBQWE7QUFBQSxFQUN4QixDQUFDO0FBRUQsUUFBTWdCLFNBQVNGLFlBQVlHO0FBQzNCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJdkMsU0FBaUIsRUFBRTtBQUNyRCxNQUFJb0MsV0FBV0ksVUFBYUYsY0FBYyxHQUFHcEIsSUFBSSxJQUFJRSxRQUFRLElBQUk7QUFDL0RHLGdCQUFZYSxNQUFNO0FBQ2xCRyxpQkFBYSxHQUFHckIsSUFBSSxJQUFJRSxRQUFRLEVBQUU7QUFBQSxFQUNwQztBQUVBLFFBQU1xQixlQUFleEMsWUFBWTtBQUFBLElBQy9CeUMsWUFBWUEsTUFDVnhCLFNBQVMsVUFDTFgsb0JBQW9CNEIsT0FBT2YsUUFBUSxHQUFHRSxRQUFRLElBQzlDZCxnQkFBZ0IyQixPQUFPZixRQUFRLEdBQUdFLFFBQVE7QUFBQSxJQUNoRHFCLFdBQVdBLE1BQU07QUFDZmxCLGVBQVMsSUFBSTtBQUNiRSxlQUFTLElBQUk7QUFDYmlCLGlCQUFXLE1BQU1qQixTQUFTLEtBQUssR0FBRyxJQUFJO0FBQ3RDLFdBQUtYLFlBQVk2QixrQkFBa0IsRUFBRWhCLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUFBLElBQzdEO0FBQUEsSUFDQWlCLFNBQVNBLENBQUNDLE1BQU10QixTQUFTc0IsYUFBYW5DLFdBQVdtQyxFQUFFQyxVQUFVLGtCQUFrQjtBQUFBLEVBQ2pGLENBQUM7QUFFRCxRQUFNQyxhQUFhQSxDQUFDQyxTQUFlO0FBQ2pDL0IsWUFBUStCLElBQUk7QUFDWjdCLGdCQUFZLEVBQUU7QUFDZEUsZ0JBQVksRUFBRTtBQUNkZ0IsaUJBQWEsRUFBRTtBQUNmZCxhQUFTLElBQUk7QUFBQSxFQUNmO0FBRUEsUUFBTTBCLFNBQVNBLENBQUNDLGNBQ2Q3QjtBQUFBQSxJQUFZLENBQUM4QixZQUNYQSxRQUFRQyxTQUFTRixTQUFTLElBQUlDLFFBQVFFLE9BQU8sQ0FBQ0MsT0FBT0EsT0FBT0osU0FBUyxJQUFJLENBQUMsR0FBR0MsU0FBU0QsU0FBUztBQUFBLEVBQ2pHO0FBRUYsU0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUssU0FBUyxJQUFJQyxVQUFVLEtBQUtDLFFBQVEsU0FBUyxHQUMxRDtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRUMsU0FBUyxRQUFRQyxLQUFLLEdBQUdDLGNBQWMsR0FBRyxHQUN2RTtBQUFBLDZCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxTQUFTLEdBQUcsdUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEQ7QUFBQSxNQUM5RCx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxvQkFBb0JELFVBQVUsU0FBUyxHQUFHLDhKQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQWMsT0FBTyxFQUFFSCxTQUFTLFFBQVFDLEtBQUssR0FBR0MsY0FBYyxHQUFHLEdBQzlFO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVc1QyxTQUFTLFVBQVUsZ0JBQWdCO0FBQUEsVUFDOUMsU0FBUyxNQUFNK0IsV0FBVyxPQUFPO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFIckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxXQUFXL0IsU0FBUyxXQUFXLGdCQUFnQjtBQUFBLFVBQy9DLFNBQVMsTUFBTStCLFdBQVcsUUFBUTtBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUVDckIsY0FBY3FDLFdBQVcsdUJBQUMsY0FBVyxPQUFPckMsY0FBY0osT0FBTyxNQUFLLGNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUQ7QUFBQSxJQUNoRk8sZUFBZWtDLFdBQVcsdUJBQUMsY0FBVyxPQUFPbEMsZUFBZVAsT0FBTyxNQUFLLGVBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQ7QUFBQSxJQUNuRlMsV0FBV2dDLFdBQVcsdUJBQUMsY0FBVyxPQUFPaEMsV0FBV1QsT0FBTyxNQUFLLGlCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVEO0FBQUEsSUFDN0VVLFlBQVkrQixXQUFXLHVCQUFDLGNBQVcsT0FBTy9CLFlBQVlWLE9BQU8sTUFBSyx1QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RDtBQUFBLElBRXRGLHVCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU8sRUFBRW9DLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQzdEO0FBQUEsNkJBQUMsWUFBTyxPQUFPekMsVUFBVSxVQUFVLENBQUMyQixNQUFNO0FBQUUxQixvQkFBWTBCLEVBQUVtQixPQUFPQyxLQUFLO0FBQUc1QixxQkFBYSxFQUFFO0FBQUEsTUFBRyxHQUN6RjtBQUFBLCtCQUFDLFlBQU8sT0FBTSxJQUFJckIsbUJBQVMsVUFBVSx1QkFBdUIseUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUNqRkEsU0FBUyxXQUNMYSxlQUFlTSxRQUFRLElBQUkrQjtBQUFBQSxVQUFJLENBQUNDLE1BQy9CLHVCQUFDLFlBQWtCLE9BQU9BLEVBQUViLElBQUthLFlBQUVDLFFBQXRCRCxFQUFFYixJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsUUFDekMsS0FDQXZCLFdBQVdJLFFBQVEsSUFDakJrQixPQUFPLENBQUNnQixNQUFNQSxFQUFFQyxRQUFRLEVBQ3hCSjtBQUFBQSxVQUFJLENBQUNHLE1BQ0osdUJBQUMsWUFBa0IsT0FBT0EsRUFBRWYsSUFBS2U7QUFBQUEsY0FBRUU7QUFBQUEsWUFBUztBQUFBLFlBQUdGLEVBQUVHO0FBQUFBLFlBQU07QUFBQSxlQUExQ0gsRUFBRWYsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFFBQ3pEO0FBQUEsV0FWVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUVDcEMsYUFBYSxNQUNaLHVCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRXFDLFNBQVMsSUFBSUcsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDbkVqQztBQUFBQSx1QkFBY1MsUUFBUSxJQUFJK0I7QUFBQUEsVUFBSSxDQUFDTyxZQUMvQix1QkFBQyxXQUF1QixPQUFPLEVBQUVmLFNBQVMsUUFBUUMsS0FBSyxJQUFJZSxZQUFZLFNBQVMsR0FDOUU7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPLEVBQUVDLE9BQU8sSUFBSUMsV0FBVyxHQUFHO0FBQUEsZ0JBQ2xDLFNBQVN4RCxTQUFTZ0MsU0FBU3FCLFFBQVFuQixFQUFFO0FBQUEsZ0JBQ3JDLFVBQVUsTUFBTUwsT0FBT3dCLFFBQVFuQixFQUFFO0FBQUE7QUFBQSxjQUpuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJcUM7QUFBQSxZQUVyQyx1QkFBQyxVQUFNbUIsa0JBQVFMLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0I7QUFBQSxlQVBWSyxRQUFRbkIsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFFBQ0Q7QUFBQSxRQUNBdEMsU0FBUyxZQUNSLHVCQUFDLFVBQUssT0FBTyxFQUFFOEMsT0FBTyxvQkFBb0JELFVBQVUsVUFBVSxHQUFHLDRGQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVEdkMsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxRQUMxQ0UsU0FBUyx1QkFBQyxPQUFFLE9BQU8sRUFBRXNDLE9BQU8sYUFBYUwsUUFBUSxFQUFFLEdBQUcsK0JBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEQ7QUFBQSxRQUN0RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ1YsVUFBVWxCLGFBQWFzQyxhQUFhN0MsWUFBWThDO0FBQUFBLFlBQ2hELFNBQVMsTUFBTXZDLGFBQWF3QyxPQUFPO0FBQUEsWUFFbEN4Qyx1QkFBYXNDLFlBQVksY0FBYztBQUFBO0FBQUEsVUFOMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsU0ExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRDQTtBQUFBLE9BM0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0RUE7QUFFSjtBQUFDaEUsR0EvSWVELFlBQVU7QUFBQSxVQUNKWCxnQkFDRVEsY0FPQVQsVUFFQ0EsVUFNSkEsVUFNQ0EsVUFjQ0QsV0FBVztBQUFBO0FBQUEsS0FyQ2xCYTtBQUFVLElBQUFvRTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsImdldEZlYXR1cmVzIiwiZ2V0Sm9iVGl0bGVGZWF0dXJlcyIsImdldFVzZXJGZWF0dXJlcyIsInNldEpvYlRpdGxlRmVhdHVyZXMiLCJzZXRVc2VyRmVhdHVyZXMiLCJnZXRKb2JUaXRsZXMiLCJnZXRVc2Vyc0J5Q29tcGFueSIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwiUXVlcnlFcnJvciIsIkFjY2Vzc1BhZ2UiLCJfcyIsInF1ZXJ5Q2xpZW50IiwiY29tcGFueUlkIiwibW9kZSIsInNldE1vZGUiLCJ0YXJnZXRJZCIsInNldFRhcmdldElkIiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsImVycm9yIiwic2V0RXJyb3IiLCJzYXZlZCIsInNldFNhdmVkIiwiZmVhdHVyZXNRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImpvYlRpdGxlc1F1ZXJ5IiwiZW5hYmxlZCIsInVzZXJzUXVlcnkiLCJncmFudHNRdWVyeSIsIk51bWJlciIsImdyYW50cyIsImRhdGEiLCJsb2FkZWRGb3IiLCJzZXRMb2FkZWRGb3IiLCJ1bmRlZmluZWQiLCJzYXZlTXV0YXRpb24iLCJtdXRhdGlvbkZuIiwib25TdWNjZXNzIiwic2V0VGltZW91dCIsImludmFsaWRhdGVRdWVyaWVzIiwib25FcnJvciIsImUiLCJtZXNzYWdlIiwic3dpdGNoTW9kZSIsIm5leHQiLCJ0b2dnbGUiLCJmZWF0dXJlSWQiLCJjdXJyZW50IiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJpZCIsInBhZGRpbmciLCJtYXhXaWR0aCIsIm1hcmdpbiIsImRpc3BsYXkiLCJnYXAiLCJtYXJnaW5Cb3R0b20iLCJmb250U2l6ZSIsImNvbG9yIiwiaXNFcnJvciIsInRhcmdldCIsInZhbHVlIiwibWFwIiwiaiIsIm5hbWUiLCJ1IiwiaXNBY3RpdmUiLCJ1c2VyTmFtZSIsImVtYWlsIiwiZmVhdHVyZSIsImFsaWduSXRlbXMiLCJ3aWR0aCIsIm1pbkhlaWdodCIsImlzUGVuZGluZyIsImlzTG9hZGluZyIsIm11dGF0ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFjY2Vzc1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7XHJcbiAgZ2V0RmVhdHVyZXMsXHJcbiAgZ2V0Sm9iVGl0bGVGZWF0dXJlcyxcclxuICBnZXRVc2VyRmVhdHVyZXMsXHJcbiAgc2V0Sm9iVGl0bGVGZWF0dXJlcyxcclxuICBzZXRVc2VyRmVhdHVyZXMsXHJcbn0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IGdldEpvYlRpdGxlcyB9IGZyb20gXCIuLi9lbXBsb3llZXMvYXBpXCI7XHJcbmltcG9ydCB7IGdldFVzZXJzQnlDb21wYW55IH0gZnJvbSBcIi4uL3VzZXJzL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi8uLi9saWIvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcblxyXG50eXBlIE1vZGUgPSBcImNhcmdvXCIgfCBcInBlc3NvYVwiO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEFjY2Vzc1BhZ2UoKSB7XHJcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgY29tcGFueUlkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbbW9kZSwgc2V0TW9kZV0gPSB1c2VTdGF0ZTxNb2RlPihcImNhcmdvXCIpO1xyXG4gIGNvbnN0IFt0YXJnZXRJZCwgc2V0VGFyZ2V0SWRdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlPG51bWJlcltdPihbXSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbc2F2ZWQsIHNldFNhdmVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgZmVhdHVyZXNRdWVyeSA9IHVzZVF1ZXJ5KHsgcXVlcnlLZXk6IFtcImFjY2Vzc1wiLCBcImZlYXR1cmVzXCJdLCBxdWVyeUZuOiBnZXRGZWF0dXJlcyB9KTtcclxuXHJcbiAgY29uc3Qgam9iVGl0bGVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiam9idGl0bGVzXCIsIGNvbXBhbnlJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRKb2JUaXRsZXMoY29tcGFueUlkID8/IDEpLFxyXG4gICAgZW5hYmxlZDogbW9kZSA9PT0gXCJjYXJnb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB1c2Vyc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcInVzZXJzXCIsIGNvbXBhbnlJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRVc2Vyc0J5Q29tcGFueShjb21wYW55SWQgPz8gMSksXHJcbiAgICBlbmFibGVkOiBtb2RlID09PSBcInBlc3NvYVwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBncmFudHNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJhY2Nlc3NcIiwgbW9kZSwgdGFyZ2V0SWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT5cclxuICAgICAgbW9kZSA9PT0gXCJjYXJnb1wiID8gZ2V0Sm9iVGl0bGVGZWF0dXJlcyhOdW1iZXIodGFyZ2V0SWQpKSA6IGdldFVzZXJGZWF0dXJlcyhOdW1iZXIodGFyZ2V0SWQpKSxcclxuICAgIGVuYWJsZWQ6IHRhcmdldElkICE9PSBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBncmFudHMgPSBncmFudHNRdWVyeS5kYXRhO1xyXG4gIGNvbnN0IFtsb2FkZWRGb3IsIHNldExvYWRlZEZvcl0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xyXG4gIGlmIChncmFudHMgIT09IHVuZGVmaW5lZCAmJiBsb2FkZWRGb3IgIT09IGAke21vZGV9OiR7dGFyZ2V0SWR9YCkge1xyXG4gICAgc2V0U2VsZWN0ZWQoZ3JhbnRzKTtcclxuICAgIHNldExvYWRlZEZvcihgJHttb2RlfToke3RhcmdldElkfWApO1xyXG4gIH1cclxuXHJcbiAgY29uc3Qgc2F2ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgbW9kZSA9PT0gXCJjYXJnb1wiXHJcbiAgICAgICAgPyBzZXRKb2JUaXRsZUZlYXR1cmVzKE51bWJlcih0YXJnZXRJZCksIHNlbGVjdGVkKVxyXG4gICAgICAgIDogc2V0VXNlckZlYXR1cmVzKE51bWJlcih0YXJnZXRJZCksIHNlbGVjdGVkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgc2V0U2F2ZWQodHJ1ZSk7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U2F2ZWQoZmFsc2UpLCAyNTAwKTtcclxuICAgICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJhY2Nlc3NcIl0gfSk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKGUpID0+IHNldEVycm9yKGUgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGUubWVzc2FnZSA6IFwiRmFsaGEgYW8gc2FsdmFyLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc3dpdGNoTW9kZSA9IChuZXh0OiBNb2RlKSA9PiB7XHJcbiAgICBzZXRNb2RlKG5leHQpO1xyXG4gICAgc2V0VGFyZ2V0SWQoXCJcIik7XHJcbiAgICBzZXRTZWxlY3RlZChbXSk7XHJcbiAgICBzZXRMb2FkZWRGb3IoXCJcIik7XHJcbiAgICBzZXRFcnJvcihudWxsKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB0b2dnbGUgPSAoZmVhdHVyZUlkOiBudW1iZXIpID0+XHJcbiAgICBzZXRTZWxlY3RlZCgoY3VycmVudCkgPT5cclxuICAgICAgY3VycmVudC5pbmNsdWRlcyhmZWF0dXJlSWQpID8gY3VycmVudC5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gZmVhdHVyZUlkKSA6IFsuLi5jdXJyZW50LCBmZWF0dXJlSWRdLFxyXG4gICAgKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIHN0eWxlPXt7IHBhZGRpbmc6IDIyLCBtYXhXaWR0aDogNzYwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDYsIG1hcmdpbkJvdHRvbTogMTggfX0+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjdyZW1cIiB9fT5BY2Vzc29zPC9oMj5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgTyBhY2Vzc28gZWZldGl2byBkZSBjYWRhIHBlc3NvYSDDqSBhIHVuacOjbyBkbyBxdWUgbyBjYXJnbyBkw6EgY29tIG8gcXVlIGZvaVxyXG4gICAgICAgICAgY29uY2VkaWRvIGluZGl2aWR1YWxtZW50ZS4gR2VyZW50ZSBlIEFkbWluaXN0cmFkb3Igc2VtcHJlIHZlZW0gdHVkby5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDgsIG1hcmdpbkJvdHRvbTogMTQgfX0+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9e21vZGUgPT09IFwiY2FyZ29cIiA/IFwiYnRuLXByaW1hcnlcIiA6IFwiYnRuLWdob3N0XCJ9XHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzd2l0Y2hNb2RlKFwiY2FyZ29cIil9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgUG9yIGNhcmdvXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9e21vZGUgPT09IFwicGVzc29hXCIgPyBcImJ0bi1wcmltYXJ5XCIgOiBcImJ0bi1naG9zdFwifVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc3dpdGNoTW9kZShcInBlc3NvYVwiKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBQb3IgcGVzc29hXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge2ZlYXR1cmVzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17ZmVhdHVyZXNRdWVyeS5lcnJvcn0gd2hhdD1cImFzIHRlbGFzXCIgLz59XHJcbiAgICAgIHtqb2JUaXRsZXNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtqb2JUaXRsZXNRdWVyeS5lcnJvcn0gd2hhdD1cIm9zIGNhcmdvc1wiIC8+fVxyXG4gICAgICB7dXNlcnNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXt1c2Vyc1F1ZXJ5LmVycm9yfSB3aGF0PVwib3MgdXN1w6FyaW9zXCIgLz59XHJcbiAgICAgIHtncmFudHNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtncmFudHNRdWVyeS5lcnJvcn0gd2hhdD1cIm9zIGFjZXNzb3MgYXR1YWlzXCIgLz59XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2UgcmlzZS0yXCIgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQgfX0+XHJcbiAgICAgICAgPHNlbGVjdCB2YWx1ZT17dGFyZ2V0SWR9IG9uQ2hhbmdlPXsoZSkgPT4geyBzZXRUYXJnZXRJZChlLnRhcmdldC52YWx1ZSk7IHNldExvYWRlZEZvcihcIlwiKTsgfX0+XHJcbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e21vZGUgPT09IFwiY2FyZ29cIiA/IFwiU2VsZWNpb25lIG8gY2FyZ2/igKZcIiA6IFwiU2VsZWNpb25lIGEgcGVzc29h4oCmXCJ9PC9vcHRpb24+XHJcbiAgICAgICAgICB7bW9kZSA9PT0gXCJjYXJnb1wiXHJcbiAgICAgICAgICAgID8gKGpvYlRpdGxlc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgoaikgPT4gKFxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2ouaWR9IHZhbHVlPXtqLmlkfT57ai5uYW1lfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgIDogKHVzZXJzUXVlcnkuZGF0YSA/PyBbXSlcclxuICAgICAgICAgICAgICAgIC5maWx0ZXIoKHUpID0+IHUuaXNBY3RpdmUpXHJcbiAgICAgICAgICAgICAgICAubWFwKCh1KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt1LmlkfSB2YWx1ZT17dS5pZH0+e3UudXNlck5hbWV9ICh7dS5lbWFpbH0pPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICA8L3NlbGVjdD5cclxuXHJcbiAgICAgICAge3RhcmdldElkICE9PSBcIlwiICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0XCIgc3R5bGU9e3sgcGFkZGluZzogMTgsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgICB7KGZlYXR1cmVzUXVlcnkuZGF0YSA/PyBbXSkubWFwKChmZWF0dXJlKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGxhYmVsIGtleT17ZmVhdHVyZS5pZH0gc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIyLCBtaW5IZWlnaHQ6IDIyIH19XHJcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkLmluY2x1ZGVzKGZlYXR1cmUuaWQpfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gdG9nZ2xlKGZlYXR1cmUuaWQpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPntmZWF0dXJlLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICB7bW9kZSA9PT0gXCJwZXNzb2FcIiAmJiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjgycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICBNYXJxdWUgYXBlbmFzIG9zIEVYVFJBUyBkZXN0YSBwZXNzb2Eg4oCUIG8gcXVlIHZlbSBkbyBjYXJnbyBqw6EgZXN0w6EgZ2FyYW50aWRvLlxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuICAgICAgICAgICAge3NhdmVkICYmIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLW9rKVwiLCBtYXJnaW46IDAgfX0+QWNlc3NvcyBzYWx2b3MuPC9wPn1cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2ZU11dGF0aW9uLmlzUGVuZGluZyB8fCBncmFudHNRdWVyeS5pc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2F2ZU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3NhdmVNdXRhdGlvbi5pc1BlbmRpbmcgPyBcIlNhbHZhbmRv4oCmXCIgOiBcIlNhbHZhciBhY2Vzc29zXCJ9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvYWNjZXNzL0FjY2Vzc1BhZ2UudHN4In0=