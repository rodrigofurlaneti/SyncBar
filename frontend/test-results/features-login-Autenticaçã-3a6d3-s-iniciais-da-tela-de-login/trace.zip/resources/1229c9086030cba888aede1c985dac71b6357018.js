import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/diningareas/DiningAreasPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  createDiningArea,
  getDiningAreasByBranch,
  updateDiningArea,
  getTablesByArea,
  assignTableToArea,
  removeTableFromArea,
  getActiveAssignmentsByArea,
  startAssignment,
  endAssignment
} from "/src/features/diningareas/api.ts";
import { getEmployeesByBranch } from "/src/features/employees/api.ts";
import { getTablesByBranch } from "/src/features/tables/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { QueryError } from "/src/components/QueryError.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { Button } from "/src/ui/Button.tsx";
import { Field, TextField } from "/src/ui/Field.tsx";
import { useToast } from "/src/ui/Toast.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { SkeletonList } from "/src/ui/Skeleton.tsx";
export function DiningAreasPage() {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { branchId } = useAuthStore();
  const [search, setSearch] = useState("");
  const [creating, setCreating] = useState(false);
  const [editingTo, setEditingTo] = useState(null);
  const [managingArea, setManagingArea] = useState(null);
  const [error, setError] = useState(null);
  const [form, setForm] = useState({ name: "" });
  const [tableForm, setTableForm] = useState({ tableId: "" });
  const [assignmentForm, setAssignmentForm] = useState({ employeeId: "" });
  const onApiError = (e) => setError(e instanceof ApiError ? e.message : "Operação falhou.");
  const refreshAreas = () => void queryClient.invalidateQueries({ queryKey: ["diningareas"] });
  const refreshManagement = () => {
    if (managingArea) {
      void queryClient.invalidateQueries({ queryKey: ["diningareatables", managingArea.id] });
      void queryClient.invalidateQueries({ queryKey: ["diningareaassignments", managingArea.id] });
    }
  };
  const areasQuery = useQuery({
    queryKey: ["diningareas", branchId],
    queryFn: () => getDiningAreasByBranch(branchId ?? 1),
    enabled: !!branchId
  });
  const branchTablesQuery = useQuery({
    queryKey: ["tables", branchId],
    queryFn: () => getTablesByBranch(branchId ?? 1),
    enabled: !!branchId && managingArea !== null
  });
  const employeesQuery = useQuery({
    queryKey: ["employees", branchId],
    queryFn: () => getEmployeesByBranch(branchId ?? 1),
    enabled: !!branchId && managingArea !== null
  });
  const areaTablesQuery = useQuery({
    queryKey: ["diningareatables", managingArea?.id],
    queryFn: () => getTablesByArea(managingArea.id),
    enabled: !!managingArea
  });
  const assignmentsQuery = useQuery({
    queryKey: ["diningareaassignments", managingArea?.id],
    queryFn: () => getActiveAssignmentsByArea(managingArea.id),
    enabled: !!managingArea
  });
  const employeeNameMap = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const e of employeesQuery.data ?? []) map.set(e.id, e.name);
    return map;
  }, [employeesQuery.data]);
  const tableNumberMap = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const t of branchTablesQuery.data ?? []) map.set(t.id, t.number);
    return map;
  }, [branchTablesQuery.data]);
  const createMutation = useMutation({
    mutationFn: () => createDiningArea({ branchId: branchId ?? 1, name: form.name.trim() }),
    onSuccess: () => {
      setError(null);
      setCreating(false);
      setForm({ name: "" });
      toast.success("Praça cadastrada.");
      refreshAreas();
    },
    onError: onApiError
  });
  const updateMutation = useMutation({
    mutationFn: () => updateDiningArea(editingTo.id, editingTo.name.trim()),
    onSuccess: () => {
      setError(null);
      setEditingTo(null);
      toast.success("Praça atualizada.");
      refreshAreas();
    },
    onError: onApiError
  });
  const addTableMutation = useMutation({
    mutationFn: () => assignTableToArea(managingArea.id, Number(tableForm.tableId)),
    onSuccess: () => {
      setError(null);
      setTableForm({ tableId: "" });
      toast.success("Mesa vinculada à praça.");
      refreshManagement();
    },
    onError: onApiError
  });
  const removeTableMutation = useMutation({
    mutationFn: (assignmentId) => removeTableFromArea(assignmentId),
    onSuccess: () => {
      toast.success("Mesa removida da praça.");
      refreshManagement();
    },
    onError: onApiError
  });
  const startAssignmentMutation = useMutation({
    mutationFn: () => startAssignment(managingArea.id, Number(assignmentForm.employeeId), (/* @__PURE__ */ new Date()).toISOString()),
    onSuccess: () => {
      setError(null);
      setAssignmentForm({ employeeId: "" });
      toast.success("Turno do garçom iniciado na praça.");
      refreshManagement();
    },
    onError: onApiError
  });
  const endAssignmentMutation = useMutation({
    mutationFn: (assignmentId) => endAssignment(assignmentId, (/* @__PURE__ */ new Date()).toISOString()),
    onSuccess: () => {
      toast.success("Turno encerrado.");
      refreshManagement();
    },
    onError: onApiError
  });
  const filteredAreas = (areasQuery.data ?? []).filter(
    (area) => area.name.toLowerCase().includes(search.toLowerCase())
  );
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 900, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise ui-row ui-row-wrap", style: { marginBottom: 6 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Praças e Salões" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 173,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "ui-spacer" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 174,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          placeholder: "Buscar praça…",
          value: search,
          onChange: (e) => setSearch(e.target.value),
          style: { flex: 1, minWidth: 220 }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 175,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => {
        setError(null);
        setCreating(true);
      }, children: "+ Nova praça" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 181,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
      lineNumber: 172,
      columnNumber: 13
    }, this),
    areasQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: areasQuery.error, what: "as praças" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
      lineNumber: 186,
      columnNumber: 36
    }, this),
    error && !creating && editingTo === null && managingArea === null && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
      lineNumber: 187,
      columnNumber: 83
    }, this),
    areasQuery.isLoading && /* @__PURE__ */ jsxDEV(SkeletonList, { rows: 4, rowHeight: 58 }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
      lineNumber: 189,
      columnNumber: 38
    }, this),
    !areasQuery.isLoading && filteredAreas.length === 0 && /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: "🍽️",
        title: "Nenhuma praça encontrada",
        description: search.trim() === "" ? "Cadastre a primeira praça (ex: Salão Interno, Varanda) para organizar suas mesas." : "Nenhuma praça bate com essa busca.",
        action: search.trim() === "" ? /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => {
          setError(null);
          setCreating(true);
        }, children: "+ Nova praça" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 202,
          columnNumber: 9
        }, this) : void 0
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 192,
        columnNumber: 7
      },
      this
    ),
    !areasQuery.isLoading && filteredAreas.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "rise rise-1 ticket", style: { marginTop: 12 }, children: filteredAreas.map(
      (area) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: area.name }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 215,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: area.isActive ? "Ativa" : "Inativa" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 216,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 214,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 10 }, children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => {
            setError(null);
            setEditingTo({ id: area.id, name: area.name });
          }, children: "Editar Nome" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 221,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "primary", size: "sm", onClick: () => {
            setError(null);
            setManagingArea(area);
          }, children: "Gerenciar Operação" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 224,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 220,
          columnNumber: 29
        }, this)
      ] }, area.id, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 213,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
      lineNumber: 211,
      columnNumber: 7
    }, this),
    creating && /* @__PURE__ */ jsxDEV(Modal, { title: "Nova praça", onClose: () => setCreating(false), children: [
      /* @__PURE__ */ jsxDEV(TextField, { label: "Nome (ex: Varanda, Salão 1)", value: form.name, onChange: (e) => setForm((f) => ({ ...f, name: e.target.value })), autoFocus: true }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 235,
        columnNumber: 21
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 236,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", block: true, disabled: form.name.trim() === "", loading: createMutation.isPending, onClick: () => createMutation.mutate(), children: "Criar praça" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 237,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
      lineNumber: 234,
      columnNumber: 7
    }, this),
    editingTo !== null && /* @__PURE__ */ jsxDEV(Modal, { title: "Editar praça", onClose: () => setEditingTo(null), children: [
      /* @__PURE__ */ jsxDEV(TextField, { label: "Nome", value: editingTo.name, onChange: (e) => setEditingTo((prev) => prev ? { ...prev, name: e.target.value } : null), autoFocus: true }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 245,
        columnNumber: 21
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 246,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "primary", block: true, disabled: editingTo.name.trim() === "", loading: updateMutation.isPending, onClick: () => updateMutation.mutate(), children: "Salvar alterações" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 247,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
      lineNumber: 244,
      columnNumber: 7
    }, this),
    managingArea !== null && /* @__PURE__ */ jsxDEV(Modal, { title: `Gerenciando: ${managingArea.name}`, onClose: () => {
      setManagingArea(null);
      setError(null);
    }, children: [
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", style: { marginBottom: 16 }, children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 255,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 24 }, children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "1.1rem", marginBottom: 8 }, children: "Mesas Vinculadas" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 258,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8, marginBottom: 12, alignItems: "end" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: /* @__PURE__ */ jsxDEV(Field, { label: "Selecione a Mesa", children: (a11y) => /* @__PURE__ */ jsxDEV(
            "select",
            {
              ...a11y,
              value: tableForm.tableId,
              onChange: (e) => setTableForm({ tableId: e.target.value }),
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Escolha uma mesa…" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
                  lineNumber: 268,
                  columnNumber: 45
                }, this),
                (branchTablesQuery.data ?? []).map(
                  (t) => /* @__PURE__ */ jsxDEV("option", { value: t.id, children: [
                    "Mesa ",
                    t.number
                  ] }, t.id, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
                    lineNumber: 270,
                    columnNumber: 19
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
              lineNumber: 263,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 261,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 260,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              disabled: !tableForm.tableId,
              loading: addTableMutation.isPending,
              onClick: () => addTableMutation.mutate(),
              children: "+ Vincular"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
              lineNumber: 276,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 259,
          columnNumber: 25
        }, this),
        areaTablesQuery.isLoading ? /* @__PURE__ */ jsxDEV("p", { children: "Carregando mesas..." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 286,
          columnNumber: 54
        }, this) : /* @__PURE__ */ jsxDEV("ul", { style: { paddingLeft: 20 }, children: [
          areaTablesQuery.data?.map(
            (t) => /* @__PURE__ */ jsxDEV("li", { style: { marginBottom: 4 }, children: [
              "Mesa ",
              tableNumberMap.get(t.diningTableId) ?? t.diningTableId,
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  style: { marginLeft: 8, color: "var(--red)", background: "none", border: "none", cursor: "pointer" },
                  onClick: () => removeTableMutation.mutate(t.id),
                  children: "(remover)"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
                  lineNumber: 291,
                  columnNumber: 41
                },
                this
              )
            ] }, t.id, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
              lineNumber: 289,
              columnNumber: 13
            }, this)
          ),
          areaTablesQuery.data?.length === 0 && /* @__PURE__ */ jsxDEV("li", { style: { color: "var(--ink-faint)" }, children: "Nenhuma mesa vinculada a esta praça." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 299,
            columnNumber: 72
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 287,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 257,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("hr", { style: { border: "0", borderTop: "1px solid var(--border)", margin: "16px 0" } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 304,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "1.1rem", marginBottom: 8 }, children: "Garçons no Turno" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 307,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8, marginBottom: 12, alignItems: "end" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: /* @__PURE__ */ jsxDEV(Field, { label: "Selecione o Garçom", children: (a11y) => /* @__PURE__ */ jsxDEV(
            "select",
            {
              ...a11y,
              value: assignmentForm.employeeId,
              onChange: (e) => setAssignmentForm({ employeeId: e.target.value }),
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Escolha um garçom…" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
                  lineNumber: 317,
                  columnNumber: 45
                }, this),
                (employeesQuery.data ?? []).map(
                  (e) => /* @__PURE__ */ jsxDEV("option", { value: e.id, children: e.name }, e.id, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
                    lineNumber: 319,
                    columnNumber: 19
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
              lineNumber: 312,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 310,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 309,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              disabled: !assignmentForm.employeeId,
              loading: startAssignmentMutation.isPending,
              onClick: () => startAssignmentMutation.mutate(),
              children: "+ Iniciar Turno"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
              lineNumber: 325,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 308,
          columnNumber: 25
        }, this),
        assignmentsQuery.isLoading ? /* @__PURE__ */ jsxDEV("p", { children: "Carregando escala..." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 335,
          columnNumber: 55
        }, this) : /* @__PURE__ */ jsxDEV("ul", { style: { paddingLeft: 20 }, children: [
          assignmentsQuery.data?.map(
            (a) => /* @__PURE__ */ jsxDEV("li", { style: { marginBottom: 4 }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 500 }, children: employeeNameMap.get(a.employeeId) ?? a.employeeId }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
                lineNumber: 339,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)", marginLeft: 6 }, children: [
                "(iniciou às ",
                new Date(a.startAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                ")"
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
                lineNumber: 340,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  style: { marginLeft: 8, color: "var(--red)", background: "none", border: "none", cursor: "pointer" },
                  onClick: () => endAssignmentMutation.mutate(a.id),
                  children: "(encerrar turno)"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
                  lineNumber: 343,
                  columnNumber: 41
                },
                this
              )
            ] }, a.id, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
              lineNumber: 338,
              columnNumber: 13
            }, this)
          ),
          assignmentsQuery.data?.length === 0 && /* @__PURE__ */ jsxDEV("li", { style: { color: "var(--ink-faint)" }, children: "Nenhum garçom alocado nesta praça." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
            lineNumber: 351,
            columnNumber: 73
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
          lineNumber: 336,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
        lineNumber: 306,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
      lineNumber: 254,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx",
    lineNumber: 171,
    columnNumber: 5
  }, this);
}
_s(DiningAreasPage, "82VD9Yi6MfVktyGptd5ctiyLa/8=", false, function() {
  return [useQueryClient, useToast, useAuthStore, useQuery, useQuery, useQuery, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation];
});
_c = DiningAreasPage;
var _c;
$RefreshReg$(_c, "DiningAreasPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/diningareas/DiningAreasPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUpnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF6SmYsU0FBU0EsU0FBU0MsZ0JBQWdCO0FBQ25DLFNBQVNDLGFBQWFDLFVBQVVDLHNCQUFzQjtBQUN0RDtBQUFBLEVBQ0lDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BRUc7QUFFUCxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MseUJBQXlCO0FBRWxDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxPQUFPQyxpQkFBaUI7QUFDakMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxvQkFBb0I7QUFFdEIsZ0JBQVNDLGtCQUFrQjtBQUFBQyxLQUFBO0FBQzlCLFFBQU1DLGNBQWN4QixlQUFlO0FBQ25DLFFBQU15QixRQUFRTixTQUFTO0FBQ3ZCLFFBQU0sRUFBRU8sU0FBUyxJQUFJZCxhQUFhO0FBRWxDLFFBQU0sQ0FBQ2UsUUFBUUMsU0FBUyxJQUFJL0IsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2dDLFVBQVVDLFdBQVcsSUFBSWpDLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNrQyxXQUFXQyxZQUFZLElBQUluQyxTQUE4QyxJQUFJO0FBQ3BGLFFBQU0sQ0FBQ29DLGNBQWNDLGVBQWUsSUFBSXJDLFNBQW9DLElBQUk7QUFDaEYsUUFBTSxDQUFDc0MsT0FBT0MsUUFBUSxJQUFJdkMsU0FBd0IsSUFBSTtBQUV0RCxRQUFNLENBQUN3QyxNQUFNQyxPQUFPLElBQUl6QyxTQUFTLEVBQUUwQyxNQUFNLEdBQUcsQ0FBQztBQUM3QyxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSTVDLFNBQVMsRUFBRTZDLFNBQVMsR0FBRyxDQUFDO0FBQzFELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSS9DLFNBQVMsRUFBRWdELFlBQVksR0FBRyxDQUFDO0FBRXZFLFFBQU1DLGFBQWFBLENBQUNDLE1BQWVYLFNBQVNXLGFBQWFsQyxXQUFXa0MsRUFBRUMsVUFBVSxrQkFBa0I7QUFDbEcsUUFBTUMsZUFBZUEsTUFBTSxLQUFLekIsWUFBWTBCLGtCQUFrQixFQUFFQyxVQUFVLENBQUMsYUFBYSxFQUFFLENBQUM7QUFDM0YsUUFBTUMsb0JBQW9CQSxNQUFNO0FBQzVCLFFBQUluQixjQUFjO0FBQ2QsV0FBS1QsWUFBWTBCLGtCQUFrQixFQUFFQyxVQUFVLENBQUMsb0JBQW9CbEIsYUFBYW9CLEVBQUUsRUFBRSxDQUFDO0FBQ3RGLFdBQUs3QixZQUFZMEIsa0JBQWtCLEVBQUVDLFVBQVUsQ0FBQyx5QkFBeUJsQixhQUFhb0IsRUFBRSxFQUFFLENBQUM7QUFBQSxJQUMvRjtBQUFBLEVBQ0o7QUFFQSxRQUFNQyxhQUFhdkQsU0FBUztBQUFBLElBQ3hCb0QsVUFBVSxDQUFDLGVBQWV6QixRQUFRO0FBQUEsSUFDbEM2QixTQUFTQSxNQUFNckQsdUJBQXVCd0IsWUFBWSxDQUFDO0FBQUEsSUFDbkQ4QixTQUFTLENBQUMsQ0FBQzlCO0FBQUFBLEVBQ2YsQ0FBQztBQUVELFFBQU0rQixvQkFBb0IxRCxTQUFTO0FBQUEsSUFDL0JvRCxVQUFVLENBQUMsVUFBVXpCLFFBQVE7QUFBQSxJQUM3QjZCLFNBQVNBLE1BQU01QyxrQkFBa0JlLFlBQVksQ0FBQztBQUFBLElBQzlDOEIsU0FBUyxDQUFDLENBQUM5QixZQUFZTyxpQkFBaUI7QUFBQSxFQUM1QyxDQUFDO0FBRUQsUUFBTXlCLGlCQUFpQjNELFNBQVM7QUFBQSxJQUM1Qm9ELFVBQVUsQ0FBQyxhQUFhekIsUUFBUTtBQUFBLElBQ2hDNkIsU0FBU0EsTUFBTTdDLHFCQUFxQmdCLFlBQVksQ0FBQztBQUFBLElBQ2pEOEIsU0FBUyxDQUFDLENBQUM5QixZQUFZTyxpQkFBaUI7QUFBQSxFQUM1QyxDQUFDO0FBRUQsUUFBTTBCLGtCQUFrQjVELFNBQVM7QUFBQSxJQUM3Qm9ELFVBQVUsQ0FBQyxvQkFBb0JsQixjQUFjb0IsRUFBRTtBQUFBLElBQy9DRSxTQUFTQSxNQUFNbkQsZ0JBQWdCNkIsYUFBY29CLEVBQUU7QUFBQSxJQUMvQ0csU0FBUyxDQUFDLENBQUN2QjtBQUFBQSxFQUNmLENBQUM7QUFFRCxRQUFNMkIsbUJBQW1CN0QsU0FBUztBQUFBLElBQzlCb0QsVUFBVSxDQUFDLHlCQUF5QmxCLGNBQWNvQixFQUFFO0FBQUEsSUFDcERFLFNBQVNBLE1BQU1oRCwyQkFBMkIwQixhQUFjb0IsRUFBRTtBQUFBLElBQzFERyxTQUFTLENBQUMsQ0FBQ3ZCO0FBQUFBLEVBQ2YsQ0FBQztBQUVELFFBQU00QixrQkFBa0JqRSxRQUFRLE1BQU07QUFDbEMsVUFBTWtFLE1BQU0sb0JBQUlDLElBQW9CO0FBQ3BDLGVBQVdoQixLQUFLVyxlQUFlTSxRQUFRLEdBQUlGLEtBQUlHLElBQUlsQixFQUFFTSxJQUFJTixFQUFFUixJQUFJO0FBQy9ELFdBQU91QjtBQUFBQSxFQUNYLEdBQUcsQ0FBQ0osZUFBZU0sSUFBSSxDQUFDO0FBRXhCLFFBQU1FLGlCQUFpQnRFLFFBQVEsTUFBTTtBQUNqQyxVQUFNa0UsTUFBTSxvQkFBSUMsSUFBb0I7QUFDcEMsZUFBV0ksS0FBS1Ysa0JBQWtCTyxRQUFRLEdBQUlGLEtBQUlHLElBQUlFLEVBQUVkLElBQUljLEVBQUVDLE1BQU07QUFDcEUsV0FBT047QUFBQUEsRUFDWCxHQUFHLENBQUNMLGtCQUFrQk8sSUFBSSxDQUFDO0FBRTNCLFFBQU1LLGlCQUFpQnZFLFlBQVk7QUFBQSxJQUMvQndFLFlBQVlBLE1BQU1yRSxpQkFBaUIsRUFBRXlCLFVBQVVBLFlBQVksR0FBR2EsTUFBTUYsS0FBS0UsS0FBS2dDLEtBQUssRUFBRSxDQUFDO0FBQUEsSUFDdEZDLFdBQVdBLE1BQU07QUFDYnBDLGVBQVMsSUFBSTtBQUFHTixrQkFBWSxLQUFLO0FBQUdRLGNBQVEsRUFBRUMsTUFBTSxHQUFHLENBQUM7QUFDeERkLFlBQU1nRCxRQUFRLG1CQUFtQjtBQUNqQ3hCLG1CQUFhO0FBQUEsSUFDakI7QUFBQSxJQUNBeUIsU0FBUzVCO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU02QixpQkFBaUI3RSxZQUFZO0FBQUEsSUFDL0J3RSxZQUFZQSxNQUFNbkUsaUJBQWlCNEIsVUFBV3NCLElBQUl0QixVQUFXUSxLQUFLZ0MsS0FBSyxDQUFDO0FBQUEsSUFDeEVDLFdBQVdBLE1BQU07QUFDYnBDLGVBQVMsSUFBSTtBQUFHSixtQkFBYSxJQUFJO0FBQ2pDUCxZQUFNZ0QsUUFBUSxtQkFBbUI7QUFDakN4QixtQkFBYTtBQUFBLElBQ2pCO0FBQUEsSUFDQXlCLFNBQVM1QjtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNOEIsbUJBQW1COUUsWUFBWTtBQUFBLElBQ2pDd0UsWUFBWUEsTUFBTWpFLGtCQUFrQjRCLGFBQWNvQixJQUFJd0IsT0FBT3JDLFVBQVVFLE9BQU8sQ0FBQztBQUFBLElBQy9FOEIsV0FBV0EsTUFBTTtBQUNicEMsZUFBUyxJQUFJO0FBQUdLLG1CQUFhLEVBQUVDLFNBQVMsR0FBRyxDQUFDO0FBQzVDakIsWUFBTWdELFFBQVEseUJBQXlCO0FBQ3ZDckIsd0JBQWtCO0FBQUEsSUFDdEI7QUFBQSxJQUNBc0IsU0FBUzVCO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1nQyxzQkFBc0JoRixZQUFZO0FBQUEsSUFDcEN3RSxZQUFZQSxDQUFDUyxpQkFBeUJ6RSxvQkFBb0J5RSxZQUFZO0FBQUEsSUFDdEVQLFdBQVdBLE1BQU07QUFBRS9DLFlBQU1nRCxRQUFRLHlCQUF5QjtBQUFHckIsd0JBQWtCO0FBQUEsSUFBRztBQUFBLElBQ2xGc0IsU0FBUzVCO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1rQywwQkFBMEJsRixZQUFZO0FBQUEsSUFDeEN3RSxZQUFZQSxNQUFNOUQsZ0JBQWdCeUIsYUFBY29CLElBQUl3QixPQUFPbEMsZUFBZUUsVUFBVSxJQUFHLG9CQUFJb0MsS0FBSyxHQUFFQyxZQUFZLENBQUM7QUFBQSxJQUMvR1YsV0FBV0EsTUFBTTtBQUNicEMsZUFBUyxJQUFJO0FBQUdRLHdCQUFrQixFQUFFQyxZQUFZLEdBQUcsQ0FBQztBQUNwRHBCLFlBQU1nRCxRQUFRLG9DQUFvQztBQUNsRHJCLHdCQUFrQjtBQUFBLElBQ3RCO0FBQUEsSUFDQXNCLFNBQVM1QjtBQUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNcUMsd0JBQXdCckYsWUFBWTtBQUFBLElBQ3RDd0UsWUFBWUEsQ0FBQ1MsaUJBQXlCdEUsY0FBY3NFLGVBQWMsb0JBQUlFLEtBQUssR0FBRUMsWUFBWSxDQUFDO0FBQUEsSUFDMUZWLFdBQVdBLE1BQU07QUFBRS9DLFlBQU1nRCxRQUFRLGtCQUFrQjtBQUFHckIsd0JBQWtCO0FBQUEsSUFBRztBQUFBLElBQzNFc0IsU0FBUzVCO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1zQyxpQkFBaUI5QixXQUFXVSxRQUFRLElBQUlxQjtBQUFBQSxJQUFPLENBQUNDLFNBQ2xEQSxLQUFLL0MsS0FBS2dELFlBQVksRUFBRUMsU0FBUzdELE9BQU80RCxZQUFZLENBQUM7QUFBQSxFQUN6RDtBQUVBLFNBQ0ksdUJBQUMsVUFBSyxPQUFPLEVBQUVFLFNBQVMsSUFBSUMsVUFBVSxLQUFLQyxRQUFRLFNBQVMsR0FDeEQ7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMkJBQTBCLE9BQU8sRUFBRUMsY0FBYyxFQUFFLEdBQzlEO0FBQUEsNkJBQUMsUUFBRyxXQUFVLFdBQVUsT0FBTyxFQUFFQyxVQUFVLFNBQVMsR0FBRywrQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLE1BQ3RFLHVCQUFDLFVBQUssV0FBVSxlQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJCO0FBQUEsTUFDM0I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLGFBQVk7QUFBQSxVQUNaLE9BQU9sRTtBQUFBQSxVQUNQLFVBQVUsQ0FBQ29CLE1BQU1uQixVQUFVbUIsRUFBRStDLE9BQU9DLEtBQUs7QUFBQSxVQUN6QyxPQUFPLEVBQUVDLE1BQU0sR0FBR0MsVUFBVSxJQUFJO0FBQUE7QUFBQSxRQUpwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJc0M7QUFBQSxNQUV0Qyx1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTLE1BQU07QUFBRTdELGlCQUFTLElBQUk7QUFBR04sb0JBQVksSUFBSTtBQUFBLE1BQUcsR0FBRyw0QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVDd0IsV0FBVzRDLFdBQVcsdUJBQUMsY0FBVyxPQUFPNUMsV0FBV25CLE9BQU8sTUFBSyxlQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFEO0FBQUEsSUFDM0VBLFNBQVMsQ0FBQ04sWUFBWUUsY0FBYyxRQUFRRSxpQkFBaUIsUUFBUSx1QkFBQyxPQUFFLFdBQVUsY0FBY0UsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUV0R21CLFdBQVc2QyxhQUFhLHVCQUFDLGdCQUFhLE1BQU0sR0FBRyxXQUFXLE1BQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUM7QUFBQSxJQUU3RCxDQUFDN0MsV0FBVzZDLGFBQWFmLGNBQWNnQixXQUFXLEtBQy9DO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxNQUFLO0FBQUEsUUFDTCxPQUFNO0FBQUEsUUFDTixhQUNJekUsT0FBTzRDLEtBQUssTUFBTSxLQUNaLHNGQUNBO0FBQUEsUUFFVixRQUNJNUMsT0FBTzRDLEtBQUssTUFBTSxLQUNkLHVCQUFDLFVBQU8sU0FBUSxXQUFVLFNBQVMsTUFBTTtBQUFFbkMsbUJBQVMsSUFBSTtBQUFHTixzQkFBWSxJQUFJO0FBQUEsUUFBRyxHQUFHLDRCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFDQXVFO0FBQUFBO0FBQUFBLE1BYlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBY0s7QUFBQSxJQUlSLENBQUMvQyxXQUFXNkMsYUFBYWYsY0FBY2dCLFNBQVMsS0FDN0MsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVFLFdBQVcsR0FBRyxHQUN0RGxCLHdCQUFjdEI7QUFBQUEsTUFBSSxDQUFDd0IsU0FDaEIsdUJBQUMsU0FBa0IsV0FBVSxjQUN6QjtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFaUIsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDbEM7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUMsWUFBWSxJQUFJLEdBQUluQixlQUFLL0MsUUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxVQUM3Qyx1QkFBQyxVQUFLLE9BQU8sRUFBRXNELFVBQVUsVUFBVWEsT0FBTyxtQkFBbUIsR0FDeERwQixlQUFLcUIsV0FBVyxVQUFVLGFBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFSCxLQUFLLEdBQUcsR0FDckM7QUFBQSxpQ0FBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLE1BQUssU0FBUyxNQUFNO0FBQUVwRSxxQkFBUyxJQUFJO0FBQUdKLHlCQUFhLEVBQUVxQixJQUFJaUMsS0FBS2pDLElBQUlkLE1BQU0rQyxLQUFLL0MsS0FBSyxDQUFDO0FBQUEsVUFBRyxHQUFHLDJCQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLFNBQVEsV0FBVSxNQUFLLE1BQUssU0FBUyxNQUFNO0FBQUVILHFCQUFTLElBQUk7QUFBR0YsNEJBQWdCb0QsSUFBSTtBQUFBLFVBQUcsR0FBRyxrQ0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FkTUEsS0FBS2pDLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsSUFDSCxLQWxCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsSUFHSHhCLFlBQ0csdUJBQUMsU0FBTSxPQUFNLGNBQWEsU0FBUyxNQUFNQyxZQUFZLEtBQUssR0FDdEQ7QUFBQSw2QkFBQyxhQUFVLE9BQU0sK0JBQThCLE9BQU9PLEtBQUtFLE1BQU0sVUFBVSxDQUFDUSxNQUFNVCxRQUFRLENBQUNzRSxPQUFPLEVBQUUsR0FBR0EsR0FBR3JFLE1BQU1RLEVBQUUrQyxPQUFPQyxNQUFNLEVBQUUsR0FBRyxXQUFTLFFBQTdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkk7QUFBQSxNQUM1STVELFNBQVMsdUJBQUMsT0FBRSxXQUFVLGNBQWNBLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDM0MsdUJBQUMsVUFBTyxTQUFRLFdBQVUsT0FBSyxNQUFDLFVBQVVFLEtBQUtFLEtBQUtnQyxLQUFLLE1BQU0sSUFBSSxTQUFTRixlQUFld0MsV0FBVyxTQUFTLE1BQU14QyxlQUFleUMsT0FBTyxHQUFHLDJCQUE5STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBR0gvRSxjQUFjLFFBQ1gsdUJBQUMsU0FBTSxPQUFNLGdCQUFlLFNBQVMsTUFBTUMsYUFBYSxJQUFJLEdBQ3hEO0FBQUEsNkJBQUMsYUFBVSxPQUFNLFFBQU8sT0FBT0QsVUFBVVEsTUFBTSxVQUFVLENBQUNRLE1BQU1mLGFBQWEsQ0FBQytFLFNBQVNBLE9BQU8sRUFBRSxHQUFHQSxNQUFNeEUsTUFBTVEsRUFBRStDLE9BQU9DLE1BQU0sSUFBSSxJQUFJLEdBQUcsV0FBUyxRQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtKO0FBQUEsTUFDako1RCxTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQzNDLHVCQUFDLFVBQU8sU0FBUSxXQUFVLE9BQUssTUFBQyxVQUFVSixVQUFVUSxLQUFLZ0MsS0FBSyxNQUFNLElBQUksU0FBU0ksZUFBZWtDLFdBQVcsU0FBUyxNQUFNbEMsZUFBZW1DLE9BQU8sR0FBRyxpQ0FBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUdIN0UsaUJBQWlCLFFBQ2QsdUJBQUMsU0FBTSxPQUFPLGdCQUFnQkEsYUFBYU0sSUFBSSxJQUFJLFNBQVMsTUFBTTtBQUFFTCxzQkFBZ0IsSUFBSTtBQUFHRSxlQUFTLElBQUk7QUFBQSxJQUFHLEdBQ3RHRDtBQUFBQSxlQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFhLE9BQU8sRUFBRXlELGNBQWMsR0FBRyxHQUFJekQsbUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEQ7QUFBQSxNQUV4RSx1QkFBQyxTQUFJLE9BQU8sRUFBRXlELGNBQWMsR0FBRyxHQUMzQjtBQUFBLCtCQUFDLFFBQUcsT0FBTyxFQUFFQyxVQUFVLFVBQVVELGNBQWMsRUFBRSxHQUFHLGdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsUUFDcEUsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFWSxLQUFLLEdBQUdaLGNBQWMsSUFBSW9CLFlBQVksTUFBTSxHQUN6RTtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFaEIsTUFBTSxFQUFFLEdBQ2xCLGlDQUFDLFNBQU0sT0FBTSxvQkFDUixXQUFDaUIsU0FDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csR0FBSUE7QUFBQUEsY0FDSixPQUFPekUsVUFBVUU7QUFBQUEsY0FDakIsVUFBVSxDQUFDSyxNQUFNTixhQUFhLEVBQUVDLFNBQVNLLEVBQUUrQyxPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUV6RDtBQUFBLHVDQUFDLFlBQU8sT0FBTSxJQUFHLGlDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQztBQUFBLGlCQUNoQ3RDLGtCQUFrQk8sUUFBUSxJQUFJRjtBQUFBQSxrQkFBSSxDQUFDSyxNQUNqQyx1QkFBQyxZQUFrQixPQUFPQSxFQUFFZCxJQUFJO0FBQUE7QUFBQSxvQkFBTWMsRUFBRUM7QUFBQUEsdUJBQTNCRCxFQUFFZCxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStDO0FBQUEsZ0JBQ2xEO0FBQUE7QUFBQTtBQUFBLFlBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0EsS0FYUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBLEtBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVE7QUFBQSxjQUNSLFVBQVUsQ0FBQ2IsVUFBVUU7QUFBQUEsY0FDckIsU0FBU2tDLGlCQUFpQmlDO0FBQUFBLGNBQzFCLFNBQVMsTUFBTWpDLGlCQUFpQmtDLE9BQU87QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUo3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLGFBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxRQUVDbkQsZ0JBQWdCd0MsWUFBWSx1QkFBQyxPQUFFLG1DQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0IsSUFDL0MsdUJBQUMsUUFBRyxPQUFPLEVBQUVlLGFBQWEsR0FBRyxHQUN4QnZEO0FBQUFBLDBCQUFnQkssTUFBTUY7QUFBQUEsWUFBSSxDQUFBSyxNQUN2Qix1QkFBQyxRQUFjLE9BQU8sRUFBRXlCLGNBQWMsRUFBRSxHQUFHO0FBQUE7QUFBQSxjQUNqQzFCLGVBQWVpRCxJQUFJaEQsRUFBRWlELGFBQWEsS0FBS2pELEVBQUVpRDtBQUFBQSxjQUMvQztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxPQUFPLEVBQUVDLFlBQVksR0FBR1gsT0FBTyxjQUFjWSxZQUFZLFFBQVFDLFFBQVEsUUFBUUMsUUFBUSxVQUFVO0FBQUEsa0JBQ25HLFNBQVMsTUFBTTFDLG9CQUFvQmdDLE9BQU8zQyxFQUFFZCxFQUFFO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQVBLYyxFQUFFZCxJQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxVQUNIO0FBQUEsVUFDQU0sZ0JBQWdCSyxNQUFNb0MsV0FBVyxLQUFLLHVCQUFDLFFBQUcsT0FBTyxFQUFFTSxPQUFPLG1CQUFtQixHQUFHLG9EQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLGFBWnpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFdBM0NSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2Q0E7QUFBQSxNQUVBLHVCQUFDLFFBQUcsT0FBTyxFQUFFYSxRQUFRLEtBQUtFLFdBQVcsMkJBQTJCOUIsUUFBUSxTQUFTLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUY7QUFBQSxNQUVuRix1QkFBQyxTQUNHO0FBQUEsK0JBQUMsUUFBRyxPQUFPLEVBQUVFLFVBQVUsVUFBVUQsY0FBYyxFQUFFLEdBQUcsZ0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0U7QUFBQSxRQUNwRSx1QkFBQyxTQUFJLFdBQVUsVUFBUyxPQUFPLEVBQUVZLEtBQUssR0FBR1osY0FBYyxJQUFJb0IsWUFBWSxNQUFNLEdBQ3pFO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUVoQixNQUFNLEVBQUUsR0FDbEIsaUNBQUMsU0FBTSxPQUFNLHNCQUNSLFdBQUNpQixTQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxHQUFJQTtBQUFBQSxjQUNKLE9BQU90RSxlQUFlRTtBQUFBQSxjQUN0QixVQUFVLENBQUNFLE1BQU1ILGtCQUFrQixFQUFFQyxZQUFZRSxFQUFFK0MsT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FFakU7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sSUFBRyxrQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUM7QUFBQSxpQkFDakNyQyxlQUFlTSxRQUFRLElBQUlGO0FBQUFBLGtCQUFJLENBQUNmLE1BQzlCLHVCQUFDLFlBQWtCLE9BQU9BLEVBQUVNLElBQUtOLFlBQUVSLFFBQXRCUSxFQUFFTSxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdDO0FBQUEsZ0JBQzNDO0FBQUE7QUFBQTtBQUFBLFlBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0EsS0FYUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBLEtBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVE7QUFBQSxjQUNSLFVBQVUsQ0FBQ1YsZUFBZUU7QUFBQUEsY0FDMUIsU0FBU21DLHdCQUF3QjZCO0FBQUFBLGNBQ2pDLFNBQVMsTUFBTTdCLHdCQUF3QjhCLE9BQU87QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUpwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLGFBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxRQUVDbEQsaUJBQWlCdUMsWUFBWSx1QkFBQyxPQUFFLG9DQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUIsSUFDakQsdUJBQUMsUUFBRyxPQUFPLEVBQUVlLGFBQWEsR0FBRyxHQUN4QnREO0FBQUFBLDJCQUFpQkksTUFBTUY7QUFBQUEsWUFBSSxDQUFBNEQsTUFDeEIsdUJBQUMsUUFBYyxPQUFPLEVBQUU5QixjQUFjLEVBQUUsR0FDcEM7QUFBQSxxQ0FBQyxVQUFLLE9BQU8sRUFBRWEsWUFBWSxJQUFJLEdBQUk1QywwQkFBZ0JzRCxJQUFJTyxFQUFFN0UsVUFBVSxLQUFLNkUsRUFBRTdFLGNBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsY0FDckYsdUJBQUMsVUFBSyxPQUFPLEVBQUVnRCxVQUFVLFVBQVVhLE9BQU8sb0JBQW9CVyxZQUFZLEVBQUUsR0FBRztBQUFBO0FBQUEsZ0JBQzlELElBQUlwQyxLQUFLeUMsRUFBRUMsT0FBTyxFQUFFQyxtQkFBbUIsSUFBSSxFQUFFQyxNQUFNLFdBQVdDLFFBQVEsVUFBVSxDQUFDO0FBQUEsZ0JBQUU7QUFBQSxtQkFEcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csT0FBTyxFQUFFVCxZQUFZLEdBQUdYLE9BQU8sY0FBY1ksWUFBWSxRQUFRQyxRQUFRLFFBQVFDLFFBQVEsVUFBVTtBQUFBLGtCQUNuRyxTQUFTLE1BQU1yQyxzQkFBc0IyQixPQUFPWSxFQUFFckUsRUFBRTtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFGdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkFWS3FFLEVBQUVyRSxJQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxVQUNIO0FBQUEsVUFDQU8saUJBQWlCSSxNQUFNb0MsV0FBVyxLQUFLLHVCQUFDLFFBQUcsT0FBTyxFQUFFTSxPQUFPLG1CQUFtQixHQUFHLGtEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLGFBZnhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQTlDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0RBO0FBQUEsU0FwR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFHQTtBQUFBLE9BeExSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwTEE7QUFFUjtBQUFDbkYsR0F2VGVELGlCQUFlO0FBQUEsVUFDUHRCLGdCQUNObUIsVUFDT1AsY0FxQkZiLFVBTU9BLFVBTUhBLFVBTUNBLFVBTUNBLFVBa0JGRCxhQVVBQSxhQVVFQSxhQVVHQSxhQU1JQSxhQVVGQSxXQUFXO0FBQUE7QUFBQSxLQWhIN0J3QjtBQUFlLElBQUF5RztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJjcmVhdGVEaW5pbmdBcmVhIiwiZ2V0RGluaW5nQXJlYXNCeUJyYW5jaCIsInVwZGF0ZURpbmluZ0FyZWEiLCJnZXRUYWJsZXNCeUFyZWEiLCJhc3NpZ25UYWJsZVRvQXJlYSIsInJlbW92ZVRhYmxlRnJvbUFyZWEiLCJnZXRBY3RpdmVBc3NpZ25tZW50c0J5QXJlYSIsInN0YXJ0QXNzaWdubWVudCIsImVuZEFzc2lnbm1lbnQiLCJnZXRFbXBsb3llZXNCeUJyYW5jaCIsImdldFRhYmxlc0J5QnJhbmNoIiwidXNlQXV0aFN0b3JlIiwiQXBpRXJyb3IiLCJRdWVyeUVycm9yIiwiTW9kYWwiLCJCdXR0b24iLCJGaWVsZCIsIlRleHRGaWVsZCIsInVzZVRvYXN0IiwiRW1wdHlTdGF0ZSIsIlNrZWxldG9uTGlzdCIsIkRpbmluZ0FyZWFzUGFnZSIsIl9zIiwicXVlcnlDbGllbnQiLCJ0b2FzdCIsImJyYW5jaElkIiwic2VhcmNoIiwic2V0U2VhcmNoIiwiY3JlYXRpbmciLCJzZXRDcmVhdGluZyIsImVkaXRpbmdUbyIsInNldEVkaXRpbmdUbyIsIm1hbmFnaW5nQXJlYSIsInNldE1hbmFnaW5nQXJlYSIsImVycm9yIiwic2V0RXJyb3IiLCJmb3JtIiwic2V0Rm9ybSIsIm5hbWUiLCJ0YWJsZUZvcm0iLCJzZXRUYWJsZUZvcm0iLCJ0YWJsZUlkIiwiYXNzaWdubWVudEZvcm0iLCJzZXRBc3NpZ25tZW50Rm9ybSIsImVtcGxveWVlSWQiLCJvbkFwaUVycm9yIiwiZSIsIm1lc3NhZ2UiLCJyZWZyZXNoQXJlYXMiLCJpbnZhbGlkYXRlUXVlcmllcyIsInF1ZXJ5S2V5IiwicmVmcmVzaE1hbmFnZW1lbnQiLCJpZCIsImFyZWFzUXVlcnkiLCJxdWVyeUZuIiwiZW5hYmxlZCIsImJyYW5jaFRhYmxlc1F1ZXJ5IiwiZW1wbG95ZWVzUXVlcnkiLCJhcmVhVGFibGVzUXVlcnkiLCJhc3NpZ25tZW50c1F1ZXJ5IiwiZW1wbG95ZWVOYW1lTWFwIiwibWFwIiwiTWFwIiwiZGF0YSIsInNldCIsInRhYmxlTnVtYmVyTWFwIiwidCIsIm51bWJlciIsImNyZWF0ZU11dGF0aW9uIiwibXV0YXRpb25GbiIsInRyaW0iLCJvblN1Y2Nlc3MiLCJzdWNjZXNzIiwib25FcnJvciIsInVwZGF0ZU11dGF0aW9uIiwiYWRkVGFibGVNdXRhdGlvbiIsIk51bWJlciIsInJlbW92ZVRhYmxlTXV0YXRpb24iLCJhc3NpZ25tZW50SWQiLCJzdGFydEFzc2lnbm1lbnRNdXRhdGlvbiIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsImVuZEFzc2lnbm1lbnRNdXRhdGlvbiIsImZpbHRlcmVkQXJlYXMiLCJmaWx0ZXIiLCJhcmVhIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInBhZGRpbmciLCJtYXhXaWR0aCIsIm1hcmdpbiIsIm1hcmdpbkJvdHRvbSIsImZvbnRTaXplIiwidGFyZ2V0IiwidmFsdWUiLCJmbGV4IiwibWluV2lkdGgiLCJpc0Vycm9yIiwiaXNMb2FkaW5nIiwibGVuZ3RoIiwidW5kZWZpbmVkIiwibWFyZ2luVG9wIiwiZGlzcGxheSIsImdhcCIsImZvbnRXZWlnaHQiLCJjb2xvciIsImlzQWN0aXZlIiwiZiIsImlzUGVuZGluZyIsIm11dGF0ZSIsInByZXYiLCJhbGlnbkl0ZW1zIiwiYTExeSIsInBhZGRpbmdMZWZ0IiwiZ2V0IiwiZGluaW5nVGFibGVJZCIsIm1hcmdpbkxlZnQiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiY3Vyc29yIiwiYm9yZGVyVG9wIiwiYSIsInN0YXJ0QXQiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJob3VyIiwibWludXRlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGluaW5nQXJlYXNQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQge1xyXG4gICAgY3JlYXRlRGluaW5nQXJlYSxcclxuICAgIGdldERpbmluZ0FyZWFzQnlCcmFuY2gsXHJcbiAgICB1cGRhdGVEaW5pbmdBcmVhLFxyXG4gICAgZ2V0VGFibGVzQnlBcmVhLFxyXG4gICAgYXNzaWduVGFibGVUb0FyZWEsXHJcbiAgICByZW1vdmVUYWJsZUZyb21BcmVhLFxyXG4gICAgZ2V0QWN0aXZlQXNzaWdubWVudHNCeUFyZWEsXHJcbiAgICBzdGFydEFzc2lnbm1lbnQsXHJcbiAgICBlbmRBc3NpZ25tZW50LFxyXG4gICAgdHlwZSBEaW5pbmdBcmVhUmVzcG9uc2VcclxufSBmcm9tIFwiLi9hcGlcIjtcclxuXHJcbmltcG9ydCB7IGdldEVtcGxveWVlc0J5QnJhbmNoIH0gZnJvbSBcIi4uL2VtcGxveWVlcy9hcGlcIjtcclxuaW1wb3J0IHsgZ2V0VGFibGVzQnlCcmFuY2ggfSBmcm9tIFwiLi4vdGFibGVzL2FwaVwiO1xyXG5cclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tIFwiLi4vLi4vbGliL2FwaUNsaWVudFwiO1xyXG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xyXG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gXCIuLi8uLi91aS9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IEZpZWxkLCBUZXh0RmllbGQgfSBmcm9tIFwiLi4vLi4vdWkvRmllbGRcIjtcclxuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vLi4vdWkvVG9hc3RcIjtcclxuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCIuLi8uLi91aS9FbXB0eVN0YXRlXCI7XHJcbmltcG9ydCB7IFNrZWxldG9uTGlzdCB9IGZyb20gXCIuLi8uLi91aS9Ta2VsZXRvblwiO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIERpbmluZ0FyZWFzUGFnZSgpIHtcclxuICAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICAgIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcclxuICAgIGNvbnN0IHsgYnJhbmNoSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG5cclxuICAgIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtjcmVhdGluZywgc2V0Q3JlYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2VkaXRpbmdUbywgc2V0RWRpdGluZ1RvXSA9IHVzZVN0YXRlPHsgaWQ6IG51bWJlcjsgbmFtZTogc3RyaW5nIH0gfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFttYW5hZ2luZ0FyZWEsIHNldE1hbmFnaW5nQXJlYV0gPSB1c2VTdGF0ZTxEaW5pbmdBcmVhUmVzcG9uc2UgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gICAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUoeyBuYW1lOiBcIlwiIH0pO1xyXG4gICAgY29uc3QgW3RhYmxlRm9ybSwgc2V0VGFibGVGb3JtXSA9IHVzZVN0YXRlKHsgdGFibGVJZDogXCJcIiB9KTtcclxuICAgIGNvbnN0IFthc3NpZ25tZW50Rm9ybSwgc2V0QXNzaWdubWVudEZvcm1dID0gdXNlU3RhdGUoeyBlbXBsb3llZUlkOiBcIlwiIH0pO1xyXG5cclxuICAgIGNvbnN0IG9uQXBpRXJyb3IgPSAoZTogdW5rbm93bikgPT4gc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEFwaUVycm9yID8gZS5tZXNzYWdlIDogXCJPcGVyYcOnw6NvIGZhbGhvdS5cIik7XHJcbiAgICBjb25zdCByZWZyZXNoQXJlYXMgPSAoKSA9PiB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImRpbmluZ2FyZWFzXCJdIH0pO1xyXG4gICAgY29uc3QgcmVmcmVzaE1hbmFnZW1lbnQgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKG1hbmFnaW5nQXJlYSkge1xyXG4gICAgICAgICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImRpbmluZ2FyZWF0YWJsZXNcIiwgbWFuYWdpbmdBcmVhLmlkXSB9KTtcclxuICAgICAgICAgICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJkaW5pbmdhcmVhYXNzaWdubWVudHNcIiwgbWFuYWdpbmdBcmVhLmlkXSB9KTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGFyZWFzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcImRpbmluZ2FyZWFzXCIsIGJyYW5jaElkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXREaW5pbmdBcmVhc0J5QnJhbmNoKGJyYW5jaElkID8/IDEpLFxyXG4gICAgICAgIGVuYWJsZWQ6ICEhYnJhbmNoSWQsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBicmFuY2hUYWJsZXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgICAgICBxdWVyeUtleTogW1widGFibGVzXCIsIGJyYW5jaElkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRUYWJsZXNCeUJyYW5jaChicmFuY2hJZCA/PyAxKSxcclxuICAgICAgICBlbmFibGVkOiAhIWJyYW5jaElkICYmIG1hbmFnaW5nQXJlYSAhPT0gbnVsbCxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGVtcGxveWVlc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgICAgIHF1ZXJ5S2V5OiBbXCJlbXBsb3llZXNcIiwgYnJhbmNoSWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldEVtcGxveWVlc0J5QnJhbmNoKGJyYW5jaElkID8/IDEpLFxyXG4gICAgICAgIGVuYWJsZWQ6ICEhYnJhbmNoSWQgJiYgbWFuYWdpbmdBcmVhICE9PSBudWxsLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgYXJlYVRhYmxlc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgICAgIHF1ZXJ5S2V5OiBbXCJkaW5pbmdhcmVhdGFibGVzXCIsIG1hbmFnaW5nQXJlYT8uaWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldFRhYmxlc0J5QXJlYShtYW5hZ2luZ0FyZWEhLmlkKSxcclxuICAgICAgICBlbmFibGVkOiAhIW1hbmFnaW5nQXJlYSxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGFzc2lnbm1lbnRzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcImRpbmluZ2FyZWFhc3NpZ25tZW50c1wiLCBtYW5hZ2luZ0FyZWE/LmlkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRBY3RpdmVBc3NpZ25tZW50c0J5QXJlYShtYW5hZ2luZ0FyZWEhLmlkKSxcclxuICAgICAgICBlbmFibGVkOiAhIW1hbmFnaW5nQXJlYSxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGVtcGxveWVlTmFtZU1hcCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XHJcbiAgICAgICAgZm9yIChjb25zdCBlIG9mIGVtcGxveWVlc1F1ZXJ5LmRhdGEgPz8gW10pIG1hcC5zZXQoZS5pZCwgZS5uYW1lKTtcclxuICAgICAgICByZXR1cm4gbWFwO1xyXG4gICAgfSwgW2VtcGxveWVlc1F1ZXJ5LmRhdGFdKTtcclxuXHJcbiAgICBjb25zdCB0YWJsZU51bWJlck1hcCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBudW1iZXI+KCk7XHJcbiAgICAgICAgZm9yIChjb25zdCB0IG9mIGJyYW5jaFRhYmxlc1F1ZXJ5LmRhdGEgPz8gW10pIG1hcC5zZXQodC5pZCwgdC5udW1iZXIpO1xyXG4gICAgICAgIHJldHVybiBtYXA7XHJcbiAgICB9LCBbYnJhbmNoVGFibGVzUXVlcnkuZGF0YV0pO1xyXG5cclxuICAgIGNvbnN0IGNyZWF0ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46ICgpID0+IGNyZWF0ZURpbmluZ0FyZWEoeyBicmFuY2hJZDogYnJhbmNoSWQgPz8gMSwgbmFtZTogZm9ybS5uYW1lLnRyaW0oKSB9KSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgICAgc2V0RXJyb3IobnVsbCk7IHNldENyZWF0aW5nKGZhbHNlKTsgc2V0Rm9ybSh7IG5hbWU6IFwiXCIgfSk7XHJcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJQcmHDp2EgY2FkYXN0cmFkYS5cIik7XHJcbiAgICAgICAgICAgIHJlZnJlc2hBcmVhcygpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHVwZGF0ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46ICgpID0+IHVwZGF0ZURpbmluZ0FyZWEoZWRpdGluZ1RvIS5pZCwgZWRpdGluZ1RvIS5uYW1lLnRyaW0oKSksXHJcbiAgICAgICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldEVycm9yKG51bGwpOyBzZXRFZGl0aW5nVG8obnVsbCk7XHJcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJQcmHDp2EgYXR1YWxpemFkYS5cIik7XHJcbiAgICAgICAgICAgIHJlZnJlc2hBcmVhcygpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGFkZFRhYmxlTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKCkgPT4gYXNzaWduVGFibGVUb0FyZWEobWFuYWdpbmdBcmVhIS5pZCwgTnVtYmVyKHRhYmxlRm9ybS50YWJsZUlkKSksXHJcbiAgICAgICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldEVycm9yKG51bGwpOyBzZXRUYWJsZUZvcm0oeyB0YWJsZUlkOiBcIlwiIH0pO1xyXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiTWVzYSB2aW5jdWxhZGEgw6AgcHJhw6dhLlwiKTtcclxuICAgICAgICAgICAgcmVmcmVzaE1hbmFnZW1lbnQoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCByZW1vdmVUYWJsZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgICAgIG11dGF0aW9uRm46IChhc3NpZ25tZW50SWQ6IG51bWJlcikgPT4gcmVtb3ZlVGFibGVGcm9tQXJlYShhc3NpZ25tZW50SWQpLFxyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4geyB0b2FzdC5zdWNjZXNzKFwiTWVzYSByZW1vdmlkYSBkYSBwcmHDp2EuXCIpOyByZWZyZXNoTWFuYWdlbWVudCgpOyB9LFxyXG4gICAgICAgIG9uRXJyb3I6IG9uQXBpRXJyb3IsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBzdGFydEFzc2lnbm1lbnRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAoKSA9PiBzdGFydEFzc2lnbm1lbnQobWFuYWdpbmdBcmVhIS5pZCwgTnVtYmVyKGFzc2lnbm1lbnRGb3JtLmVtcGxveWVlSWQpLCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpLFxyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRFcnJvcihudWxsKTsgc2V0QXNzaWdubWVudEZvcm0oeyBlbXBsb3llZUlkOiBcIlwiIH0pO1xyXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiVHVybm8gZG8gZ2Fyw6dvbSBpbmljaWFkbyBuYSBwcmHDp2EuXCIpO1xyXG4gICAgICAgICAgICByZWZyZXNoTWFuYWdlbWVudCgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb25FcnJvcjogb25BcGlFcnJvcixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGVuZEFzc2lnbm1lbnRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAoYXNzaWdubWVudElkOiBudW1iZXIpID0+IGVuZEFzc2lnbm1lbnQoYXNzaWdubWVudElkLCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpLFxyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4geyB0b2FzdC5zdWNjZXNzKFwiVHVybm8gZW5jZXJyYWRvLlwiKTsgcmVmcmVzaE1hbmFnZW1lbnQoKTsgfSxcclxuICAgICAgICBvbkVycm9yOiBvbkFwaUVycm9yLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgZmlsdGVyZWRBcmVhcyA9IChhcmVhc1F1ZXJ5LmRhdGEgPz8gW10pLmZpbHRlcigoYXJlYSkgPT5cclxuICAgICAgICBhcmVhLm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2gudG9Mb3dlckNhc2UoKSlcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDkwMCwgbWFyZ2luOiBcIjAgYXV0b1wiIH19PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2UgdWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiA2IH19PlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjdyZW1cIiB9fT5QcmHDp2FzIGUgU2Fsw7VlczwvaDI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1aS1zcGFjZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgcHJhw6dh4oCmXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNofVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMjIwIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RXJyb3IobnVsbCk7IHNldENyZWF0aW5nKHRydWUpOyB9fT5cclxuICAgICAgICAgICAgICAgICAgICArIE5vdmEgcHJhw6dhXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7YXJlYXNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXthcmVhc1F1ZXJ5LmVycm9yfSB3aGF0PVwiYXMgcHJhw6dhc1wiIC8+fVxyXG4gICAgICAgICAgICB7ZXJyb3IgJiYgIWNyZWF0aW5nICYmIGVkaXRpbmdUbyA9PT0gbnVsbCAmJiBtYW5hZ2luZ0FyZWEgPT09IG51bGwgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgICAgICAge2FyZWFzUXVlcnkuaXNMb2FkaW5nICYmIDxTa2VsZXRvbkxpc3Qgcm93cz17NH0gcm93SGVpZ2h0PXs1OH0gLz59XHJcblxyXG4gICAgICAgICAgICB7IWFyZWFzUXVlcnkuaXNMb2FkaW5nICYmIGZpbHRlcmVkQXJlYXMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbj1cIvCfjb3vuI9cIlxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTmVuaHVtYSBwcmHDp2EgZW5jb250cmFkYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb249e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2gudHJpbSgpID09PSBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiQ2FkYXN0cmUgYSBwcmltZWlyYSBwcmHDp2EgKGV4OiBTYWzDo28gSW50ZXJubywgVmFyYW5kYSkgcGFyYSBvcmdhbml6YXIgc3VhcyBtZXNhcy5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk5lbmh1bWEgcHJhw6dhIGJhdGUgY29tIGVzc2EgYnVzY2EuXCJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aW9uPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoLnRyaW0oKSA9PT0gXCJcIiA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBvbkNsaWNrPXsoKSA9PiB7IHNldEVycm9yKG51bGwpOyBzZXRDcmVhdGluZyh0cnVlKTsgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKyBOb3ZhIHByYcOnYVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgeyFhcmVhc1F1ZXJ5LmlzTG9hZGluZyAmJiBmaWx0ZXJlZEFyZWFzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlIHJpc2UtMSB0aWNrZXRcIiBzdHlsZT17eyBtYXJnaW5Ub3A6IDEyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZEFyZWFzLm1hcCgoYXJlYSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17YXJlYS5pZH0gY2xhc3NOYW1lPVwidGlja2V0LXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCB9fT57YXJlYS5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXJlYS5pc0FjdGl2ZSA/IFwiQXRpdmFcIiA6IFwiSW5hdGl2YVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4geyBzZXRFcnJvcihudWxsKTsgc2V0RWRpdGluZ1RvKHsgaWQ6IGFyZWEuaWQsIG5hbWU6IGFyZWEubmFtZSB9KTsgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRhciBOb21lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIHNpemU9XCJzbVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RXJyb3IobnVsbCk7IHNldE1hbmFnaW5nQXJlYShhcmVhKTsgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdlcmVuY2lhciBPcGVyYcOnw6NvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtjcmVhdGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8TW9kYWwgdGl0bGU9XCJOb3ZhIHByYcOnYVwiIG9uQ2xvc2U9eygpID0+IHNldENyZWF0aW5nKGZhbHNlKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk5vbWUgKGV4OiBWYXJhbmRhLCBTYWzDo28gMSlcIiB2YWx1ZT17Zm9ybS5uYW1lfSBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oKGYpID0+ICh7IC4uLmYsIG5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pKX0gYXV0b0ZvY3VzIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgYmxvY2sgZGlzYWJsZWQ9e2Zvcm0ubmFtZS50cmltKCkgPT09IFwiXCJ9IGxvYWRpbmc9e2NyZWF0ZU11dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gY3JlYXRlTXV0YXRpb24ubXV0YXRlKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDcmlhciBwcmHDp2FcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7ZWRpdGluZ1RvICE9PSBudWxsICYmIChcclxuICAgICAgICAgICAgICAgIDxNb2RhbCB0aXRsZT1cIkVkaXRhciBwcmHDp2FcIiBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0aW5nVG8obnVsbCl9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJOb21lXCIgdmFsdWU9e2VkaXRpbmdUby5uYW1lfSBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRpbmdUbygocHJldikgPT4gcHJldiA/IHsgLi4ucHJldiwgbmFtZTogZS50YXJnZXQudmFsdWUgfSA6IG51bGwpfSBhdXRvRm9jdXMgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBibG9jayBkaXNhYmxlZD17ZWRpdGluZ1RvLm5hbWUudHJpbSgpID09PSBcIlwifSBsb2FkaW5nPXt1cGRhdGVNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHVwZGF0ZU11dGF0aW9uLm11dGF0ZSgpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU2FsdmFyIGFsdGVyYcOnw7Vlc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHttYW5hZ2luZ0FyZWEgIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgPE1vZGFsIHRpdGxlPXtgR2VyZW5jaWFuZG86ICR7bWFuYWdpbmdBcmVhLm5hbWV9YH0gb25DbG9zZT17KCkgPT4geyBzZXRNYW5hZ2luZ0FyZWEobnVsbCk7IHNldEVycm9yKG51bGwpOyB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMTYgfX0+e2Vycm9yfTwvcD59XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAyNCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMXJlbVwiLCBtYXJnaW5Cb3R0b206IDggfX0+TWVzYXMgVmluY3VsYWRhczwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93XCIgc3R5bGU9e3sgZ2FwOiA4LCBtYXJnaW5Cb3R0b206IDEyLCBhbGlnbkl0ZW1zOiBcImVuZFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZCBsYWJlbD1cIlNlbGVjaW9uZSBhIE1lc2FcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhhMTF5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey4uLmExMXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhYmxlRm9ybS50YWJsZUlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGFibGVGb3JtKHsgdGFibGVJZDogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkVzY29saGEgdW1hIG1lc2HigKY8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGJyYW5jaFRhYmxlc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgodCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dC5pZH0gdmFsdWU9e3QuaWR9Pk1lc2Ege3QubnVtYmVyfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9GaWVsZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF0YWJsZUZvcm0udGFibGVJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXthZGRUYWJsZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhZGRUYWJsZU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICsgVmluY3VsYXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthcmVhVGFibGVzUXVlcnkuaXNMb2FkaW5nID8gPHA+Q2FycmVnYW5kbyBtZXNhcy4uLjwvcD4gOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dWwgc3R5bGU9e3sgcGFkZGluZ0xlZnQ6IDIwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthcmVhVGFibGVzUXVlcnkuZGF0YT8ubWFwKHQgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXt0LmlkfSBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDQgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNZXNhIHt0YWJsZU51bWJlck1hcC5nZXQodC5kaW5pbmdUYWJsZUlkKSA/PyB0LmRpbmluZ1RhYmxlSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luTGVmdDogOCwgY29sb3I6IFwidmFyKC0tcmVkKVwiLCBiYWNrZ3JvdW5kOiBcIm5vbmVcIiwgYm9yZGVyOiBcIm5vbmVcIiwgY3Vyc29yOiBcInBvaW50ZXJcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZVRhYmxlTXV0YXRpb24ubXV0YXRlKHQuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChyZW1vdmVyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FyZWFUYWJsZXNRdWVyeS5kYXRhPy5sZW5ndGggPT09IDAgJiYgPGxpIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5OZW5odW1hIG1lc2EgdmluY3VsYWRhIGEgZXN0YSBwcmHDp2EuPC9saT59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8aHIgc3R5bGU9e3sgYm9yZGVyOiBcIjBcIiwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsIG1hcmdpbjogXCIxNnB4IDBcIiB9fSAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4xcmVtXCIsIG1hcmdpbkJvdHRvbTogOCB9fT5HYXLDp29ucyBubyBUdXJubzwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93XCIgc3R5bGU9e3sgZ2FwOiA4LCBtYXJnaW5Cb3R0b206IDEyLCBhbGlnbkl0ZW1zOiBcImVuZFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZCBsYWJlbD1cIlNlbGVjaW9uZSBvIEdhcsOnb21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhhMTF5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey4uLmExMXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Fzc2lnbm1lbnRGb3JtLmVtcGxveWVlSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBc3NpZ25tZW50Rm9ybSh7IGVtcGxveWVlSWQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5Fc2NvbGhhIHVtIGdhcsOnb23igKY8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGVtcGxveWVlc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgoZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZS5pZH0gdmFsdWU9e2UuaWR9PntlLm5hbWV9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ZpZWxkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWFzc2lnbm1lbnRGb3JtLmVtcGxveWVlSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17c3RhcnRBc3NpZ25tZW50TXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0YXJ0QXNzaWdubWVudE11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICsgSW5pY2lhciBUdXJub1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Fzc2lnbm1lbnRzUXVlcnkuaXNMb2FkaW5nID8gPHA+Q2FycmVnYW5kbyBlc2NhbGEuLi48L3A+IDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsIHN0eWxlPXt7IHBhZGRpbmdMZWZ0OiAyMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXNzaWdubWVudHNRdWVyeS5kYXRhPy5tYXAoYSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2EuaWR9IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogNCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDUwMCB9fT57ZW1wbG95ZWVOYW1lTWFwLmdldChhLmVtcGxveWVlSWQpID8/IGEuZW1wbG95ZWVJZH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBtYXJnaW5MZWZ0OiA2IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChpbmljaW91IMOgcyB7bmV3IERhdGUoYS5zdGFydEF0KS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KX0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luTGVmdDogOCwgY29sb3I6IFwidmFyKC0tcmVkKVwiLCBiYWNrZ3JvdW5kOiBcIm5vbmVcIiwgYm9yZGVyOiBcIm5vbmVcIiwgY3Vyc29yOiBcInBvaW50ZXJcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGVuZEFzc2lnbm1lbnRNdXRhdGlvbi5tdXRhdGUoYS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGVuY2VycmFyIHR1cm5vKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Fzc2lnbm1lbnRzUXVlcnkuZGF0YT8ubGVuZ3RoID09PSAwICYmIDxsaSBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+TmVuaHVtIGdhcsOnb20gYWxvY2FkbyBuZXN0YSBwcmHDp2EuPC9saT59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8L21haW4+XHJcbiAgICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2RpbmluZ2FyZWFzL0RpbmluZ0FyZWFzUGFnZS50c3gifQ==