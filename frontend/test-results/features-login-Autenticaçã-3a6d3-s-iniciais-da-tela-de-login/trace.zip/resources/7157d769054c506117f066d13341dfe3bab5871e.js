import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Switch.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Switch.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function Switch({ checked, onChange, label, disabled = false }) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      role: "switch",
      "aria-checked": checked,
      "aria-label": label,
      disabled,
      className: `switch ${checked ? "is-on" : ""}`,
      onClick: () => onChange(!checked),
      children: /* @__PURE__ */ jsxDEV("span", { className: "switch-knob" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Switch.tsx",
        lineNumber: 40,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Switch.tsx",
      lineNumber: 31,
      columnNumber: 5
    },
    this
  );
}
_c = Switch;
var _c;
$RefreshReg$(_c, "Switch");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Switch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Switch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JNOzs7Ozs7Ozs7Ozs7Ozs7O0FBWEMsZ0JBQVNBLE9BQU8sRUFBRUMsU0FBU0MsVUFBVUMsT0FBT0MsV0FBVyxNQUFhLEdBQUc7QUFDNUUsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0wsTUFBSztBQUFBLE1BQ0wsZ0JBQWNIO0FBQUFBLE1BQ2QsY0FBWUU7QUFBQUEsTUFDWjtBQUFBLE1BQ0EsV0FBVyxVQUFVRixVQUFVLFVBQVUsRUFBRTtBQUFBLE1BQzNDLFNBQVMsTUFBTUMsU0FBUyxDQUFDRCxPQUFPO0FBQUEsTUFFaEMsaUNBQUMsVUFBSyxXQUFVLGlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUE7QUFBQSxJQVQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFVQTtBQUVKO0FBQUNJLEtBZGVMO0FBQU0sSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiU3dpdGNoIiwiY2hlY2tlZCIsIm9uQ2hhbmdlIiwibGFiZWwiLCJkaXNhYmxlZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlN3aXRjaC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW50ZXJmYWNlIFByb3BzIHtcbiAgY2hlY2tlZDogYm9vbGVhbjtcbiAgb25DaGFuZ2U6IChuZXh0OiBib29sZWFuKSA9PiB2b2lkO1xuICAvKiogcsOzdHVsbyBhY2Vzc8OtdmVsIG9icmlnYXTDs3JpbyAocm9sZT1cInN3aXRjaFwiKSAqL1xuICBsYWJlbDogc3RyaW5nO1xuICBkaXNhYmxlZD86IGJvb2xlYW47XG59XG5cbi8qKiBJbnRlcnJ1cHRvciBhY2Vzc8OtdmVsOiByb2xlPVwic3dpdGNoXCIgKyBhcmlhLWNoZWNrZWQsIG5hdmVnw6F2ZWwgcG9yIHRlY2xhZG8uICovXG5leHBvcnQgZnVuY3Rpb24gU3dpdGNoKHsgY2hlY2tlZCwgb25DaGFuZ2UsIGxhYmVsLCBkaXNhYmxlZCA9IGZhbHNlIH06IFByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICByb2xlPVwic3dpdGNoXCJcbiAgICAgIGFyaWEtY2hlY2tlZD17Y2hlY2tlZH1cbiAgICAgIGFyaWEtbGFiZWw9e2xhYmVsfVxuICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgY2xhc3NOYW1lPXtgc3dpdGNoICR7Y2hlY2tlZCA/IFwiaXMtb25cIiA6IFwiXCJ9YH1cbiAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKCFjaGVja2VkKX1cbiAgICA+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJzd2l0Y2gta25vYlwiIC8+XG4gICAgPC9idXR0b24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvdWkvU3dpdGNoLnRzeCJ9