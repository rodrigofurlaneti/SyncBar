import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Skeleton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Skeleton.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function SkeletonRow({ height = 20 }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "skeleton", style: { height, width: "100%" } }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Skeleton.tsx",
    lineNumber: 29,
    columnNumber: 10
  }, this);
}
_c = SkeletonRow;
export function SkeletonList({ rows = 4, rowHeight = 56 }) {
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10 }, "aria-hidden": "true", children: Array.from({ length: rows }).map(
    (_, i) => /* @__PURE__ */ jsxDEV(SkeletonRow, { height: rowHeight }, i, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Skeleton.tsx",
      lineNumber: 48,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Skeleton.tsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
}
_c2 = SkeletonList;
var _c, _c2;
$RefreshReg$(_c, "SkeletonRow");
$RefreshReg$(_c2, "SkeletonList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Skeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1M7Ozs7Ozs7Ozs7Ozs7Ozs7QUFERixnQkFBU0EsWUFBWSxFQUFFQyxTQUFTLEdBQWEsR0FBRztBQUNyRCxTQUFPLHVCQUFDLFNBQUksV0FBVSxZQUFXLE9BQU8sRUFBRUEsUUFBUUMsT0FBTyxPQUFPLEtBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkQ7QUFDcEU7QUFBQ0MsS0FGZUg7QUFnQlQsZ0JBQVNJLGFBQWEsRUFBRUMsT0FBTyxHQUFHQyxZQUFZLEdBQWMsR0FBRztBQUNwRSxTQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUFHLGVBQVksUUFDbkRDLGdCQUFNQyxLQUFLLEVBQUVDLFFBQVFOLEtBQUssQ0FBQyxFQUFFTztBQUFBQSxJQUFJLENBQUNDLEdBQUdDLE1BQ3BDLHVCQUFDLGVBQW9CLFFBQVFSLGFBQVhRLEdBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUM7QUFBQSxFQUN4QyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQTtBQUVKO0FBQUNDLE1BUmVYO0FBQVksSUFBQUQsSUFBQVk7QUFBQSxhQUFBWixJQUFBO0FBQUEsYUFBQVksS0FBQSIsIm5hbWVzIjpbIlNrZWxldG9uUm93IiwiaGVpZ2h0Iiwid2lkdGgiLCJfYyIsIlNrZWxldG9uTGlzdCIsInJvd3MiLCJyb3dIZWlnaHQiLCJkaXNwbGF5IiwiZ2FwIiwiQXJyYXkiLCJmcm9tIiwibGVuZ3RoIiwibWFwIiwiXyIsImkiLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2tlbGV0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImludGVyZmFjZSBSb3dQcm9wcyB7XHJcbiAgLyoqIGFsdHVyYSBkYSBsaW5oYSwgZW0gcHgg4oCUIGNvbWJpbmUgY29tIGEgYWx0dXJhIHJlYWwgZG8gY29udGXDumRvIHF1ZSBlbGEgc3Vic3RpdHVpICovXHJcbiAgaGVpZ2h0PzogbnVtYmVyO1xyXG59XHJcblxyXG4vKiogVW1hIGxpbmhhIGRlIHNrZWxldG9uIGlzb2xhZGEuIFVzYSBhIGNsYXNzZSBgLnNrZWxldG9uYCBxdWUgasOhIGV4aXN0ZSBlbVxyXG4gKiBnbG9iYWwuY3NzIChzaGltbWVyICsgYHByZWZlcnMtcmVkdWNlZC1tb3Rpb25gKSBtYXMgcXVlLCBhbnRlcyBkZXNzZVxyXG4gKiBjb21wb25lbnRlLCBuw6NvIGVyYSBjb25zdW1pZGEgZW0gbmVuaHVtYSB0ZWxhLiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gU2tlbGV0b25Sb3coeyBoZWlnaHQgPSAyMCB9OiBSb3dQcm9wcykge1xyXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInNrZWxldG9uXCIgc3R5bGU9e3sgaGVpZ2h0LCB3aWR0aDogXCIxMDAlXCIgfX0gLz47XHJcbn1cclxuXHJcbmludGVyZmFjZSBMaXN0UHJvcHMge1xyXG4gIC8qKiBxdWFudGFzIGxpbmhhcyBtb3N0cmFyIGVucXVhbnRvIGEgY29uc3VsdGEgY2FycmVnYSAqL1xyXG4gIHJvd3M/OiBudW1iZXI7XHJcbiAgcm93SGVpZ2h0PzogbnVtYmVyO1xyXG59XHJcblxyXG4vKipcclxuICogTGlzdGEgZGUgbGluaGFzIGRlIHNrZWxldG9uIOKAlCBzdWJzdGl0dWkgbyB0ZXh0byBzb2x0byBcIkNhcnJlZ2FuZG/igKZcIlxyXG4gKiAocHJlc2VudGUgZW0gc8OzIDQgZGFzIH4zMCB0ZWxhcyBkbyBhcHApIG5hcyBkZW1haXMgdGVsYXMgcXVlIGhvamUgbsOjb1xyXG4gKiBtb3N0cmFtIG5hZGEgZHVyYW50ZSBvIGBpc0xvYWRpbmdgIGRvIHVzZVF1ZXJ5LCBldml0YW5kbyBvIGZsYXNoIGRlXHJcbiAqIGxheW91dCB2YXppby5cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBTa2VsZXRvbkxpc3QoeyByb3dzID0gNCwgcm93SGVpZ2h0ID0gNTYgfTogTGlzdFByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAgfX0gYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiByb3dzIH0pLm1hcCgoXywgaSkgPT4gKFxyXG4gICAgICAgIDxTa2VsZXRvblJvdyBrZXk9e2l9IGhlaWdodD17cm93SGVpZ2h0fSAvPlxyXG4gICAgICApKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL3VpL1NrZWxldG9uLnRzeCJ9