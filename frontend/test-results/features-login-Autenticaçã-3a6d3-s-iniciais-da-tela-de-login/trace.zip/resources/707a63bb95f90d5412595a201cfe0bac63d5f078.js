import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/OrderDrawer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  addOrderItem,
  applyDiscount,
  cancelOrder,
  closeOrder,
  getOrder,
  raiseCreditLimit,
  removeServiceFee,
  reopenOrder,
  updateItemStatus
} from "/src/features/orders/api.ts";
import { getMenu } from "/src/features/catalog/api.ts";
import { getComplementGroups } from "/src/features/catalog/complementsApi.ts";
import { getActivePromotions } from "/src/features/promotions/api.ts";
import { getPrintSettings, printBill } from "/src/features/printing/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import {
  OrderItemStatus,
  OrderStatus,
  formatBRL,
  orderItemStatusLabel,
  promotionBadge
} from "/src/lib/types.ts";
import { Overlay } from "/src/features/orders/Overlay.tsx";
import { PaymentPanel } from "/src/features/orders/PaymentPanel.tsx";
import { PartialPaymentDialog } from "/src/features/orders/PartialPaymentDialog.tsx";
import { ComplementSelectorModal } from "/src/features/orders/ComplementSelectorModal.tsx";
import { useMyFeatures } from "/src/features/access/hooks.ts";
import { useDialog } from "/src/ui/Dialog.tsx";
import { getServiceFeeSetting } from "/src/features/settings/api.ts";
const nextItemStatus = {
  [OrderItemStatus.Lancado]: OrderItemStatus.EnviadoCozinha,
  [OrderItemStatus.EnviadoCozinha]: OrderItemStatus.EmPreparo,
  [OrderItemStatus.EmPreparo]: OrderItemStatus.Pronto,
  [OrderItemStatus.Pronto]: OrderItemStatus.Entregue
};
function creditLimitColor(totalAmount, creditLimitAmount) {
  if (totalAmount >= creditLimitAmount) return "var(--danger)";
  if (totalAmount >= creditLimitAmount * 0.8) return "var(--busy)";
  return "var(--ok)";
}
export function OrderDrawer({ orderId, onClose }) {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const { companyId, employeeId } = useAuthStore();
  const [menuOpen, setMenuOpen] = useState(false);
  const [partialOpen, setPartialOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [discount, setDiscount] = useState("");
  const [actionError, setActionError] = useState(null);
  const [selectingItem, setSelectingItem] = useState(null);
  const orderQuery = useQuery({
    queryKey: ["order", orderId],
    queryFn: () => getOrder(orderId)
  });
  const featuresQuery = useMyFeatures();
  const canUseCash = featuresQuery.data?.canManageAccess || featuresQuery.data?.features.includes("Caixa");
  const activePromosQuery = useQuery({
    queryKey: ["promotions", "active"],
    queryFn: () => getActivePromotions(useAuthStore.getState().branchId),
    refetchInterval: 6e4
  });
  const promoByProduct = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const p of activePromosQuery.data ?? []) map.set(p.productId, promotionBadge(p));
    return map;
  }, [activePromosQuery.data]);
  const menuQuery = useQuery({
    queryKey: ["menu", companyId],
    queryFn: () => getMenu(companyId ?? 1),
    staleTime: 5 * 6e4
  });
  const productNameById = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const item of menuQuery.data ?? []) map.set(item.id, item.name);
    return map;
  }, [menuQuery.data]);
  const complementGroupsQuery = useQuery({
    queryKey: ["complement-groups", companyId],
    queryFn: () => getComplementGroups(companyId ?? 1),
    staleTime: 5 * 6e4
  });
  const complementNameById = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const group of complementGroupsQuery.data ?? [])
      for (const c of group.complements) map.set(c.id, c.complementItemName);
    return map;
  }, [complementGroupsQuery.data]);
  const order = orderQuery.data;
  const refetchOrder = () => void queryClient.invalidateQueries({ queryKey: ["order", orderId] });
  const onError = (error) => setActionError(error instanceof ApiError ? error.message : "Operação falhou.");
  const run = { onSuccess: () => {
    setActionError(null);
    refetchOrder();
  }, onError };
  const addItem = useMutation({
    mutationFn: ({
      productId,
      complements
    }) => addOrderItem(orderId, productId, 1, null, employeeId, complements),
    onSuccess: () => {
      setActionError(null);
      setSelectingItem(null);
      refetchOrder();
    },
    onError
  });
  const handlePickItem = (item) => {
    if (item.complementGroups.length > 0) setSelectingItem(item);
    else
      addItem.mutate({ productId: item.id });
  };
  const advanceItem = useMutation({
    mutationFn: ({ itemId, statusId }) => updateItemStatus(orderId, itemId, statusId, employeeId),
    ...run
  });
  const discountMutation = useMutation({
    mutationFn: () => applyDiscount(orderId, Number(discount.replace(",", "."))),
    ...run
  });
  const printSettingsQuery = useQuery({
    queryKey: ["printing", "settings", useAuthStore.getState().branchId],
    queryFn: () => getPrintSettings(useAuthStore.getState().branchId),
    staleTime: 6e4
  });
  const serviceFeeSettingQuery = useQuery({
    queryKey: ["orders", "service-fee-setting", useAuthStore.getState().branchId],
    queryFn: () => getServiceFeeSetting(useAuthStore.getState().branchId),
    staleTime: 6e4
  });
  const serviceFeeOn = serviceFeeSettingQuery.data?.enabled ?? true;
  const printBillMutation = useMutation({
    mutationFn: () => printBill(orderId),
    onError: (e) => setActionError(e instanceof ApiError ? e.message : "Falha ao imprimir a conta.")
  });
  const closeMutation = useMutation({
    mutationFn: () => closeOrder(orderId),
    onSuccess: () => {
      setActionError(null);
      refetchOrder();
      if (printSettingsQuery.data?.printBillsEnabled)
        void dialog.confirm({ title: "Imprimir conta", message: "Deseja imprimir a conta?", confirmLabel: "Imprimir" }).then((ok) => {
          if (ok) printBillMutation.mutate();
        });
    },
    onError
  });
  const removeFeeMutation = useMutation({ mutationFn: () => removeServiceFee(orderId), ...run });
  const reopenMutation = useMutation({ mutationFn: () => reopenOrder(orderId), ...run });
  const raiseLimitMutation = useMutation({
    mutationFn: (newLimit) => raiseCreditLimit(orderId, newLimit),
    ...run
  });
  const cancelMutation = useMutation({
    mutationFn: () => cancelOrder(orderId),
    onSuccess: onClose,
    onError
  });
  const filteredMenu = useMemo(
    () => (menuQuery.data ?? []).filter(
      (item) => item.name.toLowerCase().includes(search.toLowerCase())
    ),
    [menuQuery.data, search]
  );
  const isOpen = order !== void 0 && (order.orderStatusId === OrderStatus.Aberto || order.orderStatusId === OrderStatus.EmAndamento || order.orderStatusId === OrderStatus.AguardandoPagamento);
  const isEditable = order !== void 0 && (order.orderStatusId === OrderStatus.Aberto || order.orderStatusId === OrderStatus.EmAndamento);
  const awaitingPayment = order !== void 0 && order.orderStatusId === OrderStatus.AguardandoPagamento;
  const title = order?.diningTableId ? `Mesa · pedido #${orderId}` : `Comanda · pedido #${orderId}`;
  return /* @__PURE__ */ jsxDEV(Overlay, { title, onClose, wide: true, children: [
    orderQuery.isLoading && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)" }, children: "Carregando pedido…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
      lineNumber: 245,
      columnNumber: 32
    }, this),
    orderQuery.isError && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: "Falha ao carregar o pedido." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
      lineNumber: 246,
      columnNumber: 30
    }, this),
    order && partialOpen && /* @__PURE__ */ jsxDEV(
      PartialPaymentDialog,
      {
        order,
        onClose: () => setPartialOpen(false),
        onRegistered: () => {
          setPartialOpen(false);
          setActionError(null);
          refetchOrder();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
        lineNumber: 249,
        columnNumber: 7
      },
      this
    ),
    selectingItem && /* @__PURE__ */ jsxDEV(
      ComplementSelectorModal,
      {
        productName: selectingItem.name,
        groups: selectingItem.complementGroups,
        onCancel: () => setSelectingItem(null),
        submitting: addItem.isPending,
        onConfirm: (complements) => addItem.mutate({ productId: selectingItem.id, complements })
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
        lineNumber: 261,
        columnNumber: 7
      },
      this
    ),
    order && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      order.comandaId !== null && order.creditLimitAmount !== null && /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "ticket",
          style: {
            padding: "10px 16px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 10,
            flexWrap: "wrap",
            borderColor: order.totalAmount >= order.creditLimitAmount ? "var(--danger)" : "var(--line)"
          },
          children: [
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.88rem", color: "var(--ink-dim)" }, children: [
              "Limite da comanda:",
              " ",
              /* @__PURE__ */ jsxDEV(
                "strong",
                {
                  className: "mono-num",
                  style: {
                    color: creditLimitColor(order.totalAmount, order.creditLimitAmount)
                  },
                  children: [
                    formatBRL(order.totalAmount),
                    " / ",
                    formatBRL(order.creditLimitAmount)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                  lineNumber: 290,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 288,
              columnNumber: 15
            }, this),
            featuresQuery.data?.canManageAccess && /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: "btn-ghost",
                type: "button",
                style: { minHeight: 44, padding: "0 12px", fontSize: "0.85rem" },
                disabled: raiseLimitMutation.isPending,
                onClick: async () => {
                  const answer = await dialog.prompt({
                    title: "Liberar limite",
                    label: "Novo limite da comanda (R$)",
                    inputMode: "decimal",
                    defaultValue: String(order.creditLimitAmount + 100)
                  });
                  if (answer === null) return;
                  const value = Number(answer.replace(",", "."));
                  if (Number.isFinite(value) && value > 0) raiseLimitMutation.mutate(value);
                },
                children: "Liberar limite (gerente)"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                lineNumber: 300,
                columnNumber: 11
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 275,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Itens" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 325,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
            "aberto às ",
            new Date(order.openedAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 328,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 324,
          columnNumber: 13
        }, this),
        order.items.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-faint)" }, children: "Nenhum item lançado ainda." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 334,
          columnNumber: 11
        }, this),
        order.items.map((item) => {
          const next = nextItemStatus[item.orderItemStatusId];
          const cancelled = item.orderItemStatusId === OrderItemStatus.Cancelado;
          return /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "mono-num",
                  style: {
                    textDecoration: cancelled ? "line-through" : "none",
                    color: cancelled ? "var(--ink-faint)" : "var(--ink)"
                  },
                  children: [
                    item.quantity,
                    " × ",
                    productNameById.get(item.productId) ?? `produto #${item.productId}`,
                    " — ",
                    formatBRL(item.totalAmount)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                  lineNumber: 345,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
                orderItemStatusLabel[item.orderItemStatusId],
                item.notes ? ` · ${item.notes}` : ""
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                lineNumber: 354,
                columnNumber: 21
              }, this),
              item.complements.length > 0 && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
                "+ ",
                item.complements.map((c) => complementNameById.get(c.complementId) ?? `complemento #${c.complementId}`).join(", ")
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                lineNumber: 359,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 344,
              columnNumber: 19
            }, this),
            isOpen && next !== void 0 && !cancelled && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 6 }, children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: "btn-ghost",
                  type: "button",
                  style: { minHeight: 44, padding: "0 10px", fontSize: "0.85rem" },
                  onClick: () => advanceItem.mutate({ itemId: item.id, statusId: next }),
                  children: [
                    "→ ",
                    orderItemStatusLabel[next]
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                  lineNumber: 368,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: "btn-danger",
                  type: "button",
                  "aria-label": `Cancelar item ${productNameById.get(item.productId) ?? ""}`.trim(),
                  title: "Cancelar item",
                  style: { minHeight: 44, padding: "0 10px", fontSize: "0.85rem" },
                  onClick: () => advanceItem.mutate({ itemId: item.id, statusId: OrderItemStatus.Cancelado }),
                  children: "✕"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                  lineNumber: 376,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 367,
              columnNumber: 17
            }, this)
          ] }, item.id, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 343,
            columnNumber: 15
          }, this);
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-dim)" }, children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Subtotal" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 395,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(order.subtotalAmount) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 396,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 394,
          columnNumber: 13
        }, this),
        order.discountAmount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ok)" }, children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Desconto" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 400,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: [
            "− ",
            formatBRL(order.discountAmount)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 401,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 399,
          columnNumber: 11
        }, this),
        order.serviceFeeAmount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-dim)" }, children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Serviço (10%)" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 406,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(order.serviceFeeAmount) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 407,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 405,
          columnNumber: 11
        }, this),
        order.partialPaidAmount > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ok)" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Pago parcial" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 413,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: [
              "− ",
              formatBRL(order.partialPaidAmount)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 414,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 412,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--amber)" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Restante" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 417,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(order.totalAmount - order.partialPaidAmount) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 418,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 416,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 411,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-total", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Total" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 423,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--amber)" }, children: formatBRL(order.totalAmount) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 424,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 422,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
        lineNumber: 323,
        columnNumber: 11
      }, this),
      actionError && /* @__PURE__ */ jsxDEV("p", { className: "error-text", role: "alert", children: actionError }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
        lineNumber: 431,
        columnNumber: 9
      }, this),
      (isOpen && order.diningTableId !== null && canUseCash && order.totalAmount - order.partialPaidAmount > 0 || awaitingPayment) && /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 8 }, children: [
        isOpen && order.diningTableId !== null && canUseCash && order.totalAmount - order.partialPaidAmount > 0 && /* @__PURE__ */ jsxDEV("button", { className: "btn-ghost", type: "button", onClick: () => setPartialOpen(true), children: "💸 Pagamento parcial (cliente saindo)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 446,
          columnNumber: 11
        }, this),
        awaitingPayment && /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: "btn-ghost",
            type: "button",
            disabled: reopenMutation.isPending,
            onClick: async () => {
              if (await dialog.confirm({
                title: "Reabrir consumo",
                message: "Reabrir a conta para consumo? A taxa de serviço será recalculada no próximo fechamento.",
                confirmLabel: "Reabrir"
              }))
                reopenMutation.mutate();
            },
            children: "↩ Reabrir consumo (fechou por engano)"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 452,
            columnNumber: 11
          },
          this
        ),
        awaitingPayment && order.serviceFeeAmount > 0 && featuresQuery.data?.canManageAccess && /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: "btn-ghost",
            type: "button",
            disabled: removeFeeMutation.isPending,
            onClick: async () => {
              if (await dialog.confirm({
                title: "Retirar taxa de serviço",
                message: "Retirar a taxa de serviço (10%) desta conta?",
                confirmLabel: "Retirar 10%"
              }))
                removeFeeMutation.mutate();
            },
            children: removeFeeMutation.isPending ? "Retirando…" : "Retirar 10% (gerente)"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 473,
            columnNumber: 11
          },
          this
        ),
        awaitingPayment && printSettingsQuery.data?.printBillsEnabled && /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: "btn-ghost",
            type: "button",
            disabled: printBillMutation.isPending,
            onClick: () => printBillMutation.mutate(),
            children: printBillMutation.isPending ? "Imprimindo…" : "🖨 Imprimir conta"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 493,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
        lineNumber: 443,
        columnNumber: 9
      }, this),
      awaitingPayment && /* @__PURE__ */ jsxDEV(
        PaymentPanel,
        {
          order,
          onPaid: () => {
            setActionError(null);
            refetchOrder();
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 506,
          columnNumber: 9
        },
        this
      ),
      isEditable && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: "btn-primary",
            type: "button",
            "aria-expanded": menuOpen,
            "aria-controls": "order-drawer-menu-panel",
            onClick: () => setMenuOpen((v) => !v),
            children: menuOpen ? "Fechar cardápio" : "+ Lançar item"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 517,
            columnNumber: 15
          },
          this
        ),
        menuOpen && /* @__PURE__ */ jsxDEV("div", { id: "order-drawer-menu-panel", style: { display: "grid", gap: 10 }, children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              placeholder: "Buscar no cardápio…",
              value: search,
              onChange: (e) => setSearch(e.target.value),
              autoFocus: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 529,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8, maxHeight: 260, overflowY: "auto" }, children: [
            menuQuery.isLoading && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)" }, children: "Carregando cardápio…" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 537,
              columnNumber: 15
            }, this),
            filteredMenu.map(
              (item) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: "btn-ghost",
                  type: "button",
                  style: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 14px", minHeight: 56 },
                  disabled: addItem.isPending,
                  onClick: () => handlePickItem(item),
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", alignItems: "center", gap: 10 }, children: [
                      item.imageUrl && /* @__PURE__ */ jsxDEV(
                        "img",
                        {
                          src: item.imageUrl,
                          alt: "",
                          style: { width: 40, height: 40, objectFit: "cover", borderRadius: 8 }
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                          lineNumber: 550,
                          columnNumber: 19
                        },
                        this
                      ),
                      item.name,
                      promoByProduct.has(item.id) && /* @__PURE__ */ jsxDEV(
                        "span",
                        {
                          style: {
                            marginLeft: 8,
                            fontFamily: "var(--font-cond)",
                            fontSize: "0.68rem",
                            letterSpacing: "0.1em",
                            color: "var(--amber-ink)",
                            background: "var(--amber)",
                            borderRadius: 4,
                            padding: "2px 6px",
                            fontWeight: 700
                          },
                          children: promoByProduct.get(item.id)
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                          lineNumber: 558,
                          columnNumber: 19
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                      lineNumber: 548,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--amber)" }, children: formatBRL(item.salePrice) }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                      lineNumber: 575,
                      columnNumber: 25
                    }, this)
                  ]
                },
                item.id,
                true,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
                  lineNumber: 540,
                  columnNumber: 15
                },
                this
              )
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
            lineNumber: 535,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 528,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10 }, children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              placeholder: "Desconto (R$)…",
              "aria-label": "Desconto em reais",
              inputMode: "decimal",
              value: discount,
              onChange: (e) => setDiscount(e.target.value),
              style: { flex: 1 }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 585,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "btn-ghost",
              type: "button",
              disabled: discount.trim() === "" || discountMutation.isPending,
              onClick: () => discountMutation.mutate(),
              children: "Aplicar"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 593,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 584,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "drawer-actionbar", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "btn-danger",
              type: "button",
              style: { flex: 1 },
              disabled: cancelMutation.isPending,
              onClick: async () => {
                if (await dialog.confirm({
                  title: "Cancelar pedido",
                  message: "Cancelar este pedido? A mesa/comanda será liberada.",
                  confirmLabel: "Cancelar pedido",
                  cancelLabel: "Voltar",
                  danger: true
                }))
                  cancelMutation.mutate();
              },
              children: "Cancelar pedido"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 606,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "btn-primary",
              type: "button",
              style: { flex: 2 },
              disabled: order.items.length === 0 || closeMutation.isPending,
              onClick: () => closeMutation.mutate(),
              children: serviceFeeOn ? "Fechar conta (+10%)" : "Fechar conta (sem 10%)"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
              lineNumber: 626,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
          lineNumber: 605,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
        lineNumber: 516,
        columnNumber: 9
      }, this),
      !isOpen && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)" }, children: [
        "Pedido encerrado — status ",
        order.orderStatusId === OrderStatus.Pago ? "Pago" : "Cancelado",
        "."
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
        lineNumber: 640,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
      lineNumber: 273,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx",
    lineNumber: 244,
    columnNumber: 5
  }, this);
}
_s(OrderDrawer, "yxAMk3MzXFogW63S7HRaII1mjic=", false, function() {
  return [useQueryClient, useDialog, useAuthStore, useQuery, useMyFeatures, useQuery, useQuery, useQuery, useMutation, useMutation, useMutation, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation];
});
_c = OrderDrawer;
var _c;
$RefreshReg$(_c, "OrderDrawer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OrderDrawer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaU8rQixTQXNLakIsVUF0S2lCOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpPOUIsU0FBU0EsU0FBU0MsZ0JBQWdCO0FBQ25DLFNBQVNDLGFBQWFDLFVBQVVDLHNCQUFzQjtBQUN0RDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0Msa0JBQWtCQyxpQkFBaUI7QUFDNUMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsNEJBQTRCO0FBT3JDLE1BQU1DLGlCQUF5QztBQUFBLEVBQzdDLENBQUNaLGdCQUFnQmEsT0FBTyxHQUFHYixnQkFBZ0JjO0FBQUFBLEVBQzNDLENBQUNkLGdCQUFnQmMsY0FBYyxHQUFHZCxnQkFBZ0JlO0FBQUFBLEVBQ2xELENBQUNmLGdCQUFnQmUsU0FBUyxHQUFHZixnQkFBZ0JnQjtBQUFBQSxFQUM3QyxDQUFDaEIsZ0JBQWdCZ0IsTUFBTSxHQUFHaEIsZ0JBQWdCaUI7QUFDNUM7QUFFQSxTQUFTQyxpQkFBaUJDLGFBQXFCQyxtQkFBbUM7QUFDaEYsTUFBSUQsZUFBZUMsa0JBQW1CLFFBQU87QUFDN0MsTUFBSUQsZUFBZUMsb0JBQW9CLElBQUssUUFBTztBQUNuRCxTQUFPO0FBQ1Q7QUFFTyxnQkFBU0MsWUFBWSxFQUFFQyxTQUFTQyxRQUFlLEdBQUc7QUFBQUMsS0FBQTtBQUN2RCxRQUFNQyxjQUFjMUMsZUFBZTtBQUNuQyxRQUFNMkMsU0FBU2hCLFVBQVU7QUFDekIsUUFBTSxFQUFFaUIsV0FBV0MsV0FBVyxJQUFJOUIsYUFBYTtBQUMvQyxRQUFNLENBQUMrQixVQUFVQyxXQUFXLElBQUlsRCxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDbUQsYUFBYUMsY0FBYyxJQUFJcEQsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ3FELFFBQVFDLFNBQVMsSUFBSXRELFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUN1RCxVQUFVQyxXQUFXLElBQUl4RCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDeUQsYUFBYUMsY0FBYyxJQUFJMUQsU0FBd0IsSUFBSTtBQUNsRSxRQUFNLENBQUMyRCxlQUFlQyxnQkFBZ0IsSUFBSTVELFNBQWtDLElBQUk7QUFDaEYsUUFBTTZELGFBQWEzRCxTQUFTO0FBQUEsSUFDMUI0RCxVQUFVLENBQUMsU0FBU3BCLE9BQU87QUFBQSxJQUMzQnFCLFNBQVNBLE1BQU12RCxTQUFTa0MsT0FBTztBQUFBLEVBQ2pDLENBQUM7QUFFRCxRQUFNc0IsZ0JBQWdCbkMsY0FBYztBQUNwQyxRQUFNb0MsYUFDSkQsY0FBY0UsTUFBTUMsbUJBQW1CSCxjQUFjRSxNQUFNRSxTQUFTQyxTQUFTLE9BQU87QUFFdEYsUUFBTUMsb0JBQW9CcEUsU0FBUztBQUFBLElBQ2pDNEQsVUFBVSxDQUFDLGNBQWMsUUFBUTtBQUFBLElBQ2pDQyxTQUFTQSxNQUFNaEQsb0JBQW9CRyxhQUFhcUQsU0FBUyxFQUFFQyxRQUFRO0FBQUEsSUFDbkVDLGlCQUFpQjtBQUFBLEVBQ25CLENBQUM7QUFFRCxRQUFNQyxpQkFBaUIzRSxRQUFRLE1BQU07QUFDbkMsVUFBTTRFLE1BQU0sb0JBQUlDLElBQW9CO0FBQ3BDLGVBQVdDLEtBQUtQLGtCQUFrQkosUUFBUSxHQUFJUyxLQUFJRyxJQUFJRCxFQUFFRSxXQUFXdkQsZUFBZXFELENBQUMsQ0FBQztBQUNwRixXQUFPRjtBQUFBQSxFQUNULEdBQUcsQ0FBQ0wsa0JBQWtCSixJQUFJLENBQUM7QUFFM0IsUUFBTWMsWUFBWTlFLFNBQVM7QUFBQSxJQUN6QjRELFVBQVUsQ0FBQyxRQUFRZixTQUFTO0FBQUEsSUFDNUJnQixTQUFTQSxNQUFNbEQsUUFBUWtDLGFBQWEsQ0FBQztBQUFBLElBQ3JDa0MsV0FBVyxJQUFJO0FBQUEsRUFDakIsQ0FBQztBQUVELFFBQU1DLGtCQUFrQm5GLFFBQVEsTUFBTTtBQUNwQyxVQUFNNEUsTUFBTSxvQkFBSUMsSUFBb0I7QUFDcEMsZUFBV08sUUFBUUgsVUFBVWQsUUFBUSxHQUFJUyxLQUFJRyxJQUFJSyxLQUFLQyxJQUFJRCxLQUFLRSxJQUFJO0FBQ25FLFdBQU9WO0FBQUFBLEVBQ1QsR0FBRyxDQUFDSyxVQUFVZCxJQUFJLENBQUM7QUFFbkIsUUFBTW9CLHdCQUF3QnBGLFNBQVM7QUFBQSxJQUNyQzRELFVBQVUsQ0FBQyxxQkFBcUJmLFNBQVM7QUFBQSxJQUN6Q2dCLFNBQVNBLE1BQU1qRCxvQkFBb0JpQyxhQUFhLENBQUM7QUFBQSxJQUNqRGtDLFdBQVcsSUFBSTtBQUFBLEVBQ2pCLENBQUM7QUFFRCxRQUFNTSxxQkFBcUJ4RixRQUFRLE1BQU07QUFDdkMsVUFBTTRFLE1BQU0sb0JBQUlDLElBQW9CO0FBQ3BDLGVBQVdZLFNBQVNGLHNCQUFzQnBCLFFBQVE7QUFDaEQsaUJBQVd1QixLQUFLRCxNQUFNRSxZQUFhZixLQUFJRyxJQUFJVyxFQUFFTCxJQUFJSyxFQUFFRSxrQkFBa0I7QUFDdkUsV0FBT2hCO0FBQUFBLEVBQ1QsR0FBRyxDQUFDVyxzQkFBc0JwQixJQUFJLENBQUM7QUFFL0IsUUFBTTBCLFFBQVEvQixXQUFXSztBQUV6QixRQUFNMkIsZUFBZUEsTUFBTSxLQUFLaEQsWUFBWWlELGtCQUFrQixFQUFFaEMsVUFBVSxDQUFDLFNBQVNwQixPQUFPLEVBQUUsQ0FBQztBQUU5RixRQUFNcUQsVUFBVUEsQ0FBQ0MsVUFDZnRDLGVBQWVzQyxpQkFBaUI3RSxXQUFXNkUsTUFBTUMsVUFBVSxrQkFBa0I7QUFFL0UsUUFBTUMsTUFBTSxFQUFFQyxXQUFXQSxNQUFNO0FBQUV6QyxtQkFBZSxJQUFJO0FBQUdtQyxpQkFBYTtBQUFBLEVBQUcsR0FBR0UsUUFBUTtBQUVsRixRQUFNSyxVQUFVbkcsWUFBWTtBQUFBLElBQzFCb0csWUFBWUEsQ0FBQztBQUFBLE1BQ1h0QjtBQUFBQSxNQUNBVztBQUFBQSxJQUlGLE1BQU10RixhQUFhc0MsU0FBU3FDLFdBQVcsR0FBRyxNQUFNL0IsWUFBWTBDLFdBQVc7QUFBQSxJQUN2RVMsV0FBV0EsTUFBTTtBQUNmekMscUJBQWUsSUFBSTtBQUNuQkUsdUJBQWlCLElBQUk7QUFDckJpQyxtQkFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBRTtBQUFBQSxFQUNGLENBQUM7QUFFRCxRQUFNTyxpQkFBaUJBLENBQUNuQixTQUEyQjtBQUNqRCxRQUFJQSxLQUFLb0IsaUJBQWlCQyxTQUFTLEVBQUc1QyxrQkFBaUJ1QixJQUFJO0FBQUE7QUFDdERpQixjQUFRSyxPQUFPLEVBQUUxQixXQUFXSSxLQUFLQyxHQUFHLENBQUM7QUFBQSxFQUM1QztBQUVBLFFBQU1zQixjQUFjekcsWUFBWTtBQUFBLElBQzlCb0csWUFBWUEsQ0FBQyxFQUFFTSxRQUFRQyxTQUErQyxNQUNwRWhHLGlCQUFpQjhCLFNBQVNpRSxRQUFRQyxVQUFVNUQsVUFBVTtBQUFBLElBQ3hELEdBQUdrRDtBQUFBQSxFQUNMLENBQUM7QUFFRCxRQUFNVyxtQkFBbUI1RyxZQUFZO0FBQUEsSUFDbkNvRyxZQUFZQSxNQUFNaEcsY0FBY3FDLFNBQVNvRSxPQUFPdkQsU0FBU3dELFFBQVEsS0FBSyxHQUFHLENBQUMsQ0FBQztBQUFBLElBQzNFLEdBQUdiO0FBQUFBLEVBQ0wsQ0FBQztBQUVELFFBQU1jLHFCQUFxQjlHLFNBQVM7QUFBQSxJQUNsQzRELFVBQVUsQ0FBQyxZQUFZLFlBQVk1QyxhQUFhcUQsU0FBUyxFQUFFQyxRQUFRO0FBQUEsSUFDbkVULFNBQVNBLE1BQU0vQyxpQkFBaUJFLGFBQWFxRCxTQUFTLEVBQUVDLFFBQVE7QUFBQSxJQUNoRVMsV0FBVztBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1nQyx5QkFBeUIvRyxTQUFTO0FBQUEsSUFDdEM0RCxVQUFVLENBQUMsVUFBVSx1QkFBdUI1QyxhQUFhcUQsU0FBUyxFQUFFQyxRQUFRO0FBQUEsSUFDNUVULFNBQVNBLE1BQU1oQyxxQkFBcUJiLGFBQWFxRCxTQUFTLEVBQUVDLFFBQVE7QUFBQSxJQUNwRVMsV0FBVztBQUFBLEVBQ2IsQ0FBQztBQUNELFFBQU1pQyxlQUFlRCx1QkFBdUIvQyxNQUFNaUQsV0FBVztBQUU3RCxRQUFNQyxvQkFBb0JuSCxZQUFZO0FBQUEsSUFDcENvRyxZQUFZQSxNQUFNcEYsVUFBVXlCLE9BQU87QUFBQSxJQUNuQ3FELFNBQVNBLENBQUNzQixNQUFNM0QsZUFBZTJELGFBQWFsRyxXQUFXa0csRUFBRXBCLFVBQVUsNEJBQTRCO0FBQUEsRUFDakcsQ0FBQztBQUVELFFBQU1xQixnQkFBZ0JySCxZQUFZO0FBQUEsSUFDaENvRyxZQUFZQSxNQUFNOUYsV0FBV21DLE9BQU87QUFBQSxJQUNwQ3lELFdBQVdBLE1BQU07QUFDZnpDLHFCQUFlLElBQUk7QUFDbkJtQyxtQkFBYTtBQUViLFVBQUltQixtQkFBbUI5QyxNQUFNcUQ7QUFDM0IsYUFBS3pFLE9BQ0YwRSxRQUFRLEVBQUVDLE9BQU8sa0JBQWtCeEIsU0FBUyw0QkFBNEJ5QixjQUFjLFdBQVcsQ0FBQyxFQUNsR0MsS0FBSyxDQUFDQyxPQUFPO0FBQ1osY0FBSUEsR0FBSVIsbUJBQWtCWCxPQUFPO0FBQUEsUUFDbkMsQ0FBQztBQUFBLElBQ1A7QUFBQSxJQUNBVjtBQUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNOEIsb0JBQW9CNUgsWUFBWSxFQUFFb0csWUFBWUEsTUFBTTNGLGlCQUFpQmdDLE9BQU8sR0FBRyxHQUFHd0QsSUFBSSxDQUFDO0FBQzdGLFFBQU00QixpQkFBaUI3SCxZQUFZLEVBQUVvRyxZQUFZQSxNQUFNMUYsWUFBWStCLE9BQU8sR0FBRyxHQUFHd0QsSUFBSSxDQUFDO0FBRXJGLFFBQU02QixxQkFBcUI5SCxZQUFZO0FBQUEsSUFDckNvRyxZQUFZQSxDQUFDMkIsYUFBcUJ2SCxpQkFBaUJpQyxTQUFTc0YsUUFBUTtBQUFBLElBQ3BFLEdBQUc5QjtBQUFBQSxFQUNMLENBQUM7QUFFRCxRQUFNK0IsaUJBQWlCaEksWUFBWTtBQUFBLElBQ2pDb0csWUFBWUEsTUFBTS9GLFlBQVlvQyxPQUFPO0FBQUEsSUFDckN5RCxXQUFXeEQ7QUFBQUEsSUFDWG9EO0FBQUFBLEVBQ0YsQ0FBQztBQUVELFFBQU1tQyxlQUFlbkk7QUFBQUEsSUFDbkIsT0FDR2lGLFVBQVVkLFFBQVEsSUFBSWlFO0FBQUFBLE1BQU8sQ0FBQ2hELFNBQzdCQSxLQUFLRSxLQUFLK0MsWUFBWSxFQUFFL0QsU0FBU2hCLE9BQU8rRSxZQUFZLENBQUM7QUFBQSxJQUN2RDtBQUFBLElBQ0YsQ0FBQ3BELFVBQVVkLE1BQU1iLE1BQU07QUFBQSxFQUN6QjtBQUVBLFFBQU1nRixTQUNKekMsVUFBVTBDLFdBQ1QxQyxNQUFNMkMsa0JBQWtCbEgsWUFBWW1ILFVBQ25DNUMsTUFBTTJDLGtCQUFrQmxILFlBQVlvSCxlQUNwQzdDLE1BQU0yQyxrQkFBa0JsSCxZQUFZcUg7QUFFeEMsUUFBTUMsYUFDSi9DLFVBQVUwQyxXQUNUMUMsTUFBTTJDLGtCQUFrQmxILFlBQVltSCxVQUNuQzVDLE1BQU0yQyxrQkFBa0JsSCxZQUFZb0g7QUFFeEMsUUFBTUcsa0JBQ0poRCxVQUFVMEMsVUFBYTFDLE1BQU0yQyxrQkFBa0JsSCxZQUFZcUg7QUFFN0QsUUFBTWpCLFFBQVE3QixPQUFPaUQsZ0JBQ2pCLGtCQUFrQm5HLE9BQU8sS0FDekIscUJBQXFCQSxPQUFPO0FBRWhDLFNBQ0UsdUJBQUMsV0FBUSxPQUFjLFNBQWtCLE1BQUksTUFDMUNtQjtBQUFBQSxlQUFXaUYsYUFBYSx1QkFBQyxPQUFFLE9BQU8sRUFBRUMsT0FBTyxpQkFBaUIsR0FBRyxrQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RDtBQUFBLElBQ2pGbEYsV0FBV21GLFdBQVcsdUJBQUMsT0FBRSxXQUFVLGNBQWEsMkNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUQ7QUFBQSxJQUUzRXBELFNBQVN6QyxlQUNSO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsU0FBUyxNQUFNQyxlQUFlLEtBQUs7QUFBQSxRQUNuQyxjQUFjLE1BQU07QUFDbEJBLHlCQUFlLEtBQUs7QUFDcEJNLHlCQUFlLElBQUk7QUFDbkJtQyx1QkFBYTtBQUFBLFFBQ2Y7QUFBQTtBQUFBLE1BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0k7QUFBQSxJQUlMbEMsaUJBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLGFBQWFBLGNBQWMwQjtBQUFBQSxRQUMzQixRQUFRMUIsY0FBYzRDO0FBQUFBLFFBQ3RCLFVBQVUsTUFBTTNDLGlCQUFpQixJQUFJO0FBQUEsUUFDckMsWUFBWXdDLFFBQVE2QztBQUFBQSxRQUNwQixXQUFXLENBQUN2RCxnQkFDVlUsUUFBUUssT0FBTyxFQUFFMUIsV0FBV3BCLGNBQWN5QixJQUFJTSxZQUFZLENBQUM7QUFBQTtBQUFBLE1BTi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9HO0FBQUEsSUFJSkUsU0FDQyxtQ0FDR0E7QUFBQUEsWUFBTXNELGNBQWMsUUFBUXRELE1BQU1wRCxzQkFBc0IsUUFDdkQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLE9BQU87QUFBQSxZQUNMMkcsU0FBUztBQUFBLFlBQ1RDLFNBQVM7QUFBQSxZQUNUQyxnQkFBZ0I7QUFBQSxZQUNoQkMsWUFBWTtBQUFBLFlBQ1pDLEtBQUs7QUFBQSxZQUNMQyxVQUFVO0FBQUEsWUFDVkMsYUFDRTdELE1BQU1yRCxlQUFlcUQsTUFBTXBELG9CQUFvQixrQkFBa0I7QUFBQSxVQUNyRTtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxVQUFLLE9BQU8sRUFBRWtILFVBQVUsV0FBV1gsT0FBTyxpQkFBaUIsR0FBRztBQUFBO0FBQUEsY0FDMUM7QUFBQSxjQUNuQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTztBQUFBLG9CQUNMQSxPQUFPekcsaUJBQWlCc0QsTUFBTXJELGFBQWFxRCxNQUFNcEQsaUJBQWlCO0FBQUEsa0JBQ3BFO0FBQUEsa0JBRUNsQjtBQUFBQSw4QkFBVXNFLE1BQU1yRCxXQUFXO0FBQUEsb0JBQUU7QUFBQSxvQkFBSWpCLFVBQVVzRSxNQUFNcEQsaUJBQWlCO0FBQUE7QUFBQTtBQUFBLGdCQU5yRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUNDd0IsY0FBY0UsTUFBTUMsbUJBQ25CO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxPQUFPLEVBQUV3RixXQUFXLElBQUlSLFNBQVMsVUFBVU8sVUFBVSxVQUFVO0FBQUEsZ0JBQy9ELFVBQVUzQixtQkFBbUJrQjtBQUFBQSxnQkFDN0IsU0FBUyxZQUFZO0FBQ25CLHdCQUFNVyxTQUFTLE1BQU05RyxPQUFPK0csT0FBTztBQUFBLG9CQUNqQ3BDLE9BQU87QUFBQSxvQkFDUHFDLE9BQU87QUFBQSxvQkFDUEMsV0FBVztBQUFBLG9CQUNYQyxjQUFjQyxPQUFPckUsTUFBTXBELG9CQUFxQixHQUFHO0FBQUEsa0JBQ3JELENBQUM7QUFDRCxzQkFBSW9ILFdBQVcsS0FBTTtBQUNyQix3QkFBTU0sUUFBUXBELE9BQU84QyxPQUFPN0MsUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUM3QyxzQkFBSUQsT0FBT3FELFNBQVNELEtBQUssS0FBS0EsUUFBUSxFQUFHbkMsb0JBQW1CdEIsT0FBT3lELEtBQUs7QUFBQSxnQkFDMUU7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFrQkE7QUFBQTtBQUFBO0FBQUEsUUEzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BNkNBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFUixVQUFVLFNBQVMsR0FBRyxxQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLFlBQVcsT0FBTyxFQUFFWCxPQUFPLG9CQUFvQlcsVUFBVSxVQUFVLEdBQUc7QUFBQTtBQUFBLFlBQ3pFLElBQUlVLEtBQUt4RSxNQUFNeUUsUUFBUSxFQUFFQyxtQkFBbUIsU0FBUyxFQUFFQyxNQUFNLFdBQVdDLFFBQVEsVUFBVSxDQUFDO0FBQUEsZUFEeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQzVFLE1BQU02RSxNQUFNakUsV0FBVyxLQUN0Qix1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUV1QyxPQUFPLG1CQUFtQixHQUFHLDBDQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUdEbkQsTUFBTTZFLE1BQU05RixJQUFJLENBQUNRLFNBQVM7QUFDekIsZ0JBQU11RixPQUFPMUksZUFBZW1ELEtBQUt3RixpQkFBaUI7QUFDbEQsZ0JBQU1DLFlBQVl6RixLQUFLd0Ysc0JBQXNCdkosZ0JBQWdCeUo7QUFDN0QsaUJBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRXpCLFNBQVMsUUFBUUcsS0FBSyxFQUFFLEdBQ3BDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE9BQU87QUFBQSxvQkFDTHVCLGdCQUFnQkYsWUFBWSxpQkFBaUI7QUFBQSxvQkFDN0M3QixPQUFPNkIsWUFBWSxxQkFBcUI7QUFBQSxrQkFDMUM7QUFBQSxrQkFFQ3pGO0FBQUFBLHlCQUFLNEY7QUFBQUEsb0JBQVM7QUFBQSxvQkFBSTdGLGdCQUFnQjhGLElBQUk3RixLQUFLSixTQUFTLEtBQUssWUFBWUksS0FBS0osU0FBUztBQUFBLG9CQUFHO0FBQUEsb0JBQUl6RCxVQUFVNkQsS0FBSzVDLFdBQVc7QUFBQTtBQUFBO0FBQUEsZ0JBUHZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRW1ILFVBQVUsVUFBVVgsT0FBTyxtQkFBbUIsR0FDMUR4SDtBQUFBQSxxQ0FBcUI0RCxLQUFLd0YsaUJBQWlCO0FBQUEsZ0JBQzNDeEYsS0FBSzhGLFFBQVEsTUFBTTlGLEtBQUs4RixLQUFLLEtBQUs7QUFBQSxtQkFGckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0M5RixLQUFLTyxZQUFZYyxTQUFTLEtBQ3pCLHVCQUFDLFVBQUssT0FBTyxFQUFFa0QsVUFBVSxVQUFVWCxPQUFPLG1CQUFtQixHQUFHO0FBQUE7QUFBQSxnQkFDM0Q1RCxLQUFLTyxZQUNMZixJQUFJLENBQUNjLE1BQU1GLG1CQUFtQnlGLElBQUl2RixFQUFFeUYsWUFBWSxLQUFLLGdCQUFnQnpGLEVBQUV5RixZQUFZLEVBQUUsRUFDckZDLEtBQUssSUFBSTtBQUFBLG1CQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUNDOUMsVUFBVXFDLFNBQVNwQyxVQUFhLENBQUNzQyxhQUNoQyx1QkFBQyxTQUFJLE9BQU8sRUFBRXhCLFNBQVMsUUFBUUcsS0FBSyxFQUFFLEdBQ3BDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE1BQUs7QUFBQSxrQkFDTCxPQUFPLEVBQUVJLFdBQVcsSUFBSVIsU0FBUyxVQUFVTyxVQUFVLFVBQVU7QUFBQSxrQkFDL0QsU0FBUyxNQUFNaEQsWUFBWUQsT0FBTyxFQUFFRSxRQUFReEIsS0FBS0MsSUFBSXdCLFVBQVU4RCxLQUFLLENBQUM7QUFBQSxrQkFBRTtBQUFBO0FBQUEsb0JBRXBFbkoscUJBQXFCbUosSUFBSTtBQUFBO0FBQUE7QUFBQSxnQkFOOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixNQUFLO0FBQUEsa0JBQ0wsY0FBWSxpQkFBaUJ4RixnQkFBZ0I4RixJQUFJN0YsS0FBS0osU0FBUyxLQUFLLEVBQUUsR0FBR3FHLEtBQUs7QUFBQSxrQkFDOUUsT0FBTTtBQUFBLGtCQUNOLE9BQU8sRUFBRXpCLFdBQVcsSUFBSVIsU0FBUyxVQUFVTyxVQUFVLFVBQVU7QUFBQSxrQkFDL0QsU0FBUyxNQUNQaEQsWUFBWUQsT0FBTyxFQUFFRSxRQUFReEIsS0FBS0MsSUFBSXdCLFVBQVV4RixnQkFBZ0J5SixVQUFVLENBQUM7QUFBQSxrQkFDNUU7QUFBQTtBQUFBLGdCQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsaUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsZUE3QzZCMUYsS0FBS0MsSUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQ0E7QUFBQSxRQUVKLENBQUM7QUFBQSxRQUVELHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRTJELE9BQU8saUJBQWlCLEdBQzNEO0FBQUEsaUNBQUMsVUFBSyx3QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFjO0FBQUEsVUFDZCx1QkFBQyxVQUFLLFdBQVUsWUFBWXpILG9CQUFVc0UsTUFBTXlGLGNBQWMsS0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQ7QUFBQSxhQUY5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDekYsTUFBTTBGLGlCQUFpQixLQUN0Qix1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUV2QyxPQUFPLFlBQVksR0FDdEQ7QUFBQSxpQ0FBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWM7QUFBQSxVQUNkLHVCQUFDLFVBQUssV0FBVSxZQUFXO0FBQUE7QUFBQSxZQUFHekgsVUFBVXNFLE1BQU0wRixjQUFjO0FBQUEsZUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQ7QUFBQSxhQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVEMUYsTUFBTTJGLG1CQUFtQixLQUN4Qix1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUV4QyxPQUFPLGlCQUFpQixHQUMzRDtBQUFBLGlDQUFDLFVBQUssNkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUNuQix1QkFBQyxVQUFLLFdBQVUsWUFBWXpILG9CQUFVc0UsTUFBTTJGLGdCQUFnQixLQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLGFBRmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUQzRixNQUFNNEYsb0JBQW9CLEtBQ3pCLG1DQUNFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFekMsT0FBTyxZQUFZLEdBQ3REO0FBQUEsbUNBQUMsVUFBSyw0QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQjtBQUFBLFlBQ2xCLHVCQUFDLFVBQUssV0FBVSxZQUFXO0FBQUE7QUFBQSxjQUFHekgsVUFBVXNFLE1BQU00RixpQkFBaUI7QUFBQSxpQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQSxlQUZuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUV6QyxPQUFPLGVBQWUsR0FDekQ7QUFBQSxtQ0FBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWM7QUFBQSxZQUNkLHVCQUFDLFVBQUssV0FBVSxZQUFZekgsb0JBQVVzRSxNQUFNckQsY0FBY3FELE1BQU00RixpQkFBaUIsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxlQUZyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUVGLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLGlDQUFDLFVBQUsscUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQ1gsdUJBQUMsVUFBSyxXQUFVLFlBQVcsT0FBTyxFQUFFekMsT0FBTyxlQUFlLEdBQ3ZEekgsb0JBQVVzRSxNQUFNckQsV0FBVyxLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQXhHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUdBO0FBQUEsTUFFQ2tCLGVBQ0MsdUJBQUMsT0FBRSxXQUFVLGNBQWEsTUFBSyxTQUM1QkEseUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsT0FNQzRFLFVBQVV6QyxNQUFNaUQsa0JBQWtCLFFBQVE1RSxjQUN6QzJCLE1BQU1yRCxjQUFjcUQsTUFBTTRGLG9CQUFvQixLQUNoRDVDLG9CQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFVyxLQUFLLEVBQUUsR0FDakRsQjtBQUFBQSxrQkFBVXpDLE1BQU1pRCxrQkFBa0IsUUFBUTVFLGNBQ3pDMkIsTUFBTXJELGNBQWNxRCxNQUFNNEYsb0JBQW9CLEtBQzlDLHVCQUFDLFlBQU8sV0FBVSxhQUFZLE1BQUssVUFBUyxTQUFTLE1BQU1wSSxlQUFlLElBQUksR0FBRyxxREFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHRHdGLG1CQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixNQUFLO0FBQUEsWUFDTCxVQUFVZCxlQUFlbUI7QUFBQUEsWUFDekIsU0FBUyxZQUFZO0FBQ25CLGtCQUNFLE1BQU1uRyxPQUFPMEUsUUFBUTtBQUFBLGdCQUNuQkMsT0FBTztBQUFBLGdCQUNQeEIsU0FDRTtBQUFBLGdCQUNGeUIsY0FBYztBQUFBLGNBQ2hCLENBQUM7QUFFREksK0JBQWVyQixPQUFPO0FBQUEsWUFDMUI7QUFBQSxZQUFFO0FBQUE7QUFBQSxVQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWlCQTtBQUFBLFFBR0RtQyxtQkFBbUJoRCxNQUFNMkYsbUJBQW1CLEtBQUt2SCxjQUFjRSxNQUFNQyxtQkFDcEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFVBQVUwRCxrQkFBa0JvQjtBQUFBQSxZQUM1QixTQUFTLFlBQVk7QUFDbkIsa0JBQ0UsTUFBTW5HLE9BQU8wRSxRQUFRO0FBQUEsZ0JBQ25CQyxPQUFPO0FBQUEsZ0JBQ1B4QixTQUFTO0FBQUEsZ0JBQ1R5QixjQUFjO0FBQUEsY0FDaEIsQ0FBQztBQUVERyxrQ0FBa0JwQixPQUFPO0FBQUEsWUFDN0I7QUFBQSxZQUVDb0IsNEJBQWtCb0IsWUFBWSxlQUFlO0FBQUE7QUFBQSxVQWZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFnQkE7QUFBQSxRQUdETCxtQkFBbUI1QixtQkFBbUI5QyxNQUFNcUQscUJBQzNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixNQUFLO0FBQUEsWUFDTCxVQUFVSCxrQkFBa0I2QjtBQUFBQSxZQUM1QixTQUFTLE1BQU03QixrQkFBa0JYLE9BQU87QUFBQSxZQUV2Q1csNEJBQWtCNkIsWUFBWSxnQkFBZ0I7QUFBQTtBQUFBLFVBTmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0F6REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJEQTtBQUFBLE1BR0RMLG1CQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsUUFBUSxNQUFNO0FBQ1psRiwyQkFBZSxJQUFJO0FBQ25CbUMseUJBQWE7QUFBQSxVQUNmO0FBQUE7QUFBQSxRQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtJO0FBQUEsTUFJTDhDLGNBQ0MsbUNBQ0U7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsTUFBSztBQUFBLFlBQ0wsaUJBQWUxRjtBQUFBQSxZQUNmLGlCQUFjO0FBQUEsWUFDZCxTQUFTLE1BQU1DLFlBQVksQ0FBQ3VJLE1BQU0sQ0FBQ0EsQ0FBQztBQUFBLFlBRW5DeEkscUJBQVcsb0JBQW9CO0FBQUE7QUFBQSxVQVBsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBRUNBLFlBQ0MsdUJBQUMsU0FBSSxJQUFHLDJCQUEwQixPQUFPLEVBQUVtRyxTQUFTLFFBQVFHLEtBQUssR0FBRyxHQUNsRTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxhQUFZO0FBQUEsY0FDWixPQUFPbEc7QUFBQUEsY0FDUCxVQUFVLENBQUNnRSxNQUFNL0QsVUFBVStELEVBQUVxRSxPQUFPeEIsS0FBSztBQUFBLGNBQ3pDLFdBQVM7QUFBQTtBQUFBLFlBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSVc7QUFBQSxVQUVYLHVCQUFDLFNBQUksT0FBTyxFQUFFZCxTQUFTLFFBQVFHLEtBQUssR0FBR29DLFdBQVcsS0FBS0MsV0FBVyxPQUFPLEdBQ3RFNUc7QUFBQUEsc0JBQVU4RCxhQUNULHVCQUFDLE9BQUUsT0FBTyxFQUFFQyxPQUFPLGlCQUFpQixHQUFHLG9DQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBRTVEYixhQUFhdkQ7QUFBQUEsY0FBSSxDQUFDUSxTQUNqQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLE9BQU8sRUFBRWlFLFNBQVMsUUFBUUMsZ0JBQWdCLGlCQUFpQkMsWUFBWSxVQUFVSCxTQUFTLFlBQVlRLFdBQVcsR0FBRztBQUFBLGtCQUNwSCxVQUFVdkQsUUFBUTZDO0FBQUFBLGtCQUNsQixTQUFTLE1BQU0zQyxlQUFlbkIsSUFBSTtBQUFBLGtCQUVsQztBQUFBLDJDQUFDLFVBQUssT0FBTyxFQUFFaUUsU0FBUyxRQUFRRSxZQUFZLFVBQVVDLEtBQUssR0FBRyxHQUMzRHBFO0FBQUFBLDJCQUFLMEcsWUFDSjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxLQUFLMUcsS0FBSzBHO0FBQUFBLDBCQUNWLEtBQUk7QUFBQSwwQkFDSixPQUFPLEVBQUVDLE9BQU8sSUFBSUMsUUFBUSxJQUFJQyxXQUFXLFNBQVNDLGNBQWMsRUFBRTtBQUFBO0FBQUEsd0JBSHRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFHd0U7QUFBQSxzQkFHekU5RyxLQUFLRTtBQUFBQSxzQkFDTFgsZUFBZXdILElBQUkvRyxLQUFLQyxFQUFFLEtBQ3pCO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE9BQU87QUFBQSw0QkFDTCtHLFlBQVk7QUFBQSw0QkFDWkMsWUFBWTtBQUFBLDRCQUNaMUMsVUFBVTtBQUFBLDRCQUNWMkMsZUFBZTtBQUFBLDRCQUNmdEQsT0FBTztBQUFBLDRCQUNQdUQsWUFBWTtBQUFBLDRCQUNaTCxjQUFjO0FBQUEsNEJBQ2Q5QyxTQUFTO0FBQUEsNEJBQ1RvRCxZQUFZO0FBQUEsMEJBQ2Q7QUFBQSwwQkFFQzdILHlCQUFlc0csSUFBSTdGLEtBQUtDLEVBQUU7QUFBQTtBQUFBLHdCQWI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBY0E7QUFBQSx5QkF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkEwQkE7QUFBQSxvQkFDQSx1QkFBQyxVQUFLLFdBQVUsWUFBVyxPQUFPLEVBQUUyRCxPQUFPLGVBQWUsR0FDdkR6SCxvQkFBVTZELEtBQUtxSCxTQUFTLEtBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQTtBQUFBO0FBQUEsZ0JBcENLckgsS0FBS0M7QUFBQUEsZ0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXNDQTtBQUFBLFlBQ0Q7QUFBQSxlQTVDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZDQTtBQUFBLGFBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxREE7QUFBQSxRQUdGLHVCQUFDLFNBQUksT0FBTyxFQUFFZ0UsU0FBUyxRQUFRRyxLQUFLLEdBQUcsR0FDckM7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBWTtBQUFBLGNBQ1osY0FBVztBQUFBLGNBQ1gsV0FBVTtBQUFBLGNBQ1YsT0FBT2hHO0FBQUFBLGNBQ1AsVUFBVSxDQUFDOEQsTUFBTTdELFlBQVk2RCxFQUFFcUUsT0FBT3hCLEtBQUs7QUFBQSxjQUMzQyxPQUFPLEVBQUV1QyxNQUFNLEVBQUU7QUFBQTtBQUFBLFlBTm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1xQjtBQUFBLFVBRXJCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTCxVQUFVbEosU0FBUzZILEtBQUssTUFBTSxNQUFNdkUsaUJBQWlCb0M7QUFBQUEsY0FDckQsU0FBUyxNQUFNcEMsaUJBQWlCSixPQUFPO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFJQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsT0FBTyxFQUFFZ0csTUFBTSxFQUFFO0FBQUEsY0FDakIsVUFBVXhFLGVBQWVnQjtBQUFBQSxjQUN6QixTQUFTLFlBQVk7QUFDbkIsb0JBQ0UsTUFBTW5HLE9BQU8wRSxRQUFRO0FBQUEsa0JBQ25CQyxPQUFPO0FBQUEsa0JBQ1B4QixTQUFTO0FBQUEsa0JBQ1R5QixjQUFjO0FBQUEsa0JBQ2RnRixhQUFhO0FBQUEsa0JBQ2JDLFFBQVE7QUFBQSxnQkFDVixDQUFDO0FBRUQxRSxpQ0FBZXhCLE9BQU87QUFBQSxjQUMxQjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLE9BQU8sRUFBRWdHLE1BQU0sRUFBRTtBQUFBLGNBQ2pCLFVBQVU3RyxNQUFNNkUsTUFBTWpFLFdBQVcsS0FBS2MsY0FBYzJCO0FBQUFBLGNBQ3BELFNBQVMsTUFBTTNCLGNBQWNiLE9BQU87QUFBQSxjQUVuQ1MseUJBQWUsd0JBQXdCO0FBQUE7QUFBQSxZQVAxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4QkE7QUFBQSxXQXZIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0hBO0FBQUEsTUFHRCxDQUFDbUIsVUFDQSx1QkFBQyxPQUFFLE9BQU8sRUFBRVUsT0FBTyxpQkFBaUIsR0FBRztBQUFBO0FBQUEsUUFDVm5ELE1BQU0yQyxrQkFBa0JsSCxZQUFZdUwsT0FBTyxTQUFTO0FBQUEsUUFBWTtBQUFBLFdBRDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBalhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtWEE7QUFBQSxPQWhaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa1pBO0FBRUo7QUFBQ2hLLEdBL2pCZUgsYUFBVztBQUFBLFVBQ0x0QyxnQkFDTDJCLFdBQ21CWixjQU9maEIsVUFLRzJCLGVBSUkzQixVQVlSQSxVQVlZQSxVQXNCZEQsYUFxQklBLGFBTUtBLGFBS0VDLFVBTUlBLFVBT0xELGFBS0pBLGFBZUlBLGFBQ0hBLGFBRUlBLGFBS0pBLFdBQVc7QUFBQTtBQUFBLEtBMUlwQndDO0FBQVcsSUFBQW9LO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsImFkZE9yZGVySXRlbSIsImFwcGx5RGlzY291bnQiLCJjYW5jZWxPcmRlciIsImNsb3NlT3JkZXIiLCJnZXRPcmRlciIsInJhaXNlQ3JlZGl0TGltaXQiLCJyZW1vdmVTZXJ2aWNlRmVlIiwicmVvcGVuT3JkZXIiLCJ1cGRhdGVJdGVtU3RhdHVzIiwiZ2V0TWVudSIsImdldENvbXBsZW1lbnRHcm91cHMiLCJnZXRBY3RpdmVQcm9tb3Rpb25zIiwiZ2V0UHJpbnRTZXR0aW5ncyIsInByaW50QmlsbCIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwiT3JkZXJJdGVtU3RhdHVzIiwiT3JkZXJTdGF0dXMiLCJmb3JtYXRCUkwiLCJvcmRlckl0ZW1TdGF0dXNMYWJlbCIsInByb21vdGlvbkJhZGdlIiwiT3ZlcmxheSIsIlBheW1lbnRQYW5lbCIsIlBhcnRpYWxQYXltZW50RGlhbG9nIiwiQ29tcGxlbWVudFNlbGVjdG9yTW9kYWwiLCJ1c2VNeUZlYXR1cmVzIiwidXNlRGlhbG9nIiwiZ2V0U2VydmljZUZlZVNldHRpbmciLCJuZXh0SXRlbVN0YXR1cyIsIkxhbmNhZG8iLCJFbnZpYWRvQ296aW5oYSIsIkVtUHJlcGFybyIsIlByb250byIsIkVudHJlZ3VlIiwiY3JlZGl0TGltaXRDb2xvciIsInRvdGFsQW1vdW50IiwiY3JlZGl0TGltaXRBbW91bnQiLCJPcmRlckRyYXdlciIsIm9yZGVySWQiLCJvbkNsb3NlIiwiX3MiLCJxdWVyeUNsaWVudCIsImRpYWxvZyIsImNvbXBhbnlJZCIsImVtcGxveWVlSWQiLCJtZW51T3BlbiIsInNldE1lbnVPcGVuIiwicGFydGlhbE9wZW4iLCJzZXRQYXJ0aWFsT3BlbiIsInNlYXJjaCIsInNldFNlYXJjaCIsImRpc2NvdW50Iiwic2V0RGlzY291bnQiLCJhY3Rpb25FcnJvciIsInNldEFjdGlvbkVycm9yIiwic2VsZWN0aW5nSXRlbSIsInNldFNlbGVjdGluZ0l0ZW0iLCJvcmRlclF1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwiZmVhdHVyZXNRdWVyeSIsImNhblVzZUNhc2giLCJkYXRhIiwiY2FuTWFuYWdlQWNjZXNzIiwiZmVhdHVyZXMiLCJpbmNsdWRlcyIsImFjdGl2ZVByb21vc1F1ZXJ5IiwiZ2V0U3RhdGUiLCJicmFuY2hJZCIsInJlZmV0Y2hJbnRlcnZhbCIsInByb21vQnlQcm9kdWN0IiwibWFwIiwiTWFwIiwicCIsInNldCIsInByb2R1Y3RJZCIsIm1lbnVRdWVyeSIsInN0YWxlVGltZSIsInByb2R1Y3ROYW1lQnlJZCIsIml0ZW0iLCJpZCIsIm5hbWUiLCJjb21wbGVtZW50R3JvdXBzUXVlcnkiLCJjb21wbGVtZW50TmFtZUJ5SWQiLCJncm91cCIsImMiLCJjb21wbGVtZW50cyIsImNvbXBsZW1lbnRJdGVtTmFtZSIsIm9yZGVyIiwicmVmZXRjaE9yZGVyIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJvbkVycm9yIiwiZXJyb3IiLCJtZXNzYWdlIiwicnVuIiwib25TdWNjZXNzIiwiYWRkSXRlbSIsIm11dGF0aW9uRm4iLCJoYW5kbGVQaWNrSXRlbSIsImNvbXBsZW1lbnRHcm91cHMiLCJsZW5ndGgiLCJtdXRhdGUiLCJhZHZhbmNlSXRlbSIsIml0ZW1JZCIsInN0YXR1c0lkIiwiZGlzY291bnRNdXRhdGlvbiIsIk51bWJlciIsInJlcGxhY2UiLCJwcmludFNldHRpbmdzUXVlcnkiLCJzZXJ2aWNlRmVlU2V0dGluZ1F1ZXJ5Iiwic2VydmljZUZlZU9uIiwiZW5hYmxlZCIsInByaW50QmlsbE11dGF0aW9uIiwiZSIsImNsb3NlTXV0YXRpb24iLCJwcmludEJpbGxzRW5hYmxlZCIsImNvbmZpcm0iLCJ0aXRsZSIsImNvbmZpcm1MYWJlbCIsInRoZW4iLCJvayIsInJlbW92ZUZlZU11dGF0aW9uIiwicmVvcGVuTXV0YXRpb24iLCJyYWlzZUxpbWl0TXV0YXRpb24iLCJuZXdMaW1pdCIsImNhbmNlbE11dGF0aW9uIiwiZmlsdGVyZWRNZW51IiwiZmlsdGVyIiwidG9Mb3dlckNhc2UiLCJpc09wZW4iLCJ1bmRlZmluZWQiLCJvcmRlclN0YXR1c0lkIiwiQWJlcnRvIiwiRW1BbmRhbWVudG8iLCJBZ3VhcmRhbmRvUGFnYW1lbnRvIiwiaXNFZGl0YWJsZSIsImF3YWl0aW5nUGF5bWVudCIsImRpbmluZ1RhYmxlSWQiLCJpc0xvYWRpbmciLCJjb2xvciIsImlzRXJyb3IiLCJpc1BlbmRpbmciLCJjb21hbmRhSWQiLCJwYWRkaW5nIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImdhcCIsImZsZXhXcmFwIiwiYm9yZGVyQ29sb3IiLCJmb250U2l6ZSIsIm1pbkhlaWdodCIsImFuc3dlciIsInByb21wdCIsImxhYmVsIiwiaW5wdXRNb2RlIiwiZGVmYXVsdFZhbHVlIiwiU3RyaW5nIiwidmFsdWUiLCJpc0Zpbml0ZSIsIkRhdGUiLCJvcGVuZWRBdCIsInRvTG9jYWxlVGltZVN0cmluZyIsImhvdXIiLCJtaW51dGUiLCJpdGVtcyIsIm5leHQiLCJvcmRlckl0ZW1TdGF0dXNJZCIsImNhbmNlbGxlZCIsIkNhbmNlbGFkbyIsInRleHREZWNvcmF0aW9uIiwicXVhbnRpdHkiLCJnZXQiLCJub3RlcyIsImNvbXBsZW1lbnRJZCIsImpvaW4iLCJ0cmltIiwic3VidG90YWxBbW91bnQiLCJkaXNjb3VudEFtb3VudCIsInNlcnZpY2VGZWVBbW91bnQiLCJwYXJ0aWFsUGFpZEFtb3VudCIsInYiLCJ0YXJnZXQiLCJtYXhIZWlnaHQiLCJvdmVyZmxvd1kiLCJpbWFnZVVybCIsIndpZHRoIiwiaGVpZ2h0Iiwib2JqZWN0Rml0IiwiYm9yZGVyUmFkaXVzIiwiaGFzIiwibWFyZ2luTGVmdCIsImZvbnRGYW1pbHkiLCJsZXR0ZXJTcGFjaW5nIiwiYmFja2dyb3VuZCIsImZvbnRXZWlnaHQiLCJzYWxlUHJpY2UiLCJmbGV4IiwiY2FuY2VsTGFiZWwiLCJkYW5nZXIiLCJQYWdvIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT3JkZXJEcmF3ZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7XHJcbiAgYWRkT3JkZXJJdGVtLFxyXG4gIGFwcGx5RGlzY291bnQsXHJcbiAgY2FuY2VsT3JkZXIsXHJcbiAgY2xvc2VPcmRlcixcclxuICBnZXRPcmRlcixcclxuICByYWlzZUNyZWRpdExpbWl0LFxyXG4gIHJlbW92ZVNlcnZpY2VGZWUsXHJcbiAgcmVvcGVuT3JkZXIsXHJcbiAgdXBkYXRlSXRlbVN0YXR1cyxcclxufSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgZ2V0TWVudSB9IGZyb20gXCIuLi9jYXRhbG9nL2FwaVwiO1xyXG5pbXBvcnQgeyBnZXRDb21wbGVtZW50R3JvdXBzIH0gZnJvbSBcIi4uL2NhdGFsb2cvY29tcGxlbWVudHNBcGlcIjtcclxuaW1wb3J0IHsgZ2V0QWN0aXZlUHJvbW90aW9ucyB9IGZyb20gXCIuLi9wcm9tb3Rpb25zL2FwaVwiO1xyXG5pbXBvcnQgeyBnZXRQcmludFNldHRpbmdzLCBwcmludEJpbGwgfSBmcm9tIFwiLi4vcHJpbnRpbmcvYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHtcclxuICBPcmRlckl0ZW1TdGF0dXMsXHJcbiAgT3JkZXJTdGF0dXMsXHJcbiAgZm9ybWF0QlJMLFxyXG4gIG9yZGVySXRlbVN0YXR1c0xhYmVsLFxyXG4gIHByb21vdGlvbkJhZGdlLFxyXG59IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHR5cGUgeyBNZW51SXRlbVJlc3BvbnNlLCBPcmRlckl0ZW1Db21wbGVtZW50U2VsZWN0aW9uIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgeyBPdmVybGF5IH0gZnJvbSBcIi4vT3ZlcmxheVwiO1xyXG5pbXBvcnQgeyBQYXltZW50UGFuZWwgfSBmcm9tIFwiLi9QYXltZW50UGFuZWxcIjtcclxuaW1wb3J0IHsgUGFydGlhbFBheW1lbnREaWFsb2cgfSBmcm9tIFwiLi9QYXJ0aWFsUGF5bWVudERpYWxvZ1wiO1xyXG5pbXBvcnQgeyBDb21wbGVtZW50U2VsZWN0b3JNb2RhbCB9IGZyb20gXCIuL0NvbXBsZW1lbnRTZWxlY3Rvck1vZGFsXCI7XHJcbmltcG9ydCB7IHVzZU15RmVhdHVyZXMgfSBmcm9tIFwiLi4vYWNjZXNzL2hvb2tzXCI7XHJcbmltcG9ydCB7IHVzZURpYWxvZyB9IGZyb20gXCIuLi8uLi91aS9EaWFsb2dcIjtcclxuaW1wb3J0IHsgZ2V0U2VydmljZUZlZVNldHRpbmcgfSBmcm9tIFwiLi4vc2V0dGluZ3MvYXBpXCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gIG9yZGVySWQ6IG51bWJlcjtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5jb25zdCBuZXh0SXRlbVN0YXR1czogUmVjb3JkPG51bWJlciwgbnVtYmVyPiA9IHtcclxuICBbT3JkZXJJdGVtU3RhdHVzLkxhbmNhZG9dOiBPcmRlckl0ZW1TdGF0dXMuRW52aWFkb0NvemluaGEsXHJcbiAgW09yZGVySXRlbVN0YXR1cy5FbnZpYWRvQ296aW5oYV06IE9yZGVySXRlbVN0YXR1cy5FbVByZXBhcm8sXHJcbiAgW09yZGVySXRlbVN0YXR1cy5FbVByZXBhcm9dOiBPcmRlckl0ZW1TdGF0dXMuUHJvbnRvLFxyXG4gIFtPcmRlckl0ZW1TdGF0dXMuUHJvbnRvXTogT3JkZXJJdGVtU3RhdHVzLkVudHJlZ3VlLFxyXG59O1xyXG5cclxuZnVuY3Rpb24gY3JlZGl0TGltaXRDb2xvcih0b3RhbEFtb3VudDogbnVtYmVyLCBjcmVkaXRMaW1pdEFtb3VudDogbnVtYmVyKTogc3RyaW5nIHtcclxuICBpZiAodG90YWxBbW91bnQgPj0gY3JlZGl0TGltaXRBbW91bnQpIHJldHVybiBcInZhcigtLWRhbmdlcilcIjtcclxuICBpZiAodG90YWxBbW91bnQgPj0gY3JlZGl0TGltaXRBbW91bnQgKiAwLjgpIHJldHVybiBcInZhcigtLWJ1c3kpXCI7XHJcbiAgcmV0dXJuIFwidmFyKC0tb2spXCI7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBPcmRlckRyYXdlcih7IG9yZGVySWQsIG9uQ2xvc2UgfTogUHJvcHMpIHtcclxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgY29uc3QgZGlhbG9nID0gdXNlRGlhbG9nKCk7XHJcbiAgY29uc3QgeyBjb21wYW55SWQsIGVtcGxveWVlSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IFttZW51T3Blbiwgc2V0TWVudU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtwYXJ0aWFsT3Blbiwgc2V0UGFydGlhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGlzY291bnQsIHNldERpc2NvdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthY3Rpb25FcnJvciwgc2V0QWN0aW9uRXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW3NlbGVjdGluZ0l0ZW0sIHNldFNlbGVjdGluZ0l0ZW1dID0gdXNlU3RhdGU8TWVudUl0ZW1SZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IG9yZGVyUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wib3JkZXJcIiwgb3JkZXJJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRPcmRlcihvcmRlcklkKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZmVhdHVyZXNRdWVyeSA9IHVzZU15RmVhdHVyZXMoKTtcclxuICBjb25zdCBjYW5Vc2VDYXNoID1cclxuICAgIGZlYXR1cmVzUXVlcnkuZGF0YT8uY2FuTWFuYWdlQWNjZXNzIHx8IGZlYXR1cmVzUXVlcnkuZGF0YT8uZmVhdHVyZXMuaW5jbHVkZXMoXCJDYWl4YVwiKTtcclxuXHJcbiAgY29uc3QgYWN0aXZlUHJvbW9zUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wicHJvbW90aW9uc1wiLCBcImFjdGl2ZVwiXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldEFjdGl2ZVByb21vdGlvbnModXNlQXV0aFN0b3JlLmdldFN0YXRlKCkuYnJhbmNoSWQpLFxyXG4gICAgcmVmZXRjaEludGVydmFsOiA2MF8wMDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHByb21vQnlQcm9kdWN0ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwPG51bWJlciwgc3RyaW5nPigpO1xyXG4gICAgZm9yIChjb25zdCBwIG9mIGFjdGl2ZVByb21vc1F1ZXJ5LmRhdGEgPz8gW10pIG1hcC5zZXQocC5wcm9kdWN0SWQsIHByb21vdGlvbkJhZGdlKHApKTtcclxuICAgIHJldHVybiBtYXA7XHJcbiAgfSwgW2FjdGl2ZVByb21vc1F1ZXJ5LmRhdGFdKTtcclxuXHJcbiAgY29uc3QgbWVudVF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcIm1lbnVcIiwgY29tcGFueUlkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldE1lbnUoY29tcGFueUlkID8/IDEpLFxyXG4gICAgc3RhbGVUaW1lOiA1ICogNjBfMDAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBwcm9kdWN0TmFtZUJ5SWQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XHJcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgbWVudVF1ZXJ5LmRhdGEgPz8gW10pIG1hcC5zZXQoaXRlbS5pZCwgaXRlbS5uYW1lKTtcclxuICAgIHJldHVybiBtYXA7XHJcbiAgfSwgW21lbnVRdWVyeS5kYXRhXSk7XHJcblxyXG4gIGNvbnN0IGNvbXBsZW1lbnRHcm91cHNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJjb21wbGVtZW50LWdyb3Vwc1wiLCBjb21wYW55SWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0Q29tcGxlbWVudEdyb3Vwcyhjb21wYW55SWQgPz8gMSksXHJcbiAgICBzdGFsZVRpbWU6IDUgKiA2MF8wMDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGNvbXBsZW1lbnROYW1lQnlJZCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgbWFwID0gbmV3IE1hcDxudW1iZXIsIHN0cmluZz4oKTtcclxuICAgIGZvciAoY29uc3QgZ3JvdXAgb2YgY29tcGxlbWVudEdyb3Vwc1F1ZXJ5LmRhdGEgPz8gW10pXHJcbiAgICAgIGZvciAoY29uc3QgYyBvZiBncm91cC5jb21wbGVtZW50cykgbWFwLnNldChjLmlkLCBjLmNvbXBsZW1lbnRJdGVtTmFtZSk7XHJcbiAgICByZXR1cm4gbWFwO1xyXG4gIH0sIFtjb21wbGVtZW50R3JvdXBzUXVlcnkuZGF0YV0pO1xyXG5cclxuICBjb25zdCBvcmRlciA9IG9yZGVyUXVlcnkuZGF0YTtcclxuXHJcbiAgY29uc3QgcmVmZXRjaE9yZGVyID0gKCkgPT4gdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJvcmRlclwiLCBvcmRlcklkXSB9KTtcclxuXHJcbiAgY29uc3Qgb25FcnJvciA9IChlcnJvcjogdW5rbm93bikgPT5cclxuICAgIHNldEFjdGlvbkVycm9yKGVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJPcGVyYcOnw6NvIGZhbGhvdS5cIik7XHJcblxyXG4gIGNvbnN0IHJ1biA9IHsgb25TdWNjZXNzOiAoKSA9PiB7IHNldEFjdGlvbkVycm9yKG51bGwpOyByZWZldGNoT3JkZXIoKTsgfSwgb25FcnJvciB9O1xyXG5cclxuICBjb25zdCBhZGRJdGVtID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKHtcclxuICAgICAgcHJvZHVjdElkLFxyXG4gICAgICBjb21wbGVtZW50cyxcclxuICAgIH06IHtcclxuICAgICAgcHJvZHVjdElkOiBudW1iZXI7XHJcbiAgICAgIGNvbXBsZW1lbnRzPzogT3JkZXJJdGVtQ29tcGxlbWVudFNlbGVjdGlvbltdO1xyXG4gICAgfSkgPT4gYWRkT3JkZXJJdGVtKG9yZGVySWQsIHByb2R1Y3RJZCwgMSwgbnVsbCwgZW1wbG95ZWVJZCwgY29tcGxlbWVudHMpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHNldEFjdGlvbkVycm9yKG51bGwpO1xyXG4gICAgICBzZXRTZWxlY3RpbmdJdGVtKG51bGwpO1xyXG4gICAgICByZWZldGNoT3JkZXIoKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVQaWNrSXRlbSA9IChpdGVtOiBNZW51SXRlbVJlc3BvbnNlKSA9PiB7XHJcbiAgICBpZiAoaXRlbS5jb21wbGVtZW50R3JvdXBzLmxlbmd0aCA+IDApIHNldFNlbGVjdGluZ0l0ZW0oaXRlbSk7XHJcbiAgICBlbHNlIGFkZEl0ZW0ubXV0YXRlKHsgcHJvZHVjdElkOiBpdGVtLmlkIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGFkdmFuY2VJdGVtID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKHsgaXRlbUlkLCBzdGF0dXNJZCB9OiB7IGl0ZW1JZDogbnVtYmVyOyBzdGF0dXNJZDogbnVtYmVyIH0pID0+XHJcbiAgICAgIHVwZGF0ZUl0ZW1TdGF0dXMob3JkZXJJZCwgaXRlbUlkLCBzdGF0dXNJZCwgZW1wbG95ZWVJZCksXHJcbiAgICAuLi5ydW4sXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGRpc2NvdW50TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBhcHBseURpc2NvdW50KG9yZGVySWQsIE51bWJlcihkaXNjb3VudC5yZXBsYWNlKFwiLFwiLCBcIi5cIikpKSxcclxuICAgIC4uLnJ1bixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcHJpbnRTZXR0aW5nc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcInByaW50aW5nXCIsIFwic2V0dGluZ3NcIiwgdXNlQXV0aFN0b3JlLmdldFN0YXRlKCkuYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0UHJpbnRTZXR0aW5ncyh1c2VBdXRoU3RvcmUuZ2V0U3RhdGUoKS5icmFuY2hJZCksXHJcbiAgICBzdGFsZVRpbWU6IDYwXzAwMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc2VydmljZUZlZVNldHRpbmdRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJvcmRlcnNcIiwgXCJzZXJ2aWNlLWZlZS1zZXR0aW5nXCIsIHVzZUF1dGhTdG9yZS5nZXRTdGF0ZSgpLmJyYW5jaElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldFNlcnZpY2VGZWVTZXR0aW5nKHVzZUF1dGhTdG9yZS5nZXRTdGF0ZSgpLmJyYW5jaElkKSxcclxuICAgIHN0YWxlVGltZTogNjBfMDAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IHNlcnZpY2VGZWVPbiA9IHNlcnZpY2VGZWVTZXR0aW5nUXVlcnkuZGF0YT8uZW5hYmxlZCA/PyB0cnVlO1xyXG5cclxuICBjb25zdCBwcmludEJpbGxNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHByaW50QmlsbChvcmRlcklkKSxcclxuICAgIG9uRXJyb3I6IChlKSA9PiBzZXRBY3Rpb25FcnJvcihlIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkZhbGhhIGFvIGltcHJpbWlyIGEgY29udGEuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjbG9zZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gY2xvc2VPcmRlcihvcmRlcklkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICBzZXRBY3Rpb25FcnJvcihudWxsKTtcclxuICAgICAgcmVmZXRjaE9yZGVyKCk7XHJcbiAgICAgIC8vIFwiRGVzZWphIGltcHJpbWlyP1wiIFNPIGFwYXJlY2UgY29tIGEgaW1wcmVzc2FvIGRlIGNvbnRhcyBsaWdhZGEuXHJcbiAgICAgIGlmIChwcmludFNldHRpbmdzUXVlcnkuZGF0YT8ucHJpbnRCaWxsc0VuYWJsZWQpXHJcbiAgICAgICAgdm9pZCBkaWFsb2dcclxuICAgICAgICAgIC5jb25maXJtKHsgdGl0bGU6IFwiSW1wcmltaXIgY29udGFcIiwgbWVzc2FnZTogXCJEZXNlamEgaW1wcmltaXIgYSBjb250YT9cIiwgY29uZmlybUxhYmVsOiBcIkltcHJpbWlyXCIgfSlcclxuICAgICAgICAgIC50aGVuKChvaykgPT4ge1xyXG4gICAgICAgICAgICBpZiAob2spIHByaW50QmlsbE11dGF0aW9uLm11dGF0ZSgpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcixcclxuICB9KTtcclxuICBjb25zdCByZW1vdmVGZWVNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHsgbXV0YXRpb25GbjogKCkgPT4gcmVtb3ZlU2VydmljZUZlZShvcmRlcklkKSwgLi4ucnVuIH0pO1xyXG4gIGNvbnN0IHJlb3Blbk11dGF0aW9uID0gdXNlTXV0YXRpb24oeyBtdXRhdGlvbkZuOiAoKSA9PiByZW9wZW5PcmRlcihvcmRlcklkKSwgLi4ucnVuIH0pO1xyXG5cclxuICBjb25zdCByYWlzZUxpbWl0TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAobmV3TGltaXQ6IG51bWJlcikgPT4gcmFpc2VDcmVkaXRMaW1pdChvcmRlcklkLCBuZXdMaW1pdCksXHJcbiAgICAuLi5ydW4sXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGNhbmNlbE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gY2FuY2VsT3JkZXIob3JkZXJJZCksXHJcbiAgICBvblN1Y2Nlc3M6IG9uQ2xvc2UsXHJcbiAgICBvbkVycm9yLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZE1lbnUgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT5cclxuICAgICAgKG1lbnVRdWVyeS5kYXRhID8/IFtdKS5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICAgICAgaXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoLnRvTG93ZXJDYXNlKCkpLFxyXG4gICAgICApLFxyXG4gICAgW21lbnVRdWVyeS5kYXRhLCBzZWFyY2hdLFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGlzT3BlbiA9XHJcbiAgICBvcmRlciAhPT0gdW5kZWZpbmVkICYmXHJcbiAgICAob3JkZXIub3JkZXJTdGF0dXNJZCA9PT0gT3JkZXJTdGF0dXMuQWJlcnRvIHx8XHJcbiAgICAgIG9yZGVyLm9yZGVyU3RhdHVzSWQgPT09IE9yZGVyU3RhdHVzLkVtQW5kYW1lbnRvIHx8XHJcbiAgICAgIG9yZGVyLm9yZGVyU3RhdHVzSWQgPT09IE9yZGVyU3RhdHVzLkFndWFyZGFuZG9QYWdhbWVudG8pO1xyXG5cclxuICBjb25zdCBpc0VkaXRhYmxlID1cclxuICAgIG9yZGVyICE9PSB1bmRlZmluZWQgJiZcclxuICAgIChvcmRlci5vcmRlclN0YXR1c0lkID09PSBPcmRlclN0YXR1cy5BYmVydG8gfHxcclxuICAgICAgb3JkZXIub3JkZXJTdGF0dXNJZCA9PT0gT3JkZXJTdGF0dXMuRW1BbmRhbWVudG8pO1xyXG5cclxuICBjb25zdCBhd2FpdGluZ1BheW1lbnQgPVxyXG4gICAgb3JkZXIgIT09IHVuZGVmaW5lZCAmJiBvcmRlci5vcmRlclN0YXR1c0lkID09PSBPcmRlclN0YXR1cy5BZ3VhcmRhbmRvUGFnYW1lbnRvO1xyXG5cclxuICBjb25zdCB0aXRsZSA9IG9yZGVyPy5kaW5pbmdUYWJsZUlkXHJcbiAgICA/IGBNZXNhIMK3IHBlZGlkbyAjJHtvcmRlcklkfWBcclxuICAgIDogYENvbWFuZGEgwrcgcGVkaWRvICMke29yZGVySWR9YDtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxPdmVybGF5IHRpdGxlPXt0aXRsZX0gb25DbG9zZT17b25DbG9zZX0gd2lkZT5cclxuICAgICAge29yZGVyUXVlcnkuaXNMb2FkaW5nICYmIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+Q2FycmVnYW5kbyBwZWRpZG/igKY8L3A+fVxyXG4gICAgICB7b3JkZXJRdWVyeS5pc0Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj5GYWxoYSBhbyBjYXJyZWdhciBvIHBlZGlkby48L3A+fVxyXG5cclxuICAgICAge29yZGVyICYmIHBhcnRpYWxPcGVuICYmIChcclxuICAgICAgICA8UGFydGlhbFBheW1lbnREaWFsb2dcclxuICAgICAgICAgIG9yZGVyPXtvcmRlcn1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFBhcnRpYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAgIG9uUmVnaXN0ZXJlZD17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRQYXJ0aWFsT3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEFjdGlvbkVycm9yKG51bGwpO1xyXG4gICAgICAgICAgICByZWZldGNoT3JkZXIoKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtzZWxlY3RpbmdJdGVtICYmIChcclxuICAgICAgICA8Q29tcGxlbWVudFNlbGVjdG9yTW9kYWxcclxuICAgICAgICAgIHByb2R1Y3ROYW1lPXtzZWxlY3RpbmdJdGVtLm5hbWV9XHJcbiAgICAgICAgICBncm91cHM9e3NlbGVjdGluZ0l0ZW0uY29tcGxlbWVudEdyb3Vwc31cclxuICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRTZWxlY3RpbmdJdGVtKG51bGwpfVxyXG4gICAgICAgICAgc3VibWl0dGluZz17YWRkSXRlbS5pc1BlbmRpbmd9XHJcbiAgICAgICAgICBvbkNvbmZpcm09eyhjb21wbGVtZW50cykgPT5cclxuICAgICAgICAgICAgYWRkSXRlbS5tdXRhdGUoeyBwcm9kdWN0SWQ6IHNlbGVjdGluZ0l0ZW0uaWQsIGNvbXBsZW1lbnRzIH0pXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtvcmRlciAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIHtvcmRlci5jb21hbmRhSWQgIT09IG51bGwgJiYgb3JkZXIuY3JlZGl0TGltaXRBbW91bnQgIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGlja2V0XCJcclxuICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogXCIxMHB4IDE2cHhcIixcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxyXG4gICAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgICAgIGdhcDogMTAsXHJcbiAgICAgICAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXHJcbiAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjpcclxuICAgICAgICAgICAgICAgICAgb3JkZXIudG90YWxBbW91bnQgPj0gb3JkZXIuY3JlZGl0TGltaXRBbW91bnQgPyBcInZhcigtLWRhbmdlcilcIiA6IFwidmFyKC0tbGluZSlcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44OHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiIH19PlxyXG4gICAgICAgICAgICAgICAgTGltaXRlIGRhIGNvbWFuZGE6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgPHN0cm9uZ1xyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtb25vLW51bVwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IGNyZWRpdExpbWl0Q29sb3Iob3JkZXIudG90YWxBbW91bnQsIG9yZGVyLmNyZWRpdExpbWl0QW1vdW50KSxcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdEJSTChvcmRlci50b3RhbEFtb3VudCl9IC8ge2Zvcm1hdEJSTChvcmRlci5jcmVkaXRMaW1pdEFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICA8L3N0cm9uZz5cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAge2ZlYXR1cmVzUXVlcnkuZGF0YT8uY2FuTWFuYWdlQWNjZXNzICYmIChcclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1pbkhlaWdodDogNDQsIHBhZGRpbmc6IFwiMCAxMnB4XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmFpc2VMaW1pdE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFuc3dlciA9IGF3YWl0IGRpYWxvZy5wcm9tcHQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiTGliZXJhciBsaW1pdGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBcIk5vdm8gbGltaXRlIGRhIGNvbWFuZGEgKFIkKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlOiBcImRlY2ltYWxcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZTogU3RyaW5nKG9yZGVyLmNyZWRpdExpbWl0QW1vdW50ISArIDEwMCksXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFuc3dlciA9PT0gbnVsbCkgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gTnVtYmVyKGFuc3dlci5yZXBsYWNlKFwiLFwiLCBcIi5cIikpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUodmFsdWUpICYmIHZhbHVlID4gMCkgcmFpc2VMaW1pdE11dGF0aW9uLm11dGF0ZSh2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIExpYmVyYXIgbGltaXRlIChnZXJlbnRlKVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LWhlYWRcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICBJdGVuc1xyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgYWJlcnRvIMOgcyB7bmV3IERhdGUob3JkZXIub3BlbmVkQXQpLnRvTG9jYWxlVGltZVN0cmluZyhcInB0LUJSXCIsIHsgaG91cjogXCIyLWRpZ2l0XCIsIG1pbnV0ZTogXCIyLWRpZ2l0XCIgfSl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtvcmRlci5pdGVtcy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LXJvd1wiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgICAgICAgIE5lbmh1bSBpdGVtIGxhbsOnYWRvIGFpbmRhLlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge29yZGVyLml0ZW1zLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IG5leHQgPSBuZXh0SXRlbVN0YXR1c1tpdGVtLm9yZGVySXRlbVN0YXR1c0lkXTtcclxuICAgICAgICAgICAgICBjb25zdCBjYW5jZWxsZWQgPSBpdGVtLm9yZGVySXRlbVN0YXR1c0lkID09PSBPcmRlckl0ZW1TdGF0dXMuQ2FuY2VsYWRvO1xyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBrZXk9e2l0ZW0uaWR9PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uOiBjYW5jZWxsZWQgPyBcImxpbmUtdGhyb3VnaFwiIDogXCJub25lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBjYW5jZWxsZWQgPyBcInZhcigtLWluay1mYWludClcIiA6IFwidmFyKC0taW5rKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5xdWFudGl0eX0gw5cge3Byb2R1Y3ROYW1lQnlJZC5nZXQoaXRlbS5wcm9kdWN0SWQpID8/IGBwcm9kdXRvICMke2l0ZW0ucHJvZHVjdElkfWB9IOKAlCB7Zm9ybWF0QlJMKGl0ZW0udG90YWxBbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAge29yZGVySXRlbVN0YXR1c0xhYmVsW2l0ZW0ub3JkZXJJdGVtU3RhdHVzSWRdfVxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubm90ZXMgPyBgIMK3ICR7aXRlbS5ub3Rlc31gIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAge2l0ZW0uY29tcGxlbWVudHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIHtpdGVtLmNvbXBsZW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcCgoYykgPT4gY29tcGxlbWVudE5hbWVCeUlkLmdldChjLmNvbXBsZW1lbnRJZCkgPz8gYGNvbXBsZW1lbnRvICMke2MuY29tcGxlbWVudElkfWApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmpvaW4oXCIsIFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAge2lzT3BlbiAmJiBuZXh0ICE9PSB1bmRlZmluZWQgJiYgIWNhbmNlbGxlZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiA2IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWluSGVpZ2h0OiA0NCwgcGFkZGluZzogXCIwIDEwcHhcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFkdmFuY2VJdGVtLm11dGF0ZSh7IGl0ZW1JZDogaXRlbS5pZCwgc3RhdHVzSWQ6IG5leHQgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKGkiB7b3JkZXJJdGVtU3RhdHVzTGFiZWxbbmV4dF19XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgQ2FuY2VsYXIgaXRlbSAke3Byb2R1Y3ROYW1lQnlJZC5nZXQoaXRlbS5wcm9kdWN0SWQpID8/IFwiXCJ9YC50cmltKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ2FuY2VsYXIgaXRlbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1pbkhlaWdodDogNDQsIHBhZGRpbmc6IFwiMCAxMHB4XCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFkdmFuY2VJdGVtLm11dGF0ZSh7IGl0ZW1JZDogaXRlbS5pZCwgc3RhdHVzSWQ6IE9yZGVySXRlbVN0YXR1cy5DYW5jZWxhZG8gfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDinJVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSl9XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiIH19PlxyXG4gICAgICAgICAgICAgIDxzcGFuPlN1YnRvdGFsPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+e2Zvcm1hdEJSTChvcmRlci5zdWJ0b3RhbEFtb3VudCl9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge29yZGVyLmRpc2NvdW50QW1vdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tb2spXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5EZXNjb250bzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+4oiSIHtmb3JtYXRCUkwob3JkZXIuZGlzY291bnRBbW91bnQpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge29yZGVyLnNlcnZpY2VGZWVBbW91bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiIH19PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+U2VydmnDp28gKDEwJSk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiPntmb3JtYXRCUkwob3JkZXIuc2VydmljZUZlZUFtb3VudCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7b3JkZXIucGFydGlhbFBhaWRBbW91bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tb2spXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPlBhZ28gcGFyY2lhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIj7iiJIge2Zvcm1hdEJSTChvcmRlci5wYXJ0aWFsUGFpZEFtb3VudCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1hbWJlcilcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+UmVzdGFudGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+e2Zvcm1hdEJSTChvcmRlci50b3RhbEFtb3VudCAtIG9yZGVyLnBhcnRpYWxQYWlkQW1vdW50KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtdG90YWxcIj5cclxuICAgICAgICAgICAgICA8c3Bhbj5Ub3RhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWFtYmVyKVwiIH19PlxyXG4gICAgICAgICAgICAgICAge2Zvcm1hdEJSTChvcmRlci50b3RhbEFtb3VudCl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHthY3Rpb25FcnJvciAmJiAoXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgICAgICB7YWN0aW9uRXJyb3J9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIEHDp8O1ZXMgc2VjdW5kw6FyaWFzIGFncnVwYWRhcyDigJQgZXZpdGEgYSBwaWxoYSB2ZXJ0aWNhbCBkZSBib3TDtWVzXHJcbiAgICAgICAgICAgICAgZSBkZWl4YSBhIGHDp8OjbyBwcmltw6FyaWEgKEZlY2hhciBjb250YSkgbGl2cmUgZGUgY29uY29ycsOqbmNpYSB2aXN1YWwuICovfVxyXG4gICAgICAgICAgeyhcclxuICAgICAgICAgICAgKGlzT3BlbiAmJiBvcmRlci5kaW5pbmdUYWJsZUlkICE9PSBudWxsICYmIGNhblVzZUNhc2ggJiZcclxuICAgICAgICAgICAgICBvcmRlci50b3RhbEFtb3VudCAtIG9yZGVyLnBhcnRpYWxQYWlkQW1vdW50ID4gMCkgfHxcclxuICAgICAgICAgICAgYXdhaXRpbmdQYXltZW50XHJcbiAgICAgICAgICApICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgICAge2lzT3BlbiAmJiBvcmRlci5kaW5pbmdUYWJsZUlkICE9PSBudWxsICYmIGNhblVzZUNhc2ggJiZcclxuICAgICAgICAgICAgICAgIG9yZGVyLnRvdGFsQW1vdW50IC0gb3JkZXIucGFydGlhbFBhaWRBbW91bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLWdob3N0XCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFBhcnRpYWxPcGVuKHRydWUpfT5cclxuICAgICAgICAgICAgICAgICAg8J+SuCBQYWdhbWVudG8gcGFyY2lhbCAoY2xpZW50ZSBzYWluZG8pXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7YXdhaXRpbmdQYXltZW50ICYmIChcclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZW9wZW5NdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBkaWFsb2cuY29uZmlybSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlJlYWJyaXIgY29uc3Vtb1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiUmVhYnJpciBhIGNvbnRhIHBhcmEgY29uc3Vtbz8gQSB0YXhhIGRlIHNlcnZpw6dvIHNlcsOhIHJlY2FsY3VsYWRhIG5vIHByw7N4aW1vIGZlY2hhbWVudG8uXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJSZWFicmlyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgIHJlb3Blbk11dGF0aW9uLm11dGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICDihqkgUmVhYnJpciBjb25zdW1vIChmZWNob3UgcG9yIGVuZ2FubylcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHthd2FpdGluZ1BheW1lbnQgJiYgb3JkZXIuc2VydmljZUZlZUFtb3VudCA+IDAgJiYgZmVhdHVyZXNRdWVyeS5kYXRhPy5jYW5NYW5hZ2VBY2Nlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlbW92ZUZlZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiUmV0aXJhciB0YXhhIGRlIHNlcnZpw6dvXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUmV0aXJhciBhIHRheGEgZGUgc2VydmnDp28gKDEwJSkgZGVzdGEgY29udGE/XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbDogXCJSZXRpcmFyIDEwJVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICByZW1vdmVGZWVNdXRhdGlvbi5tdXRhdGUoKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3JlbW92ZUZlZU11dGF0aW9uLmlzUGVuZGluZyA/IFwiUmV0aXJhbmRv4oCmXCIgOiBcIlJldGlyYXIgMTAlIChnZXJlbnRlKVwifVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge2F3YWl0aW5nUGF5bWVudCAmJiBwcmludFNldHRpbmdzUXVlcnkuZGF0YT8ucHJpbnRCaWxsc0VuYWJsZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3ByaW50QmlsbE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcHJpbnRCaWxsTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtwcmludEJpbGxNdXRhdGlvbi5pc1BlbmRpbmcgPyBcIkltcHJpbWluZG/igKZcIiA6IFwi8J+WqCBJbXByaW1pciBjb250YVwifVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHthd2FpdGluZ1BheW1lbnQgJiYgKFxyXG4gICAgICAgICAgICA8UGF5bWVudFBhbmVsXHJcbiAgICAgICAgICAgICAgb3JkZXI9e29yZGVyfVxyXG4gICAgICAgICAgICAgIG9uUGFpZD17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0QWN0aW9uRXJyb3IobnVsbCk7XHJcbiAgICAgICAgICAgICAgICByZWZldGNoT3JkZXIoKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7aXNFZGl0YWJsZSAmJiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBhcmlhLWV4cGFuZGVkPXttZW51T3Blbn1cclxuICAgICAgICAgICAgICAgIGFyaWEtY29udHJvbHM9XCJvcmRlci1kcmF3ZXItbWVudS1wYW5lbFwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNZW51T3BlbigodikgPT4gIXYpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHttZW51T3BlbiA/IFwiRmVjaGFyIGNhcmTDoXBpb1wiIDogXCIrIExhbsOnYXIgaXRlbVwifVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICB7bWVudU9wZW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBpZD1cIm9yZGVyLWRyYXdlci1tZW51LXBhbmVsXCIgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQnVzY2FyIG5vIGNhcmTDoXBpb+KAplwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCwgbWF4SGVpZ2h0OiAyNjAsIG92ZXJmbG93WTogXCJhdXRvXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAge21lbnVRdWVyeS5pc0xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT5DYXJyZWdhbmRvIGNhcmTDoXBpb+KApjwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZE1lbnUubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIHBhZGRpbmc6IFwiNnB4IDE0cHhcIiwgbWluSGVpZ2h0OiA1NiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17YWRkSXRlbS5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBpY2tJdGVtKGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiAxMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5pbWFnZVVybCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17aXRlbS5pbWFnZVVybH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDQwLCBoZWlnaHQ6IDQwLCBvYmplY3RGaXQ6IFwiY292ZXJcIiwgYm9yZGVyUmFkaXVzOiA4IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvbW9CeVByb2R1Y3QuaGFzKGl0ZW0uaWQpICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luTGVmdDogOCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5OiBcInZhcigtLWZvbnQtY29uZClcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIwLjY4cmVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogXCIwLjFlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcInZhcigtLWFtYmVyLWluaylcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLWFtYmVyKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjJweCA2cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA3MDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9tb0J5UHJvZHVjdC5nZXQoaXRlbS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWFtYmVyKVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRCUkwoaXRlbS5zYWxlUHJpY2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY29udG8gKFIkKeKAplwiXHJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJEZXNjb250byBlbSByZWFpc1wiXHJcbiAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZGlzY291bnR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGlzY291bnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2NvdW50LnRyaW0oKSA9PT0gXCJcIiB8fCBkaXNjb3VudE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGlzY291bnRNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQXBsaWNhclxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBSb2RhcMOpIGZpeG8g4oCUIGEgYcOnw6NvIHByaW3DoXJpYSAoRmVjaGFyIGNvbnRhKSBmaWNhIHNlbXByZSB2aXPDrXZlbCxcclxuICAgICAgICAgICAgICAgICAgbWVzbW8gY29tIGEgbGlzdGEgZGUgaXRlbnMvY2FyZMOhcGlvIHJvbGFuZG8gYWNpbWEuICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZHJhd2VyLWFjdGlvbmJhclwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGZsZXg6IDEgfX1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NhbmNlbE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiQ2FuY2VsYXIgcGVkaWRvXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiQ2FuY2VsYXIgZXN0ZSBwZWRpZG8/IEEgbWVzYS9jb21hbmRhIHNlcsOhIGxpYmVyYWRhLlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25maXJtTGFiZWw6IFwiQ2FuY2VsYXIgcGVkaWRvXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbExhYmVsOiBcIlZvbHRhclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbE11dGF0aW9uLm11dGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDYW5jZWxhciBwZWRpZG9cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAyIH19XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtvcmRlci5pdGVtcy5sZW5ndGggPT09IDAgfHwgY2xvc2VNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNsb3NlTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtzZXJ2aWNlRmVlT24gPyBcIkZlY2hhciBjb250YSAoKzEwJSlcIiA6IFwiRmVjaGFyIGNvbnRhIChzZW0gMTAlKVwifVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7IWlzT3BlbiAmJiAoXHJcbiAgICAgICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+XHJcbiAgICAgICAgICAgICAgUGVkaWRvIGVuY2VycmFkbyDigJQgc3RhdHVzIHtvcmRlci5vcmRlclN0YXR1c0lkID09PSBPcmRlclN0YXR1cy5QYWdvID8gXCJQYWdvXCIgOiBcIkNhbmNlbGFkb1wifS5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgIDwvT3ZlcmxheT5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9vcmRlcnMvT3JkZXJEcmF3ZXIudHN4In0=