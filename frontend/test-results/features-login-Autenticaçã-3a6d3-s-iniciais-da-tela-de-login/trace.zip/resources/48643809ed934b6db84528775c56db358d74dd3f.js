import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/publicOrdering/PublicOrderModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { formatBRL } from "/src/lib/types.ts";
import { ComandaReadingValidation, needsReadingValidation } from "/src/features/publicOrdering/ComandaReadingValidation.tsx";
export function PublicOrderModal({
  isOpen,
  onClose,
  tableNumber,
  token,
  isQrViewEnabled,
  linkedComandaCode,
  readingValidation,
  isComandaValidated,
  onComandaValidated,
  onFetchMesaBill,
  onFetchComandaBill
}) {
  _s();
  const [step, setStep] = useState("select");
  const [destination, setDestination] = useState("mesa");
  const [commandNumber, setCommandNumber] = useState("");
  const [consultedCode, setConsultedCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [billData, setBillData] = useState(null);
  const [windowWidth, setWindowWidth] = useState(typeof window !== "undefined" ? window.innerWidth : 1200);
  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  const isTvOrLarge = windowWidth > 1200;
  useEffect(() => {
    if (!isOpen || isQrViewEnabled) return;
    let cancelled = false;
    setLoading(true);
    setError(false);
    let fetchBill;
    if (linkedComandaCode) {
      setDestination("comanda");
      setConsultedCode(linkedComandaCode);
      fetchBill = onFetchComandaBill(linkedComandaCode);
    } else {
      setDestination("mesa");
      fetchBill = onFetchMesaBill();
    }
    fetchBill.then((data) => {
      if (cancelled) return;
      setBillData(data);
      setStep("view");
    }).catch(() => {
      if (!cancelled) setError(true);
    }).finally(() => {
      if (!cancelled) setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [isOpen, isQrViewEnabled, linkedComandaCode]);
  if (!isOpen) return null;
  const consultComanda = async (code) => {
    setLoading(true);
    setError(false);
    try {
      setConsultedCode(code);
      const data = await onFetchComandaBill(code);
      setBillData(data);
      setStep("view");
    } catch {
      setError(true);
      setStep("select");
    } finally {
      setLoading(false);
    }
  };
  const handleConsult = async () => {
    if (destination === "mesa") {
      setLoading(true);
      setError(false);
      try {
        const data = await onFetchMesaBill();
        setBillData(data);
        setStep("view");
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
      return;
    }
    if (!commandNumber) return;
    if (needsReadingValidation(readingValidation) && !isComandaValidated(commandNumber)) {
      setStep("validate");
      return;
    }
    await consultComanda(commandNumber);
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.85)", zIndex: 9999, display: "flex", alignItems: step === "view" ? "flex-end" : "center", justifyContent: "center", padding: step === "view" ? 0 : 16 }, children: step === "validate" ? /* @__PURE__ */ jsxDEV("div", { style: { backgroundColor: "#1e1e24", padding: isTvOrLarge ? 36 : 24, borderRadius: 16, width: "100%", maxWidth: isTvOrLarge ? 550 : 420, border: "1px solid #323238", boxShadow: "0 10px 30px rgba(0,0,0,0.6)" }, children: /* @__PURE__ */ jsxDEV(
    ComandaReadingValidation,
    {
      token,
      comandaCode: commandNumber,
      requirement: readingValidation,
      onValidated: () => {
        onComandaValidated(commandNumber);
        void consultComanda(commandNumber);
      },
      onCancel: () => setStep("select")
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 153,
      columnNumber: 21
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
    lineNumber: 152,
    columnNumber: 7
  }, this) : step === "select" && isQrViewEnabled ? /* @__PURE__ */ jsxDEV("div", { style: { backgroundColor: "#1e1e24", padding: isTvOrLarge ? 36 : 24, borderRadius: 16, width: "100%", maxWidth: isTvOrLarge ? 550 : 420, border: "1px solid #323238", boxShadow: "0 10px 30px rgba(0,0,0,0.6)", fontSize: isTvOrLarge ? "1.15rem" : "1rem" }, children: [
    /* @__PURE__ */ jsxDEV("h3", { style: { marginTop: 0, marginBottom: isTvOrLarge ? 32 : 24, color: "#fff", fontSize: isTvOrLarge ? "1.5rem" : "1.2rem", textAlign: "center" }, children: "Qual conta deseja consultar?" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 166,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12, marginBottom: destination === "comanda" ? 20 : 28 }, children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setDestination("mesa"),
          style: { flex: 1, padding: isTvOrLarge ? "18px" : "14px", borderRadius: 8, border: destination === "mesa" ? "2px solid #f59e0b" : "1px solid #323238", backgroundColor: destination === "mesa" ? "rgba(245, 158, 11, 0.1)" : "transparent", color: destination === "mesa" ? "#f59e0b" : "#a8a8b3", fontWeight: "bold", cursor: "pointer", fontSize: isTvOrLarge ? "1.1rem" : "1rem" },
          children: "Da Mesa"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 170,
          columnNumber: 25
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setDestination("comanda"),
          style: { flex: 1, padding: isTvOrLarge ? "18px" : "14px", borderRadius: 8, border: destination === "comanda" ? "2px solid #f59e0b" : "1px solid #323238", backgroundColor: destination === "comanda" ? "rgba(245, 158, 11, 0.1)" : "transparent", color: destination === "comanda" ? "#f59e0b" : "#a8a8b3", fontWeight: "bold", cursor: "pointer", fontSize: isTvOrLarge ? "1.1rem" : "1rem" },
          children: "Da Comanda"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 176,
          columnNumber: 25
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 169,
      columnNumber: 21
    }, this),
    destination === "comanda" && /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 28 }, children: [
      /* @__PURE__ */ jsxDEV("label", { style: { display: "block", color: "#a8a8b3", marginBottom: 8, fontSize: isTvOrLarge ? "1.05rem" : "0.9rem" }, children: "Número da Comanda" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
        lineNumber: 185,
        columnNumber: 29
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: commandNumber,
          onChange: (e) => setCommandNumber(e.target.value),
          placeholder: "Ex: 001",
          autoFocus: true,
          style: { width: "100%", padding: isTvOrLarge ? "18px 20px" : "14px 16px", borderRadius: 8, border: "1px solid #323238", backgroundColor: "#121214", color: "#fff", fontSize: isTvOrLarge ? "1.2rem" : "1rem", outline: "none", boxSizing: "border-box" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 186,
          columnNumber: 29
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 184,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: onClose, style: { flex: 1, padding: isTvOrLarge ? "18px" : "14px", borderRadius: 8, border: "none", backgroundColor: "#323238", color: "#fff", fontWeight: "bold", cursor: "pointer", fontSize: isTvOrLarge ? "1.1rem" : "1rem" }, children: "Cancelar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
        lineNumber: 197,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          disabled: destination === "comanda" && !commandNumber || loading,
          onClick: handleConsult,
          style: { flex: 1, padding: isTvOrLarge ? "18px" : "14px", borderRadius: 8, border: "none", backgroundColor: "#f59e0b", color: "#121214", fontWeight: "bold", cursor: "pointer", opacity: loading ? 0.7 : 1, fontSize: isTvOrLarge ? "1.1rem" : "1rem" },
          children: loading ? "Buscando..." : "Consultar"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 200,
          columnNumber: 25
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 196,
      columnNumber: 21
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
    lineNumber: 165,
    columnNumber: 7
  }, this) : step === "view" ? /* @__PURE__ */ jsxDEV("div", { style: { backgroundColor: "#1e1e24", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: isTvOrLarge ? 36 : 24, width: "100%", maxWidth: isTvOrLarge ? 800 : "100%", maxHeight: "85vh", display: "flex", flexDirection: "column", boxShadow: "0 -5px 30px rgba(0,0,0,0.6)", fontSize: isTvOrLarge ? "1.1rem" : "1rem" }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #323238", paddingBottom: 16, marginBottom: 16 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 12 }, children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setStep("select"), style: { background: "none", border: "none", color: "#a8a8b3", fontSize: isTvOrLarge ? "1.5rem" : "1.2rem", cursor: "pointer", padding: 0 }, children: "←" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 213,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { style: { margin: 0, fontSize: isTvOrLarge ? "1.5rem" : "1.2rem", color: "#fff" }, children: destination === "mesa" ? `Conta - Mesa ${tableNumber}` : `Conta - Comanda ${consultedCode}` }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 214,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
        lineNumber: 212,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: onClose, style: { background: "none", border: "none", color: "#a8a8b3", fontSize: isTvOrLarge ? "2rem" : "1.5rem", cursor: "pointer" }, children: "✕" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
        lineNumber: 218,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 211,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, overflowY: "auto", paddingRight: 4 }, children: error ? /* @__PURE__ */ jsxDEV("p", { style: { textAlign: "center", color: "#ef4444", marginTop: 40, fontSize: isTvOrLarge ? "1.2rem" : "1rem" }, children: "Nenhum consumo encontrado ou comanda inválida." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 222,
      columnNumber: 11
    }, this) : !billData?.items?.length ? /* @__PURE__ */ jsxDEV("p", { style: { textAlign: "center", color: "#a8a8b3", marginTop: 40, fontSize: isTvOrLarge ? "1.2rem" : "1rem" }, children: "Nenhum pedido feito ainda nesta conta." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 224,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12 }, children: billData.items.map((order) => {
      const statusText = order.statusId === 1 ? "Pendente" : order.statusId === 2 ? "Preparando" : order.statusId === 3 ? "Pronto" : "Entregue";
      return /* @__PURE__ */ jsxDEV("div", { style: { backgroundColor: "#202024", padding: isTvOrLarge ? 20 : 16, borderRadius: 8, border: "1px solid #323238" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", marginBottom: 8 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "#fff", fontWeight: "bold", fontSize: isTvOrLarge ? "1.2rem" : "1rem" }, children: [
            order.quantity,
            "x ",
            order.productName
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
            lineNumber: 232,
            columnNumber: 49
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "#f59e0b", fontWeight: "bold", fontSize: isTvOrLarge ? "1.2rem" : "1rem" }, children: formatBRL(order.totalPrice) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
            lineNumber: 233,
            columnNumber: 49
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 231,
          columnNumber: 45
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV("span", { style: { fontSize: isTvOrLarge ? "0.95rem" : "0.8rem", padding: "4px 8px", borderRadius: 4, fontWeight: "bold", backgroundColor: "rgba(245, 158, 11, 0.2)", color: "#f59e0b" }, children: statusText }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 236,
          columnNumber: 49
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 235,
          columnNumber: 45
        }, this)
      ] }, order.itemId, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
        lineNumber: 230,
        columnNumber: 17
      }, this);
    }) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 226,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 220,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { borderTop: "1px solid #323238", paddingTop: 16, marginTop: 16 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { color: "#a8a8b3", fontSize: isTvOrLarge ? "1.3rem" : "1.1rem" }, children: "Total Geral" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 248,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "#fff", fontSize: isTvOrLarge ? "1.8rem" : "1.4rem", fontWeight: "bold" }, children: formatBRL(billData?.totalAmount || 0) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
          lineNumber: 249,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
        lineNumber: 247,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: onClose, style: { width: "100%", padding: isTvOrLarge ? "20px" : "16px", borderRadius: 8, border: "none", backgroundColor: "#f59e0b", color: "#121214", fontWeight: "bold", fontSize: isTvOrLarge ? "1.2rem" : "1.1rem", cursor: "pointer" }, children: "Continuar Comprando" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
        lineNumber: 251,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 246,
      columnNumber: 21
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
    lineNumber: 210,
    columnNumber: 7
  }, this) : (
    // Sem "Visualização do Cliente (QR Code)": instante entre abrir o modal e o
    // efeito buscar a conta da mesa — sem isso, piscaria a tela "Mesa ou Comanda?".
    /* @__PURE__ */ jsxDEV("div", { style: { backgroundColor: "#1e1e24", padding: isTvOrLarge ? 36 : 24, borderRadius: 16, width: "100%", maxWidth: isTvOrLarge ? 550 : 420, border: "1px solid #323238", boxShadow: "0 10px 30px rgba(0,0,0,0.6)", textAlign: "center", color: "#a8a8b3" }, children: "Carregando…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
      lineNumber: 259,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx",
    lineNumber: 150,
    columnNumber: 5
  }, this);
}
_s(PublicOrderModal, "LyscxwAP9KGPGIYkjbwAszyVUAE=");
_c = PublicOrderModal;
var _c;
$RefreshReg$(_c, "PublicOrderModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUlvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFySXBCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsMEJBQTBCQyw4QkFBaUU7QUEwQjdGLGdCQUFTQyxpQkFBaUI7QUFBQSxFQUM3QkM7QUFBQUEsRUFBUUM7QUFBQUEsRUFBU0M7QUFBQUEsRUFBYUM7QUFBQUEsRUFBT0M7QUFBQUEsRUFBaUJDO0FBQUFBLEVBQW1CQztBQUFBQSxFQUFtQkM7QUFBQUEsRUFBb0JDO0FBQUFBLEVBQ2hIQztBQUFBQSxFQUFpQkM7QUFDRSxHQUFHO0FBQUFDLEtBQUE7QUFDdEIsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUluQixTQUF5QyxRQUFRO0FBQ3pFLFFBQU0sQ0FBQ29CLGFBQWFDLGNBQWMsSUFBSXJCLFNBQTZCLE1BQU07QUFDekUsUUFBTSxDQUFDc0IsZUFBZUMsZ0JBQWdCLElBQUl2QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDd0IsZUFBZUMsZ0JBQWdCLElBQUl6QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDMEIsU0FBU0MsVUFBVSxJQUFJM0IsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQzRCLE9BQU9DLFFBQVEsSUFBSTdCLFNBQVMsS0FBSztBQUN4QyxRQUFNLENBQUM4QixVQUFVQyxXQUFXLElBQUkvQixTQUFjLElBQUk7QUFFbEQsUUFBTSxDQUFDZ0MsYUFBYUMsY0FBYyxJQUFJakMsU0FBUyxPQUFPa0MsV0FBVyxjQUFjQSxPQUFPQyxhQUFhLElBQUk7QUFDdkdsQyxZQUFVLE1BQU07QUFDWixVQUFNbUMsZUFBZUEsTUFBTUgsZUFBZUMsT0FBT0MsVUFBVTtBQUMzREQsV0FBT0csaUJBQWlCLFVBQVVELFlBQVk7QUFDOUMsV0FBTyxNQUFNRixPQUFPSSxvQkFBb0IsVUFBVUYsWUFBWTtBQUFBLEVBQ2xFLEdBQUcsRUFBRTtBQUNMLFFBQU1HLGNBQWNQLGNBQWM7QUFPbEMvQixZQUFVLE1BQU07QUFDWixRQUFJLENBQUNLLFVBQVVJLGdCQUFpQjtBQUNoQyxRQUFJOEIsWUFBWTtBQUNoQmIsZUFBVyxJQUFJO0FBQ2ZFLGFBQVMsS0FBSztBQUVkLFFBQUlZO0FBQ0osUUFBSTlCLG1CQUFtQjtBQUNuQlUscUJBQWUsU0FBUztBQUN4QkksdUJBQWlCZCxpQkFBaUI7QUFDbEM4QixrQkFBWXpCLG1CQUFtQkwsaUJBQWlCO0FBQUEsSUFDcEQsT0FBTztBQUNIVSxxQkFBZSxNQUFNO0FBQ3JCb0Isa0JBQVkxQixnQkFBZ0I7QUFBQSxJQUNoQztBQUVBMEIsY0FDS0MsS0FBSyxDQUFDQyxTQUFTO0FBQ1osVUFBSUgsVUFBVztBQUNmVCxrQkFBWVksSUFBSTtBQUNoQnhCLGNBQVEsTUFBTTtBQUFBLElBQ2xCLENBQUMsRUFDQXlCLE1BQU0sTUFBTTtBQUNULFVBQUksQ0FBQ0osVUFBV1gsVUFBUyxJQUFJO0FBQUEsSUFDakMsQ0FBQyxFQUNBZ0IsUUFBUSxNQUFNO0FBQ1gsVUFBSSxDQUFDTCxVQUFXYixZQUFXLEtBQUs7QUFBQSxJQUNwQyxDQUFDO0FBQ0wsV0FBTyxNQUFNO0FBQ1RhLGtCQUFZO0FBQUEsSUFDaEI7QUFBQSxFQUNKLEdBQUcsQ0FBQ2xDLFFBQVFJLGlCQUFpQkMsaUJBQWlCLENBQUM7QUFFL0MsTUFBSSxDQUFDTCxPQUFRLFFBQU87QUFFcEIsUUFBTXdDLGlCQUFpQixPQUFPQyxTQUFpQjtBQUMzQ3BCLGVBQVcsSUFBSTtBQUNmRSxhQUFTLEtBQUs7QUFDZCxRQUFJO0FBQ0FKLHVCQUFpQnNCLElBQUk7QUFDckIsWUFBTUosT0FBTyxNQUFNM0IsbUJBQW1CK0IsSUFBSTtBQUMxQ2hCLGtCQUFZWSxJQUFJO0FBQ2hCeEIsY0FBUSxNQUFNO0FBQUEsSUFDbEIsUUFBUTtBQUNKVSxlQUFTLElBQUk7QUFDYlYsY0FBUSxRQUFRO0FBQUEsSUFDcEIsVUFBQztBQUNHUSxpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTXFCLGdCQUFnQixZQUFZO0FBQzlCLFFBQUk1QixnQkFBZ0IsUUFBUTtBQUN4Qk8saUJBQVcsSUFBSTtBQUNmRSxlQUFTLEtBQUs7QUFDZCxVQUFJO0FBQ0EsY0FBTWMsT0FBTyxNQUFNNUIsZ0JBQWdCO0FBQ25DZ0Isb0JBQVlZLElBQUk7QUFDaEJ4QixnQkFBUSxNQUFNO0FBQUEsTUFDbEIsUUFBUTtBQUNKVSxpQkFBUyxJQUFJO0FBQUEsTUFDakIsVUFBQztBQUNHRixtQkFBVyxLQUFLO0FBQUEsTUFDcEI7QUFDQTtBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUNMLGNBQWU7QUFHcEIsUUFBSWxCLHVCQUF1QlEsaUJBQWlCLEtBQUssQ0FBQ0MsbUJBQW1CUyxhQUFhLEdBQUc7QUFDakZILGNBQVEsVUFBVTtBQUNsQjtBQUFBLElBQ0o7QUFDQSxVQUFNMkIsZUFBZXhCLGFBQWE7QUFBQSxFQUN0QztBQUVBLFNBQ0ksdUJBQUMsU0FBSSxPQUFPLEVBQUUyQixVQUFVLFNBQVNDLE9BQU8sR0FBR0MsaUJBQWlCLG9CQUFvQkMsUUFBUSxNQUFNQyxTQUFTLFFBQVFDLFlBQVlwQyxTQUFTLFNBQVMsYUFBYSxVQUFVcUMsZ0JBQWdCLFVBQVVDLFNBQVN0QyxTQUFTLFNBQVMsSUFBSSxHQUFHLEdBQzNOQSxtQkFBUyxhQUNOLHVCQUFDLFNBQUksT0FBTyxFQUFFaUMsaUJBQWlCLFdBQVdLLFNBQVNqQixjQUFjLEtBQUssSUFBSWtCLGNBQWMsSUFBSUMsT0FBTyxRQUFRQyxVQUFVcEIsY0FBYyxNQUFNLEtBQUtxQixRQUFRLHFCQUFxQkMsV0FBVyw4QkFBOEIsR0FDaE47QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHO0FBQUEsTUFDQSxhQUFhdkM7QUFBQUEsTUFDYixhQUFhVjtBQUFBQSxNQUNiLGFBQWEsTUFBTTtBQUNmRSwyQkFBbUJRLGFBQWE7QUFDaEMsYUFBS3dCLGVBQWV4QixhQUFhO0FBQUEsTUFDckM7QUFBQSxNQUNBLFVBQVUsTUFBTUgsUUFBUSxRQUFRO0FBQUE7QUFBQSxJQVJwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRc0MsS0FUMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBLElBQ0FELFNBQVMsWUFBWVIsa0JBQ3JCLHVCQUFDLFNBQUksT0FBTyxFQUFFeUMsaUJBQWlCLFdBQVdLLFNBQVNqQixjQUFjLEtBQUssSUFBSWtCLGNBQWMsSUFBSUMsT0FBTyxRQUFRQyxVQUFVcEIsY0FBYyxNQUFNLEtBQUtxQixRQUFRLHFCQUFxQkMsV0FBVywrQkFBK0JDLFVBQVV2QixjQUFjLFlBQVksT0FBTyxHQUM1UDtBQUFBLDJCQUFDLFFBQUcsT0FBTyxFQUFFd0IsV0FBVyxHQUFHQyxjQUFjekIsY0FBYyxLQUFLLElBQUkwQixPQUFPLFFBQVFILFVBQVV2QixjQUFjLFdBQVcsVUFBVTJCLFdBQVcsU0FBUyxHQUFHLDRDQUFuSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFYixTQUFTLFFBQVFjLEtBQUssSUFBSUgsY0FBYzVDLGdCQUFnQixZQUFZLEtBQUssR0FBRyxHQUN0RjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxTQUFTLE1BQU1DLGVBQWUsTUFBTTtBQUFBLFVBQ3BDLE9BQU8sRUFBRStDLE1BQU0sR0FBR1osU0FBU2pCLGNBQWMsU0FBUyxRQUFRa0IsY0FBYyxHQUFHRyxRQUFReEMsZ0JBQWdCLFNBQVMsc0JBQXNCLHFCQUFxQitCLGlCQUFpQi9CLGdCQUFnQixTQUFTLDRCQUE0QixlQUFlNkMsT0FBTzdDLGdCQUFnQixTQUFTLFlBQVksV0FBV2lELFlBQVksUUFBUUMsUUFBUSxXQUFXUixVQUFVdkIsY0FBYyxXQUFXLE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUYxWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFNBQVMsTUFBTWxCLGVBQWUsU0FBUztBQUFBLFVBQ3ZDLE9BQU8sRUFBRStDLE1BQU0sR0FBR1osU0FBU2pCLGNBQWMsU0FBUyxRQUFRa0IsY0FBYyxHQUFHRyxRQUFReEMsZ0JBQWdCLFlBQVksc0JBQXNCLHFCQUFxQitCLGlCQUFpQi9CLGdCQUFnQixZQUFZLDRCQUE0QixlQUFlNkMsT0FBTzdDLGdCQUFnQixZQUFZLFlBQVksV0FBV2lELFlBQVksUUFBUUMsUUFBUSxXQUFXUixVQUFVdkIsY0FBYyxXQUFXLE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUZuWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLFNBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFDQ25CLGdCQUFnQixhQUNiLHVCQUFDLFNBQUksT0FBTyxFQUFFNEMsY0FBYyxHQUFHLEdBQzNCO0FBQUEsNkJBQUMsV0FBTSxPQUFPLEVBQUVYLFNBQVMsU0FBU1ksT0FBTyxXQUFXRCxjQUFjLEdBQUdGLFVBQVV2QixjQUFjLFlBQVksU0FBUyxHQUFHLGlDQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNJO0FBQUEsTUFDdEk7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLE9BQU9qQjtBQUFBQSxVQUNQLFVBQVUsQ0FBQ2lELE1BQU1oRCxpQkFBaUJnRCxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsVUFDaEQsYUFBWTtBQUFBLFVBQ1o7QUFBQSxVQUNBLE9BQU8sRUFBRWYsT0FBTyxRQUFRRixTQUFTakIsY0FBYyxjQUFjLGFBQWFrQixjQUFjLEdBQUdHLFFBQVEscUJBQXFCVCxpQkFBaUIsV0FBV2MsT0FBTyxRQUFRSCxVQUFVdkIsY0FBYyxXQUFXLFFBQVFtQyxTQUFTLFFBQVFDLFdBQVcsYUFBYTtBQUFBO0FBQUEsUUFOM1A7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTTZQO0FBQUEsU0FSalE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFSix1QkFBQyxTQUFJLE9BQU8sRUFBRXRCLFNBQVMsUUFBUWMsS0FBSyxHQUFHLEdBQ25DO0FBQUEsNkJBQUMsWUFBTyxTQUFTNUQsU0FBUyxPQUFPLEVBQUU2RCxNQUFNLEdBQUdaLFNBQVNqQixjQUFjLFNBQVMsUUFBUWtCLGNBQWMsR0FBR0csUUFBUSxRQUFRVCxpQkFBaUIsV0FBV2MsT0FBTyxRQUFRSSxZQUFZLFFBQVFDLFFBQVEsV0FBV1IsVUFBVXZCLGNBQWMsV0FBVyxPQUFPLEdBQUcsd0JBQXBQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFVBQVVuQixnQkFBZ0IsYUFBYSxDQUFDRSxpQkFBaUJJO0FBQUFBLFVBQ3pELFNBQVNzQjtBQUFBQSxVQUNULE9BQU8sRUFBRW9CLE1BQU0sR0FBR1osU0FBU2pCLGNBQWMsU0FBUyxRQUFRa0IsY0FBYyxHQUFHRyxRQUFRLFFBQVFULGlCQUFpQixXQUFXYyxPQUFPLFdBQVdJLFlBQVksUUFBUUMsUUFBUSxXQUFXTSxTQUFTbEQsVUFBVSxNQUFNLEdBQUdvQyxVQUFVdkIsY0FBYyxXQUFXLE9BQU87QUFBQSxVQUVyUGIsb0JBQVUsZ0JBQWdCO0FBQUE7QUFBQSxRQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0ExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJDQSxJQUNBUixTQUFTLFNBQ1QsdUJBQUMsU0FBSSxPQUFPLEVBQUVpQyxpQkFBaUIsV0FBVzBCLHFCQUFxQixJQUFJQyxzQkFBc0IsSUFBSXRCLFNBQVNqQixjQUFjLEtBQUssSUFBSW1CLE9BQU8sUUFBUUMsVUFBVXBCLGNBQWMsTUFBTSxRQUFRd0MsV0FBVyxRQUFRMUIsU0FBUyxRQUFRMkIsZUFBZSxVQUFVbkIsV0FBVywrQkFBK0JDLFVBQVV2QixjQUFjLFdBQVcsT0FBTyxHQUMvVDtBQUFBLDJCQUFDLFNBQUksT0FBTyxFQUFFYyxTQUFTLFFBQVFFLGdCQUFnQixpQkFBaUJELFlBQVksVUFBVTJCLGNBQWMscUJBQXFCQyxlQUFlLElBQUlsQixjQUFjLEdBQUcsR0FDeko7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRVgsU0FBUyxRQUFRQyxZQUFZLFVBQVVhLEtBQUssR0FBRyxHQUN6RDtBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNaEQsUUFBUSxRQUFRLEdBQUcsT0FBTyxFQUFFZ0UsWUFBWSxRQUFRdkIsUUFBUSxRQUFRSyxPQUFPLFdBQVdILFVBQVV2QixjQUFjLFdBQVcsVUFBVStCLFFBQVEsV0FBV2QsU0FBUyxFQUFFLEdBQUcsaUJBQXZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0w7QUFBQSxRQUN4TCx1QkFBQyxRQUFHLE9BQU8sRUFBRTRCLFFBQVEsR0FBR3RCLFVBQVV2QixjQUFjLFdBQVcsVUFBVTBCLE9BQU8sT0FBTyxHQUM5RTdDLDBCQUFnQixTQUFTLGdCQUFnQlosV0FBVyxLQUFLLG1CQUFtQmdCLGFBQWEsTUFEOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFlBQU8sU0FBU2pCLFNBQVMsT0FBTyxFQUFFNEUsWUFBWSxRQUFRdkIsUUFBUSxRQUFRSyxPQUFPLFdBQVdILFVBQVV2QixjQUFjLFNBQVMsVUFBVStCLFFBQVEsVUFBVSxHQUFHLGlCQUF6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBKO0FBQUEsU0FQOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUYsTUFBTSxHQUFHaUIsV0FBVyxRQUFRQyxjQUFjLEVBQUUsR0FDckQxRCxrQkFDRyx1QkFBQyxPQUFFLE9BQU8sRUFBRXNDLFdBQVcsVUFBVUQsT0FBTyxXQUFXRixXQUFXLElBQUlELFVBQVV2QixjQUFjLFdBQVcsT0FBTyxHQUFHLDhEQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZKLElBQzdKLENBQUNULFVBQVV5RCxPQUFPQyxTQUNsQix1QkFBQyxPQUFFLE9BQU8sRUFBRXRCLFdBQVcsVUFBVUQsT0FBTyxXQUFXRixXQUFXLElBQUlELFVBQVV2QixjQUFjLFdBQVcsT0FBTyxHQUFHLHNEQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFKLElBRXJKLHVCQUFDLFNBQUksT0FBTyxFQUFFYyxTQUFTLFFBQVFjLEtBQUssR0FBRyxHQUNsQ3JDLG1CQUFTeUQsTUFBTUUsSUFBSSxDQUFDQyxVQUFlO0FBQ2hDLFlBQU1DLGFBQWFELE1BQU1FLGFBQWEsSUFBSSxhQUFhRixNQUFNRSxhQUFhLElBQUksZUFBZUYsTUFBTUUsYUFBYSxJQUFJLFdBQVc7QUFDL0gsYUFDSSx1QkFBQyxTQUF1QixPQUFPLEVBQUV6QyxpQkFBaUIsV0FBV0ssU0FBU2pCLGNBQWMsS0FBSyxJQUFJa0IsY0FBYyxHQUFHRyxRQUFRLG9CQUFvQixHQUN0STtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFUCxTQUFTLFFBQVFFLGdCQUFnQixpQkFBaUJTLGNBQWMsRUFBRSxHQUM1RTtBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLFFBQVFJLFlBQVksUUFBUVAsVUFBVXZCLGNBQWMsV0FBVyxPQUFPLEdBQUltRDtBQUFBQSxrQkFBTUc7QUFBQUEsWUFBUztBQUFBLFlBQUdILE1BQU1JO0FBQUFBLGVBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9JO0FBQUEsVUFDcEksdUJBQUMsVUFBSyxPQUFPLEVBQUU3QixPQUFPLFdBQVdJLFlBQVksUUFBUVAsVUFBVXZCLGNBQWMsV0FBVyxPQUFPLEdBQUlyQyxvQkFBVXdGLE1BQU1LLFVBQVUsS0FBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0g7QUFBQSxhQUZuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFMUMsU0FBUyxRQUFRRSxnQkFBZ0IsV0FBVyxHQUN0RCxpQ0FBQyxVQUFLLE9BQU8sRUFBRU8sVUFBVXZCLGNBQWMsWUFBWSxVQUFVaUIsU0FBUyxXQUFXQyxjQUFjLEdBQUdZLFlBQVksUUFBUWxCLGlCQUFpQiwyQkFBMkJjLE9BQU8sVUFBVSxHQUM5SzBCLHdCQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBVE1ELE1BQU1NLFFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLElBRVIsQ0FBQyxLQWhCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBLEtBdkJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxXQUFXLHFCQUFxQkMsWUFBWSxJQUFJbkMsV0FBVyxHQUFHLEdBQ3hFO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVWLFNBQVMsUUFBUUUsZ0JBQWdCLGlCQUFpQkQsWUFBWSxVQUFVVSxjQUFjLEdBQUcsR0FDbkc7QUFBQSwrQkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxXQUFXSCxVQUFVdkIsY0FBYyxXQUFXLFNBQVMsR0FBRywyQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRjtBQUFBLFFBQzNGLHVCQUFDLFVBQUssT0FBTyxFQUFFMEIsT0FBTyxRQUFRSCxVQUFVdkIsY0FBYyxXQUFXLFVBQVU4QixZQUFZLE9BQU8sR0FBSW5FLG9CQUFVNEIsVUFBVXFFLGVBQWUsQ0FBQyxLQUF0STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdJO0FBQUEsV0FGNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLFNBQVM1RixTQUFTLE9BQU8sRUFBRW1ELE9BQU8sUUFBUUYsU0FBU2pCLGNBQWMsU0FBUyxRQUFRa0IsY0FBYyxHQUFHRyxRQUFRLFFBQVFULGlCQUFpQixXQUFXYyxPQUFPLFdBQVdJLFlBQVksUUFBUVAsVUFBVXZCLGNBQWMsV0FBVyxVQUFVK0IsUUFBUSxVQUFVLEdBQUcsbUNBQS9QO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsT0E1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZDQTtBQUFBO0FBQUE7QUFBQSxJQUlBLHVCQUFDLFNBQUksT0FBTyxFQUFFbkIsaUJBQWlCLFdBQVdLLFNBQVNqQixjQUFjLEtBQUssSUFBSWtCLGNBQWMsSUFBSUMsT0FBTyxRQUFRQyxVQUFVcEIsY0FBYyxNQUFNLEtBQUtxQixRQUFRLHFCQUFxQkMsV0FBVywrQkFBK0JLLFdBQVcsVUFBVUQsT0FBTyxVQUFVLEdBQUcsMkJBQTlQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BL0dSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpSEE7QUFFUjtBQUFDaEQsR0F6TmVaLGtCQUFnQjtBQUFBLEtBQWhCQTtBQUFnQixJQUFBK0Y7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJmb3JtYXRCUkwiLCJDb21hbmRhUmVhZGluZ1ZhbGlkYXRpb24iLCJuZWVkc1JlYWRpbmdWYWxpZGF0aW9uIiwiUHVibGljT3JkZXJNb2RhbCIsImlzT3BlbiIsIm9uQ2xvc2UiLCJ0YWJsZU51bWJlciIsInRva2VuIiwiaXNRclZpZXdFbmFibGVkIiwibGlua2VkQ29tYW5kYUNvZGUiLCJyZWFkaW5nVmFsaWRhdGlvbiIsImlzQ29tYW5kYVZhbGlkYXRlZCIsIm9uQ29tYW5kYVZhbGlkYXRlZCIsIm9uRmV0Y2hNZXNhQmlsbCIsIm9uRmV0Y2hDb21hbmRhQmlsbCIsIl9zIiwic3RlcCIsInNldFN0ZXAiLCJkZXN0aW5hdGlvbiIsInNldERlc3RpbmF0aW9uIiwiY29tbWFuZE51bWJlciIsInNldENvbW1hbmROdW1iZXIiLCJjb25zdWx0ZWRDb2RlIiwic2V0Q29uc3VsdGVkQ29kZSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImJpbGxEYXRhIiwic2V0QmlsbERhdGEiLCJ3aW5kb3dXaWR0aCIsInNldFdpbmRvd1dpZHRoIiwid2luZG93IiwiaW5uZXJXaWR0aCIsImhhbmRsZVJlc2l6ZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiaXNUdk9yTGFyZ2UiLCJjYW5jZWxsZWQiLCJmZXRjaEJpbGwiLCJ0aGVuIiwiZGF0YSIsImNhdGNoIiwiZmluYWxseSIsImNvbnN1bHRDb21hbmRhIiwiY29kZSIsImhhbmRsZUNvbnN1bHQiLCJwb3NpdGlvbiIsImluc2V0IiwiYmFja2dyb3VuZENvbG9yIiwiekluZGV4IiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsInBhZGRpbmciLCJib3JkZXJSYWRpdXMiLCJ3aWR0aCIsIm1heFdpZHRoIiwiYm9yZGVyIiwiYm94U2hhZG93IiwiZm9udFNpemUiLCJtYXJnaW5Ub3AiLCJtYXJnaW5Cb3R0b20iLCJjb2xvciIsInRleHRBbGlnbiIsImdhcCIsImZsZXgiLCJmb250V2VpZ2h0IiwiY3Vyc29yIiwiZSIsInRhcmdldCIsInZhbHVlIiwib3V0bGluZSIsImJveFNpemluZyIsIm9wYWNpdHkiLCJib3JkZXJUb3BMZWZ0UmFkaXVzIiwiYm9yZGVyVG9wUmlnaHRSYWRpdXMiLCJtYXhIZWlnaHQiLCJmbGV4RGlyZWN0aW9uIiwiYm9yZGVyQm90dG9tIiwicGFkZGluZ0JvdHRvbSIsImJhY2tncm91bmQiLCJtYXJnaW4iLCJvdmVyZmxvd1kiLCJwYWRkaW5nUmlnaHQiLCJpdGVtcyIsImxlbmd0aCIsIm1hcCIsIm9yZGVyIiwic3RhdHVzVGV4dCIsInN0YXR1c0lkIiwicXVhbnRpdHkiLCJwcm9kdWN0TmFtZSIsInRvdGFsUHJpY2UiLCJpdGVtSWQiLCJib3JkZXJUb3AiLCJwYWRkaW5nVG9wIiwidG90YWxBbW91bnQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQdWJsaWNPcmRlck1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IGZvcm1hdEJSTCB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgQ29tYW5kYVJlYWRpbmdWYWxpZGF0aW9uLCBuZWVkc1JlYWRpbmdWYWxpZGF0aW9uLCB0eXBlIFJlYWRpbmdWYWxpZGF0aW9uUmVxdWlyZW1lbnQgfSBmcm9tIFwiLi9Db21hbmRhUmVhZGluZ1ZhbGlkYXRpb25cIjtcclxuXHJcbnR5cGUgUHVibGljT3JkZXJNb2RhbFByb3BzID0ge1xyXG4gICAgaXNPcGVuOiBib29sZWFuO1xyXG4gICAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxuICAgIHRhYmxlTnVtYmVyOiBzdHJpbmc7XHJcbiAgICB0b2tlbjogc3RyaW5nO1xyXG4gICAgLy8gRGluaW5nVGFibGUuSXNRclZpZXdFbmFibGVkOiBxdWFuZG8gZGVzbGlnYWRhLCBhIGZpbGlhbCBuw6NvIHVzYSBvIGZsdXhvIGRlIGNvbWFuZGFcclxuICAgIC8vIHBhcmEgbyBjbGllbnRlIOKAlCBhIGNvbnRhIMOpIHNlbXByZSBhIGRhIG1lc2EsIHNlbSBwZXJndW50YXIgXCJNZXNhIG91IENvbWFuZGE/XCIg4oCUXHJcbiAgICAvLyBFWENFVE8gcXVhbmRvIGrDoSBleGlzdGUgdW1hIGNvbWFuZGEgdmluY3VsYWRhIHZpYSBjw6JtZXJhL1FSL2JhcmNvZGUgbmVzdGEgdmlzaXRhXHJcbiAgICAvLyAodmVyIGxpbmtlZENvbWFuZGFDb2RlIGFiYWl4byksIGNhc28gZW0gcXVlIG9zIHBlZGlkb3Mgc2HDrXJhbSBkYSBtZXNhIGUgZm9yYW1cclxuICAgIC8vIHByYSBlbGEuXHJcbiAgICBpc1FyVmlld0VuYWJsZWQ6IGJvb2xlYW47XHJcbiAgICAvLyBQcmVlbmNoaWRvIHF1YW5kbyBJc1FyVmlld0VuYWJsZWQgZXN0w6EgZGVzbGlnYWRhIGUgbyBjbGllbnRlIGrDoSB2aW5jdWxvdSB1bVxyXG4gICAgLy8gcGVkaWRvIGEgdW1hIGNvbWFuZGEgbmVzdGEgdmlzaXRhIHZpYSBjw6JtZXJhL1FSIENvZGUvY8OzZGlnbyBkZSBiYXJyYXMgKHZlclxyXG4gICAgLy8gTGlua0NvbWFuZGFWYWxpZGF0aW9uIGVtIFB1YmxpY09yZGVyUGFnZSkuIFF1YW5kbyBwcmVzZW50ZSwgXCJNaW5oYSBDb250YVwiIG1vc3RyYVxyXG4gICAgLy8gYSBjb250YSBkZXNzYSBjb21hbmRhIGVtIHZleiBkYSBjb250YSBkYSBtZXNhIOKAlCDDqSBsw6EgcXVlIG9zIHBlZGlkb3MgZm9yYW1cclxuICAgIC8vIHBhcmFyLCBuw6NvIG5hIG1lc2EuXHJcbiAgICBsaW5rZWRDb21hbmRhQ29kZTogc3RyaW5nIHwgbnVsbDtcclxuICAgIHJlYWRpbmdWYWxpZGF0aW9uOiBSZWFkaW5nVmFsaWRhdGlvblJlcXVpcmVtZW50O1xyXG4gICAgaXNDb21hbmRhVmFsaWRhdGVkOiAoY29kZTogc3RyaW5nKSA9PiBib29sZWFuO1xyXG4gICAgb25Db21hbmRhVmFsaWRhdGVkOiAoY29kZTogc3RyaW5nKSA9PiB2b2lkO1xyXG4gICAgb25GZXRjaE1lc2FCaWxsOiAoKSA9PiBQcm9taXNlPGFueT47XHJcbiAgICBvbkZldGNoQ29tYW5kYUJpbGw6IChjb2RlOiBzdHJpbmcpID0+IFByb21pc2U8YW55PjtcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBQdWJsaWNPcmRlck1vZGFsKHtcclxuICAgIGlzT3Blbiwgb25DbG9zZSwgdGFibGVOdW1iZXIsIHRva2VuLCBpc1FyVmlld0VuYWJsZWQsIGxpbmtlZENvbWFuZGFDb2RlLCByZWFkaW5nVmFsaWRhdGlvbiwgaXNDb21hbmRhVmFsaWRhdGVkLCBvbkNvbWFuZGFWYWxpZGF0ZWQsXHJcbiAgICBvbkZldGNoTWVzYUJpbGwsIG9uRmV0Y2hDb21hbmRhQmlsbCxcclxufTogUHVibGljT3JkZXJNb2RhbFByb3BzKSB7XHJcbiAgICBjb25zdCBbc3RlcCwgc2V0U3RlcF0gPSB1c2VTdGF0ZTxcInNlbGVjdFwiIHwgXCJ2YWxpZGF0ZVwiIHwgXCJ2aWV3XCI+KFwic2VsZWN0XCIpO1xyXG4gICAgY29uc3QgW2Rlc3RpbmF0aW9uLCBzZXREZXN0aW5hdGlvbl0gPSB1c2VTdGF0ZTxcIm1lc2FcIiB8IFwiY29tYW5kYVwiPihcIm1lc2FcIik7XHJcbiAgICBjb25zdCBbY29tbWFuZE51bWJlciwgc2V0Q29tbWFuZE51bWJlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtjb25zdWx0ZWRDb2RlLCBzZXRDb25zdWx0ZWRDb2RlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbYmlsbERhdGEsIHNldEJpbGxEYXRhXSA9IHVzZVN0YXRlPGFueT4obnVsbCk7XHJcbiAgICAvLyBNb25pdG9yYW1lbnRvIGRlIGxhcmd1cmEgZGUgdGVsYSBwYXJhIGVzY2FsYXMgZGluw6JtaWNhc1xyXG4gICAgY29uc3QgW3dpbmRvd1dpZHRoLCBzZXRXaW5kb3dXaWR0aF0gPSB1c2VTdGF0ZSh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93LmlubmVyV2lkdGggOiAxMjAwKTtcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaGFuZGxlUmVzaXplID0gKCkgPT4gc2V0V2luZG93V2lkdGgod2luZG93LmlubmVyV2lkdGgpO1xyXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIGhhbmRsZVJlc2l6ZSk7XHJcbiAgICAgICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIGhhbmRsZVJlc2l6ZSk7XHJcbiAgICB9LCBbXSk7XHJcbiAgICBjb25zdCBpc1R2T3JMYXJnZSA9IHdpbmRvd1dpZHRoID4gMTIwMDtcclxuXHJcbiAgICAvLyBTZW0gXCJWaXN1YWxpemHDp8OjbyBkbyBDbGllbnRlIChRUiBDb2RlKVwiIGxpZ2FkYSBuw6NvIGV4aXN0ZSBmbHV4byBkZSBjb21hbmRhIHByb1xyXG4gICAgLy8gY2xpZW50ZSDigJQgYW8gYWJyaXIgbyBtb2RhbCwgcHVsYSBhIHBlcmd1bnRhIFwiTWVzYSBvdSBDb21hbmRhP1wiIGUgbW9zdHJhIGEgY29udGFcclxuICAgIC8vIGRpcmV0bzogZGEgY29tYW5kYSB2aW5jdWxhZGEgbmVzdGEgdmlzaXRhIChmbHV4byBjw6JtZXJhL1FSL2JhcmNvZGUg4oCUIMOpIGzDoSBxdWUgb3NcclxuICAgIC8vIHBlZGlkb3MgZm9yYW0gcGFyYXIsIG7Do28gbmEgbWVzYSksIG91IGRhIG1lc2Egc2UgYWluZGEgbsOjbyBob3V2ZXIgY29tYW5kYVxyXG4gICAgLy8gdmluY3VsYWRhLlxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoIWlzT3BlbiB8fCBpc1FyVmlld0VuYWJsZWQpIHJldHVybjtcclxuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XHJcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgICBzZXRFcnJvcihmYWxzZSk7XHJcblxyXG4gICAgICAgIGxldCBmZXRjaEJpbGw6IFByb21pc2U8YW55PjtcclxuICAgICAgICBpZiAobGlua2VkQ29tYW5kYUNvZGUpIHtcclxuICAgICAgICAgICAgc2V0RGVzdGluYXRpb24oXCJjb21hbmRhXCIpO1xyXG4gICAgICAgICAgICBzZXRDb25zdWx0ZWRDb2RlKGxpbmtlZENvbWFuZGFDb2RlKTtcclxuICAgICAgICAgICAgZmV0Y2hCaWxsID0gb25GZXRjaENvbWFuZGFCaWxsKGxpbmtlZENvbWFuZGFDb2RlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzZXREZXN0aW5hdGlvbihcIm1lc2FcIik7XHJcbiAgICAgICAgICAgIGZldGNoQmlsbCA9IG9uRmV0Y2hNZXNhQmlsbCgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZmV0Y2hCaWxsXHJcbiAgICAgICAgICAgIC50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm47XHJcbiAgICAgICAgICAgICAgICBzZXRCaWxsRGF0YShkYXRhKTtcclxuICAgICAgICAgICAgICAgIHNldFN0ZXAoXCJ2aWV3XCIpO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuY2F0Y2goKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHNldEVycm9yKHRydWUpO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuZmluYWxseSgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNhbmNlbGxlZCA9IHRydWU7XHJcbiAgICAgICAgfTtcclxuICAgIH0sIFtpc09wZW4sIGlzUXJWaWV3RW5hYmxlZCwgbGlua2VkQ29tYW5kYUNvZGVdKTtcclxuXHJcbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgY29uc3QgY29uc3VsdENvbWFuZGEgPSBhc3luYyAoY29kZTogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgICBzZXRFcnJvcihmYWxzZSk7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgc2V0Q29uc3VsdGVkQ29kZShjb2RlKTtcclxuICAgICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IG9uRmV0Y2hDb21hbmRhQmlsbChjb2RlKTtcclxuICAgICAgICAgICAgc2V0QmlsbERhdGEoZGF0YSk7XHJcbiAgICAgICAgICAgIHNldFN0ZXAoXCJ2aWV3XCIpO1xyXG4gICAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgICAgICBzZXRFcnJvcih0cnVlKTtcclxuICAgICAgICAgICAgc2V0U3RlcChcInNlbGVjdFwiKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNvbnN1bHQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgaWYgKGRlc3RpbmF0aW9uID09PSBcIm1lc2FcIikge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgICAgICBzZXRFcnJvcihmYWxzZSk7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgb25GZXRjaE1lc2FCaWxsKCk7XHJcbiAgICAgICAgICAgICAgICBzZXRCaWxsRGF0YShkYXRhKTtcclxuICAgICAgICAgICAgICAgIHNldFN0ZXAoXCJ2aWV3XCIpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgICAgICAgIHNldEVycm9yKHRydWUpO1xyXG4gICAgICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIWNvbW1hbmROdW1iZXIpIHJldHVybjtcclxuICAgICAgICAvLyBDb21hbmRhOiBzZSBhIGZpbGlhbCBleGlnZSBjw6JtZXJhL2PDs2RpZ28gZGUgYmFycmFzL1FSIENvZGUgZSBlc3RlIGPDs2RpZ28gYWluZGFcclxuICAgICAgICAvLyBuw6NvIGZvaSB2YWxpZGFkbyBuZXN0YSBzZXNzw6NvLCBwZWRlIGEgY29uZmlybWHDp8OjbyBleHRyYSBhbnRlcyBkZSBjb25zdWx0YXIuXHJcbiAgICAgICAgaWYgKG5lZWRzUmVhZGluZ1ZhbGlkYXRpb24ocmVhZGluZ1ZhbGlkYXRpb24pICYmICFpc0NvbWFuZGFWYWxpZGF0ZWQoY29tbWFuZE51bWJlcikpIHtcclxuICAgICAgICAgICAgc2V0U3RlcChcInZhbGlkYXRlXCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGF3YWl0IGNvbnN1bHRDb21hbmRhKGNvbW1hbmROdW1iZXIpO1xyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246IFwiZml4ZWRcIiwgaW5zZXQ6IDAsIGJhY2tncm91bmRDb2xvcjogXCJyZ2JhKDAsMCwwLDAuODUpXCIsIHpJbmRleDogOTk5OSwgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IHN0ZXAgPT09IFwidmlld1wiID8gXCJmbGV4LWVuZFwiIDogXCJjZW50ZXJcIiwganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsIHBhZGRpbmc6IHN0ZXAgPT09IFwidmlld1wiID8gMCA6IDE2IH19PlxyXG4gICAgICAgICAgICB7c3RlcCA9PT0gXCJ2YWxpZGF0ZVwiID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwiIzFlMWUyNFwiLCBwYWRkaW5nOiBpc1R2T3JMYXJnZSA/IDM2IDogMjQsIGJvcmRlclJhZGl1czogMTYsIHdpZHRoOiBcIjEwMCVcIiwgbWF4V2lkdGg6IGlzVHZPckxhcmdlID8gNTUwIDogNDIwLCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiwgYm94U2hhZG93OiBcIjAgMTBweCAzMHB4IHJnYmEoMCwwLDAsMC42KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb21hbmRhUmVhZGluZ1ZhbGlkYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdG9rZW49e3Rva2VufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb21hbmRhQ29kZT17Y29tbWFuZE51bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZW1lbnQ9e3JlYWRpbmdWYWxpZGF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvblZhbGlkYXRlZD17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db21hbmRhVmFsaWRhdGVkKGNvbW1hbmROdW1iZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdm9pZCBjb25zdWx0Q29tYW5kYShjb21tYW5kTnVtYmVyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DYW5jZWw9eygpID0+IHNldFN0ZXAoXCJzZWxlY3RcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogc3RlcCA9PT0gXCJzZWxlY3RcIiAmJiBpc1FyVmlld0VuYWJsZWQgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCIjMWUxZTI0XCIsIHBhZGRpbmc6IGlzVHZPckxhcmdlID8gMzYgOiAyNCwgYm9yZGVyUmFkaXVzOiAxNiwgd2lkdGg6IFwiMTAwJVwiLCBtYXhXaWR0aDogaXNUdk9yTGFyZ2UgPyA1NTAgOiA0MjAsIGJvcmRlcjogXCIxcHggc29saWQgIzMyMzIzOFwiLCBib3hTaGFkb3c6IFwiMCAxMHB4IDMwcHggcmdiYSgwLDAsMCwwLjYpXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS4xNXJlbVwiIDogXCIxcmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIHN0eWxlPXt7IG1hcmdpblRvcDogMCwgbWFyZ2luQm90dG9tOiBpc1R2T3JMYXJnZSA/IDMyIDogMjQsIGNvbG9yOiBcIiNmZmZcIiwgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIxLjVyZW1cIiA6IFwiMS4ycmVtXCIsIHRleHRBbGlnbjogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUXVhbCBjb250YSBkZXNlamEgY29uc3VsdGFyP1xyXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMiwgbWFyZ2luQm90dG9tOiBkZXN0aW5hdGlvbiA9PT0gXCJjb21hbmRhXCIgPyAyMCA6IDI4IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXREZXN0aW5hdGlvbihcIm1lc2FcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxLCBwYWRkaW5nOiBpc1R2T3JMYXJnZSA/IFwiMThweFwiIDogXCIxNHB4XCIsIGJvcmRlclJhZGl1czogOCwgYm9yZGVyOiBkZXN0aW5hdGlvbiA9PT0gXCJtZXNhXCIgPyBcIjJweCBzb2xpZCAjZjU5ZTBiXCIgOiBcIjFweCBzb2xpZCAjMzIzMjM4XCIsIGJhY2tncm91bmRDb2xvcjogZGVzdGluYXRpb24gPT09IFwibWVzYVwiID8gXCJyZ2JhKDI0NSwgMTU4LCAxMSwgMC4xKVwiIDogXCJ0cmFuc3BhcmVudFwiLCBjb2xvcjogZGVzdGluYXRpb24gPT09IFwibWVzYVwiID8gXCIjZjU5ZTBiXCIgOiBcIiNhOGE4YjNcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGN1cnNvcjogXCJwb2ludGVyXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS4xcmVtXCIgOiBcIjFyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEYSBNZXNhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXREZXN0aW5hdGlvbihcImNvbWFuZGFcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxLCBwYWRkaW5nOiBpc1R2T3JMYXJnZSA/IFwiMThweFwiIDogXCIxNHB4XCIsIGJvcmRlclJhZGl1czogOCwgYm9yZGVyOiBkZXN0aW5hdGlvbiA9PT0gXCJjb21hbmRhXCIgPyBcIjJweCBzb2xpZCAjZjU5ZTBiXCIgOiBcIjFweCBzb2xpZCAjMzIzMjM4XCIsIGJhY2tncm91bmRDb2xvcjogZGVzdGluYXRpb24gPT09IFwiY29tYW5kYVwiID8gXCJyZ2JhKDI0NSwgMTU4LCAxMSwgMC4xKVwiIDogXCJ0cmFuc3BhcmVudFwiLCBjb2xvcjogZGVzdGluYXRpb24gPT09IFwiY29tYW5kYVwiID8gXCIjZjU5ZTBiXCIgOiBcIiNhOGE4YjNcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGN1cnNvcjogXCJwb2ludGVyXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS4xcmVtXCIgOiBcIjFyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEYSBDb21hbmRhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHtkZXN0aW5hdGlvbiA9PT0gXCJjb21hbmRhXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMjggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogXCJibG9ja1wiLCBjb2xvcjogXCIjYThhOGIzXCIsIG1hcmdpbkJvdHRvbTogOCwgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIxLjA1cmVtXCIgOiBcIjAuOXJlbVwiIH19Pk7Dum1lcm8gZGEgQ29tYW5kYTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1hbmROdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb21tYW5kTnVtYmVyKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiAwMDFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgcGFkZGluZzogaXNUdk9yTGFyZ2UgPyBcIjE4cHggMjBweFwiIDogXCIxNHB4IDE2cHhcIiwgYm9yZGVyUmFkaXVzOiA4LCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiwgYmFja2dyb3VuZENvbG9yOiBcIiMxMjEyMTRcIiwgY29sb3I6IFwiI2ZmZlwiLCBmb250U2l6ZTogaXNUdk9yTGFyZ2UgPyBcIjEuMnJlbVwiIDogXCIxcmVtXCIsIG91dGxpbmU6IFwibm9uZVwiLCBib3hTaXppbmc6IFwiYm9yZGVyLWJveFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbG9zZX0gc3R5bGU9e3sgZmxleDogMSwgcGFkZGluZzogaXNUdk9yTGFyZ2UgPyBcIjE4cHhcIiA6IFwiMTRweFwiLCBib3JkZXJSYWRpdXM6IDgsIGJvcmRlcjogXCJub25lXCIsIGJhY2tncm91bmRDb2xvcjogXCIjMzIzMjM4XCIsIGNvbG9yOiBcIiNmZmZcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGN1cnNvcjogXCJwb2ludGVyXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS4xcmVtXCIgOiBcIjFyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbGFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGVzdGluYXRpb24gPT09IFwiY29tYW5kYVwiICYmICFjb21tYW5kTnVtYmVyIHx8IGxvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb25zdWx0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZmxleDogMSwgcGFkZGluZzogaXNUdk9yTGFyZ2UgPyBcIjE4cHhcIiA6IFwiMTRweFwiLCBib3JkZXJSYWRpdXM6IDgsIGJvcmRlcjogXCJub25lXCIsIGJhY2tncm91bmRDb2xvcjogXCIjZjU5ZTBiXCIsIGNvbG9yOiBcIiMxMjEyMTRcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGN1cnNvcjogXCJwb2ludGVyXCIsIG9wYWNpdHk6IGxvYWRpbmcgPyAwLjcgOiAxLCBmb250U2l6ZTogaXNUdk9yTGFyZ2UgPyBcIjEuMXJlbVwiIDogXCIxcmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyBcIkJ1c2NhbmRvLi4uXCIgOiBcIkNvbnN1bHRhclwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogc3RlcCA9PT0gXCJ2aWV3XCIgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCIjMWUxZTI0XCIsIGJvcmRlclRvcExlZnRSYWRpdXM6IDI0LCBib3JkZXJUb3BSaWdodFJhZGl1czogMjQsIHBhZGRpbmc6IGlzVHZPckxhcmdlID8gMzYgOiAyNCwgd2lkdGg6IFwiMTAwJVwiLCBtYXhXaWR0aDogaXNUdk9yTGFyZ2UgPyA4MDAgOiBcIjEwMCVcIiwgbWF4SGVpZ2h0OiBcIjg1dmhcIiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGJveFNoYWRvdzogXCIwIC01cHggMzBweCByZ2JhKDAsMCwwLDAuNilcIiwgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIxLjFyZW1cIiA6IFwiMXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjMzIzMjM4XCIsIHBhZGRpbmdCb3R0b206IDE2LCBtYXJnaW5Cb3R0b206IDE2IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKFwic2VsZWN0XCIpfSBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcIm5vbmVcIiwgYm9yZGVyOiBcIm5vbmVcIiwgY29sb3I6IFwiI2E4YThiM1wiLCBmb250U2l6ZTogaXNUdk9yTGFyZ2UgPyBcIjEuNXJlbVwiIDogXCIxLjJyZW1cIiwgY3Vyc29yOiBcInBvaW50ZXJcIiwgcGFkZGluZzogMCB9fT7ihpA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBzdHlsZT17eyBtYXJnaW46IDAsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS41cmVtXCIgOiBcIjEuMnJlbVwiLCBjb2xvcjogXCIjZmZmXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Rlc3RpbmF0aW9uID09PSBcIm1lc2FcIiA/IGBDb250YSAtIE1lc2EgJHt0YWJsZU51bWJlcn1gIDogYENvbnRhIC0gQ29tYW5kYSAke2NvbnN1bHRlZENvZGV9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xvc2V9IHN0eWxlPXt7IGJhY2tncm91bmQ6IFwibm9uZVwiLCBib3JkZXI6IFwibm9uZVwiLCBjb2xvcjogXCIjYThhOGIzXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMnJlbVwiIDogXCIxLjVyZW1cIiwgY3Vyc29yOiBcInBvaW50ZXJcIiB9fT7inJU8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG92ZXJmbG93WTogXCJhdXRvXCIsIHBhZGRpbmdSaWdodDogNCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9yID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiLCBjb2xvcjogXCIjZWY0NDQ0XCIsIG1hcmdpblRvcDogNDAsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS4ycmVtXCIgOiBcIjFyZW1cIiB9fT5OZW5odW0gY29uc3VtbyBlbmNvbnRyYWRvIG91IGNvbWFuZGEgaW52w6FsaWRhLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6ICFiaWxsRGF0YT8uaXRlbXM/Lmxlbmd0aCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgY29sb3I6IFwiI2E4YThiM1wiLCBtYXJnaW5Ub3A6IDQwLCBmb250U2l6ZTogaXNUdk9yTGFyZ2UgPyBcIjEuMnJlbVwiIDogXCIxcmVtXCIgfX0+TmVuaHVtIHBlZGlkbyBmZWl0byBhaW5kYSBuZXN0YSBjb250YS48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtiaWxsRGF0YS5pdGVtcy5tYXAoKG9yZGVyOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3RhdHVzVGV4dCA9IG9yZGVyLnN0YXR1c0lkID09PSAxID8gXCJQZW5kZW50ZVwiIDogb3JkZXIuc3RhdHVzSWQgPT09IDIgPyBcIlByZXBhcmFuZG9cIiA6IG9yZGVyLnN0YXR1c0lkID09PSAzID8gXCJQcm9udG9cIiA6IFwiRW50cmVndWVcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtvcmRlci5pdGVtSWR9IHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCIjMjAyMDI0XCIsIHBhZGRpbmc6IGlzVHZPckxhcmdlID8gMjAgOiAxNiwgYm9yZGVyUmFkaXVzOiA4LCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIG1hcmdpbkJvdHRvbTogOCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwiI2ZmZlwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIxLjJyZW1cIiA6IFwiMXJlbVwiIH19PntvcmRlci5xdWFudGl0eX14IHtvcmRlci5wcm9kdWN0TmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcIiNmNTllMGJcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS4ycmVtXCIgOiBcIjFyZW1cIiB9fT57Zm9ybWF0QlJMKG9yZGVyLnRvdGFsUHJpY2UpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogaXNUdk9yTGFyZ2UgPyBcIjAuOTVyZW1cIiA6IFwiMC44cmVtXCIsIHBhZGRpbmc6IFwiNHB4IDhweFwiLCBib3JkZXJSYWRpdXM6IDQsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBiYWNrZ3JvdW5kQ29sb3I6IFwicmdiYSgyNDUsIDE1OCwgMTEsIDAuMilcIiwgY29sb3I6IFwiI2Y1OWUwYlwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXR1c1RleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBib3JkZXJUb3A6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiwgcGFkZGluZ1RvcDogMTYsIG1hcmdpblRvcDogMTYgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgbWFyZ2luQm90dG9tOiAxNiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcIiNhOGE4YjNcIiwgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIxLjNyZW1cIiA6IFwiMS4xcmVtXCIgfX0+VG90YWwgR2VyYWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCIjZmZmXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS44cmVtXCIgOiBcIjEuNHJlbVwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiB9fT57Zm9ybWF0QlJMKGJpbGxEYXRhPy50b3RhbEFtb3VudCB8fCAwKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xvc2V9IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgcGFkZGluZzogaXNUdk9yTGFyZ2UgPyBcIjIwcHhcIiA6IFwiMTZweFwiLCBib3JkZXJSYWRpdXM6IDgsIGJvcmRlcjogXCJub25lXCIsIGJhY2tncm91bmRDb2xvcjogXCIjZjU5ZTBiXCIsIGNvbG9yOiBcIiMxMjEyMTRcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS4ycmVtXCIgOiBcIjEuMXJlbVwiLCBjdXJzb3I6IFwicG9pbnRlclwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29udGludWFyIENvbXByYW5kb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgLy8gU2VtIFwiVmlzdWFsaXphw6fDo28gZG8gQ2xpZW50ZSAoUVIgQ29kZSlcIjogaW5zdGFudGUgZW50cmUgYWJyaXIgbyBtb2RhbCBlIG9cclxuICAgICAgICAgICAgICAgIC8vIGVmZWl0byBidXNjYXIgYSBjb250YSBkYSBtZXNhIOKAlCBzZW0gaXNzbywgcGlzY2FyaWEgYSB0ZWxhIFwiTWVzYSBvdSBDb21hbmRhP1wiLlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwiIzFlMWUyNFwiLCBwYWRkaW5nOiBpc1R2T3JMYXJnZSA/IDM2IDogMjQsIGJvcmRlclJhZGl1czogMTYsIHdpZHRoOiBcIjEwMCVcIiwgbWF4V2lkdGg6IGlzVHZPckxhcmdlID8gNTUwIDogNDIwLCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMjMyMzhcIiwgYm94U2hhZG93OiBcIjAgMTBweCAzMHB4IHJnYmEoMCwwLDAsMC42KVwiLCB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIGNvbG9yOiBcIiNhOGE4YjNcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICBDYXJyZWdhbmRv4oCmXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3B1YmxpY09yZGVyaW5nL1B1YmxpY09yZGVyTW9kYWwudHN4In0=