import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodIntegrationPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  createIFoodInterruption,
  deleteIFoodInterruption,
  getIFoodFinancialSummary,
  getIFoodInterruptions,
  getIFoodMerchantDetails,
  getIFoodMerchantMappings,
  getIFoodMerchantsList,
  getIFoodMerchantStatus,
  getIFoodMerchantStatusByOperation,
  getIFoodOpeningHours,
  getIFoodSettings,
  saveIFoodOpeningHours,
  saveIFoodSettings,
  setIFoodMerchantMapping,
  setIFoodPreparationTime,
  syncIFoodCatalog,
  syncIFoodFinancial,
  testIFoodConnection
} from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useToast } from "/src/ui/Toast.tsx";
import { Field, SelectField, TextField } from "/src/ui/Field.tsx";
import { Button } from "/src/ui/Button.tsx";
import { Switch } from "/src/ui/Switch.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
const CONNECTION_STATUS_META = {
  connected: { label: "Conectado", dot: "var(--ok)" },
  failed: { label: "Falhou no último teste", dot: "var(--danger)" },
  untested: { label: "Nunca testado", dot: "var(--ink-faint)" }
};
function getConnectionStatusKey(lastTest) {
  if (lastTest === true) return "connected";
  if (lastTest === false) return "failed";
  return "untested";
}
export function IFoodIntegrationPage() {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { companyId: rawCompanyId } = useAuthStore();
  const companyId = rawCompanyId ?? 1;
  const [clientId, setClientId] = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [enabled, setEnabled] = useState(false);
  const [ifoodCustomerId, setIfoodCustomerId] = useState("");
  const [initializedCompanyId, setInitializedCompanyId] = useState(null);
  const settingsQuery = useQuery({
    queryKey: ["integrations", "ifood", "settings", companyId],
    queryFn: () => getIFoodSettings(companyId)
  });
  useEffect(() => {
    if (settingsQuery.data && initializedCompanyId !== companyId) {
      setClientId(settingsQuery.data.clientId ?? "");
      setEnabled(settingsQuery.data.enabled);
      setIfoodCustomerId(settingsQuery.data.ifoodCustomerId ?? "");
      setInitializedCompanyId(companyId);
    }
  }, [settingsQuery.data, companyId, initializedCompanyId]);
  const saveMutation = useMutation({
    mutationFn: () => saveIFoodSettings({
      companyId,
      clientId: clientId.trim(),
      clientSecret: clientSecret.trim(),
      enabled,
      ifoodCustomerId: ifoodCustomerId.trim()
    }),
    onSuccess: () => {
      toast.success("Credenciais do iFood salvas.");
      setClientSecret("");
      void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "settings"] });
    },
    onError: () => toast.error("Não foi possível salvar as credenciais.")
  });
  const testMutation = useMutation({
    mutationFn: () => testIFoodConnection(companyId),
    onSuccess: (result) => {
      if (result.success) toast.success("Conectado ao iFood com sucesso.");
      else
        toast.error(result.errorMessage ?? "Falha ao conectar — confira as credenciais.");
      void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "settings"] });
    },
    onError: () => toast.error("Não foi possível testar a conexão.")
  });
  const mappingsQuery = useQuery({
    queryKey: ["integrations", "ifood", "merchants", companyId],
    queryFn: () => getIFoodMerchantMappings(companyId)
  });
  const syncCatalogMutation = useMutation({
    mutationFn: () => syncIFoodCatalog(companyId),
    onSuccess: (summary) => {
      if (summary.skipped) {
        toast.error("Integração desabilitada ou nenhuma loja com Merchant ID configurado — nada foi sincronizado.");
        return;
      }
      const errorSuffix = summary.errors > 0 ? ` (${summary.errors} erro${summary.errors === 1 ? "" : "s"})` : "";
      toast.success(
        `Cardápio sincronizado: ${summary.productsSynced} produto(s) em ${summary.branchesSynced} loja(s)${errorSuffix}.`
      );
    },
    onError: () => toast.error("Não foi possível sincronizar o cardápio com o iFood.")
  });
  const firstMappedBranch = (mappingsQuery.data ?? []).find((m) => !!m.merchantId);
  const financialSummaryQuery = useQuery({
    queryKey: ["integrations", "ifood", "financial", firstMappedBranch?.branchId],
    queryFn: () => getIFoodFinancialSummary(firstMappedBranch.branchId),
    enabled: !!firstMappedBranch
  });
  const syncFinancialMutation = useMutation({
    mutationFn: () => syncIFoodFinancial(companyId),
    onSuccess: () => {
      toast.success("Sincronização financeira disparada — os dados aparecem aqui em instantes.");
      void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "financial"] });
    },
    onError: () => toast.error("Não foi possível disparar a sincronização financeira.")
  });
  const lastTest = settingsQuery.data?.lastConnectionTestSucceeded;
  const connectionStatus = CONNECTION_STATUS_META[getConnectionStatusKey(lastTest)];
  const statusLabel = connectionStatus.label;
  const statusDot = connectionStatus.dot;
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 900, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Integração iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 170,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "credenciais do app (por empresa) + lojas conectadas — somente gerente/administrador" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 173,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 169,
      columnNumber: 7
    }, this),
    settingsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: settingsQuery.error, what: "a integração com o iFood" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 178,
      columnNumber: 33
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-1", style: { padding: 20, display: "grid", gap: 16 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Credenciais do aplicativo" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 182,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: 'Client ID e Client Secret vêm de "Meus aplicativos" no portal do iFood Developer — um único app pode dar acesso a várias lojas, então essas credenciais valem pra empresa inteira (cada loja individual é configurada na seção "Lojas" abaixo).' }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 185,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 181,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Client ID",
          value: clientId,
          onChange: (e) => setClientId(e.target.value),
          placeholder: "ex.: 3f9a1c2b-..."
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 192,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Client Secret",
          type: "password",
          value: clientSecret,
          onChange: (e) => setClientSecret(e.target.value),
          placeholder: settingsQuery.data?.hasCredentials ? "•••••••• (deixe em branco para manter o atual)" : "cole o Client Secret aqui",
          hint: "Fica criptografado no banco — esta tela nunca reexibe o valor já salvo."
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 199,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "iFood Customer ID (opcional)",
          value: ifoodCustomerId,
          onChange: (e) => setIfoodCustomerId(e.target.value),
          placeholder: "necessário só para configurar tempo de preparo (seção Operação da loja)",
          hint: "Não é segredo — fica salvo em texto puro. Sem ele, o resto da integração funciona normalmente, só o campo de tempo de preparo fica desabilitado."
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 208,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Field, { label: "Integração ativa", children: () => /* @__PURE__ */ jsxDEV(
        Switch,
        {
          checked: enabled,
          onChange: setEnabled,
          label: "Ativar integração com o iFood",
          disabled: saveMutation.isPending
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 218,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 216,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "primary",
          loading: saveMutation.isPending,
          disabled: enabled && clientId.trim() === "",
          onClick: () => saveMutation.mutate(),
          children: "Salvar credenciais"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 227,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 180,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-2", style: { padding: 20, display: "grid", gap: 12, marginTop: 16 }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Conexão" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 240,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Testa as credenciais salvas contra o iFood (autenticação OAuth2). Só funciona depois que você tiver credenciais reais de teste/sandbox ou produção." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 243,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 239,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 12 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": statusDot }, children: statusLabel }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 249,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              loading: testMutation.isPending,
              disabled: !settingsQuery.data?.hasCredentials,
              onClick: () => testMutation.mutate(),
              children: "Testar conexão"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 252,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 248,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 238,
        columnNumber: 9
      }, this),
      settingsQuery.data?.lastConnectionTestAt && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.82rem" }, children: [
        "Último teste: ",
        new Date(settingsQuery.data.lastConnectionTestAt).toLocaleString("pt-BR")
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 263,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 237,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 14, marginTop: 16 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Lojas (merchants)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 271,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: 'Cada filial precisa do seu MerchantId do iFood — encontrado na tela "Permissões" do seu app no portal (ou em "Testes" → dados da loja de teste). O MerchantUuid é usado só em algumas chamadas específicas; pode deixar em branco se não tiver ainda.' }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 274,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 270,
        columnNumber: 9
      }, this),
      mappingsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: mappingsQuery.error, what: "as lojas" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 281,
        columnNumber: 35
      }, this),
      !mappingsQuery.isLoading && (mappingsQuery.data?.length ?? 0) === 0 && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.88rem" }, children: "Nenhuma filial ativa cadastrada ainda." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 283,
        columnNumber: 9
      }, this),
      (mappingsQuery.data ?? []).map(
        (mapping) => /* @__PURE__ */ jsxDEV(
          MerchantMappingRow,
          {
            mapping,
            onSaved: () => void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "merchants"] })
          },
          mapping.branchId,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 289,
            columnNumber: 9
          },
          this
        )
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 269,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 12, marginTop: 16 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16, alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Pedidos" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 300,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Recebimento automático (a cada 30s), confirmação dentro do prazo de 8 minutos, e avanço manual de status (iniciar preparo, pronto, cancelar) pela tela de pedidos." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 303,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 299,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/pedidos", children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "Ver pedidos iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 309,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 308,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 298,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 297,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 12, marginTop: 16 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16, alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Logística (frota própria)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 317,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Entregue com a equipe da própria casa pedidos que vieram do iFood — atribua o entregador e avise cada passo (saiu, chegou, despachou, entregou)." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 320,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 316,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/logistica", children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "Ver logística" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 326,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 325,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 315,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 314,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 12, marginTop: 16 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16, alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Entregas iFood (Shipping)" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 334,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Peça um entregador do iFood pra um pedido de outro canal (telefone, WhatsApp, balcão) — cotação de preço/prazo, acompanhamento e cancelamento. Tudo sob demanda." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 337,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 333,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/shipping", children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "Ver entregas iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 343,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 342,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 332,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 331,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 12, marginTop: 16 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16, alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Cardápio" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 351,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Categorias e produtos ativos são enviados sozinhos pro iFood sempre que você cria, edita ou desativa algo em Produtos. Use o botão ao lado pra reenviar tudo de uma vez (primeira carga, ou depois de uma falha)." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 354,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 350,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8 }, children: [
        /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/catalogo", children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "Gerenciar catálogo" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 362,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 361,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", loading: syncCatalogMutation.isPending, onClick: () => syncCatalogMutation.mutate(), children: "Sincronizar agora" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 364,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 360,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 349,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 348,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 14, marginTop: 16 }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16, alignItems: "center" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Financeiro" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 374,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Trilha de auditoria dos lançamentos e repasses do iFood (últimos 30 dias) — não substitui o fechamento de caixa do SyncBar, é só pra conferir o que o iFood calculou. Sincroniza sozinho 1x por dia." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 377,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 373,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/financeiro/relatorios", children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "Relatórios completos" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 385,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 384,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              loading: syncFinancialMutation.isPending,
              disabled: !firstMappedBranch,
              onClick: () => syncFinancialMutation.mutate(),
              children: "Sincronizar agora"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 387,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 383,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 372,
        columnNumber: 9
      }, this),
      !firstMappedBranch && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.88rem" }, children: "Configure o Merchant ID de ao menos uma loja acima para ver o financeiro." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 399,
        columnNumber: 9
      }, this),
      financialSummaryQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: financialSummaryQuery.error, what: "o financeiro do iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 405,
        columnNumber: 9
      }, this),
      financialSummaryQuery.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 20 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
            /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.82rem" }, children: "Lançamentos c/ impacto no repasse" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 412,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.15rem" }, children: financialSummaryQuery.data.totalFinancialEventsWithTransferImpact.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 413,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 411,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
            /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.82rem" }, children: "Repasses (Settlement)" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 418,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.15rem" }, children: financialSummaryQuery.data.totalSettlements.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 419,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 417,
            columnNumber: 15
          }, this),
          financialSummaryQuery.data.hasDiscrepancy && /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": "var(--danger)" }, children: [
            "Revisar conciliação — diferença de",
            " ",
            financialSummaryQuery.data.discrepancyAmount.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 424,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 410,
          columnNumber: 13
        }, this),
        financialSummaryQuery.data.settlements.length > 0 && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.88rem", fontWeight: 600 }, children: "Repasses" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 433,
            columnNumber: 17
          }, this),
          financialSummaryQuery.data.settlements.map(
            (s) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "ui-row ui-row-wrap",
                style: { justifyContent: "space-between", gap: 10, borderTop: "1px solid var(--line-soft)", paddingTop: 8, fontSize: "0.88rem" },
                children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    s.type,
                    s.product ? ` — ${s.product}` : ""
                  ] }, void 0, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
                    lineNumber: 440,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: s.status }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
                    lineNumber: 444,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: s.paymentDate ? new Date(s.paymentDate).toLocaleDateString("pt-BR") : "sem data prevista" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
                    lineNumber: 445,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("strong", { children: s.amount.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
                    lineNumber: 446,
                    columnNumber: 21
                  }, this)
                ]
              },
              s.id,
              true,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
                lineNumber: 435,
                columnNumber: 13
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 432,
          columnNumber: 11
        }, this),
        financialSummaryQuery.data.events.length === 0 && financialSummaryQuery.data.settlements.length === 0 && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.88rem" }, children: "Nenhum lançamento financeiro nos últimos 30 dias ainda." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 453,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 409,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 371,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 12, marginTop: 16 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16, alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Avaliações" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 464,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Veja e responda às avaliações dos clientes direto no iFood (nota média, comentários, respostas). Sem sincronização — sempre lido/escrito ao vivo." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 467,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 463,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/avaliacoes", children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "Ver avaliações" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 473,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 472,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 462,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 461,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 12, marginTop: 16 }, children: /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 16, alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, maxWidth: 520 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Indicadores" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 481,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "GMV, taxas e outras métricas de pedidos por período, agrupadas por canal de venda." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 484,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 480,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood/indicadores", children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "Ver indicadores" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 489,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 488,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 479,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 478,
      columnNumber: 7
    }, this),
    firstMappedBranch && /* @__PURE__ */ jsxDEV(MerchantOperationsSection, { branchId: firstMappedBranch.branchId, companyId }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 494,
      columnNumber: 29
    }, this),
    !firstMappedBranch && /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 8, marginTop: 16 }, children: [
      /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.1rem" }, children: "Operação da loja" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 497,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.88rem" }, children: "Configure o Merchant ID de ao menos uma loja acima para ver status, interrupções, horários e tempo de preparo." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 500,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 496,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 8, marginTop: 16 }, children: [
      /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.1rem" }, children: "O que já está pronto x o que falta" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 508,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { style: { margin: 0, paddingLeft: 18, color: "var(--ink-dim)", fontSize: "0.9rem", display: "grid", gap: 6 }, children: [
        /* @__PURE__ */ jsxDEV("li", { children: [
          /* @__PURE__ */ jsxDEV("strong", { style: { color: "var(--ink)" }, children: "Pronto:" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 513,
            columnNumber: 13
          }, this),
          " guardar as credenciais do app com segurança (segredo criptografado), testar a autenticação OAuth2 real com o iFood, mapear cada loja ao MerchantId correspondente, sincronizar pedidos (receber, confirmar dentro do SLA, iniciar preparo/pronto/cancelar), sincronizar cardápio (categorias, produtos, preço, pausar/reativar, estoque de produtos com controle de estoque), trilha financeira (lançamentos, repasses e os 13 relatórios completos do iFood, alerta de discrepância), operação da loja (status em tempo real, pausar/reabrir, horários de funcionamento, tempo de preparo customizado), logística por frota própria e entrega Sob Demanda (Shipping) — inclusive pra pedidos que vieram de outros canais —, avaliações (ver/responder) e indicadores de pedidos."
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 512,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          /* @__PURE__ */ jsxDEV("strong", { style: { color: "var(--ink)" }, children: "Pendente:" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 525,
            columnNumber: 13
          }, this),
          " complementos/pizzas/combos avançados no cardápio (multisetup, migração v1↔v2, imagem em lote), disputas pós-entrega (Handshake) além do aceitar/rejeitar básico, rastreamento em tela do pedido do módulo Order (fora da tela de Shipping/Logística), avaliações no formato v2, e pedidos agendados."
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 524,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 511,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 507,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
    lineNumber: 168,
    columnNumber: 5
  }, this);
}
_s(IFoodIntegrationPage, "44S2sRgy/iSaSC6TSng2dtqJlIc=", false, function() {
  return [useQueryClient, useToast, useAuthStore, useQuery, useMutation, useMutation, useQuery, useMutation, useQuery, useMutation];
});
_c = IFoodIntegrationPage;
function MerchantMappingRow({
  mapping,
  onSaved
}) {
  _s2();
  const toast = useToast();
  const [merchantId, setMerchantId] = useState(mapping.merchantId ?? "");
  const [merchantUuid, setMerchantUuid] = useState(mapping.merchantUuid ?? "");
  const mutation = useMutation({
    mutationFn: () => setIFoodMerchantMapping({
      branchId: mapping.branchId,
      merchantId: merchantId.trim(),
      merchantUuid: merchantUuid.trim()
    }),
    onSuccess: () => {
      toast.success(`Loja "${mapping.branchName}" atualizada.`);
      onSaved();
    },
    onError: () => toast.error("Não foi possível salvar essa loja.")
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { alignItems: "end", gap: 10, borderTop: "1px solid var(--line-soft)", paddingTop: 12 }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { minWidth: 140, fontWeight: 600 }, children: mapping.branchName }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 564,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 180 }, children: /* @__PURE__ */ jsxDEV(
      TextField,
      {
        label: "Merchant ID",
        value: merchantId,
        onChange: (e) => setMerchantId(e.target.value),
        placeholder: "ID da loja no iFood"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 566,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 565,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 180 }, children: /* @__PURE__ */ jsxDEV(
      TextField,
      {
        label: "Merchant UUID (opcional)",
        value: merchantUuid,
        onChange: (e) => setMerchantUuid(e.target.value),
        placeholder: "opcional"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 574,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 573,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", loading: mutation.isPending, onClick: () => mutation.mutate(), children: "Salvar" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 581,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
    lineNumber: 563,
    columnNumber: 5
  }, this);
}
_s2(MerchantMappingRow, "5AieNr1Lopm4KZC4EFCeUzPstko=", false, function() {
  return [useToast, useMutation];
});
_c2 = MerchantMappingRow;
const WEEKDAY_LABELS = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
function MerchantOperationsSection({ branchId, companyId }) {
  _s3();
  const queryClient = useQueryClient();
  const toast = useToast();
  const statusQuery = useQuery({
    queryKey: ["integrations", "ifood", "merchant", "status", branchId],
    queryFn: () => getIFoodMerchantStatus(branchId),
    // Fase 20 (2026-08-24): evita rajada de retries reais contra o iFood quando o status
    // falha (ex.: 403 de permissão, ver Fase 19) — mesmo ajuste em IFoodDashboardPage.tsx.
    retry: false
  });
  const [showMerchantsList, setShowMerchantsList] = useState(false);
  const merchantsListQuery = useQuery({
    queryKey: ["integrations", "ifood", "merchant", "list", companyId],
    queryFn: () => getIFoodMerchantsList(companyId),
    enabled: showMerchantsList
  });
  const [showMerchantDetails, setShowMerchantDetails] = useState(false);
  const merchantDetailsQuery = useQuery({
    queryKey: ["integrations", "ifood", "merchant", "details", branchId],
    queryFn: () => getIFoodMerchantDetails(branchId),
    enabled: showMerchantDetails
  });
  const [operationQuery, setOperationQuery] = useState("DELIVERY");
  const [operationLookup, setOperationLookup] = useState(null);
  const statusByOperationQuery = useQuery({
    queryKey: ["integrations", "ifood", "merchant", "status-by-operation", branchId, operationLookup],
    queryFn: () => getIFoodMerchantStatusByOperation(branchId, operationLookup ?? ""),
    enabled: !!operationLookup,
    retry: false
  });
  const interruptionsQuery = useQuery({
    queryKey: ["integrations", "ifood", "merchant", "interruptions", branchId],
    queryFn: () => getIFoodInterruptions(branchId)
  });
  const openingHoursQuery = useQuery({
    queryKey: ["integrations", "ifood", "merchant", "opening-hours", branchId],
    queryFn: () => getIFoodOpeningHours(branchId)
  });
  const [shifts, setShifts] = useState([]);
  const [prepTime, setPrepTime] = useState("");
  const [initializedBranchId, setInitializedBranchId] = useState(null);
  useEffect(() => {
    if (openingHoursQuery.data && initializedBranchId !== branchId) {
      setShifts(openingHoursQuery.data.shifts);
      setPrepTime(openingHoursQuery.data.preparationTimeMinutes?.toString() ?? "");
      setInitializedBranchId(branchId);
    }
  }, [openingHoursQuery.data, branchId, initializedBranchId]);
  const [interruptionDescription, setInterruptionDescription] = useState("");
  const [interruptionStart, setInterruptionStart] = useState("");
  const [interruptionEnd, setInterruptionEnd] = useState("");
  const createInterruptionMutation = useMutation({
    mutationFn: () => createIFoodInterruption({
      branchId,
      description: interruptionDescription.trim(),
      start: new Date(interruptionStart).toISOString(),
      end: new Date(interruptionEnd).toISOString()
    }),
    onSuccess: () => {
      toast.success("Loja pausada no iFood.");
      setInterruptionDescription("");
      setInterruptionStart("");
      setInterruptionEnd("");
      void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "merchant", "interruptions", branchId] });
    },
    onError: () => toast.error("Não foi possível pausar a loja.")
  });
  const deleteInterruptionMutation = useMutation({
    mutationFn: (interruptionId) => deleteIFoodInterruption(branchId, interruptionId),
    onSuccess: () => {
      toast.success("Loja reaberta.");
      void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "merchant", "interruptions", branchId] });
    },
    onError: () => toast.error("Não foi possível reabrir a loja.")
  });
  const saveOpeningHoursMutation = useMutation({
    mutationFn: () => saveIFoodOpeningHours(branchId, shifts),
    onSuccess: () => {
      toast.success("Horários de funcionamento salvos e enviados ao iFood.");
      void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "merchant", "opening-hours", branchId] });
    },
    onError: () => toast.error("Não foi possível salvar os horários — confira os turnos e tente de novo.")
  });
  const setPrepTimeMutation = useMutation({
    mutationFn: () => setIFoodPreparationTime(branchId, prepTime.trim() === "" ? null : Number(prepTime)),
    onSuccess: () => {
      toast.success("Tempo de preparo atualizado.");
      void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "merchant", "opening-hours", branchId] });
    },
    onError: () => toast.error("Não foi possível atualizar o tempo de preparo.")
  });
  const addShift = () => setShifts((prev) => [...prev, { dayOfWeek: 1, start: "08:00", durationMinutes: 600 }]);
  const removeShift = (index) => setShifts((prev) => prev.filter((_, i) => i !== index));
  const updateShift = (index, patch) => setShifts((prev) => prev.map((s, i) => i === index ? { ...s, ...patch } : s));
  const hasIFoodCustomerId = openingHoursQuery.data?.hasIFoodCustomerId ?? false;
  return /* @__PURE__ */ jsxDEV("section", { className: "ticket rise rise-3", style: { padding: 20, display: "grid", gap: 20, marginTop: 16 }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
      /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Operação da loja" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 713,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.92rem" }, children: "Status em tempo real, pausas/reaberturas, horários de funcionamento e tempo de preparo customizado — tudo direto pelo módulo Merchant do iFood." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 716,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 712,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8, borderTop: "1px solid var(--line-soft)", paddingTop: 14 }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", alignItems: "center", gap: 12 }, children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: "Status" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 725,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", loading: statusQuery.isFetching, onClick: () => void statusQuery.refetch(), children: "Atualizar status" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 726,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 724,
        columnNumber: 9
      }, this),
      statusQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: statusQuery.error, what: "o status da loja" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 730,
        columnNumber: 33
      }, this),
      statusQuery.data && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 6 }, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "chip", children: statusQuery.data.operationState ?? "Desconhecido" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 733,
          columnNumber: 13
        }, this),
        statusQuery.data.validations.map(
          (v) => /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
            v.id,
            " (",
            v.state,
            ")",
            v.message ? ` — ${v.message}` : ""
          ] }, v.id, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 735,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 732,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 723,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10, borderTop: "1px solid var(--line-soft)", paddingTop: 14 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: "Lojas do client_id" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 745,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "ghost",
          size: "sm",
          loading: showMerchantsList && merchantsListQuery.isFetching,
          onClick: () => showMerchantsList ? void merchantsListQuery.refetch() : setShowMerchantsList(true),
          children: "Listar lojas no iFood"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 746,
          columnNumber: 9
        },
        this
      ),
      showMerchantsList && merchantsListQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: merchantsListQuery.error, what: "a lista de lojas" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 754,
        columnNumber: 61
      }, this),
      showMerchantsList && (merchantsListQuery.data ?? []).length > 0 && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: merchantsListQuery.data.map(
        (m) => /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: [
          m.name ?? m.id,
          " ",
          m.corporateName ? `— ${m.corporateName}` : "",
          " ",
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: [
            "(",
            m.id,
            ")"
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 759,
            columnNumber: 82
          }, this)
        ] }, m.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 758,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 756,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 744,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10, borderTop: "1px solid var(--line-soft)", paddingTop: 14 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: "Detalhes da loja" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 767,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "ghost",
          size: "sm",
          loading: showMerchantDetails && merchantDetailsQuery.isFetching,
          onClick: () => showMerchantDetails ? void merchantDetailsQuery.refetch() : setShowMerchantDetails(true),
          children: "Ver detalhes no iFood"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 768,
          columnNumber: 9
        },
        this
      ),
      showMerchantDetails && merchantDetailsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: merchantDetailsQuery.error, what: "os detalhes da loja" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 776,
        columnNumber: 65
      }, this),
      showMerchantDetails && merchantDetailsQuery.data && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, fontSize: "0.85rem", color: "var(--ink-dim)" }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Nome: ",
          merchantDetailsQuery.data.name ?? "—"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 779,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Razão social: ",
          merchantDetailsQuery.data.corporateName ?? "—"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 780,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Tipo: ",
          merchantDetailsQuery.data.type ?? "—"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 781,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Status: ",
          merchantDetailsQuery.data.status ?? "—"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 782,
          columnNumber: 13
        }, this),
        merchantDetailsQuery.data.address && /* @__PURE__ */ jsxDEV("span", { children: [
          "Endereço: ",
          merchantDetailsQuery.data.address.street,
          ", ",
          merchantDetailsQuery.data.address.number,
          " —",
          " ",
          merchantDetailsQuery.data.address.city,
          "/",
          merchantDetailsQuery.data.address.state
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 784,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 778,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 766,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10, borderTop: "1px solid var(--line-soft)", paddingTop: 14 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: "Status por operação" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 794,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "end" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Operação",
            value: operationQuery,
            onChange: (e) => setOperationQuery(e.target.value),
            placeholder: "ex.: DELIVERY, TAKEOUT"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 797,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 796,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            size: "sm",
            disabled: !operationQuery.trim(),
            loading: statusByOperationQuery.isFetching,
            onClick: () => setOperationLookup(operationQuery.trim()),
            children: "Consultar"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 804,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 795,
        columnNumber: 9
      }, this),
      statusByOperationQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: statusByOperationQuery.error, what: "o status da operação" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 814,
        columnNumber: 44
      }, this),
      statusByOperationQuery.data && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, fontSize: "0.85rem", color: "var(--ink-dim)" }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          statusByOperationQuery.data.operation ?? operationLookup,
          " — ",
          statusByOperationQuery.data.available ? "Disponível" : "Indisponível",
          statusByOperationQuery.data.state ? ` (${statusByOperationQuery.data.state})` : ""
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 817,
          columnNumber: 13
        }, this),
        statusByOperationQuery.data.validations.map(
          (v) => /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: [
            v.id,
            " (",
            v.state,
            ")",
            v.message ? ` — ${v.message}` : ""
          ] }, v.id, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 822,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 816,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 793,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10, borderTop: "1px solid var(--line-soft)", paddingTop: 14 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: "Interrupções (pausar/reabrir)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 832,
        columnNumber: 9
      }, this),
      interruptionsQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: interruptionsQuery.error, what: "as interrupções" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 833,
        columnNumber: 40
      }, this),
      (interruptionsQuery.data ?? []).length === 0 && !interruptionsQuery.isLoading && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.86rem" }, children: "Nenhuma pausa ativa." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 835,
        columnNumber: 9
      }, this),
      (interruptionsQuery.data ?? []).map(
        (i) => /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { justifyContent: "space-between", gap: 10, fontSize: "0.88rem" }, children: [
          /* @__PURE__ */ jsxDEV("span", { children: [
            i.description ?? "(sem motivo)",
            " — ",
            new Date(i.start).toLocaleString("pt-BR"),
            " até",
            " ",
            new Date(i.end).toLocaleString("pt-BR")
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 839,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              loading: deleteInterruptionMutation.isPending,
              onClick: () => deleteInterruptionMutation.mutate(i.id),
              children: "Reabrir"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 843,
              columnNumber: 13
            },
            this
          )
        ] }, i.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 838,
          columnNumber: 9
        }, this)
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "end" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 2, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Motivo",
            value: interruptionDescription,
            onChange: (e) => setInterruptionDescription(e.target.value),
            placeholder: "ex.: falta de insumo"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 856,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 855,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Início",
            type: "datetime-local",
            value: interruptionStart,
            onChange: (e) => setInterruptionStart(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 864,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 863,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Fim",
            type: "datetime-local",
            value: interruptionEnd,
            onChange: (e) => setInterruptionEnd(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 872,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 871,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            size: "sm",
            loading: createInterruptionMutation.isPending,
            disabled: !interruptionDescription.trim() || !interruptionStart || !interruptionEnd,
            onClick: () => createInterruptionMutation.mutate(),
            children: "Pausar loja"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 879,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 854,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 831,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10, borderTop: "1px solid var(--line-soft)", paddingTop: 14 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: "Horários de funcionamento" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 893,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "Ao salvar, a lista inteira de turnos é reenviada ao iFood (substitui tudo, não é incremental)." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 894,
        columnNumber: 9
      }, this),
      shifts.map(
        (shift, index) => /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "end" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(
            SelectField,
            {
              label: "Dia da semana",
              value: shift.dayOfWeek,
              onChange: (e) => updateShift(index, { dayOfWeek: Number(e.target.value) }),
              children: WEEKDAY_LABELS.map(
                (label, day) => /* @__PURE__ */ jsxDEV("option", { value: day, children: label }, day, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
                  lineNumber: 907,
                  columnNumber: 15
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 901,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 900,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { minWidth: 120 }, children: /* @__PURE__ */ jsxDEV(
            TextField,
            {
              label: "Início",
              type: "time",
              value: shift.start,
              onChange: (e) => updateShift(index, { start: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 914,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 913,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { minWidth: 120 }, children: /* @__PURE__ */ jsxDEV(
            TextField,
            {
              label: "Duração (min)",
              type: "number",
              value: shift.durationMinutes.toString(),
              onChange: (e) => updateShift(index, { durationMinutes: Number(e.target.value) })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
              lineNumber: 922,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 921,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => removeShift(index), children: "Remover" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 929,
            columnNumber: 13
          }, this)
        ] }, index, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 899,
          columnNumber: 9
        }, this)
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row", style: { gap: 10 }, children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: addShift, children: "+ Adicionar turno" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 935,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "primary",
            size: "sm",
            loading: saveOpeningHoursMutation.isPending,
            onClick: () => saveOpeningHoursMutation.mutate(),
            children: "Salvar horários"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 938,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 934,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 892,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10, borderTop: "1px solid var(--line-soft)", paddingTop: 14 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: "Tempo de preparo" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 951,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--warn, #d97706)", fontSize: "0.82rem" }, children: "⚠ Este endpoint não consta na documentação oficial auditada em 2026-08-20/21 — trate como não confirmado e valide numa loja de teste antes de depender dele." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 952,
        columnNumber: 9
      }, this),
      !hasIFoodCustomerId && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: 'Configure o "iFood Customer ID" na seção de credenciais acima para habilitar este campo.' }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 957,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 10, alignItems: "end" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { minWidth: 160 }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Minutos (vazio = automático do iFood)",
            type: "number",
            value: prepTime,
            onChange: (e) => setPrepTime(e.target.value),
            disabled: !hasIFoodCustomerId,
            placeholder: "ex.: 30"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 964,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
          lineNumber: 963,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "primary",
            size: "sm",
            loading: setPrepTimeMutation.isPending,
            disabled: !hasIFoodCustomerId,
            onClick: () => setPrepTimeMutation.mutate(),
            children: "Salvar"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
            lineNumber: 973,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
        lineNumber: 962,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
      lineNumber: 950,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx",
    lineNumber: 711,
    columnNumber: 5
  }, this);
}
_s3(MerchantOperationsSection, "n54x7hOl9pJPKBK5DEttdAHgyew=", false, function() {
  return [useQueryClient, useToast, useQuery, useQuery, useQuery, useQuery, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation];
});
_c3 = MerchantOperationsSection;
var _c, _c2, _c3;
$RefreshReg$(_c, "IFoodIntegrationPage");
$RefreshReg$(_c2, "MerchantMappingRow");
$RefreshReg$(_c3, "MerchantOperationsSection");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodIntegrationPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0pRLFNBK09FLFVBL09GOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRKUixTQUFTQSxXQUFXQyxnQkFBb0M7QUFDeEQsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUVLO0FBQ1AsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFPQyxhQUFhQyxpQkFBaUI7QUFDOUMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGtCQUFrQjtBQUszQixNQUFNQyx5QkFBc0c7QUFBQSxFQUMxR0MsV0FBVyxFQUFFQyxPQUFPLGFBQWFDLEtBQUssWUFBWTtBQUFBLEVBQ2xEQyxRQUFRLEVBQUVGLE9BQU8sMEJBQTBCQyxLQUFLLGdCQUFnQjtBQUFBLEVBQ2hFRSxVQUFVLEVBQUVILE9BQU8saUJBQWlCQyxLQUFLLG1CQUFtQjtBQUM5RDtBQUVBLFNBQVNHLHVCQUF1QkMsVUFBMkU7QUFDekcsTUFBSUEsYUFBYSxLQUFNLFFBQU87QUFDOUIsTUFBSUEsYUFBYSxNQUFPLFFBQU87QUFDL0IsU0FBTztBQUNUO0FBRU8sZ0JBQVNDLHVCQUF1QjtBQUFBQyxLQUFBO0FBQ3JDLFFBQU1DLGNBQWNyQyxlQUFlO0FBQ25DLFFBQU1zQyxRQUFRbEIsU0FBUztBQUN2QixRQUFNLEVBQUVtQixXQUFXQyxhQUFhLElBQUlyQixhQUFhO0FBQ2pELFFBQU1vQixZQUFZQyxnQkFBZ0I7QUFFbEMsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUk5QyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDK0MsY0FBY0MsZUFBZSxJQUFJaEQsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ2lELFNBQVNDLFVBQVUsSUFBSWxELFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNtRCxpQkFBaUJDLGtCQUFrQixJQUFJcEQsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ3FELHNCQUFzQkMsdUJBQXVCLElBQUl0RCxTQUF3QixJQUFJO0FBRXBGLFFBQU11RCxnQkFBZ0JwRCxTQUFTO0FBQUEsSUFDN0JxRCxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsWUFBWWIsU0FBUztBQUFBLElBQ3pEYyxTQUFTQSxNQUFNMUMsaUJBQWlCNEIsU0FBUztBQUFBLEVBQzNDLENBQUM7QUFLRDVDLFlBQVUsTUFBTTtBQUNkLFFBQUl3RCxjQUFjRyxRQUFRTCx5QkFBeUJWLFdBQVc7QUFDNURHLGtCQUFZUyxjQUFjRyxLQUFLYixZQUFZLEVBQUU7QUFDN0NLLGlCQUFXSyxjQUFjRyxLQUFLVCxPQUFPO0FBQ3JDRyx5QkFBbUJHLGNBQWNHLEtBQUtQLG1CQUFtQixFQUFFO0FBQzNERyw4QkFBd0JYLFNBQVM7QUFBQSxJQUNuQztBQUFBLEVBQ0YsR0FBRyxDQUFDWSxjQUFjRyxNQUFNZixXQUFXVSxvQkFBb0IsQ0FBQztBQUV4RCxRQUFNTSxlQUFlekQsWUFBWTtBQUFBLElBQy9CMEQsWUFBWUEsTUFDVjNDLGtCQUFrQjtBQUFBLE1BQ2hCMEI7QUFBQUEsTUFDQUUsVUFBVUEsU0FBU2dCLEtBQUs7QUFBQSxNQUN4QmQsY0FBY0EsYUFBYWMsS0FBSztBQUFBLE1BQ2hDWjtBQUFBQSxNQUNBRSxpQkFBaUJBLGdCQUFnQlUsS0FBSztBQUFBLElBQ3hDLENBQUM7QUFBQSxJQUNIQyxXQUFXQSxNQUFNO0FBQ2ZwQixZQUFNcUIsUUFBUSw4QkFBOEI7QUFDNUNmLHNCQUFnQixFQUFFO0FBQ2xCLFdBQUtQLFlBQVl1QixrQkFBa0IsRUFBRVIsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFVBQVUsRUFBRSxDQUFDO0FBQUEsSUFDeEY7QUFBQSxJQUNBUyxTQUFTQSxNQUFNdkIsTUFBTXdCLE1BQU0seUNBQXlDO0FBQUEsRUFDdEUsQ0FBQztBQUVELFFBQU1DLGVBQWVqRSxZQUFZO0FBQUEsSUFDL0IwRCxZQUFZQSxNQUFNdEMsb0JBQW9CcUIsU0FBUztBQUFBLElBQy9DbUIsV0FBV0EsQ0FBQ00sV0FBVztBQUNyQixVQUFJQSxPQUFPTCxRQUFTckIsT0FBTXFCLFFBQVEsaUNBQWlDO0FBQUE7QUFDOURyQixjQUFNd0IsTUFBTUUsT0FBT0MsZ0JBQWdCLDZDQUE2QztBQUNyRixXQUFLNUIsWUFBWXVCLGtCQUFrQixFQUFFUixVQUFVLENBQUMsZ0JBQWdCLFNBQVMsVUFBVSxFQUFFLENBQUM7QUFBQSxJQUN4RjtBQUFBLElBQ0FTLFNBQVNBLE1BQU12QixNQUFNd0IsTUFBTSxvQ0FBb0M7QUFBQSxFQUNqRSxDQUFDO0FBRUQsUUFBTUksZ0JBQWdCbkUsU0FBUztBQUFBLElBQzdCcUQsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGFBQWFiLFNBQVM7QUFBQSxJQUMxRGMsU0FBU0EsTUFBTS9DLHlCQUF5QmlDLFNBQVM7QUFBQSxFQUNuRCxDQUFDO0FBRUQsUUFBTTRCLHNCQUFzQnJFLFlBQVk7QUFBQSxJQUN0QzBELFlBQVlBLE1BQU14QyxpQkFBaUJ1QixTQUFTO0FBQUEsSUFDNUNtQixXQUFXQSxDQUFDVSxZQUFZO0FBQ3RCLFVBQUlBLFFBQVFDLFNBQVM7QUFDbkIvQixjQUFNd0IsTUFBTSw4RkFBOEY7QUFDMUc7QUFBQSxNQUNGO0FBQ0EsWUFBTVEsY0FBY0YsUUFBUUcsU0FBUyxJQUFJLEtBQUtILFFBQVFHLE1BQU0sUUFBUUgsUUFBUUcsV0FBVyxJQUFJLEtBQUssR0FBRyxNQUFNO0FBQ3pHakMsWUFBTXFCO0FBQUFBLFFBQ0osMEJBQTBCUyxRQUFRSSxjQUFjLGtCQUFrQkosUUFBUUssY0FBYyxXQUFXSCxXQUFXO0FBQUEsTUFDaEg7QUFBQSxJQUNGO0FBQUEsSUFDQVQsU0FBU0EsTUFBTXZCLE1BQU13QixNQUFNLHNEQUFzRDtBQUFBLEVBQ25GLENBQUM7QUFLRCxRQUFNWSxxQkFBcUJSLGNBQWNaLFFBQVEsSUFBSXFCLEtBQUssQ0FBQ0MsTUFBTSxDQUFDLENBQUNBLEVBQUVDLFVBQVU7QUFFL0UsUUFBTUMsd0JBQXdCL0UsU0FBUztBQUFBLElBQ3JDcUQsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGFBQWFzQixtQkFBbUJLLFFBQVE7QUFBQSxJQUM1RTFCLFNBQVNBLE1BQU1sRCx5QkFBeUJ1RSxrQkFBbUJLLFFBQVE7QUFBQSxJQUNuRWxDLFNBQVMsQ0FBQyxDQUFDNkI7QUFBQUEsRUFDYixDQUFDO0FBRUQsUUFBTU0sd0JBQXdCbEYsWUFBWTtBQUFBLElBQ3hDMEQsWUFBWUEsTUFBTXZDLG1CQUFtQnNCLFNBQVM7QUFBQSxJQUM5Q21CLFdBQVdBLE1BQU07QUFDZnBCLFlBQU1xQixRQUFRLDJFQUEyRTtBQUN6RixXQUFLdEIsWUFBWXVCLGtCQUFrQixFQUFFUixVQUFVLENBQUMsZ0JBQWdCLFNBQVMsV0FBVyxFQUFFLENBQUM7QUFBQSxJQUN6RjtBQUFBLElBQ0FTLFNBQVNBLE1BQU12QixNQUFNd0IsTUFBTSx1REFBdUQ7QUFBQSxFQUNwRixDQUFDO0FBRUQsUUFBTTVCLFdBQVdpQixjQUFjRyxNQUFNMkI7QUFDckMsUUFBTUMsbUJBQW1CdkQsdUJBQXVCTSx1QkFBdUJDLFFBQVEsQ0FBQztBQUNoRixRQUFNaUQsY0FBY0QsaUJBQWlCckQ7QUFDckMsUUFBTXVELFlBQVlGLGlCQUFpQnBEO0FBRW5DLFNBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUV1RCxTQUFTLElBQUlDLFVBQVUsS0FBS0MsUUFBUSxTQUFTLEdBQzFEO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFQyxjQUFjLEdBQUcsR0FDOUM7QUFBQSw2QkFBQyxRQUFHLFdBQVUsV0FBVSxPQUFPLEVBQUVDLFVBQVUsU0FBUyxHQUFHLGdDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLG9CQUFvQkQsVUFBVSxTQUFTLEdBQUcsbUdBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQ3RDLGNBQWN3QyxXQUFXLHVCQUFDLGNBQVcsT0FBT3hDLGNBQWNXLE9BQU8sTUFBSyw4QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RTtBQUFBLElBRWpHLHVCQUFDLGFBQVEsV0FBVSxzQkFBcUIsT0FBTyxFQUFFdUIsU0FBUyxJQUFJTyxTQUFTLFFBQVFDLEtBQUssR0FBRyxHQUNyRjtBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFRCxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLCtCQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUosVUFBVSxTQUFTLEdBQUcseUNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBRywrUEFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixPQUFPaEQ7QUFBQUEsVUFDUCxVQUFVLENBQUNxRCxNQUFNcEQsWUFBWW9ELEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxVQUMzQyxhQUFZO0FBQUE7QUFBQSxRQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlpQztBQUFBLE1BR2pDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixNQUFLO0FBQUEsVUFDTCxPQUFPckQ7QUFBQUEsVUFDUCxVQUFVLENBQUNtRCxNQUFNbEQsZ0JBQWdCa0QsRUFBRUMsT0FBT0MsS0FBSztBQUFBLFVBQy9DLGFBQWE3QyxjQUFjRyxNQUFNMkMsaUJBQWlCLG1EQUFtRDtBQUFBLFVBQ3JHLE1BQUs7QUFBQTtBQUFBLFFBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTWdGO0FBQUEsTUFHaEY7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLE9BQU9sRDtBQUFBQSxVQUNQLFVBQVUsQ0FBQytDLE1BQU05QyxtQkFBbUI4QyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsVUFDbEQsYUFBWTtBQUFBLFVBQ1osTUFBSztBQUFBO0FBQUEsUUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLeUo7QUFBQSxNQUd6Six1QkFBQyxTQUFNLE9BQU0sb0JBQ1YsZ0JBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNuRDtBQUFBQSxVQUNULFVBQVVDO0FBQUFBLFVBQ1YsT0FBTTtBQUFBLFVBQ04sVUFBVVMsYUFBYTJDO0FBQUFBO0FBQUFBLFFBSnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUltQyxLQU52QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixTQUFTM0MsYUFBYTJDO0FBQUFBLFVBQ3RCLFVBQVVyRCxXQUFXSixTQUFTZ0IsS0FBSyxNQUFNO0FBQUEsVUFDekMsU0FBUyxNQUFNRixhQUFhNEMsT0FBTztBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSnZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0F0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVEQTtBQUFBLElBRUEsdUJBQUMsYUFBUSxXQUFVLHNCQUFxQixPQUFPLEVBQUVkLFNBQVMsSUFBSU8sU0FBUyxRQUFRQyxLQUFLLElBQUlPLFdBQVcsR0FBRyxHQUNwRztBQUFBLDZCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFQyxnQkFBZ0IsaUJBQWlCUixLQUFLLEdBQUcsR0FDcEY7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRUQsU0FBUyxRQUFRQyxLQUFLLEdBQUdQLFVBQVUsSUFBSSxHQUNuRDtBQUFBLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUcsVUFBVSxTQUFTLEdBQUcsdUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsbUtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFSSxLQUFLLEdBQUcsR0FDdkM7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsUUFBTyxPQUFPLEVBQUUsU0FBU1QsVUFBVSxHQUNoREQseUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVE7QUFBQSxjQUNSLFNBQVNwQixhQUFhbUM7QUFBQUEsY0FDdEIsVUFBVSxDQUFDL0MsY0FBY0csTUFBTTJDO0FBQUFBLGNBQy9CLFNBQVMsTUFBTWxDLGFBQWFvQyxPQUFPO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxNQUNDaEQsY0FBY0csTUFBTWdELHdCQUNuQix1QkFBQyxVQUFLLE9BQU8sRUFBRVosT0FBTyxvQkFBb0JELFVBQVUsVUFBVSxHQUFHO0FBQUE7QUFBQSxRQUNoRCxJQUFJYyxLQUFLcEQsY0FBY0csS0FBS2dELG9CQUFvQixFQUFFRSxlQUFlLE9BQU87QUFBQSxXQUR6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsc0JBQXFCLE9BQU8sRUFBRW5CLFNBQVMsSUFBSU8sU0FBUyxRQUFRQyxLQUFLLElBQUlPLFdBQVcsR0FBRyxHQUNwRztBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFUixTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLCtCQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUosVUFBVSxTQUFTLEdBQUcsaUNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBRyxxUUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVDdkIsY0FBY3lCLFdBQVcsdUJBQUMsY0FBVyxPQUFPekIsY0FBY0osT0FBTyxNQUFLLGNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxNQUNoRixDQUFDSSxjQUFjdUMsY0FBY3ZDLGNBQWNaLE1BQU1vRCxVQUFVLE9BQU8sS0FDakUsdUJBQUMsVUFBSyxPQUFPLEVBQUVoQixPQUFPLG9CQUFvQkQsVUFBVSxVQUFVLEdBQUcsc0RBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE9BR0F2QixjQUFjWixRQUFRLElBQUlxRDtBQUFBQSxRQUFJLENBQUNDLFlBQy9CO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQztBQUFBLFlBQ0EsU0FBUyxNQUFNLEtBQUt2RSxZQUFZdUIsa0JBQWtCLEVBQUVSLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxXQUFXLEVBQUUsQ0FBQztBQUFBO0FBQUEsVUFGakd3RCxRQUFRN0I7QUFBQUEsVUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRzBHO0FBQUEsTUFFM0c7QUFBQSxTQXpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsc0JBQXFCLE9BQU8sRUFBRU0sU0FBUyxJQUFJTyxTQUFTLFFBQVFDLEtBQUssSUFBSU8sV0FBVyxHQUFHLEdBQ3BHLGlDQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFQyxnQkFBZ0IsaUJBQWlCUixLQUFLLElBQUlnQixZQUFZLFNBQVMsR0FDMUc7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRWpCLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFSixVQUFVLFNBQVMsR0FBRyx1QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxrQkFBa0JELFVBQVUsVUFBVSxHQUFHLGtMQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxJQUFHLDhCQUNQLGlDQUFDLFVBQU8sU0FBUSxTQUFRLGlDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUosU0FBUyxJQUFJTyxTQUFTLFFBQVFDLEtBQUssSUFBSU8sV0FBVyxHQUFHLEdBQ3BHLGlDQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFQyxnQkFBZ0IsaUJBQWlCUixLQUFLLElBQUlnQixZQUFZLFNBQVMsR0FDMUc7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRWpCLFNBQVMsUUFBUUMsS0FBSyxHQUFHUCxVQUFVLElBQUksR0FDbkQ7QUFBQSwrQkFBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVHLFVBQVUsU0FBUyxHQUFHLHlDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsZ0tBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLElBQUcsZ0NBQ1AsaUNBQUMsVUFBTyxTQUFRLFNBQVEsNkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUMsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUVBLHVCQUFDLGFBQVEsV0FBVSxzQkFBcUIsT0FBTyxFQUFFSixTQUFTLElBQUlPLFNBQVMsUUFBUUMsS0FBSyxJQUFJTyxXQUFXLEdBQUcsR0FDcEcsaUNBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVDLGdCQUFnQixpQkFBaUJSLEtBQUssSUFBSWdCLFlBQVksU0FBUyxHQUMxRztBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFakIsU0FBUyxRQUFRQyxLQUFLLEdBQUdQLFVBQVUsSUFBSSxHQUNuRDtBQUFBLCtCQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUcsVUFBVSxTQUFTLEdBQUcseUNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBRyxnTEFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssSUFBRywrQkFDUCxpQ0FBQyxVQUFPLFNBQVEsU0FBUSxrQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBRUEsdUJBQUMsYUFBUSxXQUFVLHNCQUFxQixPQUFPLEVBQUVKLFNBQVMsSUFBSU8sU0FBUyxRQUFRQyxLQUFLLElBQUlPLFdBQVcsR0FBRyxHQUNwRyxpQ0FBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUMsZ0JBQWdCLGlCQUFpQlIsS0FBSyxJQUFJZ0IsWUFBWSxTQUFTLEdBQzFHO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVqQixTQUFTLFFBQVFDLEtBQUssR0FBR1AsVUFBVSxJQUFJLEdBQ25EO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFRyxVQUFVLFNBQVMsR0FBRyx3QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxrQkFBa0JELFVBQVUsVUFBVSxHQUFHLGlPQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFSSxLQUFLLEVBQUUsR0FDdEM7QUFBQSwrQkFBQyxRQUFLLElBQUcsK0JBQ1AsaUNBQUMsVUFBTyxTQUFRLFNBQVEsa0NBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTMUIsb0JBQW9CK0IsV0FBVyxTQUFTLE1BQU0vQixvQkFBb0JnQyxPQUFPLEdBQUcsaUNBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsc0JBQXFCLE9BQU8sRUFBRWQsU0FBUyxJQUFJTyxTQUFTLFFBQVFDLEtBQUssSUFBSU8sV0FBVyxHQUFHLEdBQ3BHO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVDLGdCQUFnQixpQkFBaUJSLEtBQUssSUFBSWdCLFlBQVksU0FBUyxHQUMxRztBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFakIsU0FBUyxRQUFRQyxLQUFLLEdBQUdQLFVBQVUsSUFBSSxHQUNuRDtBQUFBLGlDQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUcsVUFBVSxTQUFTLEdBQUcsMEJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQUcsb05BQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFSSxLQUFLLEVBQUUsR0FDdEM7QUFBQSxpQ0FBQyxRQUFLLElBQUcsNENBQ1AsaUNBQUMsVUFBTyxTQUFRLFNBQVEsb0NBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDLEtBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixTQUFTYixzQkFBc0JrQjtBQUFBQSxjQUMvQixVQUFVLENBQUN4QjtBQUFBQSxjQUNYLFNBQVMsTUFBTU0sc0JBQXNCbUIsT0FBTztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFFQyxDQUFDekIscUJBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVnQixPQUFPLG9CQUFvQkQsVUFBVSxVQUFVLEdBQUcseUZBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BR0RYLHNCQUFzQmEsV0FDckIsdUJBQUMsY0FBVyxPQUFPYixzQkFBc0JoQixPQUFPLE1BQUssMkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEU7QUFBQSxNQUc3RWdCLHNCQUFzQnhCLFFBQ3JCLG1DQUNFO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUV1QyxLQUFLLEdBQUcsR0FDbkQ7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUQsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSxtQ0FBQyxVQUFLLE9BQU8sRUFBRUgsT0FBTyxvQkFBb0JELFVBQVUsVUFBVSxHQUFHLGlEQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRztBQUFBLFlBQ2xHLHVCQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUEsVUFBVSxVQUFVLEdBQ3BEWCxnQ0FBc0J4QixLQUFLd0QsdUNBQXVDTixlQUFlLFNBQVMsRUFBRU8sT0FBTyxZQUFZQyxVQUFVLE1BQU0sQ0FBQyxLQURuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXBCLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsbUNBQUMsVUFBSyxPQUFPLEVBQUVILE9BQU8sb0JBQW9CRCxVQUFVLFVBQVUsR0FBRyxxQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Y7QUFBQSxZQUN0Rix1QkFBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVBLFVBQVUsVUFBVSxHQUNwRFgsZ0NBQXNCeEIsS0FBSzJELGlCQUFpQlQsZUFBZSxTQUFTLEVBQUVPLE9BQU8sWUFBWUMsVUFBVSxNQUFNLENBQUMsS0FEN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0NsQyxzQkFBc0J4QixLQUFLNEQsa0JBQzFCLHVCQUFDLFVBQUssV0FBVSxRQUFPLE9BQU8sRUFBRSxTQUFTLGdCQUFnQixHQUFvQjtBQUFBO0FBQUEsWUFDeEM7QUFBQSxZQUNsQ3BDLHNCQUFzQnhCLEtBQUs2RCxrQkFBa0JYLGVBQWUsU0FBUyxFQUFFTyxPQUFPLFlBQVlDLFVBQVUsTUFBTSxDQUFDO0FBQUEsZUFGOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxRQUVDbEMsc0JBQXNCeEIsS0FBSzhELFlBQVlWLFNBQVMsS0FDL0MsdUJBQUMsU0FBSSxPQUFPLEVBQUVkLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEsaUNBQUMsVUFBSyxPQUFPLEVBQUVILE9BQU8sa0JBQWtCRCxVQUFVLFdBQVc0QixZQUFZLElBQUksR0FBRyx3QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Y7QUFBQSxVQUN2RnZDLHNCQUFzQnhCLEtBQUs4RCxZQUFZVDtBQUFBQSxZQUFJLENBQUNXLE1BQzNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRWpCLGdCQUFnQixpQkFBaUJSLEtBQUssSUFBSTBCLFdBQVcsOEJBQThCQyxZQUFZLEdBQUcvQixVQUFVLFVBQVU7QUFBQSxnQkFFL0g7QUFBQSx5Q0FBQyxVQUNFNkI7QUFBQUEsc0JBQUVHO0FBQUFBLG9CQUNGSCxFQUFFSSxVQUFVLE1BQU1KLEVBQUVJLE9BQU8sS0FBSztBQUFBLHVCQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVoQyxPQUFPLG1CQUFtQixHQUFJNEIsWUFBRUssVUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0Q7QUFBQSxrQkFDdEQsdUJBQUMsVUFBTUwsWUFBRU0sY0FBYyxJQUFJckIsS0FBS2UsRUFBRU0sV0FBVyxFQUFFQyxtQkFBbUIsT0FBTyxJQUFJLHVCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRztBQUFBLGtCQUNqRyx1QkFBQyxZQUFRUCxZQUFFUSxPQUFPdEIsZUFBZSxTQUFTLEVBQUVPLE9BQU8sWUFBWUMsVUFBVSxNQUFNLENBQUMsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Y7QUFBQTtBQUFBO0FBQUEsY0FWN0VNLEVBQUVTO0FBQUFBLGNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsVUFDRDtBQUFBLGFBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUdEakQsc0JBQXNCeEIsS0FBSzBFLE9BQU90QixXQUFXLEtBQUs1QixzQkFBc0J4QixLQUFLOEQsWUFBWVYsV0FBVyxLQUNuRyx1QkFBQyxVQUFLLE9BQU8sRUFBRWhCLE9BQU8sb0JBQW9CRCxVQUFVLFVBQVUsR0FBRyx1RUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0E5Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdEQTtBQUFBLFNBdEZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3RkE7QUFBQSxJQUVBLHVCQUFDLGFBQVEsV0FBVSxzQkFBcUIsT0FBTyxFQUFFSixTQUFTLElBQUlPLFNBQVMsUUFBUUMsS0FBSyxJQUFJTyxXQUFXLEdBQUcsR0FDcEcsaUNBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVDLGdCQUFnQixpQkFBaUJSLEtBQUssSUFBSWdCLFlBQVksU0FBUyxHQUMxRztBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFakIsU0FBUyxRQUFRQyxLQUFLLEdBQUdQLFVBQVUsSUFBSSxHQUNuRDtBQUFBLCtCQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUcsVUFBVSxTQUFTLEdBQUcsMEJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBRyxpS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssSUFBRyxpQ0FDUCxpQ0FBQyxVQUFPLFNBQVEsU0FBUSw4QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBRUEsdUJBQUMsYUFBUSxXQUFVLHNCQUFxQixPQUFPLEVBQUVKLFNBQVMsSUFBSU8sU0FBUyxRQUFRQyxLQUFLLElBQUlPLFdBQVcsR0FBRyxHQUNwRyxpQ0FBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUMsZ0JBQWdCLGlCQUFpQlIsS0FBSyxJQUFJZ0IsWUFBWSxTQUFTLEdBQzFHO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVqQixTQUFTLFFBQVFDLEtBQUssR0FBR1AsVUFBVSxJQUFJLEdBQ25EO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFRyxVQUFVLFNBQVMsR0FBRywyQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxrQkFBa0JELFVBQVUsVUFBVSxHQUFHLGtHQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxJQUFHLGtDQUNQLGlDQUFDLFVBQU8sU0FBUSxTQUFRLCtCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsSUFFQ2YscUJBQXFCLHVCQUFDLDZCQUEwQixVQUFVQSxrQkFBa0JLLFVBQVUsYUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRjtBQUFBLElBQzNHLENBQUNMLHFCQUNBLHVCQUFDLGFBQVEsV0FBVSxzQkFBcUIsT0FBTyxFQUFFVyxTQUFTLElBQUlPLFNBQVMsUUFBUUMsS0FBSyxHQUFHTyxXQUFXLEdBQUcsR0FDbkc7QUFBQSw2QkFBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVYLFVBQVUsU0FBUyxHQUFHLGdDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLG9CQUFvQkQsVUFBVSxVQUFVLEdBQUcsOEhBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFHRix1QkFBQyxhQUFRLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUosU0FBUyxJQUFJTyxTQUFTLFFBQVFDLEtBQUssR0FBR08sV0FBVyxHQUFHLEdBQ25HO0FBQUEsNkJBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFWCxVQUFVLFNBQVMsR0FBRyxrREFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLE9BQU8sRUFBRUYsUUFBUSxHQUFHMEMsYUFBYSxJQUFJdkMsT0FBTyxrQkFBa0JELFVBQVUsVUFBVUcsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDNUc7QUFBQSwrQkFBQyxRQUNDO0FBQUEsaUNBQUMsWUFBTyxPQUFPLEVBQUVILE9BQU8sYUFBYSxHQUFHLHVCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQztBQUFBLFVBQVM7QUFBQSxhQUQxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUNBLHVCQUFDLFFBQ0M7QUFBQSxpQ0FBQyxZQUFPLE9BQU8sRUFBRUEsT0FBTyxhQUFhLEdBQUcseUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFBUztBQUFBLGFBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsT0E1V0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZXQTtBQUVKO0FBQUN0RCxHQXJkZUQsc0JBQW9CO0FBQUEsVUFDZG5DLGdCQUNOb0IsVUFDc0JELGNBU2RwQixVQWlCREQsYUFpQkFBLGFBVUNDLFVBS01ELGFBb0JFQyxVQU1BRCxXQUFXO0FBQUE7QUFBQSxLQXZGM0JxQztBQXVkaEIsU0FBUytGLG1CQUFtQjtBQUFBLEVBQzFCdEI7QUFBQUEsRUFDQXVCO0FBSUYsR0FBRztBQUFBQyxNQUFBO0FBQ0QsUUFBTTlGLFFBQVFsQixTQUFTO0FBQ3ZCLFFBQU0sQ0FBQ3lELFlBQVl3RCxhQUFhLElBQUl6SSxTQUFTZ0gsUUFBUS9CLGNBQWMsRUFBRTtBQUNyRSxRQUFNLENBQUN5RCxjQUFjQyxlQUFlLElBQUkzSSxTQUFTZ0gsUUFBUTBCLGdCQUFnQixFQUFFO0FBRTNFLFFBQU1FLFdBQVcxSSxZQUFZO0FBQUEsSUFDM0IwRCxZQUFZQSxNQUNWMUMsd0JBQXdCO0FBQUEsTUFDdEJpRSxVQUFVNkIsUUFBUTdCO0FBQUFBLE1BQ2xCRixZQUFZQSxXQUFXcEIsS0FBSztBQUFBLE1BQzVCNkUsY0FBY0EsYUFBYTdFLEtBQUs7QUFBQSxJQUNsQyxDQUFDO0FBQUEsSUFDSEMsV0FBV0EsTUFBTTtBQUNmcEIsWUFBTXFCLFFBQVEsU0FBU2lELFFBQVE2QixVQUFVLGVBQWU7QUFDeEROLGNBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQXRFLFNBQVNBLE1BQU12QixNQUFNd0IsTUFBTSxvQ0FBb0M7QUFBQSxFQUNqRSxDQUFDO0FBRUQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRStDLFlBQVksT0FBT2hCLEtBQUssSUFBSTBCLFdBQVcsOEJBQThCQyxZQUFZLEdBQUcsR0FDL0g7QUFBQSwyQkFBQyxTQUFJLE9BQU8sRUFBRWtCLFVBQVUsS0FBS3JCLFlBQVksSUFBSSxHQUFJVCxrQkFBUTZCLGNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0U7QUFBQSxJQUNwRSx1QkFBQyxTQUFJLE9BQU8sRUFBRUUsTUFBTSxHQUFHRCxVQUFVLElBQUksR0FDbkM7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLE9BQU83RDtBQUFBQSxRQUNQLFVBQVUsQ0FBQ2lCLE1BQU11QyxjQUFjdkMsRUFBRUMsT0FBT0MsS0FBSztBQUFBLFFBQzdDLGFBQVk7QUFBQTtBQUFBLE1BSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSW1DLEtBTHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUyQyxNQUFNLEdBQUdELFVBQVUsSUFBSSxHQUNuQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sT0FBT0o7QUFBQUEsUUFDUCxVQUFVLENBQUN4QyxNQUFNeUMsZ0JBQWdCekMsRUFBRUMsT0FBT0MsS0FBSztBQUFBLFFBQy9DLGFBQVk7QUFBQTtBQUFBLE1BSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXdCLEtBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFNBQVN3QyxTQUFTdEMsV0FBVyxTQUFTLE1BQU1zQyxTQUFTckMsT0FBTyxHQUFHLHNCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBO0FBRUo7QUFBQ2lDLElBakRRRixvQkFBa0I7QUFBQSxVQU9YOUcsVUFJR3RCLFdBQVc7QUFBQTtBQUFBLE1BWHJCb0k7QUFtRFQsTUFBTVUsaUJBQWlCLENBQUMsV0FBVyxXQUFXLFNBQVMsVUFBVSxVQUFVLFNBQVMsUUFBUTtBQU01RixTQUFTQywwQkFBMEIsRUFBRTlELFVBQVV4QyxVQUFtRCxHQUFHO0FBQUF1RyxNQUFBO0FBQ25HLFFBQU16RyxjQUFjckMsZUFBZTtBQUNuQyxRQUFNc0MsUUFBUWxCLFNBQVM7QUFFdkIsUUFBTTJILGNBQWNoSixTQUFTO0FBQUEsSUFDM0JxRCxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsWUFBWSxVQUFVMkIsUUFBUTtBQUFBLElBQ2xFMUIsU0FBU0EsTUFBTTdDLHVCQUF1QnVFLFFBQVE7QUFBQTtBQUFBO0FBQUEsSUFHOUNpRSxPQUFPO0FBQUEsRUFDVCxDQUFDO0FBS0QsUUFBTSxDQUFDQyxtQkFBbUJDLG9CQUFvQixJQUFJdEosU0FBUyxLQUFLO0FBQ2hFLFFBQU11SixxQkFBcUJwSixTQUFTO0FBQUEsSUFDbENxRCxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsWUFBWSxRQUFRYixTQUFTO0FBQUEsSUFDakVjLFNBQVNBLE1BQU05QyxzQkFBc0JnQyxTQUFTO0FBQUEsSUFDOUNNLFNBQVNvRztBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNLENBQUNHLHFCQUFxQkMsc0JBQXNCLElBQUl6SixTQUFTLEtBQUs7QUFDcEUsUUFBTTBKLHVCQUF1QnZKLFNBQVM7QUFBQSxJQUNwQ3FELFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxZQUFZLFdBQVcyQixRQUFRO0FBQUEsSUFDbkUxQixTQUFTQSxNQUFNaEQsd0JBQXdCMEUsUUFBUTtBQUFBLElBQy9DbEMsU0FBU3VHO0FBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU0sQ0FBQ0csZ0JBQWdCQyxpQkFBaUIsSUFBSTVKLFNBQVMsVUFBVTtBQUMvRCxRQUFNLENBQUM2SixpQkFBaUJDLGtCQUFrQixJQUFJOUosU0FBd0IsSUFBSTtBQUMxRSxRQUFNK0oseUJBQXlCNUosU0FBUztBQUFBLElBQ3RDcUQsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFlBQVksdUJBQXVCMkIsVUFBVTBFLGVBQWU7QUFBQSxJQUNoR3BHLFNBQVNBLE1BQU01QyxrQ0FBa0NzRSxVQUFVMEUsbUJBQW1CLEVBQUU7QUFBQSxJQUNoRjVHLFNBQVMsQ0FBQyxDQUFDNEc7QUFBQUEsSUFDWFQsT0FBTztBQUFBLEVBQ1QsQ0FBQztBQUVELFFBQU1ZLHFCQUFxQjdKLFNBQVM7QUFBQSxJQUNsQ3FELFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxZQUFZLGlCQUFpQjJCLFFBQVE7QUFBQSxJQUN6RTFCLFNBQVNBLE1BQU1qRCxzQkFBc0IyRSxRQUFRO0FBQUEsRUFDL0MsQ0FBQztBQUVELFFBQU04RSxvQkFBb0I5SixTQUFTO0FBQUEsSUFDakNxRCxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsWUFBWSxpQkFBaUIyQixRQUFRO0FBQUEsSUFDekUxQixTQUFTQSxNQUFNM0MscUJBQXFCcUUsUUFBUTtBQUFBLEVBQzlDLENBQUM7QUFFRCxRQUFNLENBQUMrRSxRQUFRQyxTQUFTLElBQUluSyxTQUFrQyxFQUFFO0FBQ2hFLFFBQU0sQ0FBQ29LLFVBQVVDLFdBQVcsSUFBSXJLLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNzSyxxQkFBcUJDLHNCQUFzQixJQUFJdkssU0FBd0IsSUFBSTtBQUVsRkQsWUFBVSxNQUFNO0FBQ2QsUUFBSWtLLGtCQUFrQnZHLFFBQVE0Ryx3QkFBd0JuRixVQUFVO0FBQzlEZ0YsZ0JBQVVGLGtCQUFrQnZHLEtBQUt3RyxNQUFNO0FBQ3ZDRyxrQkFBWUosa0JBQWtCdkcsS0FBSzhHLHdCQUF3QkMsU0FBUyxLQUFLLEVBQUU7QUFDM0VGLDZCQUF1QnBGLFFBQVE7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxDQUFDOEUsa0JBQWtCdkcsTUFBTXlCLFVBQVVtRixtQkFBbUIsQ0FBQztBQUUxRCxRQUFNLENBQUNJLHlCQUF5QkMsMEJBQTBCLElBQUkzSyxTQUFTLEVBQUU7QUFDekUsUUFBTSxDQUFDNEssbUJBQW1CQyxvQkFBb0IsSUFBSTdLLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUM4SyxpQkFBaUJDLGtCQUFrQixJQUFJL0ssU0FBUyxFQUFFO0FBRXpELFFBQU1nTCw2QkFBNkI5SyxZQUFZO0FBQUEsSUFDN0MwRCxZQUFZQSxNQUNWdkQsd0JBQXdCO0FBQUEsTUFDdEI4RTtBQUFBQSxNQUNBOEYsYUFBYVAsd0JBQXdCN0csS0FBSztBQUFBLE1BQzFDcUgsT0FBTyxJQUFJdkUsS0FBS2lFLGlCQUFpQixFQUFFTyxZQUFZO0FBQUEsTUFDL0NDLEtBQUssSUFBSXpFLEtBQUttRSxlQUFlLEVBQUVLLFlBQVk7QUFBQSxJQUM3QyxDQUFDO0FBQUEsSUFDSHJILFdBQVdBLE1BQU07QUFDZnBCLFlBQU1xQixRQUFRLHdCQUF3QjtBQUN0QzRHLGlDQUEyQixFQUFFO0FBQzdCRSwyQkFBcUIsRUFBRTtBQUN2QkUseUJBQW1CLEVBQUU7QUFDckIsV0FBS3RJLFlBQVl1QixrQkFBa0IsRUFBRVIsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFlBQVksaUJBQWlCMkIsUUFBUSxFQUFFLENBQUM7QUFBQSxJQUNuSDtBQUFBLElBQ0FsQixTQUFTQSxNQUFNdkIsTUFBTXdCLE1BQU0saUNBQWlDO0FBQUEsRUFDOUQsQ0FBQztBQUVELFFBQU1tSCw2QkFBNkJuTCxZQUFZO0FBQUEsSUFDN0MwRCxZQUFZQSxDQUFDMEgsbUJBQTJCaEwsd0JBQXdCNkUsVUFBVW1HLGNBQWM7QUFBQSxJQUN4RnhILFdBQVdBLE1BQU07QUFDZnBCLFlBQU1xQixRQUFRLGdCQUFnQjtBQUM5QixXQUFLdEIsWUFBWXVCLGtCQUFrQixFQUFFUixVQUFVLENBQUMsZ0JBQWdCLFNBQVMsWUFBWSxpQkFBaUIyQixRQUFRLEVBQUUsQ0FBQztBQUFBLElBQ25IO0FBQUEsSUFDQWxCLFNBQVNBLE1BQU12QixNQUFNd0IsTUFBTSxrQ0FBa0M7QUFBQSxFQUMvRCxDQUFDO0FBRUQsUUFBTXFILDJCQUEyQnJMLFlBQVk7QUFBQSxJQUMzQzBELFlBQVlBLE1BQU01QyxzQkFBc0JtRSxVQUFVK0UsTUFBTTtBQUFBLElBQ3hEcEcsV0FBV0EsTUFBTTtBQUNmcEIsWUFBTXFCLFFBQVEsdURBQXVEO0FBQ3JFLFdBQUt0QixZQUFZdUIsa0JBQWtCLEVBQUVSLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxZQUFZLGlCQUFpQjJCLFFBQVEsRUFBRSxDQUFDO0FBQUEsSUFDbkg7QUFBQSxJQUNBbEIsU0FBU0EsTUFBTXZCLE1BQU13QixNQUFNLDBFQUEwRTtBQUFBLEVBQ3ZHLENBQUM7QUFFRCxRQUFNc0gsc0JBQXNCdEwsWUFBWTtBQUFBLElBQ3RDMEQsWUFBWUEsTUFBTXpDLHdCQUF3QmdFLFVBQVVpRixTQUFTdkcsS0FBSyxNQUFNLEtBQUssT0FBTzRILE9BQU9yQixRQUFRLENBQUM7QUFBQSxJQUNwR3RHLFdBQVdBLE1BQU07QUFDZnBCLFlBQU1xQixRQUFRLDhCQUE4QjtBQUM1QyxXQUFLdEIsWUFBWXVCLGtCQUFrQixFQUFFUixVQUFVLENBQUMsZ0JBQWdCLFNBQVMsWUFBWSxpQkFBaUIyQixRQUFRLEVBQUUsQ0FBQztBQUFBLElBQ25IO0FBQUEsSUFDQWxCLFNBQVNBLE1BQU12QixNQUFNd0IsTUFBTSxnREFBZ0Q7QUFBQSxFQUM3RSxDQUFDO0FBRUQsUUFBTXdILFdBQVdBLE1BQU12QixVQUFVLENBQUN3QixTQUFTLENBQUMsR0FBR0EsTUFBTSxFQUFFQyxXQUFXLEdBQUdWLE9BQU8sU0FBU1csaUJBQWlCLElBQUksQ0FBQyxDQUFDO0FBQzVHLFFBQU1DLGNBQWNBLENBQUNDLFVBQWtCNUIsVUFBVSxDQUFDd0IsU0FBU0EsS0FBS0ssT0FBTyxDQUFDQyxHQUFHQyxNQUFNQSxNQUFNSCxLQUFLLENBQUM7QUFDN0YsUUFBTUksY0FBY0EsQ0FBQ0osT0FBZUssVUFDbENqQyxVQUFVLENBQUN3QixTQUFTQSxLQUFLNUUsSUFBSSxDQUFDVyxHQUFHd0UsTUFBT0EsTUFBTUgsUUFBUSxFQUFFLEdBQUdyRSxHQUFHLEdBQUcwRSxNQUFNLElBQUkxRSxDQUFFLENBQUM7QUFFaEYsUUFBTTJFLHFCQUFxQnBDLGtCQUFrQnZHLE1BQU0ySSxzQkFBc0I7QUFFekUsU0FDRSx1QkFBQyxhQUFRLFdBQVUsc0JBQXFCLE9BQU8sRUFBRTVHLFNBQVMsSUFBSU8sU0FBUyxRQUFRQyxLQUFLLElBQUlPLFdBQVcsR0FBRyxHQUNwRztBQUFBLDJCQUFDLFNBQUksT0FBTyxFQUFFUixTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLDZCQUFDLFVBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUosVUFBVSxTQUFTLEdBQUcsZ0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLE9BQU8sa0JBQWtCRCxVQUFVLFVBQVUsR0FBRywrSkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFRyxTQUFTLFFBQVFDLEtBQUssR0FBRzBCLFdBQVcsOEJBQThCQyxZQUFZLEdBQUcsR0FDN0Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRW5CLGdCQUFnQixpQkFBaUJRLFlBQVksVUFBVWhCLEtBQUssR0FBRyxHQUMxRztBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFd0IsWUFBWSxJQUFJLEdBQUcsc0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxRQUN4Qyx1QkFBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLE1BQUssU0FBUzBCLFlBQVltRCxZQUFZLFNBQVMsTUFBTSxLQUFLbkQsWUFBWW9ELFFBQVEsR0FBRyxnQ0FBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNDcEQsWUFBWXBELFdBQVcsdUJBQUMsY0FBVyxPQUFPb0QsWUFBWWpGLE9BQU8sTUFBSyxzQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQ3BGaUYsWUFBWXpGLFFBQ1gsdUJBQUMsU0FBSSxPQUFPLEVBQUVzQyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLCtCQUFDLFVBQUssV0FBVSxRQUFRa0Qsc0JBQVl6RixLQUFLOEksa0JBQWtCLGtCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFDekVyRCxZQUFZekYsS0FBSytJLFlBQVkxRjtBQUFBQSxVQUFJLENBQUMyRixNQUNqQyx1QkFBQyxVQUFnQixPQUFPLEVBQUU1RyxPQUFPLG9CQUFvQkQsVUFBVSxVQUFVLEdBQ3RFNkc7QUFBQUEsY0FBRXZFO0FBQUFBLFlBQUc7QUFBQSxZQUFHdUUsRUFBRUM7QUFBQUEsWUFBTTtBQUFBLFlBQUVELEVBQUVFLFVBQVUsTUFBTUYsRUFBRUUsT0FBTyxLQUFLO0FBQUEsZUFEMUNGLEVBQUV2RSxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUNEO0FBQUEsV0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRW5DLFNBQVMsUUFBUUMsS0FBSyxJQUFJMEIsV0FBVyw4QkFBOEJDLFlBQVksR0FBRyxHQUM5RjtBQUFBLDZCQUFDLFVBQUssT0FBTyxFQUFFSCxZQUFZLElBQUksR0FBRyxrQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRDtBQUFBLE1BQ3BEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixNQUFLO0FBQUEsVUFDTCxTQUFTNEIscUJBQXFCRSxtQkFBbUIrQztBQUFBQSxVQUNqRCxTQUFTLE1BQU9qRCxvQkFBb0IsS0FBS0UsbUJBQW1CZ0QsUUFBUSxJQUFJakQscUJBQXFCLElBQUk7QUFBQSxVQUFHO0FBQUE7QUFBQSxRQUp0RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLE1BQ0NELHFCQUFxQkUsbUJBQW1CeEQsV0FBVyx1QkFBQyxjQUFXLE9BQU93RCxtQkFBbUJyRixPQUFPLE1BQUssc0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0U7QUFBQSxNQUN2SG1GLHNCQUFzQkUsbUJBQW1CN0YsUUFBUSxJQUFJb0QsU0FBUyxLQUM3RCx1QkFBQyxTQUFJLE9BQU8sRUFBRWQsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDbkNzRCw2QkFBbUI3RixLQUFNcUQ7QUFBQUEsUUFBSSxDQUFDL0IsTUFDN0IsdUJBQUMsVUFBZ0IsT0FBTyxFQUFFYyxPQUFPLGtCQUFrQkQsVUFBVSxVQUFVLEdBQ3BFYjtBQUFBQSxZQUFFNkgsUUFBUTdILEVBQUVtRDtBQUFBQSxVQUFHO0FBQUEsVUFBRW5ELEVBQUU4SCxnQkFBZ0IsS0FBSzlILEVBQUU4SCxhQUFhLEtBQUs7QUFBQSxVQUFHO0FBQUEsVUFBQyx1QkFBQyxVQUFLLE9BQU8sRUFBRWhILE9BQU8sbUJBQW1CLEdBQUc7QUFBQTtBQUFBLFlBQUVkLEVBQUVtRDtBQUFBQSxZQUFHO0FBQUEsZUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxhQUQ1R25ELEVBQUVtRCxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRW5DLFNBQVMsUUFBUUMsS0FBSyxJQUFJMEIsV0FBVyw4QkFBOEJDLFlBQVksR0FBRyxHQUM5RjtBQUFBLDZCQUFDLFVBQUssT0FBTyxFQUFFSCxZQUFZLElBQUksR0FBRyxnQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLE1BQ2xEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixNQUFLO0FBQUEsVUFDTCxTQUFTK0IsdUJBQXVCRSxxQkFBcUI0QztBQUFBQSxVQUNyRCxTQUFTLE1BQU85QyxzQkFBc0IsS0FBS0UscUJBQXFCNkMsUUFBUSxJQUFJOUMsdUJBQXVCLElBQUk7QUFBQSxVQUFHO0FBQUE7QUFBQSxRQUo1RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLE1BQ0NELHVCQUF1QkUscUJBQXFCM0QsV0FBVyx1QkFBQyxjQUFXLE9BQU8yRCxxQkFBcUJ4RixPQUFPLE1BQUsseUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUNoSXNGLHVCQUF1QkUscUJBQXFCaEcsUUFDM0MsdUJBQUMsU0FBSSxPQUFPLEVBQUVzQyxTQUFTLFFBQVFDLEtBQUssR0FBR0osVUFBVSxXQUFXQyxPQUFPLGlCQUFpQixHQUNsRjtBQUFBLCtCQUFDLFVBQUs7QUFBQTtBQUFBLFVBQU80RCxxQkFBcUJoRyxLQUFLbUosUUFBUTtBQUFBLGFBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxRQUNuRCx1QkFBQyxVQUFLO0FBQUE7QUFBQSxVQUFlbkQscUJBQXFCaEcsS0FBS29KLGlCQUFpQjtBQUFBLGFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0U7QUFBQSxRQUNwRSx1QkFBQyxVQUFLO0FBQUE7QUFBQSxVQUFPcEQscUJBQXFCaEcsS0FBS21FLFFBQVE7QUFBQSxhQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1EO0FBQUEsUUFDbkQsdUJBQUMsVUFBSztBQUFBO0FBQUEsVUFBUzZCLHFCQUFxQmhHLEtBQUtxRSxVQUFVO0FBQUEsYUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQ3REMkIscUJBQXFCaEcsS0FBS3FKLFdBQ3pCLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFVBQ09yRCxxQkFBcUJoRyxLQUFLcUosUUFBUUM7QUFBQUEsVUFBTztBQUFBLFVBQUd0RCxxQkFBcUJoRyxLQUFLcUosUUFBUUU7QUFBQUEsVUFBTztBQUFBLFVBQUc7QUFBQSxVQUNsR3ZELHFCQUFxQmhHLEtBQUtxSixRQUFRRztBQUFBQSxVQUFLO0FBQUEsVUFBRXhELHFCQUFxQmhHLEtBQUtxSixRQUFRSjtBQUFBQSxhQUY5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFM0csU0FBUyxRQUFRQyxLQUFLLElBQUkwQixXQUFXLDhCQUE4QkMsWUFBWSxHQUFHLEdBQzlGO0FBQUEsNkJBQUMsVUFBSyxPQUFPLEVBQUVILFlBQVksSUFBSSxHQUFHLG1DQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsTUFDckQsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUV4QixLQUFLLElBQUlnQixZQUFZLE1BQU0sR0FDdEU7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRThCLE1BQU0sR0FBR0QsVUFBVSxJQUFJLEdBQ25DO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPYTtBQUFBQSxZQUNQLFVBQVUsQ0FBQ3pELE1BQU0wRCxrQkFBa0IxRCxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsWUFDakQsYUFBWTtBQUFBO0FBQUEsVUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJc0MsS0FMeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsTUFBSztBQUFBLFlBQ0wsVUFBVSxDQUFDdUQsZUFBZTlGLEtBQUs7QUFBQSxZQUMvQixTQUFTa0csdUJBQXVCdUM7QUFBQUEsWUFDaEMsU0FBUyxNQUFNeEMsbUJBQW1CSCxlQUFlOUYsS0FBSyxDQUFDO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFMM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFDQ2tHLHVCQUF1QmhFLFdBQVcsdUJBQUMsY0FBVyxPQUFPZ0UsdUJBQXVCN0YsT0FBTyxNQUFLLDBCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRFO0FBQUEsTUFDOUc2Rix1QkFBdUJyRyxRQUN0Qix1QkFBQyxTQUFJLE9BQU8sRUFBRXNDLFNBQVMsUUFBUUMsS0FBSyxHQUFHSixVQUFVLFdBQVdDLE9BQU8saUJBQWlCLEdBQ2xGO0FBQUEsK0JBQUMsVUFDRWlFO0FBQUFBLGlDQUF1QnJHLEtBQUt5SixhQUFhdEQ7QUFBQUEsVUFBZ0I7QUFBQSxVQUFJRSx1QkFBdUJyRyxLQUFLMEosWUFBWSxlQUFlO0FBQUEsVUFDcEhyRCx1QkFBdUJyRyxLQUFLaUosUUFBUSxLQUFLNUMsdUJBQXVCckcsS0FBS2lKLEtBQUssTUFBTTtBQUFBLGFBRm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0M1Qyx1QkFBdUJyRyxLQUFLK0ksWUFBWTFGO0FBQUFBLFVBQUksQ0FBQzJGLE1BQzVDLHVCQUFDLFVBQWdCLE9BQU8sRUFBRTVHLE9BQU8sbUJBQW1CLEdBQ2pENEc7QUFBQUEsY0FBRXZFO0FBQUFBLFlBQUc7QUFBQSxZQUFHdUUsRUFBRUM7QUFBQUEsWUFBTTtBQUFBLFlBQUVELEVBQUVFLFVBQVUsTUFBTUYsRUFBRUUsT0FBTyxLQUFLO0FBQUEsZUFEMUNGLEVBQUV2RSxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUNEO0FBQUEsV0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQWpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUNBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRW5DLFNBQVMsUUFBUUMsS0FBSyxJQUFJMEIsV0FBVyw4QkFBOEJDLFlBQVksR0FBRyxHQUM5RjtBQUFBLDZCQUFDLFVBQUssT0FBTyxFQUFFSCxZQUFZLElBQUksR0FBRyw2Q0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRDtBQUFBLE1BQzlEdUMsbUJBQW1CakUsV0FBVyx1QkFBQyxjQUFXLE9BQU9pRSxtQkFBbUI5RixPQUFPLE1BQUsscUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUU7QUFBQSxPQUNoRzhGLG1CQUFtQnRHLFFBQVEsSUFBSW9ELFdBQVcsS0FBSyxDQUFDa0QsbUJBQW1CbkQsYUFDbkUsdUJBQUMsVUFBSyxPQUFPLEVBQUVmLE9BQU8sb0JBQW9CRCxVQUFVLFVBQVUsR0FBRyxvQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRjtBQUFBLE9BRXJGbUUsbUJBQW1CdEcsUUFBUSxJQUFJcUQ7QUFBQUEsUUFBSSxDQUFDbUYsTUFDcEMsdUJBQUMsU0FBZSxXQUFVLHNCQUFxQixPQUFPLEVBQUV6RixnQkFBZ0IsaUJBQWlCUixLQUFLLElBQUlKLFVBQVUsVUFBVSxHQUNwSDtBQUFBLGlDQUFDLFVBQ0VxRztBQUFBQSxjQUFFakIsZUFBZTtBQUFBLFlBQWU7QUFBQSxZQUFJLElBQUl0RSxLQUFLdUYsRUFBRWhCLEtBQUssRUFBRXRFLGVBQWUsT0FBTztBQUFBLFlBQUU7QUFBQSxZQUFLO0FBQUEsWUFDbkYsSUFBSUQsS0FBS3VGLEVBQUVkLEdBQUcsRUFBRXhFLGVBQWUsT0FBTztBQUFBLGVBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixNQUFLO0FBQUEsY0FDTCxTQUFTeUUsMkJBQTJCL0U7QUFBQUEsY0FDcEMsU0FBUyxNQUFNK0UsMkJBQTJCOUUsT0FBTzJGLEVBQUUvRCxFQUFFO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFKekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQVpRK0QsRUFBRS9ELElBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsTUFDRDtBQUFBLE1BRUQsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVsQyxLQUFLLElBQUlnQixZQUFZLE1BQU0sR0FDdEU7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRThCLE1BQU0sR0FBR0QsVUFBVSxJQUFJLEdBQ25DO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPNEI7QUFBQUEsWUFDUCxVQUFVLENBQUN4RSxNQUFNeUUsMkJBQTJCekUsRUFBRUMsT0FBT0MsS0FBSztBQUFBLFlBQzFELGFBQVk7QUFBQTtBQUFBLFVBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSW9DLEtBTHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUyQyxNQUFNLEdBQUdELFVBQVUsSUFBSSxHQUNuQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sTUFBSztBQUFBLFlBQ0wsT0FBTzhCO0FBQUFBLFlBQ1AsVUFBVSxDQUFDMUUsTUFBTTJFLHFCQUFxQjNFLEVBQUVDLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFVBSnREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl3RCxLQUwxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFMkMsTUFBTSxHQUFHRCxVQUFVLElBQUksR0FDbkM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE1BQUs7QUFBQSxZQUNMLE9BQU9nQztBQUFBQSxZQUNQLFVBQVUsQ0FBQzVFLE1BQU02RSxtQkFBbUI3RSxFQUFFQyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxVQUpwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJc0QsS0FMeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsTUFBSztBQUFBLFlBQ0wsU0FBUzRFLDJCQUEyQjFFO0FBQUFBLFlBQ3BDLFVBQVUsQ0FBQ29FLHdCQUF3QjdHLEtBQUssS0FBSyxDQUFDK0cscUJBQXFCLENBQUNFO0FBQUFBLFlBQ3BFLFNBQVMsTUFBTUUsMkJBQTJCekUsT0FBTztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBTHJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsV0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtDQTtBQUFBLFNBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwREE7QUFBQSxJQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFUCxTQUFTLFFBQVFDLEtBQUssSUFBSTBCLFdBQVcsOEJBQThCQyxZQUFZLEdBQUcsR0FDOUY7QUFBQSw2QkFBQyxVQUFLLE9BQU8sRUFBRUgsWUFBWSxJQUFJLEdBQUcseUNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQ7QUFBQSxNQUMzRCx1QkFBQyxVQUFLLE9BQU8sRUFBRTNCLE9BQU8sb0JBQW9CRCxVQUFVLFVBQVUsR0FBRyw4R0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQ3FFLE9BQU9uRDtBQUFBQSxRQUFJLENBQUNzRyxPQUFPdEIsVUFDbEIsdUJBQUMsU0FBZ0IsV0FBVSxzQkFBcUIsT0FBTyxFQUFFOUYsS0FBSyxJQUFJZ0IsWUFBWSxNQUFNLEdBQ2xGO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUU2QixVQUFVLElBQUksR0FDMUI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU91RSxNQUFNekI7QUFBQUEsY0FDYixVQUFVLENBQUMxRixNQUFNaUcsWUFBWUosT0FBTyxFQUFFSCxXQUFXSCxPQUFPdkYsRUFBRUMsT0FBT0MsS0FBSyxFQUFFLENBQUM7QUFBQSxjQUV4RTRDLHlCQUFlakM7QUFBQUEsZ0JBQUksQ0FBQzlFLE9BQU9xTCxRQUMxQix1QkFBQyxZQUFpQixPQUFPQSxLQUN0QnJMLG1CQURVcUwsS0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFeEUsVUFBVSxJQUFJLEdBQzFCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixNQUFLO0FBQUEsY0FDTCxPQUFPdUUsTUFBTW5DO0FBQUFBLGNBQ2IsVUFBVSxDQUFDaEYsTUFBTWlHLFlBQVlKLE9BQU8sRUFBRWIsT0FBT2hGLEVBQUVDLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsWUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSWlFLEtBTG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFMEMsVUFBVSxJQUFJLEdBQzFCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixNQUFLO0FBQUEsY0FDTCxPQUFPdUUsTUFBTXhCLGdCQUFnQnBCLFNBQVM7QUFBQSxjQUN0QyxVQUFVLENBQUN2RSxNQUFNaUcsWUFBWUosT0FBTyxFQUFFRixpQkFBaUJKLE9BQU92RixFQUFFQyxPQUFPQyxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUEsWUFKakY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSW1GLEtBTHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTLE1BQU0wRixZQUFZQyxLQUFLLEdBQUcsdUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQWhDUUEsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsTUFDRDtBQUFBLE1BQ0QsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFOUYsS0FBSyxHQUFHLEdBQ3ZDO0FBQUEsK0JBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFNBQVN5RixVQUFVLGlDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixNQUFLO0FBQUEsWUFDTCxTQUFTSCx5QkFBeUJqRjtBQUFBQSxZQUNsQyxTQUFTLE1BQU1pRix5QkFBeUJoRixPQUFPO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFKbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLFNBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1REE7QUFBQSxJQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFUCxTQUFTLFFBQVFDLEtBQUssSUFBSTBCLFdBQVcsOEJBQThCQyxZQUFZLEdBQUcsR0FDOUY7QUFBQSw2QkFBQyxVQUFLLE9BQU8sRUFBRUgsWUFBWSxJQUFJLEdBQUcsZ0NBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Q7QUFBQSxNQUNsRCx1QkFBQyxVQUFLLE9BQU8sRUFBRTNCLE9BQU8sd0JBQXdCRCxVQUFVLFVBQVUsR0FBRyw0S0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQyxDQUFDd0csc0JBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUV2RyxPQUFPLG9CQUFvQkQsVUFBVSxVQUFVLEdBQUcsd0dBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUYsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVJLEtBQUssSUFBSWdCLFlBQVksTUFBTSxHQUN0RTtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFNkIsVUFBVSxJQUFJLEdBQzFCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixNQUFLO0FBQUEsWUFDTCxPQUFPc0I7QUFBQUEsWUFDUCxVQUFVLENBQUNsRSxNQUFNbUUsWUFBWW5FLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxZQUMzQyxVQUFVLENBQUNpRztBQUFBQSxZQUNYLGFBQVk7QUFBQTtBQUFBLFVBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXVCLEtBUHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLE1BQUs7QUFBQSxZQUNMLFNBQVNiLG9CQUFvQmxGO0FBQUFBLFlBQzdCLFVBQVUsQ0FBQytGO0FBQUFBLFlBQ1gsU0FBUyxNQUFNYixvQkFBb0JqRixPQUFPO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFMOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxXQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsU0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlDQTtBQUFBLE9BaFJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpUkE7QUFFSjtBQUFDMkMsSUF4WVFELDJCQUF5QjtBQUFBLFVBQ1o3SSxnQkFDTm9CLFVBRU1yQixVQVlPQSxVQU9FQSxVQVFFQSxVQU9KQSxVQUtEQSxVQXFCU0QsYUFrQkFBLGFBU0ZBLGFBU0xBLFdBQVc7QUFBQTtBQUFBLE1BcEdoQytJO0FBQXlCLElBQUFzRSxJQUFBQyxLQUFBQztBQUFBLGFBQUFGLElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTGluayIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsImNyZWF0ZUlGb29kSW50ZXJydXB0aW9uIiwiZGVsZXRlSUZvb2RJbnRlcnJ1cHRpb24iLCJnZXRJRm9vZEZpbmFuY2lhbFN1bW1hcnkiLCJnZXRJRm9vZEludGVycnVwdGlvbnMiLCJnZXRJRm9vZE1lcmNoYW50RGV0YWlscyIsImdldElGb29kTWVyY2hhbnRNYXBwaW5ncyIsImdldElGb29kTWVyY2hhbnRzTGlzdCIsImdldElGb29kTWVyY2hhbnRTdGF0dXMiLCJnZXRJRm9vZE1lcmNoYW50U3RhdHVzQnlPcGVyYXRpb24iLCJnZXRJRm9vZE9wZW5pbmdIb3VycyIsImdldElGb29kU2V0dGluZ3MiLCJzYXZlSUZvb2RPcGVuaW5nSG91cnMiLCJzYXZlSUZvb2RTZXR0aW5ncyIsInNldElGb29kTWVyY2hhbnRNYXBwaW5nIiwic2V0SUZvb2RQcmVwYXJhdGlvblRpbWUiLCJzeW5jSUZvb2RDYXRhbG9nIiwic3luY0lGb29kRmluYW5jaWFsIiwidGVzdElGb29kQ29ubmVjdGlvbiIsInVzZUF1dGhTdG9yZSIsInVzZVRvYXN0IiwiRmllbGQiLCJTZWxlY3RGaWVsZCIsIlRleHRGaWVsZCIsIkJ1dHRvbiIsIlN3aXRjaCIsIlF1ZXJ5RXJyb3IiLCJDT05ORUNUSU9OX1NUQVRVU19NRVRBIiwiY29ubmVjdGVkIiwibGFiZWwiLCJkb3QiLCJmYWlsZWQiLCJ1bnRlc3RlZCIsImdldENvbm5lY3Rpb25TdGF0dXNLZXkiLCJsYXN0VGVzdCIsIklGb29kSW50ZWdyYXRpb25QYWdlIiwiX3MiLCJxdWVyeUNsaWVudCIsInRvYXN0IiwiY29tcGFueUlkIiwicmF3Q29tcGFueUlkIiwiY2xpZW50SWQiLCJzZXRDbGllbnRJZCIsImNsaWVudFNlY3JldCIsInNldENsaWVudFNlY3JldCIsImVuYWJsZWQiLCJzZXRFbmFibGVkIiwiaWZvb2RDdXN0b21lcklkIiwic2V0SWZvb2RDdXN0b21lcklkIiwiaW5pdGlhbGl6ZWRDb21wYW55SWQiLCJzZXRJbml0aWFsaXplZENvbXBhbnlJZCIsInNldHRpbmdzUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJkYXRhIiwic2F2ZU11dGF0aW9uIiwibXV0YXRpb25GbiIsInRyaW0iLCJvblN1Y2Nlc3MiLCJzdWNjZXNzIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJvbkVycm9yIiwiZXJyb3IiLCJ0ZXN0TXV0YXRpb24iLCJyZXN1bHQiLCJlcnJvck1lc3NhZ2UiLCJtYXBwaW5nc1F1ZXJ5Iiwic3luY0NhdGFsb2dNdXRhdGlvbiIsInN1bW1hcnkiLCJza2lwcGVkIiwiZXJyb3JTdWZmaXgiLCJlcnJvcnMiLCJwcm9kdWN0c1N5bmNlZCIsImJyYW5jaGVzU3luY2VkIiwiZmlyc3RNYXBwZWRCcmFuY2giLCJmaW5kIiwibSIsIm1lcmNoYW50SWQiLCJmaW5hbmNpYWxTdW1tYXJ5UXVlcnkiLCJicmFuY2hJZCIsInN5bmNGaW5hbmNpYWxNdXRhdGlvbiIsImxhc3RDb25uZWN0aW9uVGVzdFN1Y2NlZWRlZCIsImNvbm5lY3Rpb25TdGF0dXMiLCJzdGF0dXNMYWJlbCIsInN0YXR1c0RvdCIsInBhZGRpbmciLCJtYXhXaWR0aCIsIm1hcmdpbiIsIm1hcmdpbkJvdHRvbSIsImZvbnRTaXplIiwiY29sb3IiLCJpc0Vycm9yIiwiZGlzcGxheSIsImdhcCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImhhc0NyZWRlbnRpYWxzIiwiaXNQZW5kaW5nIiwibXV0YXRlIiwibWFyZ2luVG9wIiwianVzdGlmeUNvbnRlbnQiLCJsYXN0Q29ubmVjdGlvblRlc3RBdCIsIkRhdGUiLCJ0b0xvY2FsZVN0cmluZyIsImlzTG9hZGluZyIsImxlbmd0aCIsIm1hcCIsIm1hcHBpbmciLCJhbGlnbkl0ZW1zIiwidG90YWxGaW5hbmNpYWxFdmVudHNXaXRoVHJhbnNmZXJJbXBhY3QiLCJzdHlsZSIsImN1cnJlbmN5IiwidG90YWxTZXR0bGVtZW50cyIsImhhc0Rpc2NyZXBhbmN5IiwiZGlzY3JlcGFuY3lBbW91bnQiLCJzZXR0bGVtZW50cyIsImZvbnRXZWlnaHQiLCJzIiwiYm9yZGVyVG9wIiwicGFkZGluZ1RvcCIsInR5cGUiLCJwcm9kdWN0Iiwic3RhdHVzIiwicGF5bWVudERhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJhbW91bnQiLCJpZCIsImV2ZW50cyIsInBhZGRpbmdMZWZ0IiwiTWVyY2hhbnRNYXBwaW5nUm93Iiwib25TYXZlZCIsIl9zMiIsInNldE1lcmNoYW50SWQiLCJtZXJjaGFudFV1aWQiLCJzZXRNZXJjaGFudFV1aWQiLCJtdXRhdGlvbiIsImJyYW5jaE5hbWUiLCJtaW5XaWR0aCIsImZsZXgiLCJXRUVLREFZX0xBQkVMUyIsIk1lcmNoYW50T3BlcmF0aW9uc1NlY3Rpb24iLCJfczMiLCJzdGF0dXNRdWVyeSIsInJldHJ5Iiwic2hvd01lcmNoYW50c0xpc3QiLCJzZXRTaG93TWVyY2hhbnRzTGlzdCIsIm1lcmNoYW50c0xpc3RRdWVyeSIsInNob3dNZXJjaGFudERldGFpbHMiLCJzZXRTaG93TWVyY2hhbnREZXRhaWxzIiwibWVyY2hhbnREZXRhaWxzUXVlcnkiLCJvcGVyYXRpb25RdWVyeSIsInNldE9wZXJhdGlvblF1ZXJ5Iiwib3BlcmF0aW9uTG9va3VwIiwic2V0T3BlcmF0aW9uTG9va3VwIiwic3RhdHVzQnlPcGVyYXRpb25RdWVyeSIsImludGVycnVwdGlvbnNRdWVyeSIsIm9wZW5pbmdIb3Vyc1F1ZXJ5Iiwic2hpZnRzIiwic2V0U2hpZnRzIiwicHJlcFRpbWUiLCJzZXRQcmVwVGltZSIsImluaXRpYWxpemVkQnJhbmNoSWQiLCJzZXRJbml0aWFsaXplZEJyYW5jaElkIiwicHJlcGFyYXRpb25UaW1lTWludXRlcyIsInRvU3RyaW5nIiwiaW50ZXJydXB0aW9uRGVzY3JpcHRpb24iLCJzZXRJbnRlcnJ1cHRpb25EZXNjcmlwdGlvbiIsImludGVycnVwdGlvblN0YXJ0Iiwic2V0SW50ZXJydXB0aW9uU3RhcnQiLCJpbnRlcnJ1cHRpb25FbmQiLCJzZXRJbnRlcnJ1cHRpb25FbmQiLCJjcmVhdGVJbnRlcnJ1cHRpb25NdXRhdGlvbiIsImRlc2NyaXB0aW9uIiwic3RhcnQiLCJ0b0lTT1N0cmluZyIsImVuZCIsImRlbGV0ZUludGVycnVwdGlvbk11dGF0aW9uIiwiaW50ZXJydXB0aW9uSWQiLCJzYXZlT3BlbmluZ0hvdXJzTXV0YXRpb24iLCJzZXRQcmVwVGltZU11dGF0aW9uIiwiTnVtYmVyIiwiYWRkU2hpZnQiLCJwcmV2IiwiZGF5T2ZXZWVrIiwiZHVyYXRpb25NaW51dGVzIiwicmVtb3ZlU2hpZnQiLCJpbmRleCIsImZpbHRlciIsIl8iLCJpIiwidXBkYXRlU2hpZnQiLCJwYXRjaCIsImhhc0lGb29kQ3VzdG9tZXJJZCIsImlzRmV0Y2hpbmciLCJyZWZldGNoIiwib3BlcmF0aW9uU3RhdGUiLCJ2YWxpZGF0aW9ucyIsInYiLCJzdGF0ZSIsIm1lc3NhZ2UiLCJuYW1lIiwiY29ycG9yYXRlTmFtZSIsImFkZHJlc3MiLCJzdHJlZXQiLCJudW1iZXIiLCJjaXR5Iiwib3BlcmF0aW9uIiwiYXZhaWxhYmxlIiwic2hpZnQiLCJkYXkiLCJfYyIsIl9jMiIsIl9jMyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJJRm9vZEludGVncmF0aW9uUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdHlwZSBDU1NQcm9wZXJ0aWVzIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQge1xyXG4gIGNyZWF0ZUlGb29kSW50ZXJydXB0aW9uLFxyXG4gIGRlbGV0ZUlGb29kSW50ZXJydXB0aW9uLFxyXG4gIGdldElGb29kRmluYW5jaWFsU3VtbWFyeSxcclxuICBnZXRJRm9vZEludGVycnVwdGlvbnMsXHJcbiAgZ2V0SUZvb2RNZXJjaGFudERldGFpbHMsXHJcbiAgZ2V0SUZvb2RNZXJjaGFudE1hcHBpbmdzLFxyXG4gIGdldElGb29kTWVyY2hhbnRzTGlzdCxcclxuICBnZXRJRm9vZE1lcmNoYW50U3RhdHVzLFxyXG4gIGdldElGb29kTWVyY2hhbnRTdGF0dXNCeU9wZXJhdGlvbixcclxuICBnZXRJRm9vZE9wZW5pbmdIb3VycyxcclxuICBnZXRJRm9vZFNldHRpbmdzLFxyXG4gIHNhdmVJRm9vZE9wZW5pbmdIb3VycyxcclxuICBzYXZlSUZvb2RTZXR0aW5ncyxcclxuICBzZXRJRm9vZE1lcmNoYW50TWFwcGluZyxcclxuICBzZXRJRm9vZFByZXBhcmF0aW9uVGltZSxcclxuICBzeW5jSUZvb2RDYXRhbG9nLFxyXG4gIHN5bmNJRm9vZEZpbmFuY2lhbCxcclxuICB0ZXN0SUZvb2RDb25uZWN0aW9uLFxyXG4gIHR5cGUgSUZvb2RPcGVuaW5nSG91clNoaWZ0LFxyXG59IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi8uLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyBGaWVsZCwgU2VsZWN0RmllbGQsIFRleHRGaWVsZCB9IGZyb20gXCIuLi8uLi91aS9GaWVsZFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IFN3aXRjaCB9IGZyb20gXCIuLi8uLi91aS9Td2l0Y2hcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuXHJcbi8vIEV4dHJhw61kbyBkbyB0ZXJuw6FyaW8gYW5pbmhhZG8gcXVlIGRlY2lkaWEgbGFiZWwgKyBjb3IgZG8gc3RhdHVzIGRlIGNvbmV4w6NvIGEgcGFydGlyIGRvXHJcbi8vIMO6bHRpbW8gdGVzdGUgKHRydWUvZmFsc2UvbnVsbCkg4oCUIG1lc21vIHBhZHLDo28gZGUgbG9va3VwIHVzYWRvIGVtIG91dHJhcyB0ZWxhcyAoZXguOiBtYXBhc1xyXG4vLyB0aXBvIFRSRU5EX01FVEEvU0VWRVJJVFlfSUNPTikuXHJcbmNvbnN0IENPTk5FQ1RJT05fU1RBVFVTX01FVEE6IFJlY29yZDxcImNvbm5lY3RlZFwiIHwgXCJmYWlsZWRcIiB8IFwidW50ZXN0ZWRcIiwgeyBsYWJlbDogc3RyaW5nOyBkb3Q6IHN0cmluZyB9PiA9IHtcclxuICBjb25uZWN0ZWQ6IHsgbGFiZWw6IFwiQ29uZWN0YWRvXCIsIGRvdDogXCJ2YXIoLS1vaylcIiB9LFxyXG4gIGZhaWxlZDogeyBsYWJlbDogXCJGYWxob3Ugbm8gw7psdGltbyB0ZXN0ZVwiLCBkb3Q6IFwidmFyKC0tZGFuZ2VyKVwiIH0sXHJcbiAgdW50ZXN0ZWQ6IHsgbGFiZWw6IFwiTnVuY2EgdGVzdGFkb1wiLCBkb3Q6IFwidmFyKC0taW5rLWZhaW50KVwiIH0sXHJcbn07XHJcblxyXG5mdW5jdGlvbiBnZXRDb25uZWN0aW9uU3RhdHVzS2V5KGxhc3RUZXN0OiBib29sZWFuIHwgbnVsbCB8IHVuZGVmaW5lZCk6IFwiY29ubmVjdGVkXCIgfCBcImZhaWxlZFwiIHwgXCJ1bnRlc3RlZFwiIHtcclxuICBpZiAobGFzdFRlc3QgPT09IHRydWUpIHJldHVybiBcImNvbm5lY3RlZFwiO1xyXG4gIGlmIChsYXN0VGVzdCA9PT0gZmFsc2UpIHJldHVybiBcImZhaWxlZFwiO1xyXG4gIHJldHVybiBcInVudGVzdGVkXCI7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJRm9vZEludGVncmF0aW9uUGFnZSgpIHtcclxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG4gIGNvbnN0IHsgY29tcGFueUlkOiByYXdDb21wYW55SWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IGNvbXBhbnlJZCA9IHJhd0NvbXBhbnlJZCA/PyAxO1xyXG5cclxuICBjb25zdCBbY2xpZW50SWQsIHNldENsaWVudElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjbGllbnRTZWNyZXQsIHNldENsaWVudFNlY3JldF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZW5hYmxlZCwgc2V0RW5hYmxlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lmb29kQ3VzdG9tZXJJZCwgc2V0SWZvb2RDdXN0b21lcklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpbml0aWFsaXplZENvbXBhbnlJZCwgc2V0SW5pdGlhbGl6ZWRDb21wYW55SWRdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IHNldHRpbmdzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJzZXR0aW5nc1wiLCBjb21wYW55SWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RTZXR0aW5ncyhjb21wYW55SWQpLFxyXG4gIH0pO1xyXG5cclxuICAvLyBTw7MgcHJlZW5jaGUgbyBmb3JtdWzDoXJpbyBhIHBhcnRpciBkbyBzZXJ2aWRvciBVTUEgdmV6IHBvciBlbXByZXNhIOKAlCBkZXBvaXMgZGlzc28gb1xyXG4gIC8vIHVzdcOhcmlvIMOpIGRvbm8gZG8gcXVlIGVzdMOhIGRpZ2l0YWRvIChldml0YSBhcGFnYXIgZWRpw6fDo28gZW0gYW5kYW1lbnRvIHNlIGEgcXVlcnkgcmVmaXplclxyXG4gIC8vIGZldGNoIGVtIHNlZ3VuZG8gcGxhbm8sIGV4LjogYW8gdm9sdGFyIG8gZm9jbyBwcmEgYWJhKS5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHNldHRpbmdzUXVlcnkuZGF0YSAmJiBpbml0aWFsaXplZENvbXBhbnlJZCAhPT0gY29tcGFueUlkKSB7XHJcbiAgICAgIHNldENsaWVudElkKHNldHRpbmdzUXVlcnkuZGF0YS5jbGllbnRJZCA/PyBcIlwiKTtcclxuICAgICAgc2V0RW5hYmxlZChzZXR0aW5nc1F1ZXJ5LmRhdGEuZW5hYmxlZCk7XHJcbiAgICAgIHNldElmb29kQ3VzdG9tZXJJZChzZXR0aW5nc1F1ZXJ5LmRhdGEuaWZvb2RDdXN0b21lcklkID8/IFwiXCIpO1xyXG4gICAgICBzZXRJbml0aWFsaXplZENvbXBhbnlJZChjb21wYW55SWQpO1xyXG4gICAgfVxyXG4gIH0sIFtzZXR0aW5nc1F1ZXJ5LmRhdGEsIGNvbXBhbnlJZCwgaW5pdGlhbGl6ZWRDb21wYW55SWRdKTtcclxuXHJcbiAgY29uc3Qgc2F2ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgc2F2ZUlGb29kU2V0dGluZ3Moe1xyXG4gICAgICAgIGNvbXBhbnlJZCxcclxuICAgICAgICBjbGllbnRJZDogY2xpZW50SWQudHJpbSgpLFxyXG4gICAgICAgIGNsaWVudFNlY3JldDogY2xpZW50U2VjcmV0LnRyaW0oKSxcclxuICAgICAgICBlbmFibGVkLFxyXG4gICAgICAgIGlmb29kQ3VzdG9tZXJJZDogaWZvb2RDdXN0b21lcklkLnRyaW0oKSxcclxuICAgICAgfSksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNyZWRlbmNpYWlzIGRvIGlGb29kIHNhbHZhcy5cIik7XHJcbiAgICAgIHNldENsaWVudFNlY3JldChcIlwiKTsgLy8gbnVuY2EgcmVleGliZSBvIHNlZ3JlZG8g4oCUIGxpbXBhIG8gY2FtcG8gYXDDs3Mgc2FsdmFyXHJcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJzZXR0aW5nc1wiXSB9KTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBzYWx2YXIgYXMgY3JlZGVuY2lhaXMuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB0ZXN0TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiB0ZXN0SUZvb2RDb25uZWN0aW9uKGNvbXBhbnlJZCksXHJcbiAgICBvblN1Y2Nlc3M6IChyZXN1bHQpID0+IHtcclxuICAgICAgaWYgKHJlc3VsdC5zdWNjZXNzKSB0b2FzdC5zdWNjZXNzKFwiQ29uZWN0YWRvIGFvIGlGb29kIGNvbSBzdWNlc3NvLlwiKTtcclxuICAgICAgZWxzZSB0b2FzdC5lcnJvcihyZXN1bHQuZXJyb3JNZXNzYWdlID8/IFwiRmFsaGEgYW8gY29uZWN0YXIg4oCUIGNvbmZpcmEgYXMgY3JlZGVuY2lhaXMuXCIpO1xyXG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwic2V0dGluZ3NcIl0gfSk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgdGVzdGFyIGEgY29uZXjDo28uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBtYXBwaW5nc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwibWVyY2hhbnRzXCIsIGNvbXBhbnlJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZE1lcmNoYW50TWFwcGluZ3MoY29tcGFueUlkKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc3luY0NhdGFsb2dNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IHN5bmNJRm9vZENhdGFsb2coY29tcGFueUlkKSxcclxuICAgIG9uU3VjY2VzczogKHN1bW1hcnkpID0+IHtcclxuICAgICAgaWYgKHN1bW1hcnkuc2tpcHBlZCkge1xyXG4gICAgICAgIHRvYXN0LmVycm9yKFwiSW50ZWdyYcOnw6NvIGRlc2FiaWxpdGFkYSBvdSBuZW5odW1hIGxvamEgY29tIE1lcmNoYW50IElEIGNvbmZpZ3VyYWRvIOKAlCBuYWRhIGZvaSBzaW5jcm9uaXphZG8uXCIpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG4gICAgICBjb25zdCBlcnJvclN1ZmZpeCA9IHN1bW1hcnkuZXJyb3JzID4gMCA/IGAgKCR7c3VtbWFyeS5lcnJvcnN9IGVycm8ke3N1bW1hcnkuZXJyb3JzID09PSAxID8gXCJcIiA6IFwic1wifSlgIDogXCJcIjtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcclxuICAgICAgICBgQ2FyZMOhcGlvIHNpbmNyb25pemFkbzogJHtzdW1tYXJ5LnByb2R1Y3RzU3luY2VkfSBwcm9kdXRvKHMpIGVtICR7c3VtbWFyeS5icmFuY2hlc1N5bmNlZH0gbG9qYShzKSR7ZXJyb3JTdWZmaXh9LmAsXHJcbiAgICAgICk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKCkgPT4gdG9hc3QuZXJyb3IoXCJOw6NvIGZvaSBwb3Nzw612ZWwgc2luY3Jvbml6YXIgbyBjYXJkw6FwaW8gY29tIG8gaUZvb2QuXCIpLFxyXG4gIH0pO1xyXG5cclxuICAvLyBGaW5hbmNlaXJvIMOpIHBvciBGSUxJQUwgKG8gcmVwYXNzZSBkbyBpRm9vZCDDqSBwb3IgbG9qYSkg4oCUIHVzYSBhIHByaW1laXJhIGxvamEgasOhIG1hcGVhZGFcclxuICAvLyBjb20gTWVyY2hhbnRJZCBjb21vIHBhZHLDo28uIFNlbGV0b3IgZGUgbG9qYSBmaWNhIHByYSBxdWFuZG8gaG91dmVyIG1haXMgZGUgdW1hIGNvbmZpZ3VyYWRhXHJcbiAgLy8gY29tIGZyZXF1w6puY2lhIChob2plIG8gdXN1w6FyaW8gZGUgdGVzdGUgdGVtIHPDsyBhIFwiTWF0cml6XCIpLlxyXG4gIGNvbnN0IGZpcnN0TWFwcGVkQnJhbmNoID0gKG1hcHBpbmdzUXVlcnkuZGF0YSA/PyBbXSkuZmluZCgobSkgPT4gISFtLm1lcmNoYW50SWQpO1xyXG5cclxuICBjb25zdCBmaW5hbmNpYWxTdW1tYXJ5UXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJmaW5hbmNpYWxcIiwgZmlyc3RNYXBwZWRCcmFuY2g/LmJyYW5jaElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldElGb29kRmluYW5jaWFsU3VtbWFyeShmaXJzdE1hcHBlZEJyYW5jaCEuYnJhbmNoSWQpLFxyXG4gICAgZW5hYmxlZDogISFmaXJzdE1hcHBlZEJyYW5jaCxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc3luY0ZpbmFuY2lhbE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gc3luY0lGb29kRmluYW5jaWFsKGNvbXBhbnlJZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIlNpbmNyb25pemHDp8OjbyBmaW5hbmNlaXJhIGRpc3BhcmFkYSDigJQgb3MgZGFkb3MgYXBhcmVjZW0gYXF1aSBlbSBpbnN0YW50ZXMuXCIpO1xyXG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwiZmluYW5jaWFsXCJdIH0pO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIGRpc3BhcmFyIGEgc2luY3Jvbml6YcOnw6NvIGZpbmFuY2VpcmEuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBsYXN0VGVzdCA9IHNldHRpbmdzUXVlcnkuZGF0YT8ubGFzdENvbm5lY3Rpb25UZXN0U3VjY2VlZGVkO1xyXG4gIGNvbnN0IGNvbm5lY3Rpb25TdGF0dXMgPSBDT05ORUNUSU9OX1NUQVRVU19NRVRBW2dldENvbm5lY3Rpb25TdGF0dXNLZXkobGFzdFRlc3QpXTtcclxuICBjb25zdCBzdGF0dXNMYWJlbCA9IGNvbm5lY3Rpb25TdGF0dXMubGFiZWw7XHJcbiAgY29uc3Qgc3RhdHVzRG90ID0gY29ubmVjdGlvblN0YXR1cy5kb3Q7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDkwMCwgbWFyZ2luOiBcIjAgYXV0b1wiIH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2VcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDE4IH19PlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS43cmVtXCIgfX0+XHJcbiAgICAgICAgICBJbnRlZ3Jhw6fDo28gaUZvb2RcclxuICAgICAgICA8L2gyPlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+XHJcbiAgICAgICAgICBjcmVkZW5jaWFpcyBkbyBhcHAgKHBvciBlbXByZXNhKSArIGxvamFzIGNvbmVjdGFkYXMg4oCUIHNvbWVudGUgZ2VyZW50ZS9hZG1pbmlzdHJhZG9yXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtzZXR0aW5nc1F1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e3NldHRpbmdzUXVlcnkuZXJyb3J9IHdoYXQ9XCJhIGludGVncmHDp8OjbyBjb20gbyBpRm9vZFwiIC8+fVxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidGlja2V0IHJpc2UgcmlzZS0xXCIgc3R5bGU9e3sgcGFkZGluZzogMjAsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE2IH19PlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5cclxuICAgICAgICAgICAgQ3JlZGVuY2lhaXMgZG8gYXBsaWNhdGl2b1xyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45MnJlbVwiIH19PlxyXG4gICAgICAgICAgICBDbGllbnQgSUQgZSBDbGllbnQgU2VjcmV0IHbDqm0gZGUgXCJNZXVzIGFwbGljYXRpdm9zXCIgbm8gcG9ydGFsIGRvIGlGb29kIERldmVsb3BlciDigJRcclxuICAgICAgICAgICAgdW0gw7puaWNvIGFwcCBwb2RlIGRhciBhY2Vzc28gYSB2w6FyaWFzIGxvamFzLCBlbnTDo28gZXNzYXMgY3JlZGVuY2lhaXMgdmFsZW0gcHJhXHJcbiAgICAgICAgICAgIGVtcHJlc2EgaW50ZWlyYSAoY2FkYSBsb2phIGluZGl2aWR1YWwgw6kgY29uZmlndXJhZGEgbmEgc2XDp8OjbyBcIkxvamFzXCIgYWJhaXhvKS5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgbGFiZWw9XCJDbGllbnQgSURcIlxyXG4gICAgICAgICAgdmFsdWU9e2NsaWVudElkfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDbGllbnRJZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4LjogM2Y5YTFjMmItLi4uXCJcclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICBsYWJlbD1cIkNsaWVudCBTZWNyZXRcIlxyXG4gICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgIHZhbHVlPXtjbGllbnRTZWNyZXR9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENsaWVudFNlY3JldChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj17c2V0dGluZ3NRdWVyeS5kYXRhPy5oYXNDcmVkZW50aWFscyA/IFwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiIChkZWl4ZSBlbSBicmFuY28gcGFyYSBtYW50ZXIgbyBhdHVhbClcIiA6IFwiY29sZSBvIENsaWVudCBTZWNyZXQgYXF1aVwifVxyXG4gICAgICAgICAgaGludD1cIkZpY2EgY3JpcHRvZ3JhZmFkbyBubyBiYW5jbyDigJQgZXN0YSB0ZWxhIG51bmNhIHJlZXhpYmUgbyB2YWxvciBqw6Egc2Fsdm8uXCJcclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICBsYWJlbD1cImlGb29kIEN1c3RvbWVyIElEIChvcGNpb25hbClcIlxyXG4gICAgICAgICAgdmFsdWU9e2lmb29kQ3VzdG9tZXJJZH1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SWZvb2RDdXN0b21lcklkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwibmVjZXNzw6FyaW8gc8OzIHBhcmEgY29uZmlndXJhciB0ZW1wbyBkZSBwcmVwYXJvIChzZcOnw6NvIE9wZXJhw6fDo28gZGEgbG9qYSlcIlxyXG4gICAgICAgICAgaGludD1cIk7Do28gw6kgc2VncmVkbyDigJQgZmljYSBzYWx2byBlbSB0ZXh0byBwdXJvLiBTZW0gZWxlLCBvIHJlc3RvIGRhIGludGVncmHDp8OjbyBmdW5jaW9uYSBub3JtYWxtZW50ZSwgc8OzIG8gY2FtcG8gZGUgdGVtcG8gZGUgcHJlcGFybyBmaWNhIGRlc2FiaWxpdGFkby5cIlxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxGaWVsZCBsYWJlbD1cIkludGVncmHDp8OjbyBhdGl2YVwiPlxyXG4gICAgICAgICAgeygpID0+IChcclxuICAgICAgICAgICAgPFN3aXRjaFxyXG4gICAgICAgICAgICAgIGNoZWNrZWQ9e2VuYWJsZWR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldEVuYWJsZWR9XHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJBdGl2YXIgaW50ZWdyYcOnw6NvIGNvbSBvIGlGb29kXCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2ZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9GaWVsZD5cclxuXHJcbiAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgdmFyaWFudD1cInByaW1hcnlcIlxyXG4gICAgICAgICAgbG9hZGluZz17c2F2ZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgIGRpc2FibGVkPXtlbmFibGVkICYmIGNsaWVudElkLnRyaW0oKSA9PT0gXCJcIn1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNhdmVNdXRhdGlvbi5tdXRhdGUoKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBTYWx2YXIgY3JlZGVuY2lhaXNcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidGlja2V0IHJpc2UgcmlzZS0yXCIgc3R5bGU9e3sgcGFkZGluZzogMjAsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyLCBtYXJnaW5Ub3A6IDE2IH19PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBnYXA6IDE2IH19PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0LCBtYXhXaWR0aDogNTIwIH19PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgQ29uZXjDo29cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgVGVzdGEgYXMgY3JlZGVuY2lhaXMgc2FsdmFzIGNvbnRyYSBvIGlGb29kIChhdXRlbnRpY2HDp8OjbyBPQXV0aDIpLiBTw7MgZnVuY2lvbmFcclxuICAgICAgICAgICAgICBkZXBvaXMgcXVlIHZvY8OqIHRpdmVyIGNyZWRlbmNpYWlzIHJlYWlzIGRlIHRlc3RlL3NhbmRib3ggb3UgcHJvZHXDp8Ojby5cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogMTIgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNoaXBcIiBzdHlsZT17eyBcIi0tZG90XCI6IHN0YXR1c0RvdCB9IGFzIENTU1Byb3BlcnRpZXN9PlxyXG4gICAgICAgICAgICAgIHtzdGF0dXNMYWJlbH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgICBsb2FkaW5nPXt0ZXN0TXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXshc2V0dGluZ3NRdWVyeS5kYXRhPy5oYXNDcmVkZW50aWFsc31cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0ZXN0TXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBUZXN0YXIgY29uZXjDo29cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7c2V0dGluZ3NRdWVyeS5kYXRhPy5sYXN0Q29ubmVjdGlvblRlc3RBdCAmJiAoXHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODJyZW1cIiB9fT5cclxuICAgICAgICAgICAgw5psdGltbyB0ZXN0ZToge25ldyBEYXRlKHNldHRpbmdzUXVlcnkuZGF0YS5sYXN0Q29ubmVjdGlvblRlc3RBdCkudG9Mb2NhbGVTdHJpbmcoXCJwdC1CUlwiKX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTNcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTQsIG1hcmdpblRvcDogMTYgfX0+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMnJlbVwiIH19PlxyXG4gICAgICAgICAgICBMb2phcyAobWVyY2hhbnRzKVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45MnJlbVwiIH19PlxyXG4gICAgICAgICAgICBDYWRhIGZpbGlhbCBwcmVjaXNhIGRvIHNldSBNZXJjaGFudElkIGRvIGlGb29kIOKAlCBlbmNvbnRyYWRvIG5hIHRlbGEgXCJQZXJtaXNzw7Vlc1wiIGRvXHJcbiAgICAgICAgICAgIHNldSBhcHAgbm8gcG9ydGFsIChvdSBlbSBcIlRlc3Rlc1wiIOKGkiBkYWRvcyBkYSBsb2phIGRlIHRlc3RlKS4gTyBNZXJjaGFudFV1aWQgw6kgdXNhZG9cclxuICAgICAgICAgICAgc8OzIGVtIGFsZ3VtYXMgY2hhbWFkYXMgZXNwZWPDrWZpY2FzOyBwb2RlIGRlaXhhciBlbSBicmFuY28gc2UgbsOjbyB0aXZlciBhaW5kYS5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge21hcHBpbmdzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17bWFwcGluZ3NRdWVyeS5lcnJvcn0gd2hhdD1cImFzIGxvamFzXCIgLz59XHJcbiAgICAgICAgeyFtYXBwaW5nc1F1ZXJ5LmlzTG9hZGluZyAmJiAobWFwcGluZ3NRdWVyeS5kYXRhPy5sZW5ndGggPz8gMCkgPT09IDAgJiYgKFxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjg4cmVtXCIgfX0+XHJcbiAgICAgICAgICAgIE5lbmh1bWEgZmlsaWFsIGF0aXZhIGNhZGFzdHJhZGEgYWluZGEuXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgeyhtYXBwaW5nc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgobWFwcGluZykgPT4gKFxyXG4gICAgICAgICAgPE1lcmNoYW50TWFwcGluZ1Jvd1xyXG4gICAgICAgICAgICBrZXk9e21hcHBpbmcuYnJhbmNoSWR9XHJcbiAgICAgICAgICAgIG1hcHBpbmc9e21hcHBpbmd9XHJcbiAgICAgICAgICAgIG9uU2F2ZWQ9eygpID0+IHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJtZXJjaGFudHNcIl0gfSl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTNcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIsIG1hcmdpblRvcDogMTYgfX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMTYsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5cclxuICAgICAgICAgICAgICBQZWRpZG9zXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45MnJlbVwiIH19PlxyXG4gICAgICAgICAgICAgIFJlY2ViaW1lbnRvIGF1dG9tw6F0aWNvIChhIGNhZGEgMzBzKSwgY29uZmlybWHDp8OjbyBkZW50cm8gZG8gcHJhem8gZGUgOCBtaW51dG9zLCBlXHJcbiAgICAgICAgICAgICAgYXZhbsOnbyBtYW51YWwgZGUgc3RhdHVzIChpbmljaWFyIHByZXBhcm8sIHByb250bywgY2FuY2VsYXIpIHBlbGEgdGVsYSBkZSBwZWRpZG9zLlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxMaW5rIHRvPVwiL2ludGVncmFjb2VzL2lmb29kL3BlZGlkb3NcIj5cclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIj5WZXIgcGVkaWRvcyBpRm9vZDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTNcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIsIG1hcmdpblRvcDogMTYgfX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMTYsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIG1heFdpZHRoOiA1MjAgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5cclxuICAgICAgICAgICAgICBMb2fDrXN0aWNhIChmcm90YSBwcsOzcHJpYSlcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgRW50cmVndWUgY29tIGEgZXF1aXBlIGRhIHByw7NwcmlhIGNhc2EgcGVkaWRvcyBxdWUgdmllcmFtIGRvIGlGb29kIOKAlCBhdHJpYnVhIG9cclxuICAgICAgICAgICAgICBlbnRyZWdhZG9yIGUgYXZpc2UgY2FkYSBwYXNzbyAoc2FpdSwgY2hlZ291LCBkZXNwYWNob3UsIGVudHJlZ291KS5cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8TGluayB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZC9sb2dpc3RpY2FcIj5cclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIj5WZXIgbG9nw61zdGljYTwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTNcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIsIG1hcmdpblRvcDogMTYgfX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMTYsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIG1heFdpZHRoOiA1MjAgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5cclxuICAgICAgICAgICAgICBFbnRyZWdhcyBpRm9vZCAoU2hpcHBpbmcpXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45MnJlbVwiIH19PlxyXG4gICAgICAgICAgICAgIFBlw6dhIHVtIGVudHJlZ2Fkb3IgZG8gaUZvb2QgcHJhIHVtIHBlZGlkbyBkZSBvdXRybyBjYW5hbCAodGVsZWZvbmUsIFdoYXRzQXBwLCBiYWxjw6NvKVxyXG4gICAgICAgICAgICAgIOKAlCBjb3Rhw6fDo28gZGUgcHJlw6dvL3ByYXpvLCBhY29tcGFuaGFtZW50byBlIGNhbmNlbGFtZW50by4gVHVkbyBzb2IgZGVtYW5kYS5cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8TGluayB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZC9zaGlwcGluZ1wiPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiPlZlciBlbnRyZWdhcyBpRm9vZDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTNcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIsIG1hcmdpblRvcDogMTYgfX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMTYsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIG1heFdpZHRoOiA1MjAgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5cclxuICAgICAgICAgICAgICBDYXJkw6FwaW9cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgQ2F0ZWdvcmlhcyBlIHByb2R1dG9zIGF0aXZvcyBzw6NvIGVudmlhZG9zIHNvemluaG9zIHBybyBpRm9vZCBzZW1wcmUgcXVlIHZvY8OqXHJcbiAgICAgICAgICAgICAgY3JpYSwgZWRpdGEgb3UgZGVzYXRpdmEgYWxnbyBlbSBQcm9kdXRvcy4gVXNlIG8gYm90w6NvIGFvIGxhZG8gcHJhIHJlZW52aWFyIHR1ZG8gZGVcclxuICAgICAgICAgICAgICB1bWEgdmV6IChwcmltZWlyYSBjYXJnYSwgb3UgZGVwb2lzIGRlIHVtYSBmYWxoYSkuXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3dcIiBzdHlsZT17eyBnYXA6IDggfX0+XHJcbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL2ludGVncmFjb2VzL2lmb29kL2NhdGFsb2dvXCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIj5HZXJlbmNpYXIgY2F0w6Fsb2dvPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBsb2FkaW5nPXtzeW5jQ2F0YWxvZ011dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gc3luY0NhdGFsb2dNdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgICAgICAgU2luY3Jvbml6YXIgYWdvcmFcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidGlja2V0IHJpc2UgcmlzZS0zXCIgc3R5bGU9e3sgcGFkZGluZzogMjAsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDE0LCBtYXJnaW5Ub3A6IDE2IH19PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBnYXA6IDE2LCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0LCBtYXhXaWR0aDogNTIwIH19PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgRmluYW5jZWlyb1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuOTJyZW1cIiB9fT5cclxuICAgICAgICAgICAgICBUcmlsaGEgZGUgYXVkaXRvcmlhIGRvcyBsYW7Dp2FtZW50b3MgZSByZXBhc3NlcyBkbyBpRm9vZCAow7psdGltb3MgMzAgZGlhcykg4oCUIG7Do29cclxuICAgICAgICAgICAgICBzdWJzdGl0dWkgbyBmZWNoYW1lbnRvIGRlIGNhaXhhIGRvIFN5bmNCYXIsIMOpIHPDsyBwcmEgY29uZmVyaXIgbyBxdWUgbyBpRm9vZFxyXG4gICAgICAgICAgICAgIGNhbGN1bG91LiBTaW5jcm9uaXphIHNvemluaG8gMXggcG9yIGRpYS5cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvd1wiIHN0eWxlPXt7IGdhcDogOCB9fT5cclxuICAgICAgICAgICAgPExpbmsgdG89XCIvaW50ZWdyYWNvZXMvaWZvb2QvZmluYW5jZWlyby9yZWxhdG9yaW9zXCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIj5SZWxhdMOzcmlvcyBjb21wbGV0b3M8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgICBsb2FkaW5nPXtzeW5jRmluYW5jaWFsTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXshZmlyc3RNYXBwZWRCcmFuY2h9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc3luY0ZpbmFuY2lhbE11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgU2luY3Jvbml6YXIgYWdvcmFcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgeyFmaXJzdE1hcHBlZEJyYW5jaCAmJiAoXHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODhyZW1cIiB9fT5cclxuICAgICAgICAgICAgQ29uZmlndXJlIG8gTWVyY2hhbnQgSUQgZGUgYW8gbWVub3MgdW1hIGxvamEgYWNpbWEgcGFyYSB2ZXIgbyBmaW5hbmNlaXJvLlxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHtmaW5hbmNpYWxTdW1tYXJ5UXVlcnkuaXNFcnJvciAmJiAoXHJcbiAgICAgICAgICA8UXVlcnlFcnJvciBlcnJvcj17ZmluYW5jaWFsU3VtbWFyeVF1ZXJ5LmVycm9yfSB3aGF0PVwibyBmaW5hbmNlaXJvIGRvIGlGb29kXCIgLz5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7ZmluYW5jaWFsU3VtbWFyeVF1ZXJ5LmRhdGEgJiYgKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDIwIH19PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44MnJlbVwiIH19PkxhbsOnYW1lbnRvcyBjLyBpbXBhY3RvIG5vIHJlcGFzc2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4xNXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICB7ZmluYW5jaWFsU3VtbWFyeVF1ZXJ5LmRhdGEudG90YWxGaW5hbmNpYWxFdmVudHNXaXRoVHJhbnNmZXJJbXBhY3QudG9Mb2NhbGVTdHJpbmcoXCJwdC1CUlwiLCB7IHN0eWxlOiBcImN1cnJlbmN5XCIsIGN1cnJlbmN5OiBcIkJSTFwiIH0pfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMiB9fT5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC44MnJlbVwiIH19PlJlcGFzc2VzIChTZXR0bGVtZW50KTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjE1cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIHtmaW5hbmNpYWxTdW1tYXJ5UXVlcnkuZGF0YS50b3RhbFNldHRsZW1lbnRzLnRvTG9jYWxlU3RyaW5nKFwicHQtQlJcIiwgeyBzdHlsZTogXCJjdXJyZW5jeVwiLCBjdXJyZW5jeTogXCJCUkxcIiB9KX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7ZmluYW5jaWFsU3VtbWFyeVF1ZXJ5LmRhdGEuaGFzRGlzY3JlcGFuY3kgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2hpcFwiIHN0eWxlPXt7IFwiLS1kb3RcIjogXCJ2YXIoLS1kYW5nZXIpXCIgfSBhcyBDU1NQcm9wZXJ0aWVzfT5cclxuICAgICAgICAgICAgICAgICAgUmV2aXNhciBjb25jaWxpYcOnw6NvIOKAlCBkaWZlcmVuw6dhIGRle1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7ZmluYW5jaWFsU3VtbWFyeVF1ZXJ5LmRhdGEuZGlzY3JlcGFuY3lBbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJwdC1CUlwiLCB7IHN0eWxlOiBcImN1cnJlbmN5XCIsIGN1cnJlbmN5OiBcIkJSTFwiIH0pfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge2ZpbmFuY2lhbFN1bW1hcnlRdWVyeS5kYXRhLnNldHRsZW1lbnRzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODhyZW1cIiwgZm9udFdlaWdodDogNjAwIH19PlJlcGFzc2VzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge2ZpbmFuY2lhbFN1bW1hcnlRdWVyeS5kYXRhLnNldHRsZW1lbnRzLm1hcCgocykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtzLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBnYXA6IDEwLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkIHZhcigtLWxpbmUtc29mdClcIiwgcGFkZGluZ1RvcDogOCwgZm9udFNpemU6IFwiMC44OHJlbVwiIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzLnR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cy5wcm9kdWN0ID8gYCDigJQgJHtzLnByb2R1Y3R9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT57cy5zdGF0dXN9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntzLnBheW1lbnREYXRlID8gbmV3IERhdGUocy5wYXltZW50RGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwicHQtQlJcIikgOiBcInNlbSBkYXRhIHByZXZpc3RhXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3MuYW1vdW50LnRvTG9jYWxlU3RyaW5nKFwicHQtQlJcIiwgeyBzdHlsZTogXCJjdXJyZW5jeVwiLCBjdXJyZW5jeTogXCJCUkxcIiB9KX08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtmaW5hbmNpYWxTdW1tYXJ5UXVlcnkuZGF0YS5ldmVudHMubGVuZ3RoID09PSAwICYmIGZpbmFuY2lhbFN1bW1hcnlRdWVyeS5kYXRhLnNldHRsZW1lbnRzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjg4cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICBOZW5odW0gbGFuw6dhbWVudG8gZmluYW5jZWlybyBub3Mgw7psdGltb3MgMzAgZGlhcyBhaW5kYS5cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8Lz5cclxuICAgICAgICApfVxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTNcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIsIG1hcmdpblRvcDogMTYgfX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogMTYsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIG1heFdpZHRoOiA1MjAgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5cclxuICAgICAgICAgICAgICBBdmFsaWHDp8O1ZXNcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgVmVqYSBlIHJlc3BvbmRhIMOgcyBhdmFsaWHDp8O1ZXMgZG9zIGNsaWVudGVzIGRpcmV0byBubyBpRm9vZCAobm90YSBtw6lkaWEsIGNvbWVudMOhcmlvcyxcclxuICAgICAgICAgICAgICByZXNwb3N0YXMpLiBTZW0gc2luY3Jvbml6YcOnw6NvIOKAlCBzZW1wcmUgbGlkby9lc2NyaXRvIGFvIHZpdm8uXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPExpbmsgdG89XCIvaW50ZWdyYWNvZXMvaWZvb2QvYXZhbGlhY29lc1wiPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiPlZlciBhdmFsaWHDp8O1ZXM8L0J1dHRvbj5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidGlja2V0IHJpc2UgcmlzZS0zXCIgc3R5bGU9e3sgcGFkZGluZzogMjAsIGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEyLCBtYXJnaW5Ub3A6IDE2IH19PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBnYXA6IDE2LCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0LCBtYXhXaWR0aDogNTIwIH19PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgSW5kaWNhZG9yZXNcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgR01WLCB0YXhhcyBlIG91dHJhcyBtw6l0cmljYXMgZGUgcGVkaWRvcyBwb3IgcGVyw61vZG8sIGFncnVwYWRhcyBwb3IgY2FuYWwgZGUgdmVuZGEuXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPExpbmsgdG89XCIvaW50ZWdyYWNvZXMvaWZvb2QvaW5kaWNhZG9yZXNcIj5cclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIj5WZXIgaW5kaWNhZG9yZXM8L0J1dHRvbj5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAge2ZpcnN0TWFwcGVkQnJhbmNoICYmIDxNZXJjaGFudE9wZXJhdGlvbnNTZWN0aW9uIGJyYW5jaElkPXtmaXJzdE1hcHBlZEJyYW5jaC5icmFuY2hJZH0gY29tcGFueUlkPXtjb21wYW55SWR9IC8+fVxyXG4gICAgICB7IWZpcnN0TWFwcGVkQnJhbmNoICYmIChcclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTNcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCwgbWFyZ2luVG9wOiAxNiB9fT5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjFyZW1cIiB9fT5cclxuICAgICAgICAgICAgT3BlcmHDp8OjbyBkYSBsb2phXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODhyZW1cIiB9fT5cclxuICAgICAgICAgICAgQ29uZmlndXJlIG8gTWVyY2hhbnQgSUQgZGUgYW8gbWVub3MgdW1hIGxvamEgYWNpbWEgcGFyYSB2ZXIgc3RhdHVzLCBpbnRlcnJ1cMOnw7VlcyxcclxuICAgICAgICAgICAgaG9yw6FyaW9zIGUgdGVtcG8gZGUgcHJlcGFyby5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTNcIiBzdHlsZT17eyBwYWRkaW5nOiAyMCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCwgbWFyZ2luVG9wOiAxNiB9fT5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4xcmVtXCIgfX0+XHJcbiAgICAgICAgICBPIHF1ZSBqw6EgZXN0w6EgcHJvbnRvIHggbyBxdWUgZmFsdGFcclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPHVsIHN0eWxlPXt7IG1hcmdpbjogMCwgcGFkZGluZ0xlZnQ6IDE4LCBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgPHN0cm9uZyBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmspXCIgfX0+UHJvbnRvOjwvc3Ryb25nPiBndWFyZGFyIGFzIGNyZWRlbmNpYWlzIGRvIGFwcFxyXG4gICAgICAgICAgICBjb20gc2VndXJhbsOnYSAoc2VncmVkbyBjcmlwdG9ncmFmYWRvKSwgdGVzdGFyIGEgYXV0ZW50aWNhw6fDo28gT0F1dGgyIHJlYWwgY29tIG9cclxuICAgICAgICAgICAgaUZvb2QsIG1hcGVhciBjYWRhIGxvamEgYW8gTWVyY2hhbnRJZCBjb3JyZXNwb25kZW50ZSwgc2luY3Jvbml6YXIgcGVkaWRvcyAocmVjZWJlcixcclxuICAgICAgICAgICAgY29uZmlybWFyIGRlbnRybyBkbyBTTEEsIGluaWNpYXIgcHJlcGFyby9wcm9udG8vY2FuY2VsYXIpLCBzaW5jcm9uaXphciBjYXJkw6FwaW9cclxuICAgICAgICAgICAgKGNhdGVnb3JpYXMsIHByb2R1dG9zLCBwcmXDp28sIHBhdXNhci9yZWF0aXZhciwgZXN0b3F1ZSBkZSBwcm9kdXRvcyBjb20gY29udHJvbGUgZGVcclxuICAgICAgICAgICAgZXN0b3F1ZSksIHRyaWxoYSBmaW5hbmNlaXJhIChsYW7Dp2FtZW50b3MsIHJlcGFzc2VzIGUgb3MgMTMgcmVsYXTDs3Jpb3MgY29tcGxldG9zIGRvXHJcbiAgICAgICAgICAgIGlGb29kLCBhbGVydGEgZGUgZGlzY3JlcMOibmNpYSksIG9wZXJhw6fDo28gZGEgbG9qYSAoc3RhdHVzIGVtIHRlbXBvIHJlYWwsXHJcbiAgICAgICAgICAgIHBhdXNhci9yZWFicmlyLCBob3LDoXJpb3MgZGUgZnVuY2lvbmFtZW50bywgdGVtcG8gZGUgcHJlcGFybyBjdXN0b21pemFkbyksIGxvZ8Otc3RpY2FcclxuICAgICAgICAgICAgcG9yIGZyb3RhIHByw7NwcmlhIGUgZW50cmVnYSBTb2IgRGVtYW5kYSAoU2hpcHBpbmcpIOKAlCBpbmNsdXNpdmUgcHJhIHBlZGlkb3MgcXVlIHZpZXJhbVxyXG4gICAgICAgICAgICBkZSBvdXRyb3MgY2FuYWlzIOKAlCwgYXZhbGlhw6fDtWVzICh2ZXIvcmVzcG9uZGVyKSBlIGluZGljYWRvcmVzIGRlIHBlZGlkb3MuXHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICA8c3Ryb25nIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluaylcIiB9fT5QZW5kZW50ZTo8L3N0cm9uZz4gY29tcGxlbWVudG9zL3Bpenphcy9jb21ib3NcclxuICAgICAgICAgICAgYXZhbsOnYWRvcyBubyBjYXJkw6FwaW8gKG11bHRpc2V0dXAsIG1pZ3Jhw6fDo28gdjHihpR2MiwgaW1hZ2VtIGVtIGxvdGUpLCBkaXNwdXRhc1xyXG4gICAgICAgICAgICBww7NzLWVudHJlZ2EgKEhhbmRzaGFrZSkgYWzDqW0gZG8gYWNlaXRhci9yZWplaXRhciBiw6FzaWNvLCByYXN0cmVhbWVudG8gZW0gdGVsYSBkb1xyXG4gICAgICAgICAgICBwZWRpZG8gZG8gbcOzZHVsbyBPcmRlciAoZm9yYSBkYSB0ZWxhIGRlIFNoaXBwaW5nL0xvZ8Otc3RpY2EpLCBhdmFsaWHDp8O1ZXMgbm8gZm9ybWF0b1xyXG4gICAgICAgICAgICB2MiwgZSBwZWRpZG9zIGFnZW5kYWRvcy5cclxuICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgPC91bD5cclxuICAgICAgPC9zZWN0aW9uPlxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIE1lcmNoYW50TWFwcGluZ1Jvdyh7XHJcbiAgbWFwcGluZyxcclxuICBvblNhdmVkLFxyXG59OiB7XHJcbiAgbWFwcGluZzogeyBicmFuY2hJZDogbnVtYmVyOyBicmFuY2hOYW1lOiBzdHJpbmc7IG1lcmNoYW50SWQ6IHN0cmluZyB8IG51bGw7IG1lcmNoYW50VXVpZDogc3RyaW5nIHwgbnVsbCB9O1xyXG4gIG9uU2F2ZWQ6ICgpID0+IHZvaWQ7XHJcbn0pIHtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgW21lcmNoYW50SWQsIHNldE1lcmNoYW50SWRdID0gdXNlU3RhdGUobWFwcGluZy5tZXJjaGFudElkID8/IFwiXCIpO1xyXG4gIGNvbnN0IFttZXJjaGFudFV1aWQsIHNldE1lcmNoYW50VXVpZF0gPSB1c2VTdGF0ZShtYXBwaW5nLm1lcmNoYW50VXVpZCA/PyBcIlwiKTtcclxuXHJcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICBzZXRJRm9vZE1lcmNoYW50TWFwcGluZyh7XHJcbiAgICAgICAgYnJhbmNoSWQ6IG1hcHBpbmcuYnJhbmNoSWQsXHJcbiAgICAgICAgbWVyY2hhbnRJZDogbWVyY2hhbnRJZC50cmltKCksXHJcbiAgICAgICAgbWVyY2hhbnRVdWlkOiBtZXJjaGFudFV1aWQudHJpbSgpLFxyXG4gICAgICB9KSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKGBMb2phIFwiJHttYXBwaW5nLmJyYW5jaE5hbWV9XCIgYXR1YWxpemFkYS5gKTtcclxuICAgICAgb25TYXZlZCgpO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHNhbHZhciBlc3NhIGxvamEuXCIpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiBcImVuZFwiLCBnYXA6IDEwLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkIHZhcigtLWxpbmUtc29mdClcIiwgcGFkZGluZ1RvcDogMTIgfX0+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgbWluV2lkdGg6IDE0MCwgZm9udFdlaWdodDogNjAwIH19PnttYXBwaW5nLmJyYW5jaE5hbWV9PC9kaXY+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE4MCB9fT5cclxuICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICBsYWJlbD1cIk1lcmNoYW50IElEXCJcclxuICAgICAgICAgIHZhbHVlPXttZXJjaGFudElkfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNZXJjaGFudElkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSUQgZGEgbG9qYSBubyBpRm9vZFwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgbWluV2lkdGg6IDE4MCB9fT5cclxuICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICBsYWJlbD1cIk1lcmNoYW50IFVVSUQgKG9wY2lvbmFsKVwiXHJcbiAgICAgICAgICB2YWx1ZT17bWVyY2hhbnRVdWlkfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNZXJjaGFudFV1aWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJvcGNpb25hbFwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgbG9hZGluZz17bXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBtdXRhdGlvbi5tdXRhdGUoKX0+XHJcbiAgICAgICAgU2FsdmFyXHJcbiAgICAgIDwvQnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgV0VFS0RBWV9MQUJFTFMgPSBbXCJEb21pbmdvXCIsIFwiU2VndW5kYVwiLCBcIlRlcsOnYVwiLCBcIlF1YXJ0YVwiLCBcIlF1aW50YVwiLCBcIlNleHRhXCIsIFwiU8OhYmFkb1wiXTtcclxuXHJcbi8vIE9wZXJhw6fDo28gZGEgbG9qYSBpRm9vZCAoZmFzZSA1LCBtw7NkdWxvIE1lcmNoYW50KSDigJQgc3RhdHVzIGVtIHRlbXBvIHJlYWwsIGludGVycnVww6fDtWVzXHJcbi8vIChwYXVzYXIvcmVhYnJpciksIGhvcsOhcmlvcyBkZSBmdW5jaW9uYW1lbnRvIChjw7NwaWEgbG9jYWwgZWRpdMOhdmVsLCByZWVudmlhZGEgYW8gc2FsdmFyKSBlXHJcbi8vIHRlbXBvIGRlIHByZXBhcm8gY3VzdG9taXphZG8uIFR1ZG8gcG9yIGZpbGlhbCDigJQgdXNhIGEgbWVzbWEgbG9qYSBcInBhZHLDo29cIiAocHJpbWVpcmEgbWFwZWFkYSlcclxuLy8gcXVlIGEgc2XDp8OjbyBGaW5hbmNlaXJvLCBtZXNtYSBkZWNpc8OjbyBkZSBuw6NvIHRlciBzZWxldG9yIGRlIGxvamEgYWluZGEuXHJcbmZ1bmN0aW9uIE1lcmNoYW50T3BlcmF0aW9uc1NlY3Rpb24oeyBicmFuY2hJZCwgY29tcGFueUlkIH06IHsgYnJhbmNoSWQ6IG51bWJlcjsgY29tcGFueUlkOiBudW1iZXIgfSkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcblxyXG4gIGNvbnN0IHN0YXR1c1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwibWVyY2hhbnRcIiwgXCJzdGF0dXNcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RNZXJjaGFudFN0YXR1cyhicmFuY2hJZCksXHJcbiAgICAvLyBGYXNlIDIwICgyMDI2LTA4LTI0KTogZXZpdGEgcmFqYWRhIGRlIHJldHJpZXMgcmVhaXMgY29udHJhIG8gaUZvb2QgcXVhbmRvIG8gc3RhdHVzXHJcbiAgICAvLyBmYWxoYSAoZXguOiA0MDMgZGUgcGVybWlzc8OjbywgdmVyIEZhc2UgMTkpIOKAlCBtZXNtbyBhanVzdGUgZW0gSUZvb2REYXNoYm9hcmRQYWdlLnRzeC5cclxuICAgIHJldHJ5OiBmYWxzZSxcclxuICB9KTtcclxuXHJcbiAgLy8gRmFzZSA5YyDigJQgZmVjaGEgb3MgZ2FwcyByZXN0YW50ZXMgZG8gbcOzZHVsbyBNZXJjaGFudCBkYSBhdWRpdG9yaWEgZGUgMjAyNi0wOC0yMC8yMTogbGlzdGFyXHJcbiAgLy8gbG9qYXMgZG8gY2xpZW50X2lkLCB2ZXIgZGV0YWxoZXMgZGUgdW1hIGxvamEgZSBjb25zdWx0YXIgc3RhdHVzIHBvciBvcGVyYcOnw6NvIChleC46IERFTElWRVJZLFxyXG4gIC8vIFRBS0VPVVQg4oCUIGRpZmVyZW50ZSBkbyBzdGF0dXMgZ2VyYWwgYWNpbWEsIHF1ZSBzw7Mgb2xoYSBhIHByaW1laXJhIG9wZXJhw6fDo28gZGEgbGlzdGEpLlxyXG4gIGNvbnN0IFtzaG93TWVyY2hhbnRzTGlzdCwgc2V0U2hvd01lcmNoYW50c0xpc3RdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IG1lcmNoYW50c0xpc3RRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcIm1lcmNoYW50XCIsIFwibGlzdFwiLCBjb21wYW55SWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RNZXJjaGFudHNMaXN0KGNvbXBhbnlJZCksXHJcbiAgICBlbmFibGVkOiBzaG93TWVyY2hhbnRzTGlzdCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW3Nob3dNZXJjaGFudERldGFpbHMsIHNldFNob3dNZXJjaGFudERldGFpbHNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IG1lcmNoYW50RGV0YWlsc1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwibWVyY2hhbnRcIiwgXCJkZXRhaWxzXCIsIGJyYW5jaElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldElGb29kTWVyY2hhbnREZXRhaWxzKGJyYW5jaElkKSxcclxuICAgIGVuYWJsZWQ6IHNob3dNZXJjaGFudERldGFpbHMsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtvcGVyYXRpb25RdWVyeSwgc2V0T3BlcmF0aW9uUXVlcnldID0gdXNlU3RhdGUoXCJERUxJVkVSWVwiKTtcclxuICBjb25zdCBbb3BlcmF0aW9uTG9va3VwLCBzZXRPcGVyYXRpb25Mb29rdXBdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3Qgc3RhdHVzQnlPcGVyYXRpb25RdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcIm1lcmNoYW50XCIsIFwic3RhdHVzLWJ5LW9wZXJhdGlvblwiLCBicmFuY2hJZCwgb3BlcmF0aW9uTG9va3VwXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldElGb29kTWVyY2hhbnRTdGF0dXNCeU9wZXJhdGlvbihicmFuY2hJZCwgb3BlcmF0aW9uTG9va3VwID8/IFwiXCIpLFxyXG4gICAgZW5hYmxlZDogISFvcGVyYXRpb25Mb29rdXAsXHJcbiAgICByZXRyeTogZmFsc2UsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGludGVycnVwdGlvbnNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcIm1lcmNoYW50XCIsIFwiaW50ZXJydXB0aW9uc1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZEludGVycnVwdGlvbnMoYnJhbmNoSWQpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBvcGVuaW5nSG91cnNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcIm1lcmNoYW50XCIsIFwib3BlbmluZy1ob3Vyc1wiLCBicmFuY2hJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZE9wZW5pbmdIb3VycyhicmFuY2hJZCksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtzaGlmdHMsIHNldFNoaWZ0c10gPSB1c2VTdGF0ZTxJRm9vZE9wZW5pbmdIb3VyU2hpZnRbXT4oW10pO1xyXG4gIGNvbnN0IFtwcmVwVGltZSwgc2V0UHJlcFRpbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2luaXRpYWxpemVkQnJhbmNoSWQsIHNldEluaXRpYWxpemVkQnJhbmNoSWRdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAob3BlbmluZ0hvdXJzUXVlcnkuZGF0YSAmJiBpbml0aWFsaXplZEJyYW5jaElkICE9PSBicmFuY2hJZCkge1xyXG4gICAgICBzZXRTaGlmdHMob3BlbmluZ0hvdXJzUXVlcnkuZGF0YS5zaGlmdHMpO1xyXG4gICAgICBzZXRQcmVwVGltZShvcGVuaW5nSG91cnNRdWVyeS5kYXRhLnByZXBhcmF0aW9uVGltZU1pbnV0ZXM/LnRvU3RyaW5nKCkgPz8gXCJcIik7XHJcbiAgICAgIHNldEluaXRpYWxpemVkQnJhbmNoSWQoYnJhbmNoSWQpO1xyXG4gICAgfVxyXG4gIH0sIFtvcGVuaW5nSG91cnNRdWVyeS5kYXRhLCBicmFuY2hJZCwgaW5pdGlhbGl6ZWRCcmFuY2hJZF0pO1xyXG5cclxuICBjb25zdCBbaW50ZXJydXB0aW9uRGVzY3JpcHRpb24sIHNldEludGVycnVwdGlvbkRlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpbnRlcnJ1cHRpb25TdGFydCwgc2V0SW50ZXJydXB0aW9uU3RhcnRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2ludGVycnVwdGlvbkVuZCwgc2V0SW50ZXJydXB0aW9uRW5kXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBjcmVhdGVJbnRlcnJ1cHRpb25NdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+XHJcbiAgICAgIGNyZWF0ZUlGb29kSW50ZXJydXB0aW9uKHtcclxuICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICBkZXNjcmlwdGlvbjogaW50ZXJydXB0aW9uRGVzY3JpcHRpb24udHJpbSgpLFxyXG4gICAgICAgIHN0YXJ0OiBuZXcgRGF0ZShpbnRlcnJ1cHRpb25TdGFydCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICBlbmQ6IG5ldyBEYXRlKGludGVycnVwdGlvbkVuZCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgfSksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkxvamEgcGF1c2FkYSBubyBpRm9vZC5cIik7XHJcbiAgICAgIHNldEludGVycnVwdGlvbkRlc2NyaXB0aW9uKFwiXCIpO1xyXG4gICAgICBzZXRJbnRlcnJ1cHRpb25TdGFydChcIlwiKTtcclxuICAgICAgc2V0SW50ZXJydXB0aW9uRW5kKFwiXCIpO1xyXG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwibWVyY2hhbnRcIiwgXCJpbnRlcnJ1cHRpb25zXCIsIGJyYW5jaElkXSB9KTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBwYXVzYXIgYSBsb2phLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZGVsZXRlSW50ZXJydXB0aW9uTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoaW50ZXJydXB0aW9uSWQ6IHN0cmluZykgPT4gZGVsZXRlSUZvb2RJbnRlcnJ1cHRpb24oYnJhbmNoSWQsIGludGVycnVwdGlvbklkKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiTG9qYSByZWFiZXJ0YS5cIik7XHJcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJtZXJjaGFudFwiLCBcImludGVycnVwdGlvbnNcIiwgYnJhbmNoSWRdIH0pO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHJlYWJyaXIgYSBsb2phLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc2F2ZU9wZW5pbmdIb3Vyc011dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gc2F2ZUlGb29kT3BlbmluZ0hvdXJzKGJyYW5jaElkLCBzaGlmdHMpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJIb3LDoXJpb3MgZGUgZnVuY2lvbmFtZW50byBzYWx2b3MgZSBlbnZpYWRvcyBhbyBpRm9vZC5cIik7XHJcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJtZXJjaGFudFwiLCBcIm9wZW5pbmctaG91cnNcIiwgYnJhbmNoSWRdIH0pO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIHNhbHZhciBvcyBob3LDoXJpb3Mg4oCUIGNvbmZpcmEgb3MgdHVybm9zIGUgdGVudGUgZGUgbm92by5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHNldFByZXBUaW1lTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiBzZXRJRm9vZFByZXBhcmF0aW9uVGltZShicmFuY2hJZCwgcHJlcFRpbWUudHJpbSgpID09PSBcIlwiID8gbnVsbCA6IE51bWJlcihwcmVwVGltZSkpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJUZW1wbyBkZSBwcmVwYXJvIGF0dWFsaXphZG8uXCIpO1xyXG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwibWVyY2hhbnRcIiwgXCJvcGVuaW5nLWhvdXJzXCIsIGJyYW5jaElkXSB9KTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBhdHVhbGl6YXIgbyB0ZW1wbyBkZSBwcmVwYXJvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgYWRkU2hpZnQgPSAoKSA9PiBzZXRTaGlmdHMoKHByZXYpID0+IFsuLi5wcmV2LCB7IGRheU9mV2VlazogMSwgc3RhcnQ6IFwiMDg6MDBcIiwgZHVyYXRpb25NaW51dGVzOiA2MDAgfV0pO1xyXG4gIGNvbnN0IHJlbW92ZVNoaWZ0ID0gKGluZGV4OiBudW1iZXIpID0+IHNldFNoaWZ0cygocHJldikgPT4gcHJldi5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KSk7XHJcbiAgY29uc3QgdXBkYXRlU2hpZnQgPSAoaW5kZXg6IG51bWJlciwgcGF0Y2g6IFBhcnRpYWw8SUZvb2RPcGVuaW5nSG91clNoaWZ0PikgPT5cclxuICAgIHNldFNoaWZ0cygocHJldikgPT4gcHJldi5tYXAoKHMsIGkpID0+IChpID09PSBpbmRleCA/IHsgLi4ucywgLi4ucGF0Y2ggfSA6IHMpKSk7XHJcblxyXG4gIGNvbnN0IGhhc0lGb29kQ3VzdG9tZXJJZCA9IG9wZW5pbmdIb3Vyc1F1ZXJ5LmRhdGE/Lmhhc0lGb29kQ3VzdG9tZXJJZCA/PyBmYWxzZTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInRpY2tldCByaXNlIHJpc2UtM1wiIHN0eWxlPXt7IHBhZGRpbmc6IDIwLCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyMCwgbWFyZ2luVG9wOiAxNiB9fT5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0IH19PlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT5cclxuICAgICAgICAgIE9wZXJhw6fDo28gZGEgbG9qYVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjkycmVtXCIgfX0+XHJcbiAgICAgICAgICBTdGF0dXMgZW0gdGVtcG8gcmVhbCwgcGF1c2FzL3JlYWJlcnR1cmFzLCBob3LDoXJpb3MgZGUgZnVuY2lvbmFtZW50byBlIHRlbXBvIGRlIHByZXBhcm9cclxuICAgICAgICAgIGN1c3RvbWl6YWRvIOKAlCB0dWRvIGRpcmV0byBwZWxvIG3Ds2R1bG8gTWVyY2hhbnQgZG8gaUZvb2QuXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBTdGF0dXMgKi99XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lLXNvZnQpXCIsIHBhZGRpbmdUb3A6IDE0IH19PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDEyIH19PlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19PlN0YXR1czwvc3Bhbj5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgbG9hZGluZz17c3RhdHVzUXVlcnkuaXNGZXRjaGluZ30gb25DbGljaz17KCkgPT4gdm9pZCBzdGF0dXNRdWVyeS5yZWZldGNoKCl9PlxyXG4gICAgICAgICAgICBBdHVhbGl6YXIgc3RhdHVzXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7c3RhdHVzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17c3RhdHVzUXVlcnkuZXJyb3J9IHdoYXQ9XCJvIHN0YXR1cyBkYSBsb2phXCIgLz59XHJcbiAgICAgICAge3N0YXR1c1F1ZXJ5LmRhdGEgJiYgKFxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA2IH19PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGlwXCI+e3N0YXR1c1F1ZXJ5LmRhdGEub3BlcmF0aW9uU3RhdGUgPz8gXCJEZXNjb25oZWNpZG9cIn08L3NwYW4+XHJcbiAgICAgICAgICAgIHtzdGF0dXNRdWVyeS5kYXRhLnZhbGlkYXRpb25zLm1hcCgodikgPT4gKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGtleT17di5pZH0gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICB7di5pZH0gKHt2LnN0YXRlfSl7di5tZXNzYWdlID8gYCDigJQgJHt2Lm1lc3NhZ2V9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEZhc2UgOWMg4oCUIExpc3QgbWVyY2hhbnRzIC8gR2V0IG1lcmNoYW50IGRldGFpbHMgLyBHZXQgc3RhdHVzIGJ5IG9wZXJhdGlvbiAqL31cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lLXNvZnQpXCIsIHBhZGRpbmdUb3A6IDE0IH19PlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCB9fT5Mb2phcyBkbyBjbGllbnRfaWQ8L3NwYW4+XHJcbiAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICBsb2FkaW5nPXtzaG93TWVyY2hhbnRzTGlzdCAmJiBtZXJjaGFudHNMaXN0UXVlcnkuaXNGZXRjaGluZ31cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IChzaG93TWVyY2hhbnRzTGlzdCA/IHZvaWQgbWVyY2hhbnRzTGlzdFF1ZXJ5LnJlZmV0Y2goKSA6IHNldFNob3dNZXJjaGFudHNMaXN0KHRydWUpKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBMaXN0YXIgbG9qYXMgbm8gaUZvb2RcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICB7c2hvd01lcmNoYW50c0xpc3QgJiYgbWVyY2hhbnRzTGlzdFF1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e21lcmNoYW50c0xpc3RRdWVyeS5lcnJvcn0gd2hhdD1cImEgbGlzdGEgZGUgbG9qYXNcIiAvPn1cclxuICAgICAgICB7c2hvd01lcmNoYW50c0xpc3QgJiYgKG1lcmNoYW50c0xpc3RRdWVyeS5kYXRhID8/IFtdKS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNCB9fT5cclxuICAgICAgICAgICAge21lcmNoYW50c0xpc3RRdWVyeS5kYXRhIS5tYXAoKG0pID0+IChcclxuICAgICAgICAgICAgICA8c3BhbiBrZXk9e20uaWR9IHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgIHttLm5hbWUgPz8gbS5pZH0ge20uY29ycG9yYXRlTmFtZSA/IGDigJQgJHttLmNvcnBvcmF0ZU5hbWV9YCA6IFwiXCJ9IDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT4oe20uaWR9KTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEwLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkIHZhcigtLWxpbmUtc29mdClcIiwgcGFkZGluZ1RvcDogMTQgfX0+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19PkRldGFsaGVzIGRhIGxvamE8L3NwYW4+XHJcbiAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICBsb2FkaW5nPXtzaG93TWVyY2hhbnREZXRhaWxzICYmIG1lcmNoYW50RGV0YWlsc1F1ZXJ5LmlzRmV0Y2hpbmd9XHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiAoc2hvd01lcmNoYW50RGV0YWlscyA/IHZvaWQgbWVyY2hhbnREZXRhaWxzUXVlcnkucmVmZXRjaCgpIDogc2V0U2hvd01lcmNoYW50RGV0YWlscyh0cnVlKSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgVmVyIGRldGFsaGVzIG5vIGlGb29kXHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAge3Nob3dNZXJjaGFudERldGFpbHMgJiYgbWVyY2hhbnREZXRhaWxzUXVlcnkuaXNFcnJvciAmJiA8UXVlcnlFcnJvciBlcnJvcj17bWVyY2hhbnREZXRhaWxzUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBkZXRhbGhlcyBkYSBsb2phXCIgLz59XHJcbiAgICAgICAge3Nob3dNZXJjaGFudERldGFpbHMgJiYgbWVyY2hhbnREZXRhaWxzUXVlcnkuZGF0YSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT5cclxuICAgICAgICAgICAgPHNwYW4+Tm9tZToge21lcmNoYW50RGV0YWlsc1F1ZXJ5LmRhdGEubmFtZSA/PyBcIuKAlFwifTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+UmF6w6NvIHNvY2lhbDoge21lcmNoYW50RGV0YWlsc1F1ZXJ5LmRhdGEuY29ycG9yYXRlTmFtZSA/PyBcIuKAlFwifTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+VGlwbzoge21lcmNoYW50RGV0YWlsc1F1ZXJ5LmRhdGEudHlwZSA/PyBcIuKAlFwifTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+U3RhdHVzOiB7bWVyY2hhbnREZXRhaWxzUXVlcnkuZGF0YS5zdGF0dXMgPz8gXCLigJRcIn08L3NwYW4+XHJcbiAgICAgICAgICAgIHttZXJjaGFudERldGFpbHNRdWVyeS5kYXRhLmFkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgRW5kZXJlw6dvOiB7bWVyY2hhbnREZXRhaWxzUXVlcnkuZGF0YS5hZGRyZXNzLnN0cmVldH0sIHttZXJjaGFudERldGFpbHNRdWVyeS5kYXRhLmFkZHJlc3MubnVtYmVyfSDigJR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICB7bWVyY2hhbnREZXRhaWxzUXVlcnkuZGF0YS5hZGRyZXNzLmNpdHl9L3ttZXJjaGFudERldGFpbHNRdWVyeS5kYXRhLmFkZHJlc3Muc3RhdGV9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEwLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkIHZhcigtLWxpbmUtc29mdClcIiwgcGFkZGluZ1RvcDogMTQgfX0+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19PlN0YXR1cyBwb3Igb3BlcmHDp8Ojbzwvc3Bhbj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAsIGFsaWduSXRlbXM6IFwiZW5kXCIgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNjAgfX0+XHJcbiAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICBsYWJlbD1cIk9wZXJhw6fDo29cIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtvcGVyYXRpb25RdWVyeX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE9wZXJhdGlvblF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4LjogREVMSVZFUlksIFRBS0VPVVRcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXHJcbiAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXshb3BlcmF0aW9uUXVlcnkudHJpbSgpfVxyXG4gICAgICAgICAgICBsb2FkaW5nPXtzdGF0dXNCeU9wZXJhdGlvblF1ZXJ5LmlzRmV0Y2hpbmd9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZXJhdGlvbkxvb2t1cChvcGVyYXRpb25RdWVyeS50cmltKCkpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBDb25zdWx0YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtzdGF0dXNCeU9wZXJhdGlvblF1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e3N0YXR1c0J5T3BlcmF0aW9uUXVlcnkuZXJyb3J9IHdoYXQ9XCJvIHN0YXR1cyBkYSBvcGVyYcOnw6NvXCIgLz59XHJcbiAgICAgICAge3N0YXR1c0J5T3BlcmF0aW9uUXVlcnkuZGF0YSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT5cclxuICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAge3N0YXR1c0J5T3BlcmF0aW9uUXVlcnkuZGF0YS5vcGVyYXRpb24gPz8gb3BlcmF0aW9uTG9va3VwfSDigJQge3N0YXR1c0J5T3BlcmF0aW9uUXVlcnkuZGF0YS5hdmFpbGFibGUgPyBcIkRpc3BvbsOtdmVsXCIgOiBcIkluZGlzcG9uw612ZWxcIn1cclxuICAgICAgICAgICAgICB7c3RhdHVzQnlPcGVyYXRpb25RdWVyeS5kYXRhLnN0YXRlID8gYCAoJHtzdGF0dXNCeU9wZXJhdGlvblF1ZXJ5LmRhdGEuc3RhdGV9KWAgOiBcIlwifVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIHtzdGF0dXNCeU9wZXJhdGlvblF1ZXJ5LmRhdGEudmFsaWRhdGlvbnMubWFwKCh2KSA9PiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4ga2V5PXt2LmlkfSBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICB7di5pZH0gKHt2LnN0YXRlfSl7di5tZXNzYWdlID8gYCDigJQgJHt2Lm1lc3NhZ2V9YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEludGVycnVww6fDtWVzICovfVxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEwLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkIHZhcigtLWxpbmUtc29mdClcIiwgcGFkZGluZ1RvcDogMTQgfX0+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19PkludGVycnVww6fDtWVzIChwYXVzYXIvcmVhYnJpcik8L3NwYW4+XHJcbiAgICAgICAge2ludGVycnVwdGlvbnNRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtpbnRlcnJ1cHRpb25zUXVlcnkuZXJyb3J9IHdoYXQ9XCJhcyBpbnRlcnJ1cMOnw7Vlc1wiIC8+fVxyXG4gICAgICAgIHsoaW50ZXJydXB0aW9uc1F1ZXJ5LmRhdGEgPz8gW10pLmxlbmd0aCA9PT0gMCAmJiAhaW50ZXJydXB0aW9uc1F1ZXJ5LmlzTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODZyZW1cIiB9fT5OZW5odW1hIHBhdXNhIGF0aXZhLjwvc3Bhbj5cclxuICAgICAgICApfVxyXG4gICAgICAgIHsoaW50ZXJydXB0aW9uc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgoaSkgPT4gKFxyXG4gICAgICAgICAgPGRpdiBrZXk9e2kuaWR9IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgZ2FwOiAxMCwgZm9udFNpemU6IFwiMC44OHJlbVwiIH19PlxyXG4gICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICB7aS5kZXNjcmlwdGlvbiA/PyBcIihzZW0gbW90aXZvKVwifSDigJQge25ldyBEYXRlKGkuc3RhcnQpLnRvTG9jYWxlU3RyaW5nKFwicHQtQlJcIil9IGF0w6l7XCIgXCJ9XHJcbiAgICAgICAgICAgICAge25ldyBEYXRlKGkuZW5kKS50b0xvY2FsZVN0cmluZyhcInB0LUJSXCIpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgbG9hZGluZz17ZGVsZXRlSW50ZXJydXB0aW9uTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRlbGV0ZUludGVycnVwdGlvbk11dGF0aW9uLm11dGF0ZShpLmlkKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJlYWJyaXJcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApKX1cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1aS1yb3cgdWktcm93LXdyYXBcIiBzdHlsZT17eyBnYXA6IDEwLCBhbGlnbkl0ZW1zOiBcImVuZFwiIH19PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAyLCBtaW5XaWR0aDogMTYwIH19PlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJNb3Rpdm9cIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtpbnRlcnJ1cHRpb25EZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEludGVycnVwdGlvbkRlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4LjogZmFsdGEgZGUgaW5zdW1vXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTYwIH19PlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJJbsOtY2lvXCJcclxuICAgICAgICAgICAgICB0eXBlPVwiZGF0ZXRpbWUtbG9jYWxcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtpbnRlcnJ1cHRpb25TdGFydH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEludGVycnVwdGlvblN0YXJ0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTYwIH19PlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJGaW1cIlxyXG4gICAgICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2ludGVycnVwdGlvbkVuZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEludGVycnVwdGlvbkVuZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgbG9hZGluZz17Y3JlYXRlSW50ZXJydXB0aW9uTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17IWludGVycnVwdGlvbkRlc2NyaXB0aW9uLnRyaW0oKSB8fCAhaW50ZXJydXB0aW9uU3RhcnQgfHwgIWludGVycnVwdGlvbkVuZH1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY3JlYXRlSW50ZXJydXB0aW9uTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFBhdXNhciBsb2phXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogSG9yw6FyaW9zIGRlIGZ1bmNpb25hbWVudG8gKi99XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTAsIGJvcmRlclRvcDogXCIxcHggc29saWQgdmFyKC0tbGluZS1zb2Z0KVwiLCBwYWRkaW5nVG9wOiAxNCB9fT5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAgfX0+SG9yw6FyaW9zIGRlIGZ1bmNpb25hbWVudG88L3NwYW4+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+XHJcbiAgICAgICAgICBBbyBzYWx2YXIsIGEgbGlzdGEgaW50ZWlyYSBkZSB0dXJub3Mgw6kgcmVlbnZpYWRhIGFvIGlGb29kIChzdWJzdGl0dWkgdHVkbywgbsOjbyDDqVxyXG4gICAgICAgICAgaW5jcmVtZW50YWwpLlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICB7c2hpZnRzLm1hcCgoc2hpZnQsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICA8ZGl2IGtleT17aW5kZXh9IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTAsIGFsaWduSXRlbXM6IFwiZW5kXCIgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWluV2lkdGg6IDE0MCB9fT5cclxuICAgICAgICAgICAgICA8U2VsZWN0RmllbGRcclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiRGlhIGRhIHNlbWFuYVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2hpZnQuZGF5T2ZXZWVrfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVTaGlmdChpbmRleCwgeyBkYXlPZldlZWs6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge1dFRUtEQVlfTEFCRUxTLm1hcCgobGFiZWwsIGRheSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZGF5fSB2YWx1ZT17ZGF5fT5cclxuICAgICAgICAgICAgICAgICAgICB7bGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3RGaWVsZD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWluV2lkdGg6IDEyMCB9fT5cclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkluw61jaW9cIlxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRpbWVcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NoaWZ0LnN0YXJ0fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVTaGlmdChpbmRleCwgeyBzdGFydDogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWluV2lkdGg6IDEyMCB9fT5cclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkR1cmHDp8OjbyAobWluKVwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzaGlmdC5kdXJhdGlvbk1pbnV0ZXMudG9TdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlU2hpZnQoaW5kZXgsIHsgZHVyYXRpb25NaW51dGVzOiBOdW1iZXIoZS50YXJnZXQudmFsdWUpIH0pfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHNpemU9XCJzbVwiIG9uQ2xpY2s9eygpID0+IHJlbW92ZVNoaWZ0KGluZGV4KX0+XHJcbiAgICAgICAgICAgICAgUmVtb3ZlclxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93XCIgc3R5bGU9e3sgZ2FwOiAxMCB9fT5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17YWRkU2hpZnR9PlxyXG4gICAgICAgICAgICArIEFkaWNpb25hciB0dXJub1xyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgbG9hZGluZz17c2F2ZU9wZW5pbmdIb3Vyc011dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2F2ZU9wZW5pbmdIb3Vyc011dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBTYWx2YXIgaG9yw6FyaW9zXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogVGVtcG8gZGUgcHJlcGFybyAqL31cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMCwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lLXNvZnQpXCIsIHBhZGRpbmdUb3A6IDE0IH19PlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCB9fT5UZW1wbyBkZSBwcmVwYXJvPC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLXdhcm4sICNkOTc3MDYpXCIsIGZvbnRTaXplOiBcIjAuODJyZW1cIiB9fT5cclxuICAgICAgICAgIOKaoCBFc3RlIGVuZHBvaW50IG7Do28gY29uc3RhIG5hIGRvY3VtZW50YcOnw6NvIG9maWNpYWwgYXVkaXRhZGEgZW0gMjAyNi0wOC0yMC8yMSDigJQgdHJhdGUgY29tb1xyXG4gICAgICAgICAgbsOjbyBjb25maXJtYWRvIGUgdmFsaWRlIG51bWEgbG9qYSBkZSB0ZXN0ZSBhbnRlcyBkZSBkZXBlbmRlciBkZWxlLlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICB7IWhhc0lGb29kQ3VzdG9tZXJJZCAmJiAoXHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5cclxuICAgICAgICAgICAgQ29uZmlndXJlIG8gXCJpRm9vZCBDdXN0b21lciBJRFwiIG5hIHNlw6fDo28gZGUgY3JlZGVuY2lhaXMgYWNpbWEgcGFyYSBoYWJpbGl0YXIgZXN0ZVxyXG4gICAgICAgICAgICBjYW1wby5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiAxMCwgYWxpZ25JdGVtczogXCJlbmRcIiB9fT5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWluV2lkdGg6IDE2MCB9fT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiTWludXRvcyAodmF6aW8gPSBhdXRvbcOhdGljbyBkbyBpRm9vZClcIlxyXG4gICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtwcmVwVGltZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFByZXBUaW1lKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17IWhhc0lGb29kQ3VzdG9tZXJJZH1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4LjogMzBcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgbG9hZGluZz17c2V0UHJlcFRpbWVNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXshaGFzSUZvb2RDdXN0b21lcklkfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQcmVwVGltZU11dGF0aW9uLm11dGF0ZSgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBTYWx2YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9pbnRlZ3JhdGlvbnMvSUZvb2RJbnRlZ3JhdGlvblBhZ2UudHN4In0=