import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodReviewsDetailedPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  getIFoodReviewById,
  getIFoodReviews,
  getIFoodReviewsSummary,
  replyIFoodReview
} from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useToast } from "/src/ui/Toast.tsx";
import { Button } from "/src/ui/Button.tsx";
import { Modal } from "/src/ui/Modal.tsx";
import { Field } from "/src/ui/Field.tsx";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
import { Tabs } from "/src/components/Tabs.tsx";
import { DashboardCard } from "/src/components/DashboardCard.tsx";
import { formatReviewState, formatDateTimeShort } from "/src/utils/ifoodFormattersEnhanced.ts";
const PAGE_SIZE = 20;
const MAX_REPLY_LENGTH = 500;
export function IFoodReviewsDetailedPage() {
  _s();
  const { branchId } = useAuthStore();
  const toast = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("aberta");
  const [page, setPage] = useState(1);
  const [replyingReview, setReplyingReview] = useState(null);
  const [replyText, setReplyText] = useState("");
  const [viewingId, setViewingId] = useState(null);
  const summaryQuery = useQuery({
    queryKey: ["integrations", "ifood", "reviews", "summary", branchId],
    queryFn: () => getIFoodReviewsSummary(branchId)
  });
  const reviewsQuery = useQuery({
    queryKey: ["integrations", "ifood", "reviews", branchId, page],
    queryFn: () => getIFoodReviews(branchId, { page, pageSize: PAGE_SIZE }),
    refetchInterval: 6e4
  });
  const detailQuery = useQuery({
    queryKey: ["integrations", "ifood", "reviews", "detail", branchId, viewingId],
    queryFn: () => getIFoodReviewById(branchId, viewingId),
    enabled: !!viewingId
  });
  const replyMutation = useMutation({
    mutationFn: (payload) => replyIFoodReview(branchId, payload.reviewId, payload.text),
    onSuccess: () => {
      toast.success("Resposta enviada ao iFood.");
      setReplyingReview(null);
      setReplyText("");
      void queryClient.invalidateQueries({ queryKey: ["integrations", "ifood", "reviews"] });
    },
    onError: () => toast.error("Falha ao enviar resposta.")
  });
  const reviews = reviewsQuery.data?.reviews ?? [];
  const openReviews = reviews.filter((r) => !r.reply);
  const repliedReviews = reviews.filter((r) => !!r.reply);
  const displayReviews = activeTab === "aberta" ? openReviews : repliedReviews;
  const summary = summaryQuery.data;
  const avgScore = summary?.score != null ? summary.score.toFixed(1) : "—";
  const totalReviews = summary?.totalReviewsCount ?? reviewsQuery.data?.total ?? reviews.length;
  const pageCount = reviewsQuery.data?.pageCount ?? 1;
  const replyTooLong = replyText.length > MAX_REPLY_LENGTH;
  if (reviewsQuery.isLoading) {
    return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1e3, margin: "0 auto" }, children: [
      /* @__PURE__ */ jsxDEV(
        PageHeader,
        {
          title: "Avaliações iFood",
          subtitle: "Gerencie respostas a clientes",
          breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 102,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", padding: "40px 20px" }, children: /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)" }, children: "Carregando avaliações..." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 108,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 107,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this);
  }
  if (reviewsQuery.isError) {
    return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1e3, margin: "0 auto" }, children: [
      /* @__PURE__ */ jsxDEV(
        PageHeader,
        {
          title: "Avaliações iFood",
          subtitle: "Gerencie respostas a clientes",
          breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 117,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(QueryError, { error: reviewsQuery.error, what: "as avaliações" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 122,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
      lineNumber: 116,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1e3, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "Avaliações iFood",
        subtitle: "Gerencie respostas a clientes",
        breadcrumb: [{ label: "iFood", href: "/integracoes/ifood" }],
        actions: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => reviewsQuery.refetch(), disabled: reviewsQuery.isRefetching, children: [
          "🔄 ",
          reviewsQuery.isRefetching ? "Atualizando..." : "Atualizar agora"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 134,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 129,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
          gap: 12,
          marginBottom: 24
        },
        children: [
          /* @__PURE__ */ jsxDEV(
            DashboardCard,
            {
              title: "Nota Média",
              value: `${avgScore} ⭐`,
              subtitle: `de ${totalReviews} avaliações`,
              status: "info",
              icon: "📊"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
              lineNumber: 149,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DashboardCard,
            {
              title: "Não Respondidas (página)",
              value: openReviews.length,
              status: openReviews.length > 0 ? "warning" : "success",
              icon: "📝"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
              lineNumber: 156,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(DashboardCard, { title: "Respondidas (página)", value: repliedReviews.length, status: "success", icon: "✓" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
            lineNumber: 162,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            DashboardCard,
            {
              title: "Taxa de Resposta (página)",
              value: `${(repliedReviews.length / Math.max(reviews.length, 1) * 100).toFixed(0)}%`,
              status: "info",
              icon: "📈"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
              lineNumber: 163,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 141,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Tabs,
      {
        tabs: [
          { id: "aberta", label: "Não Respondidas", badge: openReviews.length },
          { id: "respondida", label: "Respondidas", badge: repliedReviews.length }
        ],
        activeTab,
        onTabChange: setActiveTab,
        children: displayReviews.length === 0 ? /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 20 }, children: /* @__PURE__ */ jsxDEV(
          EmptyState,
          {
            title: activeTab === "aberta" ? "Todas respondidas!" : "Nenhuma respondida",
            description: activeTab === "aberta" ? "Nenhuma avaliação pendente de resposta nesta página." : "Comece respondendo avaliações dos clientes."
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
            lineNumber: 182,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 181,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 16, marginTop: 16 }, children: displayReviews.map((review) => {
          const stateDisplay = formatReviewState(review.reply ? "CLOSED" : "OPEN");
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "card",
              style: { padding: 16, borderLeft: `4px solid ${stateDisplay.color}` },
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      display: "grid",
                      gridTemplateColumns: "1fr auto",
                      alignItems: "flex-start",
                      gap: 12,
                      marginBottom: 12
                    },
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, alignItems: "center", marginBottom: 4 }, children: [
                          /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "1.2rem" }, children: review.score != null ? "⭐".repeat(Math.round(review.score)) : "—" }, void 0, false, {
                            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                            lineNumber: 212,
                            columnNumber: 25
                          }, this),
                          review.score != null && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.9rem", color: "var(--ink-faint)" }, children: review.score.toFixed(1) }, void 0, false, {
                            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                            lineNumber: 216,
                            columnNumber: 23
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                          lineNumber: 211,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.9rem", fontWeight: 600, margin: 0, marginBottom: 4 }, children: [
                          "Pedido ",
                          review.order?.shortId ?? review.order?.id ?? "—"
                        ] }, void 0, true, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                          lineNumber: 221,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.8rem", color: "var(--ink-faint)", margin: 0 }, children: review.createdAt ? formatDateTimeShort(review.createdAt) : "—" }, void 0, false, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                          lineNumber: 224,
                          columnNumber: 23
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                        lineNumber: 210,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "span",
                        {
                          style: {
                            fontSize: "0.8rem",
                            padding: "4px 8px",
                            borderRadius: 4,
                            background: stateDisplay.color + "20",
                            color: stateDisplay.color,
                            fontWeight: 600
                          },
                          children: [
                            stateDisplay.icon,
                            " ",
                            stateDisplay.label
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                          lineNumber: 228,
                          columnNumber: 21
                        },
                        this
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                    lineNumber: 201,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      padding: 12,
                      borderRadius: 6,
                      background: "var(--surface-2)",
                      marginBottom: 12,
                      borderLeft: "3px solid var(--accent)"
                    },
                    children: /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.9rem", margin: 0, lineHeight: 1.5 }, children: review.comment || "Avaliação sem comentário." }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                      lineNumber: 252,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                    lineNumber: 243,
                    columnNumber: 19
                  },
                  this
                ),
                review.reply && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      padding: 12,
                      borderRadius: 6,
                      background: "#e8f5e9",
                      borderLeft: "3px solid #4caf50",
                      marginBottom: 12
                    },
                    children: [
                      /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.75rem", fontWeight: 600, color: "#1b5e20", margin: "0 0 4px" }, children: "✓ Resposta da loja:" }, void 0, false, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                        lineNumber: 268,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.9rem", margin: 0, lineHeight: 1.5 }, children: review.reply }, void 0, false, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                        lineNumber: 271,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                    lineNumber: 259,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
                  /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setViewingId(review.id), children: "🔍 Ver detalhes" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                    lineNumber: 277,
                    columnNumber: 21
                  }, this),
                  !review.reply && /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => setReplyingReview(review), style: { flex: 1 }, children: "✉️ Responder" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                    lineNumber: 281,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                  lineNumber: 276,
                  columnNumber: 19
                }, this)
              ]
            },
            review.id,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
              lineNumber: 196,
              columnNumber: 15
            },
            this
          );
        }) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 192,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 172,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, alignItems: "center", justifyContent: "center", marginTop: 20 }, children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", disabled: page <= 1, onClick: () => setPage((p) => Math.max(1, p - 1)), children: "← Anterior" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 295,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--ink-faint)" }, children: [
        "Página ",
        page,
        " de ",
        Math.max(pageCount, 1)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 298,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", disabled: page >= pageCount, onClick: () => setPage((p) => p + 1), children: "Próxima →" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 301,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
      lineNumber: 294,
      columnNumber: 7
    }, this),
    replyingReview && /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: "Responder Avaliação",
        onClose: () => {
          setReplyingReview(null);
          setReplyText("");
        },
        children: /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12 }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.9rem", fontWeight: 600, margin: "0 0 8px" }, children: [
              "Avaliação do pedido ",
              replyingReview.order?.shortId ?? replyingReview.order?.id ?? "—"
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
              lineNumber: 317,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                style: {
                  padding: 12,
                  background: "var(--surface-2)",
                  borderRadius: 6,
                  borderLeft: "3px solid var(--accent)"
                },
                children: [
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1rem", marginBottom: 4 }, children: replyingReview.score != null ? "⭐".repeat(Math.round(replyingReview.score)) : "—" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                    lineNumber: 328,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.9rem", margin: 0, lineHeight: 1.5 }, children: replyingReview.comment || "Avaliação sem comentário." }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                    lineNumber: 331,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                lineNumber: 320,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
            lineNumber: 316,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Field,
            {
              label: "Sua Resposta",
              hint: `${replyText.length}/${MAX_REPLY_LENGTH} caracteres. Seja educado e profissional.`,
              error: replyTooLong ? `A resposta passa de ${MAX_REPLY_LENGTH} caracteres.` : void 0,
              children: (a11y) => /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  ...a11y,
                  rows: 4,
                  maxLength: MAX_REPLY_LENGTH,
                  value: replyText,
                  onChange: (e) => setReplyText(e.target.value),
                  placeholder: "Digite sua resposta ao cliente..."
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                  lineNumber: 343,
                  columnNumber: 13
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
              lineNumber: 337,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, justifyContent: "flex-end" }, children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "ghost",
                onClick: () => {
                  setReplyingReview(null);
                  setReplyText("");
                },
                children: "Cancelar"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                lineNumber: 355,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "primary",
                onClick: () => replyMutation.mutate({ reviewId: replyingReview.id, text: replyText.trim() }),
                disabled: !replyText.trim() || replyTooLong || replyMutation.isPending,
                children: replyMutation.isPending ? "Enviando..." : "Enviar Resposta"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                lineNumber: 364,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
            lineNumber: 354,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 315,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 308,
        columnNumber: 7
      },
      this
    ),
    viewingId && /* @__PURE__ */ jsxDEV(Modal, { title: "Detalhes da Avaliação", onClose: () => setViewingId(null), children: [
      detailQuery.isLoading && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-faint)" }, children: "Carregando..." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 379,
        columnNumber: 37
      }, this),
      detailQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: detailQuery.error, what: "os detalhes da avaliação" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 380,
        columnNumber: 35
      }, this),
      detailQuery.data && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12 }, children: [
        /* @__PURE__ */ jsxDEV("p", { style: { margin: 0, fontSize: "0.9rem" }, children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Cliente:" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
            lineNumber: 384,
            columnNumber: 17
          }, this),
          " ",
          detailQuery.data.customerName || "—"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 383,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { margin: 0, fontSize: "0.9rem" }, children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Nota:" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
            lineNumber: 387,
            columnNumber: 17
          }, this),
          " ",
          detailQuery.data.score != null ? detailQuery.data.score.toFixed(1) : "—"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 386,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { margin: 0, fontSize: "0.9rem" }, children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Comentário:" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
            lineNumber: 390,
            columnNumber: 17
          }, this),
          " ",
          detailQuery.data.comment || "—"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 389,
          columnNumber: 15
        }, this),
        detailQuery.data.questions.length > 0 && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("strong", { style: { fontSize: "0.9rem" }, children: "Perguntas" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
            lineNumber: 394,
            columnNumber: 19
          }, this),
          detailQuery.data.questions.map(
            (question) => /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 12 }, children: [
              /* @__PURE__ */ jsxDEV("p", { style: { margin: 0, fontSize: "0.9rem", fontWeight: 600 }, children: question.title || question.id }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                lineNumber: 397,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("ul", { style: { margin: "4px 0 0", paddingLeft: 18, fontSize: "0.85rem" }, children: question.answers.map(
                (answer) => /* @__PURE__ */ jsxDEV("li", { children: answer.title || answer.id }, answer.id, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                  lineNumber: 400,
                  columnNumber: 17
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
                lineNumber: 398,
                columnNumber: 23
              }, this)
            ] }, question.id, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
              lineNumber: 396,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
          lineNumber: 393,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
        lineNumber: 382,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
      lineNumber: 378,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 32, padding: 16, borderRadius: 8, background: "var(--surface-2)" }, children: /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood", style: { textDecoration: "none" }, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", children: "← Voltar ao iFood" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
      lineNumber: 415,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
      lineNumber: 414,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
      lineNumber: 413,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx",
    lineNumber: 128,
    columnNumber: 5
  }, this);
}
_s(IFoodReviewsDetailedPage, "PKRzIT6R2xh2zP7F8Ibf/uol6tA=", false, function() {
  return [useAuthStore, useToast, useQueryClient, useQuery, useQuery, useQuery, useMutation];
});
_c = IFoodReviewsDetailedPage;
var _c;
$RefreshReg$(_c, "IFoodReviewsDetailedPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodReviewsDetailedPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0ZROzs7Ozs7Ozs7Ozs7Ozs7OztBQWxGUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUVLO0FBQ1AsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxtQkFBbUJDLDJCQUEyQjtBQUV2RCxNQUFNQyxZQUFZO0FBRWxCLE1BQU1DLG1CQUFtQjtBQUVsQixnQkFBU0MsMkJBQTJCO0FBQUFDLEtBQUE7QUFDekMsUUFBTSxFQUFFQyxTQUFTLElBQUloQixhQUFhO0FBQ2xDLFFBQU1pQixRQUFRaEIsU0FBUztBQUN2QixRQUFNaUIsY0FBY3ZCLGVBQWU7QUFDbkMsUUFBTSxDQUFDd0IsV0FBV0MsWUFBWSxJQUFJN0IsU0FBUyxRQUFRO0FBQ25ELFFBQU0sQ0FBQzhCLE1BQU1DLE9BQU8sSUFBSS9CLFNBQVMsQ0FBQztBQUNsQyxRQUFNLENBQUNnQyxnQkFBZ0JDLGlCQUFpQixJQUFJakMsU0FBcUMsSUFBSTtBQUNyRixRQUFNLENBQUNrQyxXQUFXQyxZQUFZLElBQUluQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDb0MsV0FBV0MsWUFBWSxJQUFJckMsU0FBd0IsSUFBSTtBQUU5RCxRQUFNc0MsZUFBZW5DLFNBQVM7QUFBQSxJQUM1Qm9DLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxXQUFXLFdBQVdkLFFBQVE7QUFBQSxJQUNsRWUsU0FBU0EsTUFBTWpDLHVCQUF1QmtCLFFBQVE7QUFBQSxFQUNoRCxDQUFDO0FBRUQsUUFBTWdCLGVBQWV0QyxTQUFTO0FBQUEsSUFDNUJvQyxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsV0FBV2QsVUFBVUssSUFBSTtBQUFBLElBQzdEVSxTQUFTQSxNQUFNbEMsZ0JBQWdCbUIsVUFBVSxFQUFFSyxNQUFNWSxVQUFVckIsVUFBVSxDQUFDO0FBQUEsSUFDdEVzQixpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTUMsY0FBY3pDLFNBQVM7QUFBQSxJQUMzQm9DLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUyxXQUFXLFVBQVVkLFVBQVVXLFNBQVM7QUFBQSxJQUM1RUksU0FBU0EsTUFBTW5DLG1CQUFtQm9CLFVBQVVXLFNBQVU7QUFBQSxJQUN0RFMsU0FBUyxDQUFDLENBQUNUO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1VLGdCQUFnQjVDLFlBQVk7QUFBQSxJQUNoQzZDLFlBQVlBLENBQUNDLFlBQ1h4QyxpQkFBaUJpQixVQUFVdUIsUUFBUUMsVUFBVUQsUUFBUUUsSUFBSTtBQUFBLElBQzNEQyxXQUFXQSxNQUFNO0FBQ2Z6QixZQUFNMEIsUUFBUSw0QkFBNEI7QUFDMUNuQix3QkFBa0IsSUFBSTtBQUN0QkUsbUJBQWEsRUFBRTtBQUNmLFdBQUtSLFlBQVkwQixrQkFBa0IsRUFBRWQsVUFBVSxDQUFDLGdCQUFnQixTQUFTLFNBQVMsRUFBRSxDQUFDO0FBQUEsSUFDdkY7QUFBQSxJQUNBZSxTQUFTQSxNQUFNNUIsTUFBTTZCLE1BQU0sMkJBQTJCO0FBQUEsRUFDeEQsQ0FBQztBQUVELFFBQU1DLFVBQVVmLGFBQWFnQixNQUFNRCxXQUFXO0FBRzlDLFFBQU1FLGNBQWNGLFFBQVFHLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDQSxFQUFFQyxLQUFLO0FBQ2xELFFBQU1DLGlCQUFpQk4sUUFBUUcsT0FBTyxDQUFDQyxNQUFNLENBQUMsQ0FBQ0EsRUFBRUMsS0FBSztBQUN0RCxRQUFNRSxpQkFBaUJuQyxjQUFjLFdBQVc4QixjQUFjSTtBQUU5RCxRQUFNRSxVQUFVMUIsYUFBYW1CO0FBQzdCLFFBQU1RLFdBQVdELFNBQVNFLFNBQVMsT0FBT0YsUUFBUUUsTUFBTUMsUUFBUSxDQUFDLElBQUk7QUFDckUsUUFBTUMsZUFBZUosU0FBU0sscUJBQXFCNUIsYUFBYWdCLE1BQU1hLFNBQVNkLFFBQVFlO0FBQ3ZGLFFBQU1DLFlBQVkvQixhQUFhZ0IsTUFBTWUsYUFBYTtBQUVsRCxRQUFNQyxlQUFldkMsVUFBVXFDLFNBQVNqRDtBQUV4QyxNQUFJbUIsYUFBYWlDLFdBQVc7QUFDMUIsV0FDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsU0FBUyxJQUFJQyxVQUFVLEtBQU1DLFFBQVEsU0FBUyxHQUMzRDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixVQUFTO0FBQUEsVUFDVCxZQUFZLENBQUMsRUFBRUMsT0FBTyxTQUFTQyxNQUFNLHFCQUFxQixDQUFDO0FBQUE7QUFBQSxRQUg3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHK0Q7QUFBQSxNQUUvRCx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsV0FBVyxVQUFVTCxTQUFTLFlBQVksR0FDdEQsaUNBQUMsT0FBRSxPQUFPLEVBQUVNLE9BQU8sbUJBQW1CLEdBQUcsd0NBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUUsS0FEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxFQUVKO0FBRUEsTUFBSXhDLGFBQWF5QyxTQUFTO0FBQ3hCLFdBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUVQLFNBQVMsSUFBSUMsVUFBVSxLQUFNQyxRQUFRLFNBQVMsR0FDM0Q7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sVUFBUztBQUFBLFVBQ1QsWUFBWSxDQUFDLEVBQUVDLE9BQU8sU0FBU0MsTUFBTSxxQkFBcUIsQ0FBQztBQUFBO0FBQUEsUUFIN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRytEO0FBQUEsTUFFL0QsdUJBQUMsY0FBVyxPQUFPdEMsYUFBYWMsT0FBTyxNQUFLLG1CQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJEO0FBQUEsU0FON0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUVvQixTQUFTLElBQUlDLFVBQVUsS0FBTUMsUUFBUSxTQUFTLEdBQzNEO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLFVBQVM7QUFBQSxRQUNULFlBQVksQ0FBQyxFQUFFQyxPQUFPLFNBQVNDLE1BQU0scUJBQXFCLENBQUM7QUFBQSxRQUMzRCxTQUNFLHVCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVMsTUFBTXRDLGFBQWEwQyxRQUFRLEdBQUcsVUFBVTFDLGFBQWEyQyxjQUFjO0FBQUE7QUFBQSxVQUM5RjNDLGFBQWEyQyxlQUFlLG1CQUFtQjtBQUFBLGFBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRRztBQUFBLElBSUg7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU87QUFBQSxVQUNMQyxTQUFTO0FBQUEsVUFDVEMscUJBQXFCO0FBQUEsVUFDckJDLEtBQUs7QUFBQSxVQUNMQyxjQUFjO0FBQUEsUUFDaEI7QUFBQSxRQUVBO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU8sR0FBR3ZCLFFBQVE7QUFBQSxjQUNsQixVQUFVLE1BQU1HLFlBQVk7QUFBQSxjQUM1QixRQUFPO0FBQUEsY0FDUCxNQUFLO0FBQUE7QUFBQSxZQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtXO0FBQUEsVUFFWDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBT1YsWUFBWWE7QUFBQUEsY0FDbkIsUUFBUWIsWUFBWWEsU0FBUyxJQUFJLFlBQVk7QUFBQSxjQUM3QyxNQUFLO0FBQUE7QUFBQSxZQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlXO0FBQUEsVUFFWCx1QkFBQyxpQkFBYyxPQUFNLHdCQUF1QixPQUFPVCxlQUFlUyxRQUFRLFFBQU8sV0FBVSxNQUFLLE9BQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1HO0FBQUEsVUFDbkc7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU8sSUFBS1QsZUFBZVMsU0FBU2tCLEtBQUtDLElBQUlsQyxRQUFRZSxRQUFRLENBQUMsSUFBSyxLQUFLSixRQUFRLENBQUMsQ0FBQztBQUFBLGNBQ2xGLFFBQU87QUFBQSxjQUNQLE1BQUs7QUFBQTtBQUFBLFlBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSVc7QUFBQTtBQUFBO0FBQUEsTUExQmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNEJBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTTtBQUFBLFVBQ0osRUFBRXdCLElBQUksVUFBVWIsT0FBTyxtQkFBbUJjLE9BQU9sQyxZQUFZYSxPQUFPO0FBQUEsVUFDcEUsRUFBRW9CLElBQUksY0FBY2IsT0FBTyxlQUFlYyxPQUFPOUIsZUFBZVMsT0FBTztBQUFBLFFBQUM7QUFBQSxRQUUxRTtBQUFBLFFBQ0EsYUFBYTFDO0FBQUFBLFFBRVprQyx5QkFBZVEsV0FBVyxJQUN6Qix1QkFBQyxTQUFJLE9BQU8sRUFBRXNCLFdBQVcsR0FBRyxHQUMxQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBT2pFLGNBQWMsV0FBVyx1QkFBdUI7QUFBQSxZQUN2RCxhQUNFQSxjQUFjLFdBQ1YseURBQ0E7QUFBQTtBQUFBLFVBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUcsS0FQTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0EsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXlELFNBQVMsUUFBUUUsS0FBSyxJQUFJTSxXQUFXLEdBQUcsR0FDbkQ5Qix5QkFBZStCLElBQUksQ0FBQ0MsV0FBVztBQUM5QixnQkFBTUMsZUFBZTdFLGtCQUFrQjRFLE9BQU9sQyxRQUFRLFdBQVcsTUFBTTtBQUN2RSxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFYyxTQUFTLElBQUlzQixZQUFZLGFBQWFELGFBQWFmLEtBQUssR0FBRztBQUFBLGNBRXBFO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBTztBQUFBLHNCQUNMSSxTQUFTO0FBQUEsc0JBQ1RDLHFCQUFxQjtBQUFBLHNCQUNyQlksWUFBWTtBQUFBLHNCQUNaWCxLQUFLO0FBQUEsc0JBQ0xDLGNBQWM7QUFBQSxvQkFDaEI7QUFBQSxvQkFFQTtBQUFBLDZDQUFDLFNBQ0M7QUFBQSwrQ0FBQyxTQUFJLE9BQU8sRUFBRUgsU0FBUyxRQUFRRSxLQUFLLEdBQUdXLFlBQVksVUFBVVYsY0FBYyxFQUFFLEdBQzNFO0FBQUEsaURBQUMsVUFBSyxPQUFPLEVBQUVXLFVBQVUsU0FBUyxHQUMvQkosaUJBQU83QixTQUFTLE9BQU8sSUFBSWtDLE9BQU9YLEtBQUtZLE1BQU1OLE9BQU83QixLQUFLLENBQUMsSUFBSSxPQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0M2QixPQUFPN0IsU0FBUyxRQUNmLHVCQUFDLFVBQUssT0FBTyxFQUFFaUMsVUFBVSxVQUFVbEIsT0FBTyxtQkFBbUIsR0FDMURjLGlCQUFPN0IsTUFBTUMsUUFBUSxDQUFDLEtBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVNBO0FBQUEsd0JBQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVnQyxVQUFVLFVBQVVHLFlBQVksS0FBS3pCLFFBQVEsR0FBR1csY0FBYyxFQUFFLEdBQUc7QUFBQTtBQUFBLDBCQUNyRU8sT0FBT1EsT0FBT0MsV0FBV1QsT0FBT1EsT0FBT1osTUFBTTtBQUFBLDZCQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVRLFVBQVUsVUFBVWxCLE9BQU8sb0JBQW9CSixRQUFRLEVBQUUsR0FDbEVrQixpQkFBT1UsWUFBWXJGLG9CQUFvQjJFLE9BQU9VLFNBQVMsSUFBSSxPQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsMkJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBaUJBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsT0FBTztBQUFBLDRCQUNMTixVQUFVO0FBQUEsNEJBQ1Z4QixTQUFTO0FBQUEsNEJBQ1QrQixjQUFjO0FBQUEsNEJBQ2RDLFlBQVlYLGFBQWFmLFFBQVE7QUFBQSw0QkFDakNBLE9BQU9lLGFBQWFmO0FBQUFBLDRCQUNwQnFCLFlBQVk7QUFBQSwwQkFDZDtBQUFBLDBCQUVDTjtBQUFBQSx5Q0FBYVk7QUFBQUEsNEJBQUs7QUFBQSw0QkFBRVosYUFBYWxCO0FBQUFBO0FBQUFBO0FBQUFBLHdCQVZwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBV0E7QUFBQTtBQUFBO0FBQUEsa0JBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF1Q0E7QUFBQSxnQkFHQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPO0FBQUEsc0JBQ0xILFNBQVM7QUFBQSxzQkFDVCtCLGNBQWM7QUFBQSxzQkFDZEMsWUFBWTtBQUFBLHNCQUNabkIsY0FBYztBQUFBLHNCQUNkUyxZQUFZO0FBQUEsb0JBQ2Q7QUFBQSxvQkFFQSxpQ0FBQyxPQUFFLE9BQU8sRUFBRUUsVUFBVSxVQUFVdEIsUUFBUSxHQUFHZ0MsWUFBWSxJQUFJLEdBQ3hEZCxpQkFBT2UsV0FBVywrQkFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUEsa0JBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlBO0FBQUEsZ0JBR0NmLE9BQU9sQyxTQUNOO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU87QUFBQSxzQkFDTGMsU0FBUztBQUFBLHNCQUNUK0IsY0FBYztBQUFBLHNCQUNkQyxZQUFZO0FBQUEsc0JBQ1pWLFlBQVk7QUFBQSxzQkFDWlQsY0FBYztBQUFBLG9CQUNoQjtBQUFBLG9CQUVBO0FBQUEsNkNBQUMsT0FBRSxPQUFPLEVBQUVXLFVBQVUsV0FBV0csWUFBWSxLQUFLckIsT0FBTyxXQUFXSixRQUFRLFVBQVUsR0FBRyxtQ0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLE9BQUUsT0FBTyxFQUFFc0IsVUFBVSxVQUFVdEIsUUFBUSxHQUFHZ0MsWUFBWSxJQUFJLEdBQUlkLGlCQUFPbEMsU0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEU7QUFBQTtBQUFBO0FBQUEsa0JBWjlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFhQTtBQUFBLGdCQUlGLHVCQUFDLFNBQUksT0FBTyxFQUFFd0IsU0FBUyxRQUFRRSxLQUFLLEVBQUUsR0FDcEM7QUFBQSx5Q0FBQyxVQUFPLFNBQVEsU0FBUSxTQUFTLE1BQU1sRCxhQUFhMEQsT0FBT0osRUFBRSxHQUFHLCtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0MsQ0FBQ0ksT0FBT2xDLFNBQ1AsdUJBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNNUIsa0JBQWtCOEQsTUFBTSxHQUFHLE9BQU8sRUFBRWdCLE1BQU0sRUFBRSxHQUFHLDRCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBO0FBQUE7QUFBQSxZQXhGS2hCLE9BQU9KO0FBQUFBLFlBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTBGQTtBQUFBLFFBRUosQ0FBQyxLQWhHSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUdBO0FBQUE7QUFBQSxNQXJISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1SEE7QUFBQSxJQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFTixTQUFTLFFBQVFFLEtBQUssR0FBR1csWUFBWSxVQUFVYyxnQkFBZ0IsVUFBVW5CLFdBQVcsR0FBRyxHQUNuRztBQUFBLDZCQUFDLFVBQU8sU0FBUSxTQUFRLFVBQVUvRCxRQUFRLEdBQUcsU0FBUyxNQUFNQyxRQUFRLENBQUNrRixNQUFNeEIsS0FBS0MsSUFBSSxHQUFHdUIsSUFBSSxDQUFDLENBQUMsR0FBRywwQkFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRWQsVUFBVSxXQUFXbEIsT0FBTyxtQkFBbUIsR0FBRztBQUFBO0FBQUEsUUFDdkRuRDtBQUFBQSxRQUFLO0FBQUEsUUFBSzJELEtBQUtDLElBQUlsQixXQUFXLENBQUM7QUFBQSxXQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQU8sU0FBUSxTQUFRLFVBQVUxQyxRQUFRMEMsV0FBVyxTQUFTLE1BQU16QyxRQUFRLENBQUNrRixNQUFNQSxJQUFJLENBQUMsR0FBRyx5QkFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUdDakYsa0JBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLFNBQVMsTUFBTTtBQUNiQyw0QkFBa0IsSUFBSTtBQUN0QkUsdUJBQWEsRUFBRTtBQUFBLFFBQ2pCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRWtELFNBQVMsUUFBUUUsS0FBSyxHQUFHLEdBQ3JDO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLE9BQUUsT0FBTyxFQUFFWSxVQUFVLFVBQVVHLFlBQVksS0FBS3pCLFFBQVEsVUFBVSxHQUFHO0FBQUE7QUFBQSxjQUMvQzdDLGVBQWV1RSxPQUFPQyxXQUFXeEUsZUFBZXVFLE9BQU9aLE1BQU07QUFBQSxpQkFEcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPO0FBQUEsa0JBQ0xoQixTQUFTO0FBQUEsa0JBQ1RnQyxZQUFZO0FBQUEsa0JBQ1pELGNBQWM7QUFBQSxrQkFDZFQsWUFBWTtBQUFBLGdCQUNkO0FBQUEsZ0JBRUE7QUFBQSx5Q0FBQyxTQUFJLE9BQU8sRUFBRUUsVUFBVSxRQUFRWCxjQUFjLEVBQUUsR0FDN0N4RCx5QkFBZWtDLFNBQVMsT0FBTyxJQUFJa0MsT0FBT1gsS0FBS1ksTUFBTXJFLGVBQWVrQyxLQUFLLENBQUMsSUFBSSxPQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVpQyxVQUFVLFVBQVV0QixRQUFRLEdBQUdnQyxZQUFZLElBQUksR0FDeEQ3RSx5QkFBZThFLFdBQVcsK0JBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sTUFBTSxHQUFHNUUsVUFBVXFDLE1BQU0sSUFBSWpELGdCQUFnQjtBQUFBLGNBQzdDLE9BQU9tRCxlQUFlLHVCQUF1Qm5ELGdCQUFnQixpQkFBaUI0RjtBQUFBQSxjQUU3RSxXQUFDQyxTQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLEdBQUlBO0FBQUFBLGtCQUNKLE1BQU07QUFBQSxrQkFDTixXQUFXN0Y7QUFBQUEsa0JBQ1gsT0FBT1k7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDa0YsTUFBTWpGLGFBQWFpRixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsa0JBQzVDLGFBQVk7QUFBQTtBQUFBLGdCQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1pRDtBQUFBO0FBQUEsWUFackQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFakMsU0FBUyxRQUFRRSxLQUFLLEdBQUd5QixnQkFBZ0IsV0FBVyxHQUNoRTtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLFNBQVMsTUFBTTtBQUNiL0Usb0NBQWtCLElBQUk7QUFDdEJFLCtCQUFhLEVBQUU7QUFBQSxnQkFDakI7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFRO0FBQUEsZ0JBQ1IsU0FBUyxNQUFNVyxjQUFjeUUsT0FBTyxFQUFFdEUsVUFBVWpCLGVBQWUyRCxJQUFJekMsTUFBTWhCLFVBQVVzRixLQUFLLEVBQUUsQ0FBQztBQUFBLGdCQUMzRixVQUFVLENBQUN0RixVQUFVc0YsS0FBSyxLQUFLL0MsZ0JBQWdCM0IsY0FBYzJFO0FBQUFBLGdCQUU1RDNFLHdCQUFjMkUsWUFBWSxnQkFBZ0I7QUFBQTtBQUFBLGNBTDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxhQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeURBO0FBQUE7QUFBQSxNQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFpRUE7QUFBQSxJQUlEckYsYUFDQyx1QkFBQyxTQUFNLE9BQU0seUJBQXdCLFNBQVMsTUFBTUMsYUFBYSxJQUFJLEdBQ2xFTztBQUFBQSxrQkFBWThCLGFBQWEsdUJBQUMsT0FBRSxPQUFPLEVBQUVPLE9BQU8sbUJBQW1CLEdBQUcsNkJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Q7QUFBQSxNQUMvRXJDLFlBQVlzQyxXQUFXLHVCQUFDLGNBQVcsT0FBT3RDLFlBQVlXLE9BQU8sTUFBSyw4QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLE1BQzVGWCxZQUFZYSxRQUNYLHVCQUFDLFNBQUksT0FBTyxFQUFFNEIsU0FBUyxRQUFRRSxLQUFLLEdBQUcsR0FDckM7QUFBQSwrQkFBQyxPQUFFLE9BQU8sRUFBRVYsUUFBUSxHQUFHc0IsVUFBVSxTQUFTLEdBQ3hDO0FBQUEsaUNBQUMsWUFBTyx3QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLFVBQVM7QUFBQSxVQUFFdkQsWUFBWWEsS0FBS2lFLGdCQUFnQjtBQUFBLGFBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUU3QyxRQUFRLEdBQUdzQixVQUFVLFNBQVMsR0FDeEM7QUFBQSxpQ0FBQyxZQUFPLHFCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWE7QUFBQSxVQUFTO0FBQUEsVUFBRXZELFlBQVlhLEtBQUtTLFNBQVMsT0FBT3RCLFlBQVlhLEtBQUtTLE1BQU1DLFFBQVEsQ0FBQyxJQUFJO0FBQUEsYUFEL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLE9BQU8sRUFBRVUsUUFBUSxHQUFHc0IsVUFBVSxTQUFTLEdBQ3hDO0FBQUEsaUNBQUMsWUFBTywyQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQjtBQUFBLFVBQVM7QUFBQSxVQUFFdkQsWUFBWWEsS0FBS3FELFdBQVc7QUFBQSxhQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDbEUsWUFBWWEsS0FBS2tFLFVBQVVwRCxTQUFTLEtBQ25DLHVCQUFDLFNBQUksT0FBTyxFQUFFYyxTQUFTLFFBQVFFLEtBQUssRUFBRSxHQUNwQztBQUFBLGlDQUFDLFlBQU8sT0FBTyxFQUFFWSxVQUFVLFNBQVMsR0FBRyx5QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUMvQ3ZELFlBQVlhLEtBQUtrRSxVQUFVN0I7QUFBQUEsWUFBSSxDQUFDOEIsYUFDL0IsdUJBQUMsU0FBc0IsV0FBVSxRQUFPLE9BQU8sRUFBRWpELFNBQVMsR0FBRyxHQUMzRDtBQUFBLHFDQUFDLE9BQUUsT0FBTyxFQUFFRSxRQUFRLEdBQUdzQixVQUFVLFVBQVVHLFlBQVksSUFBSSxHQUFJc0IsbUJBQVNDLFNBQVNELFNBQVNqQyxNQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RjtBQUFBLGNBQzdGLHVCQUFDLFFBQUcsT0FBTyxFQUFFZCxRQUFRLFdBQVdpRCxhQUFhLElBQUkzQixVQUFVLFVBQVUsR0FDbEV5QixtQkFBU0csUUFBUWpDO0FBQUFBLGdCQUFJLENBQUNrQyxXQUNyQix1QkFBQyxRQUFvQkEsaUJBQU9ILFNBQVNHLE9BQU9yQyxNQUFuQ3FDLE9BQU9yQyxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQztBQUFBLGNBQ2hELEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQU5RaUMsU0FBU2pDLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxVQUNEO0FBQUEsYUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsU0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStCQTtBQUFBLElBSUYsdUJBQUMsU0FBSSxPQUFPLEVBQUVFLFdBQVcsSUFBSWxCLFNBQVMsSUFBSStCLGNBQWMsR0FBR0MsWUFBWSxtQkFBbUIsR0FDeEYsaUNBQUMsUUFBSyxJQUFHLHNCQUFxQixPQUFPLEVBQUVzQixnQkFBZ0IsT0FBTyxHQUM1RCxpQ0FBQyxVQUFPLFNBQVEsU0FBUSxpQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQWpTRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa1NBO0FBRUo7QUFBQ3pHLEdBdFhlRCwwQkFBd0I7QUFBQSxVQUNqQmQsY0FDUEMsVUFDTU4sZ0JBT0NELFVBS0FBLFVBTURBLFVBTUVELFdBQVc7QUFBQTtBQUFBLEtBM0JuQnFCO0FBQXdCLElBQUEyRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkxpbmsiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJnZXRJRm9vZFJldmlld0J5SWQiLCJnZXRJRm9vZFJldmlld3MiLCJnZXRJRm9vZFJldmlld3NTdW1tYXJ5IiwicmVwbHlJRm9vZFJldmlldyIsInVzZUF1dGhTdG9yZSIsInVzZVRvYXN0IiwiQnV0dG9uIiwiTW9kYWwiLCJGaWVsZCIsIlBhZ2VIZWFkZXIiLCJRdWVyeUVycm9yIiwiRW1wdHlTdGF0ZSIsIlRhYnMiLCJEYXNoYm9hcmRDYXJkIiwiZm9ybWF0UmV2aWV3U3RhdGUiLCJmb3JtYXREYXRlVGltZVNob3J0IiwiUEFHRV9TSVpFIiwiTUFYX1JFUExZX0xFTkdUSCIsIklGb29kUmV2aWV3c0RldGFpbGVkUGFnZSIsIl9zIiwiYnJhbmNoSWQiLCJ0b2FzdCIsInF1ZXJ5Q2xpZW50IiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwicGFnZSIsInNldFBhZ2UiLCJyZXBseWluZ1JldmlldyIsInNldFJlcGx5aW5nUmV2aWV3IiwicmVwbHlUZXh0Iiwic2V0UmVwbHlUZXh0Iiwidmlld2luZ0lkIiwic2V0Vmlld2luZ0lkIiwic3VtbWFyeVF1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwicmV2aWV3c1F1ZXJ5IiwicGFnZVNpemUiLCJyZWZldGNoSW50ZXJ2YWwiLCJkZXRhaWxRdWVyeSIsImVuYWJsZWQiLCJyZXBseU11dGF0aW9uIiwibXV0YXRpb25GbiIsInBheWxvYWQiLCJyZXZpZXdJZCIsInRleHQiLCJvblN1Y2Nlc3MiLCJzdWNjZXNzIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJvbkVycm9yIiwiZXJyb3IiLCJyZXZpZXdzIiwiZGF0YSIsIm9wZW5SZXZpZXdzIiwiZmlsdGVyIiwiciIsInJlcGx5IiwicmVwbGllZFJldmlld3MiLCJkaXNwbGF5UmV2aWV3cyIsInN1bW1hcnkiLCJhdmdTY29yZSIsInNjb3JlIiwidG9GaXhlZCIsInRvdGFsUmV2aWV3cyIsInRvdGFsUmV2aWV3c0NvdW50IiwidG90YWwiLCJsZW5ndGgiLCJwYWdlQ291bnQiLCJyZXBseVRvb0xvbmciLCJpc0xvYWRpbmciLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJsYWJlbCIsImhyZWYiLCJ0ZXh0QWxpZ24iLCJjb2xvciIsImlzRXJyb3IiLCJyZWZldGNoIiwiaXNSZWZldGNoaW5nIiwiZGlzcGxheSIsImdyaWRUZW1wbGF0ZUNvbHVtbnMiLCJnYXAiLCJtYXJnaW5Cb3R0b20iLCJNYXRoIiwibWF4IiwiaWQiLCJiYWRnZSIsIm1hcmdpblRvcCIsIm1hcCIsInJldmlldyIsInN0YXRlRGlzcGxheSIsImJvcmRlckxlZnQiLCJhbGlnbkl0ZW1zIiwiZm9udFNpemUiLCJyZXBlYXQiLCJyb3VuZCIsImZvbnRXZWlnaHQiLCJvcmRlciIsInNob3J0SWQiLCJjcmVhdGVkQXQiLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kIiwiaWNvbiIsImxpbmVIZWlnaHQiLCJjb21tZW50IiwiZmxleCIsImp1c3RpZnlDb250ZW50IiwicCIsInVuZGVmaW5lZCIsImExMXkiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJtdXRhdGUiLCJ0cmltIiwiaXNQZW5kaW5nIiwiY3VzdG9tZXJOYW1lIiwicXVlc3Rpb25zIiwicXVlc3Rpb24iLCJ0aXRsZSIsInBhZGRpbmdMZWZ0IiwiYW5zd2VycyIsImFuc3dlciIsInRleHREZWNvcmF0aW9uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSUZvb2RSZXZpZXdzRGV0YWlsZWRQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHtcclxuICBnZXRJRm9vZFJldmlld0J5SWQsXHJcbiAgZ2V0SUZvb2RSZXZpZXdzLFxyXG4gIGdldElGb29kUmV2aWV3c1N1bW1hcnksXHJcbiAgcmVwbHlJRm9vZFJldmlldyxcclxuICB0eXBlIElGb29kUmV2aWV3TGlzdEl0ZW0sXHJcbn0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIi4uLy4uL3VpL1RvYXN0XCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCIuLi8uLi91aS9CdXR0b25cIjtcclxuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiLi4vLi4vdWkvTW9kYWxcIjtcclxuaW1wb3J0IHsgRmllbGQgfSBmcm9tIFwiLi4vLi4vdWkvRmllbGRcIjtcclxuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1BhZ2VIZWFkZXJcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCIuLi8uLi91aS9FbXB0eVN0YXRlXCI7XHJcbmltcG9ydCB7IFRhYnMgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9UYWJzXCI7XHJcbmltcG9ydCB7IERhc2hib2FyZENhcmQgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9EYXNoYm9hcmRDYXJkXCI7XHJcbmltcG9ydCB7IGZvcm1hdFJldmlld1N0YXRlLCBmb3JtYXREYXRlVGltZVNob3J0IH0gZnJvbSBcIi4uLy4uL3V0aWxzL2lmb29kRm9ybWF0dGVyc0VuaGFuY2VkXCI7XHJcblxyXG5jb25zdCBQQUdFX1NJWkUgPSAyMDtcclxuLy8gTGltaXRlIGRvIHRleHRvIGRlIHJlc3Bvc3RhIGFjZWl0byBwZWxvIGlGb29kIChtw7NkdWxvIFJldmlldyB2MS4wKS5cclxuY29uc3QgTUFYX1JFUExZX0xFTkdUSCA9IDUwMDtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJRm9vZFJldmlld3NEZXRhaWxlZFBhZ2UoKSB7XHJcbiAgY29uc3QgeyBicmFuY2hJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUoXCJhYmVydGFcIik7XHJcbiAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMSk7XHJcbiAgY29uc3QgW3JlcGx5aW5nUmV2aWV3LCBzZXRSZXBseWluZ1Jldmlld10gPSB1c2VTdGF0ZTxJRm9vZFJldmlld0xpc3RJdGVtIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW3JlcGx5VGV4dCwgc2V0UmVwbHlUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt2aWV3aW5nSWQsIHNldFZpZXdpbmdJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3Qgc3VtbWFyeVF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwicmV2aWV3c1wiLCBcInN1bW1hcnlcIiwgYnJhbmNoSWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RSZXZpZXdzU3VtbWFyeShicmFuY2hJZCksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJldmlld3NRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcInJldmlld3NcIiwgYnJhbmNoSWQsIHBhZ2VdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0SUZvb2RSZXZpZXdzKGJyYW5jaElkLCB7IHBhZ2UsIHBhZ2VTaXplOiBQQUdFX1NJWkUgfSksXHJcbiAgICByZWZldGNoSW50ZXJ2YWw6IDYwMDAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBkZXRhaWxRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcInJldmlld3NcIiwgXCJkZXRhaWxcIiwgYnJhbmNoSWQsIHZpZXdpbmdJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZFJldmlld0J5SWQoYnJhbmNoSWQsIHZpZXdpbmdJZCEpLFxyXG4gICAgZW5hYmxlZDogISF2aWV3aW5nSWQsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJlcGx5TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAocGF5bG9hZDogeyByZXZpZXdJZDogc3RyaW5nOyB0ZXh0OiBzdHJpbmcgfSkgPT5cclxuICAgICAgcmVwbHlJRm9vZFJldmlldyhicmFuY2hJZCwgcGF5bG9hZC5yZXZpZXdJZCwgcGF5bG9hZC50ZXh0KSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICB0b2FzdC5zdWNjZXNzKFwiUmVzcG9zdGEgZW52aWFkYSBhbyBpRm9vZC5cIik7XHJcbiAgICAgIHNldFJlcGx5aW5nUmV2aWV3KG51bGwpO1xyXG4gICAgICBzZXRSZXBseVRleHQoXCJcIik7XHJcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiaW50ZWdyYXRpb25zXCIsIFwiaWZvb2RcIiwgXCJyZXZpZXdzXCJdIH0pO1xyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6ICgpID0+IHRvYXN0LmVycm9yKFwiRmFsaGEgYW8gZW52aWFyIHJlc3Bvc3RhLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcmV2aWV3cyA9IHJldmlld3NRdWVyeS5kYXRhPy5yZXZpZXdzID8/IFtdO1xyXG4gIC8vIEEgbGlzdGEgZG8gaUZvb2QgbsOjbyB0ZW0gdW0gZXN0YWRvIGRlIHJlc3Bvc3RhOiBcInJlc3BvbmRpZGFcIiDDqSBhIGF2YWxpYcOnw6NvIHF1ZSBqw6EgdGVtXHJcbiAgLy8gYHJlcGx5YCBwcmVlbmNoaWRvLlxyXG4gIGNvbnN0IG9wZW5SZXZpZXdzID0gcmV2aWV3cy5maWx0ZXIoKHIpID0+ICFyLnJlcGx5KTtcclxuICBjb25zdCByZXBsaWVkUmV2aWV3cyA9IHJldmlld3MuZmlsdGVyKChyKSA9PiAhIXIucmVwbHkpO1xyXG4gIGNvbnN0IGRpc3BsYXlSZXZpZXdzID0gYWN0aXZlVGFiID09PSBcImFiZXJ0YVwiID8gb3BlblJldmlld3MgOiByZXBsaWVkUmV2aWV3cztcclxuXHJcbiAgY29uc3Qgc3VtbWFyeSA9IHN1bW1hcnlRdWVyeS5kYXRhO1xyXG4gIGNvbnN0IGF2Z1Njb3JlID0gc3VtbWFyeT8uc2NvcmUgIT0gbnVsbCA/IHN1bW1hcnkuc2NvcmUudG9GaXhlZCgxKSA6IFwi4oCUXCI7XHJcbiAgY29uc3QgdG90YWxSZXZpZXdzID0gc3VtbWFyeT8udG90YWxSZXZpZXdzQ291bnQgPz8gcmV2aWV3c1F1ZXJ5LmRhdGE/LnRvdGFsID8/IHJldmlld3MubGVuZ3RoO1xyXG4gIGNvbnN0IHBhZ2VDb3VudCA9IHJldmlld3NRdWVyeS5kYXRhPy5wYWdlQ291bnQgPz8gMTtcclxuXHJcbiAgY29uc3QgcmVwbHlUb29Mb25nID0gcmVwbHlUZXh0Lmxlbmd0aCA+IE1BWF9SRVBMWV9MRU5HVEg7XHJcblxyXG4gIGlmIChyZXZpZXdzUXVlcnkuaXNMb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDEwMDAsIG1hcmdpbjogXCIwIGF1dG9cIiB9fT5cclxuICAgICAgICA8UGFnZUhlYWRlclxyXG4gICAgICAgICAgdGl0bGU9XCJBdmFsaWHDp8O1ZXMgaUZvb2RcIlxyXG4gICAgICAgICAgc3VidGl0bGU9XCJHZXJlbmNpZSByZXNwb3N0YXMgYSBjbGllbnRlc1wiXHJcbiAgICAgICAgICBicmVhZGNydW1iPXtbeyBsYWJlbDogXCJpRm9vZFwiLCBocmVmOiBcIi9pbnRlZ3JhY29lcy9pZm9vZFwiIH1dfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIHBhZGRpbmc6IFwiNDBweCAyMHB4XCIgfX0+XHJcbiAgICAgICAgICA8cCBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+Q2FycmVnYW5kbyBhdmFsaWHDp8O1ZXMuLi48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAocmV2aWV3c1F1ZXJ5LmlzRXJyb3IpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxtYWluIHN0eWxlPXt7IHBhZGRpbmc6IDIyLCBtYXhXaWR0aDogMTAwMCwgbWFyZ2luOiBcIjAgYXV0b1wiIH19PlxyXG4gICAgICAgIDxQYWdlSGVhZGVyXHJcbiAgICAgICAgICB0aXRsZT1cIkF2YWxpYcOnw7VlcyBpRm9vZFwiXHJcbiAgICAgICAgICBzdWJ0aXRsZT1cIkdlcmVuY2llIHJlc3Bvc3RhcyBhIGNsaWVudGVzXCJcclxuICAgICAgICAgIGJyZWFkY3J1bWI9e1t7IGxhYmVsOiBcImlGb29kXCIsIGhyZWY6IFwiL2ludGVncmFjb2VzL2lmb29kXCIgfV19XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8UXVlcnlFcnJvciBlcnJvcj17cmV2aWV3c1F1ZXJ5LmVycm9yfSB3aGF0PVwiYXMgYXZhbGlhw6fDtWVzXCIgLz5cclxuICAgICAgPC9tYWluPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBzdHlsZT17eyBwYWRkaW5nOiAyMiwgbWF4V2lkdGg6IDEwMDAsIG1hcmdpbjogXCIwIGF1dG9cIiB9fT5cclxuICAgICAgPFBhZ2VIZWFkZXJcclxuICAgICAgICB0aXRsZT1cIkF2YWxpYcOnw7VlcyBpRm9vZFwiXHJcbiAgICAgICAgc3VidGl0bGU9XCJHZXJlbmNpZSByZXNwb3N0YXMgYSBjbGllbnRlc1wiXHJcbiAgICAgICAgYnJlYWRjcnVtYj17W3sgbGFiZWw6IFwiaUZvb2RcIiwgaHJlZjogXCIvaW50ZWdyYWNvZXMvaWZvb2RcIiB9XX1cclxuICAgICAgICBhY3Rpb25zPXtcclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gcmV2aWV3c1F1ZXJ5LnJlZmV0Y2goKX0gZGlzYWJsZWQ9e3Jldmlld3NRdWVyeS5pc1JlZmV0Y2hpbmd9PlxyXG4gICAgICAgICAgICDwn5SEIHtyZXZpZXdzUXVlcnkuaXNSZWZldGNoaW5nID8gXCJBdHVhbGl6YW5kby4uLlwiIDogXCJBdHVhbGl6YXIgYWdvcmFcIn1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIH1cclxuICAgICAgLz5cclxuXHJcbiAgICAgIHsvKiBSZXN1bW8gZGUgTcOpdHJpY2FzICovfVxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgIGRpc3BsYXk6IFwiZ3JpZFwiLFxyXG4gICAgICAgICAgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCJyZXBlYXQoYXV0by1maXQsIG1pbm1heCgyMDBweCwgMWZyKSlcIixcclxuICAgICAgICAgIGdhcDogMTIsXHJcbiAgICAgICAgICBtYXJnaW5Cb3R0b206IDI0LFxyXG4gICAgICAgIH19XHJcbiAgICAgID5cclxuICAgICAgICA8RGFzaGJvYXJkQ2FyZFxyXG4gICAgICAgICAgdGl0bGU9XCJOb3RhIE3DqWRpYVwiXHJcbiAgICAgICAgICB2YWx1ZT17YCR7YXZnU2NvcmV9IOKtkGB9XHJcbiAgICAgICAgICBzdWJ0aXRsZT17YGRlICR7dG90YWxSZXZpZXdzfSBhdmFsaWHDp8O1ZXNgfVxyXG4gICAgICAgICAgc3RhdHVzPVwiaW5mb1wiXHJcbiAgICAgICAgICBpY29uPVwi8J+TilwiXHJcbiAgICAgICAgLz5cclxuICAgICAgICA8RGFzaGJvYXJkQ2FyZFxyXG4gICAgICAgICAgdGl0bGU9XCJOw6NvIFJlc3BvbmRpZGFzIChww6FnaW5hKVwiXHJcbiAgICAgICAgICB2YWx1ZT17b3BlblJldmlld3MubGVuZ3RofVxyXG4gICAgICAgICAgc3RhdHVzPXtvcGVuUmV2aWV3cy5sZW5ndGggPiAwID8gXCJ3YXJuaW5nXCIgOiBcInN1Y2Nlc3NcIn1cclxuICAgICAgICAgIGljb249XCLwn5OdXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxEYXNoYm9hcmRDYXJkIHRpdGxlPVwiUmVzcG9uZGlkYXMgKHDDoWdpbmEpXCIgdmFsdWU9e3JlcGxpZWRSZXZpZXdzLmxlbmd0aH0gc3RhdHVzPVwic3VjY2Vzc1wiIGljb249XCLinJNcIiAvPlxyXG4gICAgICAgIDxEYXNoYm9hcmRDYXJkXHJcbiAgICAgICAgICB0aXRsZT1cIlRheGEgZGUgUmVzcG9zdGEgKHDDoWdpbmEpXCJcclxuICAgICAgICAgIHZhbHVlPXtgJHsoKHJlcGxpZWRSZXZpZXdzLmxlbmd0aCAvIE1hdGgubWF4KHJldmlld3MubGVuZ3RoLCAxKSkgKiAxMDApLnRvRml4ZWQoMCl9JWB9XHJcbiAgICAgICAgICBzdGF0dXM9XCJpbmZvXCJcclxuICAgICAgICAgIGljb249XCLwn5OIXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBBYmFzICovfVxyXG4gICAgICA8VGFic1xyXG4gICAgICAgIHRhYnM9e1tcclxuICAgICAgICAgIHsgaWQ6IFwiYWJlcnRhXCIsIGxhYmVsOiBcIk7Do28gUmVzcG9uZGlkYXNcIiwgYmFkZ2U6IG9wZW5SZXZpZXdzLmxlbmd0aCB9LFxyXG4gICAgICAgICAgeyBpZDogXCJyZXNwb25kaWRhXCIsIGxhYmVsOiBcIlJlc3BvbmRpZGFzXCIsIGJhZGdlOiByZXBsaWVkUmV2aWV3cy5sZW5ndGggfSxcclxuICAgICAgICBdfVxyXG4gICAgICAgIGFjdGl2ZVRhYj17YWN0aXZlVGFifVxyXG4gICAgICAgIG9uVGFiQ2hhbmdlPXtzZXRBY3RpdmVUYWJ9XHJcbiAgICAgID5cclxuICAgICAgICB7ZGlzcGxheVJldmlld3MubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6IDIwIH19PlxyXG4gICAgICAgICAgICA8RW1wdHlTdGF0ZVxyXG4gICAgICAgICAgICAgIHRpdGxlPXthY3RpdmVUYWIgPT09IFwiYWJlcnRhXCIgPyBcIlRvZGFzIHJlc3BvbmRpZGFzIVwiIDogXCJOZW5odW1hIHJlc3BvbmRpZGFcIn1cclxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbj17XHJcbiAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwiYWJlcnRhXCJcclxuICAgICAgICAgICAgICAgICAgPyBcIk5lbmh1bWEgYXZhbGlhw6fDo28gcGVuZGVudGUgZGUgcmVzcG9zdGEgbmVzdGEgcMOhZ2luYS5cIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiQ29tZWNlIHJlc3BvbmRlbmRvIGF2YWxpYcOnw7VlcyBkb3MgY2xpZW50ZXMuXCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxNiwgbWFyZ2luVG9wOiAxNiB9fT5cclxuICAgICAgICAgICAge2Rpc3BsYXlSZXZpZXdzLm1hcCgocmV2aWV3KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3Qgc3RhdGVEaXNwbGF5ID0gZm9ybWF0UmV2aWV3U3RhdGUocmV2aWV3LnJlcGx5ID8gXCJDTE9TRURcIiA6IFwiT1BFTlwiKTtcclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBrZXk9e3Jldmlldy5pZH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IDE2LCBib3JkZXJMZWZ0OiBgNHB4IHNvbGlkICR7c3RhdGVEaXNwbGF5LmNvbG9yfWAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImdyaWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwiMWZyIGF1dG9cIixcclxuICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiZmxleC1zdGFydFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZ2FwOiAxMixcclxuICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogMTIsXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDgsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIG1hcmdpbkJvdHRvbTogNCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3Jldmlldy5zY29yZSAhPSBudWxsID8gXCLirZBcIi5yZXBlYXQoTWF0aC5yb3VuZChyZXZpZXcuc2NvcmUpKSA6IFwi4oCUXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Jldmlldy5zY29yZSAhPSBudWxsICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jldmlldy5zY29yZS50b0ZpeGVkKDEpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCwgbWFyZ2luOiAwLCBtYXJnaW5Cb3R0b206IDQgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBlZGlkbyB7cmV2aWV3Lm9yZGVyPy5zaG9ydElkID8/IHJldmlldy5vcmRlcj8uaWQgPz8gXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIG1hcmdpbjogMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Jldmlldy5jcmVhdGVkQXQgPyBmb3JtYXREYXRlVGltZVNob3J0KHJldmlldy5jcmVhdGVkQXQpIDogXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC44cmVtXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiNHB4IDhweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHN0YXRlRGlzcGxheS5jb2xvciArIFwiMjBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHN0YXRlRGlzcGxheS5jb2xvcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNjAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c3RhdGVEaXNwbGF5Lmljb259IHtzdGF0ZURpc3BsYXkubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBDb21lbnTDoXJpbyBkbyBjbGllbnRlICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1zdXJmYWNlLTIpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IDEyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyTGVmdDogXCIzcHggc29saWQgdmFyKC0tYWNjZW50KVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiwgbWFyZ2luOiAwLCBsaW5lSGVpZ2h0OiAxLjUgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cmV2aWV3LmNvbW1lbnQgfHwgXCJBdmFsaWHDp8OjbyBzZW0gY29tZW50w6FyaW8uXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBSZXNwb3N0YSAoc2UgaG91dmVyKSAqL31cclxuICAgICAgICAgICAgICAgICAge3Jldmlldy5yZXBseSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMTIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogNixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCIjZThmNWU5XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlckxlZnQ6IFwiM3B4IHNvbGlkICM0Y2FmNTBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAxMixcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6IFwiMC43NXJlbVwiLCBmb250V2VpZ2h0OiA2MDAsIGNvbG9yOiBcIiMxYjVlMjBcIiwgbWFyZ2luOiBcIjAgMCA0cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAg4pyTIFJlc3Bvc3RhIGRhIGxvamE6XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiwgbWFyZ2luOiAwLCBsaW5lSGVpZ2h0OiAxLjUgfX0+e3Jldmlldy5yZXBseX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogQcOnw7VlcyAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gc2V0Vmlld2luZ0lkKHJldmlldy5pZCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAg8J+UjSBWZXIgZGV0YWxoZXNcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICB7IXJldmlldy5yZXBseSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0UmVwbHlpbmdSZXZpZXcocmV2aWV3KX0gc3R5bGU9e3sgZmxleDogMSB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAg4pyJ77iPIFJlc3BvbmRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvVGFicz5cclxuXHJcbiAgICAgIHsvKiBQYWdpbmHDp8OjbyAqL31cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiA4LCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIiwgbWFyZ2luVG9wOiAyMCB9fT5cclxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIGRpc2FibGVkPXtwYWdlIDw9IDF9IG9uQ2xpY2s9eygpID0+IHNldFBhZ2UoKHApID0+IE1hdGgubWF4KDEsIHAgLSAxKSl9PlxyXG4gICAgICAgICAg4oaQIEFudGVyaW9yXHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44NXJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICBQw6FnaW5hIHtwYWdlfSBkZSB7TWF0aC5tYXgocGFnZUNvdW50LCAxKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBkaXNhYmxlZD17cGFnZSA+PSBwYWdlQ291bnR9IG9uQ2xpY2s9eygpID0+IHNldFBhZ2UoKHApID0+IHAgKyAxKX0+XHJcbiAgICAgICAgICBQcsOzeGltYSDihpJcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogTW9kYWwgZGUgUmVzcG9zdGEgKi99XHJcbiAgICAgIHtyZXBseWluZ1JldmlldyAmJiAoXHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICB0aXRsZT1cIlJlc3BvbmRlciBBdmFsaWHDp8Ojb1wiXHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFJlcGx5aW5nUmV2aWV3KG51bGwpO1xyXG4gICAgICAgICAgICBzZXRSZXBseVRleHQoXCJcIik7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCwgbWFyZ2luOiBcIjAgMCA4cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgIEF2YWxpYcOnw6NvIGRvIHBlZGlkbyB7cmVwbHlpbmdSZXZpZXcub3JkZXI/LnNob3J0SWQgPz8gcmVwbHlpbmdSZXZpZXcub3JkZXI/LmlkID8/IFwi4oCUXCJ9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEyLFxyXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLXN1cmZhY2UtMilcIixcclxuICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA2LFxyXG4gICAgICAgICAgICAgICAgICBib3JkZXJMZWZ0OiBcIjNweCBzb2xpZCB2YXIoLS1hY2NlbnQpXCIsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IFwiMXJlbVwiLCBtYXJnaW5Cb3R0b206IDQgfX0+XHJcbiAgICAgICAgICAgICAgICAgIHtyZXBseWluZ1Jldmlldy5zY29yZSAhPSBudWxsID8gXCLirZBcIi5yZXBlYXQoTWF0aC5yb3VuZChyZXBseWluZ1Jldmlldy5zY29yZSkpIDogXCLigJRcIn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6IFwiMC45cmVtXCIsIG1hcmdpbjogMCwgbGluZUhlaWdodDogMS41IH19PlxyXG4gICAgICAgICAgICAgICAgICB7cmVwbHlpbmdSZXZpZXcuY29tbWVudCB8fCBcIkF2YWxpYcOnw6NvIHNlbSBjb21lbnTDoXJpby5cIn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8RmllbGRcclxuICAgICAgICAgICAgICBsYWJlbD1cIlN1YSBSZXNwb3N0YVwiXHJcbiAgICAgICAgICAgICAgaGludD17YCR7cmVwbHlUZXh0Lmxlbmd0aH0vJHtNQVhfUkVQTFlfTEVOR1RIfSBjYXJhY3RlcmVzLiBTZWphIGVkdWNhZG8gZSBwcm9maXNzaW9uYWwuYH1cclxuICAgICAgICAgICAgICBlcnJvcj17cmVwbHlUb29Mb25nID8gYEEgcmVzcG9zdGEgcGFzc2EgZGUgJHtNQVhfUkVQTFlfTEVOR1RIfSBjYXJhY3RlcmVzLmAgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7KGExMXkpID0+IChcclxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICB7Li4uYTExeX1cclxuICAgICAgICAgICAgICAgICAgcm93cz17NH1cclxuICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXtNQVhfUkVQTFlfTEVOR1RIfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cmVwbHlUZXh0fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlcGx5VGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGlnaXRlIHN1YSByZXNwb3N0YSBhbyBjbGllbnRlLi4uXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9GaWVsZD5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogOCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRSZXBseWluZ1JldmlldyhudWxsKTtcclxuICAgICAgICAgICAgICAgICAgc2V0UmVwbHlUZXh0KFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlcGx5TXV0YXRpb24ubXV0YXRlKHsgcmV2aWV3SWQ6IHJlcGx5aW5nUmV2aWV3LmlkLCB0ZXh0OiByZXBseVRleHQudHJpbSgpIH0pfVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFyZXBseVRleHQudHJpbSgpIHx8IHJlcGx5VG9vTG9uZyB8fCByZXBseU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7cmVwbHlNdXRhdGlvbi5pc1BlbmRpbmcgPyBcIkVudmlhbmRvLi4uXCIgOiBcIkVudmlhciBSZXNwb3N0YVwifVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogTW9kYWwgZGUgRGV0YWxoZXMgKi99XHJcbiAgICAgIHt2aWV3aW5nSWQgJiYgKFxyXG4gICAgICAgIDxNb2RhbCB0aXRsZT1cIkRldGFsaGVzIGRhIEF2YWxpYcOnw6NvXCIgb25DbG9zZT17KCkgPT4gc2V0Vmlld2luZ0lkKG51bGwpfT5cclxuICAgICAgICAgIHtkZXRhaWxRdWVyeS5pc0xvYWRpbmcgJiYgPHAgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PkNhcnJlZ2FuZG8uLi48L3A+fVxyXG4gICAgICAgICAge2RldGFpbFF1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e2RldGFpbFF1ZXJ5LmVycm9yfSB3aGF0PVwib3MgZGV0YWxoZXMgZGEgYXZhbGlhw6fDo29cIiAvPn1cclxuICAgICAgICAgIHtkZXRhaWxRdWVyeS5kYXRhICYmIChcclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICAgICAgICA8cCBzdHlsZT17eyBtYXJnaW46IDAsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgPHN0cm9uZz5DbGllbnRlOjwvc3Ryb25nPiB7ZGV0YWlsUXVlcnkuZGF0YS5jdXN0b21lck5hbWUgfHwgXCLigJRcIn1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luOiAwLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgIDxzdHJvbmc+Tm90YTo8L3N0cm9uZz4ge2RldGFpbFF1ZXJ5LmRhdGEuc2NvcmUgIT0gbnVsbCA/IGRldGFpbFF1ZXJ5LmRhdGEuc2NvcmUudG9GaXhlZCgxKSA6IFwi4oCUXCJ9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxwIHN0eWxlPXt7IG1hcmdpbjogMCwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3Ryb25nPkNvbWVudMOhcmlvOjwvc3Ryb25nPiB7ZGV0YWlsUXVlcnkuZGF0YS5jb21tZW50IHx8IFwi4oCUXCJ9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIHtkZXRhaWxRdWVyeS5kYXRhLnF1ZXN0aW9ucy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZyBzdHlsZT17eyBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5QZXJndW50YXM8L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAge2RldGFpbFF1ZXJ5LmRhdGEucXVlc3Rpb25zLm1hcCgocXVlc3Rpb24pID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cXVlc3Rpb24uaWR9IGNsYXNzTmFtZT1cImNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAxMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IG1hcmdpbjogMCwgZm9udFNpemU6IFwiMC45cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCB9fT57cXVlc3Rpb24udGl0bGUgfHwgcXVlc3Rpb24uaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHVsIHN0eWxlPXt7IG1hcmdpbjogXCI0cHggMCAwXCIsIHBhZGRpbmdMZWZ0OiAxOCwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cXVlc3Rpb24uYW5zd2Vycy5tYXAoKGFuc3dlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2Fuc3dlci5pZH0+e2Fuc3dlci50aXRsZSB8fCBhbnN3ZXIuaWR9PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIEZvb3RlciAqL31cclxuICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6IDMyLCBwYWRkaW5nOiAxNiwgYm9yZGVyUmFkaXVzOiA4LCBiYWNrZ3JvdW5kOiBcInZhcigtLXN1cmZhY2UtMilcIiB9fT5cclxuICAgICAgICA8TGluayB0bz1cIi9pbnRlZ3JhY29lcy9pZm9vZFwiIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiB9fT5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCI+4oaQIFZvbHRhciBhbyBpRm9vZDwvQnV0dG9uPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvaW50ZWdyYXRpb25zL0lGb29kUmV2aWV3c0RldGFpbGVkUGFnZS50c3gifQ==