import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/LoginPage.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { login } from "/src/features/auth/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useThemeStore } from "/src/stores/themeStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import logoDark from "/src/image/logodark.png?import";
import logoLight from "/src/image/logoligth.png?import";
import bgImage from "/src/image/screenbackground_auth.jpeg?import";
export function LoginPage() {
  _s();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const setSession = useAuthStore((s) => s.setSession);
  const { theme, toggleTheme } = useThemeStore();
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const commitHash = (import.meta.env?.VITE_COMMIT_HASH || "Dev").substring(0, 7);
  const mutation = useMutation({
    mutationFn: () => login(userName, password),
    onSuccess: (session) => {
      queryClient.clear();
      setSession(session);
      navigate("/", { replace: true });
    }
  });
  const errorMessage = mutation.error instanceof ApiError ? mutation.error.message : mutation.isError ? "Não foi possível conectar à API." : null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("style", { children: `
                @keyframes fadeInAlpha {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
            ` }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
      lineNumber: 62,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      "main",
      {
        style: {
          minHeight: "100vh",
          display: "grid",
          placeItems: "center",
          padding: 24,
          backgroundImage: `url(${bgImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          animation: "fadeInAlpha 1s ease-out forwards",
          position: "relative"
        },
        children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-ghost btn-icon",
              "aria-label": theme === "dark" ? "Ativar tema claro" : "Ativar tema escuro",
              title: theme === "dark" ? "Tema claro" : "Tema escuro",
              onClick: toggleTheme,
              "data-testid": "theme-toggle",
              style: {
                position: "fixed",
                top: 16,
                right: 16,
                zIndex: 5,
                background: "var(--bg-raise)",
                borderRadius: 999,
                boxShadow: "0 4px 16px rgba(0, 0, 0, 0.35)"
              },
              children: theme === "dark" ? "☀" : "🌙"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
              lineNumber: 82,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "form",
            {
              className: "rise",
              onSubmit: (e) => {
                e.preventDefault();
                mutation.mutate();
              },
              style: {
                width: "min(380px, 100%)",
                background: "var(--bg-raise)",
                border: "1px solid var(--line)",
                borderRadius: 16,
                padding: "36px 32px 32px",
                display: "grid",
                gap: 16,
                boxShadow: theme === "light" ? "0 8px 32px rgba(0, 0, 0, 0.15)" : "0 8px 32px rgba(0, 0, 0, 0.4)"
              },
              children: [
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", marginBottom: 8 }, children: [
                  /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: theme === "light" ? logoLight : logoDark,
                      alt: "Logo do Sistema",
                      "data-testid": "system-logo",
                      style: {
                        height: 100,
                        margin: "0 auto 16px",
                        objectFit: "contain",
                        transition: "opacity 0.2s ease-in-out"
                      }
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                      lineNumber: 122,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      style: {
                        color: "var(--ink-faint)",
                        fontFamily: "var(--font-cond)",
                        letterSpacing: "0.22em",
                        textTransform: "uppercase",
                        fontSize: "0.78rem"
                      },
                      children: "painel do salão"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                      lineNumber: 133,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                  lineNumber: 121,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("label", { htmlFor: "username", style: { display: "grid", gap: 6 }, children: [
                  /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Usuário" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                    lineNumber: 148,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      id: "username",
                      name: "username",
                      "data-testid": "username",
                      value: userName,
                      onChange: (e) => setUserName(e.target.value),
                      autoComplete: "username",
                      autoFocus: true,
                      required: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                      lineNumber: 149,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                  lineNumber: 147,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("label", { htmlFor: "password", style: { display: "grid", gap: 6 }, children: [
                  /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Senha" }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                    lineNumber: 163,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      id: "password",
                      name: "password",
                      "data-testid": "password",
                      type: "password",
                      value: password,
                      onChange: (e) => setPassword(e.target.value),
                      autoComplete: "current-password",
                      required: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                      lineNumber: 164,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                  lineNumber: 162,
                  columnNumber: 21
                }, this),
                errorMessage && /* @__PURE__ */ jsxDEV("p", { className: "error-text", "data-testid": "error-message", children: errorMessage }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                  lineNumber: 176,
                  columnNumber: 38
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    className: "btn-primary",
                    type: "submit",
                    disabled: mutation.isPending,
                    "data-testid": "submit-login",
                    children: mutation.isPending ? "Entrando…" : "Entrar"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                    lineNumber: 178,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(Link, { to: "/cadastro", style: { textAlign: "center", color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Ainda não tem conta? Cadastre seu bar" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                  lineNumber: 187,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", marginTop: 8, borderTop: "1px solid var(--line)", paddingTop: 12 }, children: /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.75rem", fontFamily: "monospace" }, children: [
                  "Commit hash: ",
                  commitHash,
                  " - Release: 1.22v"
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                  lineNumber: 192,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                  lineNumber: 191,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", marginTop: 8, borderTop: "1px solid var(--line)", paddingTop: 12 }, children: /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.75rem", fontFamily: "monospace" }, children: "Last update: 2026-09-03" }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                  lineNumber: 197,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
                  lineNumber: 196,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
              lineNumber: 102,
              columnNumber: 17
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
        lineNumber: 69,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx",
    lineNumber: 61,
    columnNumber: 5
  }, this);
}
_s(LoginPage, "OVMD17CwdDs+qa6ADQE6EZs2DhA=", false, function() {
  return [useNavigate, useQueryClient, useAuthStore, useThemeStore, useMutation];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/auth/LoginPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNRLG1CQUNJLGNBREo7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBekNQLFNBQVNBLGdCQUFnQjtBQUMxQixTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsYUFBYUMsc0JBQXNCO0FBQzVDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGFBQWE7QUFFYixnQkFBU0MsWUFBWTtBQUFBQyxLQUFBO0FBQ3hCLFFBQU1DLFdBQVdaLFlBQVk7QUFDN0IsUUFBTWEsY0FBY1gsZUFBZTtBQUNuQyxRQUFNWSxhQUFhVixhQUFhLENBQUNXLE1BQU1BLEVBQUVELFVBQVU7QUFDbkQsUUFBTSxFQUFFRSxPQUFPQyxZQUFZLElBQUlaLGNBQWM7QUFDN0MsUUFBTSxDQUFDYSxVQUFVQyxXQUFXLElBQUlyQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDc0IsVUFBVUMsV0FBVyxJQUFJdkIsU0FBUyxFQUFFO0FBRTNDLFFBQU13QixjQUNGQyxZQUFZQyxLQUFLQyxvQkFDakIsT0FDRkMsVUFBVSxHQUFHLENBQUM7QUFFaEIsUUFBTUMsV0FBVzFCLFlBQVk7QUFBQSxJQUN6QjJCLFlBQVlBLE1BQU16QixNQUFNZSxVQUFVRSxRQUFRO0FBQUEsSUFDMUNTLFdBQVdBLENBQUNDLFlBQVk7QUFDcEJqQixrQkFBWWtCLE1BQU07QUFDbEJqQixpQkFBV2dCLE9BQU87QUFDbEJsQixlQUFTLEtBQUssRUFBRW9CLFNBQVMsS0FBSyxDQUFDO0FBQUEsSUFDbkM7QUFBQSxFQUNKLENBQUM7QUFFRCxRQUFNQyxlQUNGTixTQUFTTyxpQkFBaUI1QixXQUNwQnFCLFNBQVNPLE1BQU1DLFVBQ2ZSLFNBQVNTLFVBQ0wscUNBQ0E7QUFFZCxTQUNJLG1DQUNJO0FBQUEsMkJBQUMsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtFO0FBQUEsSUFFRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csT0FBTztBQUFBLFVBQ0hDLFdBQVc7QUFBQSxVQUNYQyxTQUFTO0FBQUEsVUFDVEMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxpQkFBaUIsT0FBT2hDLE9BQU87QUFBQSxVQUMvQmlDLGdCQUFnQjtBQUFBLFVBQ2hCQyxvQkFBb0I7QUFBQSxVQUNwQkMsV0FBVztBQUFBLFVBQ1hDLFVBQVU7QUFBQSxRQUNkO0FBQUEsUUFFQTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixjQUFZN0IsVUFBVSxTQUFTLHNCQUFzQjtBQUFBLGNBQ3JELE9BQU9BLFVBQVUsU0FBUyxlQUFlO0FBQUEsY0FDekMsU0FBU0M7QUFBQUEsY0FDVCxlQUFZO0FBQUEsY0FDWixPQUFPO0FBQUEsZ0JBQ0g0QixVQUFVO0FBQUEsZ0JBQ1ZDLEtBQUs7QUFBQSxnQkFDTEMsT0FBTztBQUFBLGdCQUNQQyxRQUFRO0FBQUEsZ0JBQ1JDLFlBQVk7QUFBQSxnQkFDWkMsY0FBYztBQUFBLGdCQUNkQyxXQUFXO0FBQUEsY0FDZjtBQUFBLGNBRUNuQyxvQkFBVSxTQUFTLE1BQU07QUFBQTtBQUFBLFlBakI5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrQkE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFVO0FBQUEsY0FDVixVQUFVLENBQUNvQyxNQUFNO0FBQ2JBLGtCQUFFQyxlQUFlO0FBQ2pCMUIseUJBQVMyQixPQUFPO0FBQUEsY0FDcEI7QUFBQSxjQUNBLE9BQU87QUFBQSxnQkFDSEMsT0FBTztBQUFBLGdCQUNQTixZQUFZO0FBQUEsZ0JBQ1pPLFFBQVE7QUFBQSxnQkFDUk4sY0FBYztBQUFBLGdCQUNkVixTQUFTO0FBQUEsZ0JBQ1RGLFNBQVM7QUFBQSxnQkFDVG1CLEtBQUs7QUFBQSxnQkFDTE4sV0FBV25DLFVBQVUsVUFDZixtQ0FDQTtBQUFBLGNBQ1Y7QUFBQSxjQUVBO0FBQUEsdUNBQUMsU0FBSSxPQUFPLEVBQUUwQyxXQUFXLFVBQVVDLGNBQWMsRUFBRSxHQUMvQztBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLEtBQUszQyxVQUFVLFVBQVVSLFlBQVlEO0FBQUFBLHNCQUNyQyxLQUFJO0FBQUEsc0JBQ0osZUFBWTtBQUFBLHNCQUNaLE9BQU87QUFBQSx3QkFDSHFELFFBQVE7QUFBQSx3QkFDUkMsUUFBUTtBQUFBLHdCQUNSQyxXQUFXO0FBQUEsd0JBQ1hDLFlBQVk7QUFBQSxzQkFDaEI7QUFBQTtBQUFBLG9CQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTTTtBQUFBLGtCQUVOO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLE9BQU87QUFBQSx3QkFDSEMsT0FBTztBQUFBLHdCQUNQQyxZQUFZO0FBQUEsd0JBQ1pDLGVBQWU7QUFBQSx3QkFDZkMsZUFBZTtBQUFBLHdCQUNmQyxVQUFVO0FBQUEsc0JBQ2Q7QUFBQSxzQkFBRTtBQUFBO0FBQUEsb0JBUE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVBO0FBQUEscUJBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUJBO0FBQUEsZ0JBR0EsdUJBQUMsV0FBTSxTQUFRLFlBQVcsT0FBTyxFQUFFOUIsU0FBUyxRQUFRbUIsS0FBSyxFQUFFLEdBQ3ZEO0FBQUEseUNBQUMsVUFBSyxPQUFPLEVBQUVPLE9BQU8sa0JBQWtCSSxVQUFVLFNBQVMsR0FBRyx1QkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUU7QUFBQSxrQkFDckU7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csSUFBRztBQUFBLHNCQUNILE1BQUs7QUFBQSxzQkFDTCxlQUFZO0FBQUEsc0JBQ1osT0FBT2xEO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ2tDLE1BQU1qQyxZQUFZaUMsRUFBRWlCLE9BQU9DLEtBQUs7QUFBQSxzQkFDM0MsY0FBYTtBQUFBLHNCQUNiO0FBQUEsc0JBQ0EsVUFBUTtBQUFBO0FBQUEsb0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVFZO0FBQUEscUJBVmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWUE7QUFBQSxnQkFHQSx1QkFBQyxXQUFNLFNBQVEsWUFBVyxPQUFPLEVBQUVoQyxTQUFTLFFBQVFtQixLQUFLLEVBQUUsR0FDdkQ7QUFBQSx5Q0FBQyxVQUFLLE9BQU8sRUFBRU8sT0FBTyxrQkFBa0JJLFVBQVUsU0FBUyxHQUFHLHFCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRTtBQUFBLGtCQUNuRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxJQUFHO0FBQUEsc0JBQ0gsTUFBSztBQUFBLHNCQUNMLGVBQVk7QUFBQSxzQkFDWixNQUFLO0FBQUEsc0JBQ0wsT0FBT2hEO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ2dDLE1BQU0vQixZQUFZK0IsRUFBRWlCLE9BQU9DLEtBQUs7QUFBQSxzQkFDM0MsY0FBYTtBQUFBLHNCQUNiLFVBQVE7QUFBQTtBQUFBLG9CQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFRWTtBQUFBLHFCQVZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVlBO0FBQUEsZ0JBRUNyQyxnQkFBZ0IsdUJBQUMsT0FBRSxXQUFVLGNBQWEsZUFBWSxpQkFBaUJBLDBCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRTtBQUFBLGdCQUVyRjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLFVBQVVOLFNBQVM0QztBQUFBQSxvQkFDbkIsZUFBWTtBQUFBLG9CQUVYNUMsbUJBQVM0QyxZQUFZLGNBQWM7QUFBQTtBQUFBLGtCQU54QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxnQkFFQSx1QkFBQyxRQUFLLElBQUcsYUFBWSxPQUFPLEVBQUViLFdBQVcsVUFBVU0sT0FBTyxrQkFBa0JJLFVBQVUsVUFBVSxHQUFHLHFEQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVWLFdBQVcsVUFBVWMsV0FBVyxHQUFHQyxXQUFXLHlCQUF5QkMsWUFBWSxHQUFHLEdBQ2hHLGlDQUFDLFVBQUssT0FBTyxFQUFFVixPQUFPLG9CQUFvQkksVUFBVSxXQUFXSCxZQUFZLFlBQVksR0FBRztBQUFBO0FBQUEsa0JBQ3hFM0M7QUFBQUEsa0JBQVc7QUFBQSxxQkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRW9DLFdBQVcsVUFBVWMsV0FBVyxHQUFHQyxXQUFXLHlCQUF5QkMsWUFBWSxHQUFHLEdBQ2hHLGlDQUFDLFVBQUssT0FBTyxFQUFFVixPQUFPLG9CQUFvQkksVUFBVSxXQUFXSCxZQUFZLFlBQVksR0FBRyx1Q0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQTtBQUFBO0FBQUEsWUFsR0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBbUdBO0FBQUE7QUFBQTtBQUFBLE1BcElKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXFJQTtBQUFBLE9BN0lKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4SUE7QUFFUjtBQUFDdEQsR0E5S2VELFdBQVM7QUFBQSxVQUNKVixhQUNHRSxnQkFDREUsY0FDWUMsZUFTZEosV0FBVztBQUFBO0FBQUEsS0FiaEJTO0FBQVMsSUFBQWlFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZU5hdmlnYXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeUNsaWVudCIsImxvZ2luIiwidXNlQXV0aFN0b3JlIiwidXNlVGhlbWVTdG9yZSIsIkFwaUVycm9yIiwibG9nb0RhcmsiLCJsb2dvTGlnaHQiLCJiZ0ltYWdlIiwiTG9naW5QYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsInF1ZXJ5Q2xpZW50Iiwic2V0U2Vzc2lvbiIsInMiLCJ0aGVtZSIsInRvZ2dsZVRoZW1lIiwidXNlck5hbWUiLCJzZXRVc2VyTmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJjb21taXRIYXNoIiwiaW1wb3J0IiwiZW52IiwiVklURV9DT01NSVRfSEFTSCIsInN1YnN0cmluZyIsIm11dGF0aW9uIiwibXV0YXRpb25GbiIsIm9uU3VjY2VzcyIsInNlc3Npb24iLCJjbGVhciIsInJlcGxhY2UiLCJlcnJvck1lc3NhZ2UiLCJlcnJvciIsIm1lc3NhZ2UiLCJpc0Vycm9yIiwibWluSGVpZ2h0IiwiZGlzcGxheSIsInBsYWNlSXRlbXMiLCJwYWRkaW5nIiwiYmFja2dyb3VuZEltYWdlIiwiYmFja2dyb3VuZFNpemUiLCJiYWNrZ3JvdW5kUG9zaXRpb24iLCJhbmltYXRpb24iLCJwb3NpdGlvbiIsInRvcCIsInJpZ2h0IiwiekluZGV4IiwiYmFja2dyb3VuZCIsImJvcmRlclJhZGl1cyIsImJveFNoYWRvdyIsImUiLCJwcmV2ZW50RGVmYXVsdCIsIm11dGF0ZSIsIndpZHRoIiwiYm9yZGVyIiwiZ2FwIiwidGV4dEFsaWduIiwibWFyZ2luQm90dG9tIiwiaGVpZ2h0IiwibWFyZ2luIiwib2JqZWN0Rml0IiwidHJhbnNpdGlvbiIsImNvbG9yIiwiZm9udEZhbWlseSIsImxldHRlclNwYWNpbmciLCJ0ZXh0VHJhbnNmb3JtIiwiZm9udFNpemUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImlzUGVuZGluZyIsIm1hcmdpblRvcCIsImJvcmRlclRvcCIsInBhZGRpbmdUb3AiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMb2dpblBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyBsb2dpbiB9IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyB1c2VUaGVtZVN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy90aGVtZVN0b3JlXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IGxvZ29EYXJrIGZyb20gXCIuLi8uLi9pbWFnZS9sb2dvZGFyay5wbmdcIjtcclxuaW1wb3J0IGxvZ29MaWdodCBmcm9tIFwiLi4vLi4vaW1hZ2UvbG9nb2xpZ3RoLnBuZ1wiO1xyXG5pbXBvcnQgYmdJbWFnZSBmcm9tIFwiLi4vLi4vaW1hZ2Uvc2NyZWVuYmFja2dyb3VuZF9hdXRoLmpwZWdcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBMb2dpblBhZ2UoKSB7XHJcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgICBjb25zdCBzZXRTZXNzaW9uID0gdXNlQXV0aFN0b3JlKChzKSA9PiBzLnNldFNlc3Npb24pO1xyXG4gICAgY29uc3QgeyB0aGVtZSwgdG9nZ2xlVGhlbWUgfSA9IHVzZVRoZW1lU3RvcmUoKTtcclxuICAgIGNvbnN0IFt1c2VyTmFtZSwgc2V0VXNlck5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICAgIGNvbnN0IGNvbW1pdEhhc2ggPSAoXHJcbiAgICAgICAgaW1wb3J0Lm1ldGEuZW52Py5WSVRFX0NPTU1JVF9IQVNIIHx8XHJcbiAgICAgICAgXCJEZXZcIlxyXG4gICAgKS5zdWJzdHJpbmcoMCwgNyk7XHJcblxyXG4gICAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICAgICAgbXV0YXRpb25GbjogKCkgPT4gbG9naW4odXNlck5hbWUsIHBhc3N3b3JkKSxcclxuICAgICAgICBvblN1Y2Nlc3M6IChzZXNzaW9uKSA9PiB7XHJcbiAgICAgICAgICAgIHF1ZXJ5Q2xpZW50LmNsZWFyKCk7XHJcbiAgICAgICAgICAgIHNldFNlc3Npb24oc2Vzc2lvbik7XHJcbiAgICAgICAgICAgIG5hdmlnYXRlKFwiL1wiLCB7IHJlcGxhY2U6IHRydWUgfSk7XHJcbiAgICAgICAgfSxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9XHJcbiAgICAgICAgbXV0YXRpb24uZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvclxyXG4gICAgICAgICAgICA/IG11dGF0aW9uLmVycm9yLm1lc3NhZ2VcclxuICAgICAgICAgICAgOiBtdXRhdGlvbi5pc0Vycm9yXHJcbiAgICAgICAgICAgICAgICA/IFwiTsOjbyBmb2kgcG9zc8OtdmVsIGNvbmVjdGFyIMOgIEFQSS5cIlxyXG4gICAgICAgICAgICAgICAgOiBudWxsO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPHN0eWxlPntgXHJcbiAgICAgICAgICAgICAgICBAa2V5ZnJhbWVzIGZhZGVJbkFscGhhIHtcclxuICAgICAgICAgICAgICAgICAgICBmcm9tIHsgb3BhY2l0eTogMDsgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRvIHsgb3BhY2l0eTogMTsgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBgfTwvc3R5bGU+XHJcblxyXG4gICAgICAgICAgICA8bWFpblxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHQ6IFwiMTAwdmhcIixcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImdyaWRcIixcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZUl0ZW1zOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDI0LFxyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRJbWFnZTogYHVybCgke2JnSW1hZ2V9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZFNpemU6IFwiY292ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kUG9zaXRpb246IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgYW5pbWF0aW9uOiBcImZhZGVJbkFscGhhIDFzIGVhc2Utb3V0IGZvcndhcmRzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IFwicmVsYXRpdmVcIixcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3QgYnRuLWljb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e3RoZW1lID09PSBcImRhcmtcIiA/IFwiQXRpdmFyIHRlbWEgY2xhcm9cIiA6IFwiQXRpdmFyIHRlbWEgZXNjdXJvXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3RoZW1lID09PSBcImRhcmtcIiA/IFwiVGVtYSBjbGFyb1wiIDogXCJUZW1hIGVzY3Vyb1wifVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVRoZW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwidGhlbWUtdG9nZ2xlXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogXCJmaXhlZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDE2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICByaWdodDogMTYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleDogNSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1iZy1yYWlzZSlcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA5OTksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogXCIwIDRweCAxNnB4IHJnYmEoMCwgMCwgMCwgMC4zNSlcIixcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0aGVtZSA9PT0gXCJkYXJrXCIgPyBcIuKYgFwiIDogXCLwn4yZXCJ9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJpc2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG11dGF0aW9uLm11dGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IFwibWluKDM4MHB4LCAxMDAlKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLWJnLXJhaXNlKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHZhcigtLWxpbmUpXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMTYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMzZweCAzMnB4IDMycHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJncmlkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdhcDogMTYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogdGhlbWUgPT09IFwibGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIjAgOHB4IDMycHggcmdiYSgwLCAwLCAwLCAwLjE1KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiMCA4cHggMzJweCByZ2JhKDAsIDAsIDAsIDAuNClcIixcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiLCBtYXJnaW5Cb3R0b206IDggfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17dGhlbWUgPT09IFwibGlnaHRcIiA/IGxvZ29MaWdodCA6IGxvZ29EYXJrfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiTG9nbyBkbyBTaXN0ZW1hXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwic3lzdGVtLWxvZ29cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IFwiMCBhdXRvIDE2cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmplY3RGaXQ6IFwiY29udGFpblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IFwib3BhY2l0eSAwLjJzIGVhc2UtaW4tb3V0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5OiBcInZhcigtLWZvbnQtY29uZClcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIjAuMjJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC43OHJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFpbmVsIGRvIHNhbMOjb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIGh0bWxGb3IgYWRpY2lvbmFkbyBhcG9udGFuZG8gcGFyYSBvIGlkIGRvIGlucHV0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwidXNlcm5hbWVcIiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA2IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5Vc3XDoXJpbzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInVzZXJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ1c2VybmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cInVzZXJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1c2VyTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXNlck5hbWUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwidXNlcm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBodG1sRm9yIGFkaWNpb25hZG8gYXBvbnRhbmRvIHBhcmEgbyBpZCBkbyBpbnB1dCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCIgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+U2VuaGE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJjdXJyZW50LXBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9yTWVzc2FnZSAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCIgZGF0YS10ZXN0aWQ9XCJlcnJvci1tZXNzYWdlXCI+e2Vycm9yTWVzc2FnZX08L3A+fVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXttdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwic3VibWl0LWxvZ2luXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHttdXRhdGlvbi5pc1BlbmRpbmcgPyBcIkVudHJhbmRv4oCmXCIgOiBcIkVudHJhclwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9jYWRhc3Ryb1wiIHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBaW5kYSBuw6NvIHRlbSBjb250YT8gQ2FkYXN0cmUgc2V1IGJhclxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIG1hcmdpblRvcDogOCwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lKVwiLCBwYWRkaW5nVG9wOiAxMiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjc1cmVtXCIsIGZvbnRGYW1pbHk6IFwibW9ub3NwYWNlXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb21taXQgaGFzaDoge2NvbW1pdEhhc2h9IC0gUmVsZWFzZTogMS4yMnZcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiLCBtYXJnaW5Ub3A6IDgsIGJvcmRlclRvcDogXCIxcHggc29saWQgdmFyKC0tbGluZSlcIiwgcGFkZGluZ1RvcDogMTIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiwgZm9udFNpemU6IFwiMC43NXJlbVwiLCBmb250RmFtaWx5OiBcIm1vbm9zcGFjZVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTGFzdCB1cGRhdGU6IDIwMjYtMDktMDNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICA8L21haW4+XHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2F1dGgvTG9naW5QYWdlLnRzeCJ9