import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/publicOrdering/PublicOrderCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { formatBRL } from "/src/lib/types.ts";
export function PublicOrderCard({ item, quantity, isJustSent, isPending, onQuantityChange, onAddItem }) {
  _s();
  const [windowWidth, setWindowWidth] = useState(typeof window !== "undefined" ? window.innerWidth : 1200);
  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  const isTvOrLarge = windowWidth > 1200;
  const cardPadding = isTvOrLarge ? 24 : 16;
  const imageSize = isTvOrLarge ? 120 : 80;
  const titleFontSize = isTvOrLarge ? "1.25rem" : "1rem";
  const descFontSize = isTvOrLarge ? "1.05rem" : "0.85rem";
  const priceFontSize = isTvOrLarge ? "1.35rem" : "1.1rem";
  const controlHeight = isTvOrLarge ? 48 : 36;
  const buttonPadding = isTvOrLarge ? "0 28px" : "0 20px";
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", backgroundColor: "#1e1e24", borderRadius: 12, padding: cardPadding, border: "1px solid #29292e", boxShadow: "0 4px 6px rgba(0,0,0,0.3)", boxSizing: "border-box" }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { width: imageSize, height: imageSize, borderRadius: 8, backgroundColor: "#323238", flexShrink: 0, overflow: "hidden" }, children: item.imageUrl ? /* @__PURE__ */ jsxDEV("img", { src: item.imageUrl, alt: item.name, style: { width: "100%", height: "100%", objectFit: "cover" } }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
      lineNumber: 57,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { style: { width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "#555", fontSize: isTvOrLarge ? "2rem" : "1.2rem" }, children: "📷" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
      lineNumber: 59,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
      lineNumber: 55,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { marginLeft: 16, flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between" }, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { margin: 0, fontSize: titleFontSize, color: "#ffffff", fontWeight: "600", lineHeight: "1.2" }, children: item.name }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
          lineNumber: 65,
          columnNumber: 21
        }, this),
        item.description && /* @__PURE__ */ jsxDEV("p", { style: { margin: "6px 0 0", fontSize: descFontSize, color: "#8d8d99", lineHeight: "1.4" }, children: item.description }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
          lineNumber: 67,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
        lineNumber: 64,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { marginTop: 12, fontWeight: "bold", color: "#f59e0b", fontSize: priceFontSize }, children: [
        item.complementGroups?.length ? "A partir de " : "",
        formatBRL(item.salePrice)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
        lineNumber: 73,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 12, marginTop: 12 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", border: "1px solid #323238", borderRadius: 8, overflow: "hidden", height: controlHeight, backgroundColor: "#121214" }, children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => onQuantityChange(quantity - 1), style: { width: controlHeight, height: "100%", background: "none", border: "none", color: "#a8a8b3", fontSize: isTvOrLarge ? "1.5rem" : "1.2rem", cursor: "pointer" }, children: "−" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
            lineNumber: 79,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { width: isTvOrLarge ? 40 : 28, textAlign: "center", color: "#ffffff", fontWeight: "500", fontSize: isTvOrLarge ? "1.15rem" : "0.95rem" }, children: quantity }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
            lineNumber: 80,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => onQuantityChange(quantity + 1), style: { width: controlHeight, height: "100%", background: "none", border: "none", color: "#a8a8b3", fontSize: isTvOrLarge ? "1.5rem" : "1.2rem", cursor: "pointer" }, children: "+" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
            lineNumber: 81,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
          lineNumber: 78,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onAddItem,
            disabled: isPending,
            style: { backgroundColor: "#f59e0b", color: "#121214", border: "none", borderRadius: 8, padding: buttonPadding, height: controlHeight, fontWeight: "bold", fontSize: isTvOrLarge ? "1.1rem" : "0.95rem", cursor: isPending ? "not-allowed" : "pointer", opacity: isPending ? 0.7 : 1 },
            children: isJustSent ? "Pedir de novo" : "Pedir"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
            lineNumber: 84,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
        lineNumber: 77,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
      lineNumber: 63,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx",
    lineNumber: 54,
    columnNumber: 5
  }, this);
}
_s(PublicOrderCard, "dAGi625P1ePv8009Wrdl/cMbrho=");
_c = PublicOrderCard;
var _c;
$RefreshReg$(_c, "PublicOrderCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/publicOrdering/PublicOrderCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQ25CLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNyQyxTQUFTQyxpQkFBaUI7QUFZbkIsZ0JBQVNDLGdCQUFnQixFQUFFQyxNQUFNQyxVQUFVQyxZQUFZQyxXQUFXQyxrQkFBa0JDLFVBQWdDLEdBQUc7QUFBQUMsS0FBQTtBQUMxSCxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSVosU0FBUyxPQUFPYSxXQUFXLGNBQWNBLE9BQU9DLGFBQWEsSUFBSTtBQUV2R2IsWUFBVSxNQUFNO0FBQ1osVUFBTWMsZUFBZUEsTUFBTUgsZUFBZUMsT0FBT0MsVUFBVTtBQUMzREQsV0FBT0csaUJBQWlCLFVBQVVELFlBQVk7QUFDOUMsV0FBTyxNQUFNRixPQUFPSSxvQkFBb0IsVUFBVUYsWUFBWTtBQUFBLEVBQ2xFLEdBQUcsRUFBRTtBQUVMLFFBQU1HLGNBQWNQLGNBQWM7QUFHbEMsUUFBTVEsY0FBY0QsY0FBYyxLQUFLO0FBQ3ZDLFFBQU1FLFlBQVlGLGNBQWMsTUFBTTtBQUN0QyxRQUFNRyxnQkFBZ0JILGNBQWMsWUFBWTtBQUNoRCxRQUFNSSxlQUFlSixjQUFjLFlBQVk7QUFDL0MsUUFBTUssZ0JBQWdCTCxjQUFjLFlBQVk7QUFDaEQsUUFBTU0sZ0JBQWdCTixjQUFjLEtBQUs7QUFDekMsUUFBTU8sZ0JBQWdCUCxjQUFjLFdBQVc7QUFFL0MsU0FDSSx1QkFBQyxTQUFJLE9BQU8sRUFBRVEsU0FBUyxRQUFRQyxpQkFBaUIsV0FBV0MsY0FBYyxJQUFJQyxTQUFTVixhQUFhVyxRQUFRLHFCQUFxQkMsV0FBVyw2QkFBNkJDLFdBQVcsYUFBYSxHQUM1TDtBQUFBLDJCQUFDLFNBQUksT0FBTyxFQUFFQyxPQUFPYixXQUFXYyxRQUFRZCxXQUFXUSxjQUFjLEdBQUdELGlCQUFpQixXQUFXUSxZQUFZLEdBQUdDLFVBQVUsU0FBUyxHQUM3SGhDLGVBQUtpQyxXQUNGLHVCQUFDLFNBQUksS0FBS2pDLEtBQUtpQyxVQUFVLEtBQUtqQyxLQUFLa0MsTUFBTSxPQUFPLEVBQUVMLE9BQU8sUUFBUUMsUUFBUSxRQUFRSyxXQUFXLFFBQVEsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRyxJQUV0Ryx1QkFBQyxTQUFJLE9BQU8sRUFBRU4sT0FBTyxRQUFRQyxRQUFRLFFBQVFSLFNBQVMsUUFBUWMsWUFBWSxVQUFVQyxnQkFBZ0IsVUFBVUMsT0FBTyxRQUFRQyxVQUFVekIsY0FBYyxTQUFTLFNBQVMsR0FBRyxrQkFBMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0SyxLQUpwTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFMEIsWUFBWSxJQUFJQyxNQUFNLEdBQUduQixTQUFTLFFBQVFvQixlQUFlLFVBQVVMLGdCQUFnQixnQkFBZ0IsR0FDN0c7QUFBQSw2QkFBQyxTQUNHO0FBQUEsK0JBQUMsUUFBRyxPQUFPLEVBQUVNLFFBQVEsR0FBR0osVUFBVXRCLGVBQWVxQixPQUFPLFdBQVdNLFlBQVksT0FBT0MsWUFBWSxNQUFNLEdBQUk3QyxlQUFLa0MsUUFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSDtBQUFBLFFBQ3JIbEMsS0FBSzhDLGVBQ0YsdUJBQUMsT0FBRSxPQUFPLEVBQUVILFFBQVEsV0FBV0osVUFBVXJCLGNBQWNvQixPQUFPLFdBQVdPLFlBQVksTUFBTSxHQUN0RjdDLGVBQUs4QyxlQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFFQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsV0FBVyxJQUFJSCxZQUFZLFFBQVFOLE9BQU8sV0FBV0MsVUFBVXBCLGNBQWMsR0FDdkZuQjtBQUFBQSxhQUFLZ0Qsa0JBQWtCQyxTQUFTLGlCQUFpQjtBQUFBLFFBQUluRCxVQUFVRSxLQUFLa0QsU0FBUztBQUFBLFdBRGxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUU1QixTQUFTLFFBQVFlLGdCQUFnQixZQUFZRCxZQUFZLFVBQVVlLEtBQUssSUFBSUosV0FBVyxHQUFHLEdBQ3BHO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUV6QixTQUFTLFFBQVFjLFlBQVksVUFBVVYsUUFBUSxxQkFBcUJGLGNBQWMsR0FBR1EsVUFBVSxVQUFVRixRQUFRVixlQUFlRyxpQkFBaUIsVUFBVSxHQUNySztBQUFBLGlDQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTW5CLGlCQUFpQkgsV0FBVyxDQUFDLEdBQUcsT0FBTyxFQUFFNEIsT0FBT1QsZUFBZVUsUUFBUSxRQUFRc0IsWUFBWSxRQUFRMUIsUUFBUSxRQUFRWSxPQUFPLFdBQVdDLFVBQVV6QixjQUFjLFdBQVcsVUFBVXVDLFFBQVEsVUFBVSxHQUFHLGlCQUE1TztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2TztBQUFBLFVBQzdPLHVCQUFDLFVBQUssT0FBTyxFQUFFeEIsT0FBT2YsY0FBYyxLQUFLLElBQUl3QyxXQUFXLFVBQVVoQixPQUFPLFdBQVdNLFlBQVksT0FBT0wsVUFBVXpCLGNBQWMsWUFBWSxVQUFVLEdBQUliLHNCQUF6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrSztBQUFBLFVBQ2xLLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTUcsaUJBQWlCSCxXQUFXLENBQUMsR0FBRyxPQUFPLEVBQUU0QixPQUFPVCxlQUFlVSxRQUFRLFFBQVFzQixZQUFZLFFBQVExQixRQUFRLFFBQVFZLE9BQU8sV0FBV0MsVUFBVXpCLGNBQWMsV0FBVyxVQUFVdUMsUUFBUSxVQUFVLEdBQUcsaUJBQTVPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZPO0FBQUEsYUFIalA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBU2hEO0FBQUFBLFlBQ1QsVUFBVUY7QUFBQUEsWUFDVixPQUFPLEVBQUVvQixpQkFBaUIsV0FBV2UsT0FBTyxXQUFXWixRQUFRLFFBQVFGLGNBQWMsR0FBR0MsU0FBU0osZUFBZVMsUUFBUVYsZUFBZXdCLFlBQVksUUFBUUwsVUFBVXpCLGNBQWMsV0FBVyxXQUFXdUMsUUFBUWxELFlBQVksZ0JBQWdCLFdBQVdvRCxTQUFTcEQsWUFBWSxNQUFNLEVBQUU7QUFBQSxZQUVwUkQsdUJBQWEsa0JBQWtCO0FBQUE7QUFBQSxVQU5wQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLE9BdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3Q0E7QUFFUjtBQUFDSSxHQS9EZVAsaUJBQWU7QUFBQSxLQUFmQTtBQUFlLElBQUF5RDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImZvcm1hdEJSTCIsIlB1YmxpY09yZGVyQ2FyZCIsIml0ZW0iLCJxdWFudGl0eSIsImlzSnVzdFNlbnQiLCJpc1BlbmRpbmciLCJvblF1YW50aXR5Q2hhbmdlIiwib25BZGRJdGVtIiwiX3MiLCJ3aW5kb3dXaWR0aCIsInNldFdpbmRvd1dpZHRoIiwid2luZG93IiwiaW5uZXJXaWR0aCIsImhhbmRsZVJlc2l6ZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiaXNUdk9yTGFyZ2UiLCJjYXJkUGFkZGluZyIsImltYWdlU2l6ZSIsInRpdGxlRm9udFNpemUiLCJkZXNjRm9udFNpemUiLCJwcmljZUZvbnRTaXplIiwiY29udHJvbEhlaWdodCIsImJ1dHRvblBhZGRpbmciLCJkaXNwbGF5IiwiYmFja2dyb3VuZENvbG9yIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsImJvcmRlciIsImJveFNoYWRvdyIsImJveFNpemluZyIsIndpZHRoIiwiaGVpZ2h0IiwiZmxleFNocmluayIsIm92ZXJmbG93IiwiaW1hZ2VVcmwiLCJuYW1lIiwib2JqZWN0Rml0IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiY29sb3IiLCJmb250U2l6ZSIsIm1hcmdpbkxlZnQiLCJmbGV4IiwiZmxleERpcmVjdGlvbiIsIm1hcmdpbiIsImZvbnRXZWlnaHQiLCJsaW5lSGVpZ2h0IiwiZGVzY3JpcHRpb24iLCJtYXJnaW5Ub3AiLCJjb21wbGVtZW50R3JvdXBzIiwibGVuZ3RoIiwic2FsZVByaWNlIiwiZ2FwIiwiYmFja2dyb3VuZCIsImN1cnNvciIsInRleHRBbGlnbiIsIm9wYWNpdHkiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQdWJsaWNPcmRlckNhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgZm9ybWF0QlJMIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IE1lbnVJdGVtUmVzcG9uc2UgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcblxyXG50eXBlIFB1YmxpY09yZGVyQ2FyZFByb3BzID0ge1xyXG4gICAgaXRlbTogTWVudUl0ZW1SZXNwb25zZTtcclxuICAgIHF1YW50aXR5OiBudW1iZXI7XHJcbiAgICBpc0p1c3RTZW50OiBib29sZWFuO1xyXG4gICAgaXNQZW5kaW5nOiBib29sZWFuO1xyXG4gICAgb25RdWFudGl0eUNoYW5nZTogKG5ld1F0eTogbnVtYmVyKSA9PiB2b2lkO1xyXG4gICAgb25BZGRJdGVtOiAoKSA9PiB2b2lkO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFB1YmxpY09yZGVyQ2FyZCh7IGl0ZW0sIHF1YW50aXR5LCBpc0p1c3RTZW50LCBpc1BlbmRpbmcsIG9uUXVhbnRpdHlDaGFuZ2UsIG9uQWRkSXRlbSB9OiBQdWJsaWNPcmRlckNhcmRQcm9wcykge1xyXG4gICAgY29uc3QgW3dpbmRvd1dpZHRoLCBzZXRXaW5kb3dXaWR0aF0gPSB1c2VTdGF0ZSh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93LmlubmVyV2lkdGggOiAxMjAwKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGhhbmRsZVJlc2l6ZSA9ICgpID0+IHNldFdpbmRvd1dpZHRoKHdpbmRvdy5pbm5lcldpZHRoKTtcclxuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCBoYW5kbGVSZXNpemUpO1xyXG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCBoYW5kbGVSZXNpemUpO1xyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIGNvbnN0IGlzVHZPckxhcmdlID0gd2luZG93V2lkdGggPiAxMjAwO1xyXG5cclxuICAgIC8vIERpbWVuc8O1ZXMgZGluw6JtaWNhcyBiYXNlYWRhcyBuYSB0ZWxhXHJcbiAgICBjb25zdCBjYXJkUGFkZGluZyA9IGlzVHZPckxhcmdlID8gMjQgOiAxNjtcclxuICAgIGNvbnN0IGltYWdlU2l6ZSA9IGlzVHZPckxhcmdlID8gMTIwIDogODA7XHJcbiAgICBjb25zdCB0aXRsZUZvbnRTaXplID0gaXNUdk9yTGFyZ2UgPyBcIjEuMjVyZW1cIiA6IFwiMXJlbVwiO1xyXG4gICAgY29uc3QgZGVzY0ZvbnRTaXplID0gaXNUdk9yTGFyZ2UgPyBcIjEuMDVyZW1cIiA6IFwiMC44NXJlbVwiO1xyXG4gICAgY29uc3QgcHJpY2VGb250U2l6ZSA9IGlzVHZPckxhcmdlID8gXCIxLjM1cmVtXCIgOiBcIjEuMXJlbVwiO1xyXG4gICAgY29uc3QgY29udHJvbEhlaWdodCA9IGlzVHZPckxhcmdlID8gNDggOiAzNjtcclxuICAgIGNvbnN0IGJ1dHRvblBhZGRpbmcgPSBpc1R2T3JMYXJnZSA/IFwiMCAyOHB4XCIgOiBcIjAgMjBweFwiO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYmFja2dyb3VuZENvbG9yOiBcIiMxZTFlMjRcIiwgYm9yZGVyUmFkaXVzOiAxMiwgcGFkZGluZzogY2FyZFBhZGRpbmcsIGJvcmRlcjogXCIxcHggc29saWQgIzI5MjkyZVwiLCBib3hTaGFkb3c6IFwiMCA0cHggNnB4IHJnYmEoMCwwLDAsMC4zKVwiLCBib3hTaXppbmc6IFwiYm9yZGVyLWJveFwiIH19PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiBpbWFnZVNpemUsIGhlaWdodDogaW1hZ2VTaXplLCBib3JkZXJSYWRpdXM6IDgsIGJhY2tncm91bmRDb2xvcjogXCIjMzIzMjM4XCIsIGZsZXhTaHJpbms6IDAsIG92ZXJmbG93OiBcImhpZGRlblwiIH19PlxyXG4gICAgICAgICAgICAgICAge2l0ZW0uaW1hZ2VVcmwgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2l0ZW0uaW1hZ2VVcmx9IGFsdD17aXRlbS5uYW1lfSBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIGhlaWdodDogXCIxMDAlXCIsIG9iamVjdEZpdDogXCJjb3ZlclwiIH19IC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiLCBoZWlnaHQ6IFwiMTAwJVwiLCBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsIGNvbG9yOiBcIiM1NTVcIiwgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIycmVtXCIgOiBcIjEuMnJlbVwiIH19PvCfk7c8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5MZWZ0OiAxNiwgZmxleDogMSwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiB9fT5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIHN0eWxlPXt7IG1hcmdpbjogMCwgZm9udFNpemU6IHRpdGxlRm9udFNpemUsIGNvbG9yOiBcIiNmZmZmZmZcIiwgZm9udFdlaWdodDogXCI2MDBcIiwgbGluZUhlaWdodDogXCIxLjJcIiB9fT57aXRlbS5uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGVzY3JpcHRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBtYXJnaW46IFwiNnB4IDAgMFwiLCBmb250U2l6ZTogZGVzY0ZvbnRTaXplLCBjb2xvcjogXCIjOGQ4ZDk5XCIsIGxpbmVIZWlnaHQ6IFwiMS40XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBtYXJnaW5Ub3A6IDEyLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgY29sb3I6IFwiI2Y1OWUwYlwiLCBmb250U2l6ZTogcHJpY2VGb250U2l6ZSB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5jb21wbGVtZW50R3JvdXBzPy5sZW5ndGggPyBcIkEgcGFydGlyIGRlIFwiIDogXCJcIn17Zm9ybWF0QlJMKGl0ZW0uc2FsZVByaWNlKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDEyLCBtYXJnaW5Ub3A6IDEyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGJvcmRlcjogXCIxcHggc29saWQgIzMyMzIzOFwiLCBib3JkZXJSYWRpdXM6IDgsIG92ZXJmbG93OiBcImhpZGRlblwiLCBoZWlnaHQ6IGNvbnRyb2xIZWlnaHQsIGJhY2tncm91bmRDb2xvcjogXCIjMTIxMjE0XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG9uUXVhbnRpdHlDaGFuZ2UocXVhbnRpdHkgLSAxKX0gc3R5bGU9e3sgd2lkdGg6IGNvbnRyb2xIZWlnaHQsIGhlaWdodDogXCIxMDAlXCIsIGJhY2tncm91bmQ6IFwibm9uZVwiLCBib3JkZXI6IFwibm9uZVwiLCBjb2xvcjogXCIjYThhOGIzXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS41cmVtXCIgOiBcIjEuMnJlbVwiLCBjdXJzb3I6IFwicG9pbnRlclwiIH19PuKIkjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyB3aWR0aDogaXNUdk9yTGFyZ2UgPyA0MCA6IDI4LCB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIGNvbG9yOiBcIiNmZmZmZmZcIiwgZm9udFdlaWdodDogXCI1MDBcIiwgZm9udFNpemU6IGlzVHZPckxhcmdlID8gXCIxLjE1cmVtXCIgOiBcIjAuOTVyZW1cIiB9fT57cXVhbnRpdHl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBvblF1YW50aXR5Q2hhbmdlKHF1YW50aXR5ICsgMSl9IHN0eWxlPXt7IHdpZHRoOiBjb250cm9sSGVpZ2h0LCBoZWlnaHQ6IFwiMTAwJVwiLCBiYWNrZ3JvdW5kOiBcIm5vbmVcIiwgYm9yZGVyOiBcIm5vbmVcIiwgY29sb3I6IFwiI2E4YThiM1wiLCBmb250U2l6ZTogaXNUdk9yTGFyZ2UgPyBcIjEuNXJlbVwiIDogXCIxLjJyZW1cIiwgY3Vyc29yOiBcInBvaW50ZXJcIiB9fT4rPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQWRkSXRlbX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcIiNmNTllMGJcIiwgY29sb3I6IFwiIzEyMTIxNFwiLCBib3JkZXI6IFwibm9uZVwiLCBib3JkZXJSYWRpdXM6IDgsIHBhZGRpbmc6IGJ1dHRvblBhZGRpbmcsIGhlaWdodDogY29udHJvbEhlaWdodCwgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBpc1R2T3JMYXJnZSA/IFwiMS4xcmVtXCIgOiBcIjAuOTVyZW1cIiwgY3Vyc29yOiBpc1BlbmRpbmcgPyBcIm5vdC1hbGxvd2VkXCIgOiBcInBvaW50ZXJcIiwgb3BhY2l0eTogaXNQZW5kaW5nID8gMC43IDogMSB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2lzSnVzdFNlbnQgPyBcIlBlZGlyIGRlIG5vdm9cIiA6IFwiUGVkaXJcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn0iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvcHVibGljT3JkZXJpbmcvUHVibGljT3JkZXJDYXJkLnRzeCJ9