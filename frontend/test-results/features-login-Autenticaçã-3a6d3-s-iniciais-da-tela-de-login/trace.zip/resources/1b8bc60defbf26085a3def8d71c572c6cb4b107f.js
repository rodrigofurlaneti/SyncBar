import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/OpenDeliveryOrderDialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { openOrder } from "/src/features/orders/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { OrderType } from "/src/lib/types.ts";
import { Overlay } from "/src/features/orders/Overlay.tsx";
export function OpenDeliveryOrderDialog({ onClose, onOpened }) {
  _s();
  const { branchId, employeeId } = useAuthStore();
  const [orderTypeId, setOrderTypeId] = useState(OrderType.Retirada);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const mutation = useMutation({
    mutationFn: () => openOrder({
      branchId,
      diningTableId: null,
      comandaId: null,
      employeeId: employeeId ?? 1,
      guestCount: null,
      notes: null,
      orderTypeId,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim() === "" ? null : customerPhone.trim(),
      deliveryAddress: orderTypeId === OrderType.Delivery ? deliveryAddress.trim() : null
    }),
    onSuccess: (orderId) => onOpened(orderId)
  });
  const isDelivery = orderTypeId === OrderType.Delivery;
  const canSubmit = customerName.trim() !== "" && (!isDelivery || deliveryAddress.trim() !== "");
  return /* @__PURE__ */ jsxDEV(Overlay, { onClose, title: "Novo pedido — retirada / delivery", children: [
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8 }, children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: orderTypeId === OrderType.Retirada ? "btn-primary" : "btn-ghost",
          style: { flex: 1 },
          onClick: () => setOrderTypeId(OrderType.Retirada),
          children: "Retirada"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
          lineNumber: 64,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: isDelivery ? "btn-primary" : "btn-ghost",
          style: { flex: 1 },
          onClick: () => setOrderTypeId(OrderType.Delivery),
          children: "Delivery"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
          lineNumber: 72,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Nome do cliente" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { value: customerName, onChange: (e) => setCustomerName(e.target.value), autoFocus: true }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
        lineNumber: 84,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
      lineNumber: 82,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Telefone" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
        lineNumber: 88,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { value: customerPhone, onChange: (e) => setCustomerPhone(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
        lineNumber: 89,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
      lineNumber: 87,
      columnNumber: 7
    }, this),
    isDelivery && /* @__PURE__ */ jsxDEV("label", { style: { display: "grid", gap: 6 }, children: [
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Endereço de entrega" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
        lineNumber: 94,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { value: deliveryAddress, onChange: (e) => setDeliveryAddress(e.target.value) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
        lineNumber: 95,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
      lineNumber: 93,
      columnNumber: 7
    }, this),
    mutation.isError && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: mutation.error instanceof ApiError ? mutation.error.message : "Falha ao abrir pedido." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", onClick: onClose, children: "Voltar" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
        lineNumber: 106,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          disabled: !canSubmit || mutation.isPending,
          onClick: () => mutation.mutate(),
          children: mutation.isPending ? "Abrindo…" : "Abrir pedido"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
          lineNumber: 109,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
      lineNumber: 105,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx",
    lineNumber: 62,
    columnNumber: 5
  }, this);
}
_s(OpenDeliveryOrderDialog, "FVQZMwFG7fiB4/64Y9mIeasCxlI=", false, function() {
  return [useAuthStore, useMutation];
});
_c = OpenDeliveryOrderDialog;
var _c;
$RefreshReg$(_c, "OpenDeliveryOrderDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/orders/OpenDeliveryOrderDialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDUCxTQUFTQSxnQkFBZ0I7QUFDMUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxlQUFlO0FBT2pCLGdCQUFTQyx3QkFBd0IsRUFBRUMsU0FBU0MsU0FBZ0IsR0FBRztBQUFBQyxLQUFBO0FBQ3BFLFFBQU0sRUFBRUMsVUFBVUMsV0FBVyxJQUFJVCxhQUFhO0FBQzlDLFFBQU0sQ0FBQ1UsYUFBYUMsY0FBYyxJQUFJZCxTQUFpQkssVUFBVVUsUUFBUTtBQUN6RSxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSWpCLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNrQixlQUFlQyxnQkFBZ0IsSUFBSW5CLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNvQixpQkFBaUJDLGtCQUFrQixJQUFJckIsU0FBUyxFQUFFO0FBRXpELFFBQU1zQixXQUFXckIsWUFBWTtBQUFBLElBQzNCc0IsWUFBWUEsTUFDVnJCLFVBQVU7QUFBQSxNQUNSUztBQUFBQSxNQUNBYSxlQUFlO0FBQUEsTUFDZkMsV0FBVztBQUFBLE1BQ1hiLFlBQVlBLGNBQWM7QUFBQSxNQUMxQmMsWUFBWTtBQUFBLE1BQ1pDLE9BQU87QUFBQSxNQUNQZDtBQUFBQSxNQUNBRyxjQUFjQSxhQUFhWSxLQUFLO0FBQUEsTUFDaENWLGVBQWVBLGNBQWNVLEtBQUssTUFBTSxLQUFLLE9BQU9WLGNBQWNVLEtBQUs7QUFBQSxNQUN2RVIsaUJBQWlCUCxnQkFBZ0JSLFVBQVV3QixXQUFXVCxnQkFBZ0JRLEtBQUssSUFBSTtBQUFBLElBQ2pGLENBQUM7QUFBQSxJQUNIRSxXQUFXQSxDQUFDQyxZQUFZdEIsU0FBU3NCLE9BQU87QUFBQSxFQUMxQyxDQUFDO0FBRUQsUUFBTUMsYUFBYW5CLGdCQUFnQlIsVUFBVXdCO0FBQzdDLFFBQU1JLFlBQ0pqQixhQUFhWSxLQUFLLE1BQU0sT0FBTyxDQUFDSSxjQUFjWixnQkFBZ0JRLEtBQUssTUFBTTtBQUUzRSxTQUNFLHVCQUFDLFdBQVEsU0FBa0IsT0FBTSxxQ0FDL0I7QUFBQSwyQkFBQyxTQUFJLE9BQU8sRUFBRU0sU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBV3RCLGdCQUFnQlIsVUFBVVUsV0FBVyxnQkFBZ0I7QUFBQSxVQUNoRSxPQUFPLEVBQUVxQixNQUFNLEVBQUU7QUFBQSxVQUNqQixTQUFTLE1BQU10QixlQUFlVCxVQUFVVSxRQUFRO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFKcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxXQUFXaUIsYUFBYSxnQkFBZ0I7QUFBQSxVQUN4QyxPQUFPLEVBQUVJLE1BQU0sRUFBRTtBQUFBLFVBQ2pCLFNBQVMsTUFBTXRCLGVBQWVULFVBQVV3QixRQUFRO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFKcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFFQSx1QkFBQyxXQUFNLE9BQU8sRUFBRUssU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDdEM7QUFBQSw2QkFBQyxVQUFLLE9BQU8sRUFBRUUsT0FBTyxrQkFBa0JDLFVBQVUsU0FBUyxHQUFHLCtCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZFO0FBQUEsTUFDN0UsdUJBQUMsV0FBTSxPQUFPdEIsY0FBYyxVQUFVLENBQUN1QixNQUFNdEIsZ0JBQWdCc0IsRUFBRUMsT0FBT0MsS0FBSyxHQUFHLFdBQVMsUUFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RjtBQUFBLFNBRnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUEsdUJBQUMsV0FBTSxPQUFPLEVBQUVQLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsNkJBQUMsVUFBSyxPQUFPLEVBQUVFLE9BQU8sa0JBQWtCQyxVQUFVLFNBQVMsR0FBRyx3QkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLE1BQ3RFLHVCQUFDLFdBQU0sT0FBT3BCLGVBQWUsVUFBVSxDQUFDcUIsTUFBTXBCLGlCQUFpQm9CLEVBQUVDLE9BQU9DLEtBQUssS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRTtBQUFBLFNBRmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUNULGNBQ0MsdUJBQUMsV0FBTSxPQUFPLEVBQUVFLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3RDO0FBQUEsNkJBQUMsVUFBSyxPQUFPLEVBQUVFLE9BQU8sa0JBQWtCQyxVQUFVLFNBQVMsR0FBRyxtQ0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRjtBQUFBLE1BQ2pGLHVCQUFDLFdBQU0sT0FBT2xCLGlCQUFpQixVQUFVLENBQUNtQixNQUFNbEIsbUJBQW1Ca0IsRUFBRUMsT0FBT0MsS0FBSyxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1GO0FBQUEsU0FGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFHRG5CLFNBQVNvQixXQUNSLHVCQUFDLE9BQUUsV0FBVSxjQUNWcEIsbUJBQVNxQixpQkFBaUJ2QyxXQUFXa0IsU0FBU3FCLE1BQU1DLFVBQVUsNEJBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxPQUFPLEVBQUVWLFNBQVMsUUFBUUMsS0FBSyxJQUFJVSxnQkFBZ0IsV0FBVyxHQUNqRTtBQUFBLDZCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsYUFBWSxTQUFTckMsU0FBUyxzQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsVUFBVSxDQUFDeUIsYUFBYVgsU0FBU3dCO0FBQUFBLFVBQ2pDLFNBQVMsTUFBTXhCLFNBQVN5QixPQUFPO0FBQUEsVUFFOUJ6QixtQkFBU3dCLFlBQVksYUFBYTtBQUFBO0FBQUEsUUFOckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLE9BdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3REE7QUFFSjtBQUFDcEMsR0F2RmVILHlCQUF1QjtBQUFBLFVBQ0pKLGNBTWhCRixXQUFXO0FBQUE7QUFBQSxLQVBkTTtBQUF1QixJQUFBeUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsIm9wZW5PcmRlciIsInVzZUF1dGhTdG9yZSIsIkFwaUVycm9yIiwiT3JkZXJUeXBlIiwiT3ZlcmxheSIsIk9wZW5EZWxpdmVyeU9yZGVyRGlhbG9nIiwib25DbG9zZSIsIm9uT3BlbmVkIiwiX3MiLCJicmFuY2hJZCIsImVtcGxveWVlSWQiLCJvcmRlclR5cGVJZCIsInNldE9yZGVyVHlwZUlkIiwiUmV0aXJhZGEiLCJjdXN0b21lck5hbWUiLCJzZXRDdXN0b21lck5hbWUiLCJjdXN0b21lclBob25lIiwic2V0Q3VzdG9tZXJQaG9uZSIsImRlbGl2ZXJ5QWRkcmVzcyIsInNldERlbGl2ZXJ5QWRkcmVzcyIsIm11dGF0aW9uIiwibXV0YXRpb25GbiIsImRpbmluZ1RhYmxlSWQiLCJjb21hbmRhSWQiLCJndWVzdENvdW50Iiwibm90ZXMiLCJ0cmltIiwiRGVsaXZlcnkiLCJvblN1Y2Nlc3MiLCJvcmRlcklkIiwiaXNEZWxpdmVyeSIsImNhblN1Ym1pdCIsImRpc3BsYXkiLCJnYXAiLCJmbGV4IiwiY29sb3IiLCJmb250U2l6ZSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImlzRXJyb3IiLCJlcnJvciIsIm1lc3NhZ2UiLCJqdXN0aWZ5Q29udGVudCIsImlzUGVuZGluZyIsIm11dGF0ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk9wZW5EZWxpdmVyeU9yZGVyRGlhbG9nLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgb3Blbk9yZGVyIH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHsgT3JkZXJUeXBlIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgeyBPdmVybGF5IH0gZnJvbSBcIi4vT3ZlcmxheVwiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIG9uT3BlbmVkOiAob3JkZXJJZDogbnVtYmVyKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gT3BlbkRlbGl2ZXJ5T3JkZXJEaWFsb2coeyBvbkNsb3NlLCBvbk9wZW5lZCB9OiBQcm9wcykge1xyXG4gIGNvbnN0IHsgYnJhbmNoSWQsIGVtcGxveWVlSWQgfSA9IHVzZUF1dGhTdG9yZSgpO1xyXG4gIGNvbnN0IFtvcmRlclR5cGVJZCwgc2V0T3JkZXJUeXBlSWRdID0gdXNlU3RhdGU8bnVtYmVyPihPcmRlclR5cGUuUmV0aXJhZGEpO1xyXG4gIGNvbnN0IFtjdXN0b21lck5hbWUsIHNldEN1c3RvbWVyTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY3VzdG9tZXJQaG9uZSwgc2V0Q3VzdG9tZXJQaG9uZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGVsaXZlcnlBZGRyZXNzLCBzZXREZWxpdmVyeUFkZHJlc3NdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IG11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgb3Blbk9yZGVyKHtcclxuICAgICAgICBicmFuY2hJZCxcclxuICAgICAgICBkaW5pbmdUYWJsZUlkOiBudWxsLFxyXG4gICAgICAgIGNvbWFuZGFJZDogbnVsbCxcclxuICAgICAgICBlbXBsb3llZUlkOiBlbXBsb3llZUlkID8/IDEsXHJcbiAgICAgICAgZ3Vlc3RDb3VudDogbnVsbCxcclxuICAgICAgICBub3RlczogbnVsbCxcclxuICAgICAgICBvcmRlclR5cGVJZCxcclxuICAgICAgICBjdXN0b21lck5hbWU6IGN1c3RvbWVyTmFtZS50cmltKCksXHJcbiAgICAgICAgY3VzdG9tZXJQaG9uZTogY3VzdG9tZXJQaG9uZS50cmltKCkgPT09IFwiXCIgPyBudWxsIDogY3VzdG9tZXJQaG9uZS50cmltKCksXHJcbiAgICAgICAgZGVsaXZlcnlBZGRyZXNzOiBvcmRlclR5cGVJZCA9PT0gT3JkZXJUeXBlLkRlbGl2ZXJ5ID8gZGVsaXZlcnlBZGRyZXNzLnRyaW0oKSA6IG51bGwsXHJcbiAgICAgIH0pLFxyXG4gICAgb25TdWNjZXNzOiAob3JkZXJJZCkgPT4gb25PcGVuZWQob3JkZXJJZCksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGlzRGVsaXZlcnkgPSBvcmRlclR5cGVJZCA9PT0gT3JkZXJUeXBlLkRlbGl2ZXJ5O1xyXG4gIGNvbnN0IGNhblN1Ym1pdCA9XHJcbiAgICBjdXN0b21lck5hbWUudHJpbSgpICE9PSBcIlwiICYmICghaXNEZWxpdmVyeSB8fCBkZWxpdmVyeUFkZHJlc3MudHJpbSgpICE9PSBcIlwiKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxPdmVybGF5IG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPVwiTm92byBwZWRpZG8g4oCUIHJldGlyYWRhIC8gZGVsaXZlcnlcIj5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtvcmRlclR5cGVJZCA9PT0gT3JkZXJUeXBlLlJldGlyYWRhID8gXCJidG4tcHJpbWFyeVwiIDogXCJidG4tZ2hvc3RcIn1cclxuICAgICAgICAgIHN0eWxlPXt7IGZsZXg6IDEgfX1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9yZGVyVHlwZUlkKE9yZGVyVHlwZS5SZXRpcmFkYSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgUmV0aXJhZGFcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT17aXNEZWxpdmVyeSA/IFwiYnRuLXByaW1hcnlcIiA6IFwiYnRuLWdob3N0XCJ9XHJcbiAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxIH19XHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcmRlclR5cGVJZChPcmRlclR5cGUuRGVsaXZlcnkpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIERlbGl2ZXJ5XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDYgfX0+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+Tm9tZSBkbyBjbGllbnRlPC9zcGFuPlxyXG4gICAgICAgIDxpbnB1dCB2YWx1ZT17Y3VzdG9tZXJOYW1lfSBvbkNoYW5nZT17KGUpID0+IHNldEN1c3RvbWVyTmFtZShlLnRhcmdldC52YWx1ZSl9IGF1dG9Gb2N1cyAvPlxyXG4gICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDYgfX0+XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+VGVsZWZvbmU8L3NwYW4+XHJcbiAgICAgICAgPGlucHV0IHZhbHVlPXtjdXN0b21lclBob25lfSBvbkNoYW5nZT17KGUpID0+IHNldEN1c3RvbWVyUGhvbmUoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAge2lzRGVsaXZlcnkgJiYgKFxyXG4gICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA2IH19PlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+RW5kZXJlw6dvIGRlIGVudHJlZ2E8L3NwYW4+XHJcbiAgICAgICAgICA8aW5wdXQgdmFsdWU9e2RlbGl2ZXJ5QWRkcmVzc30gb25DaGFuZ2U9eyhlKSA9PiBzZXREZWxpdmVyeUFkZHJlc3MoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7bXV0YXRpb24uaXNFcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPlxyXG4gICAgICAgICAge211dGF0aW9uLmVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBtdXRhdGlvbi5lcnJvci5tZXNzYWdlIDogXCJGYWxoYSBhbyBhYnJpciBwZWRpZG8uXCJ9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgIFZvbHRhclxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIlxyXG4gICAgICAgICAgZGlzYWJsZWQ9eyFjYW5TdWJtaXQgfHwgbXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gbXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge211dGF0aW9uLmlzUGVuZGluZyA/IFwiQWJyaW5kb+KAplwiIDogXCJBYnJpciBwZWRpZG9cIn1cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L092ZXJsYXk+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvb3JkZXJzL09wZW5EZWxpdmVyeU9yZGVyRGlhbG9nLnRzeCJ9