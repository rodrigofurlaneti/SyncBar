import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/IFoodAlertsBell.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  acknowledgeIFoodOperationalAlert,
  getIFoodOperationalAlerts
} from "/src/features/integrations/api.ts";
import { useToast } from "/src/ui/Toast.tsx";
const POLL_INTERVAL_MS = 3e4;
const SEVERITY_COLOR = {
  Info: "var(--info, #3b82f6)",
  Warning: "var(--warn, #d97706)",
  Critical: "var(--danger, #dc2626)"
};
const SEVERITY_ICON = {
  Info: "🔵",
  Warning: "🟠",
  Critical: "🔴"
};
function playAlertChime() {
  try {
    const AudioCtxCtor = window.AudioContext ?? window.webkitAudioContext;
    if (!AudioCtxCtor) return;
    const ctx = new AudioCtxCtor();
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.type = "square";
    oscillator.frequency.value = 440;
    const now = ctx.currentTime;
    gain.gain.setValueAtTime(1e-4, now);
    gain.gain.exponentialRampToValueAtTime(0.25, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(1e-4, now + 0.5);
    oscillator.connect(gain);
    gain.connect(ctx.destination);
    oscillator.start(now);
    oscillator.stop(now + 0.5);
    setTimeout(() => void ctx.close(), 900);
  } catch {
  }
}
export function IFoodAlertsBell({ companyId }) {
  _s();
  const queryClient = useQueryClient();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const containerRef = useRef(null);
  const knownAlertIdsRef = useRef(null);
  const lastCompanyIdRef = useRef(null);
  const alertsQuery = useQuery({
    queryKey: ["integrations", "ifood", "alerts", companyId],
    queryFn: () => getIFoodOperationalAlerts(companyId),
    enabled: companyId != null,
    refetchInterval: POLL_INTERVAL_MS
  });
  const alerts = alertsQuery.data ?? [];
  useEffect(() => {
    if (!alertsQuery.data) return;
    const currentIds = new Set(alertsQuery.data.map((a) => a.id));
    if (lastCompanyIdRef.current !== companyId) {
      lastCompanyIdRef.current = companyId;
      knownAlertIdsRef.current = currentIds;
      return;
    }
    if (knownAlertIdsRef.current === null) {
      knownAlertIdsRef.current = currentIds;
      return;
    }
    const previouslyKnown = knownAlertIdsRef.current;
    const newAlerts = alertsQuery.data.filter((a) => !previouslyKnown.has(a.id));
    knownAlertIdsRef.current = currentIds;
    if (newAlerts.length === 0) return;
    playAlertChime();
    for (const alert of newAlerts) {
      const icon = SEVERITY_ICON[alert.severity];
      toast.info(`${icon} ${alert.title} — ${alert.branchName}`);
    }
  }, [alertsQuery.data, toast, companyId]);
  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);
  if (companyId == null) return null;
  const handleAcknowledge = async (alertId) => {
    try {
      await acknowledgeIFoodOperationalAlert(companyId, alertId);
      queryClient.setQueryData(
        ["integrations", "ifood", "alerts", companyId],
        (previous) => (previous ?? []).filter((a) => a.id !== alertId)
      );
    } catch {
      toast.error("Não foi possível marcar o alerta como visto.");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { ref: containerRef, style: { position: "relative" }, children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "btn-ghost btn-icon",
        "aria-label": alerts.length > 0 ? `${alerts.length} alertas do iFood` : "Alertas do iFood",
        title: "Alertas operacionais do iFood",
        onClick: () => setOpen((v) => !v),
        style: { position: "relative" },
        children: [
          "🔔",
          alerts.length > 0 && /* @__PURE__ */ jsxDEV(
            "span",
            {
              style: {
                position: "absolute",
                top: -4,
                right: -4,
                background: "var(--danger, #dc2626)",
                color: "#fff",
                borderRadius: "999px",
                fontSize: "0.65rem",
                fontWeight: 700,
                lineHeight: 1,
                padding: "3px 5px",
                minWidth: 16,
                textAlign: "center"
              },
              children: alerts.length > 9 ? "9+" : alerts.length
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
              lineNumber: 171,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
        lineNumber: 161,
        columnNumber: 7
      },
      this
    ),
    open && /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          position: "absolute",
          top: "calc(100% + 8px)",
          right: 0,
          width: 340,
          maxHeight: 420,
          overflowY: "auto",
          background: "var(--surface, var(--panel-bg, #1e1e1e))",
          border: "1px solid var(--border, #d0d0d0)",
          borderRadius: 10,
          boxShadow: "0 8px 24px rgba(0,0,0,0.18)",
          zIndex: 1e3,
          padding: alerts.length === 0 ? 16 : 6
        },
        children: alerts.length === 0 ? /* @__PURE__ */ jsxDEV("p", { style: { margin: 0, color: "var(--ink-dim)", fontSize: "0.9rem" }, children: "Nenhum alerta operacional do iFood no momento." }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
          lineNumber: 210,
          columnNumber: 9
        }, this) : alerts.map(
          (alert) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                padding: "10px 10px",
                borderLeft: `3px solid ${SEVERITY_COLOR[alert.severity]}`,
                borderRadius: 6,
                marginBottom: 4,
                background: "var(--surface-raised, rgba(0,0,0,0.03))"
              },
              children: [
                /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", gap: 8 }, children: [
                  /* @__PURE__ */ jsxDEV("strong", { style: { fontSize: "0.85rem" }, children: alert.title }, void 0, false, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
                    lineNumber: 226,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      className: "btn-ghost",
                      style: { padding: "2px 8px", fontSize: "0.75rem" },
                      onClick: () => void handleAcknowledge(alert.id),
                      children: "OK"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
                      lineNumber: 227,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
                  lineNumber: 225,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("p", { style: { margin: "4px 0 0", fontSize: "0.8rem", color: "var(--ink-dim)" }, children: alert.message }, void 0, false, {
                  fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
                  lineNumber: 236,
                  columnNumber: 17
                }, this)
              ]
            },
            alert.id,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
              lineNumber: 215,
              columnNumber: 9
            },
            this
          )
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
        lineNumber: 193,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx",
    lineNumber: 160,
    columnNumber: 5
  }, this);
}
_s(IFoodAlertsBell, "YKwwwkgYOpJpFKxYlNt3rfg/QG0=", false, function() {
  return [useQueryClient, useToast, useQuery];
});
_c = IFoodAlertsBell;
var _c;
$RefreshReg$(_c, "IFoodAlertsBell");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/IFoodAlertsBell.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUpVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZKVixTQUFTQSxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsU0FBU0MsVUFBVUMsc0JBQXNCO0FBQ3pDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FFSztBQUNQLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxtQkFBbUI7QUFFekIsTUFBTUMsaUJBQW9FO0FBQUEsRUFDeEVDLE1BQU07QUFBQSxFQUNOQyxTQUFTO0FBQUEsRUFDVEMsVUFBVTtBQUNaO0FBRUEsTUFBTUMsZ0JBQW1FO0FBQUEsRUFDdkVILE1BQU07QUFBQSxFQUNOQyxTQUFTO0FBQUEsRUFDVEMsVUFBVTtBQUNaO0FBT0EsU0FBU0UsaUJBQWlCO0FBQ3hCLE1BQUk7QUFDRixVQUFNQyxlQUNKQyxPQUFPQyxnQkFBaUJELE9BQW1FRTtBQUM3RixRQUFJLENBQUNILGFBQWM7QUFDbkIsVUFBTUksTUFBTSxJQUFJSixhQUFhO0FBQzdCLFVBQU1LLGFBQWFELElBQUlFLGlCQUFpQjtBQUN4QyxVQUFNQyxPQUFPSCxJQUFJSSxXQUFXO0FBQzVCSCxlQUFXSSxPQUFPO0FBQ2xCSixlQUFXSyxVQUFVQyxRQUFRO0FBQzdCLFVBQU1DLE1BQU1SLElBQUlTO0FBQ2hCTixTQUFLQSxLQUFLTyxlQUFlLE1BQVFGLEdBQUc7QUFDcENMLFNBQUtBLEtBQUtRLDZCQUE2QixNQUFNSCxNQUFNLElBQUk7QUFDdkRMLFNBQUtBLEtBQUtRLDZCQUE2QixNQUFRSCxNQUFNLEdBQUc7QUFDeERQLGVBQVdXLFFBQVFULElBQUk7QUFDdkJBLFNBQUtTLFFBQVFaLElBQUlhLFdBQVc7QUFDNUJaLGVBQVdhLE1BQU1OLEdBQUc7QUFDcEJQLGVBQVdjLEtBQUtQLE1BQU0sR0FBRztBQUN6QlEsZUFBVyxNQUFNLEtBQUtoQixJQUFJaUIsTUFBTSxHQUFHLEdBQUc7QUFBQSxFQUN4QyxRQUFRO0FBQUEsRUFDTjtBQUVKO0FBVU8sZ0JBQVNDLGdCQUFnQixFQUFFQyxVQUF3QyxHQUFHO0FBQUFDLEtBQUE7QUFDM0UsUUFBTUMsY0FBY3BDLGVBQWU7QUFDbkMsUUFBTXFDLFFBQVFsQyxTQUFTO0FBQ3ZCLFFBQU0sQ0FBQ21DLE1BQU1DLE9BQU8sSUFBSXpDLFNBQVMsS0FBSztBQUN0QyxRQUFNMEMsZUFBZTNDLE9BQXVCLElBQUk7QUFDaEQsUUFBTTRDLG1CQUFtQjVDLE9BQTJCLElBQUk7QUFDeEQsUUFBTTZDLG1CQUFtQjdDLE9BQXNCLElBQUk7QUFFbkQsUUFBTThDLGNBQWM1QyxTQUFTO0FBQUEsSUFDM0I2QyxVQUFVLENBQUMsZ0JBQWdCLFNBQVMsVUFBVVYsU0FBUztBQUFBLElBQ3ZEVyxTQUFTQSxNQUFNM0MsMEJBQTBCZ0MsU0FBbUI7QUFBQSxJQUM1RFksU0FBU1osYUFBYTtBQUFBLElBQ3RCYSxpQkFBaUIzQztBQUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTTRDLFNBQVNMLFlBQVlNLFFBQVE7QUFLbkNyRCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUMrQyxZQUFZTSxLQUFNO0FBRXZCLFVBQU1DLGFBQWEsSUFBSUMsSUFBSVIsWUFBWU0sS0FBS0csSUFBSSxDQUFDQyxNQUFNQSxFQUFFQyxFQUFFLENBQUM7QUFNNUQsUUFBSVosaUJBQWlCYSxZQUFZckIsV0FBVztBQUMxQ1EsdUJBQWlCYSxVQUFVckI7QUFDM0JPLHVCQUFpQmMsVUFBVUw7QUFDM0I7QUFBQSxJQUNGO0FBRUEsUUFBSVQsaUJBQWlCYyxZQUFZLE1BQU07QUFDckNkLHVCQUFpQmMsVUFBVUw7QUFDM0I7QUFBQSxJQUNGO0FBRUEsVUFBTU0sa0JBQWtCZixpQkFBaUJjO0FBQ3pDLFVBQU1FLFlBQVlkLFlBQVlNLEtBQUtTLE9BQU8sQ0FBQ0wsTUFBTSxDQUFDRyxnQkFBZ0JHLElBQUlOLEVBQUVDLEVBQUUsQ0FBQztBQUMzRWIscUJBQWlCYyxVQUFVTDtBQUUzQixRQUFJTyxVQUFVRyxXQUFXLEVBQUc7QUFFNUJsRCxtQkFBZTtBQUNmLGVBQVdtRCxTQUFTSixXQUFXO0FBQzdCLFlBQU1LLE9BQU9yRCxjQUFjb0QsTUFBTUUsUUFBUTtBQUN6QzFCLFlBQU0yQixLQUFLLEdBQUdGLElBQUksSUFBSUQsTUFBTUksS0FBSyxNQUFNSixNQUFNSyxVQUFVLEVBQUU7QUFBQSxJQUMzRDtBQUFBLEVBQ0YsR0FBRyxDQUFDdkIsWUFBWU0sTUFBTVosT0FBT0gsU0FBUyxDQUFDO0FBR3ZDdEMsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDMEMsS0FBTTtBQUNYLFVBQU02QixxQkFBcUJBLENBQUNDLFVBQXNCO0FBQ2hELFVBQUk1QixhQUFhZSxXQUFXLENBQUNmLGFBQWFlLFFBQVFjLFNBQVNELE1BQU1FLE1BQWMsR0FBRztBQUNoRi9CLGdCQUFRLEtBQUs7QUFBQSxNQUNmO0FBQUEsSUFDRjtBQUNBZ0MsYUFBU0MsaUJBQWlCLGFBQWFMLGtCQUFrQjtBQUN6RCxXQUFPLE1BQU1JLFNBQVNFLG9CQUFvQixhQUFhTixrQkFBa0I7QUFBQSxFQUMzRSxHQUFHLENBQUM3QixJQUFJLENBQUM7QUFFVCxNQUFJSixhQUFhLEtBQU0sUUFBTztBQUU5QixRQUFNd0Msb0JBQW9CLE9BQU9DLFlBQW9CO0FBQ25ELFFBQUk7QUFDRixZQUFNMUUsaUNBQWlDaUMsV0FBV3lDLE9BQU87QUFDekR2QyxrQkFBWXdDO0FBQUFBLFFBQ1YsQ0FBQyxnQkFBZ0IsU0FBUyxVQUFVMUMsU0FBUztBQUFBLFFBQzdDLENBQUMyQyxjQUFjQSxZQUFZLElBQUluQixPQUFPLENBQUNMLE1BQU1BLEVBQUVDLE9BQU9xQixPQUFPO0FBQUEsTUFDL0Q7QUFBQSxJQUNGLFFBQVE7QUFDTnRDLFlBQU15QyxNQUFNLDhDQUE4QztBQUFBLElBQzVEO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxLQUFLdEMsY0FBYyxPQUFPLEVBQUV1QyxVQUFVLFdBQVcsR0FDcEQ7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsY0FBWS9CLE9BQU9ZLFNBQVMsSUFBSSxHQUFHWixPQUFPWSxNQUFNLHNCQUFzQjtBQUFBLFFBQ3RFLE9BQU07QUFBQSxRQUNOLFNBQVMsTUFBTXJCLFFBQVEsQ0FBQ3lDLE1BQU0sQ0FBQ0EsQ0FBQztBQUFBLFFBQ2hDLE9BQU8sRUFBRUQsVUFBVSxXQUFXO0FBQUEsUUFBRTtBQUFBO0FBQUEsVUFHL0IvQixPQUFPWSxTQUFTLEtBQ2Y7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU87QUFBQSxnQkFDTG1CLFVBQVU7QUFBQSxnQkFDVkUsS0FBSztBQUFBLGdCQUNMQyxPQUFPO0FBQUEsZ0JBQ1BDLFlBQVk7QUFBQSxnQkFDWkMsT0FBTztBQUFBLGdCQUNQQyxjQUFjO0FBQUEsZ0JBQ2RDLFVBQVU7QUFBQSxnQkFDVkMsWUFBWTtBQUFBLGdCQUNaQyxZQUFZO0FBQUEsZ0JBQ1pDLFNBQVM7QUFBQSxnQkFDVEMsVUFBVTtBQUFBLGdCQUNWQyxXQUFXO0FBQUEsY0FDYjtBQUFBLGNBRUMzQyxpQkFBT1ksU0FBUyxJQUFJLE9BQU9aLE9BQU9ZO0FBQUFBO0FBQUFBLFlBaEJyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQkE7QUFBQTtBQUFBO0FBQUEsTUEzQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNkJBO0FBQUEsSUFFQ3RCLFFBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU87QUFBQSxVQUNMeUMsVUFBVTtBQUFBLFVBQ1ZFLEtBQUs7QUFBQSxVQUNMQyxPQUFPO0FBQUEsVUFDUFUsT0FBTztBQUFBLFVBQ1BDLFdBQVc7QUFBQSxVQUNYQyxXQUFXO0FBQUEsVUFDWFgsWUFBWTtBQUFBLFVBQ1pZLFFBQVE7QUFBQSxVQUNSVixjQUFjO0FBQUEsVUFDZFcsV0FBVztBQUFBLFVBQ1hDLFFBQVE7QUFBQSxVQUNSUixTQUFTekMsT0FBT1ksV0FBVyxJQUFJLEtBQUs7QUFBQSxRQUN0QztBQUFBLFFBRUNaLGlCQUFPWSxXQUFXLElBQ2pCLHVCQUFDLE9BQUUsT0FBTyxFQUFFc0MsUUFBUSxHQUFHZCxPQUFPLGtCQUFrQkUsVUFBVSxTQUFTLEdBQUcsOERBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBdEMsT0FBT0k7QUFBQUEsVUFBSSxDQUFDUyxVQUNWO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxPQUFPO0FBQUEsZ0JBQ0w0QixTQUFTO0FBQUEsZ0JBQ1RVLFlBQVksYUFBYTlGLGVBQWV3RCxNQUFNRSxRQUFRLENBQUM7QUFBQSxnQkFDdkRzQixjQUFjO0FBQUEsZ0JBQ2RlLGNBQWM7QUFBQSxnQkFDZGpCLFlBQVk7QUFBQSxjQUNkO0FBQUEsY0FFQTtBQUFBLHVDQUFDLFNBQUksT0FBTyxFQUFFa0IsU0FBUyxRQUFRQyxnQkFBZ0IsaUJBQWlCQyxLQUFLLEVBQUUsR0FDckU7QUFBQSx5Q0FBQyxZQUFPLE9BQU8sRUFBRWpCLFVBQVUsVUFBVSxHQUFJekIsZ0JBQU1JLFNBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFEO0FBQUEsa0JBQ3JEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxXQUFVO0FBQUEsc0JBQ1YsT0FBTyxFQUFFd0IsU0FBUyxXQUFXSCxVQUFVLFVBQVU7QUFBQSxzQkFDakQsU0FBUyxNQUFNLEtBQUtaLGtCQUFrQmIsTUFBTVAsRUFBRTtBQUFBLHNCQUFFO0FBQUE7QUFBQSxvQkFKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9BO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsT0FBTyxFQUFFNEMsUUFBUSxXQUFXWixVQUFVLFVBQVVGLE9BQU8saUJBQWlCLEdBQUl2QixnQkFBTTJDLFdBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZGO0FBQUE7QUFBQTtBQUFBLFlBcEJ4RjNDLE1BQU1QO0FBQUFBLFlBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXNCQTtBQUFBLFFBQ0Q7QUFBQTtBQUFBLE1BN0NMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQStDQTtBQUFBLE9BaEZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrRkE7QUFFSjtBQUFDbkIsR0FwS2VGLGlCQUFlO0FBQUEsVUFDVGpDLGdCQUNORyxVQU1NSixRQUFRO0FBQUE7QUFBQSxLQVJka0M7QUFBZSxJQUFBd0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiYWNrbm93bGVkZ2VJRm9vZE9wZXJhdGlvbmFsQWxlcnQiLCJnZXRJRm9vZE9wZXJhdGlvbmFsQWxlcnRzIiwidXNlVG9hc3QiLCJQT0xMX0lOVEVSVkFMX01TIiwiU0VWRVJJVFlfQ09MT1IiLCJJbmZvIiwiV2FybmluZyIsIkNyaXRpY2FsIiwiU0VWRVJJVFlfSUNPTiIsInBsYXlBbGVydENoaW1lIiwiQXVkaW9DdHhDdG9yIiwid2luZG93IiwiQXVkaW9Db250ZXh0Iiwid2Via2l0QXVkaW9Db250ZXh0IiwiY3R4Iiwib3NjaWxsYXRvciIsImNyZWF0ZU9zY2lsbGF0b3IiLCJnYWluIiwiY3JlYXRlR2FpbiIsInR5cGUiLCJmcmVxdWVuY3kiLCJ2YWx1ZSIsIm5vdyIsImN1cnJlbnRUaW1lIiwic2V0VmFsdWVBdFRpbWUiLCJleHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lIiwiY29ubmVjdCIsImRlc3RpbmF0aW9uIiwic3RhcnQiLCJzdG9wIiwic2V0VGltZW91dCIsImNsb3NlIiwiSUZvb2RBbGVydHNCZWxsIiwiY29tcGFueUlkIiwiX3MiLCJxdWVyeUNsaWVudCIsInRvYXN0Iiwib3BlbiIsInNldE9wZW4iLCJjb250YWluZXJSZWYiLCJrbm93bkFsZXJ0SWRzUmVmIiwibGFzdENvbXBhbnlJZFJlZiIsImFsZXJ0c1F1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwiZW5hYmxlZCIsInJlZmV0Y2hJbnRlcnZhbCIsImFsZXJ0cyIsImRhdGEiLCJjdXJyZW50SWRzIiwiU2V0IiwibWFwIiwiYSIsImlkIiwiY3VycmVudCIsInByZXZpb3VzbHlLbm93biIsIm5ld0FsZXJ0cyIsImZpbHRlciIsImhhcyIsImxlbmd0aCIsImFsZXJ0IiwiaWNvbiIsInNldmVyaXR5IiwiaW5mbyIsInRpdGxlIiwiYnJhbmNoTmFtZSIsImhhbmRsZUNsaWNrT3V0c2lkZSIsImV2ZW50IiwiY29udGFpbnMiLCJ0YXJnZXQiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiaGFuZGxlQWNrbm93bGVkZ2UiLCJhbGVydElkIiwic2V0UXVlcnlEYXRhIiwicHJldmlvdXMiLCJlcnJvciIsInBvc2l0aW9uIiwidiIsInRvcCIsInJpZ2h0IiwiYmFja2dyb3VuZCIsImNvbG9yIiwiYm9yZGVyUmFkaXVzIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwibGluZUhlaWdodCIsInBhZGRpbmciLCJtaW5XaWR0aCIsInRleHRBbGlnbiIsIndpZHRoIiwibWF4SGVpZ2h0Iiwib3ZlcmZsb3dZIiwiYm9yZGVyIiwiYm94U2hhZG93IiwiekluZGV4IiwibWFyZ2luIiwiYm9yZGVyTGVmdCIsIm1hcmdpbkJvdHRvbSIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImdhcCIsIm1lc3NhZ2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJJRm9vZEFsZXJ0c0JlbGwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7XHJcbiAgYWNrbm93bGVkZ2VJRm9vZE9wZXJhdGlvbmFsQWxlcnQsXHJcbiAgZ2V0SUZvb2RPcGVyYXRpb25hbEFsZXJ0cyxcclxuICB0eXBlIElGb29kT3BlcmF0aW9uYWxBbGVydCxcclxufSBmcm9tIFwiLi4vZmVhdHVyZXMvaW50ZWdyYXRpb25zL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi91aS9Ub2FzdFwiO1xyXG5cclxuY29uc3QgUE9MTF9JTlRFUlZBTF9NUyA9IDMwXzAwMDtcclxuXHJcbmNvbnN0IFNFVkVSSVRZX0NPTE9SOiBSZWNvcmQ8SUZvb2RPcGVyYXRpb25hbEFsZXJ0W1wic2V2ZXJpdHlcIl0sIHN0cmluZz4gPSB7XHJcbiAgSW5mbzogXCJ2YXIoLS1pbmZvLCAjM2I4MmY2KVwiLFxyXG4gIFdhcm5pbmc6IFwidmFyKC0td2FybiwgI2Q5NzcwNilcIixcclxuICBDcml0aWNhbDogXCJ2YXIoLS1kYW5nZXIsICNkYzI2MjYpXCIsXHJcbn07XHJcblxyXG5jb25zdCBTRVZFUklUWV9JQ09OOiBSZWNvcmQ8SUZvb2RPcGVyYXRpb25hbEFsZXJ0W1wic2V2ZXJpdHlcIl0sIHN0cmluZz4gPSB7XHJcbiAgSW5mbzogXCLwn5S1XCIsXHJcbiAgV2FybmluZzogXCLwn5+gXCIsXHJcbiAgQ3JpdGljYWw6IFwi8J+UtFwiLFxyXG59O1xyXG5cclxuLy8gTWVzbWEgdMOpY25pY2EgZGUgYXZpc28gc29ub3JvIGRhIEZhc2UgMTIgKElGb29kT3JkZXJzUGFnZSDigJQgcGVkaWRvIG5vdm8pLCBtYXMgY29tIHVtIMO6bmljbyB0b21cclxuLy8gZ3JhdmUgcHJhIG7Do28gc2VyIGNvbmZ1bmRpZG8gY29tIFwiY2hlZ291IHBlZGlkbyBub3ZvXCI6IGFsZXJ0YSBvcGVyYWNpb25hbCAobG9qYSBjYWl1IGRvIGlGb29kKVxyXG4vLyDDqSBvdXRyYSBjYXRlZ29yaWEgZGUgdXJnw6puY2lhLiBTZW0gZGVwZW5kZXIgZGUgYXJxdWl2byBkZSDDoXVkaW8gZXh0ZXJubzsgZmFsaGEgc2lsZW5jaW9zYW1lbnRlXHJcbi8vIHNlIG8gbmF2ZWdhZG9yIGJsb3F1ZWFyIMOhdWRpbyBhbnRlcyBkZSBxdWFscXVlciBpbnRlcmHDp8OjbyBkbyB1c3XDoXJpbyDigJQgbyB0b2FzdCB2aXN1YWwgY29udGludWFcclxuLy8gYXZpc2FuZG8gZGUgcXVhbHF1ZXIgZm9ybWEuXHJcbmZ1bmN0aW9uIHBsYXlBbGVydENoaW1lKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBBdWRpb0N0eEN0b3IgPVxyXG4gICAgICB3aW5kb3cuQXVkaW9Db250ZXh0ID8/ICh3aW5kb3cgYXMgdW5rbm93biBhcyB7IHdlYmtpdEF1ZGlvQ29udGV4dD86IHR5cGVvZiBBdWRpb0NvbnRleHQgfSkud2Via2l0QXVkaW9Db250ZXh0O1xyXG4gICAgaWYgKCFBdWRpb0N0eEN0b3IpIHJldHVybjtcclxuICAgIGNvbnN0IGN0eCA9IG5ldyBBdWRpb0N0eEN0b3IoKTtcclxuICAgIGNvbnN0IG9zY2lsbGF0b3IgPSBjdHguY3JlYXRlT3NjaWxsYXRvcigpO1xyXG4gICAgY29uc3QgZ2FpbiA9IGN0eC5jcmVhdGVHYWluKCk7XHJcbiAgICBvc2NpbGxhdG9yLnR5cGUgPSBcInNxdWFyZVwiO1xyXG4gICAgb3NjaWxsYXRvci5mcmVxdWVuY3kudmFsdWUgPSA0NDA7XHJcbiAgICBjb25zdCBub3cgPSBjdHguY3VycmVudFRpbWU7XHJcbiAgICBnYWluLmdhaW4uc2V0VmFsdWVBdFRpbWUoMC4wMDAxLCBub3cpO1xyXG4gICAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4yNSwgbm93ICsgMC4wMik7XHJcbiAgICBnYWluLmdhaW4uZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgwLjAwMDEsIG5vdyArIDAuNSk7XHJcbiAgICBvc2NpbGxhdG9yLmNvbm5lY3QoZ2Fpbik7XHJcbiAgICBnYWluLmNvbm5lY3QoY3R4LmRlc3RpbmF0aW9uKTtcclxuICAgIG9zY2lsbGF0b3Iuc3RhcnQobm93KTtcclxuICAgIG9zY2lsbGF0b3Iuc3RvcChub3cgKyAwLjUpO1xyXG4gICAgc2V0VGltZW91dCgoKSA9PiB2b2lkIGN0eC5jbG9zZSgpLCA5MDApO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgLy8gQW1iaWVudGUgc2VtIHN1cG9ydGUgYSBXZWIgQXVkaW8sIG91IMOhdWRpbyBibG9xdWVhZG8g4oCUIHNlZ3VlIHPDsyBjb20gbyB0b2FzdCB2aXN1YWwuXHJcbiAgfVxyXG59XHJcblxyXG4vLy8gPHN1bW1hcnk+XHJcbi8vLyBTaW5vIGRlIGFsZXJ0YXMgb3BlcmFjaW9uYWlzIGRvIGlGb29kIChGYXNlIDEzKS4gSG9qZSBzw7MgcmVjZWJlIG9zIGF2aXNvcyBkbyB3YXRjaGVyIGRlXHJcbi8vLyBzdGF0dXMgZGUgbG9qYSAoSUZvb2RNZXJjaGFudFN0YXR1c1dhdGNoZXJCYWNrZ3JvdW5kU2VydmljZSDigJQgbG9qYSBjYWl1L3ZvbHRvdSBubyBpRm9vZCksIG1hc1xyXG4vLy8gYSBsaXN0YSB2ZW0gZGUgdW0gZW5kcG9pbnQgZ2Vuw6lyaWNvIChHRVQgaWZvb2QvYWxlcnRzL2NvbXBhbnkve2lkfSkgcXVlIHF1YWxxdWVyIG91dHJvIGpvYiBkZVxyXG4vLy8gZnVuZG8gZG8gbcOzZHVsbyBpRm9vZCBwb2RlIGFsaW1lbnRhciBubyBmdXR1cm8gc2VtIGV4aWdpciBtdWRhbsOnYSBuZXN0YSB0ZWxhLiBGaWNhIG5vIHRvcG8sXHJcbi8vLyBhbyBsYWRvIGRvcyBvdXRyb3MgYm90w7VlcyBvcGVyYWNpb25haXMsIGUgc8OzIGFwYXJlY2UgcHJhIHF1ZW0gasOhIGVueGVyZ2EgQ29uZmlnLi9pRm9vZFxyXG4vLy8gKG1lc21vIGdhdGUgZGUgYWNlc3NvIOKAlCBhZG1pbmlzdHJhIGEgZW1wcmVzYSkuXHJcbi8vLyA8L3N1bW1hcnk+XHJcbmV4cG9ydCBmdW5jdGlvbiBJRm9vZEFsZXJ0c0JlbGwoeyBjb21wYW55SWQgfTogeyBjb21wYW55SWQ6IG51bWJlciB8IG51bGwgfSkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGNvbnRhaW5lclJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XHJcbiAgY29uc3Qga25vd25BbGVydElkc1JlZiA9IHVzZVJlZjxTZXQ8c3RyaW5nPiB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IGxhc3RDb21wYW55SWRSZWYgPSB1c2VSZWY8bnVtYmVyIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IGFsZXJ0c1F1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwiYWxlcnRzXCIsIGNvbXBhbnlJZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJRm9vZE9wZXJhdGlvbmFsQWxlcnRzKGNvbXBhbnlJZCBhcyBudW1iZXIpLFxyXG4gICAgZW5hYmxlZDogY29tcGFueUlkICE9IG51bGwsXHJcbiAgICByZWZldGNoSW50ZXJ2YWw6IFBPTExfSU5URVJWQUxfTVMsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGFsZXJ0cyA9IGFsZXJ0c1F1ZXJ5LmRhdGEgPz8gW107XHJcblxyXG4gIC8vIE1lc21vIHBhZHLDo28gZGUgZGV0ZWPDp8OjbyBkZSBcIm5vdmlkYWRlXCIgZGEgRmFzZSAxMiAocGVkaWRvIG5vdm8pOiBjb21wYXJhIGNvbnRyYSBvIHNuYXBzaG90XHJcbiAgLy8gYW50ZXJpb3IgZGUgSURzLCBlIG8gcHJpbWVpcm8gY2FycmVnYW1lbnRvIHPDsyBncmF2YSBhIGJhc2VsaW5lIHNlbSBzb2FyIGFsYXJtZSDigJQgc2Vuw6NvIHRvZG9cclxuICAvLyBhbGVydGEgcXVlIGrDoSBlc3RhdmEgcGVuZGVudGUgYW50ZXMgZGUgYWJyaXIgYSB0ZWxhIHZpcmFyaWEgdW0gXCJhbGVydGEgbm92b1wiIGJhcnVsaGVudG8uXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghYWxlcnRzUXVlcnkuZGF0YSkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGN1cnJlbnRJZHMgPSBuZXcgU2V0KGFsZXJ0c1F1ZXJ5LmRhdGEubWFwKChhKSA9PiBhLmlkKSk7XHJcblxyXG4gICAgLy8gQ29ycmXDp8OjbyBww7NzLXJldmlzw6NvIChDb2RlUmFiYml0LCBQUiAjNCk6IHJlc2V0YSBhIGJhc2VsaW5lIHF1YW5kbyBhIGVtcHJlc2Egc2VsZWNpb25hZGFcclxuICAgIC8vIG11ZGEuIFNlbSBpc3NvLCBvIHByaW1laXJvIGNhcnJlZ2FtZW50byBkZSBhbGVydGFzIGRhIGVtcHJlc2EgTk9WQSBjb21wYXJhdmEgY29udHJhIG9cclxuICAgIC8vIHNuYXBzaG90IGRlIElEcyBkYSBlbXByZXNhIEFOVEVSSU9SIOKAlCB0b2RvIGFsZXJ0YSBxdWUgasOhIGV4aXN0aWEgKHPDsyBxdWUgZGUgb3V0cmEgZW1wcmVzYSxcclxuICAgIC8vIG51bmNhIHZpc3RvIHBvciBlc3RlIGNvbXBvbmVudGUpIHZpcmF2YSB1bSBcImFsZXJ0YSBub3ZvXCIgYmFydWxoZW50byAoYmlwZSArIHRvYXN0KS5cclxuICAgIGlmIChsYXN0Q29tcGFueUlkUmVmLmN1cnJlbnQgIT09IGNvbXBhbnlJZCkge1xyXG4gICAgICBsYXN0Q29tcGFueUlkUmVmLmN1cnJlbnQgPSBjb21wYW55SWQ7XHJcbiAgICAgIGtub3duQWxlcnRJZHNSZWYuY3VycmVudCA9IGN1cnJlbnRJZHM7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoa25vd25BbGVydElkc1JlZi5jdXJyZW50ID09PSBudWxsKSB7XHJcbiAgICAgIGtub3duQWxlcnRJZHNSZWYuY3VycmVudCA9IGN1cnJlbnRJZHM7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBwcmV2aW91c2x5S25vd24gPSBrbm93bkFsZXJ0SWRzUmVmLmN1cnJlbnQ7XHJcbiAgICBjb25zdCBuZXdBbGVydHMgPSBhbGVydHNRdWVyeS5kYXRhLmZpbHRlcigoYSkgPT4gIXByZXZpb3VzbHlLbm93bi5oYXMoYS5pZCkpO1xyXG4gICAga25vd25BbGVydElkc1JlZi5jdXJyZW50ID0gY3VycmVudElkcztcclxuXHJcbiAgICBpZiAobmV3QWxlcnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG5cclxuICAgIHBsYXlBbGVydENoaW1lKCk7XHJcbiAgICBmb3IgKGNvbnN0IGFsZXJ0IG9mIG5ld0FsZXJ0cykge1xyXG4gICAgICBjb25zdCBpY29uID0gU0VWRVJJVFlfSUNPTlthbGVydC5zZXZlcml0eV07XHJcbiAgICAgIHRvYXN0LmluZm8oYCR7aWNvbn0gJHthbGVydC50aXRsZX0g4oCUICR7YWxlcnQuYnJhbmNoTmFtZX1gKTtcclxuICAgIH1cclxuICB9LCBbYWxlcnRzUXVlcnkuZGF0YSwgdG9hc3QsIGNvbXBhbnlJZF0pO1xyXG5cclxuICAvLyBGZWNoYSBvIGRyb3Bkb3duIGFvIGNsaWNhciBmb3JhIGRlbGUuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghb3BlbikgcmV0dXJuO1xyXG4gICAgY29uc3QgaGFuZGxlQ2xpY2tPdXRzaWRlID0gKGV2ZW50OiBNb3VzZUV2ZW50KSA9PiB7XHJcbiAgICAgIGlmIChjb250YWluZXJSZWYuY3VycmVudCAmJiAhY29udGFpbmVyUmVmLmN1cnJlbnQuY29udGFpbnMoZXZlbnQudGFyZ2V0IGFzIE5vZGUpKSB7XHJcbiAgICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwibW91c2Vkb3duXCIsIGhhbmRsZUNsaWNrT3V0c2lkZSk7XHJcbiAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1vdXNlZG93blwiLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gIH0sIFtvcGVuXSk7XHJcblxyXG4gIGlmIChjb21wYW55SWQgPT0gbnVsbCkgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFja25vd2xlZGdlID0gYXN5bmMgKGFsZXJ0SWQ6IHN0cmluZykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYWNrbm93bGVkZ2VJRm9vZE9wZXJhdGlvbmFsQWxlcnQoY29tcGFueUlkLCBhbGVydElkKTtcclxuICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhPElGb29kT3BlcmF0aW9uYWxBbGVydFtdPihcclxuICAgICAgICBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImFsZXJ0c1wiLCBjb21wYW55SWRdLFxyXG4gICAgICAgIChwcmV2aW91cykgPT4gKHByZXZpb3VzID8/IFtdKS5maWx0ZXIoKGEpID0+IGEuaWQgIT09IGFsZXJ0SWQpLFxyXG4gICAgICApO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHRvYXN0LmVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIG1hcmNhciBvIGFsZXJ0YSBjb21vIHZpc3RvLlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiByZWY9e2NvbnRhaW5lclJlZn0gc3R5bGU9e3sgcG9zaXRpb246IFwicmVsYXRpdmVcIiB9fT5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdCBidG4taWNvblwiXHJcbiAgICAgICAgYXJpYS1sYWJlbD17YWxlcnRzLmxlbmd0aCA+IDAgPyBgJHthbGVydHMubGVuZ3RofSBhbGVydGFzIGRvIGlGb29kYCA6IFwiQWxlcnRhcyBkbyBpRm9vZFwifVxyXG4gICAgICAgIHRpdGxlPVwiQWxlcnRhcyBvcGVyYWNpb25haXMgZG8gaUZvb2RcIlxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oKHYpID0+ICF2KX1cclxuICAgICAgICBzdHlsZT17eyBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiIH19XHJcbiAgICAgID5cclxuICAgICAgICDwn5SUXHJcbiAgICAgICAge2FsZXJ0cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcclxuICAgICAgICAgICAgICB0b3A6IC00LFxyXG4gICAgICAgICAgICAgIHJpZ2h0OiAtNCxcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLWRhbmdlciwgI2RjMjYyNilcIixcclxuICAgICAgICAgICAgICBjb2xvcjogXCIjZmZmXCIsXHJcbiAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjk5OXB4XCIsXHJcbiAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC42NXJlbVwiLFxyXG4gICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDcwMCxcclxuICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiAxLFxyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IFwiM3B4IDVweFwiLFxyXG4gICAgICAgICAgICAgIG1pbldpZHRoOiAxNixcclxuICAgICAgICAgICAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHthbGVydHMubGVuZ3RoID4gOSA/IFwiOStcIiA6IGFsZXJ0cy5sZW5ndGh9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICB7b3BlbiAmJiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcclxuICAgICAgICAgICAgdG9wOiBcImNhbGMoMTAwJSArIDhweClcIixcclxuICAgICAgICAgICAgcmlnaHQ6IDAsXHJcbiAgICAgICAgICAgIHdpZHRoOiAzNDAsXHJcbiAgICAgICAgICAgIG1heEhlaWdodDogNDIwLFxyXG4gICAgICAgICAgICBvdmVyZmxvd1k6IFwiYXV0b1wiLFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLXN1cmZhY2UsIHZhcigtLXBhbmVsLWJnLCAjMWUxZTFlKSlcIixcclxuICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIsICNkMGQwZDApXCIsXHJcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogMTAsXHJcbiAgICAgICAgICAgIGJveFNoYWRvdzogXCIwIDhweCAyNHB4IHJnYmEoMCwwLDAsMC4xOClcIixcclxuICAgICAgICAgICAgekluZGV4OiAxMDAwLFxyXG4gICAgICAgICAgICBwYWRkaW5nOiBhbGVydHMubGVuZ3RoID09PSAwID8gMTYgOiA2LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7YWxlcnRzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luOiAwLCBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT5cclxuICAgICAgICAgICAgICBOZW5odW0gYWxlcnRhIG9wZXJhY2lvbmFsIGRvIGlGb29kIG5vIG1vbWVudG8uXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIGFsZXJ0cy5tYXAoKGFsZXJ0KSA9PiAoXHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAga2V5PXthbGVydC5pZH1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMTBweCAxMHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlckxlZnQ6IGAzcHggc29saWQgJHtTRVZFUklUWV9DT0xPUlthbGVydC5zZXZlcml0eV19YCxcclxuICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA2LFxyXG4gICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IDQsXHJcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwidmFyKC0tc3VyZmFjZS1yYWlzZWQsIHJnYmEoMCwwLDAsMC4wMykpXCIsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT57YWxlcnQudGl0bGV9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMnB4IDhweFwiLCBmb250U2l6ZTogXCIwLjc1cmVtXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGhhbmRsZUFja25vd2xlZGdlKGFsZXJ0LmlkKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIE9LXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBtYXJnaW46IFwiNHB4IDAgMFwiLCBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT57YWxlcnQubWVzc2FnZX08L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkpXHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9JRm9vZEFsZXJ0c0JlbGwudHN4In0=