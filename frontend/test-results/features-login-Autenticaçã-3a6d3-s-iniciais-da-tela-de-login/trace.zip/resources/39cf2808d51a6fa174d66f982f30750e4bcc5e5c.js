import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cash/CashDrawer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { useDialog } from "/src/ui/Dialog.tsx";
import {
  closeCashSession,
  getCashSummary,
  getOpenSession,
  openCashSession,
  registerCashMovement
} from "/src/features/cash/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { getPrintSettings, printCashClosing } from "/src/features/printing/api.ts";
import { getSalesBySession, refundSale } from "/src/features/billing/api.ts";
import { useMyFeatures } from "/src/features/access/hooks.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import {
  CashMovementType,
  DEFAULT_CASH_REGISTER_ID,
  PaymentMethod,
  formatBRL,
  paymentMethodLabel
} from "/src/lib/types.ts";
import { Overlay } from "/src/features/orders/Overlay.tsx";
const parseAmount = (raw) => {
  const value = Number(raw.replace(",", "."));
  return Number.isFinite(value) ? value : 0;
};
const RECONCILE_METHODS = [PaymentMethod.CartaoCredito, PaymentMethod.CartaoDebito, PaymentMethod.Pix];
const getDifferenceState = (differenceAmount) => {
  if (differenceAmount === 0) return { label: "Conferido — sem diferença", color: "var(--ok)" };
  if (differenceAmount > 0) return { label: "Sobra", color: "var(--amber)" };
  return { label: "Falta", color: "var(--danger)" };
};
export function CashDrawer({ onClose }) {
  _s();
  const queryClient = useQueryClient();
  const dialog = useDialog();
  const { employeeId } = useAuthStore();
  const [openingAmount, setOpeningAmount] = useState("");
  const [movementType, setMovementType] = useState(CashMovementType.Suprimento);
  const [movementAmount, setMovementAmount] = useState("");
  const [movementDescription, setMovementDescription] = useState("");
  const [countedAmount, setCountedAmount] = useState("");
  const [cardCounts, setCardCounts] = useState({});
  const [closeResult, setCloseResult] = useState(null);
  const [error, setError] = useState(null);
  const printSettingsQuery = useQuery({
    queryKey: ["printing", "settings", DEFAULT_CASH_REGISTER_ID],
    queryFn: () => getPrintSettings(useAuthStore.getState().branchId),
    staleTime: 6e4
  });
  const printClosingMutation = useMutation({
    mutationFn: (sessionIdToPrint) => printCashClosing(sessionIdToPrint),
    onError: (e) => onApiError(e, "Falha ao imprimir o fechamento.")
  });
  const sessionQuery = useQuery({
    queryKey: ["cash", "open", DEFAULT_CASH_REGISTER_ID],
    queryFn: () => getOpenSession(DEFAULT_CASH_REGISTER_ID),
    retry: false
  });
  const sessionId = sessionQuery.data?.id;
  const featuresQuery = useMyFeatures();
  const salesQuery = useQuery({
    queryKey: ["cash", "sales", sessionId],
    queryFn: () => getSalesBySession(sessionId),
    enabled: sessionId !== void 0,
    refetchInterval: 3e4
  });
  const refundMutation = useMutation({
    mutationFn: ({ saleId, reason }) => refundSale(saleId, useAuthStore.getState().employeeId ?? 1, reason),
    onSuccess: () => {
      setError(null);
      invalidateCash();
      void queryClient.invalidateQueries({ queryKey: ["orders"] });
      void queryClient.invalidateQueries({ queryKey: ["tables"] });
    },
    onError: (e) => onApiError(e, "Falha ao estornar a venda.")
  });
  const summaryQuery = useQuery({
    queryKey: ["cash", "summary", sessionId],
    queryFn: () => getCashSummary(sessionId),
    enabled: sessionId !== void 0,
    refetchInterval: 2e4
  });
  const noSession = sessionQuery.isError && sessionQuery.error instanceof ApiError && sessionQuery.error.status === 404;
  const invalidateCash = () => void queryClient.invalidateQueries({ queryKey: ["cash"] });
  const onApiError = (e, fallback) => setError(e instanceof ApiError ? e.message : fallback);
  const openMutation = useMutation({
    mutationFn: () => openCashSession(DEFAULT_CASH_REGISTER_ID, employeeId ?? 1, parseAmount(openingAmount)),
    onSuccess: () => {
      setError(null);
      invalidateCash();
    },
    onError: (e) => onApiError(e, "Falha ao abrir o caixa.")
  });
  const movementMutation = useMutation({
    mutationFn: () => registerCashMovement(
      sessionId,
      movementType,
      employeeId ?? 1,
      parseAmount(movementAmount),
      movementDescription.trim() === "" ? null : movementDescription.trim()
    ),
    onSuccess: () => {
      setError(null);
      setMovementAmount("");
      setMovementDescription("");
      invalidateCash();
    },
    onError: (e) => onApiError(e, "Falha ao registrar movimento.")
  });
  const closeMutation = useMutation({
    mutationFn: () => closeCashSession(sessionId, employeeId ?? 1, parseAmount(countedAmount)),
    onSuccess: (result) => {
      setError(null);
      setCloseResult(result);
      invalidateCash();
    },
    onError: (e) => onApiError(e, "Falha ao fechar o caixa.")
  });
  const summary = summaryQuery.data;
  const differenceState = getDifferenceState(closeResult?.differenceAmount ?? 0);
  return /* @__PURE__ */ jsxDEV(Overlay, { title: "Caixa 01", onClose, wide: true, children: [
    sessionQuery.isLoading && /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)" }, children: "Carregando…" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
      lineNumber: 184,
      columnNumber: 34
    }, this),
    closeResult && /* @__PURE__ */ jsxDEV("div", { className: "ticket", style: { padding: 18, display: "grid", gap: 8 }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "display", style: { fontSize: "1.3rem" }, children: "Caixa fechado" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
        lineNumber: 188,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", color: "var(--ink-dim)" }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Esperado em dinheiro" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 190,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(closeResult.expectedAmount) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 191,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
        lineNumber: 189,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", color: "var(--ink-dim)" }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Contado" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 194,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(closeResult.closingAmount) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 195,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
        lineNumber: 193,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          style: {
            display: "flex",
            justifyContent: "space-between",
            fontWeight: 700,
            color: differenceState.color
          },
          children: [
            /* @__PURE__ */ jsxDEV("span", { children: differenceState.label }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 205,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(Math.abs(closeResult.differenceAmount)) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 206,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 197,
          columnNumber: 11
        },
        this
      ),
      printSettingsQuery.data?.printBillsEnabled && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          disabled: printClosingMutation.isPending,
          onClick: () => printClosingMutation.mutate(closeResult.cashSessionId),
          children: printClosingMutation.isPending ? "Imprimindo…" : "🖨 Imprimir fechamento"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 209,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
      lineNumber: 187,
      columnNumber: 7
    }, this),
    !closeResult && noSession && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--ink-dim)" }, children: "Nenhuma sessão aberta neste caixa." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
        lineNumber: 223,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          placeholder: "Fundo de troco (R$)",
          inputMode: "decimal",
          value: openingAmount,
          onChange: (e) => setOpeningAmount(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 224,
          columnNumber: 11
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
        lineNumber: 230,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "btn-primary",
          disabled: openMutation.isPending,
          onClick: () => openMutation.mutate(),
          children: "Abrir caixa"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 231,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
      lineNumber: 222,
      columnNumber: 7
    }, this),
    !closeResult && sessionId !== void 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem" }, children: "Resumo da sessão" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 246,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: [
            "#",
            sessionId
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 247,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 245,
          columnNumber: 13
        }, this),
        summary && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-dim)" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Fundo de troco" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 254,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(summary.openingAmount) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 255,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 253,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-dim)" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              "Vendas (",
              summary.salesCount,
              ")"
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 258,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(summary.salesTotal) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 259,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 257,
            columnNumber: 17
          }, this),
          summary.paymentTotals.map(
            (total) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
              /* @__PURE__ */ jsxDEV("span", { children: paymentMethodLabel[total.paymentMethodId] ?? "Outros" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                lineNumber: 263,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: formatBRL(total.totalAmount) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                lineNumber: 264,
                columnNumber: 21
              }, this)
            ] }, total.paymentMethodId, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 262,
              columnNumber: 13
            }, this)
          ),
          summary.partialPaymentsTotal > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ok)" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Pagamentos parciais (mesas abertas)" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 269,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: [
              "+ ",
              formatBRL(summary.partialPaymentsTotal)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 270,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 268,
            columnNumber: 13
          }, this),
          summary.suprimentoTotal > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ok)" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Suprimentos" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 275,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: [
              "+ ",
              formatBRL(summary.suprimentoTotal)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 276,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 274,
            columnNumber: 13
          }, this),
          summary.sangriaTotal > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--closing)" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Sangrias" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 281,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: [
              "− ",
              formatBRL(summary.sangriaTotal)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 282,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 280,
            columnNumber: 13
          }, this),
          summary.despesaTotal > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--closing)" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Despesas" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 287,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: [
              "− ",
              formatBRL(summary.despesaTotal)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 288,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 286,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ticket-total", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Esperado em dinheiro" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 292,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--amber)" }, children: formatBRL(summary.expectedCashAmount) }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 293,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 291,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 252,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
        lineNumber: 244,
        columnNumber: 11
      }, this),
      (salesQuery.data ?? []).length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.1rem" }, children: "Vendas da sessão" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 304,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 303,
          columnNumber: 15
        }, this),
        (salesQuery.data ?? []).map(
          (sale) => /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 2 }, children: [
              /* @__PURE__ */ jsxDEV("span", { className: "mono-num", children: [
                "Venda #",
                sale.saleNumber,
                " · pedido #",
                sale.customerOrderId,
                " · ",
                formatBRL(sale.totalAmount)
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                lineNumber: 309,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.78rem", color: "var(--ink-faint)" }, children: new Date(sale.soldAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }) }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                lineNumber: 312,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 308,
              columnNumber: 19
            }, this),
            featuresQuery.data?.canManageAccess && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "btn-danger",
                style: { minHeight: 44, padding: "0 10px", fontSize: "0.82rem" },
                disabled: refundMutation.isPending,
                onClick: async () => {
                  const reason = await dialog.prompt({
                    title: "Estornar venda",
                    message: `Estornar a venda #${sale.saleNumber} (${formatBRL(sale.totalAmount)})?`,
                    label: "Motivo (opcional)",
                    confirmLabel: "Estornar"
                  });
                  if (reason !== null)
                    refundMutation.mutate({ saleId: sale.id, reason: reason.trim() === "" ? null : reason.trim() });
                },
                children: "Estornar"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                lineNumber: 317,
                columnNumber: 13
              },
              this
            )
          ] }, sale.id, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 307,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
        lineNumber: 302,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "display", style: { fontSize: "1.1rem" }, children: "Sangria / Suprimento" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 342,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8, gridTemplateColumns: "1fr 1fr" }, children: [
          /* @__PURE__ */ jsxDEV("select", { value: movementType, onChange: (e) => setMovementType(Number(e.target.value)), children: [
            /* @__PURE__ */ jsxDEV("option", { value: CashMovementType.Suprimento, children: "Suprimento (entrada)" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 345,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: CashMovementType.Sangria, children: "Sangria (retirada)" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 346,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: CashMovementType.Despesa, children: "Despesa" }, void 0, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 347,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 344,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              placeholder: "Valor (R$)",
              inputMode: "decimal",
              value: movementAmount,
              onChange: (e) => setMovementAmount(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
              lineNumber: 349,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 343,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            placeholder: "Descrição (opcional)",
            value: movementDescription,
            onChange: (e) => setMovementDescription(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 356,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "btn-ghost",
            disabled: parseAmount(movementAmount) <= 0 || movementMutation.isPending,
            onClick: () => movementMutation.mutate(),
            children: "Registrar movimento"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 361,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
        lineNumber: 341,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8 }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "display", style: { fontSize: "1.1rem" }, children: "Fechar caixa" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 372,
          columnNumber: 13
        }, this),
        summary && /* @__PURE__ */ jsxDEV("div", { className: "ticket", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ticket-head", children: /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--ink-dim)" }, children: "Conferência por forma de pagamento" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 377,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 376,
            columnNumber: 17
          }, this),
          RECONCILE_METHODS.map((methodId) => {
            const expected = summary.paymentTotals.find((t) => t.paymentMethodId === methodId)?.totalAmount ?? 0;
            const countedRaw = cardCounts[methodId] ?? "";
            const hasCounted = countedRaw.trim() !== "";
            const diff = parseAmount(countedRaw) - expected;
            return /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "ticket-row",
                style: { flexDirection: "column", alignItems: "stretch", gap: 6 },
                children: [
                  /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", width: "100%" }, children: [
                    /* @__PURE__ */ jsxDEV("span", { children: paymentMethodLabel[methodId] }, void 0, false, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                      lineNumber: 394,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--ink-dim)" }, children: [
                      "Esperado ",
                      formatBRL(expected)
                    ] }, void 0, true, {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                      lineNumber: 395,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                    lineNumber: 393,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, alignItems: "center" }, children: [
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        placeholder: "Conferido (R$)",
                        inputMode: "decimal",
                        value: countedRaw,
                        onChange: (e) => setCardCounts((c) => ({ ...c, [methodId]: e.target.value })),
                        style: { flex: 1 }
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                        lineNumber: 400,
                        columnNumber: 25
                      },
                      this
                    ),
                    hasCounted && /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: "mono-num",
                        style: {
                          fontSize: "0.85rem",
                          minWidth: 96,
                          textAlign: "right",
                          color: diff === 0 ? "var(--ok)" : diff > 0 ? "var(--amber)" : "var(--danger)"
                        },
                        children: diff === 0 ? "Confere" : diff > 0 ? `+ ${formatBRL(diff)}` : `− ${formatBRL(Math.abs(diff))}`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                        lineNumber: 408,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                    lineNumber: 399,
                    columnNumber: 23
                  }, this)
                ]
              },
              methodId,
              true,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
                lineNumber: 388,
                columnNumber: 17
              },
              this
            );
          }),
          /* @__PURE__ */ jsxDEV("p", { style: { padding: "8px 18px 12px", margin: 0, fontSize: "0.78rem", color: "var(--ink-faint)" }, children: "Só o Dinheiro abaixo é enviado ao fechar o caixa — Crédito/Débito/Pix aqui são conferência visual (o valor esperado já vem das vendas da sessão) e não alteram o fechamento." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 424,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 375,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            placeholder: "Dinheiro contado na gaveta (R$)",
            inputMode: "decimal",
            value: countedAmount,
            onChange: (e) => setCountedAmount(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 431,
            columnNumber: 13
          },
          this
        ),
        error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
          lineNumber: 437,
          columnNumber: 23
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "btn-danger",
            disabled: countedAmount.trim() === "" || closeMutation.isPending,
            onClick: async () => {
              if (await dialog.confirm({
                title: "Fechar caixa",
                message: "Fechar o caixa? Pedidos aguardando pagamento não poderão ser recebidos.",
                confirmLabel: "Fechar caixa",
                danger: true
              }))
                closeMutation.mutate();
            },
            children: closeMutation.isPending ? "Fechando…" : "Fechar caixa e conferir"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
            lineNumber: 438,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
        lineNumber: 371,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
      lineNumber: 243,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx",
    lineNumber: 183,
    columnNumber: 5
  }, this);
}
_s(CashDrawer, "fjKXZnbmRsWpNnFmqJ3CGyAxFkA=", false, function() {
  return [useQueryClient, useDialog, useAuthStore, useQuery, useMutation, useQuery, useMyFeatures, useQuery, useMutation, useQuery, useMutation, useMutation, useMutation];
});
_c = CashDrawer;
var _c;
$RefreshReg$(_c, "CashDrawer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashDrawer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0tpQyxTQW9FbkIsVUFwRW1COzs7Ozs7Ozs7Ozs7Ozs7OztBQXBLakMsU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLGFBQWFDLFVBQVVDLHNCQUFzQjtBQUN0RCxTQUFTQyxpQkFBaUI7QUFDMUI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGtCQUFrQkMsd0JBQXdCO0FBQ25ELFNBQVNDLG1CQUFtQkMsa0JBQWtCO0FBQzlDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxnQkFBZ0I7QUFDekI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRVAsU0FBU0MsZUFBZTtBQU14QixNQUFNQyxjQUFjQSxDQUFDQyxRQUF3QjtBQUMzQyxRQUFNQyxRQUFRQyxPQUFPRixJQUFJRyxRQUFRLEtBQUssR0FBRyxDQUFDO0FBQzFDLFNBQU9ELE9BQU9FLFNBQVNILEtBQUssSUFBSUEsUUFBUTtBQUMxQztBQU9BLE1BQU1JLG9CQUFvQixDQUFDVixjQUFjVyxlQUFlWCxjQUFjWSxjQUFjWixjQUFjYSxHQUFHO0FBT3JHLE1BQU1DLHFCQUFxQkEsQ0FBQ0MscUJBQThDO0FBQ3hFLE1BQUlBLHFCQUFxQixFQUFHLFFBQU8sRUFBRUMsT0FBTyw2QkFBNkJDLE9BQU8sWUFBWTtBQUM1RixNQUFJRixtQkFBbUIsRUFBRyxRQUFPLEVBQUVDLE9BQU8sU0FBU0MsT0FBTyxlQUFlO0FBQ3pFLFNBQU8sRUFBRUQsT0FBTyxTQUFTQyxPQUFPLGdCQUFnQjtBQUNsRDtBQUVPLGdCQUFTQyxXQUFXLEVBQUVDLFFBQWUsR0FBRztBQUFBQyxLQUFBO0FBQzdDLFFBQU1DLGNBQWNyQyxlQUFlO0FBQ25DLFFBQU1zQyxTQUFTckMsVUFBVTtBQUN6QixRQUFNLEVBQUVzQyxXQUFXLElBQUloQyxhQUFhO0FBQ3BDLFFBQU0sQ0FBQ2lDLGVBQWVDLGdCQUFnQixJQUFJNUMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzZDLGNBQWNDLGVBQWUsSUFBSTlDLFNBQWlCaUIsaUJBQWlCOEIsVUFBVTtBQUNwRixRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUlqRCxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDa0QscUJBQXFCQyxzQkFBc0IsSUFBSW5ELFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUNvRCxlQUFlQyxnQkFBZ0IsSUFBSXJELFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNzRCxZQUFZQyxhQUFhLElBQUl2RCxTQUFpQyxDQUFDLENBQUM7QUFDdkUsUUFBTSxDQUFDd0QsYUFBYUMsY0FBYyxJQUFJekQsU0FBMEMsSUFBSTtBQUNwRixRQUFNLENBQUMwRCxPQUFPQyxRQUFRLElBQUkzRCxTQUF3QixJQUFJO0FBRXRELFFBQU00RCxxQkFBcUIxRCxTQUFTO0FBQUEsSUFDbEMyRCxVQUFVLENBQUMsWUFBWSxZQUFZM0Msd0JBQXdCO0FBQUEsSUFDM0Q0QyxTQUFTQSxNQUFNbkQsaUJBQWlCRCxhQUFhcUQsU0FBUyxFQUFFQyxRQUFRO0FBQUEsSUFDaEVDLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNQyx1QkFBdUJqRSxZQUFZO0FBQUEsSUFDdkNrRSxZQUFZQSxDQUFDQyxxQkFBNkJ4RCxpQkFBaUJ3RCxnQkFBZ0I7QUFBQSxJQUMzRUMsU0FBU0EsQ0FBQ0MsTUFBTUMsV0FBV0QsR0FBRyxpQ0FBaUM7QUFBQSxFQUNqRSxDQUFDO0FBRUQsUUFBTUUsZUFBZXRFLFNBQVM7QUFBQSxJQUM1QjJELFVBQVUsQ0FBQyxRQUFRLFFBQVEzQyx3QkFBd0I7QUFBQSxJQUNuRDRDLFNBQVNBLE1BQU12RCxlQUFlVyx3QkFBd0I7QUFBQSxJQUN0RHVELE9BQU87QUFBQSxFQUNULENBQUM7QUFFRCxRQUFNQyxZQUFZRixhQUFhRyxNQUFNQztBQUNyQyxRQUFNQyxnQkFBZ0I5RCxjQUFjO0FBRXBDLFFBQU0rRCxhQUFhNUUsU0FBUztBQUFBLElBQzFCMkQsVUFBVSxDQUFDLFFBQVEsU0FBU2EsU0FBUztBQUFBLElBQ3JDWixTQUFTQSxNQUFNakQsa0JBQWtCNkQsU0FBVTtBQUFBLElBQzNDSyxTQUFTTCxjQUFjTTtBQUFBQSxJQUN2QkMsaUJBQWlCO0FBQUEsRUFDbkIsQ0FBQztBQUVELFFBQU1DLGlCQUFpQmpGLFlBQVk7QUFBQSxJQUNqQ2tFLFlBQVlBLENBQUMsRUFBRWdCLFFBQVFDLE9BQWtELE1BQ3ZFdEUsV0FBV3FFLFFBQVF6RSxhQUFhcUQsU0FBUyxFQUFFckIsY0FBYyxHQUFHMEMsTUFBTTtBQUFBLElBQ3BFQyxXQUFXQSxNQUFNO0FBQ2YxQixlQUFTLElBQUk7QUFDYjJCLHFCQUFlO0FBQ2YsV0FBSzlDLFlBQVkrQyxrQkFBa0IsRUFBRTFCLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMzRCxXQUFLckIsWUFBWStDLGtCQUFrQixFQUFFMUIsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQUEsSUFDN0Q7QUFBQSxJQUNBUSxTQUFTQSxDQUFDQyxNQUFNQyxXQUFXRCxHQUFHLDRCQUE0QjtBQUFBLEVBQzVELENBQUM7QUFFRCxRQUFNa0IsZUFBZXRGLFNBQVM7QUFBQSxJQUM1QjJELFVBQVUsQ0FBQyxRQUFRLFdBQVdhLFNBQVM7QUFBQSxJQUN2Q1osU0FBU0EsTUFBTXhELGVBQWVvRSxTQUFVO0FBQUEsSUFDeENLLFNBQVNMLGNBQWNNO0FBQUFBLElBQ3ZCQyxpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTVEsWUFDSmpCLGFBQWFrQixXQUNibEIsYUFBYWQsaUJBQWlCMUMsWUFDOUJ3RCxhQUFhZCxNQUFNaUMsV0FBVztBQUVoQyxRQUFNTCxpQkFBaUJBLE1BQU0sS0FBSzlDLFlBQVkrQyxrQkFBa0IsRUFBRTFCLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztBQUV0RixRQUFNVSxhQUFhQSxDQUFDRCxHQUFZc0IsYUFDOUJqQyxTQUFTVyxhQUFhdEQsV0FBV3NELEVBQUV1QixVQUFVRCxRQUFRO0FBRXZELFFBQU1FLGVBQWU3RixZQUFZO0FBQUEsSUFDL0JrRSxZQUFZQSxNQUNWM0QsZ0JBQWdCVSwwQkFBMEJ3QixjQUFjLEdBQUduQixZQUFZb0IsYUFBYSxDQUFDO0FBQUEsSUFDdkYwQyxXQUFXQSxNQUFNO0FBQ2YxQixlQUFTLElBQUk7QUFDYjJCLHFCQUFlO0FBQUEsSUFDakI7QUFBQSxJQUNBakIsU0FBU0EsQ0FBQ0MsTUFBTUMsV0FBV0QsR0FBRyx5QkFBeUI7QUFBQSxFQUN6RCxDQUFDO0FBRUQsUUFBTXlCLG1CQUFtQjlGLFlBQVk7QUFBQSxJQUNuQ2tFLFlBQVlBLE1BQ1YxRDtBQUFBQSxNQUNFaUU7QUFBQUEsTUFDQTdCO0FBQUFBLE1BQ0FILGNBQWM7QUFBQSxNQUNkbkIsWUFBWXlCLGNBQWM7QUFBQSxNQUMxQkUsb0JBQW9COEMsS0FBSyxNQUFNLEtBQUssT0FBTzlDLG9CQUFvQjhDLEtBQUs7QUFBQSxJQUN0RTtBQUFBLElBQ0ZYLFdBQVdBLE1BQU07QUFDZjFCLGVBQVMsSUFBSTtBQUNiVix3QkFBa0IsRUFBRTtBQUNwQkUsNkJBQXVCLEVBQUU7QUFDekJtQyxxQkFBZTtBQUFBLElBQ2pCO0FBQUEsSUFDQWpCLFNBQVNBLENBQUNDLE1BQU1DLFdBQVdELEdBQUcsK0JBQStCO0FBQUEsRUFDL0QsQ0FBQztBQUVELFFBQU0yQixnQkFBZ0JoRyxZQUFZO0FBQUEsSUFDaENrRSxZQUFZQSxNQUFNOUQsaUJBQWlCcUUsV0FBWWhDLGNBQWMsR0FBR25CLFlBQVk2QixhQUFhLENBQUM7QUFBQSxJQUMxRmlDLFdBQVdBLENBQUNhLFdBQVc7QUFDckJ2QyxlQUFTLElBQUk7QUFDYkYscUJBQWV5QyxNQUFNO0FBQ3JCWixxQkFBZTtBQUFBLElBQ2pCO0FBQUEsSUFDQWpCLFNBQVNBLENBQUNDLE1BQU1DLFdBQVdELEdBQUcsMEJBQTBCO0FBQUEsRUFDMUQsQ0FBQztBQUVELFFBQU02QixVQUFVWCxhQUFhYjtBQUM3QixRQUFNeUIsa0JBQWtCbkUsbUJBQW1CdUIsYUFBYXRCLG9CQUFvQixDQUFDO0FBRTdFLFNBQ0UsdUJBQUMsV0FBUSxPQUFNLFlBQVcsU0FBa0IsTUFBSSxNQUM3Q3NDO0FBQUFBLGlCQUFhNkIsYUFBYSx1QkFBQyxPQUFFLE9BQU8sRUFBRWpFLE9BQU8saUJBQWlCLEdBQUcsMkJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0Q7QUFBQSxJQUU1RW9CLGVBQ0MsdUJBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFOEMsU0FBUyxJQUFJQyxTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwRTtBQUFBLDZCQUFDLFNBQUksV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxTQUFTLEdBQUcsNkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUNyRSx1QkFBQyxTQUFJLE9BQU8sRUFBRUYsU0FBUyxRQUFRRyxnQkFBZ0IsaUJBQWlCdEUsT0FBTyxpQkFBaUIsR0FDdEY7QUFBQSwrQkFBQyxVQUFLLG9DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUMxQix1QkFBQyxVQUFLLFdBQVUsWUFBWWhCLG9CQUFVb0MsWUFBWW1ELGNBQWMsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFdBRnBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVKLFNBQVMsUUFBUUcsZ0JBQWdCLGlCQUFpQnRFLE9BQU8saUJBQWlCLEdBQ3RGO0FBQUEsK0JBQUMsVUFBSyx1QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxRQUNiLHVCQUFDLFVBQUssV0FBVSxZQUFZaEIsb0JBQVVvQyxZQUFZb0QsYUFBYSxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsV0FGbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTztBQUFBLFlBQ0xMLFNBQVM7QUFBQSxZQUNURyxnQkFBZ0I7QUFBQSxZQUNoQkcsWUFBWTtBQUFBLFlBQ1p6RSxPQUFPZ0UsZ0JBQWdCaEU7QUFBQUEsVUFDekI7QUFBQSxVQUVBO0FBQUEsbUNBQUMsVUFBTWdFLDBCQUFnQmpFLFNBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFDN0IsdUJBQUMsVUFBSyxXQUFVLFlBQVlmLG9CQUFVMEYsS0FBS0MsSUFBSXZELFlBQVl0QixnQkFBZ0IsQ0FBQyxLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RTtBQUFBO0FBQUE7QUFBQSxRQVRoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLE1BQ0MwQixtQkFBbUJlLE1BQU1xQyxxQkFDeEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFVBQVU5QyxxQkFBcUIrQztBQUFBQSxVQUMvQixTQUFTLE1BQU0vQyxxQkFBcUJnRCxPQUFPMUQsWUFBWTJELGFBQWE7QUFBQSxVQUVuRWpELCtCQUFxQitDLFlBQVksZ0JBQWdCO0FBQUE7QUFBQSxRQU5wRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErQkE7QUFBQSxJQUdELENBQUN6RCxlQUFlaUMsYUFDZix1QkFBQyxTQUFJLE9BQU8sRUFBRWMsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDckM7QUFBQSw2QkFBQyxPQUFFLE9BQU8sRUFBRXBFLE9BQU8saUJBQWlCLEdBQUcsa0RBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUN6RTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsYUFBWTtBQUFBLFVBQ1osV0FBVTtBQUFBLFVBQ1YsT0FBT087QUFBQUEsVUFDUCxVQUFVLENBQUMyQixNQUFNMUIsaUJBQWlCMEIsRUFBRThDLE9BQU8zRixLQUFLO0FBQUE7QUFBQSxRQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJb0Q7QUFBQSxNQUVuRGlDLFNBQVMsdUJBQUMsT0FBRSxXQUFVLGNBQWNBLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDM0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFVBQVVvQyxhQUFhbUI7QUFBQUEsVUFDdkIsU0FBUyxNQUFNbkIsYUFBYW9CLE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUp2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUdELENBQUMxRCxlQUFla0IsY0FBY00sVUFDN0IsbUNBQ0U7QUFBQSw2QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFeUIsVUFBVSxTQUFTLEdBQUcsZ0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsVUFDekUsdUJBQUMsVUFBSyxXQUFVLFlBQVcsT0FBTyxFQUFFckUsT0FBTyxvQkFBb0JxRSxVQUFVLFVBQVUsR0FBRztBQUFBO0FBQUEsWUFDbEYvQjtBQUFBQSxlQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0N5QixXQUNDLG1DQUNFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFL0QsT0FBTyxpQkFBaUIsR0FDM0Q7QUFBQSxtQ0FBQyxVQUFLLDhCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9CO0FBQUEsWUFDcEIsdUJBQUMsVUFBSyxXQUFVLFlBQVloQixvQkFBVStFLFFBQVF4RCxhQUFhLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsZUFGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFUCxPQUFPLGlCQUFpQixHQUMzRDtBQUFBLG1DQUFDLFVBQUs7QUFBQTtBQUFBLGNBQVMrRCxRQUFRa0I7QUFBQUEsY0FBVztBQUFBLGlCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQztBQUFBLFlBQ25DLHVCQUFDLFVBQUssV0FBVSxZQUFZakcsb0JBQVUrRSxRQUFRbUIsVUFBVSxLQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLGVBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNDbkIsUUFBUW9CLGNBQWNDO0FBQUFBLFlBQUksQ0FBQ0MsVUFDMUIsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxVQUFNcEcsNkJBQW1Cb0csTUFBTUMsZUFBZSxLQUFLLFlBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsY0FDN0QsdUJBQUMsVUFBSyxXQUFVLFlBQVl0RyxvQkFBVXFHLE1BQU1FLFdBQVcsS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxpQkFGMUJGLE1BQU1DLGlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsVUFDRDtBQUFBLFVBQ0F2QixRQUFReUIsdUJBQXVCLEtBQzlCLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRXhGLE9BQU8sWUFBWSxHQUN0RDtBQUFBLG1DQUFDLFVBQUssbURBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUN6Qyx1QkFBQyxVQUFLLFdBQVUsWUFBVztBQUFBO0FBQUEsY0FBR2hCLFVBQVUrRSxRQUFReUIsb0JBQW9CO0FBQUEsaUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsZUFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUR6QixRQUFRMEIsa0JBQWtCLEtBQ3pCLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRXpGLE9BQU8sWUFBWSxHQUN0RDtBQUFBLG1DQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQSxZQUNqQix1QkFBQyxVQUFLLFdBQVUsWUFBVztBQUFBO0FBQUEsY0FBR2hCLFVBQVUrRSxRQUFRMEIsZUFBZTtBQUFBLGlCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLGVBRm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVEMUIsUUFBUTJCLGVBQWUsS0FDdEIsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFMUYsT0FBTyxpQkFBaUIsR0FDM0Q7QUFBQSxtQ0FBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWM7QUFBQSxZQUNkLHVCQUFDLFVBQUssV0FBVSxZQUFXO0FBQUE7QUFBQSxjQUFHaEIsVUFBVStFLFFBQVEyQixZQUFZO0FBQUEsaUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThEO0FBQUEsZUFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUQzQixRQUFRNEIsZUFBZSxLQUN0Qix1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUUzRixPQUFPLGlCQUFpQixHQUMzRDtBQUFBLG1DQUFDLFVBQUssd0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYztBQUFBLFlBQ2QsdUJBQUMsVUFBSyxXQUFVLFlBQVc7QUFBQTtBQUFBLGNBQUdoQixVQUFVK0UsUUFBUTRCLFlBQVk7QUFBQSxpQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxlQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFRix1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxtQ0FBQyxVQUFLLG9DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBCO0FBQUEsWUFDMUIsdUJBQUMsVUFBSyxXQUFVLFlBQVcsT0FBTyxFQUFFM0YsT0FBTyxlQUFlLEdBQ3ZEaEIsb0JBQVUrRSxRQUFRNkIsa0JBQWtCLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkNBO0FBQUEsV0FyREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVEQTtBQUFBLE9BRUVsRCxXQUFXSCxRQUFRLElBQUlzRCxTQUFTLEtBQ2hDLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGVBQ2IsaUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFeEIsVUFBVSxTQUFTLEdBQUcsZ0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUUsS0FEM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsU0FDRTNCLFdBQVdILFFBQVEsSUFBSTZDO0FBQUFBLFVBQUksQ0FBQ1UsU0FDNUIsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRTNCLFNBQVMsUUFBUUMsS0FBSyxFQUFFLEdBQ3BDO0FBQUEscUNBQUMsVUFBSyxXQUFVLFlBQVc7QUFBQTtBQUFBLGdCQUNqQjBCLEtBQUtDO0FBQUFBLGdCQUFXO0FBQUEsZ0JBQVlELEtBQUtFO0FBQUFBLGdCQUFnQjtBQUFBLGdCQUFJaEgsVUFBVThHLEtBQUtQLFdBQVc7QUFBQSxtQkFEekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVsQixVQUFVLFdBQVdyRSxPQUFPLG1CQUFtQixHQUMzRCxjQUFJaUcsS0FBS0gsS0FBS0ksTUFBTSxFQUFFQyxtQkFBbUIsU0FBUyxFQUFFQyxNQUFNLFdBQVdDLFFBQVEsVUFBVSxDQUFDLEtBRDNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQzVELGNBQWNGLE1BQU0rRCxtQkFDbkI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRUMsV0FBVyxJQUFJckMsU0FBUyxVQUFVRyxVQUFVLFVBQVU7QUFBQSxnQkFDL0QsVUFBVXZCLGVBQWUrQjtBQUFBQSxnQkFDekIsU0FBUyxZQUFZO0FBQ25CLHdCQUFNN0IsU0FBUyxNQUFNM0MsT0FBT21HLE9BQU87QUFBQSxvQkFDakNDLE9BQU87QUFBQSxvQkFDUGhELFNBQVMscUJBQXFCcUMsS0FBS0MsVUFBVSxLQUFLL0csVUFBVThHLEtBQUtQLFdBQVcsQ0FBQztBQUFBLG9CQUM3RXhGLE9BQU87QUFBQSxvQkFDUDJHLGNBQWM7QUFBQSxrQkFDaEIsQ0FBQztBQUNELHNCQUFJMUQsV0FBVztBQUNiRixtQ0FBZWdDLE9BQU8sRUFBRS9CLFFBQVErQyxLQUFLdEQsSUFBSVEsUUFBUUEsT0FBT1ksS0FBSyxNQUFNLEtBQUssT0FBT1osT0FBT1ksS0FBSyxFQUFFLENBQUM7QUFBQSxnQkFDbEc7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFpQkE7QUFBQSxlQTNCNkJrQyxLQUFLdEQsSUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxRQUNEO0FBQUEsV0FuQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9DQTtBQUFBLE1BR0YsdUJBQUMsU0FBSSxPQUFPLEVBQUUyQixTQUFTLFFBQVFDLEtBQUssRUFBRSxHQUNwQztBQUFBLCtCQUFDLFNBQUksV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxTQUFTLEdBQUcsb0NBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxRQUM1RSx1QkFBQyxTQUFJLE9BQU8sRUFBRUYsU0FBUyxRQUFRQyxLQUFLLEdBQUd1QyxxQkFBcUIsVUFBVSxHQUNwRTtBQUFBLGlDQUFDLFlBQU8sT0FBT2xHLGNBQWMsVUFBVSxDQUFDeUIsTUFBTXhCLGdCQUFnQnBCLE9BQU80QyxFQUFFOEMsT0FBTzNGLEtBQUssQ0FBQyxHQUNsRjtBQUFBLG1DQUFDLFlBQU8sT0FBT1IsaUJBQWlCOEIsWUFBWSxvQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxZQUFPLE9BQU85QixpQkFBaUIrSCxTQUFTLGtDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNELHVCQUFDLFlBQU8sT0FBTy9ILGlCQUFpQmdJLFNBQVMsdUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdEO0FBQUEsZUFIbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWLE9BQU9qRztBQUFBQSxjQUNQLFVBQVUsQ0FBQ3NCLE1BQU1yQixrQkFBa0JxQixFQUFFOEMsT0FBTzNGLEtBQUs7QUFBQTtBQUFBLFlBSm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlxRDtBQUFBLGFBVnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGFBQVk7QUFBQSxZQUNaLE9BQU95QjtBQUFBQSxZQUNQLFVBQVUsQ0FBQ29CLE1BQU1uQix1QkFBdUJtQixFQUFFOEMsT0FBTzNGLEtBQUs7QUFBQTtBQUFBLFVBSHhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcwRDtBQUFBLFFBRTFEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixVQUFVRixZQUFZeUIsY0FBYyxLQUFLLEtBQUsrQyxpQkFBaUJrQjtBQUFBQSxZQUMvRCxTQUFTLE1BQU1sQixpQkFBaUJtQixPQUFPO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxXQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVgsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDcEM7QUFBQSwrQkFBQyxTQUFJLFdBQVUsV0FBVSxPQUFPLEVBQUVDLFVBQVUsU0FBUyxHQUFHLDRCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsUUFFbkVOLFdBQ0MsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZUFDYixpQ0FBQyxVQUFLLE9BQU8sRUFBRU0sVUFBVSxXQUFXckUsT0FBTyxpQkFBaUIsR0FBRyxrREFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNDUCxrQkFBa0IyRixJQUFJLENBQUMwQixhQUFhO0FBQ25DLGtCQUFNQyxXQUNKaEQsUUFBUW9CLGNBQWM2QixLQUFLLENBQUNDLE1BQU1BLEVBQUUzQixvQkFBb0J3QixRQUFRLEdBQUd2QixlQUFlO0FBQ3BGLGtCQUFNMkIsYUFBYWhHLFdBQVc0RixRQUFRLEtBQUs7QUFDM0Msa0JBQU1LLGFBQWFELFdBQVd0RCxLQUFLLE1BQU07QUFDekMsa0JBQU13RCxPQUFPakksWUFBWStILFVBQVUsSUFBSUg7QUFDdkMsbUJBQ0U7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBRVYsT0FBTyxFQUFFTSxlQUFlLFVBQVVDLFlBQVksV0FBV2xELEtBQUssRUFBRTtBQUFBLGdCQUVoRTtBQUFBLHlDQUFDLFNBQUksT0FBTyxFQUFFRCxTQUFTLFFBQVFHLGdCQUFnQixpQkFBaUJpRCxPQUFPLE9BQU8sR0FDNUU7QUFBQSwyQ0FBQyxVQUFNdEksNkJBQW1CNkgsUUFBUSxLQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvQztBQUFBLG9CQUNwQyx1QkFBQyxVQUFLLFdBQVUsWUFBVyxPQUFPLEVBQUU5RyxPQUFPLGlCQUFpQixHQUFHO0FBQUE7QUFBQSxzQkFDbkRoQixVQUFVK0gsUUFBUTtBQUFBLHlCQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFNUMsU0FBUyxRQUFRQyxLQUFLLEdBQUdrRCxZQUFZLFNBQVMsR0FDMUQ7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBLHdCQUNWLE9BQU9KO0FBQUFBLHdCQUNQLFVBQVUsQ0FBQ2hGLE1BQU1mLGNBQWMsQ0FBQ3FHLE9BQU8sRUFBRSxHQUFHQSxHQUFHLENBQUNWLFFBQVEsR0FBRzVFLEVBQUU4QyxPQUFPM0YsTUFBTSxFQUFFO0FBQUEsd0JBQzVFLE9BQU8sRUFBRW9JLE1BQU0sRUFBRTtBQUFBO0FBQUEsc0JBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLcUI7QUFBQSxvQkFFcEJOLGNBQ0M7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLE9BQU87QUFBQSwwQkFDTDlDLFVBQVU7QUFBQSwwQkFDVnFELFVBQVU7QUFBQSwwQkFDVkMsV0FBVztBQUFBLDBCQUNYM0gsT0FBT29ILFNBQVMsSUFBSSxjQUFjQSxPQUFPLElBQUksaUJBQWlCO0FBQUEsd0JBQ2hFO0FBQUEsd0JBRUNBLG1CQUFTLElBQUksWUFBWUEsT0FBTyxJQUFJLEtBQUtwSSxVQUFVb0ksSUFBSSxDQUFDLEtBQUssS0FBS3BJLFVBQVUwRixLQUFLQyxJQUFJeUMsSUFBSSxDQUFDLENBQUM7QUFBQTtBQUFBLHNCQVQ5RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBVUE7QUFBQSx1QkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFxQkE7QUFBQTtBQUFBO0FBQUEsY0E5QktOO0FBQUFBLGNBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlDQTtBQUFBLFVBRUosQ0FBQztBQUFBLFVBQ0QsdUJBQUMsT0FBRSxPQUFPLEVBQUU1QyxTQUFTLGlCQUFpQjBELFFBQVEsR0FBR3ZELFVBQVUsV0FBV3JFLE9BQU8sbUJBQW1CLEdBQUcsNExBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcURBO0FBQUEsUUFHRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsYUFBWTtBQUFBLFlBQ1osV0FBVTtBQUFBLFlBQ1YsT0FBT2dCO0FBQUFBLFlBQ1AsVUFBVSxDQUFDa0IsTUFBTWpCLGlCQUFpQmlCLEVBQUU4QyxPQUFPM0YsS0FBSztBQUFBO0FBQUEsVUFKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSW9EO0FBQUEsUUFFbkRpQyxTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQzNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixVQUFVTixjQUFjNEMsS0FBSyxNQUFNLE1BQU1DLGNBQWNnQjtBQUFBQSxZQUN2RCxTQUFTLFlBQVk7QUFDbkIsa0JBQ0UsTUFBTXhFLE9BQU93SCxRQUFRO0FBQUEsZ0JBQ25CcEIsT0FBTztBQUFBLGdCQUNQaEQsU0FBUztBQUFBLGdCQUNUaUQsY0FBYztBQUFBLGdCQUNkb0IsUUFBUTtBQUFBLGNBQ1YsQ0FBQztBQUVEakUsOEJBQWNpQixPQUFPO0FBQUEsWUFDekI7QUFBQSxZQUVDakIsd0JBQWNnQixZQUFZLGNBQWM7QUFBQTtBQUFBLFVBaEIzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFpQkE7QUFBQSxXQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUZBO0FBQUEsU0FyTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNOQTtBQUFBLE9BbFJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvUkE7QUFFSjtBQUFDMUUsR0FyWWVGLFlBQVU7QUFBQSxVQUNKbEMsZ0JBQ0xDLFdBQ1FNLGNBVUlSLFVBTUVELGFBS1JDLFVBT0NhLGVBRUhiLFVBT0lELGFBWUZDLFVBaUJBRCxhQVVJQSxhQWtCSEEsV0FBVztBQUFBO0FBQUEsS0FqR25Cb0M7QUFBVSxJQUFBOEg7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJ1c2VEaWFsb2ciLCJjbG9zZUNhc2hTZXNzaW9uIiwiZ2V0Q2FzaFN1bW1hcnkiLCJnZXRPcGVuU2Vzc2lvbiIsIm9wZW5DYXNoU2Vzc2lvbiIsInJlZ2lzdGVyQ2FzaE1vdmVtZW50IiwidXNlQXV0aFN0b3JlIiwiZ2V0UHJpbnRTZXR0aW5ncyIsInByaW50Q2FzaENsb3NpbmciLCJnZXRTYWxlc0J5U2Vzc2lvbiIsInJlZnVuZFNhbGUiLCJ1c2VNeUZlYXR1cmVzIiwiQXBpRXJyb3IiLCJDYXNoTW92ZW1lbnRUeXBlIiwiREVGQVVMVF9DQVNIX1JFR0lTVEVSX0lEIiwiUGF5bWVudE1ldGhvZCIsImZvcm1hdEJSTCIsInBheW1lbnRNZXRob2RMYWJlbCIsIk92ZXJsYXkiLCJwYXJzZUFtb3VudCIsInJhdyIsInZhbHVlIiwiTnVtYmVyIiwicmVwbGFjZSIsImlzRmluaXRlIiwiUkVDT05DSUxFX01FVEhPRFMiLCJDYXJ0YW9DcmVkaXRvIiwiQ2FydGFvRGViaXRvIiwiUGl4IiwiZ2V0RGlmZmVyZW5jZVN0YXRlIiwiZGlmZmVyZW5jZUFtb3VudCIsImxhYmVsIiwiY29sb3IiLCJDYXNoRHJhd2VyIiwib25DbG9zZSIsIl9zIiwicXVlcnlDbGllbnQiLCJkaWFsb2ciLCJlbXBsb3llZUlkIiwib3BlbmluZ0Ftb3VudCIsInNldE9wZW5pbmdBbW91bnQiLCJtb3ZlbWVudFR5cGUiLCJzZXRNb3ZlbWVudFR5cGUiLCJTdXByaW1lbnRvIiwibW92ZW1lbnRBbW91bnQiLCJzZXRNb3ZlbWVudEFtb3VudCIsIm1vdmVtZW50RGVzY3JpcHRpb24iLCJzZXRNb3ZlbWVudERlc2NyaXB0aW9uIiwiY291bnRlZEFtb3VudCIsInNldENvdW50ZWRBbW91bnQiLCJjYXJkQ291bnRzIiwic2V0Q2FyZENvdW50cyIsImNsb3NlUmVzdWx0Iiwic2V0Q2xvc2VSZXN1bHQiLCJlcnJvciIsInNldEVycm9yIiwicHJpbnRTZXR0aW5nc1F1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwiZ2V0U3RhdGUiLCJicmFuY2hJZCIsInN0YWxlVGltZSIsInByaW50Q2xvc2luZ011dGF0aW9uIiwibXV0YXRpb25GbiIsInNlc3Npb25JZFRvUHJpbnQiLCJvbkVycm9yIiwiZSIsIm9uQXBpRXJyb3IiLCJzZXNzaW9uUXVlcnkiLCJyZXRyeSIsInNlc3Npb25JZCIsImRhdGEiLCJpZCIsImZlYXR1cmVzUXVlcnkiLCJzYWxlc1F1ZXJ5IiwiZW5hYmxlZCIsInVuZGVmaW5lZCIsInJlZmV0Y2hJbnRlcnZhbCIsInJlZnVuZE11dGF0aW9uIiwic2FsZUlkIiwicmVhc29uIiwib25TdWNjZXNzIiwiaW52YWxpZGF0ZUNhc2giLCJpbnZhbGlkYXRlUXVlcmllcyIsInN1bW1hcnlRdWVyeSIsIm5vU2Vzc2lvbiIsImlzRXJyb3IiLCJzdGF0dXMiLCJmYWxsYmFjayIsIm1lc3NhZ2UiLCJvcGVuTXV0YXRpb24iLCJtb3ZlbWVudE11dGF0aW9uIiwidHJpbSIsImNsb3NlTXV0YXRpb24iLCJyZXN1bHQiLCJzdW1tYXJ5IiwiZGlmZmVyZW5jZVN0YXRlIiwiaXNMb2FkaW5nIiwicGFkZGluZyIsImRpc3BsYXkiLCJnYXAiLCJmb250U2l6ZSIsImp1c3RpZnlDb250ZW50IiwiZXhwZWN0ZWRBbW91bnQiLCJjbG9zaW5nQW1vdW50IiwiZm9udFdlaWdodCIsIk1hdGgiLCJhYnMiLCJwcmludEJpbGxzRW5hYmxlZCIsImlzUGVuZGluZyIsIm11dGF0ZSIsImNhc2hTZXNzaW9uSWQiLCJ0YXJnZXQiLCJzYWxlc0NvdW50Iiwic2FsZXNUb3RhbCIsInBheW1lbnRUb3RhbHMiLCJtYXAiLCJ0b3RhbCIsInBheW1lbnRNZXRob2RJZCIsInRvdGFsQW1vdW50IiwicGFydGlhbFBheW1lbnRzVG90YWwiLCJzdXByaW1lbnRvVG90YWwiLCJzYW5ncmlhVG90YWwiLCJkZXNwZXNhVG90YWwiLCJleHBlY3RlZENhc2hBbW91bnQiLCJsZW5ndGgiLCJzYWxlIiwic2FsZU51bWJlciIsImN1c3RvbWVyT3JkZXJJZCIsIkRhdGUiLCJzb2xkQXQiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJob3VyIiwibWludXRlIiwiY2FuTWFuYWdlQWNjZXNzIiwibWluSGVpZ2h0IiwicHJvbXB0IiwidGl0bGUiLCJjb25maXJtTGFiZWwiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwiU2FuZ3JpYSIsIkRlc3Blc2EiLCJtZXRob2RJZCIsImV4cGVjdGVkIiwiZmluZCIsInQiLCJjb3VudGVkUmF3IiwiaGFzQ291bnRlZCIsImRpZmYiLCJmbGV4RGlyZWN0aW9uIiwiYWxpZ25JdGVtcyIsIndpZHRoIiwiYyIsImZsZXgiLCJtaW5XaWR0aCIsInRleHRBbGlnbiIsIm1hcmdpbiIsImNvbmZpcm0iLCJkYW5nZXIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXNoRHJhd2VyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xyXG5pbXBvcnQgeyB1c2VEaWFsb2cgfSBmcm9tIFwiLi4vLi4vdWkvRGlhbG9nXCI7XHJcbmltcG9ydCB7XHJcbiAgY2xvc2VDYXNoU2Vzc2lvbixcclxuICBnZXRDYXNoU3VtbWFyeSxcclxuICBnZXRPcGVuU2Vzc2lvbixcclxuICBvcGVuQ2FzaFNlc3Npb24sXHJcbiAgcmVnaXN0ZXJDYXNoTW92ZW1lbnQsXHJcbn0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IGdldFByaW50U2V0dGluZ3MsIHByaW50Q2FzaENsb3NpbmcgfSBmcm9tIFwiLi4vcHJpbnRpbmcvYXBpXCI7XHJcbmltcG9ydCB7IGdldFNhbGVzQnlTZXNzaW9uLCByZWZ1bmRTYWxlIH0gZnJvbSBcIi4uL2JpbGxpbmcvYXBpXCI7XHJcbmltcG9ydCB7IHVzZU15RmVhdHVyZXMgfSBmcm9tIFwiLi4vYWNjZXNzL2hvb2tzXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHtcclxuICBDYXNoTW92ZW1lbnRUeXBlLFxyXG4gIERFRkFVTFRfQ0FTSF9SRUdJU1RFUl9JRCxcclxuICBQYXltZW50TWV0aG9kLFxyXG4gIGZvcm1hdEJSTCxcclxuICBwYXltZW50TWV0aG9kTGFiZWwsXHJcbn0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IENsb3NlQ2FzaFNlc3Npb25SZXNwb25zZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgT3ZlcmxheSB9IGZyb20gXCIuLi9vcmRlcnMvT3ZlcmxheVwiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5jb25zdCBwYXJzZUFtb3VudCA9IChyYXc6IHN0cmluZyk6IG51bWJlciA9PiB7XHJcbiAgY29uc3QgdmFsdWUgPSBOdW1iZXIocmF3LnJlcGxhY2UoXCIsXCIsIFwiLlwiKSk7XHJcbiAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgPyB2YWx1ZSA6IDA7XHJcbn07XHJcblxyXG4vLyBDb25mZXLDqm5jaWEgZGUgZmVjaGFtZW50byBwb3IgbW9kYWxpZGFkZSBlbGV0csO0bmljYSDigJQgc8OzIGV4aWJpw6fDo28vY29tcGFyYcOnw6NvIG5vIGZyb250LWVuZC5cclxuLy8gTyDDum5pY28gdmFsb3IgZGUgZmF0byBlbnZpYWRvIGFvIGJhY2tlbmQgZW0gRmVjaGFyIGNhaXhhIGNvbnRpbnVhIHNlbmRvIG8gRGluaGVpcm8gY29udGFkb1xyXG4vLyAow6kgbyBxdWUgYSB0YWJlbGEgQ2FzaFNlc3Npb24gZ3JhdmEgaG9qZSk7IENyw6lkaXRvL0TDqWJpdG8vUGl4IGFxdWkgYWp1ZGFtIG8gb3BlcmFkb3IgYSBiYXRlclxyXG4vLyBvIHF1ZSBhIG1hcXVpbmluaGEvbyBleHRyYXRvIFBpeCBtb3N0cm91IGNvbnRyYSBvIHF1ZSBvIHNpc3RlbWEgasOhIGVzcGVyYSwgc2VtIGV4aWdpciBtdWRhbsOnYVxyXG4vLyBkZSBzY2hlbWEgcGFyYSBpc3NvLlxyXG5jb25zdCBSRUNPTkNJTEVfTUVUSE9EUyA9IFtQYXltZW50TWV0aG9kLkNhcnRhb0NyZWRpdG8sIFBheW1lbnRNZXRob2QuQ2FydGFvRGViaXRvLCBQYXltZW50TWV0aG9kLlBpeF07XHJcblxyXG5pbnRlcmZhY2UgRGlmZmVyZW5jZVN0YXRlIHtcclxuICBsYWJlbDogc3RyaW5nO1xyXG4gIGNvbG9yOiBzdHJpbmc7XHJcbn1cclxuXHJcbmNvbnN0IGdldERpZmZlcmVuY2VTdGF0ZSA9IChkaWZmZXJlbmNlQW1vdW50OiBudW1iZXIpOiBEaWZmZXJlbmNlU3RhdGUgPT4ge1xyXG4gIGlmIChkaWZmZXJlbmNlQW1vdW50ID09PSAwKSByZXR1cm4geyBsYWJlbDogXCJDb25mZXJpZG8g4oCUIHNlbSBkaWZlcmVuw6dhXCIsIGNvbG9yOiBcInZhcigtLW9rKVwiIH07XHJcbiAgaWYgKGRpZmZlcmVuY2VBbW91bnQgPiAwKSByZXR1cm4geyBsYWJlbDogXCJTb2JyYVwiLCBjb2xvcjogXCJ2YXIoLS1hbWJlcilcIiB9O1xyXG4gIHJldHVybiB7IGxhYmVsOiBcIkZhbHRhXCIsIGNvbG9yOiBcInZhcigtLWRhbmdlcilcIiB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIENhc2hEcmF3ZXIoeyBvbkNsb3NlIH06IFByb3BzKSB7XHJcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gIGNvbnN0IGRpYWxvZyA9IHVzZURpYWxvZygpO1xyXG4gIGNvbnN0IHsgZW1wbG95ZWVJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgY29uc3QgW29wZW5pbmdBbW91bnQsIHNldE9wZW5pbmdBbW91bnRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21vdmVtZW50VHlwZSwgc2V0TW92ZW1lbnRUeXBlXSA9IHVzZVN0YXRlPG51bWJlcj4oQ2FzaE1vdmVtZW50VHlwZS5TdXByaW1lbnRvKTtcclxuICBjb25zdCBbbW92ZW1lbnRBbW91bnQsIHNldE1vdmVtZW50QW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFttb3ZlbWVudERlc2NyaXB0aW9uLCBzZXRNb3ZlbWVudERlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjb3VudGVkQW1vdW50LCBzZXRDb3VudGVkQW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjYXJkQ291bnRzLCBzZXRDYXJkQ291bnRzXSA9IHVzZVN0YXRlPFJlY29yZDxudW1iZXIsIHN0cmluZz4+KHt9KTtcclxuICBjb25zdCBbY2xvc2VSZXN1bHQsIHNldENsb3NlUmVzdWx0XSA9IHVzZVN0YXRlPENsb3NlQ2FzaFNlc3Npb25SZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IHByaW50U2V0dGluZ3NRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJwcmludGluZ1wiLCBcInNldHRpbmdzXCIsIERFRkFVTFRfQ0FTSF9SRUdJU1RFUl9JRF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRQcmludFNldHRpbmdzKHVzZUF1dGhTdG9yZS5nZXRTdGF0ZSgpLmJyYW5jaElkKSxcclxuICAgIHN0YWxlVGltZTogNjBfMDAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBwcmludENsb3NpbmdNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46IChzZXNzaW9uSWRUb1ByaW50OiBudW1iZXIpID0+IHByaW50Q2FzaENsb3Npbmcoc2Vzc2lvbklkVG9QcmludCksXHJcbiAgICBvbkVycm9yOiAoZSkgPT4gb25BcGlFcnJvcihlLCBcIkZhbGhhIGFvIGltcHJpbWlyIG8gZmVjaGFtZW50by5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHNlc3Npb25RdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJjYXNoXCIsIFwib3BlblwiLCBERUZBVUxUX0NBU0hfUkVHSVNURVJfSURdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0T3BlblNlc3Npb24oREVGQVVMVF9DQVNIX1JFR0lTVEVSX0lEKSxcclxuICAgIHJldHJ5OiBmYWxzZSxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc2Vzc2lvbklkID0gc2Vzc2lvblF1ZXJ5LmRhdGE/LmlkO1xyXG4gIGNvbnN0IGZlYXR1cmVzUXVlcnkgPSB1c2VNeUZlYXR1cmVzKCk7XHJcblxyXG4gIGNvbnN0IHNhbGVzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiY2FzaFwiLCBcInNhbGVzXCIsIHNlc3Npb25JZF0sXHJcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRTYWxlc0J5U2Vzc2lvbihzZXNzaW9uSWQhKSxcclxuICAgIGVuYWJsZWQ6IHNlc3Npb25JZCAhPT0gdW5kZWZpbmVkLFxyXG4gICAgcmVmZXRjaEludGVydmFsOiAzMF8wMDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJlZnVuZE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKHsgc2FsZUlkLCByZWFzb24gfTogeyBzYWxlSWQ6IG51bWJlcjsgcmVhc29uOiBzdHJpbmcgfCBudWxsIH0pID0+XHJcbiAgICAgIHJlZnVuZFNhbGUoc2FsZUlkLCB1c2VBdXRoU3RvcmUuZ2V0U3RhdGUoKS5lbXBsb3llZUlkID8/IDEsIHJlYXNvbiksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgIGludmFsaWRhdGVDYXNoKCk7XHJcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wib3JkZXJzXCJdIH0pO1xyXG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcInRhYmxlc1wiXSB9KTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoZSkgPT4gb25BcGlFcnJvcihlLCBcIkZhbGhhIGFvIGVzdG9ybmFyIGEgdmVuZGEuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBzdW1tYXJ5UXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogW1wiY2FzaFwiLCBcInN1bW1hcnlcIiwgc2Vzc2lvbklkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldENhc2hTdW1tYXJ5KHNlc3Npb25JZCEpLFxyXG4gICAgZW5hYmxlZDogc2Vzc2lvbklkICE9PSB1bmRlZmluZWQsXHJcbiAgICByZWZldGNoSW50ZXJ2YWw6IDIwXzAwMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgbm9TZXNzaW9uID1cclxuICAgIHNlc3Npb25RdWVyeS5pc0Vycm9yICYmXHJcbiAgICBzZXNzaW9uUXVlcnkuZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvciAmJlxyXG4gICAgc2Vzc2lvblF1ZXJ5LmVycm9yLnN0YXR1cyA9PT0gNDA0O1xyXG5cclxuICBjb25zdCBpbnZhbGlkYXRlQ2FzaCA9ICgpID0+IHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiY2FzaFwiXSB9KTtcclxuXHJcbiAgY29uc3Qgb25BcGlFcnJvciA9IChlOiB1bmtub3duLCBmYWxsYmFjazogc3RyaW5nKSA9PlxyXG4gICAgc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEFwaUVycm9yID8gZS5tZXNzYWdlIDogZmFsbGJhY2spO1xyXG5cclxuICBjb25zdCBvcGVuTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PlxyXG4gICAgICBvcGVuQ2FzaFNlc3Npb24oREVGQVVMVF9DQVNIX1JFR0lTVEVSX0lELCBlbXBsb3llZUlkID8/IDEsIHBhcnNlQW1vdW50KG9wZW5pbmdBbW91bnQpKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgaW52YWxpZGF0ZUNhc2goKTtcclxuICAgIH0sXHJcbiAgICBvbkVycm9yOiAoZSkgPT4gb25BcGlFcnJvcihlLCBcIkZhbGhhIGFvIGFicmlyIG8gY2FpeGEuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBtb3ZlbWVudE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT5cclxuICAgICAgcmVnaXN0ZXJDYXNoTW92ZW1lbnQoXHJcbiAgICAgICAgc2Vzc2lvbklkISxcclxuICAgICAgICBtb3ZlbWVudFR5cGUsXHJcbiAgICAgICAgZW1wbG95ZWVJZCA/PyAxLFxyXG4gICAgICAgIHBhcnNlQW1vdW50KG1vdmVtZW50QW1vdW50KSxcclxuICAgICAgICBtb3ZlbWVudERlc2NyaXB0aW9uLnRyaW0oKSA9PT0gXCJcIiA/IG51bGwgOiBtb3ZlbWVudERlc2NyaXB0aW9uLnRyaW0oKSxcclxuICAgICAgKSxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgc2V0TW92ZW1lbnRBbW91bnQoXCJcIik7XHJcbiAgICAgIHNldE1vdmVtZW50RGVzY3JpcHRpb24oXCJcIik7XHJcbiAgICAgIGludmFsaWRhdGVDYXNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKGUpID0+IG9uQXBpRXJyb3IoZSwgXCJGYWxoYSBhbyByZWdpc3RyYXIgbW92aW1lbnRvLlwiKSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgY2xvc2VNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46ICgpID0+IGNsb3NlQ2FzaFNlc3Npb24oc2Vzc2lvbklkISwgZW1wbG95ZWVJZCA/PyAxLCBwYXJzZUFtb3VudChjb3VudGVkQW1vdW50KSksXHJcbiAgICBvblN1Y2Nlc3M6IChyZXN1bHQpID0+IHtcclxuICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgIHNldENsb3NlUmVzdWx0KHJlc3VsdCk7XHJcbiAgICAgIGludmFsaWRhdGVDYXNoKCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKGUpID0+IG9uQXBpRXJyb3IoZSwgXCJGYWxoYSBhbyBmZWNoYXIgbyBjYWl4YS5cIiksXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHN1bW1hcnkgPSBzdW1tYXJ5UXVlcnkuZGF0YTtcclxuICBjb25zdCBkaWZmZXJlbmNlU3RhdGUgPSBnZXREaWZmZXJlbmNlU3RhdGUoY2xvc2VSZXN1bHQ/LmRpZmZlcmVuY2VBbW91bnQgPz8gMCk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8T3ZlcmxheSB0aXRsZT1cIkNhaXhhIDAxXCIgb25DbG9zZT17b25DbG9zZX0gd2lkZT5cclxuICAgICAge3Nlc3Npb25RdWVyeS5pc0xvYWRpbmcgJiYgPHAgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT5DYXJyZWdhbmRv4oCmPC9wPn1cclxuXHJcbiAgICAgIHtjbG9zZVJlc3VsdCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIiBzdHlsZT17eyBwYWRkaW5nOiAxOCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogOCB9fT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuM3JlbVwiIH19PkNhaXhhIGZlY2hhZG88L2Rpdj5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiB9fT5cclxuICAgICAgICAgICAgPHNwYW4+RXNwZXJhZG8gZW0gZGluaGVpcm88L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+e2Zvcm1hdEJSTChjbG9zZVJlc3VsdC5leHBlY3RlZEFtb3VudCl9PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+XHJcbiAgICAgICAgICAgIDxzcGFuPkNvbnRhZG88L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+e2Zvcm1hdEJSTChjbG9zZVJlc3VsdC5jbG9zaW5nQW1vdW50KX08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsXHJcbiAgICAgICAgICAgICAgZm9udFdlaWdodDogNzAwLFxyXG4gICAgICAgICAgICAgIGNvbG9yOiBkaWZmZXJlbmNlU3RhdGUuY29sb3IsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxzcGFuPntkaWZmZXJlbmNlU3RhdGUubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiPntmb3JtYXRCUkwoTWF0aC5hYnMoY2xvc2VSZXN1bHQuZGlmZmVyZW5jZUFtb3VudCkpfTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge3ByaW50U2V0dGluZ3NRdWVyeS5kYXRhPy5wcmludEJpbGxzRW5hYmxlZCAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3ByaW50Q2xvc2luZ011dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwcmludENsb3NpbmdNdXRhdGlvbi5tdXRhdGUoY2xvc2VSZXN1bHQuY2FzaFNlc3Npb25JZCl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7cHJpbnRDbG9zaW5nTXV0YXRpb24uaXNQZW5kaW5nID8gXCJJbXByaW1pbmRv4oCmXCIgOiBcIvCflqggSW1wcmltaXIgZmVjaGFtZW50b1wifVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7IWNsb3NlUmVzdWx0ICYmIG5vU2Vzc2lvbiAmJiAoXHJcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICAgIDxwIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+TmVuaHVtYSBzZXNzw6NvIGFiZXJ0YSBuZXN0ZSBjYWl4YS48L3A+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJGdW5kbyBkZSB0cm9jbyAoUiQpXCJcclxuICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtvcGVuaW5nQW1vdW50fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE9wZW5pbmdBbW91bnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci10ZXh0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtvcGVuTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuTXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIEFicmlyIGNhaXhhXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHshY2xvc2VSZXN1bHQgJiYgc2Vzc2lvbklkICE9PSB1bmRlZmluZWQgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1oZWFkXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMnJlbVwiIH19PlJlc3VtbyBkYSBzZXNzw6NvPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjg1cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAje3Nlc3Npb25JZH1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7c3VtbWFyeSAmJiAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LXJvd1wiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkZ1bmRvIGRlIHRyb2NvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiPntmb3JtYXRCUkwoc3VtbWFyeS5vcGVuaW5nQW1vdW50KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LXJvd1wiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPlZlbmRhcyAoe3N1bW1hcnkuc2FsZXNDb3VudH0pPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiPntmb3JtYXRCUkwoc3VtbWFyeS5zYWxlc1RvdGFsKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHtzdW1tYXJ5LnBheW1lbnRUb3RhbHMubWFwKCh0b3RhbCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIiBrZXk9e3RvdGFsLnBheW1lbnRNZXRob2RJZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3BheW1lbnRNZXRob2RMYWJlbFt0b3RhbC5wYXltZW50TWV0aG9kSWRdID8/IFwiT3V0cm9zXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+e2Zvcm1hdEJSTCh0b3RhbC50b3RhbEFtb3VudCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAge3N1bW1hcnkucGFydGlhbFBheW1lbnRzVG90YWwgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tb2spXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UGFnYW1lbnRvcyBwYXJjaWFpcyAobWVzYXMgYWJlcnRhcyk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIj4rIHtmb3JtYXRCUkwoc3VtbWFyeS5wYXJ0aWFsUGF5bWVudHNUb3RhbCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7c3VtbWFyeS5zdXByaW1lbnRvVG90YWwgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tb2spXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+U3VwcmltZW50b3M8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIj4rIHtmb3JtYXRCUkwoc3VtbWFyeS5zdXByaW1lbnRvVG90YWwpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge3N1bW1hcnkuc2FuZ3JpYVRvdGFsID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LXJvd1wiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWNsb3NpbmcpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2FuZ3JpYXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIj7iiJIge2Zvcm1hdEJSTChzdW1tYXJ5LnNhbmdyaWFUb3RhbCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7c3VtbWFyeS5kZXNwZXNhVG90YWwgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tY2xvc2luZylcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EZXNwZXNhczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiPuKIkiB7Zm9ybWF0QlJMKHN1bW1hcnkuZGVzcGVzYVRvdGFsKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LXRvdGFsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkVzcGVyYWRvIGVtIGRpbmhlaXJvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWFtYmVyKVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtYXRCUkwoc3VtbWFyeS5leHBlY3RlZENhc2hBbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsoc2FsZXNRdWVyeS5kYXRhID8/IFtdKS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1oZWFkXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4xcmVtXCIgfX0+VmVuZGFzIGRhIHNlc3PDo288L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgeyhzYWxlc1F1ZXJ5LmRhdGEgPz8gW10pLm1hcCgoc2FsZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIga2V5PXtzYWxlLmlkfT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBWZW5kYSAje3NhbGUuc2FsZU51bWJlcn0gwrcgcGVkaWRvICN7c2FsZS5jdXN0b21lck9yZGVySWR9IMK3IHtmb3JtYXRCUkwoc2FsZS50b3RhbEFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuNzhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKHNhbGUuc29sZEF0KS50b0xvY2FsZVRpbWVTdHJpbmcoXCJwdC1CUlwiLCB7IGhvdXI6IFwiMi1kaWdpdFwiLCBtaW51dGU6IFwiMi1kaWdpdFwiIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtmZWF0dXJlc1F1ZXJ5LmRhdGE/LmNhbk1hbmFnZUFjY2VzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1pbkhlaWdodDogNDQsIHBhZGRpbmc6IFwiMCAxMHB4XCIsIGZvbnRTaXplOiBcIjAuODJyZW1cIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlZnVuZE11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVhc29uID0gYXdhaXQgZGlhbG9nLnByb21wdCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiRXN0b3JuYXIgdmVuZGFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBgRXN0b3JuYXIgYSB2ZW5kYSAjJHtzYWxlLnNhbGVOdW1iZXJ9ICgke2Zvcm1hdEJSTChzYWxlLnRvdGFsQW1vdW50KX0pP2AsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IFwiTW90aXZvIChvcGNpb25hbClcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25maXJtTGFiZWw6IFwiRXN0b3JuYXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZWFzb24gIT09IG51bGwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmdW5kTXV0YXRpb24ubXV0YXRlKHsgc2FsZUlkOiBzYWxlLmlkLCByZWFzb246IHJlYXNvbi50cmltKCkgPT09IFwiXCIgPyBudWxsIDogcmVhc29uLnRyaW0oKSB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRXN0b3JuYXJcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjFyZW1cIiB9fT5TYW5ncmlhIC8gU3VwcmltZW50bzwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDgsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwiMWZyIDFmclwiIH19PlxyXG4gICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e21vdmVtZW50VHlwZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRNb3ZlbWVudFR5cGUoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9PlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17Q2FzaE1vdmVtZW50VHlwZS5TdXByaW1lbnRvfT5TdXByaW1lbnRvIChlbnRyYWRhKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17Q2FzaE1vdmVtZW50VHlwZS5TYW5ncmlhfT5TYW5ncmlhIChyZXRpcmFkYSk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9e0Nhc2hNb3ZlbWVudFR5cGUuRGVzcGVzYX0+RGVzcGVzYTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJWYWxvciAoUiQpXCJcclxuICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e21vdmVtZW50QW1vdW50fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNb3ZlbWVudEFtb3VudChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3Jpw6fDo28gKG9wY2lvbmFsKVwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e21vdmVtZW50RGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNb3ZlbWVudERlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhcnNlQW1vdW50KG1vdmVtZW50QW1vdW50KSA8PSAwIHx8IG1vdmVtZW50TXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG1vdmVtZW50TXV0YXRpb24ubXV0YXRlKCl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBSZWdpc3RyYXIgbW92aW1lbnRvXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjFyZW1cIiB9fT5GZWNoYXIgY2FpeGE8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtzdW1tYXJ5ICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtaGVhZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgQ29uZmVyw6puY2lhIHBvciBmb3JtYSBkZSBwYWdhbWVudG9cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7UkVDT05DSUxFX01FVEhPRFMubWFwKChtZXRob2RJZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBleHBlY3RlZCA9XHJcbiAgICAgICAgICAgICAgICAgICAgc3VtbWFyeS5wYXltZW50VG90YWxzLmZpbmQoKHQpID0+IHQucGF5bWVudE1ldGhvZElkID09PSBtZXRob2RJZCk/LnRvdGFsQW1vdW50ID8/IDA7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGNvdW50ZWRSYXcgPSBjYXJkQ291bnRzW21ldGhvZElkXSA/PyBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBoYXNDb3VudGVkID0gY291bnRlZFJhdy50cmltKCkgIT09IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGRpZmYgPSBwYXJzZUFtb3VudChjb3VudGVkUmF3KSAtIGV4cGVjdGVkO1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRpY2tldC1yb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXttZXRob2RJZH1cclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGFsaWduSXRlbXM6IFwic3RyZXRjaFwiLCBnYXA6IDYgfX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIHdpZHRoOiBcIjEwMCVcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3BheW1lbnRNZXRob2RMYWJlbFttZXRob2RJZF19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtb25vLW51bVwiIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRXNwZXJhZG8ge2Zvcm1hdEJSTChleHBlY3RlZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiA4LCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNvbmZlcmlkbyAoUiQpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y291bnRlZFJhd31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENhcmRDb3VudHMoKGMpID0+ICh7IC4uLmMsIFttZXRob2RJZF06IGUudGFyZ2V0LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoYXNDb3VudGVkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibW9uby1udW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC44NXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5XaWR0aDogOTYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogZGlmZiA9PT0gMCA/IFwidmFyKC0tb2spXCIgOiBkaWZmID4gMCA/IFwidmFyKC0tYW1iZXIpXCIgOiBcInZhcigtLWRhbmdlcilcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2RpZmYgPT09IDAgPyBcIkNvbmZlcmVcIiA6IGRpZmYgPiAwID8gYCsgJHtmb3JtYXRCUkwoZGlmZil9YCA6IGDiiJIgJHtmb3JtYXRCUkwoTWF0aC5hYnMoZGlmZikpfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IHBhZGRpbmc6IFwiOHB4IDE4cHggMTJweFwiLCBtYXJnaW46IDAsIGZvbnRTaXplOiBcIjAuNzhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICBTw7MgbyBEaW5oZWlybyBhYmFpeG8gw6kgZW52aWFkbyBhbyBmZWNoYXIgbyBjYWl4YSDigJQgQ3LDqWRpdG8vRMOpYml0by9QaXggYXF1aSBzw6NvIGNvbmZlcsOqbmNpYVxyXG4gICAgICAgICAgICAgICAgICB2aXN1YWwgKG8gdmFsb3IgZXNwZXJhZG8gasOhIHZlbSBkYXMgdmVuZGFzIGRhIHNlc3PDo28pIGUgbsOjbyBhbHRlcmFtIG8gZmVjaGFtZW50by5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGluaGVpcm8gY29udGFkbyBuYSBnYXZldGEgKFIkKVwiXHJcbiAgICAgICAgICAgICAgaW5wdXRNb2RlPVwiZGVjaW1hbFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvdW50ZWRBbW91bnR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb3VudGVkQW1vdW50KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1kYW5nZXJcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtjb3VudGVkQW1vdW50LnRyaW0oKSA9PT0gXCJcIiB8fCBjbG9zZU11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICAgIGF3YWl0IGRpYWxvZy5jb25maXJtKHtcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJGZWNoYXIgY2FpeGFcIixcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIkZlY2hhciBvIGNhaXhhPyBQZWRpZG9zIGFndWFyZGFuZG8gcGFnYW1lbnRvIG7Do28gcG9kZXLDo28gc2VyIHJlY2ViaWRvcy5cIixcclxuICAgICAgICAgICAgICAgICAgICBjb25maXJtTGFiZWw6IFwiRmVjaGFyIGNhaXhhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZGFuZ2VyOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICBjbG9zZU11dGF0aW9uLm11dGF0ZSgpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7Y2xvc2VNdXRhdGlvbi5pc1BlbmRpbmcgPyBcIkZlY2hhbmRv4oCmXCIgOiBcIkZlY2hhciBjYWl4YSBlIGNvbmZlcmlyXCJ9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICA8L092ZXJsYXk+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvY2FzaC9DYXNoRHJhd2VyLnRzeCJ9