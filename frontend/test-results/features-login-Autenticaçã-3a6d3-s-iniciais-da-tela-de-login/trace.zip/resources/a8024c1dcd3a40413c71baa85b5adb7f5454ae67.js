import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/modals/CalculatorModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
export function CalculatorModal({ onClose }) {
  _s();
  const [calcInput, setCalcInput] = useState("0");
  const [calcPrevValue, setCalcPrevValue] = useState(null);
  const [calcOperator, setCalcOperator] = useState(null);
  const [calcNewNumber, setCalcNewNumber] = useState(false);
  const handleCalcNum = (num) => {
    if (calcNewNumber) {
      setCalcInput(num);
      setCalcNewNumber(false);
    } else {
      setCalcInput(calcInput === "0" && num !== "." ? num : calcInput + num);
    }
  };
  const handleCalcOp = (op) => {
    if (calcOperator && !calcNewNumber) handleCalcEqual();
    else
      setCalcPrevValue(parseFloat(calcInput));
    setCalcOperator(op);
    setCalcNewNumber(true);
  };
  const handleCalcEqual = () => {
    if (calcOperator && calcPrevValue !== null) {
      const current = parseFloat(calcInput);
      let result = 0;
      if (calcOperator === "+") result = calcPrevValue + current;
      if (calcOperator === "-") result = calcPrevValue - current;
      if (calcOperator === "*") result = calcPrevValue * current;
      if (calcOperator === "/") result = calcPrevValue / current;
      setCalcInput(parseFloat(result.toFixed(4)).toString());
      setCalcPrevValue(null);
      setCalcOperator(null);
      setCalcNewNumber(true);
    }
  };
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "modal-backdrop is-center",
      onMouseDown: (e) => {
        if (e.target === e.currentTarget) onClose();
      },
      style: { position: "absolute" },
      children: /* @__PURE__ */ jsxDEV("div", { className: "modal-panel is-center", style: { width: "90%", maxWidth: "320px", padding: "20px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "modal-head", style: { marginBottom: "16px", display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.2rem", fontWeight: "bold" }, children: "➗ Calculadora" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 69,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost btn-icon", onClick: onClose, children: "✕" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 70,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
          lineNumber: 68,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { backgroundColor: "var(--bg-body)", border: "1px solid var(--border)", borderRadius: "8px", padding: "16px", fontSize: "2rem", textAlign: "right", marginBottom: "16px", overflow: "hidden", color: "var(--ink)", fontWeight: "bold" }, children: calcInput }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
          lineNumber: 72,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "8px" }, children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { gridColumn: "span 3", backgroundColor: "#fee2e2", color: "#b91c1c", fontWeight: "bold", fontSize: "1.2rem" }, onClick: () => {
            setCalcInput("0");
            setCalcPrevValue(null);
            setCalcOperator(null);
            setCalcNewNumber(false);
          }, children: "C" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 76,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "#e0e7ff", color: "#4338ca", fontWeight: "bold", fontSize: "1.2rem" }, onClick: () => handleCalcOp("/"), children: "÷" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 77,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("7"), children: "7" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 78,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("8"), children: "8" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 79,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("9"), children: "9" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 80,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "#e0e7ff", color: "#4338ca", fontWeight: "bold", fontSize: "1.2rem" }, onClick: () => handleCalcOp("*"), children: "×" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 81,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("4"), children: "4" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 82,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("5"), children: "5" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 83,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("6"), children: "6" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 84,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "#e0e7ff", color: "#4338ca", fontWeight: "bold", fontSize: "1.5rem" }, onClick: () => handleCalcOp("-"), children: "-" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 85,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("1"), children: "1" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 86,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("2"), children: "2" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 87,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("3"), children: "3" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 88,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "#e0e7ff", color: "#4338ca", fontWeight: "bold", fontSize: "1.2rem" }, onClick: () => handleCalcOp("+"), children: "+" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 89,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { gridColumn: "span 2", backgroundColor: "var(--bg-raise)", fontSize: "1.2rem" }, onClick: () => handleCalcNum("0"), children: "0" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 90,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost", style: { backgroundColor: "var(--bg-raise)", fontWeight: "bold", fontSize: "1.2rem" }, onClick: () => handleCalcNum("."), children: "." }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 91,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "waiter-cta", style: { margin: 0, fontSize: "1.2rem" }, onClick: handleCalcEqual, children: "=" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
            lineNumber: 92,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
          lineNumber: 75,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
        lineNumber: 67,
        columnNumber: 13
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx",
      lineNumber: 60,
      columnNumber: 5
    },
    this
  );
}
_s(CalculatorModal, "idvaeAH7+EOlZrWbF111V7hFASY=");
_c = CalculatorModal;
var _c;
$RefreshReg$(_c, "CalculatorModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/CalculatorModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqRG5CLFNBQVNBLGdCQUFnQjtBQUVuQixnQkFBU0MsZ0JBQWdCLEVBQUVDLFFBQWlDLEdBQUc7QUFBQUMsS0FBQTtBQUNsRSxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSUwsU0FBUyxHQUFHO0FBQzlDLFFBQU0sQ0FBQ00sZUFBZUMsZ0JBQWdCLElBQUlQLFNBQXdCLElBQUk7QUFDdEUsUUFBTSxDQUFDUSxjQUFjQyxlQUFlLElBQUlULFNBQXdCLElBQUk7QUFDcEUsUUFBTSxDQUFDVSxlQUFlQyxnQkFBZ0IsSUFBSVgsU0FBUyxLQUFLO0FBRXhELFFBQU1ZLGdCQUFnQkEsQ0FBQ0MsUUFBZ0I7QUFDbkMsUUFBSUgsZUFBZTtBQUNmTCxtQkFBYVEsR0FBRztBQUNoQkYsdUJBQWlCLEtBQUs7QUFBQSxJQUMxQixPQUFPO0FBQ0hOLG1CQUFhRCxjQUFjLE9BQU9TLFFBQVEsTUFBTUEsTUFBTVQsWUFBWVMsR0FBRztBQUFBLElBQ3pFO0FBQUEsRUFDSjtBQUVBLFFBQU1DLGVBQWVBLENBQUNDLE9BQWU7QUFDakMsUUFBSVAsZ0JBQWdCLENBQUNFLGNBQWVNLGlCQUFnQjtBQUFBO0FBQy9DVCx1QkFBaUJVLFdBQVdiLFNBQVMsQ0FBQztBQUMzQ0ssb0JBQWdCTSxFQUFFO0FBQ2xCSixxQkFBaUIsSUFBSTtBQUFBLEVBQ3pCO0FBRUEsUUFBTUssa0JBQWtCQSxNQUFNO0FBQzFCLFFBQUlSLGdCQUFnQkYsa0JBQWtCLE1BQU07QUFDeEMsWUFBTVksVUFBVUQsV0FBV2IsU0FBUztBQUNwQyxVQUFJZSxTQUFTO0FBQ2IsVUFBSVgsaUJBQWlCLElBQUtXLFVBQVNiLGdCQUFnQlk7QUFDbkQsVUFBSVYsaUJBQWlCLElBQUtXLFVBQVNiLGdCQUFnQlk7QUFDbkQsVUFBSVYsaUJBQWlCLElBQUtXLFVBQVNiLGdCQUFnQlk7QUFDbkQsVUFBSVYsaUJBQWlCLElBQUtXLFVBQVNiLGdCQUFnQlk7QUFDbkRiLG1CQUFhWSxXQUFXRSxPQUFPQyxRQUFRLENBQUMsQ0FBQyxFQUFFQyxTQUFTLENBQUM7QUFDckRkLHVCQUFpQixJQUFJO0FBQ3JCRSxzQkFBZ0IsSUFBSTtBQUNwQkUsdUJBQWlCLElBQUk7QUFBQSxJQUN6QjtBQUFBLEVBQ0o7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxXQUFVO0FBQUEsTUFDVixhQUFhLENBQUNXLE1BQU07QUFDaEIsWUFBSUEsRUFBRUMsV0FBV0QsRUFBRUUsY0FBZXRCLFNBQVE7QUFBQSxNQUM5QztBQUFBLE1BQ0EsT0FBTyxFQUFFdUIsVUFBVSxXQUFXO0FBQUEsTUFFOUIsaUNBQUMsU0FBSSxXQUFVLHlCQUF3QixPQUFPLEVBQUVDLE9BQU8sT0FBT0MsVUFBVSxTQUFTQyxTQUFTLE9BQU8sR0FDN0Y7QUFBQSwrQkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVDLGNBQWMsUUFBUUMsU0FBUyxRQUFRQyxnQkFBZ0IsaUJBQWlCQyxZQUFZLFNBQVMsR0FDOUg7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVDLFVBQVUsVUFBVUMsWUFBWSxPQUFPLEdBQUcsNkJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBGO0FBQUEsVUFDMUYsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxzQkFBcUIsU0FBU2hDLFNBQVMsaUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdFO0FBQUEsYUFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWlDLGlCQUFpQixrQkFBa0JDLFFBQVEsMkJBQTJCQyxjQUFjLE9BQU9ULFNBQVMsUUFBUUssVUFBVSxRQUFRSyxXQUFXLFNBQVNULGNBQWMsUUFBUVUsVUFBVSxVQUFVQyxPQUFPLGNBQWNOLFlBQVksT0FBTyxHQUM3TzlCLHVCQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUwQixTQUFTLFFBQVFXLHFCQUFxQixrQkFBa0JDLEtBQUssTUFBTSxHQUM3RTtBQUFBLGlDQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsYUFBWSxPQUFPLEVBQUVDLFlBQVksVUFBVVIsaUJBQWlCLFdBQVdLLE9BQU8sV0FBV04sWUFBWSxRQUFRRCxVQUFVLFNBQVMsR0FBRyxTQUFTLE1BQU07QUFBRTVCLHlCQUFhLEdBQUc7QUFBR0UsNkJBQWlCLElBQUk7QUFBR0UsNEJBQWdCLElBQUk7QUFBR0UsNkJBQWlCLEtBQUs7QUFBQSxVQUFHLEdBQUcsaUJBQWxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1SO0FBQUEsVUFDblIsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLE9BQU8sRUFBRXdCLGlCQUFpQixXQUFXSyxPQUFPLFdBQVdOLFlBQVksUUFBUUQsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNbkIsYUFBYSxHQUFHLEdBQUcsaUJBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdMO0FBQUEsVUFDaEwsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLE9BQU8sRUFBRXFCLGlCQUFpQixtQkFBbUJGLFVBQVUsU0FBUyxHQUFHLFNBQVMsTUFBTXJCLGNBQWMsR0FBRyxHQUFHLGlCQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSjtBQUFBLFVBQ25KLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsYUFBWSxPQUFPLEVBQUV1QixpQkFBaUIsbUJBQW1CRixVQUFVLFNBQVMsR0FBRyxTQUFTLE1BQU1yQixjQUFjLEdBQUcsR0FBRyxpQkFBbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUo7QUFBQSxVQUNuSix1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGFBQVksT0FBTyxFQUFFdUIsaUJBQWlCLG1CQUFtQkYsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNckIsY0FBYyxHQUFHLEdBQUcsaUJBQWxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1KO0FBQUEsVUFDbkosdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLE9BQU8sRUFBRXVCLGlCQUFpQixXQUFXSyxPQUFPLFdBQVdOLFlBQVksUUFBUUQsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNbkIsYUFBYSxHQUFHLEdBQUcsaUJBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdMO0FBQUEsVUFDaEwsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLE9BQU8sRUFBRXFCLGlCQUFpQixtQkFBbUJGLFVBQVUsU0FBUyxHQUFHLFNBQVMsTUFBTXJCLGNBQWMsR0FBRyxHQUFHLGlCQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSjtBQUFBLFVBQ25KLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsYUFBWSxPQUFPLEVBQUV1QixpQkFBaUIsbUJBQW1CRixVQUFVLFNBQVMsR0FBRyxTQUFTLE1BQU1yQixjQUFjLEdBQUcsR0FBRyxpQkFBbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUo7QUFBQSxVQUNuSix1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGFBQVksT0FBTyxFQUFFdUIsaUJBQWlCLG1CQUFtQkYsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNckIsY0FBYyxHQUFHLEdBQUcsaUJBQWxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1KO0FBQUEsVUFDbkosdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLE9BQU8sRUFBRXVCLGlCQUFpQixXQUFXSyxPQUFPLFdBQVdOLFlBQVksUUFBUUQsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNbkIsYUFBYSxHQUFHLEdBQUcsaUJBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdMO0FBQUEsVUFDaEwsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLE9BQU8sRUFBRXFCLGlCQUFpQixtQkFBbUJGLFVBQVUsU0FBUyxHQUFHLFNBQVMsTUFBTXJCLGNBQWMsR0FBRyxHQUFHLGlCQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSjtBQUFBLFVBQ25KLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsYUFBWSxPQUFPLEVBQUV1QixpQkFBaUIsbUJBQW1CRixVQUFVLFNBQVMsR0FBRyxTQUFTLE1BQU1yQixjQUFjLEdBQUcsR0FBRyxpQkFBbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUo7QUFBQSxVQUNuSix1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGFBQVksT0FBTyxFQUFFdUIsaUJBQWlCLG1CQUFtQkYsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNckIsY0FBYyxHQUFHLEdBQUcsaUJBQWxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1KO0FBQUEsVUFDbkosdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLE9BQU8sRUFBRXVCLGlCQUFpQixXQUFXSyxPQUFPLFdBQVdOLFlBQVksUUFBUUQsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNbkIsYUFBYSxHQUFHLEdBQUcsaUJBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdMO0FBQUEsVUFDaEwsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLE9BQU8sRUFBRTZCLFlBQVksVUFBVVIsaUJBQWlCLG1CQUFtQkYsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNckIsY0FBYyxHQUFHLEdBQUcsaUJBQXhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlLO0FBQUEsVUFDekssdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxhQUFZLE9BQU8sRUFBRXVCLGlCQUFpQixtQkFBbUJELFlBQVksUUFBUUQsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNckIsY0FBYyxHQUFHLEdBQUcsaUJBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVLO0FBQUEsVUFDdkssdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxjQUFhLE9BQU8sRUFBRWdDLFFBQVEsR0FBR1gsVUFBVSxTQUFTLEdBQUcsU0FBU2pCLGlCQUFpQixpQkFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0g7QUFBQSxhQWpCdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFdBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQTtBQUFBLElBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1DQTtBQUVSO0FBQUNiLEdBM0VlRixpQkFBZTtBQUFBLEtBQWZBO0FBQWUsSUFBQTRDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ2FsY3VsYXRvck1vZGFsIiwib25DbG9zZSIsIl9zIiwiY2FsY0lucHV0Iiwic2V0Q2FsY0lucHV0IiwiY2FsY1ByZXZWYWx1ZSIsInNldENhbGNQcmV2VmFsdWUiLCJjYWxjT3BlcmF0b3IiLCJzZXRDYWxjT3BlcmF0b3IiLCJjYWxjTmV3TnVtYmVyIiwic2V0Q2FsY05ld051bWJlciIsImhhbmRsZUNhbGNOdW0iLCJudW0iLCJoYW5kbGVDYWxjT3AiLCJvcCIsImhhbmRsZUNhbGNFcXVhbCIsInBhcnNlRmxvYXQiLCJjdXJyZW50IiwicmVzdWx0IiwidG9GaXhlZCIsInRvU3RyaW5nIiwiZSIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJwb3NpdGlvbiIsIndpZHRoIiwibWF4V2lkdGgiLCJwYWRkaW5nIiwibWFyZ2luQm90dG9tIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsInRleHRBbGlnbiIsIm92ZXJmbG93IiwiY29sb3IiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwiZ2FwIiwiZ3JpZENvbHVtbiIsIm1hcmdpbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhbGN1bGF0b3JNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBDYWxjdWxhdG9yTW9kYWwoeyBvbkNsb3NlIH06IHsgb25DbG9zZTogKCkgPT4gdm9pZCB9KSB7XHJcbiAgICBjb25zdCBbY2FsY0lucHV0LCBzZXRDYWxjSW5wdXRdID0gdXNlU3RhdGUoXCIwXCIpO1xyXG4gICAgY29uc3QgW2NhbGNQcmV2VmFsdWUsIHNldENhbGNQcmV2VmFsdWVdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbY2FsY09wZXJhdG9yLCBzZXRDYWxjT3BlcmF0b3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbY2FsY05ld051bWJlciwgc2V0Q2FsY05ld051bWJlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2FsY051bSA9IChudW06IHN0cmluZykgPT4ge1xyXG4gICAgICAgIGlmIChjYWxjTmV3TnVtYmVyKSB7XHJcbiAgICAgICAgICAgIHNldENhbGNJbnB1dChudW0pO1xyXG4gICAgICAgICAgICBzZXRDYWxjTmV3TnVtYmVyKGZhbHNlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzZXRDYWxjSW5wdXQoY2FsY0lucHV0ID09PSBcIjBcIiAmJiBudW0gIT09IFwiLlwiID8gbnVtIDogY2FsY0lucHV0ICsgbnVtKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNhbGNPcCA9IChvcDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgaWYgKGNhbGNPcGVyYXRvciAmJiAhY2FsY05ld051bWJlcikgaGFuZGxlQ2FsY0VxdWFsKCk7XHJcbiAgICAgICAgZWxzZSBzZXRDYWxjUHJldlZhbHVlKHBhcnNlRmxvYXQoY2FsY0lucHV0KSk7XHJcbiAgICAgICAgc2V0Q2FsY09wZXJhdG9yKG9wKTtcclxuICAgICAgICBzZXRDYWxjTmV3TnVtYmVyKHRydWUpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDYWxjRXF1YWwgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKGNhbGNPcGVyYXRvciAmJiBjYWxjUHJldlZhbHVlICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnQgPSBwYXJzZUZsb2F0KGNhbGNJbnB1dCk7XHJcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSAwO1xyXG4gICAgICAgICAgICBpZiAoY2FsY09wZXJhdG9yID09PSBcIitcIikgcmVzdWx0ID0gY2FsY1ByZXZWYWx1ZSArIGN1cnJlbnQ7XHJcbiAgICAgICAgICAgIGlmIChjYWxjT3BlcmF0b3IgPT09IFwiLVwiKSByZXN1bHQgPSBjYWxjUHJldlZhbHVlIC0gY3VycmVudDtcclxuICAgICAgICAgICAgaWYgKGNhbGNPcGVyYXRvciA9PT0gXCIqXCIpIHJlc3VsdCA9IGNhbGNQcmV2VmFsdWUgKiBjdXJyZW50O1xyXG4gICAgICAgICAgICBpZiAoY2FsY09wZXJhdG9yID09PSBcIi9cIikgcmVzdWx0ID0gY2FsY1ByZXZWYWx1ZSAvIGN1cnJlbnQ7XHJcbiAgICAgICAgICAgIHNldENhbGNJbnB1dChwYXJzZUZsb2F0KHJlc3VsdC50b0ZpeGVkKDQpKS50b1N0cmluZygpKTtcclxuICAgICAgICAgICAgc2V0Q2FsY1ByZXZWYWx1ZShudWxsKTtcclxuICAgICAgICAgICAgc2V0Q2FsY09wZXJhdG9yKG51bGwpO1xyXG4gICAgICAgICAgICBzZXRDYWxjTmV3TnVtYmVyKHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1vZGFsLWJhY2tkcm9wIGlzLWNlbnRlclwiXHJcbiAgICAgICAgICAgIG9uTW91c2VEb3duPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKGUudGFyZ2V0ID09PSBlLmN1cnJlbnRUYXJnZXQpIG9uQ2xvc2UoKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgc3R5bGU9e3sgcG9zaXRpb246IFwiYWJzb2x1dGVcIiB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1wYW5lbCBpcy1jZW50ZXJcIiBzdHlsZT17eyB3aWR0aDogXCI5MCVcIiwgbWF4V2lkdGg6IFwiMzIwcHhcIiwgcGFkZGluZzogXCIyMHB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IFwiMTZweFwiLCBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiwgZm9udFdlaWdodDogXCJib2xkXCIgfX0+4p6XIENhbGN1bGFkb3JhPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1naG9zdCBidG4taWNvblwiIG9uQ2xpY2s9e29uQ2xvc2V9PuKclTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCJ2YXIoLS1iZy1ib2R5KVwiLCBib3JkZXI6IFwiMXB4IHNvbGlkIHZhcigtLWJvcmRlcilcIiwgYm9yZGVyUmFkaXVzOiBcIjhweFwiLCBwYWRkaW5nOiBcIjE2cHhcIiwgZm9udFNpemU6IFwiMnJlbVwiLCB0ZXh0QWxpZ246IFwicmlnaHRcIiwgbWFyZ2luQm90dG9tOiBcIjE2cHhcIiwgb3ZlcmZsb3c6IFwiaGlkZGVuXCIsIGNvbG9yOiBcInZhcigtLWluaylcIiwgZm9udFdlaWdodDogXCJib2xkXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAge2NhbGNJbnB1dH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCJyZXBlYXQoNCwgMWZyKVwiLCBnYXA6IFwiOHB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCIgc3R5bGU9e3sgZ3JpZENvbHVtbjogXCJzcGFuIDNcIiwgYmFja2dyb3VuZENvbG9yOiBcIiNmZWUyZTJcIiwgY29sb3I6IFwiI2I5MWMxY1wiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0gb25DbGljaz17KCkgPT4geyBzZXRDYWxjSW5wdXQoXCIwXCIpOyBzZXRDYWxjUHJldlZhbHVlKG51bGwpOyBzZXRDYWxjT3BlcmF0b3IobnVsbCk7IHNldENhbGNOZXdOdW1iZXIoZmFsc2UpOyB9fT5DPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcIiNlMGU3ZmZcIiwgY29sb3I6IFwiIzQzMzhjYVwiLCBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0gb25DbGljaz17KCkgPT4gaGFuZGxlQ2FsY09wKFwiL1wiKX0+w7c8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwidmFyKC0tYmctcmFpc2UpXCIsIGZvbnRTaXplOiBcIjEuMnJlbVwiIH19IG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhbGNOdW0oXCI3XCIpfT43PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcInZhcigtLWJnLXJhaXNlKVwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiB9fSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDYWxjTnVtKFwiOFwiKX0+ODwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCJ2YXIoLS1iZy1yYWlzZSlcIiwgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0gb25DbGljaz17KCkgPT4gaGFuZGxlQ2FsY051bShcIjlcIil9Pjk8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwiI2UwZTdmZlwiLCBjb2xvcjogXCIjNDMzOGNhXCIsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiB9fSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDYWxjT3AoXCIqXCIpfT7DlzwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCJ2YXIoLS1iZy1yYWlzZSlcIiwgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0gb25DbGljaz17KCkgPT4gaGFuZGxlQ2FsY051bShcIjRcIil9PjQ8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwidmFyKC0tYmctcmFpc2UpXCIsIGZvbnRTaXplOiBcIjEuMnJlbVwiIH19IG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhbGNOdW0oXCI1XCIpfT41PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcInZhcigtLWJnLXJhaXNlKVwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiB9fSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDYWxjTnVtKFwiNlwiKX0+NjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCIjZTBlN2ZmXCIsIGNvbG9yOiBcIiM0MzM4Y2FcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcIjEuNXJlbVwiIH19IG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhbGNPcChcIi1cIil9Pi08L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwidmFyKC0tYmctcmFpc2UpXCIsIGZvbnRTaXplOiBcIjEuMnJlbVwiIH19IG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhbGNOdW0oXCIxXCIpfT4xPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcInZhcigtLWJnLXJhaXNlKVwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiB9fSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDYWxjTnVtKFwiMlwiKX0+MjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCJ2YXIoLS1iZy1yYWlzZSlcIiwgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0gb25DbGljaz17KCkgPT4gaGFuZGxlQ2FsY051bShcIjNcIil9PjM8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tZ2hvc3RcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwiI2UwZTdmZlwiLCBjb2xvcjogXCIjNDMzOGNhXCIsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiB9fSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDYWxjT3AoXCIrXCIpfT4rPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLWdob3N0XCIgc3R5bGU9e3sgZ3JpZENvbHVtbjogXCJzcGFuIDJcIiwgYmFja2dyb3VuZENvbG9yOiBcInZhcigtLWJnLXJhaXNlKVwiLCBmb250U2l6ZTogXCIxLjJyZW1cIiB9fSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDYWxjTnVtKFwiMFwiKX0+MDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCJ2YXIoLS1iZy1yYWlzZSlcIiwgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcIjEuMnJlbVwiIH19IG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhbGNOdW0oXCIuXCIpfT4uPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwid2FpdGVyLWN0YVwiIHN0eWxlPXt7IG1hcmdpbjogMCwgZm9udFNpemU6IFwiMS4ycmVtXCIgfX0gb25DbGljaz17aGFuZGxlQ2FsY0VxdWFsfT49PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3dhaXRlci9jb21wb25lbnRzL21vZGFscy9DYWxjdWxhdG9yTW9kYWwudHN4In0=