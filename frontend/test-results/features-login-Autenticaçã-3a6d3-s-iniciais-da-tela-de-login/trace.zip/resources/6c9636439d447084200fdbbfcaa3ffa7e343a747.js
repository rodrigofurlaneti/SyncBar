import {
  require_react
} from "/node_modules/.vite/deps/chunk-HPDSNDDJ.js?v=ca0b4140";
import "/node_modules/.vite/deps/chunk-3O7X656O.js?v=ca0b4140";
export default require_react();
//# sourceMappingURL=react.js.map
