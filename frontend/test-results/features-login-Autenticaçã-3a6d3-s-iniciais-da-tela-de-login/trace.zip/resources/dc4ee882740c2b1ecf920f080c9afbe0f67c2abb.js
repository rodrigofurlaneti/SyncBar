import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/integrations/IFoodFinancialReportsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useMutation, useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import {
  IFOOD_FINANCIAL_REPORT_TYPES,
  getIFoodFinancialReport,
  getIFoodReconciliationOnDemandStatus,
  requestIFoodReconciliationOnDemand
} from "/src/features/integrations/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useToast } from "/src/ui/Toast.tsx";
import { Button } from "/src/ui/Button.tsx";
import { SelectField, TextField } from "/src/ui/Field.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { EmptyState } from "/src/ui/EmptyState.tsx";
const REPORT_LABELS = {
  SalesAdjustments: "Ajustes de vendas",
  Payments: "Pagamentos",
  PaymentDetails: "Detalhes de pagamento",
  Occurrences: "Ocorrências",
  MaintenanceFees: "Taxas de manutenção",
  IncomeTaxes: "Impostos de renda",
  Periods: "Períodos de apuração",
  ChargeCancellations: "Cancelamentos de cobrança",
  Cancellations: "Cancelamentos",
  ReceivableRecords: "Registros de recebíveis",
  SalesBenefits: "Benefícios em vendas",
  AdjustmentsBenefits: "Benefícios em ajustes",
  SalesV21: "Vendas (v2.1)",
  AnticipationsV3: "Antecipações",
  SalesV3: "Vendas (v3.0)"
};
function toInputDate(date) {
  return date.toISOString().slice(0, 10);
}
function prettyJson(raw) {
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch {
    return raw;
  }
}
export function IFoodFinancialReportsPage() {
  _s();
  const { branchId } = useAuthStore();
  const toast = useToast();
  const today = /* @__PURE__ */ new Date();
  const monthAgo = new Date(today);
  monthAgo.setDate(monthAgo.getDate() - 30);
  const [reportType, setReportType] = useState("SalesAdjustments");
  const [periodId, setPeriodId] = useState("");
  const [rangeStart, setRangeStart] = useState(toInputDate(monthAgo));
  const [rangeEnd, setRangeEnd] = useState(toInputDate(today));
  const [submitted, setSubmitted] = useState(
    null
  );
  const [competence, setCompetence] = useState(toInputDate(today).slice(0, 7));
  const [requestId, setRequestId] = useState("");
  const reportQuery = useQuery({
    queryKey: ["integrations", "ifood", "financial", "report", branchId, submitted],
    queryFn: () => getIFoodFinancialReport(branchId, submitted.reportType, {
      periodId: submitted.periodId || void 0,
      rangeStart: submitted.rangeStart || void 0,
      rangeEnd: submitted.rangeEnd || void 0
    }),
    enabled: !!submitted
  });
  const requestOnDemandMutation = useMutation({
    mutationFn: () => requestIFoodReconciliationOnDemand(branchId, competence),
    onSuccess: (data) => {
      setRequestId(data.requestId);
      toast.success(`Apuração solicitada. RequestId: ${data.requestId || "(veja o payload bruto)"}`);
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "Falha ao solicitar apuração.")
  });
  const statusQuery = useQuery({
    queryKey: ["integrations", "ifood", "financial", "reconciliation-status", branchId, requestId],
    queryFn: () => getIFoodReconciliationOnDemandStatus(branchId, requestId),
    enabled: false
  });
  const items = reportQuery.data?.items ?? [];
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1e3, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { marginBottom: 18 }, children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/integracoes/ifood", style: { color: "var(--ink-faint)", fontSize: "0.85rem" }, children: "← Integração iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
        lineNumber: 121,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Relatórios financeiros iFood" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
        lineNumber: 124,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "consulta direta aos relatórios do módulo Financial (v2.0/v2.1/v3.0) que não têm tela dedicada" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
        lineNumber: 127,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
      lineNumber: 120,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, marginBottom: 18, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV(
        SelectField,
        {
          label: "Relatório",
          value: reportType,
          onChange: (e) => setReportType(e.target.value),
          children: IFOOD_FINANCIAL_REPORT_TYPES.map(
            (type) => /* @__PURE__ */ jsxDEV("option", { value: type, children: REPORT_LABELS[type] }, type, false, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
              lineNumber: 139,
              columnNumber: 11
            }, this)
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
          lineNumber: 133,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 12, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Período/PeriodId (opcional)", value: periodId, onChange: (e) => setPeriodId(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
          lineNumber: 145,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "De", type: "date", value: rangeStart, onChange: (e) => setRangeStart(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
          lineNumber: 146,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Até", type: "date", value: rangeEnd, onChange: (e) => setRangeEnd(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
          lineNumber: 147,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => setSubmitted({ reportType, periodId, rangeStart, rangeEnd }), children: "Consultar" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
          lineNumber: 148,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
        lineNumber: 144,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
      lineNumber: 132,
      columnNumber: 7
    }, this),
    reportQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: reportQuery.error, what: "o relatório financeiro" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
      lineNumber: 154,
      columnNumber: 31
    }, this),
    submitted && !reportQuery.isLoading && items.length === 0 && !reportQuery.isError && /* @__PURE__ */ jsxDEV(EmptyState, { title: "Sem registros", description: "Nenhum registro devolvido pelo iFood pros filtros informados." }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
      lineNumber: 157,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 10, marginBottom: 24 }, children: items.map(
      (raw, index) => /* @__PURE__ */ jsxDEV(
        "pre",
        {
          className: "card",
          style: { padding: 12, fontSize: "0.8rem", overflowX: "auto", margin: 0, whiteSpace: "pre-wrap" },
          children: prettyJson(raw)
        },
        index,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
          lineNumber: 162,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card", style: { padding: 16, display: "grid", gap: 12 }, children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Apuração sob demanda (reconciliation on-demand)" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
        lineNumber: 173,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--ink-faint)" }, children: "use quando a apuração automática do período ainda não foi gerada pelo iFood." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
        lineNumber: 174,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ui-row ui-row-wrap", style: { gap: 12, alignItems: "flex-end" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Competência (yyyy-MM)", value: competence, onChange: (e) => setCompetence(e.target.value) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
          lineNumber: 178,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "primary", disabled: requestOnDemandMutation.isPending, onClick: () => requestOnDemandMutation.mutate(), children: "Solicitar apuração" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
          lineNumber: 179,
          columnNumber: 11
        }, this),
        requestId && /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => void statusQuery.refetch(), children: "Consultar status" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
          lineNumber: 183,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
        lineNumber: 177,
        columnNumber: 9
      }, this),
      statusQuery.data?.rawPayload && /* @__PURE__ */ jsxDEV("pre", { style: { fontSize: "0.8rem", whiteSpace: "pre-wrap", margin: 0 }, children: prettyJson(statusQuery.data.rawPayload) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
        lineNumber: 189,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
      lineNumber: 172,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx",
    lineNumber: 119,
    columnNumber: 5
  }, this);
}
_s(IFoodFinancialReportsPage, "P1/8JJtJ2hRfUBvuPP2y3WpGFNc=", false, function() {
  return [useAuthStore, useToast, useQuery, useMutation, useQuery];
});
_c = IFoodFinancialReportsPage;
var _c;
$RefreshReg$(_c, "IFoodFinancialReportsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/integrations/IFoodFinancialReportsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUdROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJHUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhQyxnQkFBZ0I7QUFDdEM7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUVLO0FBQ1AsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBTzNCLE1BQU1DLGdCQUEwRDtBQUFBLEVBQzlEQyxrQkFBa0I7QUFBQSxFQUNsQkMsVUFBVTtBQUFBLEVBQ1ZDLGdCQUFnQjtBQUFBLEVBQ2hCQyxhQUFhO0FBQUEsRUFDYkMsaUJBQWlCO0FBQUEsRUFDakJDLGFBQWE7QUFBQSxFQUNiQyxTQUFTO0FBQUEsRUFDVEMscUJBQXFCO0FBQUEsRUFDckJDLGVBQWU7QUFBQSxFQUNmQyxtQkFBbUI7QUFBQSxFQUNuQkMsZUFBZTtBQUFBLEVBQ2ZDLHFCQUFxQjtBQUFBLEVBQ3JCQyxVQUFVO0FBQUEsRUFDVkMsaUJBQWlCO0FBQUEsRUFDakJDLFNBQVM7QUFDWDtBQUVBLFNBQVNDLFlBQVlDLE1BQW9CO0FBQ3ZDLFNBQU9BLEtBQUtDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUU7QUFDdkM7QUFFQSxTQUFTQyxXQUFXQyxLQUFxQjtBQUN2QyxNQUFJO0FBQ0YsV0FBT0MsS0FBS0MsVUFBVUQsS0FBS0UsTUFBTUgsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUFBLEVBQ2hELFFBQVE7QUFDTixXQUFPQTtBQUFBQSxFQUNUO0FBQ0Y7QUFFTyxnQkFBU0ksNEJBQTRCO0FBQUFDLEtBQUE7QUFDMUMsUUFBTSxFQUFFQyxTQUFTLElBQUlsQyxhQUFhO0FBQ2xDLFFBQU1tQyxRQUFRbEMsU0FBUztBQUN2QixRQUFNbUMsUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFNQyxXQUFXLElBQUlELEtBQUtELEtBQUs7QUFDL0JFLFdBQVNDLFFBQVFELFNBQVNFLFFBQVEsSUFBSSxFQUFFO0FBRXhDLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJbEQsU0FBbUMsa0JBQWtCO0FBQ3pGLFFBQU0sQ0FBQ21ELFVBQVVDLFdBQVcsSUFBSXBELFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNxRCxZQUFZQyxhQUFhLElBQUl0RCxTQUFTK0IsWUFBWWUsUUFBUSxDQUFDO0FBQ2xFLFFBQU0sQ0FBQ1MsVUFBVUMsV0FBVyxJQUFJeEQsU0FBUytCLFlBQVlhLEtBQUssQ0FBQztBQUMzRCxRQUFNLENBQUNhLFdBQVdDLFlBQVksSUFBSTFEO0FBQUFBLElBQ2hDO0FBQUEsRUFDRjtBQUVBLFFBQU0sQ0FBQzJELFlBQVlDLGFBQWEsSUFBSTVELFNBQVMrQixZQUFZYSxLQUFLLEVBQUVWLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDM0UsUUFBTSxDQUFDMkIsV0FBV0MsWUFBWSxJQUFJOUQsU0FBUyxFQUFFO0FBRTdDLFFBQU0rRCxjQUFjNUQsU0FBUztBQUFBLElBQzNCNkQsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGFBQWEsVUFBVXRCLFVBQVVlLFNBQVM7QUFBQSxJQUM5RVEsU0FBU0EsTUFDUDVELHdCQUF3QnFDLFVBQVVlLFVBQVdSLFlBQVk7QUFBQSxNQUN2REUsVUFBVU0sVUFBV04sWUFBWWU7QUFBQUEsTUFDakNiLFlBQVlJLFVBQVdKLGNBQWNhO0FBQUFBLE1BQ3JDWCxVQUFVRSxVQUFXRixZQUFZVztBQUFBQSxJQUNuQyxDQUFDO0FBQUEsSUFDSEMsU0FBUyxDQUFDLENBQUNWO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1XLDBCQUEwQmxFLFlBQVk7QUFBQSxJQUMxQ21FLFlBQVlBLE1BQU05RCxtQ0FBbUNtQyxVQUFVaUIsVUFBVTtBQUFBLElBQ3pFVyxXQUFXQSxDQUFDQyxTQUFTO0FBQ25CVCxtQkFBYVMsS0FBS1YsU0FBUztBQUMzQmxCLFlBQU02QixRQUFRLG1DQUFtQ0QsS0FBS1YsYUFBYSx3QkFBd0IsRUFBRTtBQUFBLElBQy9GO0FBQUEsSUFDQVksU0FBU0EsQ0FBQ0MsVUFBbUIvQixNQUFNK0IsTUFBTUEsaUJBQWlCQyxRQUFRRCxNQUFNRSxVQUFVLDhCQUE4QjtBQUFBLEVBQ2xILENBQUM7QUFFRCxRQUFNQyxjQUFjMUUsU0FBUztBQUFBLElBQzNCNkQsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGFBQWEseUJBQXlCdEIsVUFBVW1CLFNBQVM7QUFBQSxJQUM3RkksU0FBU0EsTUFBTTNELHFDQUFxQ29DLFVBQVVtQixTQUFTO0FBQUEsSUFDdkVNLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNVyxRQUFRZixZQUFZUSxNQUFNTyxTQUFTO0FBRXpDLFNBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLFNBQVMsSUFBSUMsVUFBVSxLQUFNQyxRQUFRLFNBQVMsR0FDM0Q7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVDLGNBQWMsR0FBRyxHQUM5QztBQUFBLDZCQUFDLFFBQUssSUFBRyxzQkFBcUIsT0FBTyxFQUFFQyxPQUFPLG9CQUFvQkMsVUFBVSxVQUFVLEdBQUcsa0NBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBRyxXQUFVLFdBQVUsT0FBTyxFQUFFQSxVQUFVLFNBQVMsR0FBRyw0Q0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRUQsT0FBTyxvQkFBb0JDLFVBQVUsU0FBUyxHQUFHLDZHQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFTCxTQUFTLElBQUlHLGNBQWMsSUFBSUcsU0FBUyxRQUFRQyxLQUFLLEdBQUcsR0FDckY7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sT0FBT3JDO0FBQUFBLFVBQ1AsVUFBVSxDQUFDc0MsTUFBTXJDLGNBQWNxQyxFQUFFQyxPQUFPQyxLQUFpQztBQUFBLFVBRXhFckYsdUNBQTZCc0Y7QUFBQUEsWUFBSSxDQUFDQyxTQUNqQyx1QkFBQyxZQUFrQixPQUFPQSxNQUN2QjVFLHdCQUFjNEUsSUFBSSxLQURSQSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNEO0FBQUE7QUFBQSxRQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUwsS0FBSyxJQUFJTSxZQUFZLFdBQVcsR0FDM0U7QUFBQSwrQkFBQyxhQUFVLE9BQU0sK0JBQThCLE9BQU96QyxVQUFVLFVBQVUsQ0FBQ29DLE1BQU1uQyxZQUFZbUMsRUFBRUMsT0FBT0MsS0FBSyxLQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZHO0FBQUEsUUFDN0csdUJBQUMsYUFBVSxPQUFNLE1BQUssTUFBSyxRQUFPLE9BQU9wQyxZQUFZLFVBQVUsQ0FBQ2tDLE1BQU1qQyxjQUFjaUMsRUFBRUMsT0FBT0MsS0FBSyxLQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9HO0FBQUEsUUFDcEcsdUJBQUMsYUFBVSxPQUFNLE9BQU0sTUFBSyxRQUFPLE9BQU9sQyxVQUFVLFVBQVUsQ0FBQ2dDLE1BQU0vQixZQUFZK0IsRUFBRUMsT0FBT0MsS0FBSyxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlHO0FBQUEsUUFDakcsdUJBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNL0IsYUFBYSxFQUFFVCxZQUFZRSxVQUFVRSxZQUFZRSxTQUFTLENBQUMsR0FBRyx5QkFBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFFQ1EsWUFBWThCLFdBQVcsdUJBQUMsY0FBVyxPQUFPOUIsWUFBWVcsT0FBTyxNQUFLLDRCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1FO0FBQUEsSUFFMUZqQixhQUFhLENBQUNNLFlBQVkrQixhQUFhaEIsTUFBTWlCLFdBQVcsS0FBSyxDQUFDaEMsWUFBWThCLFdBQ3pFLHVCQUFDLGNBQVcsT0FBTSxpQkFBZ0IsYUFBWSxtRUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RztBQUFBLElBRy9HLHVCQUFDLFNBQUksT0FBTyxFQUFFUixTQUFTLFFBQVFDLEtBQUssSUFBSUosY0FBYyxHQUFHLEdBQ3RESixnQkFBTVk7QUFBQUEsTUFBSSxDQUFDdEQsS0FBSzRELFVBQ2Y7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFdBQVU7QUFBQSxVQUNWLE9BQU8sRUFBRWpCLFNBQVMsSUFBSUssVUFBVSxVQUFVYSxXQUFXLFFBQVFoQixRQUFRLEdBQUdpQixZQUFZLFdBQVc7QUFBQSxVQUU5Ri9ELHFCQUFXQyxHQUFHO0FBQUE7QUFBQSxRQUpWNEQ7QUFBQUEsUUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxJQUNELEtBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVqQixTQUFTLElBQUlNLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ25FO0FBQUEsNkJBQUMsWUFBTywrREFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVEO0FBQUEsTUFDdkQsdUJBQUMsVUFBSyxPQUFPLEVBQUVGLFVBQVUsV0FBV0QsT0FBTyxtQkFBbUIsR0FBRyw0RkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUcsS0FBSyxJQUFJTSxZQUFZLFdBQVcsR0FDM0U7QUFBQSwrQkFBQyxhQUFVLE9BQU0seUJBQXdCLE9BQU9qQyxZQUFZLFVBQVUsQ0FBQzRCLE1BQU0zQixjQUFjMkIsRUFBRUMsT0FBT0MsS0FBSyxLQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJHO0FBQUEsUUFDM0csdUJBQUMsVUFBTyxTQUFRLFdBQVUsVUFBVXJCLHdCQUF3QitCLFdBQVcsU0FBUyxNQUFNL0Isd0JBQXdCZ0MsT0FBTyxHQUFHLGtDQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDdkMsYUFDQyx1QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTLE1BQU0sS0FBS2dCLFlBQVl3QixRQUFRLEdBQUcsZ0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQ3hCLFlBQVlOLE1BQU0rQixjQUNqQix1QkFBQyxTQUFJLE9BQU8sRUFBRWxCLFVBQVUsVUFBVWMsWUFBWSxZQUFZakIsUUFBUSxFQUFFLEdBQUk5QyxxQkFBVzBDLFlBQVlOLEtBQUsrQixVQUFVLEtBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0g7QUFBQSxTQWpCcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLE9BeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RUE7QUFFSjtBQUFDN0QsR0ExSGVELDJCQUF5QjtBQUFBLFVBQ2xCaEMsY0FDUEMsVUFnQk1OLFVBV1lELGFBU1pDLFFBQVE7QUFBQTtBQUFBLEtBdENkcUM7QUFBeUIsSUFBQStEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJJRk9PRF9GSU5BTkNJQUxfUkVQT1JUX1RZUEVTIiwiZ2V0SUZvb2RGaW5hbmNpYWxSZXBvcnQiLCJnZXRJRm9vZFJlY29uY2lsaWF0aW9uT25EZW1hbmRTdGF0dXMiLCJyZXF1ZXN0SUZvb2RSZWNvbmNpbGlhdGlvbk9uRGVtYW5kIiwidXNlQXV0aFN0b3JlIiwidXNlVG9hc3QiLCJCdXR0b24iLCJTZWxlY3RGaWVsZCIsIlRleHRGaWVsZCIsIlF1ZXJ5RXJyb3IiLCJFbXB0eVN0YXRlIiwiUkVQT1JUX0xBQkVMUyIsIlNhbGVzQWRqdXN0bWVudHMiLCJQYXltZW50cyIsIlBheW1lbnREZXRhaWxzIiwiT2NjdXJyZW5jZXMiLCJNYWludGVuYW5jZUZlZXMiLCJJbmNvbWVUYXhlcyIsIlBlcmlvZHMiLCJDaGFyZ2VDYW5jZWxsYXRpb25zIiwiQ2FuY2VsbGF0aW9ucyIsIlJlY2VpdmFibGVSZWNvcmRzIiwiU2FsZXNCZW5lZml0cyIsIkFkanVzdG1lbnRzQmVuZWZpdHMiLCJTYWxlc1YyMSIsIkFudGljaXBhdGlvbnNWMyIsIlNhbGVzVjMiLCJ0b0lucHV0RGF0ZSIsImRhdGUiLCJ0b0lTT1N0cmluZyIsInNsaWNlIiwicHJldHR5SnNvbiIsInJhdyIsIkpTT04iLCJzdHJpbmdpZnkiLCJwYXJzZSIsIklGb29kRmluYW5jaWFsUmVwb3J0c1BhZ2UiLCJfcyIsImJyYW5jaElkIiwidG9hc3QiLCJ0b2RheSIsIkRhdGUiLCJtb250aEFnbyIsInNldERhdGUiLCJnZXREYXRlIiwicmVwb3J0VHlwZSIsInNldFJlcG9ydFR5cGUiLCJwZXJpb2RJZCIsInNldFBlcmlvZElkIiwicmFuZ2VTdGFydCIsInNldFJhbmdlU3RhcnQiLCJyYW5nZUVuZCIsInNldFJhbmdlRW5kIiwic3VibWl0dGVkIiwic2V0U3VibWl0dGVkIiwiY29tcGV0ZW5jZSIsInNldENvbXBldGVuY2UiLCJyZXF1ZXN0SWQiLCJzZXRSZXF1ZXN0SWQiLCJyZXBvcnRRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInVuZGVmaW5lZCIsImVuYWJsZWQiLCJyZXF1ZXN0T25EZW1hbmRNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJvblN1Y2Nlc3MiLCJkYXRhIiwic3VjY2VzcyIsIm9uRXJyb3IiLCJlcnJvciIsIkVycm9yIiwibWVzc2FnZSIsInN0YXR1c1F1ZXJ5IiwiaXRlbXMiLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJtYXJnaW5Cb3R0b20iLCJjb2xvciIsImZvbnRTaXplIiwiZGlzcGxheSIsImdhcCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1hcCIsInR5cGUiLCJhbGlnbkl0ZW1zIiwiaXNFcnJvciIsImlzTG9hZGluZyIsImxlbmd0aCIsImluZGV4Iiwib3ZlcmZsb3dYIiwid2hpdGVTcGFjZSIsImlzUGVuZGluZyIsIm11dGF0ZSIsInJlZmV0Y2giLCJyYXdQYXlsb2FkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSUZvb2RGaW5hbmNpYWxSZXBvcnRzUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHtcclxuICBJRk9PRF9GSU5BTkNJQUxfUkVQT1JUX1RZUEVTLFxyXG4gIGdldElGb29kRmluYW5jaWFsUmVwb3J0LFxyXG4gIGdldElGb29kUmVjb25jaWxpYXRpb25PbkRlbWFuZFN0YXR1cyxcclxuICByZXF1ZXN0SUZvb2RSZWNvbmNpbGlhdGlvbk9uRGVtYW5kLFxyXG4gIHR5cGUgSUZvb2RGaW5hbmNpYWxSZXBvcnRUeXBlLFxyXG59IGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoU3RvcmUgfSBmcm9tIFwiLi4vLi4vc3RvcmVzL2F1dGhTdG9yZVwiO1xyXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi8uLi91aS9Ub2FzdFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vLi4vdWkvQnV0dG9uXCI7XHJcbmltcG9ydCB7IFNlbGVjdEZpZWxkLCBUZXh0RmllbGQgfSBmcm9tIFwiLi4vLi4vdWkvRmllbGRcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCIuLi8uLi91aS9FbXB0eVN0YXRlXCI7XHJcblxyXG4vLyBGYXNlIDkg4oCUIFJlbGF0w7NyaW9zIGZpbmFuY2Vpcm9zOiBjYXTDoWxvZ28gZ2Vuw6lyaWNvIGRvcyAxMyByZWxhdMOzcmlvcyByZXN0YW50ZXMgZG8gbcOzZHVsb1xyXG4vLyBGaW5hbmNpYWwgKGZpbmFuY2lhbC92Mi4wIMOXMTIgKyBmaW5hbmNpYWwvdjIuMSDDlzEpICsgYW50aWNpcGF0aW9ucy9zYWxlcyAoZmluYW5jaWFsL3YzLjApLlxyXG4vLyBBIGRvYyBvZmljaWFsIG7Do28gZG9jdW1lbnRhIG8gc2NoZW1hIGRlIHJlc3Bvc3RhIGNhbXBvLWEtY2FtcG8gcHJhIGVzdGVzIHJlbGF0w7NyaW9zLCBlbnTDo29cclxuLy8gZXN0YSB0ZWxhIG1vc3RyYSBvIEpTT04gYnJ1dG8gZGUgY2FkYSByZWdpc3RybyAodmVyIGNvbWVudMOhcmlvIG5vIGJhY2tlbmQsXHJcbi8vIElJRm9vZEZpbmFuY2lhbENsaWVudCkg4oCUIMOpIHVtYSB0ZWxhIGRlIGF1ZGl0b3JpYS9leHBvcnRhw6fDo28sIG7Do28gdW0gZGFzaGJvYXJkIHRyYXRhZG8uXHJcbmNvbnN0IFJFUE9SVF9MQUJFTFM6IFJlY29yZDxJRm9vZEZpbmFuY2lhbFJlcG9ydFR5cGUsIHN0cmluZz4gPSB7XHJcbiAgU2FsZXNBZGp1c3RtZW50czogXCJBanVzdGVzIGRlIHZlbmRhc1wiLFxyXG4gIFBheW1lbnRzOiBcIlBhZ2FtZW50b3NcIixcclxuICBQYXltZW50RGV0YWlsczogXCJEZXRhbGhlcyBkZSBwYWdhbWVudG9cIixcclxuICBPY2N1cnJlbmNlczogXCJPY29ycsOqbmNpYXNcIixcclxuICBNYWludGVuYW5jZUZlZXM6IFwiVGF4YXMgZGUgbWFudXRlbsOnw6NvXCIsXHJcbiAgSW5jb21lVGF4ZXM6IFwiSW1wb3N0b3MgZGUgcmVuZGFcIixcclxuICBQZXJpb2RzOiBcIlBlcsOtb2RvcyBkZSBhcHVyYcOnw6NvXCIsXHJcbiAgQ2hhcmdlQ2FuY2VsbGF0aW9uczogXCJDYW5jZWxhbWVudG9zIGRlIGNvYnJhbsOnYVwiLFxyXG4gIENhbmNlbGxhdGlvbnM6IFwiQ2FuY2VsYW1lbnRvc1wiLFxyXG4gIFJlY2VpdmFibGVSZWNvcmRzOiBcIlJlZ2lzdHJvcyBkZSByZWNlYsOtdmVpc1wiLFxyXG4gIFNhbGVzQmVuZWZpdHM6IFwiQmVuZWbDrWNpb3MgZW0gdmVuZGFzXCIsXHJcbiAgQWRqdXN0bWVudHNCZW5lZml0czogXCJCZW5lZsOtY2lvcyBlbSBhanVzdGVzXCIsXHJcbiAgU2FsZXNWMjE6IFwiVmVuZGFzICh2Mi4xKVwiLFxyXG4gIEFudGljaXBhdGlvbnNWMzogXCJBbnRlY2lwYcOnw7Vlc1wiLFxyXG4gIFNhbGVzVjM6IFwiVmVuZGFzICh2My4wKVwiLFxyXG59O1xyXG5cclxuZnVuY3Rpb24gdG9JbnB1dERhdGUoZGF0ZTogRGF0ZSk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHByZXR0eUpzb24ocmF3OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIHRyeSB7XHJcbiAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoSlNPTi5wYXJzZShyYXcpLCBudWxsLCAyKTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiByYXc7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gSUZvb2RGaW5hbmNpYWxSZXBvcnRzUGFnZSgpIHtcclxuICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IG1vbnRoQWdvID0gbmV3IERhdGUodG9kYXkpO1xyXG4gIG1vbnRoQWdvLnNldERhdGUobW9udGhBZ28uZ2V0RGF0ZSgpIC0gMzApO1xyXG5cclxuICBjb25zdCBbcmVwb3J0VHlwZSwgc2V0UmVwb3J0VHlwZV0gPSB1c2VTdGF0ZTxJRm9vZEZpbmFuY2lhbFJlcG9ydFR5cGU+KFwiU2FsZXNBZGp1c3RtZW50c1wiKTtcclxuICBjb25zdCBbcGVyaW9kSWQsIHNldFBlcmlvZElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyYW5nZVN0YXJ0LCBzZXRSYW5nZVN0YXJ0XSA9IHVzZVN0YXRlKHRvSW5wdXREYXRlKG1vbnRoQWdvKSk7XHJcbiAgY29uc3QgW3JhbmdlRW5kLCBzZXRSYW5nZUVuZF0gPSB1c2VTdGF0ZSh0b0lucHV0RGF0ZSh0b2RheSkpO1xyXG4gIGNvbnN0IFtzdWJtaXR0ZWQsIHNldFN1Ym1pdHRlZF0gPSB1c2VTdGF0ZTx7IHJlcG9ydFR5cGU6IElGb29kRmluYW5jaWFsUmVwb3J0VHlwZTsgcGVyaW9kSWQ6IHN0cmluZzsgcmFuZ2VTdGFydDogc3RyaW5nOyByYW5nZUVuZDogc3RyaW5nIH0gfCBudWxsPihcclxuICAgIG51bGwsXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgW2NvbXBldGVuY2UsIHNldENvbXBldGVuY2VdID0gdXNlU3RhdGUodG9JbnB1dERhdGUodG9kYXkpLnNsaWNlKDAsIDcpKTtcclxuICBjb25zdCBbcmVxdWVzdElkLCBzZXRSZXF1ZXN0SWRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IHJlcG9ydFF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFtcImludGVncmF0aW9uc1wiLCBcImlmb29kXCIsIFwiZmluYW5jaWFsXCIsIFwicmVwb3J0XCIsIGJyYW5jaElkLCBzdWJtaXR0ZWRdLFxyXG4gICAgcXVlcnlGbjogKCkgPT5cclxuICAgICAgZ2V0SUZvb2RGaW5hbmNpYWxSZXBvcnQoYnJhbmNoSWQsIHN1Ym1pdHRlZCEucmVwb3J0VHlwZSwge1xyXG4gICAgICAgIHBlcmlvZElkOiBzdWJtaXR0ZWQhLnBlcmlvZElkIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICByYW5nZVN0YXJ0OiBzdWJtaXR0ZWQhLnJhbmdlU3RhcnQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHJhbmdlRW5kOiBzdWJtaXR0ZWQhLnJhbmdlRW5kIHx8IHVuZGVmaW5lZCxcclxuICAgICAgfSksXHJcbiAgICBlbmFibGVkOiAhIXN1Ym1pdHRlZCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcmVxdWVzdE9uRGVtYW5kTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiAoKSA9PiByZXF1ZXN0SUZvb2RSZWNvbmNpbGlhdGlvbk9uRGVtYW5kKGJyYW5jaElkLCBjb21wZXRlbmNlKSxcclxuICAgIG9uU3VjY2VzczogKGRhdGEpID0+IHtcclxuICAgICAgc2V0UmVxdWVzdElkKGRhdGEucmVxdWVzdElkKTtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhgQXB1cmHDp8OjbyBzb2xpY2l0YWRhLiBSZXF1ZXN0SWQ6ICR7ZGF0YS5yZXF1ZXN0SWQgfHwgXCIodmVqYSBvIHBheWxvYWQgYnJ1dG8pXCJ9YCk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKGVycm9yOiB1bmtub3duKSA9PiB0b2FzdC5lcnJvcihlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiRmFsaGEgYW8gc29saWNpdGFyIGFwdXJhw6fDo28uXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBzdGF0dXNRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJpbnRlZ3JhdGlvbnNcIiwgXCJpZm9vZFwiLCBcImZpbmFuY2lhbFwiLCBcInJlY29uY2lsaWF0aW9uLXN0YXR1c1wiLCBicmFuY2hJZCwgcmVxdWVzdElkXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldElGb29kUmVjb25jaWxpYXRpb25PbkRlbWFuZFN0YXR1cyhicmFuY2hJZCwgcmVxdWVzdElkKSxcclxuICAgIGVuYWJsZWQ6IGZhbHNlLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBpdGVtcyA9IHJlcG9ydFF1ZXJ5LmRhdGE/Lml0ZW1zID8/IFtdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMDAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMTggfX0+XHJcbiAgICAgICAgPExpbmsgdG89XCIvaW50ZWdyYWNvZXMvaWZvb2RcIiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5cclxuICAgICAgICAgIOKGkCBJbnRlZ3Jhw6fDo28gaUZvb2RcclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjdyZW1cIiB9fT5cclxuICAgICAgICAgIFJlbGF0w7NyaW9zIGZpbmFuY2Vpcm9zIGlGb29kXHJcbiAgICAgICAgPC9oMj5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgY29uc3VsdGEgZGlyZXRhIGFvcyByZWxhdMOzcmlvcyBkbyBtw7NkdWxvIEZpbmFuY2lhbCAodjIuMC92Mi4xL3YzLjApIHF1ZSBuw6NvIHTDqm0gdGVsYSBkZWRpY2FkYVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAxNiwgbWFyZ2luQm90dG9tOiAxOCwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMTIgfX0+XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkXHJcbiAgICAgICAgICBsYWJlbD1cIlJlbGF0w7NyaW9cIlxyXG4gICAgICAgICAgdmFsdWU9e3JlcG9ydFR5cGV9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlcG9ydFR5cGUoZS50YXJnZXQudmFsdWUgYXMgSUZvb2RGaW5hbmNpYWxSZXBvcnRUeXBlKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7SUZPT0RfRklOQU5DSUFMX1JFUE9SVF9UWVBFUy5tYXAoKHR5cGUpID0+IChcclxuICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3R5cGV9IHZhbHVlPXt0eXBlfT5cclxuICAgICAgICAgICAgICB7UkVQT1JUX0xBQkVMU1t0eXBlXX1cclxuICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L1NlbGVjdEZpZWxkPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidWktcm93IHVpLXJvdy13cmFwXCIgc3R5bGU9e3sgZ2FwOiAxMiwgYWxpZ25JdGVtczogXCJmbGV4LWVuZFwiIH19PlxyXG4gICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlBlcsOtb2RvL1BlcmlvZElkIChvcGNpb25hbClcIiB2YWx1ZT17cGVyaW9kSWR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGVyaW9kSWQoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkRlXCIgdHlwZT1cImRhdGVcIiB2YWx1ZT17cmFuZ2VTdGFydH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRSYW5nZVN0YXJ0KGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJBdMOpXCIgdHlwZT1cImRhdGVcIiB2YWx1ZT17cmFuZ2VFbmR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmFuZ2VFbmQoZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIG9uQ2xpY2s9eygpID0+IHNldFN1Ym1pdHRlZCh7IHJlcG9ydFR5cGUsIHBlcmlvZElkLCByYW5nZVN0YXJ0LCByYW5nZUVuZCB9KX0+XHJcbiAgICAgICAgICAgIENvbnN1bHRhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge3JlcG9ydFF1ZXJ5LmlzRXJyb3IgJiYgPFF1ZXJ5RXJyb3IgZXJyb3I9e3JlcG9ydFF1ZXJ5LmVycm9yfSB3aGF0PVwibyByZWxhdMOzcmlvIGZpbmFuY2Vpcm9cIiAvPn1cclxuXHJcbiAgICAgIHtzdWJtaXR0ZWQgJiYgIXJlcG9ydFF1ZXJ5LmlzTG9hZGluZyAmJiBpdGVtcy5sZW5ndGggPT09IDAgJiYgIXJlcG9ydFF1ZXJ5LmlzRXJyb3IgJiYgKFxyXG4gICAgICAgIDxFbXB0eVN0YXRlIHRpdGxlPVwiU2VtIHJlZ2lzdHJvc1wiIGRlc2NyaXB0aW9uPVwiTmVuaHVtIHJlZ2lzdHJvIGRldm9sdmlkbyBwZWxvIGlGb29kIHByb3MgZmlsdHJvcyBpbmZvcm1hZG9zLlwiIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDEwLCBtYXJnaW5Cb3R0b206IDI0IH19PlxyXG4gICAgICAgIHtpdGVtcy5tYXAoKHJhdywgaW5kZXgpID0+IChcclxuICAgICAgICAgIDxwcmVcclxuICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2FyZFwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IDEyLCBmb250U2l6ZTogXCIwLjhyZW1cIiwgb3ZlcmZsb3dYOiBcImF1dG9cIiwgbWFyZ2luOiAwLCB3aGl0ZVNwYWNlOiBcInByZS13cmFwXCIgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3ByZXR0eUpzb24ocmF3KX1cclxuICAgICAgICAgIDwvcHJlPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6IDE2LCBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxMiB9fT5cclxuICAgICAgICA8c3Ryb25nPkFwdXJhw6fDo28gc29iIGRlbWFuZGEgKHJlY29uY2lsaWF0aW9uIG9uLWRlbWFuZCk8L3N0cm9uZz5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjg1cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT5cclxuICAgICAgICAgIHVzZSBxdWFuZG8gYSBhcHVyYcOnw6NvIGF1dG9tw6F0aWNhIGRvIHBlcsOtb2RvIGFpbmRhIG7Do28gZm9pIGdlcmFkYSBwZWxvIGlGb29kLlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVpLXJvdyB1aS1yb3ctd3JhcFwiIHN0eWxlPXt7IGdhcDogMTIsIGFsaWduSXRlbXM6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJDb21wZXTDqm5jaWEgKHl5eXktTU0pXCIgdmFsdWU9e2NvbXBldGVuY2V9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29tcGV0ZW5jZShlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgZGlzYWJsZWQ9e3JlcXVlc3RPbkRlbWFuZE11dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gcmVxdWVzdE9uRGVtYW5kTXV0YXRpb24ubXV0YXRlKCl9PlxyXG4gICAgICAgICAgICBTb2xpY2l0YXIgYXB1cmHDp8Ojb1xyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICB7cmVxdWVzdElkICYmIChcclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIHN0YXR1c1F1ZXJ5LnJlZmV0Y2goKX0+XHJcbiAgICAgICAgICAgICAgQ29uc3VsdGFyIHN0YXR1c1xyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge3N0YXR1c1F1ZXJ5LmRhdGE/LnJhd1BheWxvYWQgJiYgKFxyXG4gICAgICAgICAgPHByZSBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgd2hpdGVTcGFjZTogXCJwcmUtd3JhcFwiLCBtYXJnaW46IDAgfX0+e3ByZXR0eUpzb24oc3RhdHVzUXVlcnkuZGF0YS5yYXdQYXlsb2FkKX08L3ByZT5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy9mZWF0dXJlcy9pbnRlZ3JhdGlvbnMvSUZvb2RGaW5hbmNpYWxSZXBvcnRzUGFnZS50c3gifQ==