import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MetricsRow.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function MetricsRow({ metric, value, change, unit = "", icon }) {
  const isPositive = change !== void 0 && change >= 0;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "8px 0",
        borderBottom: "1px solid var(--border)"
      },
      children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 8 }, children: [
          icon && /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.2rem" }, children: icon }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx",
            lineNumber: 44,
            columnNumber: 18
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: metric }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx",
            lineNumber: 45,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx",
          lineNumber: 43,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 8, justifyContent: "flex-end" }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 700, fontSize: "1.1rem" }, children: [
            value,
            unit && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
              " ",
              unit
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx",
              lineNumber: 50,
              columnNumber: 20
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx",
            lineNumber: 48,
            columnNumber: 9
          }, this),
          change !== void 0 && /* @__PURE__ */ jsxDEV(
            "span",
            {
              style: {
                fontSize: "0.8rem",
                padding: "2px 6px",
                borderRadius: 3,
                background: isPositive ? "#e8f5e9" : "#ffebee",
                color: isPositive ? "#1b5e20" : "#b71c1c",
                fontWeight: 600,
                minWidth: 50,
                textAlign: "center"
              },
              children: [
                isPositive ? "+" : "",
                change.toFixed(1),
                "%"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx",
              lineNumber: 53,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx",
          lineNumber: 47,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx",
      lineNumber: 34,
      columnNumber: 5
    },
    this
  );
}
_c = MetricsRow;
var _c;
$RefreshReg$(_c, "MetricsRow");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/components/MetricsRow.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JpQjs7Ozs7Ozs7Ozs7Ozs7OztBQWRWLGdCQUFTQSxXQUFXLEVBQUVDLFFBQVFDLE9BQU9DLFFBQVFDLE9BQU8sSUFBSUMsS0FBc0IsR0FBRztBQUN0RixRQUFNQyxhQUFhSCxXQUFXSSxVQUFhSixVQUFVO0FBRXJELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE9BQU87QUFBQSxRQUNMSyxTQUFTO0FBQUEsUUFDVEMsZ0JBQWdCO0FBQUEsUUFDaEJDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsY0FBYztBQUFBLE1BQ2hCO0FBQUEsTUFFQTtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFSixTQUFTLFFBQVFFLFlBQVksVUFBVUcsS0FBSyxFQUFFLEdBQ3pEUjtBQUFBQSxrQkFBUSx1QkFBQyxTQUFJLE9BQU8sRUFBRVMsVUFBVSxTQUFTLEdBQUlULGtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQztBQUFBLFVBQ25ELHVCQUFDLFVBQUssT0FBTyxFQUFFVSxPQUFPLG9CQUFvQkQsVUFBVSxTQUFTLEdBQUliLG9CQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLGFBRjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVPLFNBQVMsUUFBUUUsWUFBWSxVQUFVRyxLQUFLLEdBQUdKLGdCQUFnQixXQUFXLEdBQ3RGO0FBQUEsaUNBQUMsVUFBSyxPQUFPLEVBQUVPLFlBQVksS0FBS0YsVUFBVSxTQUFTLEdBQ2hEWjtBQUFBQTtBQUFBQSxZQUNBRSxRQUFRLHVCQUFDLFVBQUssT0FBTyxFQUFFVSxVQUFVLFVBQVVDLE9BQU8sbUJBQW1CLEdBQUc7QUFBQTtBQUFBLGNBQUVYO0FBQUFBLGlCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLGVBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNDRCxXQUFXSSxVQUNWO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPO0FBQUEsZ0JBQ0xPLFVBQVU7QUFBQSxnQkFDVkgsU0FBUztBQUFBLGdCQUNUTSxjQUFjO0FBQUEsZ0JBQ2RDLFlBQVlaLGFBQWEsWUFBWTtBQUFBLGdCQUNyQ1MsT0FBT1QsYUFBYSxZQUFZO0FBQUEsZ0JBQ2hDVSxZQUFZO0FBQUEsZ0JBQ1pHLFVBQVU7QUFBQSxnQkFDVkMsV0FBVztBQUFBLGNBQ2I7QUFBQSxjQUVDZDtBQUFBQSw2QkFBYSxNQUFNO0FBQUEsZ0JBQUlILE9BQU9rQixRQUFRLENBQUM7QUFBQSxnQkFBRTtBQUFBO0FBQUE7QUFBQSxZQVo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLGFBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQTtBQUFBO0FBQUEsSUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBbUNBO0FBRUo7QUFBQ0MsS0F6Q2V0QjtBQUFVLElBQUFzQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJNZXRyaWNzUm93IiwibWV0cmljIiwidmFsdWUiLCJjaGFuZ2UiLCJ1bml0IiwiaWNvbiIsImlzUG9zaXRpdmUiLCJ1bmRlZmluZWQiLCJkaXNwbGF5IiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwicGFkZGluZyIsImJvcmRlckJvdHRvbSIsImdhcCIsImZvbnRTaXplIiwiY29sb3IiLCJmb250V2VpZ2h0IiwiYm9yZGVyUmFkaXVzIiwiYmFja2dyb3VuZCIsIm1pbldpZHRoIiwidGV4dEFsaWduIiwidG9GaXhlZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1ldHJpY3NSb3cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5pbnRlcmZhY2UgTWV0cmljc1Jvd1Byb3BzIHtcclxuICBtZXRyaWM6IHN0cmluZztcclxuICB2YWx1ZTogUmVhY3ROb2RlO1xyXG4gIGNoYW5nZT86IG51bWJlcjtcclxuICB1bml0Pzogc3RyaW5nO1xyXG4gIGljb24/OiBSZWFjdE5vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBNZXRyaWNzUm93KHsgbWV0cmljLCB2YWx1ZSwgY2hhbmdlLCB1bml0ID0gXCJcIiwgaWNvbiB9OiBNZXRyaWNzUm93UHJvcHMpIHtcclxuICBjb25zdCBpc1Bvc2l0aXZlID0gY2hhbmdlICE9PSB1bmRlZmluZWQgJiYgY2hhbmdlID49IDA7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxyXG4gICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgcGFkZGluZzogXCI4cHggMFwiLFxyXG4gICAgICAgIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgdmFyKC0tYm9yZGVyKVwiLFxyXG4gICAgICB9fVxyXG4gICAgPlxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDggfX0+XHJcbiAgICAgICAge2ljb24gJiYgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjJyZW1cIiB9fT57aWNvbn08L2Rpdj59XHJcbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjlyZW1cIiB9fT57bWV0cmljfTwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGdhcDogOCwganVzdGlmeUNvbnRlbnQ6IFwiZmxleC1lbmRcIiB9fT5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA3MDAsIGZvbnRTaXplOiBcIjEuMXJlbVwiIH19PlxyXG4gICAgICAgICAge3ZhbHVlfVxyXG4gICAgICAgICAge3VuaXQgJiYgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC44cmVtXCIsIGNvbG9yOiBcInZhcigtLWluay1mYWludClcIiB9fT4ge3VuaXR9PC9zcGFuPn1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAge2NoYW5nZSAhPT0gdW5kZWZpbmVkICYmIChcclxuICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC44cmVtXCIsXHJcbiAgICAgICAgICAgICAgcGFkZGluZzogXCIycHggNnB4XCIsXHJcbiAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAzLFxyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzUG9zaXRpdmUgPyBcIiNlOGY1ZTlcIiA6IFwiI2ZmZWJlZVwiLFxyXG4gICAgICAgICAgICAgIGNvbG9yOiBpc1Bvc2l0aXZlID8gXCIjMWI1ZTIwXCIgOiBcIiNiNzFjMWNcIixcclxuICAgICAgICAgICAgICBmb250V2VpZ2h0OiA2MDAsXHJcbiAgICAgICAgICAgICAgbWluV2lkdGg6IDUwLFxyXG4gICAgICAgICAgICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2lzUG9zaXRpdmUgPyBcIitcIiA6IFwiXCJ9e2NoYW5nZS50b0ZpeGVkKDEpfSVcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTWV0cmljc1Jvdy50c3gifQ==