import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/WaiterDashboardPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ca0b4140";
import { useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { api } from "/src/lib/apiClient.ts";
import { getTablesByBranch } from "/src/features/tables/api.ts";
import { getOpenOrdersByBranch } from "/src/features/orders/api.ts";
import { getComandasByBranch } from "/src/features/comandas/api.ts";
import { getActiveAssignmentsByEmployee, getTablesByArea } from "/src/features/diningareas/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { useMyFeatures } from "/src/features/access/hooks.ts";
import { OrderDrawer } from "/src/features/orders/OrderDrawer.tsx";
import { CashDrawer } from "/src/features/cash/CashDrawer.tsx";
import { QueryError } from "/src/components/QueryError.tsx";
import { TableStatus, OrderItemStatus, parseApiDate } from "/src/lib/types.ts";
import { WaiterHeader } from "/src/features/waiter/components/WaiterHeader.tsx";
import { WaiterTabBar } from "/src/features/waiter/components/WaiterTabBar.tsx";
import { TabInicio } from "/src/features/waiter/components/tabs/TabInicio.tsx";
import { TabMesas } from "/src/features/waiter/components/tabs/TabMesas.tsx";
import { TabComandas } from "/src/features/waiter/components/tabs/TabComandas.tsx";
import { TabPedidos } from "/src/features/waiter/components/tabs/TabPedidos.tsx";
import { TabMensagens } from "/src/features/waiter/components/tabs/TabMensagens.tsx";
import { CalculatorModal } from "/src/features/waiter/components/modals/CalculatorModal.tsx";
import { TransferItemModal } from "/src/features/waiter/components/modals/TransferItemModal.tsx";
import { WaiterProfileModal } from "/src/features/waiter/components/modals/WaiterProfileModal.tsx";
import { WaiterOpenTableModal } from "/src/features/waiter/components/modals/WaiterOpenTableModal.tsx";
import { WaiterOpenComandaModal } from "/src/features/waiter/components/modals/WaiterOpenComandaModal.tsx";
const getWaiterMessagesByBranch = (branchId, diningAreaId) => {
  if (!diningAreaId) return Promise.resolve([]);
  return api(`/api/diningareas/messages/branch/${branchId}?diningAreaId=${diningAreaId}`);
};
export function WaiterDashboardPage() {
  _s();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { branchId, userName, clear, employeeId } = useAuthStore();
  const featuresQuery = useMyFeatures();
  const canSeeCaixa = !!(featuresQuery.data?.canManageAccess || featuresQuery.data?.features?.includes("Caixa"));
  const [activeTab, setActiveTab] = useState("inicio");
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [tableToOpen, setTableToOpen] = useState(null);
  const [comandaToOpen, setComandaToOpen] = useState(null);
  const [openModal, setOpenModal] = useState(null);
  const [toast, setToast] = useState(null);
  const showToast = (message) => {
    setToast(message);
    window.setTimeout(() => setToast((current) => current === message ? null : current), 2500);
  };
  const handleLogout = () => {
    queryClient.clear();
    clear();
    navigate("/login", { replace: true });
  };
  const assignmentQuery = useQuery({ queryKey: ["diningareaassignments", "active", employeeId], queryFn: () => getActiveAssignmentsByEmployee(employeeId ?? 0), enabled: !!employeeId });
  const activeAreaId = assignmentQuery.data?.[0]?.diningAreaId ?? null;
  const areaTablesQuery = useQuery({ queryKey: ["diningareatables", activeAreaId], queryFn: () => getTablesByArea(activeAreaId), enabled: !!activeAreaId });
  const allowedTableIds = useMemo(() => {
    const set = /* @__PURE__ */ new Set();
    for (const t of areaTablesQuery.data ?? []) set.add(t.diningTableId);
    return set;
  }, [areaTablesQuery.data]);
  const tablesQuery = useQuery({ queryKey: ["tables", branchId], queryFn: () => getTablesByBranch(branchId), refetchInterval: 15e3 });
  const comandasQuery = useQuery({ queryKey: ["comandas", branchId], queryFn: () => getComandasByBranch(branchId), refetchInterval: 15e3 });
  const ordersQuery = useQuery({ queryKey: ["orders", "open", branchId], queryFn: () => getOpenOrdersByBranch(branchId), refetchInterval: 15e3 });
  const messagesQuery = useQuery({
    queryKey: ["waitermessages", branchId, activeAreaId],
    queryFn: () => getWaiterMessagesByBranch(branchId, activeAreaId),
    enabled: !!branchId && !!activeAreaId,
    refetchInterval: 1e4
  });
  const sortedMessages = useMemo(() => {
    const msgs = messagesQuery.data ?? [];
    return [...msgs].sort((a, b) => parseApiDate(a.createdAt).getTime() - parseApiDate(b.createdAt).getTime());
  }, [messagesQuery.data]);
  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: ["tables"] });
    void queryClient.invalidateQueries({ queryKey: ["orders"] });
    void queryClient.invalidateQueries({ queryKey: ["comandas"] });
    void queryClient.invalidateQueries({ queryKey: ["waitermessages"] });
  };
  const allActiveOrders = ordersQuery.data ?? [];
  const myOrders = useMemo(() => {
    if (!activeAreaId) return [];
    return allActiveOrders.filter((order) => order.comandaId !== null || order.diningTableId !== null && allowedTableIds.has(order.diningTableId));
  }, [allActiveOrders, activeAreaId, allowedTableIds]);
  const myTables = useMemo(() => (tablesQuery.data ?? []).filter((t) => allowedTableIds.has(t.id)), [tablesQuery.data, allowedTableIds]);
  const ordersByTableId = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const order of allActiveOrders) if (order.diningTableId !== null) map.set(order.diningTableId, order);
    return map;
  }, [allActiveOrders]);
  const tablesById = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const table of tablesQuery.data ?? []) map.set(table.id, table);
    return map;
  }, [tablesQuery.data]);
  const comandasById = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const comanda of comandasQuery.data ?? []) map.set(comanda.id, comanda);
    return map;
  }, [comandasQuery.data]);
  const myOpenTablesCount = myTables.filter((t) => t.tableStatusId === TableStatus.Ocupada || t.tableStatusId === TableStatus.EmFechamento).length;
  const tableOrders = useMemo(() => myOrders.filter((o) => o.diningTableId !== null), [myOrders]);
  const comandaOrders = useMemo(() => myOrders.filter((o) => o.comandaId !== null && o.diningTableId === null), [myOrders]);
  const totalTablesAmount = useMemo(() => tableOrders.reduce((sum, order) => sum + order.totalAmount, 0), [tableOrders]);
  const totalComandasAmount = useMemo(() => comandaOrders.reduce((sum, order) => sum + order.totalAmount, 0), [comandaOrders]);
  const readyItemsCount = useMemo(() => myOrders.reduce((sum, order) => sum + order.items.filter((i) => i.orderItemStatusId === OrderItemStatus.Pronto).length, 0), [myOrders]);
  const latestOrders = useMemo(() => [...myOrders].sort((a, b) => new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime()).slice(0, 3), [myOrders]);
  const handleQuickAction = (key) => {
    if (key === "mesas" || key === "comandas") setActiveTab(key);
    else if (key === "turno") setOpenModal("cash");
    else if (key === "calculadora") setOpenModal("calculator");
    else if (key === "transferir") setOpenModal("transfer");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "waiter-view", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "waiter-shell", children: [
      /* @__PURE__ */ jsxDEV(WaiterHeader, { userName, readyItemsCount, onBellClick: () => setActiveTab("mensagens") }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
        lineNumber: 147,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "waiter-body", children: [
        (tablesQuery.isError || ordersQuery.isError || comandasQuery.isError) && /* @__PURE__ */ jsxDEV("div", { className: "waiter-card", children: /* @__PURE__ */ jsxDEV(QueryError, { error: tablesQuery.error || ordersQuery.error || comandasQuery.error, what: "os dados" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
          lineNumber: 151,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
          lineNumber: 150,
          columnNumber: 11
        }, this),
        !assignmentQuery.isLoading && !activeAreaId && /* @__PURE__ */ jsxDEV("div", { className: "waiter-card", style: { backgroundColor: "var(--w-warn)", padding: 12, borderRadius: 8, marginBottom: 16 }, children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Sem praça atribuída!" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
            lineNumber: 156,
            columnNumber: 29
          }, this),
          " Solicite ao gerente que inicie seu turno em uma praça."
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
          lineNumber: 155,
          columnNumber: 11
        }, this),
        activeTab === "inicio" && /* @__PURE__ */ jsxDEV(
          TabInicio,
          {
            myOpenTablesCount,
            myTotalTables: myTables.length,
            comandaOrders,
            myOrders,
            totalTablesAmount,
            totalComandasAmount,
            latestOrders,
            tablesById,
            comandasById,
            canSeeCaixa,
            onTabChange: setActiveTab,
            onQuickAction: handleQuickAction,
            onOrderClick: setSelectedOrderId
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
            lineNumber: 160,
            columnNumber: 11
          },
          this
        ),
        activeTab === "mesas" && /* @__PURE__ */ jsxDEV(
          TabMesas,
          {
            activeAreaId,
            myTables,
            ordersByTableId,
            onTableClick: (tableId, status) => status === TableStatus.Livre ? setTableToOpen(myTables.find((t) => t.id === tableId)) : setSelectedOrderId(myOrders.find((o) => o.diningTableId === tableId)?.id || null)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
            lineNumber: 168,
            columnNumber: 11
          },
          this
        ),
        activeTab === "comandas" && /* @__PURE__ */ jsxDEV(
          TabComandas,
          {
            isLoading: comandasQuery.isLoading,
            comandas: comandasQuery.data,
            comandaOrders,
            onComandaClick: (comanda, orderId) => orderId ? setSelectedOrderId(orderId) : setComandaToOpen(comanda)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
            lineNumber: 176,
            columnNumber: 11
          },
          this
        ),
        activeTab === "pedidos" && /* @__PURE__ */ jsxDEV(
          TabPedidos,
          {
            myOrders,
            tablesById,
            comandasById,
            onOrderClick: setSelectedOrderId
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
            lineNumber: 184,
            columnNumber: 11
          },
          this
        ),
        activeTab === "mensagens" && /* @__PURE__ */ jsxDEV(
          TabMensagens,
          {
            activeAreaId,
            isLoading: messagesQuery.isLoading,
            isError: messagesQuery.isError,
            error: messagesQuery.error,
            messages: sortedMessages
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
            lineNumber: 192,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
        lineNumber: 148,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        WaiterTabBar,
        {
          activeTab,
          onTabChange: (key) => key === "perfil" ? setOpenModal("profile") : setActiveTab(key)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
          lineNumber: 201,
          columnNumber: 17
        },
        this
      ),
      openModal === "calculator" && /* @__PURE__ */ jsxDEV(CalculatorModal, { onClose: () => setOpenModal(null) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
        lineNumber: 207,
        columnNumber: 48
      }, this),
      openModal === "profile" && /* @__PURE__ */ jsxDEV(WaiterProfileModal, { userName, branchId, onClose: () => setOpenModal(null), onLogout: handleLogout }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
        lineNumber: 208,
        columnNumber: 45
      }, this),
      openModal === "cash" && /* @__PURE__ */ jsxDEV(CashDrawer, { onClose: () => setOpenModal(null) }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
        lineNumber: 209,
        columnNumber: 42
      }, this),
      openModal === "transfer" && /* @__PURE__ */ jsxDEV(
        TransferItemModal,
        {
          mode: "table",
          myTables,
          comandas: comandasQuery.data ?? [],
          comandaOrders,
          ordersByTableId,
          allActiveOrders,
          employeeId,
          onClose: () => setOpenModal(null),
          onSuccess: showToast,
          onError: showToast
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
          lineNumber: 213,
          columnNumber: 9
        },
        this
      ),
      tableToOpen && /* @__PURE__ */ jsxDEV(WaiterOpenTableModal, { table: tableToOpen, onClose: () => setTableToOpen(null), onOpened: (id) => {
        setTableToOpen(null);
        refresh();
        setSelectedOrderId(id);
      } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
        lineNumber: 227,
        columnNumber: 33
      }, this),
      comandaToOpen && /* @__PURE__ */ jsxDEV(WaiterOpenComandaModal, { comanda: comandaToOpen, onClose: () => setComandaToOpen(null), onOpened: (id) => {
        setComandaToOpen(null);
        refresh();
        setSelectedOrderId(id);
      } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
        lineNumber: 228,
        columnNumber: 35
      }, this),
      selectedOrderId !== null && /* @__PURE__ */ jsxDEV(OrderDrawer, { orderId: selectedOrderId, onClose: () => {
        setSelectedOrderId(null);
        refresh();
      } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
        lineNumber: 230,
        columnNumber: 46
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
      lineNumber: 146,
      columnNumber: 13
    }, this),
    toast && /* @__PURE__ */ jsxDEV("div", { className: "waiter-toast", role: "status", children: toast }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
      lineNumber: 233,
      columnNumber: 23
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx",
    lineNumber: 145,
    columnNumber: 5
  }, this);
}
_s(WaiterDashboardPage, "7rCCB4ra6r9eWNQM7YUbvXkvCq4=", false, function() {
  return [useNavigate, useQueryClient, useAuthStore, useMyFeatures, useQuery, useQuery, useQuery, useQuery, useQuery, useQuery];
});
_c = WaiterDashboardPage;
var _c;
$RefreshReg$(_c, "WaiterDashboardPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/WaiterDashboardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0hnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvSGYsU0FBU0EsU0FBU0MsZ0JBQWdCO0FBQ25DLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxVQUFVQyxzQkFBc0I7QUFDekMsU0FBU0MsV0FBVztBQUNwQixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxnQ0FBZ0NDLHVCQUF1QjtBQUNoRSxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGFBQWFDLGlCQUFpQkMsb0JBQW9CO0FBRzNELFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUEyQztBQUNwRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsOEJBQThCO0FBRXZDLE1BQU1DLDRCQUE0QkEsQ0FBQ0MsVUFBa0JDLGlCQUFrRTtBQUNuSCxNQUFJLENBQUNBLGFBQWMsUUFBT0MsUUFBUUMsUUFBUSxFQUFFO0FBQzVDLFNBQU85QixJQUE2QixvQ0FBb0MyQixRQUFRLGlCQUFpQkMsWUFBWSxFQUFFO0FBQ25IO0FBRU8sZ0JBQVNHLHNCQUFzQjtBQUFBQyxLQUFBO0FBQ2xDLFFBQU1DLFdBQVdwQyxZQUFZO0FBQzdCLFFBQU1xQyxjQUFjbkMsZUFBZTtBQUNuQyxRQUFNLEVBQUU0QixVQUFVUSxVQUFVQyxPQUFPQyxXQUFXLElBQUkvQixhQUFhO0FBQy9ELFFBQU1nQyxnQkFBZ0IvQixjQUFjO0FBRXBDLFFBQU1nQyxjQUFjLENBQUMsRUFBRUQsY0FBY0UsTUFBTUMsbUJBQW1CSCxjQUFjRSxNQUFNRSxVQUFVQyxTQUFTLE9BQU87QUFFNUcsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlqRCxTQUFpQixRQUFRO0FBQzNELFFBQU0sQ0FBQ2tELGlCQUFpQkMsa0JBQWtCLElBQUluRCxTQUF3QixJQUFJO0FBQzFFLFFBQU0sQ0FBQ29ELGFBQWFDLGNBQWMsSUFBSXJELFNBQStCLElBQUk7QUFDekUsUUFBTSxDQUFDc0QsZUFBZUMsZ0JBQWdCLElBQUl2RCxTQUFpQyxJQUFJO0FBRy9FLFFBQU0sQ0FBQ3dELFdBQVdDLFlBQVksSUFBSXpELFNBQWdFLElBQUk7QUFFdEcsUUFBTSxDQUFDMEQsT0FBT0MsUUFBUSxJQUFJM0QsU0FBd0IsSUFBSTtBQUN0RCxRQUFNNEQsWUFBWUEsQ0FBQ0MsWUFBb0I7QUFDbkNGLGFBQVNFLE9BQU87QUFDaEJDLFdBQU9DLFdBQVcsTUFBTUosU0FBUyxDQUFDSyxZQUFhQSxZQUFZSCxVQUFVLE9BQU9HLE9BQVEsR0FBRyxJQUFJO0FBQUEsRUFDL0Y7QUFDQSxRQUFNQyxlQUFlQSxNQUFNO0FBQ3ZCM0IsZ0JBQVlFLE1BQU07QUFDbEJBLFVBQU07QUFDTkgsYUFBUyxVQUFVLEVBQUU2QixTQUFTLEtBQUssQ0FBQztBQUFBLEVBQ3hDO0FBQ0EsUUFBTUMsa0JBQWtCakUsU0FBUyxFQUFFa0UsVUFBVSxDQUFDLHlCQUF5QixVQUFVM0IsVUFBVSxHQUFHNEIsU0FBU0EsTUFBTTdELCtCQUErQmlDLGNBQWMsQ0FBQyxHQUFHNkIsU0FBUyxDQUFDLENBQUM3QixXQUFXLENBQUM7QUFDckwsUUFBTThCLGVBQWVKLGdCQUFnQnZCLE9BQU8sQ0FBQyxHQUFHWixnQkFBZ0I7QUFDaEUsUUFBTXdDLGtCQUFrQnRFLFNBQVMsRUFBRWtFLFVBQVUsQ0FBQyxvQkFBb0JHLFlBQVksR0FBR0YsU0FBU0EsTUFBTTVELGdCQUFnQjhELFlBQWEsR0FBR0QsU0FBUyxDQUFDLENBQUNDLGFBQWEsQ0FBQztBQUN6SixRQUFNRSxrQkFBa0IxRSxRQUFRLE1BQU07QUFDbEMsVUFBTTJFLE1BQU0sb0JBQUlDLElBQVk7QUFDNUIsZUFBV0MsS0FBS0osZ0JBQWdCNUIsUUFBUSxHQUFJOEIsS0FBSUcsSUFBSUQsRUFBRUUsYUFBYTtBQUNuRSxXQUFPSjtBQUFBQSxFQUNYLEdBQUcsQ0FBQ0YsZ0JBQWdCNUIsSUFBSSxDQUFDO0FBQ3pCLFFBQU1tQyxjQUFjN0UsU0FBUyxFQUFFa0UsVUFBVSxDQUFDLFVBQVVyQyxRQUFRLEdBQUdzQyxTQUFTQSxNQUFNaEUsa0JBQWtCMEIsUUFBUSxHQUFHaUQsaUJBQWlCLEtBQU8sQ0FBQztBQUNwSSxRQUFNQyxnQkFBZ0IvRSxTQUFTLEVBQUVrRSxVQUFVLENBQUMsWUFBWXJDLFFBQVEsR0FBR3NDLFNBQVNBLE1BQU05RCxvQkFBb0J3QixRQUFRLEdBQUdpRCxpQkFBaUIsS0FBTyxDQUFDO0FBQzFJLFFBQU1FLGNBQWNoRixTQUFTLEVBQUVrRSxVQUFVLENBQUMsVUFBVSxRQUFRckMsUUFBUSxHQUFHc0MsU0FBU0EsTUFBTS9ELHNCQUFzQnlCLFFBQVEsR0FBR2lELGlCQUFpQixLQUFPLENBQUM7QUFDaEosUUFBTUcsZ0JBQWdCakYsU0FBUztBQUFBLElBQzNCa0UsVUFBVSxDQUFDLGtCQUFrQnJDLFVBQVV3QyxZQUFZO0FBQUEsSUFDbkRGLFNBQVNBLE1BQU12QywwQkFBMEJDLFVBQVV3QyxZQUFZO0FBQUEsSUFDL0RELFNBQVMsQ0FBQyxDQUFDdkMsWUFBWSxDQUFDLENBQUN3QztBQUFBQSxJQUN6QlMsaUJBQWlCO0FBQUEsRUFDckIsQ0FBQztBQUNELFFBQU1JLGlCQUFpQnJGLFFBQVEsTUFBTTtBQUNqQyxVQUFNc0YsT0FBT0YsY0FBY3ZDLFFBQVE7QUFDbkMsV0FBTyxDQUFDLEdBQUd5QyxJQUFJLEVBQUVDLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTXZFLGFBQWFzRSxFQUFFRSxTQUFTLEVBQUVDLFFBQVEsSUFBSXpFLGFBQWF1RSxFQUFFQyxTQUFTLEVBQUVDLFFBQVEsQ0FBQztBQUFBLEVBQzdHLEdBQUcsQ0FBQ1AsY0FBY3ZDLElBQUksQ0FBQztBQUV2QixRQUFNK0MsVUFBVUEsTUFBTTtBQUNsQixTQUFLckQsWUFBWXNELGtCQUFrQixFQUFFeEIsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzNELFNBQUs5QixZQUFZc0Qsa0JBQWtCLEVBQUV4QixVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDM0QsU0FBSzlCLFlBQVlzRCxrQkFBa0IsRUFBRXhCLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztBQUM3RCxTQUFLOUIsWUFBWXNELGtCQUFrQixFQUFFeEIsVUFBVSxDQUFDLGdCQUFnQixFQUFFLENBQUM7QUFBQSxFQUN2RTtBQUNBLFFBQU15QixrQkFBa0JYLFlBQVl0QyxRQUFRO0FBQzVDLFFBQU1rRCxXQUFXL0YsUUFBUSxNQUFNO0FBQzNCLFFBQUksQ0FBQ3dFLGFBQWMsUUFBTztBQUMxQixXQUFPc0IsZ0JBQWdCRSxPQUFPLENBQUFDLFVBQVVBLE1BQU1DLGNBQWMsUUFBVUQsTUFBTWxCLGtCQUFrQixRQUFRTCxnQkFBZ0J5QixJQUFJRixNQUFNbEIsYUFBYSxDQUFFO0FBQUEsRUFDbkosR0FBRyxDQUFDZSxpQkFBaUJ0QixjQUFjRSxlQUFlLENBQUM7QUFDbkQsUUFBTTBCLFdBQVdwRyxRQUFRLE9BQU9nRixZQUFZbkMsUUFBUSxJQUFJbUQsT0FBTyxDQUFDbkIsTUFBTUgsZ0JBQWdCeUIsSUFBSXRCLEVBQUV3QixFQUFFLENBQUMsR0FBRyxDQUFDckIsWUFBWW5DLE1BQU02QixlQUFlLENBQUM7QUFDckksUUFBTTRCLGtCQUFrQnRHLFFBQVEsTUFBTTtBQUNsQyxVQUFNdUcsTUFBTSxvQkFBSUMsSUFBMkI7QUFDM0MsZUFBV1AsU0FBU0gsZ0JBQWlCLEtBQUlHLE1BQU1sQixrQkFBa0IsS0FBTXdCLEtBQUk1QixJQUFJc0IsTUFBTWxCLGVBQWVrQixLQUFLO0FBQ3pHLFdBQU9NO0FBQUFBLEVBQ1gsR0FBRyxDQUFDVCxlQUFlLENBQUM7QUFDcEIsUUFBTVcsYUFBYXpHLFFBQVEsTUFBTTtBQUM3QixVQUFNdUcsTUFBTSxvQkFBSUMsSUFBMkI7QUFDM0MsZUFBV0UsU0FBUzFCLFlBQVluQyxRQUFRLEdBQUkwRCxLQUFJNUIsSUFBSStCLE1BQU1MLElBQUlLLEtBQUs7QUFDbkUsV0FBT0g7QUFBQUEsRUFDWCxHQUFHLENBQUN2QixZQUFZbkMsSUFBSSxDQUFDO0FBQ3JCLFFBQU04RCxlQUFlM0csUUFBUSxNQUFNO0FBQy9CLFVBQU11RyxNQUFNLG9CQUFJQyxJQUE2QjtBQUM3QyxlQUFXSSxXQUFXMUIsY0FBY3JDLFFBQVEsR0FBSTBELEtBQUk1QixJQUFJaUMsUUFBUVAsSUFBSU8sT0FBTztBQUMzRSxXQUFPTDtBQUFBQSxFQUNYLEdBQUcsQ0FBQ3JCLGNBQWNyQyxJQUFJLENBQUM7QUFDdkIsUUFBTWdFLG9CQUFvQlQsU0FBU0osT0FBTyxDQUFDbkIsTUFBTUEsRUFBRWlDLGtCQUFrQjlGLFlBQVkrRixXQUFXbEMsRUFBRWlDLGtCQUFrQjlGLFlBQVlnRyxZQUFZLEVBQUVDO0FBQzFJLFFBQU1DLGNBQWNsSCxRQUFRLE1BQU0rRixTQUFTQyxPQUFPLENBQUNtQixNQUFNQSxFQUFFcEMsa0JBQWtCLElBQUksR0FBRyxDQUFDZ0IsUUFBUSxDQUFDO0FBQzlGLFFBQU1xQixnQkFBZ0JwSCxRQUFRLE1BQU0rRixTQUFTQyxPQUFPLENBQUNtQixNQUFNQSxFQUFFakIsY0FBYyxRQUFRaUIsRUFBRXBDLGtCQUFrQixJQUFJLEdBQUcsQ0FBQ2dCLFFBQVEsQ0FBQztBQUN4SCxRQUFNc0Isb0JBQW9CckgsUUFBUSxNQUFNa0gsWUFBWUksT0FBTyxDQUFDQyxLQUFLdEIsVUFBVXNCLE1BQU10QixNQUFNdUIsYUFBYSxDQUFDLEdBQUcsQ0FBQ04sV0FBVyxDQUFDO0FBQ3JILFFBQU1PLHNCQUFzQnpILFFBQVEsTUFBTW9ILGNBQWNFLE9BQU8sQ0FBQ0MsS0FBS3RCLFVBQVVzQixNQUFNdEIsTUFBTXVCLGFBQWEsQ0FBQyxHQUFHLENBQUNKLGFBQWEsQ0FBQztBQUMzSCxRQUFNTSxrQkFBa0IxSCxRQUFRLE1BQU0rRixTQUFTdUIsT0FBTyxDQUFDQyxLQUFLdEIsVUFBVXNCLE1BQU10QixNQUFNMEIsTUFBTTNCLE9BQU8sQ0FBQzRCLE1BQU1BLEVBQUVDLHNCQUFzQjVHLGdCQUFnQjZHLE1BQU0sRUFBRWIsUUFBUSxDQUFDLEdBQUcsQ0FBQ2xCLFFBQVEsQ0FBQztBQUM1SyxRQUFNZ0MsZUFBZS9ILFFBQVEsTUFBTSxDQUFDLEdBQUcrRixRQUFRLEVBQUVSLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTSxJQUFJdUMsS0FBS3ZDLEVBQUV3QyxRQUFRLEVBQUV0QyxRQUFRLElBQUksSUFBSXFDLEtBQUt4QyxFQUFFeUMsUUFBUSxFQUFFdEMsUUFBUSxDQUFDLEVBQUV1QyxNQUFNLEdBQUcsQ0FBQyxHQUFHLENBQUNuQyxRQUFRLENBQUM7QUFFeEosUUFBTW9DLG9CQUFvQkEsQ0FBQ0MsUUFBd0I7QUFDL0MsUUFBSUEsUUFBUSxXQUFXQSxRQUFRLFdBQVlsRixjQUFha0YsR0FBRztBQUFBLGFBQ2xEQSxRQUFRLFFBQVMxRSxjQUFhLE1BQU07QUFBQSxhQUNwQzBFLFFBQVEsY0FBZTFFLGNBQWEsWUFBWTtBQUFBLGFBQ2hEMEUsUUFBUSxhQUFjMUUsY0FBYSxVQUFVO0FBQUEsRUFDMUQ7QUFFQSxTQUNJLHVCQUFDLFNBQUksV0FBVSxlQUNYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGdCQUNYO0FBQUEsNkJBQUMsZ0JBQWEsVUFBb0IsaUJBQWtDLGFBQWEsTUFBTVIsYUFBYSxXQUFXLEtBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUg7QUFBQSxNQUNqSCx1QkFBQyxVQUFLLFdBQVUsZUFDVjhCO0FBQUFBLHFCQUFZcUQsV0FBV2xELFlBQVlrRCxXQUFXbkQsY0FBY21ELFlBQzFELHVCQUFDLFNBQUksV0FBVSxlQUNYLGlDQUFDLGNBQVcsT0FBT3JELFlBQVlzRCxTQUFTbkQsWUFBWW1ELFNBQVNwRCxjQUFjb0QsT0FBTyxNQUFLLGNBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUcsS0FEckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFSCxDQUFDbEUsZ0JBQWdCbUUsYUFBYSxDQUFDL0QsZ0JBQzVCLHVCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU8sRUFBRWdFLGlCQUFpQixpQkFBaUJDLFNBQVMsSUFBSUMsY0FBYyxHQUFHQyxjQUFjLEdBQUcsR0FDbkg7QUFBQSxpQ0FBQyxZQUFPLG9DQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsVUFBUztBQUFBLGFBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUgxRixjQUFjLFlBQ1g7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHO0FBQUEsWUFBc0MsZUFBZW1ELFNBQVNhO0FBQUFBLFlBQVE7QUFBQSxZQUN0RTtBQUFBLFlBQW9CO0FBQUEsWUFBc0M7QUFBQSxZQUMxRDtBQUFBLFlBQTRCO0FBQUEsWUFBd0I7QUFBQSxZQUE0QjtBQUFBLFlBQ2hGLGFBQWEvRDtBQUFBQSxZQUFjLGVBQWVpRjtBQUFBQSxZQUFtQixjQUFjL0U7QUFBQUE7QUFBQUEsVUFKL0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWtHO0FBQUEsUUFHckdILGNBQWMsV0FDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0c7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0EsY0FBYyxDQUFDMkYsU0FBU0MsV0FBV0EsV0FBVzdILFlBQVk4SCxRQUFReEYsZUFBZThDLFNBQVMyQyxLQUFLLENBQUFsRSxNQUFLQSxFQUFFd0IsT0FBT3VDLE9BQU8sQ0FBRSxJQUFJeEYsbUJBQW1CMkMsU0FBU2dELEtBQUssQ0FBQTVCLE1BQUtBLEVBQUVwQyxrQkFBa0I2RCxPQUFPLEdBQUd2QyxNQUFNLElBQUk7QUFBQTtBQUFBLFVBSjVNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk4TTtBQUFBLFFBR2pOcEQsY0FBYyxjQUNYO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxXQUFXaUMsY0FBY3FEO0FBQUFBLFlBQ3pCLFVBQVVyRCxjQUFjckM7QUFBQUEsWUFDeEI7QUFBQSxZQUNBLGdCQUFnQixDQUFDK0QsU0FBU29DLFlBQVlBLFVBQVU1RixtQkFBbUI0RixPQUFPLElBQUl4RixpQkFBaUJvRCxPQUFPO0FBQUE7QUFBQSxVQUoxRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJNEc7QUFBQSxRQUcvRzNELGNBQWMsYUFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0c7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0EsY0FBY0c7QUFBQUE7QUFBQUEsVUFKbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXFDO0FBQUEsUUFHeENILGNBQWMsZUFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0c7QUFBQSxZQUNBLFdBQVdtQyxjQUFjbUQ7QUFBQUEsWUFDekIsU0FBU25ELGNBQWNpRDtBQUFBQSxZQUN2QixPQUFPakQsY0FBY2tEO0FBQUFBLFlBQ3JCLFVBQVVqRDtBQUFBQTtBQUFBQSxVQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUs2QjtBQUFBLFdBakRyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0RBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0c7QUFBQSxVQUNBLGFBQWEsQ0FBQytDLFFBQVFBLFFBQVEsV0FBVzFFLGFBQWEsU0FBUyxJQUFJUixhQUFha0YsR0FBRztBQUFBO0FBQUEsUUFGdkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRXlGO0FBQUEsTUFJeEYzRSxjQUFjLGdCQUFnQix1QkFBQyxtQkFBZ0IsU0FBUyxNQUFNQyxhQUFhLElBQUksS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLE1BQ2pGRCxjQUFjLGFBQWEsdUJBQUMsc0JBQW1CLFVBQW9CLFVBQW9CLFNBQVMsTUFBTUMsYUFBYSxJQUFJLEdBQUcsVUFBVVEsZ0JBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0g7QUFBQSxNQUNqSlQsY0FBYyxVQUFVLHVCQUFDLGNBQVcsU0FBUyxNQUFNQyxhQUFhLElBQUksS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QztBQUFBLE1BR3RFRCxjQUFjLGNBQ1g7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMO0FBQUEsVUFDQSxVQUFVeUIsY0FBY3JDLFFBQVE7QUFBQSxVQUNoQztBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsU0FBUyxNQUFNYSxhQUFhLElBQUk7QUFBQSxVQUNoQyxXQUFXRztBQUFBQSxVQUNYLFNBQVNBO0FBQUFBO0FBQUFBLFFBVmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVXVCO0FBQUEsTUFJMUJSLGVBQWUsdUJBQUMsd0JBQXFCLE9BQU9BLGFBQWEsU0FBUyxNQUFNQyxlQUFlLElBQUksR0FBRyxVQUFVLENBQUMrQyxPQUFPO0FBQUUvQyx1QkFBZSxJQUFJO0FBQUdzQyxnQkFBUTtBQUFHeEMsMkJBQW1CaUQsRUFBRTtBQUFBLE1BQUcsS0FBNUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4SjtBQUFBLE1BQzdLOUMsaUJBQWlCLHVCQUFDLDBCQUF1QixTQUFTQSxlQUFlLFNBQVMsTUFBTUMsaUJBQWlCLElBQUksR0FBRyxVQUFVLENBQUM2QyxPQUFPO0FBQUU3Qyx5QkFBaUIsSUFBSTtBQUFHb0MsZ0JBQVE7QUFBR3hDLDJCQUFtQmlELEVBQUU7QUFBQSxNQUFHLEtBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0s7QUFBQSxNQUV6TGxELG9CQUFvQixRQUFRLHVCQUFDLGVBQVksU0FBU0EsaUJBQWlCLFNBQVMsTUFBTTtBQUFFQywyQkFBbUIsSUFBSTtBQUFHd0MsZ0JBQVE7QUFBQSxNQUFHLEtBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Y7QUFBQSxTQXBGaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFGQTtBQUFBLElBRUNqQyxTQUFTLHVCQUFDLFNBQUksV0FBVSxnQkFBZSxNQUFLLFVBQVVBLG1CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1EO0FBQUEsT0F4RmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RkE7QUFFUjtBQUFDdEIsR0F0TGVELHFCQUFtQjtBQUFBLFVBQ2RsQyxhQUNHRSxnQkFDOEJPLGNBQzVCQyxlQXNCRVQsVUFFQUEsVUFNSkEsVUFDRUEsVUFDRkEsVUFDRUEsUUFBUTtBQUFBO0FBQUEsS0FyQ2xCaUM7QUFBbUIsSUFBQTZHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsImFwaSIsImdldFRhYmxlc0J5QnJhbmNoIiwiZ2V0T3Blbk9yZGVyc0J5QnJhbmNoIiwiZ2V0Q29tYW5kYXNCeUJyYW5jaCIsImdldEFjdGl2ZUFzc2lnbm1lbnRzQnlFbXBsb3llZSIsImdldFRhYmxlc0J5QXJlYSIsInVzZUF1dGhTdG9yZSIsInVzZU15RmVhdHVyZXMiLCJPcmRlckRyYXdlciIsIkNhc2hEcmF3ZXIiLCJRdWVyeUVycm9yIiwiVGFibGVTdGF0dXMiLCJPcmRlckl0ZW1TdGF0dXMiLCJwYXJzZUFwaURhdGUiLCJXYWl0ZXJIZWFkZXIiLCJXYWl0ZXJUYWJCYXIiLCJUYWJJbmljaW8iLCJUYWJNZXNhcyIsIlRhYkNvbWFuZGFzIiwiVGFiUGVkaWRvcyIsIlRhYk1lbnNhZ2VucyIsIkNhbGN1bGF0b3JNb2RhbCIsIlRyYW5zZmVySXRlbU1vZGFsIiwiV2FpdGVyUHJvZmlsZU1vZGFsIiwiV2FpdGVyT3BlblRhYmxlTW9kYWwiLCJXYWl0ZXJPcGVuQ29tYW5kYU1vZGFsIiwiZ2V0V2FpdGVyTWVzc2FnZXNCeUJyYW5jaCIsImJyYW5jaElkIiwiZGluaW5nQXJlYUlkIiwiUHJvbWlzZSIsInJlc29sdmUiLCJXYWl0ZXJEYXNoYm9hcmRQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsInF1ZXJ5Q2xpZW50IiwidXNlck5hbWUiLCJjbGVhciIsImVtcGxveWVlSWQiLCJmZWF0dXJlc1F1ZXJ5IiwiY2FuU2VlQ2FpeGEiLCJkYXRhIiwiY2FuTWFuYWdlQWNjZXNzIiwiZmVhdHVyZXMiLCJpbmNsdWRlcyIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInNlbGVjdGVkT3JkZXJJZCIsInNldFNlbGVjdGVkT3JkZXJJZCIsInRhYmxlVG9PcGVuIiwic2V0VGFibGVUb09wZW4iLCJjb21hbmRhVG9PcGVuIiwic2V0Q29tYW5kYVRvT3BlbiIsIm9wZW5Nb2RhbCIsInNldE9wZW5Nb2RhbCIsInRvYXN0Iiwic2V0VG9hc3QiLCJzaG93VG9hc3QiLCJtZXNzYWdlIiwid2luZG93Iiwic2V0VGltZW91dCIsImN1cnJlbnQiLCJoYW5kbGVMb2dvdXQiLCJyZXBsYWNlIiwiYXNzaWdubWVudFF1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwiZW5hYmxlZCIsImFjdGl2ZUFyZWFJZCIsImFyZWFUYWJsZXNRdWVyeSIsImFsbG93ZWRUYWJsZUlkcyIsInNldCIsIlNldCIsInQiLCJhZGQiLCJkaW5pbmdUYWJsZUlkIiwidGFibGVzUXVlcnkiLCJyZWZldGNoSW50ZXJ2YWwiLCJjb21hbmRhc1F1ZXJ5Iiwib3JkZXJzUXVlcnkiLCJtZXNzYWdlc1F1ZXJ5Iiwic29ydGVkTWVzc2FnZXMiLCJtc2dzIiwic29ydCIsImEiLCJiIiwiY3JlYXRlZEF0IiwiZ2V0VGltZSIsInJlZnJlc2giLCJpbnZhbGlkYXRlUXVlcmllcyIsImFsbEFjdGl2ZU9yZGVycyIsIm15T3JkZXJzIiwiZmlsdGVyIiwib3JkZXIiLCJjb21hbmRhSWQiLCJoYXMiLCJteVRhYmxlcyIsImlkIiwib3JkZXJzQnlUYWJsZUlkIiwibWFwIiwiTWFwIiwidGFibGVzQnlJZCIsInRhYmxlIiwiY29tYW5kYXNCeUlkIiwiY29tYW5kYSIsIm15T3BlblRhYmxlc0NvdW50IiwidGFibGVTdGF0dXNJZCIsIk9jdXBhZGEiLCJFbUZlY2hhbWVudG8iLCJsZW5ndGgiLCJ0YWJsZU9yZGVycyIsIm8iLCJjb21hbmRhT3JkZXJzIiwidG90YWxUYWJsZXNBbW91bnQiLCJyZWR1Y2UiLCJzdW0iLCJ0b3RhbEFtb3VudCIsInRvdGFsQ29tYW5kYXNBbW91bnQiLCJyZWFkeUl0ZW1zQ291bnQiLCJpdGVtcyIsImkiLCJvcmRlckl0ZW1TdGF0dXNJZCIsIlByb250byIsImxhdGVzdE9yZGVycyIsIkRhdGUiLCJvcGVuZWRBdCIsInNsaWNlIiwiaGFuZGxlUXVpY2tBY3Rpb24iLCJrZXkiLCJpc0Vycm9yIiwiZXJyb3IiLCJpc0xvYWRpbmciLCJiYWNrZ3JvdW5kQ29sb3IiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwibWFyZ2luQm90dG9tIiwidGFibGVJZCIsInN0YXR1cyIsIkxpdnJlIiwiZmluZCIsIm9yZGVySWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJXYWl0ZXJEYXNoYm9hcmRQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyLvu79pbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHsgZ2V0VGFibGVzQnlCcmFuY2ggfSBmcm9tIFwiLi4vdGFibGVzL2FwaVwiO1xyXG5pbXBvcnQgeyBnZXRPcGVuT3JkZXJzQnlCcmFuY2ggfSBmcm9tIFwiLi4vb3JkZXJzL2FwaVwiO1xyXG5pbXBvcnQgeyBnZXRDb21hbmRhc0J5QnJhbmNoIH0gZnJvbSBcIi4uL2NvbWFuZGFzL2FwaVwiO1xyXG5pbXBvcnQgeyBnZXRBY3RpdmVBc3NpZ25tZW50c0J5RW1wbG95ZWUsIGdldFRhYmxlc0J5QXJlYSB9IGZyb20gXCIuLi9kaW5pbmdhcmVhcy9hcGlcIjtcclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcclxuaW1wb3J0IHsgdXNlTXlGZWF0dXJlcyB9IGZyb20gXCIuLi9hY2Nlc3MvaG9va3NcIjtcclxuaW1wb3J0IHsgT3JkZXJEcmF3ZXIgfSBmcm9tIFwiLi4vb3JkZXJzL09yZGVyRHJhd2VyXCI7XHJcbmltcG9ydCB7IENhc2hEcmF3ZXIgfSBmcm9tIFwiLi4vY2FzaC9DYXNoRHJhd2VyXCI7XHJcbmltcG9ydCB7IFF1ZXJ5RXJyb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9RdWVyeUVycm9yXCI7XHJcbmltcG9ydCB7IFRhYmxlU3RhdHVzLCBPcmRlckl0ZW1TdGF0dXMsIHBhcnNlQXBpRGF0ZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHR5cGUgeyBDb21hbmRhUmVzcG9uc2UsIE9yZGVyUmVzcG9uc2UsIFRhYmxlUmVzcG9uc2UgfSBmcm9tIFwiLi4vLi4vbGliL3R5cGVzXCI7XHJcbmltcG9ydCB7IFRhYktleSwgUXVpY2tBY3Rpb25LZXkgfSBmcm9tIFwiLi91dGlsc1wiO1xyXG5pbXBvcnQgeyBXYWl0ZXJIZWFkZXIgfSBmcm9tIFwiLi9jb21wb25lbnRzL1dhaXRlckhlYWRlclwiO1xyXG5pbXBvcnQgeyBXYWl0ZXJUYWJCYXIgfSBmcm9tIFwiLi9jb21wb25lbnRzL1dhaXRlclRhYkJhclwiO1xyXG5pbXBvcnQgeyBUYWJJbmljaW8gfSBmcm9tIFwiLi9jb21wb25lbnRzL3RhYnMvVGFiSW5pY2lvXCI7XHJcbmltcG9ydCB7IFRhYk1lc2FzIH0gZnJvbSBcIi4vY29tcG9uZW50cy90YWJzL1RhYk1lc2FzXCI7XHJcbmltcG9ydCB7IFRhYkNvbWFuZGFzIH0gZnJvbSBcIi4vY29tcG9uZW50cy90YWJzL1RhYkNvbWFuZGFzXCI7XHJcbmltcG9ydCB7IFRhYlBlZGlkb3MgfSBmcm9tIFwiLi9jb21wb25lbnRzL3RhYnMvVGFiUGVkaWRvc1wiO1xyXG5pbXBvcnQgeyBUYWJNZW5zYWdlbnMsIFdhaXRlck1lc3NhZ2VSZXNwb25zZSB9IGZyb20gXCIuL2NvbXBvbmVudHMvdGFicy9UYWJNZW5zYWdlbnNcIjtcclxuaW1wb3J0IHsgQ2FsY3VsYXRvck1vZGFsIH0gZnJvbSBcIi4vY29tcG9uZW50cy9tb2RhbHMvQ2FsY3VsYXRvck1vZGFsXCI7XHJcbmltcG9ydCB7IFRyYW5zZmVySXRlbU1vZGFsIH0gZnJvbSBcIi4vY29tcG9uZW50cy9tb2RhbHMvVHJhbnNmZXJJdGVtTW9kYWxcIjtcclxuaW1wb3J0IHsgV2FpdGVyUHJvZmlsZU1vZGFsIH0gZnJvbSBcIi4vY29tcG9uZW50cy9tb2RhbHMvV2FpdGVyUHJvZmlsZU1vZGFsXCI7XHJcbmltcG9ydCB7IFdhaXRlck9wZW5UYWJsZU1vZGFsIH0gZnJvbSBcIi4vY29tcG9uZW50cy9tb2RhbHMvV2FpdGVyT3BlblRhYmxlTW9kYWxcIjtcclxuaW1wb3J0IHsgV2FpdGVyT3BlbkNvbWFuZGFNb2RhbCB9IGZyb20gXCIuL2NvbXBvbmVudHMvbW9kYWxzL1dhaXRlck9wZW5Db21hbmRhTW9kYWxcIjtcclxuXHJcbmNvbnN0IGdldFdhaXRlck1lc3NhZ2VzQnlCcmFuY2ggPSAoYnJhbmNoSWQ6IG51bWJlciwgZGluaW5nQXJlYUlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTxXYWl0ZXJNZXNzYWdlUmVzcG9uc2VbXT4gPT4ge1xyXG4gICAgaWYgKCFkaW5pbmdBcmVhSWQpIHJldHVybiBQcm9taXNlLnJlc29sdmUoW10pO1xyXG4gICAgcmV0dXJuIGFwaTxXYWl0ZXJNZXNzYWdlUmVzcG9uc2VbXT4oYC9hcGkvZGluaW5nYXJlYXMvbWVzc2FnZXMvYnJhbmNoLyR7YnJhbmNoSWR9P2RpbmluZ0FyZWFJZD0ke2RpbmluZ0FyZWFJZH1gKTtcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBXYWl0ZXJEYXNoYm9hcmRQYWdlKCkge1xyXG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBicmFuY2hJZCwgdXNlck5hbWUsIGNsZWFyLCBlbXBsb3llZUlkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICAgIGNvbnN0IGZlYXR1cmVzUXVlcnkgPSB1c2VNeUZlYXR1cmVzKCk7XHJcblxyXG4gICAgY29uc3QgY2FuU2VlQ2FpeGEgPSAhIShmZWF0dXJlc1F1ZXJ5LmRhdGE/LmNhbk1hbmFnZUFjY2VzcyB8fCBmZWF0dXJlc1F1ZXJ5LmRhdGE/LmZlYXR1cmVzPy5pbmNsdWRlcyhcIkNhaXhhXCIpKTtcclxuXHJcbiAgICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8VGFiS2V5PihcImluaWNpb1wiKTtcclxuICAgIGNvbnN0IFtzZWxlY3RlZE9yZGVySWQsIHNldFNlbGVjdGVkT3JkZXJJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFt0YWJsZVRvT3Blbiwgc2V0VGFibGVUb09wZW5dID0gdXNlU3RhdGU8VGFibGVSZXNwb25zZSB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgW2NvbWFuZGFUb09wZW4sIHNldENvbWFuZGFUb09wZW5dID0gdXNlU3RhdGU8Q29tYW5kYVJlc3BvbnNlIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gICAgLy8gVW5pZmljYWRvIHBhcmEgdW0gw7puaWNvIGVzdGFkbyBkZSBtb2RhbCBkZSB0cmFuc2ZlcsOqbmNpYVxyXG4gICAgY29uc3QgW29wZW5Nb2RhbCwgc2V0T3Blbk1vZGFsXSA9IHVzZVN0YXRlPFwiY2FsY3VsYXRvclwiIHwgXCJ0cmFuc2ZlclwiIHwgXCJwcm9maWxlXCIgfCBcImNhc2hcIiB8IG51bGw+KG51bGwpO1xyXG5cclxuICAgIGNvbnN0IFt0b2FzdCwgc2V0VG9hc3RdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBzaG93VG9hc3QgPSAobWVzc2FnZTogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgc2V0VG9hc3QobWVzc2FnZSk7XHJcbiAgICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0VG9hc3QoKGN1cnJlbnQpID0+IChjdXJyZW50ID09PSBtZXNzYWdlID8gbnVsbCA6IGN1cnJlbnQpKSwgMjUwMCk7XHJcbiAgICB9O1xyXG4gICAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgICAgIHF1ZXJ5Q2xpZW50LmNsZWFyKCk7XHJcbiAgICAgICAgY2xlYXIoKTtcclxuICAgICAgICBuYXZpZ2F0ZShcIi9sb2dpblwiLCB7IHJlcGxhY2U6IHRydWUgfSk7XHJcbiAgICB9O1xyXG4gICAgY29uc3QgYXNzaWdubWVudFF1ZXJ5ID0gdXNlUXVlcnkoeyBxdWVyeUtleTogW1wiZGluaW5nYXJlYWFzc2lnbm1lbnRzXCIsIFwiYWN0aXZlXCIsIGVtcGxveWVlSWRdLCBxdWVyeUZuOiAoKSA9PiBnZXRBY3RpdmVBc3NpZ25tZW50c0J5RW1wbG95ZWUoZW1wbG95ZWVJZCA/PyAwKSwgZW5hYmxlZDogISFlbXBsb3llZUlkIH0pO1xyXG4gICAgY29uc3QgYWN0aXZlQXJlYUlkID0gYXNzaWdubWVudFF1ZXJ5LmRhdGE/LlswXT8uZGluaW5nQXJlYUlkID8/IG51bGw7XHJcbiAgICBjb25zdCBhcmVhVGFibGVzUXVlcnkgPSB1c2VRdWVyeSh7IHF1ZXJ5S2V5OiBbXCJkaW5pbmdhcmVhdGFibGVzXCIsIGFjdGl2ZUFyZWFJZF0sIHF1ZXJ5Rm46ICgpID0+IGdldFRhYmxlc0J5QXJlYShhY3RpdmVBcmVhSWQhKSwgZW5hYmxlZDogISFhY3RpdmVBcmVhSWQgfSk7XHJcbiAgICBjb25zdCBhbGxvd2VkVGFibGVJZHMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBjb25zdCBzZXQgPSBuZXcgU2V0PG51bWJlcj4oKTtcclxuICAgICAgICBmb3IgKGNvbnN0IHQgb2YgYXJlYVRhYmxlc1F1ZXJ5LmRhdGEgPz8gW10pIHNldC5hZGQodC5kaW5pbmdUYWJsZUlkKTtcclxuICAgICAgICByZXR1cm4gc2V0O1xyXG4gICAgfSwgW2FyZWFUYWJsZXNRdWVyeS5kYXRhXSk7XHJcbiAgICBjb25zdCB0YWJsZXNRdWVyeSA9IHVzZVF1ZXJ5KHsgcXVlcnlLZXk6IFtcInRhYmxlc1wiLCBicmFuY2hJZF0sIHF1ZXJ5Rm46ICgpID0+IGdldFRhYmxlc0J5QnJhbmNoKGJyYW5jaElkKSwgcmVmZXRjaEludGVydmFsOiAxNV8wMDAgfSk7XHJcbiAgICBjb25zdCBjb21hbmRhc1F1ZXJ5ID0gdXNlUXVlcnkoeyBxdWVyeUtleTogW1wiY29tYW5kYXNcIiwgYnJhbmNoSWRdLCBxdWVyeUZuOiAoKSA9PiBnZXRDb21hbmRhc0J5QnJhbmNoKGJyYW5jaElkKSwgcmVmZXRjaEludGVydmFsOiAxNV8wMDAgfSk7XHJcbiAgICBjb25zdCBvcmRlcnNRdWVyeSA9IHVzZVF1ZXJ5KHsgcXVlcnlLZXk6IFtcIm9yZGVyc1wiLCBcIm9wZW5cIiwgYnJhbmNoSWRdLCBxdWVyeUZuOiAoKSA9PiBnZXRPcGVuT3JkZXJzQnlCcmFuY2goYnJhbmNoSWQpLCByZWZldGNoSW50ZXJ2YWw6IDE1XzAwMCB9KTtcclxuICAgIGNvbnN0IG1lc3NhZ2VzUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcIndhaXRlcm1lc3NhZ2VzXCIsIGJyYW5jaElkLCBhY3RpdmVBcmVhSWRdLFxyXG4gICAgICAgIHF1ZXJ5Rm46ICgpID0+IGdldFdhaXRlck1lc3NhZ2VzQnlCcmFuY2goYnJhbmNoSWQsIGFjdGl2ZUFyZWFJZCksXHJcbiAgICAgICAgZW5hYmxlZDogISFicmFuY2hJZCAmJiAhIWFjdGl2ZUFyZWFJZCxcclxuICAgICAgICByZWZldGNoSW50ZXJ2YWw6IDEwXzAwMCxcclxuICAgIH0pO1xyXG4gICAgY29uc3Qgc29ydGVkTWVzc2FnZXMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBjb25zdCBtc2dzID0gbWVzc2FnZXNRdWVyeS5kYXRhID8/IFtdO1xyXG4gICAgICAgIHJldHVybiBbLi4ubXNnc10uc29ydCgoYSwgYikgPT4gcGFyc2VBcGlEYXRlKGEuY3JlYXRlZEF0KS5nZXRUaW1lKCkgLSBwYXJzZUFwaURhdGUoYi5jcmVhdGVkQXQpLmdldFRpbWUoKSk7XHJcbiAgICB9LCBbbWVzc2FnZXNRdWVyeS5kYXRhXSk7XHJcblxyXG4gICAgY29uc3QgcmVmcmVzaCA9ICgpID0+IHtcclxuICAgICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcInRhYmxlc1wiXSB9KTtcclxuICAgICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcIm9yZGVyc1wiXSB9KTtcclxuICAgICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcImNvbWFuZGFzXCJdIH0pO1xyXG4gICAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wid2FpdGVybWVzc2FnZXNcIl0gfSk7XHJcbiAgICB9O1xyXG4gICAgY29uc3QgYWxsQWN0aXZlT3JkZXJzID0gb3JkZXJzUXVlcnkuZGF0YSA/PyBbXTtcclxuICAgIGNvbnN0IG15T3JkZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFhY3RpdmVBcmVhSWQpIHJldHVybiBbXTtcclxuICAgICAgICByZXR1cm4gYWxsQWN0aXZlT3JkZXJzLmZpbHRlcihvcmRlciA9PiAob3JkZXIuY29tYW5kYUlkICE9PSBudWxsKSB8fCAob3JkZXIuZGluaW5nVGFibGVJZCAhPT0gbnVsbCAmJiBhbGxvd2VkVGFibGVJZHMuaGFzKG9yZGVyLmRpbmluZ1RhYmxlSWQpKSk7XHJcbiAgICB9LCBbYWxsQWN0aXZlT3JkZXJzLCBhY3RpdmVBcmVhSWQsIGFsbG93ZWRUYWJsZUlkc10pO1xyXG4gICAgY29uc3QgbXlUYWJsZXMgPSB1c2VNZW1vKCgpID0+ICh0YWJsZXNRdWVyeS5kYXRhID8/IFtdKS5maWx0ZXIoKHQpID0+IGFsbG93ZWRUYWJsZUlkcy5oYXModC5pZCkpLCBbdGFibGVzUXVlcnkuZGF0YSwgYWxsb3dlZFRhYmxlSWRzXSk7XHJcbiAgICBjb25zdCBvcmRlcnNCeVRhYmxlSWQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBjb25zdCBtYXAgPSBuZXcgTWFwPG51bWJlciwgT3JkZXJSZXNwb25zZT4oKTtcclxuICAgICAgICBmb3IgKGNvbnN0IG9yZGVyIG9mIGFsbEFjdGl2ZU9yZGVycykgaWYgKG9yZGVyLmRpbmluZ1RhYmxlSWQgIT09IG51bGwpIG1hcC5zZXQob3JkZXIuZGluaW5nVGFibGVJZCwgb3JkZXIpO1xyXG4gICAgICAgIHJldHVybiBtYXA7XHJcbiAgICB9LCBbYWxsQWN0aXZlT3JkZXJzXSk7XHJcbiAgICBjb25zdCB0YWJsZXNCeUlkID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgbWFwID0gbmV3IE1hcDxudW1iZXIsIFRhYmxlUmVzcG9uc2U+KCk7XHJcbiAgICAgICAgZm9yIChjb25zdCB0YWJsZSBvZiB0YWJsZXNRdWVyeS5kYXRhID8/IFtdKSBtYXAuc2V0KHRhYmxlLmlkLCB0YWJsZSk7XHJcbiAgICAgICAgcmV0dXJuIG1hcDtcclxuICAgIH0sIFt0YWJsZXNRdWVyeS5kYXRhXSk7XHJcbiAgICBjb25zdCBjb21hbmRhc0J5SWQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBjb25zdCBtYXAgPSBuZXcgTWFwPG51bWJlciwgQ29tYW5kYVJlc3BvbnNlPigpO1xyXG4gICAgICAgIGZvciAoY29uc3QgY29tYW5kYSBvZiBjb21hbmRhc1F1ZXJ5LmRhdGEgPz8gW10pIG1hcC5zZXQoY29tYW5kYS5pZCwgY29tYW5kYSk7XHJcbiAgICAgICAgcmV0dXJuIG1hcDtcclxuICAgIH0sIFtjb21hbmRhc1F1ZXJ5LmRhdGFdKTtcclxuICAgIGNvbnN0IG15T3BlblRhYmxlc0NvdW50ID0gbXlUYWJsZXMuZmlsdGVyKCh0KSA9PiB0LnRhYmxlU3RhdHVzSWQgPT09IFRhYmxlU3RhdHVzLk9jdXBhZGEgfHwgdC50YWJsZVN0YXR1c0lkID09PSBUYWJsZVN0YXR1cy5FbUZlY2hhbWVudG8pLmxlbmd0aDtcclxuICAgIGNvbnN0IHRhYmxlT3JkZXJzID0gdXNlTWVtbygoKSA9PiBteU9yZGVycy5maWx0ZXIoKG8pID0+IG8uZGluaW5nVGFibGVJZCAhPT0gbnVsbCksIFtteU9yZGVyc10pO1xyXG4gICAgY29uc3QgY29tYW5kYU9yZGVycyA9IHVzZU1lbW8oKCkgPT4gbXlPcmRlcnMuZmlsdGVyKChvKSA9PiBvLmNvbWFuZGFJZCAhPT0gbnVsbCAmJiBvLmRpbmluZ1RhYmxlSWQgPT09IG51bGwpLCBbbXlPcmRlcnNdKTtcclxuICAgIGNvbnN0IHRvdGFsVGFibGVzQW1vdW50ID0gdXNlTWVtbygoKSA9PiB0YWJsZU9yZGVycy5yZWR1Y2UoKHN1bSwgb3JkZXIpID0+IHN1bSArIG9yZGVyLnRvdGFsQW1vdW50LCAwKSwgW3RhYmxlT3JkZXJzXSk7XHJcbiAgICBjb25zdCB0b3RhbENvbWFuZGFzQW1vdW50ID0gdXNlTWVtbygoKSA9PiBjb21hbmRhT3JkZXJzLnJlZHVjZSgoc3VtLCBvcmRlcikgPT4gc3VtICsgb3JkZXIudG90YWxBbW91bnQsIDApLCBbY29tYW5kYU9yZGVyc10pO1xyXG4gICAgY29uc3QgcmVhZHlJdGVtc0NvdW50ID0gdXNlTWVtbygoKSA9PiBteU9yZGVycy5yZWR1Y2UoKHN1bSwgb3JkZXIpID0+IHN1bSArIG9yZGVyLml0ZW1zLmZpbHRlcigoaSkgPT4gaS5vcmRlckl0ZW1TdGF0dXNJZCA9PT0gT3JkZXJJdGVtU3RhdHVzLlByb250bykubGVuZ3RoLCAwKSwgW215T3JkZXJzXSk7XHJcbiAgICBjb25zdCBsYXRlc3RPcmRlcnMgPSB1c2VNZW1vKCgpID0+IFsuLi5teU9yZGVyc10uc29ydCgoYSwgYikgPT4gbmV3IERhdGUoYi5vcGVuZWRBdCkuZ2V0VGltZSgpIC0gbmV3IERhdGUoYS5vcGVuZWRBdCkuZ2V0VGltZSgpKS5zbGljZSgwLCAzKSwgW215T3JkZXJzXSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUXVpY2tBY3Rpb24gPSAoa2V5OiBRdWlja0FjdGlvbktleSkgPT4ge1xyXG4gICAgICAgIGlmIChrZXkgPT09IFwibWVzYXNcIiB8fCBrZXkgPT09IFwiY29tYW5kYXNcIikgc2V0QWN0aXZlVGFiKGtleSk7XHJcbiAgICAgICAgZWxzZSBpZiAoa2V5ID09PSBcInR1cm5vXCIpIHNldE9wZW5Nb2RhbChcImNhc2hcIik7XHJcbiAgICAgICAgZWxzZSBpZiAoa2V5ID09PSBcImNhbGN1bGFkb3JhXCIpIHNldE9wZW5Nb2RhbChcImNhbGN1bGF0b3JcIik7XHJcbiAgICAgICAgZWxzZSBpZiAoa2V5ID09PSBcInRyYW5zZmVyaXJcIikgc2V0T3Blbk1vZGFsKFwidHJhbnNmZXJcIik7XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3YWl0ZXItdmlld1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndhaXRlci1zaGVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPFdhaXRlckhlYWRlciB1c2VyTmFtZT17dXNlck5hbWV9IHJlYWR5SXRlbXNDb3VudD17cmVhZHlJdGVtc0NvdW50fSBvbkJlbGxDbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwibWVuc2FnZW5zXCIpfSAvPlxyXG4gICAgICAgICAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwid2FpdGVyLWJvZHlcIj5cclxuICAgICAgICAgICAgICAgICAgICB7KHRhYmxlc1F1ZXJ5LmlzRXJyb3IgfHwgb3JkZXJzUXVlcnkuaXNFcnJvciB8fCBjb21hbmRhc1F1ZXJ5LmlzRXJyb3IpICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3YWl0ZXItY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFF1ZXJ5RXJyb3IgZXJyb3I9e3RhYmxlc1F1ZXJ5LmVycm9yIHx8IG9yZGVyc1F1ZXJ5LmVycm9yIHx8IGNvbWFuZGFzUXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBkYWRvc1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgeyFhc3NpZ25tZW50UXVlcnkuaXNMb2FkaW5nICYmICFhY3RpdmVBcmVhSWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndhaXRlci1jYXJkXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcInZhcigtLXctd2FybilcIiwgcGFkZGluZzogMTIsIGJvcmRlclJhZGl1czogOCwgbWFyZ2luQm90dG9tOiAxNiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+U2VtIHByYcOnYSBhdHJpYnXDrWRhITwvc3Ryb25nPiBTb2xpY2l0ZSBhbyBnZXJlbnRlIHF1ZSBpbmljaWUgc2V1IHR1cm5vIGVtIHVtYSBwcmHDp2EuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJpbmljaW9cIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJJbmljaW9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG15T3BlblRhYmxlc0NvdW50PXtteU9wZW5UYWJsZXNDb3VudH0gbXlUb3RhbFRhYmxlcz17bXlUYWJsZXMubGVuZ3RofSBjb21hbmRhT3JkZXJzPXtjb21hbmRhT3JkZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbXlPcmRlcnM9e215T3JkZXJzfSB0b3RhbFRhYmxlc0Ftb3VudD17dG90YWxUYWJsZXNBbW91bnR9IHRvdGFsQ29tYW5kYXNBbW91bnQ9e3RvdGFsQ29tYW5kYXNBbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXRlc3RPcmRlcnM9e2xhdGVzdE9yZGVyc30gdGFibGVzQnlJZD17dGFibGVzQnlJZH0gY29tYW5kYXNCeUlkPXtjb21hbmRhc0J5SWR9IGNhblNlZUNhaXhhPXtjYW5TZWVDYWl4YX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uVGFiQ2hhbmdlPXtzZXRBY3RpdmVUYWJ9IG9uUXVpY2tBY3Rpb249e2hhbmRsZVF1aWNrQWN0aW9ufSBvbk9yZGVyQ2xpY2s9e3NldFNlbGVjdGVkT3JkZXJJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwibWVzYXNcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJNZXNhc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlQXJlYUlkPXthY3RpdmVBcmVhSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBteVRhYmxlcz17bXlUYWJsZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcmRlcnNCeVRhYmxlSWQ9e29yZGVyc0J5VGFibGVJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uVGFibGVDbGljaz17KHRhYmxlSWQsIHN0YXR1cykgPT4gc3RhdHVzID09PSBUYWJsZVN0YXR1cy5MaXZyZSA/IHNldFRhYmxlVG9PcGVuKG15VGFibGVzLmZpbmQodCA9PiB0LmlkID09PSB0YWJsZUlkKSEpIDogc2V0U2VsZWN0ZWRPcmRlcklkKG15T3JkZXJzLmZpbmQobyA9PiBvLmRpbmluZ1RhYmxlSWQgPT09IHRhYmxlSWQpPy5pZCB8fCBudWxsKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiY29tYW5kYXNcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJDb21hbmRhc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtjb21hbmRhc1F1ZXJ5LmlzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbWFuZGFzPXtjb21hbmRhc1F1ZXJ5LmRhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21hbmRhT3JkZXJzPXtjb21hbmRhT3JkZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db21hbmRhQ2xpY2s9eyhjb21hbmRhLCBvcmRlcklkKSA9PiBvcmRlcklkID8gc2V0U2VsZWN0ZWRPcmRlcklkKG9yZGVySWQpIDogc2V0Q29tYW5kYVRvT3Blbihjb21hbmRhKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwicGVkaWRvc1wiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRhYlBlZGlkb3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG15T3JkZXJzPXtteU9yZGVyc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhYmxlc0J5SWQ9e3RhYmxlc0J5SWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21hbmRhc0J5SWQ9e2NvbWFuZGFzQnlJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uT3JkZXJDbGljaz17c2V0U2VsZWN0ZWRPcmRlcklkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJtZW5zYWdlbnNcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJNZW5zYWdlbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZUFyZWFJZD17YWN0aXZlQXJlYUlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXttZXNzYWdlc1F1ZXJ5LmlzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXJyb3I9e21lc3NhZ2VzUXVlcnkuaXNFcnJvcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yPXttZXNzYWdlc1F1ZXJ5LmVycm9yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZXM9e3NvcnRlZE1lc3NhZ2VzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L21haW4+XHJcbiAgICAgICAgICAgICAgICA8V2FpdGVyVGFiQmFyXHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiPXthY3RpdmVUYWJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25UYWJDaGFuZ2U9eyhrZXkpID0+IGtleSA9PT0gXCJwZXJmaWxcIiA/IHNldE9wZW5Nb2RhbChcInByb2ZpbGVcIikgOiBzZXRBY3RpdmVUYWIoa2V5KX1cclxuICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIE1vZGFpcyBHbG9iYWlzICovfVxyXG4gICAgICAgICAgICAgICAge29wZW5Nb2RhbCA9PT0gXCJjYWxjdWxhdG9yXCIgJiYgPENhbGN1bGF0b3JNb2RhbCBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuTW9kYWwobnVsbCl9IC8+fVxyXG4gICAgICAgICAgICAgICAge29wZW5Nb2RhbCA9PT0gXCJwcm9maWxlXCIgJiYgPFdhaXRlclByb2ZpbGVNb2RhbCB1c2VyTmFtZT17dXNlck5hbWV9IGJyYW5jaElkPXticmFuY2hJZH0gb25DbG9zZT17KCkgPT4gc2V0T3Blbk1vZGFsKG51bGwpfSBvbkxvZ291dD17aGFuZGxlTG9nb3V0fSAvPn1cclxuICAgICAgICAgICAgICAgIHtvcGVuTW9kYWwgPT09IFwiY2FzaFwiICYmIDxDYXNoRHJhd2VyIG9uQ2xvc2U9eygpID0+IHNldE9wZW5Nb2RhbChudWxsKX0gLz59XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIE1vZGFsIFVuaWZpY2FkbyBkZSBUcmFuc2ZlcsOqbmNpYSAoTWVzYXMgLyBDb21hbmRhcykgKi99XHJcbiAgICAgICAgICAgICAgICB7b3Blbk1vZGFsID09PSBcInRyYW5zZmVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxUcmFuc2Zlckl0ZW1Nb2RhbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2RlPVwidGFibGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBteVRhYmxlcz17bXlUYWJsZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbWFuZGFzPXtjb21hbmRhc1F1ZXJ5LmRhdGEgPz8gW119XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbWFuZGFPcmRlcnM9e2NvbWFuZGFPcmRlcnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9yZGVyc0J5VGFibGVJZD17b3JkZXJzQnlUYWJsZUlkfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWxsQWN0aXZlT3JkZXJzPXthbGxBY3RpdmVPcmRlcnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtcGxveWVlSWQ9e2VtcGxveWVlSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE9wZW5Nb2RhbChudWxsKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25TdWNjZXNzPXtzaG93VG9hc3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9e3Nob3dUb2FzdH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7dGFibGVUb09wZW4gJiYgPFdhaXRlck9wZW5UYWJsZU1vZGFsIHRhYmxlPXt0YWJsZVRvT3Blbn0gb25DbG9zZT17KCkgPT4gc2V0VGFibGVUb09wZW4obnVsbCl9IG9uT3BlbmVkPXsoaWQpID0+IHsgc2V0VGFibGVUb09wZW4obnVsbCk7IHJlZnJlc2goKTsgc2V0U2VsZWN0ZWRPcmRlcklkKGlkKTsgfX0gLz59XHJcbiAgICAgICAgICAgICAgICB7Y29tYW5kYVRvT3BlbiAmJiA8V2FpdGVyT3BlbkNvbWFuZGFNb2RhbCBjb21hbmRhPXtjb21hbmRhVG9PcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRDb21hbmRhVG9PcGVuKG51bGwpfSBvbk9wZW5lZD17KGlkKSA9PiB7IHNldENvbWFuZGFUb09wZW4obnVsbCk7IHJlZnJlc2goKTsgc2V0U2VsZWN0ZWRPcmRlcklkKGlkKTsgfX0gLz59XHJcblxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkT3JkZXJJZCAhPT0gbnVsbCAmJiA8T3JkZXJEcmF3ZXIgb3JkZXJJZD17c2VsZWN0ZWRPcmRlcklkfSBvbkNsb3NlPXsoKSA9PiB7IHNldFNlbGVjdGVkT3JkZXJJZChudWxsKTsgcmVmcmVzaCgpOyB9fSAvPn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7dG9hc3QgJiYgPGRpdiBjbGFzc05hbWU9XCJ3YWl0ZXItdG9hc3RcIiByb2xlPVwic3RhdHVzXCI+e3RvYXN0fTwvZGl2Pn1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn0iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvd2FpdGVyL1dhaXRlckRhc2hib2FyZFBhZ2UudHN4In0=