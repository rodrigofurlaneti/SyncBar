import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cash/CashHistoryPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { getCashHistory, reviewCashSession } from "/src/features/cash/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { ApiError } from "/src/lib/apiClient.ts";
import { CashSessionStatus, formatBRL } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
function currentMonthValue() {
  const now = /* @__PURE__ */ new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}
function totalDiffColor(totalDiff) {
  if (totalDiff === 0) return "var(--ok)";
  if (totalDiff > 0) return "var(--busy)";
  return "var(--danger)";
}
function differenceBadge(session) {
  if (session.cashSessionStatusId === CashSessionStatus.Aberto)
    return { label: "Em aberto", color: "var(--reserved)" };
  const diff = session.differenceAmount ?? 0;
  if (diff === 0) return { label: "Bateu", color: "var(--ok)" };
  if (diff > 0) return { label: `Sobra ${formatBRL(diff)}`, color: "var(--busy)" };
  return { label: `Falta ${formatBRL(Math.abs(diff))}`, color: "var(--danger)" };
}
const fmtTime = (iso) => new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
export function CashHistoryPage() {
  _s();
  const queryClient = useQueryClient();
  const { branchId } = useAuthStore();
  const [monthValue, setMonthValue] = useState(currentMonthValue());
  const [error, setError] = useState(null);
  const [yearStr, monthStr] = monthValue.split("-");
  const year = Number(yearStr);
  const month = Number(monthStr);
  const historyQuery = useQuery({
    queryKey: ["cash", "history", branchId, year, month],
    queryFn: () => getCashHistory(branchId, year, month),
    enabled: Number.isFinite(year) && Number.isFinite(month)
  });
  const reviewMutation = useMutation({
    mutationFn: (id) => reviewCashSession(id),
    onSuccess: () => {
      setError(null);
      void queryClient.invalidateQueries({ queryKey: ["cash", "history"] });
    },
    onError: (e) => setError(e instanceof ApiError ? e.message : "Falha ao conferir.")
  });
  const sessions = historyQuery.data ?? [];
  const closed = sessions.filter((s) => s.cashSessionStatusId !== CashSessionStatus.Aberto);
  const totalDiff = closed.reduce((sum, s) => sum + (s.differenceAmount ?? 0), 0);
  const divergent = closed.filter((s) => (s.differenceAmount ?? 0) !== 0).length;
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22, maxWidth: 1100, margin: "0 auto" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "center", gap: 14, marginBottom: 6, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Fechamentos de caixa" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
        lineNumber: 85,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { flex: 1 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
        lineNumber: 86,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "month", value: monthValue, onChange: (e) => setMonthValue(e.target.value), style: { width: 190 } }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
        lineNumber: 87,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
      lineNumber: 84,
      columnNumber: 7
    }, this),
    closed.length > 0 && /* @__PURE__ */ jsxDEV("p", { className: "rise", style: { color: "var(--ink-dim)", fontSize: "0.9rem", marginTop: 0 }, children: [
      closed.length,
      " fechamentos no mês · ",
      divergent === 0 ? "todos bateram" : `${divergent} com divergência`,
      " · saldo das diferenças:",
      " ",
      /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: totalDiffColor(totalDiff), fontWeight: 700 }, children: [
        totalDiff > 0 ? "+" : "",
        formatBRL(totalDiff)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
        lineNumber: 94,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    historyQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: historyQuery.error, what: "os fechamentos" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
      lineNumber: 100,
      columnNumber: 32
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "error-text", children: error }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
      lineNumber: 101,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ticket rise rise-1", children: [
      sessions.map((session) => {
        const badge = differenceBadge(session);
        return /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { flexWrap: "wrap", gap: 10 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 3, minWidth: 220 }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              session.cashRegisterName,
              " · sessão #",
              session.id,
              session.cashSessionStatusId === CashSessionStatus.Conferido && /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ok)", fontSize: "0.78rem", marginLeft: 8 }, children: "✓ conferido" }, void 0, false, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
                lineNumber: 112,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
              lineNumber: 109,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
              fmtTime(session.openedAt),
              session.closedAt ? ` → ${fmtTime(session.closedAt)}` : " → em aberto",
              session.openedByName ? ` · abriu ${session.openedByName}` : "",
              session.closedByName ? ` · fechou ${session.closedByName}` : ""
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
              lineNumber: 115,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { fontSize: "0.8rem", color: "var(--ink-faint)" }, children: [
              session.salesCount,
              " vendas (",
              formatBRL(session.salesTotal),
              ") · fundo ",
              formatBRL(session.openingAmount),
              session.expectedAmount !== null && ` · esperado ${formatBRL(session.expectedAmount)}`,
              session.closingAmount !== null && ` · contado ${formatBRL(session.closingAmount)}`
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
              lineNumber: 121,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
            lineNumber: 108,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, alignItems: "center", marginLeft: "auto" }, children: [
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: "chip",
                style: { "--dot": badge.color, color: badge.color, borderColor: badge.color },
                children: badge.label
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
                lineNumber: 128,
                columnNumber: 17
              },
              this
            ),
            session.cashSessionStatusId === CashSessionStatus.Fechado && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "btn-ghost",
                style: { minHeight: 38, padding: "0 12px", fontSize: "0.85rem" },
                disabled: reviewMutation.isPending,
                onClick: () => reviewMutation.mutate(session.id),
                children: "Marcar conferido"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
                lineNumber: 135,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
            lineNumber: 127,
            columnNumber: 15
          }, this)
        ] }, session.id, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
          lineNumber: 107,
          columnNumber: 13
        }, this);
      }),
      sessions.length === 0 && !historyQuery.isLoading && /* @__PURE__ */ jsxDEV("div", { className: "ticket-row", style: { color: "var(--ink-faint)" }, children: "Nenhuma sessão de caixa neste mês." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
        lineNumber: 150,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
      lineNumber: 103,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx",
    lineNumber: 83,
    columnNumber: 5
  }, this);
}
_s(CashHistoryPage, "EoPkYLY4KbN1k5kYOEAw2yHcKwo=", false, function() {
  return [useQueryClient, useAuthStore, useQuery, useMutation];
});
_c = CashHistoryPage;
var _c;
$RefreshReg$(_c, "CashHistoryPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/cash/CashHistoryPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUVROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpFUixTQUFTQSxnQkFBb0M7QUFDN0MsU0FBU0MsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLGdCQUFnQkMseUJBQXlCO0FBQ2xELFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CQyxpQkFBaUI7QUFFN0MsU0FBU0Msa0JBQWtCO0FBRTNCLFNBQVNDLG9CQUE0QjtBQUNuQyxRQUFNQyxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFNBQU8sR0FBR0QsSUFBSUUsWUFBWSxDQUFDLElBQUlDLE9BQU9ILElBQUlJLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDNUU7QUFFQSxTQUFTQyxlQUFlQyxXQUEyQjtBQUNqRCxNQUFJQSxjQUFjLEVBQUcsUUFBTztBQUM1QixNQUFJQSxZQUFZLEVBQUcsUUFBTztBQUMxQixTQUFPO0FBQ1Q7QUFFQSxTQUFTQyxnQkFBZ0JDLFNBQXFDO0FBQzVELE1BQUlBLFFBQVFDLHdCQUF3QmQsa0JBQWtCZTtBQUNwRCxXQUFPLEVBQUVDLE9BQU8sYUFBYUMsT0FBTyxrQkFBa0I7QUFDeEQsUUFBTUMsT0FBT0wsUUFBUU0sb0JBQW9CO0FBQ3pDLE1BQUlELFNBQVMsRUFBRyxRQUFPLEVBQUVGLE9BQU8sU0FBU0MsT0FBTyxZQUFZO0FBQzVELE1BQUlDLE9BQU8sRUFBRyxRQUFPLEVBQUVGLE9BQU8sU0FBU2YsVUFBVWlCLElBQUksQ0FBQyxJQUFJRCxPQUFPLGNBQWM7QUFDL0UsU0FBTyxFQUFFRCxPQUFPLFNBQVNmLFVBQVVtQixLQUFLQyxJQUFJSCxJQUFJLENBQUMsQ0FBQyxJQUFJRCxPQUFPLGdCQUFnQjtBQUMvRTtBQUVBLE1BQU1LLFVBQVVBLENBQUNDLFFBQ2YsSUFBSWxCLEtBQUtrQixHQUFHLEVBQUVDLGVBQWUsU0FBUyxFQUFFQyxLQUFLLFdBQVdDLE9BQU8sV0FBV0MsTUFBTSxXQUFXQyxRQUFRLFVBQVUsQ0FBQztBQUV6RyxnQkFBU0Msa0JBQWtCO0FBQUFDLEtBQUE7QUFDaEMsUUFBTUMsY0FBY3BDLGVBQWU7QUFDbkMsUUFBTSxFQUFFcUMsU0FBUyxJQUFJbEMsYUFBYTtBQUNsQyxRQUFNLENBQUNtQyxZQUFZQyxhQUFhLElBQUkxQyxTQUFTVyxrQkFBa0IsQ0FBQztBQUNoRSxRQUFNLENBQUNnQyxPQUFPQyxRQUFRLElBQUk1QyxTQUF3QixJQUFJO0FBRXRELFFBQU0sQ0FBQzZDLFNBQVNDLFFBQVEsSUFBSUwsV0FBV00sTUFBTSxHQUFHO0FBQ2hELFFBQU1DLE9BQU9DLE9BQU9KLE9BQU87QUFDM0IsUUFBTVgsUUFBUWUsT0FBT0gsUUFBUTtBQUU3QixRQUFNSSxlQUFlaEQsU0FBUztBQUFBLElBQzVCaUQsVUFBVSxDQUFDLFFBQVEsV0FBV1gsVUFBVVEsTUFBTWQsS0FBSztBQUFBLElBQ25Ea0IsU0FBU0EsTUFBTWhELGVBQWVvQyxVQUFVUSxNQUFNZCxLQUFLO0FBQUEsSUFDbkRtQixTQUFTSixPQUFPSyxTQUFTTixJQUFJLEtBQUtDLE9BQU9LLFNBQVNwQixLQUFLO0FBQUEsRUFDekQsQ0FBQztBQUVELFFBQU1xQixpQkFBaUJ0RCxZQUFZO0FBQUEsSUFDakN1RCxZQUFZQSxDQUFDQyxPQUFlcEQsa0JBQWtCb0QsRUFBRTtBQUFBLElBQ2hEQyxXQUFXQSxNQUFNO0FBQ2ZkLGVBQVMsSUFBSTtBQUNiLFdBQUtMLFlBQVlvQixrQkFBa0IsRUFBRVIsVUFBVSxDQUFDLFFBQVEsU0FBUyxFQUFFLENBQUM7QUFBQSxJQUN0RTtBQUFBLElBQ0FTLFNBQVNBLENBQUNDLE1BQU1qQixTQUFTaUIsYUFBYXRELFdBQVdzRCxFQUFFQyxVQUFVLG9CQUFvQjtBQUFBLEVBQ25GLENBQUM7QUFFRCxRQUFNQyxXQUFXYixhQUFhYyxRQUFRO0FBQ3RDLFFBQU1DLFNBQVNGLFNBQVNHLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRTdDLHdCQUF3QmQsa0JBQWtCZSxNQUFNO0FBQ3hGLFFBQU1KLFlBQVk4QyxPQUFPRyxPQUFPLENBQUNDLEtBQUtGLE1BQU1FLE9BQU9GLEVBQUV4QyxvQkFBb0IsSUFBSSxDQUFDO0FBQzlFLFFBQU0yQyxZQUFZTCxPQUFPQyxPQUFPLENBQUNDLE9BQU9BLEVBQUV4QyxvQkFBb0IsT0FBTyxDQUFDLEVBQUU0QztBQUV4RSxTQUNFLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxTQUFTLElBQUlDLFVBQVUsTUFBTUMsUUFBUSxTQUFTLEdBQzNEO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFQyxTQUFTLFFBQVFDLFlBQVksVUFBVUMsS0FBSyxJQUFJQyxjQUFjLEdBQUdDLFVBQVUsT0FBTyxHQUMvRztBQUFBLDZCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRUMsVUFBVSxTQUFTLEdBQUcsb0NBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkU7QUFBQSxNQUMzRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsTUFBTSxFQUFFLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxXQUFNLE1BQUssU0FBUSxPQUFPeEMsWUFBWSxVQUFVLENBQUNvQixNQUFNbkIsY0FBY21CLEVBQUVxQixPQUFPQyxLQUFLLEdBQUcsT0FBTyxFQUFFQyxPQUFPLElBQUksS0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RztBQUFBLFNBSC9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUNuQixPQUFPTSxTQUFTLEtBQ2YsdUJBQUMsT0FBRSxXQUFVLFFBQU8sT0FBTyxFQUFFOUMsT0FBTyxrQkFBa0J1RCxVQUFVLFVBQVVLLFdBQVcsRUFBRSxHQUNwRnBCO0FBQUFBLGFBQU9NO0FBQUFBLE1BQU87QUFBQSxNQUF1QkQsY0FBYyxJQUFJLGtCQUFrQixHQUFHQSxTQUFTO0FBQUEsTUFBbUI7QUFBQSxNQUNuRjtBQUFBLE1BQ3RCLHVCQUFDLFVBQUssV0FBVSxZQUFXLE9BQU8sRUFBRTdDLE9BQU9QLGVBQWVDLFNBQVMsR0FBR21FLFlBQVksSUFBSSxHQUNuRm5FO0FBQUFBLG9CQUFZLElBQUksTUFBTTtBQUFBLFFBQUlWLFVBQVVVLFNBQVM7QUFBQSxXQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBR0QrQixhQUFhcUMsV0FBVyx1QkFBQyxjQUFXLE9BQU9yQyxhQUFhUCxPQUFPLE1BQUssb0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQ7QUFBQSxJQUNwRkEsU0FBUyx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUUzQyx1QkFBQyxTQUFJLFdBQVUsc0JBQ1pvQjtBQUFBQSxlQUFTeUIsSUFBSSxDQUFDbkUsWUFBWTtBQUN6QixjQUFNb0UsUUFBUXJFLGdCQUFnQkMsT0FBTztBQUNyQyxlQUNFLHVCQUFDLFNBQUksV0FBVSxjQUE4QixPQUFPLEVBQUUwRCxVQUFVLFFBQVFGLEtBQUssR0FBRyxHQUM5RTtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFRixTQUFTLFFBQVFFLEtBQUssR0FBR2EsVUFBVSxJQUFJLEdBQ25EO0FBQUEsbUNBQUMsVUFDRXJFO0FBQUFBLHNCQUFRc0U7QUFBQUEsY0FBaUI7QUFBQSxjQUFZdEUsUUFBUW9DO0FBQUFBLGNBQzdDcEMsUUFBUUMsd0JBQXdCZCxrQkFBa0JvRixhQUNqRCx1QkFBQyxVQUFLLE9BQU8sRUFBRW5FLE9BQU8sYUFBYXVELFVBQVUsV0FBV2EsWUFBWSxFQUFFLEdBQUcsMkJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9GO0FBQUEsaUJBSHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFYixVQUFVLFVBQVV2RCxPQUFPLG1CQUFtQixHQUMxREs7QUFBQUEsc0JBQVFULFFBQVF5RSxRQUFRO0FBQUEsY0FDeEJ6RSxRQUFRMEUsV0FBVyxNQUFNakUsUUFBUVQsUUFBUTBFLFFBQVEsQ0FBQyxLQUFLO0FBQUEsY0FDdkQxRSxRQUFRMkUsZUFBZSxZQUFZM0UsUUFBUTJFLFlBQVksS0FBSztBQUFBLGNBQzVEM0UsUUFBUTRFLGVBQWUsYUFBYTVFLFFBQVE0RSxZQUFZLEtBQUs7QUFBQSxpQkFKaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLFlBQVcsT0FBTyxFQUFFakIsVUFBVSxVQUFVdkQsT0FBTyxtQkFBbUIsR0FDL0VKO0FBQUFBLHNCQUFRNkU7QUFBQUEsY0FBVztBQUFBLGNBQVV6RixVQUFVWSxRQUFROEUsVUFBVTtBQUFBLGNBQUU7QUFBQSxjQUFXMUYsVUFBVVksUUFBUStFLGFBQWE7QUFBQSxjQUNyRy9FLFFBQVFnRixtQkFBbUIsUUFBUSxlQUFlNUYsVUFBVVksUUFBUWdGLGNBQWMsQ0FBQztBQUFBLGNBQ25GaEYsUUFBUWlGLGtCQUFrQixRQUFRLGNBQWM3RixVQUFVWSxRQUFRaUYsYUFBYSxDQUFDO0FBQUEsaUJBSG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUzQixTQUFTLFFBQVFFLEtBQUssSUFBSUQsWUFBWSxVQUFVaUIsWUFBWSxPQUFPLEdBQy9FO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFLFNBQVNKLE1BQU1oRSxPQUFPQSxPQUFPZ0UsTUFBTWhFLE9BQU84RSxhQUFhZCxNQUFNaEUsTUFBTTtBQUFBLGdCQUUzRWdFLGdCQUFNakU7QUFBQUE7QUFBQUEsY0FKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0NILFFBQVFDLHdCQUF3QmQsa0JBQWtCZ0csV0FDakQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRUMsV0FBVyxJQUFJakMsU0FBUyxVQUFVUSxVQUFVLFVBQVU7QUFBQSxnQkFDL0QsVUFBVXpCLGVBQWVtRDtBQUFBQSxnQkFDekIsU0FBUyxNQUFNbkQsZUFBZW9ELE9BQU90RixRQUFRb0MsRUFBRTtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUF0QytCcEMsUUFBUW9DLElBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1Q0E7QUFBQSxNQUVKLENBQUM7QUFBQSxNQUNBTSxTQUFTUSxXQUFXLEtBQUssQ0FBQ3JCLGFBQWEwRCxhQUN0Qyx1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVuRixPQUFPLG1CQUFtQixHQUFHLGtEQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQWpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbURBO0FBQUEsT0F2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdFQTtBQUVKO0FBQUNhLEdBekdlRCxpQkFBZTtBQUFBLFVBQ1RsQyxnQkFDQ0csY0FRQUosVUFNRUQsV0FBVztBQUFBO0FBQUEsS0FoQnBCb0M7QUFBZSxJQUFBd0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJnZXRDYXNoSGlzdG9yeSIsInJldmlld0Nhc2hTZXNzaW9uIiwidXNlQXV0aFN0b3JlIiwiQXBpRXJyb3IiLCJDYXNoU2Vzc2lvblN0YXR1cyIsImZvcm1hdEJSTCIsIlF1ZXJ5RXJyb3IiLCJjdXJyZW50TW9udGhWYWx1ZSIsIm5vdyIsIkRhdGUiLCJnZXRGdWxsWWVhciIsIlN0cmluZyIsImdldE1vbnRoIiwicGFkU3RhcnQiLCJ0b3RhbERpZmZDb2xvciIsInRvdGFsRGlmZiIsImRpZmZlcmVuY2VCYWRnZSIsInNlc3Npb24iLCJjYXNoU2Vzc2lvblN0YXR1c0lkIiwiQWJlcnRvIiwibGFiZWwiLCJjb2xvciIsImRpZmYiLCJkaWZmZXJlbmNlQW1vdW50IiwiTWF0aCIsImFicyIsImZtdFRpbWUiLCJpc28iLCJ0b0xvY2FsZVN0cmluZyIsImRheSIsIm1vbnRoIiwiaG91ciIsIm1pbnV0ZSIsIkNhc2hIaXN0b3J5UGFnZSIsIl9zIiwicXVlcnlDbGllbnQiLCJicmFuY2hJZCIsIm1vbnRoVmFsdWUiLCJzZXRNb250aFZhbHVlIiwiZXJyb3IiLCJzZXRFcnJvciIsInllYXJTdHIiLCJtb250aFN0ciIsInNwbGl0IiwieWVhciIsIk51bWJlciIsImhpc3RvcnlRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImVuYWJsZWQiLCJpc0Zpbml0ZSIsInJldmlld011dGF0aW9uIiwibXV0YXRpb25GbiIsImlkIiwib25TdWNjZXNzIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJvbkVycm9yIiwiZSIsIm1lc3NhZ2UiLCJzZXNzaW9ucyIsImRhdGEiLCJjbG9zZWQiLCJmaWx0ZXIiLCJzIiwicmVkdWNlIiwic3VtIiwiZGl2ZXJnZW50IiwibGVuZ3RoIiwicGFkZGluZyIsIm1heFdpZHRoIiwibWFyZ2luIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJnYXAiLCJtYXJnaW5Cb3R0b20iLCJmbGV4V3JhcCIsImZvbnRTaXplIiwiZmxleCIsInRhcmdldCIsInZhbHVlIiwid2lkdGgiLCJtYXJnaW5Ub3AiLCJmb250V2VpZ2h0IiwiaXNFcnJvciIsIm1hcCIsImJhZGdlIiwibWluV2lkdGgiLCJjYXNoUmVnaXN0ZXJOYW1lIiwiQ29uZmVyaWRvIiwibWFyZ2luTGVmdCIsIm9wZW5lZEF0IiwiY2xvc2VkQXQiLCJvcGVuZWRCeU5hbWUiLCJjbG9zZWRCeU5hbWUiLCJzYWxlc0NvdW50Iiwic2FsZXNUb3RhbCIsIm9wZW5pbmdBbW91bnQiLCJleHBlY3RlZEFtb3VudCIsImNsb3NpbmdBbW91bnQiLCJib3JkZXJDb2xvciIsIkZlY2hhZG8iLCJtaW5IZWlnaHQiLCJpc1BlbmRpbmciLCJtdXRhdGUiLCJpc0xvYWRpbmciLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXNoSGlzdG9yeVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB0eXBlIENTU1Byb3BlcnRpZXMgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgZ2V0Q2FzaEhpc3RvcnksIHJldmlld0Nhc2hTZXNzaW9uIH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gXCIuLi8uLi9zdG9yZXMvYXV0aFN0b3JlXCI7XHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGlDbGllbnRcIjtcclxuaW1wb3J0IHsgQ2FzaFNlc3Npb25TdGF0dXMsIGZvcm1hdEJSTCB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHR5cGUgeyBDYXNoU2Vzc2lvbkhpc3RvcnlSZXNwb25zZSB9IGZyb20gXCIuLi8uLi9saWIvdHlwZXNcIjtcclxuaW1wb3J0IHsgUXVlcnlFcnJvciB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1F1ZXJ5RXJyb3JcIjtcclxuXHJcbmZ1bmN0aW9uIGN1cnJlbnRNb250aFZhbHVlKCk6IHN0cmluZyB7XHJcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICByZXR1cm4gYCR7bm93LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKG5vdy5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHRvdGFsRGlmZkNvbG9yKHRvdGFsRGlmZjogbnVtYmVyKTogc3RyaW5nIHtcclxuICBpZiAodG90YWxEaWZmID09PSAwKSByZXR1cm4gXCJ2YXIoLS1vaylcIjtcclxuICBpZiAodG90YWxEaWZmID4gMCkgcmV0dXJuIFwidmFyKC0tYnVzeSlcIjtcclxuICByZXR1cm4gXCJ2YXIoLS1kYW5nZXIpXCI7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRpZmZlcmVuY2VCYWRnZShzZXNzaW9uOiBDYXNoU2Vzc2lvbkhpc3RvcnlSZXNwb25zZSkge1xyXG4gIGlmIChzZXNzaW9uLmNhc2hTZXNzaW9uU3RhdHVzSWQgPT09IENhc2hTZXNzaW9uU3RhdHVzLkFiZXJ0bylcclxuICAgIHJldHVybiB7IGxhYmVsOiBcIkVtIGFiZXJ0b1wiLCBjb2xvcjogXCJ2YXIoLS1yZXNlcnZlZClcIiB9O1xyXG4gIGNvbnN0IGRpZmYgPSBzZXNzaW9uLmRpZmZlcmVuY2VBbW91bnQgPz8gMDtcclxuICBpZiAoZGlmZiA9PT0gMCkgcmV0dXJuIHsgbGFiZWw6IFwiQmF0ZXVcIiwgY29sb3I6IFwidmFyKC0tb2spXCIgfTtcclxuICBpZiAoZGlmZiA+IDApIHJldHVybiB7IGxhYmVsOiBgU29icmEgJHtmb3JtYXRCUkwoZGlmZil9YCwgY29sb3I6IFwidmFyKC0tYnVzeSlcIiB9O1xyXG4gIHJldHVybiB7IGxhYmVsOiBgRmFsdGEgJHtmb3JtYXRCUkwoTWF0aC5hYnMoZGlmZikpfWAsIGNvbG9yOiBcInZhcigtLWRhbmdlcilcIiB9O1xyXG59XHJcblxyXG5jb25zdCBmbXRUaW1lID0gKGlzbzogc3RyaW5nKSA9PlxyXG4gIG5ldyBEYXRlKGlzbykudG9Mb2NhbGVTdHJpbmcoXCJwdC1CUlwiLCB7IGRheTogXCIyLWRpZ2l0XCIsIG1vbnRoOiBcIjItZGlnaXRcIiwgaG91cjogXCIyLWRpZ2l0XCIsIG1pbnV0ZTogXCIyLWRpZ2l0XCIgfSk7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ2FzaEhpc3RvcnlQYWdlKCkge1xyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuICBjb25zdCB7IGJyYW5jaElkIH0gPSB1c2VBdXRoU3RvcmUoKTtcclxuICBjb25zdCBbbW9udGhWYWx1ZSwgc2V0TW9udGhWYWx1ZV0gPSB1c2VTdGF0ZShjdXJyZW50TW9udGhWYWx1ZSgpKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBbeWVhclN0ciwgbW9udGhTdHJdID0gbW9udGhWYWx1ZS5zcGxpdChcIi1cIik7XHJcbiAgY29uc3QgeWVhciA9IE51bWJlcih5ZWFyU3RyKTtcclxuICBjb25zdCBtb250aCA9IE51bWJlcihtb250aFN0cik7XHJcblxyXG4gIGNvbnN0IGhpc3RvcnlRdWVyeSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJjYXNoXCIsIFwiaGlzdG9yeVwiLCBicmFuY2hJZCwgeWVhciwgbW9udGhdLFxyXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0Q2FzaEhpc3RvcnkoYnJhbmNoSWQsIHllYXIsIG1vbnRoKSxcclxuICAgIGVuYWJsZWQ6IE51bWJlci5pc0Zpbml0ZSh5ZWFyKSAmJiBOdW1iZXIuaXNGaW5pdGUobW9udGgpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCByZXZpZXdNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46IChpZDogbnVtYmVyKSA9PiByZXZpZXdDYXNoU2Vzc2lvbihpZCksXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wiY2FzaFwiLCBcImhpc3RvcnlcIl0gfSk7XHJcbiAgICB9LFxyXG4gICAgb25FcnJvcjogKGUpID0+IHNldEVycm9yKGUgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGUubWVzc2FnZSA6IFwiRmFsaGEgYW8gY29uZmVyaXIuXCIpLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBzZXNzaW9ucyA9IGhpc3RvcnlRdWVyeS5kYXRhID8/IFtdO1xyXG4gIGNvbnN0IGNsb3NlZCA9IHNlc3Npb25zLmZpbHRlcigocykgPT4gcy5jYXNoU2Vzc2lvblN0YXR1c0lkICE9PSBDYXNoU2Vzc2lvblN0YXR1cy5BYmVydG8pO1xyXG4gIGNvbnN0IHRvdGFsRGlmZiA9IGNsb3NlZC5yZWR1Y2UoKHN1bSwgcykgPT4gc3VtICsgKHMuZGlmZmVyZW5jZUFtb3VudCA/PyAwKSwgMCk7XHJcbiAgY29uc3QgZGl2ZXJnZW50ID0gY2xvc2VkLmZpbHRlcigocykgPT4gKHMuZGlmZmVyZW5jZUFtb3VudCA/PyAwKSAhPT0gMCkubGVuZ3RoO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIsIG1heFdpZHRoOiAxMTAwLCBtYXJnaW46IFwiMCBhdXRvXCIgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDE0LCBtYXJnaW5Cb3R0b206IDYsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuN3JlbVwiIH19PkZlY2hhbWVudG9zIGRlIGNhaXhhPC9oMj5cclxuICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxIH19IC8+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJtb250aFwiIHZhbHVlPXttb250aFZhbHVlfSBvbkNoYW5nZT17KGUpID0+IHNldE1vbnRoVmFsdWUoZS50YXJnZXQudmFsdWUpfSBzdHlsZT17eyB3aWR0aDogMTkwIH19IC8+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge2Nsb3NlZC5sZW5ndGggPiAwICYmIChcclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJyaXNlXCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC45cmVtXCIsIG1hcmdpblRvcDogMCB9fT5cclxuICAgICAgICAgIHtjbG9zZWQubGVuZ3RofSBmZWNoYW1lbnRvcyBubyBtw6pzIMK3IHtkaXZlcmdlbnQgPT09IDAgPyBcInRvZG9zIGJhdGVyYW1cIiA6IGAke2RpdmVyZ2VudH0gY29tIGRpdmVyZ8OqbmNpYWB9IMK3XHJcbiAgICAgICAgICBzYWxkbyBkYXMgZGlmZXJlbsOnYXM6e1wiIFwifVxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIiBzdHlsZT17eyBjb2xvcjogdG90YWxEaWZmQ29sb3IodG90YWxEaWZmKSwgZm9udFdlaWdodDogNzAwIH19PlxyXG4gICAgICAgICAgICB7dG90YWxEaWZmID4gMCA/IFwiK1wiIDogXCJcIn17Zm9ybWF0QlJMKHRvdGFsRGlmZil9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge2hpc3RvcnlRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtoaXN0b3J5UXVlcnkuZXJyb3J9IHdoYXQ9XCJvcyBmZWNoYW1lbnRvc1wiIC8+fVxyXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItdGV4dFwiPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQgcmlzZSByaXNlLTFcIj5cclxuICAgICAgICB7c2Vzc2lvbnMubWFwKChzZXNzaW9uKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBiYWRnZSA9IGRpZmZlcmVuY2VCYWRnZShzZXNzaW9uKTtcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LXJvd1wiIGtleT17c2Vzc2lvbi5pZH0gc3R5bGU9e3sgZmxleFdyYXA6IFwid3JhcFwiLCBnYXA6IDEwIH19PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJncmlkXCIsIGdhcDogMywgbWluV2lkdGg6IDIyMCB9fT5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICB7c2Vzc2lvbi5jYXNoUmVnaXN0ZXJOYW1lfSDCtyBzZXNzw6NvICN7c2Vzc2lvbi5pZH1cclxuICAgICAgICAgICAgICAgICAge3Nlc3Npb24uY2FzaFNlc3Npb25TdGF0dXNJZCA9PT0gQ2FzaFNlc3Npb25TdGF0dXMuQ29uZmVyaWRvICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1vaylcIiwgZm9udFNpemU6IFwiMC43OHJlbVwiLCBtYXJnaW5MZWZ0OiA4IH19PuKckyBjb25mZXJpZG88L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICB7Zm10VGltZShzZXNzaW9uLm9wZW5lZEF0KX1cclxuICAgICAgICAgICAgICAgICAge3Nlc3Npb24uY2xvc2VkQXQgPyBgIOKGkiAke2ZtdFRpbWUoc2Vzc2lvbi5jbG9zZWRBdCl9YCA6IFwiIOKGkiBlbSBhYmVydG9cIn1cclxuICAgICAgICAgICAgICAgICAge3Nlc3Npb24ub3BlbmVkQnlOYW1lID8gYCDCtyBhYnJpdSAke3Nlc3Npb24ub3BlbmVkQnlOYW1lfWAgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICB7c2Vzc2lvbi5jbG9zZWRCeU5hbWUgPyBgIMK3IGZlY2hvdSAke3Nlc3Npb24uY2xvc2VkQnlOYW1lfWAgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW1cIiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjhyZW1cIiwgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICB7c2Vzc2lvbi5zYWxlc0NvdW50fSB2ZW5kYXMgKHtmb3JtYXRCUkwoc2Vzc2lvbi5zYWxlc1RvdGFsKX0pIMK3IGZ1bmRvIHtmb3JtYXRCUkwoc2Vzc2lvbi5vcGVuaW5nQW1vdW50KX1cclxuICAgICAgICAgICAgICAgICAge3Nlc3Npb24uZXhwZWN0ZWRBbW91bnQgIT09IG51bGwgJiYgYCDCtyBlc3BlcmFkbyAke2Zvcm1hdEJSTChzZXNzaW9uLmV4cGVjdGVkQW1vdW50KX1gfVxyXG4gICAgICAgICAgICAgICAgICB7c2Vzc2lvbi5jbG9zaW5nQW1vdW50ICE9PSBudWxsICYmIGAgwrcgY29udGFkbyAke2Zvcm1hdEJSTChzZXNzaW9uLmNsb3NpbmdBbW91bnQpfWB9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAxMCwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgbWFyZ2luTGVmdDogXCJhdXRvXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjaGlwXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgXCItLWRvdFwiOiBiYWRnZS5jb2xvciwgY29sb3I6IGJhZGdlLmNvbG9yLCBib3JkZXJDb2xvcjogYmFkZ2UuY29sb3IgfSBhcyBDU1NQcm9wZXJ0aWVzfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7YmFkZ2UubGFiZWx9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB7c2Vzc2lvbi5jYXNoU2Vzc2lvblN0YXR1c0lkID09PSBDYXNoU2Vzc2lvblN0YXR1cy5GZWNoYWRvICYmIChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWluSGVpZ2h0OiAzOCwgcGFkZGluZzogXCIwIDEycHhcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Jldmlld011dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZXZpZXdNdXRhdGlvbi5tdXRhdGUoc2Vzc2lvbi5pZCl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBNYXJjYXIgY29uZmVyaWRvXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0pfVxyXG4gICAgICAgIHtzZXNzaW9ucy5sZW5ndGggPT09IDAgJiYgIWhpc3RvcnlRdWVyeS5pc0xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtcm93XCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiIH19PlxyXG4gICAgICAgICAgICBOZW5odW1hIHNlc3PDo28gZGUgY2FpeGEgbmVzdGUgbcOqcy5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BTUQvc291cmNlL3JlcG9zL1N5bmNCYXIvZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2Nhc2gvQ2FzaEhpc3RvcnlQYWdlLnRzeCJ9