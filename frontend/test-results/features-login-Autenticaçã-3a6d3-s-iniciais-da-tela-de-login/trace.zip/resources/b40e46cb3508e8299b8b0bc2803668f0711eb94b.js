import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/waiter/components/modals/WaiterProfileModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function WaiterProfileModal({ userName, branchId, onClose, onLogout }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "modal-backdrop is-center",
      onMouseDown: (e) => {
        if (e.target === e.currentTarget) onClose();
      },
      style: { position: "absolute" },
      children: /* @__PURE__ */ jsxDEV("div", { className: "modal-panel is-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "modal-head", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.3rem" }, children: "Perfil" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
            lineNumber: 38,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-ghost btn-icon", onClick: onClose, children: "✕" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
            lineNumber: 39,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
          lineNumber: 37,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, marginBottom: "12px" }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Usuário" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
            lineNumber: 42,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: userName ?? "—" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
            lineNumber: 43,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
          lineNumber: 41,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4, marginBottom: "20px" }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontSize: "0.85rem" }, children: "Filial" }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
            lineNumber: 46,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Filial ",
            branchId
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
            lineNumber: 47,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
          lineNumber: 45,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn-danger btn-block", onClick: onLogout, children: "Sair" }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
          lineNumber: 49,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
        lineNumber: 36,
        columnNumber: 13
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx",
      lineNumber: 29,
      columnNumber: 5
    },
    this
  );
}
_c = WaiterProfileModal;
var _c;
$RefreshReg$(_c, "WaiterProfileModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/waiter/components/modals/WaiterProfileModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JvQjs7Ozs7Ozs7Ozs7Ozs7OztBQVhiLGdCQUFTQSxtQkFBbUIsRUFBRUMsVUFBVUMsVUFBVUMsU0FBU0MsU0FBa0MsR0FBRztBQUNuRyxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxXQUFVO0FBQUEsTUFDVixhQUFhLENBQUNDLE1BQU07QUFDaEIsWUFBSUEsRUFBRUMsV0FBV0QsRUFBRUUsY0FBZUosU0FBUTtBQUFBLE1BQzlDO0FBQUEsTUFDQSxPQUFPLEVBQUVLLFVBQVUsV0FBVztBQUFBLE1BRTlCLGlDQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxjQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFQyxVQUFVLFNBQVMsR0FBRyxzQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Q7QUFBQSxVQUMvRCx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHNCQUFxQixTQUFTTixTQUFTLGlCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLGFBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVPLFNBQVMsUUFBUUMsS0FBSyxHQUFHQyxjQUFjLE9BQU8sR0FDeEQ7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUMsT0FBTyxrQkFBa0JKLFVBQVUsVUFBVSxHQUFHLHVCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLFVBQ3RFLHVCQUFDLFVBQU1SLHNCQUFZLE9BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCO0FBQUEsYUFGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVMsU0FBUyxRQUFRQyxLQUFLLEdBQUdDLGNBQWMsT0FBTyxHQUN4RDtBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFQyxPQUFPLGtCQUFrQkosVUFBVSxVQUFVLEdBQUcsc0JBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsVUFDckUsdUJBQUMsVUFBSztBQUFBO0FBQUEsWUFBUVA7QUFBQUEsZUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QjtBQUFBLGFBRjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSx3QkFBdUIsU0FBU0UsVUFBVSxvQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUE7QUFBQSxJQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF3QkE7QUFFUjtBQUFDVSxLQTVCZWQ7QUFBa0IsSUFBQWM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiV2FpdGVyUHJvZmlsZU1vZGFsIiwidXNlck5hbWUiLCJicmFuY2hJZCIsIm9uQ2xvc2UiLCJvbkxvZ291dCIsImUiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwicG9zaXRpb24iLCJmb250U2l6ZSIsImRpc3BsYXkiLCJnYXAiLCJtYXJnaW5Cb3R0b20iLCJjb2xvciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIldhaXRlclByb2ZpbGVNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsi77u/aW50ZXJmYWNlIFdhaXRlclByb2ZpbGVNb2RhbFByb3BzIHtcclxuICAgIHVzZXJOYW1lOiBzdHJpbmcgfCBudWxsO1xyXG4gICAgYnJhbmNoSWQ6IG51bWJlcjtcclxuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgICBvbkxvZ291dDogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFdhaXRlclByb2ZpbGVNb2RhbCh7IHVzZXJOYW1lLCBicmFuY2hJZCwgb25DbG9zZSwgb25Mb2dvdXQgfTogV2FpdGVyUHJvZmlsZU1vZGFsUHJvcHMpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtb2RhbC1iYWNrZHJvcCBpcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICBvbk1vdXNlRG93bj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChlLnRhcmdldCA9PT0gZS5jdXJyZW50VGFyZ2V0KSBvbkNsb3NlKCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHBvc2l0aW9uOiBcImFic29sdXRlXCIgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtcGFuZWwgaXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS4zcmVtXCIgfX0+UGVyZmlsPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1naG9zdCBidG4taWNvblwiIG9uQ2xpY2s9e29uQ2xvc2V9PuKclTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQsIG1hcmdpbkJvdHRvbTogXCIxMnB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWRpbSlcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlVzdcOhcmlvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt1c2VyTmFtZSA/PyBcIuKAlFwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA0LCBtYXJnaW5Cb3R0b206IFwiMjBweFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLWluay1kaW0pXCIsIGZvbnRTaXplOiBcIjAuODVyZW1cIiB9fT5GaWxpYWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+RmlsaWFsIHticmFuY2hJZH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1kYW5nZXIgYnRuLWJsb2NrXCIgb25DbGljaz17b25Mb2dvdXR9PlxyXG4gICAgICAgICAgICAgICAgICAgIFNhaXJcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn0iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvd2FpdGVyL2NvbXBvbmVudHMvbW9kYWxzL1dhaXRlclByb2ZpbGVNb2RhbC50c3gifQ==