import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/preparation/PreparationPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ca0b4140"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=ca0b4140";
import { advanceItemStatus, getPreparationQueue } from "/src/features/preparation/api.ts";
import { useAuthStore } from "/src/stores/authStore.ts";
import { OrderItemStatus, orderItemStatusLabel, OrderType } from "/src/lib/types.ts";
import { QueryError } from "/src/components/QueryError.tsx";
function timeColor(ratio) {
  if (ratio >= 1) return "var(--danger)";
  if (ratio >= 0.7) return "var(--busy)";
  return "var(--free)";
}
const nextStatus = {
  [OrderItemStatus.Lancado]: { id: OrderItemStatus.EmPreparo, label: "Iniciar" },
  [OrderItemStatus.EnviadoCozinha]: { id: OrderItemStatus.EmPreparo, label: "Iniciar" },
  [OrderItemStatus.EmPreparo]: { id: OrderItemStatus.Pronto, label: "Pronto" },
  [OrderItemStatus.Pronto]: { id: OrderItemStatus.Entregue, label: "Entregue" }
};
function formatElapsed(ms) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1e3));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}
function parseLocalDateTime(dateString) {
  if (!dateString) return Date.now();
  const matches = dateString.match(/^(\d{4})-(\d{2})-(\d{2})[T\s](\d{2}):(\d{2}):(\d{2})/);
  if (!matches) {
    return new Date(dateString).getTime();
  }
  const [, year, month, day, hour, minute, second] = matches.map(Number);
  return new Date(year, month - 1, day, hour, minute, second).getTime();
}
function ItemRow({
  item,
  now,
  onAdvance,
  isPending
}) {
  const startedTime = parseLocalDateTime(item.startedAt);
  const elapsedMs = now - startedTime;
  const limitMs = item.limitMinutes * 6e4;
  const ratio = limitMs <= 0 ? 1 : elapsedMs / limitMs;
  const color = timeColor(ratio);
  const next = nextStatus[item.orderItemStatusId];
  const overdue = ratio >= 1;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: overdue ? "kds-overdue" : void 0,
      style: {
        display: "grid",
        gap: 6,
        padding: "10px 12px",
        borderBottom: "1px solid var(--line-soft)"
      },
      children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", gap: 8, alignItems: "baseline" }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600 }, children: [
            item.quantity,
            " × ",
            item.productName,
            item.isBarItem && /* @__PURE__ */ jsxDEV(
              "span",
              {
                style: {
                  marginLeft: 8,
                  fontFamily: "var(--font-cond)",
                  fontSize: "0.7rem",
                  letterSpacing: "0.1em",
                  color: "var(--reserved)",
                  border: "1px solid var(--reserved)",
                  borderRadius: 4,
                  padding: "1px 6px",
                  verticalAlign: "middle"
                },
                children: "BAR"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
                lineNumber: 94,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
            lineNumber: 91,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mono-num display", style: { fontSize: "1.15rem", color }, children: formatElapsed(elapsedMs) }, void 0, false, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
            lineNumber: 111,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
          lineNumber: 90,
          columnNumber: 13
        }, this),
        item.notes && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.82rem", color: "var(--amber)" }, children: [
          "“",
          item.notes,
          "”"
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
          lineNumber: 117,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { background: "var(--bg-press)", borderRadius: 999, height: 8, overflow: "hidden" }, children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            style: {
              width: `${Math.min(100, ratio * 100)}%`,
              height: "100%",
              background: color,
              transition: "width 1s linear, background 300ms ease"
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
            lineNumber: 121,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
          lineNumber: 120,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.78rem", color: "var(--ink-faint)" }, children: [
            orderItemStatusLabel[item.orderItemStatusId],
            " · limite ",
            item.limitMinutes,
            " min",
            item.requestedBy && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              " · ",
              /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-dim)", fontWeight: 600 }, children: [
                "por ",
                item.requestedBy
              ] }, void 0, true, {
                fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
                lineNumber: 137,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
              lineNumber: 135,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
            lineNumber: 132,
            columnNumber: 17
          }, this),
          next && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "btn-primary",
              style: { minHeight: 40, padding: "0 16px", fontSize: "0.9rem" },
              disabled: isPending,
              onClick: () => onAdvance(next.id),
              children: next.label
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
              lineNumber: 142,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
          lineNumber: 131,
          columnNumber: 13
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
      lineNumber: 81,
      columnNumber: 5
    },
    this
  );
}
_c = ItemRow;
export function PreparationPage() {
  _s();
  const queryClient = useQueryClient();
  const { branchId } = useAuthStore();
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1e3);
    return () => clearInterval(timer);
  }, []);
  const queueQuery = useQuery({
    queryKey: ["preparation", branchId],
    queryFn: () => getPreparationQueue(branchId),
    refetchInterval: 1e4
  });
  const advanceMutation = useMutation({
    mutationFn: ({ orderId, itemId, statusId }) => advanceItemStatus(orderId, itemId, statusId),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ["preparation"] })
  });
  const tickets = queueQuery.data ?? [];
  return /* @__PURE__ */ jsxDEV("main", { style: { padding: 22 }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rise", style: { display: "flex", alignItems: "baseline", gap: 14, marginBottom: 6 }, children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "display", style: { fontSize: "1.7rem" }, children: "Preparo" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
        lineNumber: 184,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)", fontSize: "0.9rem" }, children: "verde no prazo · amarelo atenção · vermelho estourou o tempo" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
        lineNumber: 185,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
      lineNumber: 183,
      columnNumber: 13
    }, this),
    queueQuery.isError && /* @__PURE__ */ jsxDEV(QueryError, { error: queueQuery.error, what: "a fila de preparo" }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
      lineNumber: 190,
      columnNumber: 36
    }, this),
    tickets.length === 0 && !queueQuery.isLoading && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", placeItems: "center", minHeight: "50vh" }, children: /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", display: "grid", gap: 6 }, children: [
      /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "2.2rem", color: "var(--free)" }, children: "Tudo em dia" }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
        lineNumber: 195,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ink-faint)" }, children: "Nenhum item aguardando preparo." }, void 0, false, {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
        lineNumber: 198,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
      lineNumber: 194,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
      lineNumber: 193,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "rise rise-1",
        style: {
          display: "flex",
          gap: 14,
          overflowX: "auto",
          paddingBottom: 14,
          alignItems: "flex-start"
        },
        children: tickets.map((ticket) => {
          const worstRatio = Math.max(
            ...ticket.items.map((item) => {
              const elapsed = now - parseLocalDateTime(item.startedAt);
              return elapsed / (item.limitMinutes * 6e4);
            })
          );
          const headColor = timeColor(worstRatio);
          const comandaOrCustomerLabel = ticket.comandaCode !== null ? `Comanda ${ticket.comandaCode}` : ticket.customerName?.trim() || `Pedido #${ticket.customerOrderId}`;
          const ticketTitle = ticket.tableNumber !== null ? `Mesa ${ticket.tableNumber}` : comandaOrCustomerLabel;
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "ticket",
              style: { minWidth: 300, maxWidth: 340, flexShrink: 0 },
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "ticket-head",
                    style: { borderTop: `3px solid ${headColor}`, alignItems: "center" },
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 4 }, children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "display", style: { fontSize: "1.35rem" }, children: ticketTitle }, void 0, false, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
                          lineNumber: 239,
                          columnNumber: 37
                        }, this),
                        ticket.orderTypeId !== OrderType.Mesa && /* @__PURE__ */ jsxDEV("span", { className: "chip", style: { "--dot": "var(--reserved)" }, children: ticket.orderTypeId === OrderType.Delivery ? "DELIVERY" : "RETIRADA" }, void 0, false, {
                          fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
                          lineNumber: 247,
                          columnNumber: 19
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
                        lineNumber: 238,
                        columnNumber: 33
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "mono-num", style: { color: "var(--ink-faint)", fontSize: "0.8rem" }, children: [
                        "#",
                        ticket.customerOrderId,
                        " ·",
                        " ",
                        new Date(parseLocalDateTime(ticket.openedAt)).toLocaleTimeString("pt-BR", {
                          hour: "2-digit",
                          minute: "2-digit"
                        })
                      ] }, void 0, true, {
                        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
                        lineNumber: 252,
                        columnNumber: 33
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
                    lineNumber: 234,
                    columnNumber: 29
                  },
                  this
                ),
                ticket.items.map(
                  (item) => /* @__PURE__ */ jsxDEV(
                    ItemRow,
                    {
                      item,
                      now,
                      isPending: advanceMutation.isPending,
                      onAdvance: (statusId) => advanceMutation.mutate({
                        orderId: ticket.customerOrderId,
                        itemId: item.orderItemId,
                        statusId
                      })
                    },
                    item.orderItemId,
                    false,
                    {
                      fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
                      lineNumber: 261,
                      columnNumber: 15
                    },
                    this
                  )
                )
              ]
            },
            ticket.customerOrderId,
            true,
            {
              fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
              lineNumber: 229,
              columnNumber: 13
            },
            this
          );
        })
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
        lineNumber: 204,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx",
    lineNumber: 182,
    columnNumber: 5
  }, this);
}
_s(PreparationPage, "GjvsspexeebnxaBAMjWzSRBd+lQ=", false, function() {
  return [useQueryClient, useAuthStore, useQuery, useMutation];
});
_c2 = PreparationPage;
var _c, _c2;
$RefreshReg$(_c, "ItemRow");
$RefreshReg$(_c2, "PreparationPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/features/preparation/PreparationPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEV3QixTQXlDQSxVQXpDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUExRXZCLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNyQyxTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQsU0FBU0MsbUJBQW1CQywyQkFBMkI7QUFDdkQsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGlCQUFpQkMsc0JBQXNCQyxpQkFBaUI7QUFFakUsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLFVBQVVDLE9BQXVCO0FBQ3RDLE1BQUlBLFNBQVMsRUFBRyxRQUFPO0FBQ3ZCLE1BQUlBLFNBQVMsSUFBSyxRQUFPO0FBQ3pCLFNBQU87QUFDWDtBQUVBLE1BQU1DLGFBQTREO0FBQUEsRUFDOUQsQ0FBQ04sZ0JBQWdCTyxPQUFPLEdBQUcsRUFBRUMsSUFBSVIsZ0JBQWdCUyxXQUFXQyxPQUFPLFVBQVU7QUFBQSxFQUM3RSxDQUFDVixnQkFBZ0JXLGNBQWMsR0FBRyxFQUFFSCxJQUFJUixnQkFBZ0JTLFdBQVdDLE9BQU8sVUFBVTtBQUFBLEVBQ3BGLENBQUNWLGdCQUFnQlMsU0FBUyxHQUFHLEVBQUVELElBQUlSLGdCQUFnQlksUUFBUUYsT0FBTyxTQUFTO0FBQUEsRUFDM0UsQ0FBQ1YsZ0JBQWdCWSxNQUFNLEdBQUcsRUFBRUosSUFBSVIsZ0JBQWdCYSxVQUFVSCxPQUFPLFdBQVc7QUFDaEY7QUFFQSxTQUFTSSxjQUFjQyxJQUFvQjtBQUN2QyxRQUFNQyxlQUFlQyxLQUFLQyxJQUFJLEdBQUdELEtBQUtFLE1BQU1KLEtBQUssR0FBSSxDQUFDO0FBQ3RELFFBQU1LLFVBQVVILEtBQUtFLE1BQU1ILGVBQWUsRUFBRTtBQUM1QyxRQUFNSyxVQUFVTCxlQUFlO0FBQy9CLFNBQU8sR0FBR00sT0FBT0YsT0FBTyxFQUFFRyxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUlELE9BQU9ELE9BQU8sRUFBRUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUNsRjtBQUVBLFNBQVNDLG1CQUFtQkMsWUFBNEI7QUFDcEQsTUFBSSxDQUFDQSxXQUFZLFFBQU9DLEtBQUtDLElBQUk7QUFFakMsUUFBTUMsVUFBVUgsV0FBV0ksTUFBTSxzREFBc0Q7QUFFdkYsTUFBSSxDQUFDRCxTQUFTO0FBQ1YsV0FBTyxJQUFJRixLQUFLRCxVQUFVLEVBQUVLLFFBQVE7QUFBQSxFQUN4QztBQUVBLFFBQU0sR0FBR0MsTUFBTUMsT0FBT0MsS0FBS0MsTUFBTUMsUUFBUUMsTUFBTSxJQUFJUixRQUFRUyxJQUFJQyxNQUFNO0FBRXJFLFNBQU8sSUFBSVosS0FBS0ssTUFBTUMsUUFBUSxHQUFHQyxLQUFLQyxNQUFNQyxRQUFRQyxNQUFNLEVBQUVOLFFBQVE7QUFDeEU7QUFFQSxTQUFTUyxRQUFRO0FBQUEsRUFDYkM7QUFBQUEsRUFDQWI7QUFBQUEsRUFDQWM7QUFBQUEsRUFDQUM7QUFNSixHQUFHO0FBQ0MsUUFBTUMsY0FBY25CLG1CQUFtQmdCLEtBQUtJLFNBQVM7QUFDckQsUUFBTUMsWUFBWWxCLE1BQU1nQjtBQUN4QixRQUFNRyxVQUFVTixLQUFLTyxlQUFlO0FBQ3BDLFFBQU0xQyxRQUFReUMsV0FBVyxJQUFJLElBQUlELFlBQVlDO0FBQzdDLFFBQU1FLFFBQVE1QyxVQUFVQyxLQUFLO0FBQzdCLFFBQU00QyxPQUFPM0MsV0FBV2tDLEtBQUtVLGlCQUFpQjtBQUM5QyxRQUFNQyxVQUFVOUMsU0FBUztBQUV6QixTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxXQUFXOEMsVUFBVSxnQkFBZ0JDO0FBQUFBLE1BQ3JDLE9BQU87QUFBQSxRQUNIQyxTQUFTO0FBQUEsUUFDVEMsS0FBSztBQUFBLFFBQ0xDLFNBQVM7QUFBQSxRQUNUQyxjQUFjO0FBQUEsTUFDbEI7QUFBQSxNQUVBO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVILFNBQVMsUUFBUUksZ0JBQWdCLGlCQUFpQkgsS0FBSyxHQUFHSSxZQUFZLFdBQVcsR0FDM0Y7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUMsWUFBWSxJQUFJLEdBQzFCbkI7QUFBQUEsaUJBQUtvQjtBQUFBQSxZQUFTO0FBQUEsWUFBSXBCLEtBQUtxQjtBQUFBQSxZQUN2QnJCLEtBQUtzQixhQUNGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csT0FBTztBQUFBLGtCQUNIQyxZQUFZO0FBQUEsa0JBQ1pDLFlBQVk7QUFBQSxrQkFDWkMsVUFBVTtBQUFBLGtCQUNWQyxlQUFlO0FBQUEsa0JBQ2ZsQixPQUFPO0FBQUEsa0JBQ1BtQixRQUFRO0FBQUEsa0JBQ1JDLGNBQWM7QUFBQSxrQkFDZGIsU0FBUztBQUFBLGtCQUNUYyxlQUFlO0FBQUEsZ0JBQ25CO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY0E7QUFBQSxlQWpCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQixPQUFPLEVBQUVKLFVBQVUsV0FBV2pCLE1BQU0sR0FDbEVsQyx3QkFBYytCLFNBQVMsS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVDTCxLQUFLOEIsU0FDRix1QkFBQyxVQUFLLE9BQU8sRUFBRUwsVUFBVSxXQUFXakIsT0FBTyxlQUFlLEdBQUc7QUFBQTtBQUFBLFVBQUVSLEtBQUs4QjtBQUFBQSxVQUFNO0FBQUEsYUFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFFBRy9FLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxZQUFZLG1CQUFtQkgsY0FBYyxLQUFLSSxRQUFRLEdBQUdDLFVBQVUsU0FBUyxHQUMxRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csT0FBTztBQUFBLGNBQ0hDLE9BQU8sR0FBR3pELEtBQUswRCxJQUFJLEtBQUt0RSxRQUFRLEdBQUcsQ0FBQztBQUFBLGNBQ3BDbUUsUUFBUTtBQUFBLGNBQ1JELFlBQVl2QjtBQUFBQSxjQUNaNEIsWUFBWTtBQUFBLFlBQ2hCO0FBQUE7QUFBQSxVQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1NLEtBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXZCLFNBQVMsUUFBUUksZ0JBQWdCLGlCQUFpQkMsWUFBWSxVQUFVSixLQUFLLEVBQUUsR0FDekY7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRVcsVUFBVSxXQUFXakIsT0FBTyxtQkFBbUIsR0FDekQvQztBQUFBQSxpQ0FBcUJ1QyxLQUFLVSxpQkFBaUI7QUFBQSxZQUFFO0FBQUEsWUFBV1YsS0FBS087QUFBQUEsWUFBYTtBQUFBLFlBQzFFUCxLQUFLcUMsZUFDRixtQ0FDSztBQUFBO0FBQUEsY0FDRCx1QkFBQyxVQUFLLE9BQU8sRUFBRTdCLE9BQU8sa0JBQWtCVyxZQUFZLElBQUksR0FBRztBQUFBO0FBQUEsZ0JBQUtuQixLQUFLcUM7QUFBQUEsbUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlGO0FBQUEsaUJBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUNDNUIsUUFDRztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFNkIsV0FBVyxJQUFJdkIsU0FBUyxVQUFVVSxVQUFVLFNBQVM7QUFBQSxjQUM5RCxVQUFVdkI7QUFBQUEsY0FDVixTQUFTLE1BQU1ELFVBQVVRLEtBQUt6QyxFQUFFO0FBQUEsY0FFL0J5QyxlQUFLdkM7QUFBQUE7QUFBQUEsWUFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBbkJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQTtBQUFBO0FBQUEsSUF2RUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBd0VBO0FBRVI7QUFBQ3FFLEtBOUZReEM7QUFnR0YsZ0JBQVN5QyxrQkFBa0I7QUFBQUMsS0FBQTtBQUM5QixRQUFNQyxjQUFjdEYsZUFBZTtBQUNuQyxRQUFNLEVBQUV1RixTQUFTLElBQUlwRixhQUFhO0FBQ2xDLFFBQU0sQ0FBQzRCLEtBQUt5RCxNQUFNLElBQUkzRixTQUFTLE1BQU1pQyxLQUFLQyxJQUFJLENBQUM7QUFFL0NuQyxZQUFVLE1BQU07QUFDWixVQUFNNkYsUUFBUUMsWUFBWSxNQUFNRixPQUFPMUQsS0FBS0MsSUFBSSxDQUFDLEdBQUcsR0FBSTtBQUN4RCxXQUFPLE1BQU00RCxjQUFjRixLQUFLO0FBQUEsRUFDcEMsR0FBRyxFQUFFO0FBRUwsUUFBTUcsYUFBYTdGLFNBQVM7QUFBQSxJQUN4QjhGLFVBQVUsQ0FBQyxlQUFlTixRQUFRO0FBQUEsSUFDbENPLFNBQVNBLE1BQU01RixvQkFBb0JxRixRQUFRO0FBQUEsSUFDM0NRLGlCQUFpQjtBQUFBLEVBQ3JCLENBQUM7QUFFRCxRQUFNQyxrQkFBa0JsRyxZQUFZO0FBQUEsSUFDaENtRyxZQUFZQSxDQUFDLEVBQUVDLFNBQVNDLFFBQVFDLFNBQWdFLE1BQzVGbkcsa0JBQWtCaUcsU0FBU0MsUUFBUUMsUUFBUTtBQUFBLElBQy9DQyxXQUFXQSxNQUFNLEtBQUtmLFlBQVlnQixrQkFBa0IsRUFBRVQsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDO0FBQUEsRUFDckYsQ0FBQztBQUVELFFBQU1VLFVBQVVYLFdBQVdZLFFBQVE7QUFFbkMsU0FDSSx1QkFBQyxVQUFLLE9BQU8sRUFBRTdDLFNBQVMsR0FBRyxHQUN2QjtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU8sRUFBRUYsU0FBUyxRQUFRSyxZQUFZLFlBQVlKLEtBQUssSUFBSStDLGNBQWMsRUFBRSxHQUM3RjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxXQUFVLE9BQU8sRUFBRXBDLFVBQVUsU0FBUyxHQUFHLHVCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDOUQsdUJBQUMsVUFBSyxPQUFPLEVBQUVqQixPQUFPLG9CQUFvQmlCLFVBQVUsU0FBUyxHQUFHLDRFQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUN1QixXQUFXYyxXQUFXLHVCQUFDLGNBQVcsT0FBT2QsV0FBV2UsT0FBTyxNQUFLLHVCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZEO0FBQUEsSUFFbkZKLFFBQVFLLFdBQVcsS0FBSyxDQUFDaEIsV0FBV2lCLGFBQ2pDLHVCQUFDLFNBQUksT0FBTyxFQUFFcEQsU0FBUyxRQUFRcUQsWUFBWSxVQUFVNUIsV0FBVyxPQUFPLEdBQ25FLGlDQUFDLFNBQUksT0FBTyxFQUFFNkIsV0FBVyxVQUFVdEQsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDdkQ7QUFBQSw2QkFBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVXLFVBQVUsVUFBVWpCLE9BQU8sY0FBYyxHQUFHLDJCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFQSxPQUFPLG1CQUFtQixHQUFHLCtDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsU0FKL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFJSjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csV0FBVTtBQUFBLFFBQ1YsT0FBTztBQUFBLFVBQ0hLLFNBQVM7QUFBQSxVQUNUQyxLQUFLO0FBQUEsVUFDTHNELFdBQVc7QUFBQSxVQUNYQyxlQUFlO0FBQUEsVUFDZm5ELFlBQVk7QUFBQSxRQUNoQjtBQUFBLFFBRUN5QyxrQkFBUTlELElBQUksQ0FBQ3lFLFdBQVc7QUFDckIsZ0JBQU1DLGFBQWE5RixLQUFLQztBQUFBQSxZQUNwQixHQUFHNEYsT0FBT0UsTUFBTTNFLElBQUksQ0FBQ0csU0FBUztBQUMxQixvQkFBTXlFLFVBQVV0RixNQUFNSCxtQkFBbUJnQixLQUFLSSxTQUFTO0FBQ3ZELHFCQUFPcUUsV0FBV3pFLEtBQUtPLGVBQWU7QUFBQSxZQUMxQyxDQUFDO0FBQUEsVUFDTDtBQUNBLGdCQUFNbUUsWUFBWTlHLFVBQVUyRyxVQUFVO0FBQ3RDLGdCQUFNSSx5QkFBeUJMLE9BQU9NLGdCQUFnQixPQUNoRCxXQUFXTixPQUFPTSxXQUFXLEtBQzdCTixPQUFPTyxjQUFjQyxLQUFLLEtBQUssV0FBV1IsT0FBT1MsZUFBZTtBQUN0RSxnQkFBTUMsY0FBY1YsT0FBT1csZ0JBQWdCLE9BQ3JDLFFBQVFYLE9BQU9XLFdBQVcsS0FDMUJOO0FBQ04saUJBQ0k7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVHLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRU8sVUFBVSxLQUFLQyxVQUFVLEtBQUtDLFlBQVksRUFBRTtBQUFBLGNBRXJEO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csV0FBVTtBQUFBLG9CQUNWLE9BQU8sRUFBRUMsV0FBVyxhQUFhWCxTQUFTLElBQUl4RCxZQUFZLFNBQVM7QUFBQSxvQkFFbkU7QUFBQSw2Q0FBQyxTQUFJLE9BQU8sRUFBRUwsU0FBUyxRQUFRQyxLQUFLLEVBQUUsR0FDbEM7QUFBQSwrQ0FBQyxVQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVXLFVBQVUsVUFBVSxHQUNsRHVELHlCQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFLQ1YsT0FBT2dCLGdCQUFnQjVILFVBQVU2SCxRQUM5Qix1QkFBQyxVQUFLLFdBQVUsUUFBTyxPQUFPLEVBQUUsU0FBUyxrQkFBa0IsR0FDdERqQixpQkFBT2dCLGdCQUFnQjVILFVBQVU4SCxXQUFXLGFBQWEsY0FEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQVhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBYUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFLLFdBQVUsWUFBVyxPQUFPLEVBQUVoRixPQUFPLG9CQUFvQmlCLFVBQVUsU0FBUyxHQUFHO0FBQUE7QUFBQSx3QkFDL0U2QyxPQUFPUztBQUFBQSx3QkFBZ0I7QUFBQSx3QkFBRztBQUFBLHdCQUMzQixJQUFJN0YsS0FBS0YsbUJBQW1Cc0YsT0FBT21CLFFBQVEsQ0FBQyxFQUFFQyxtQkFBbUIsU0FBUztBQUFBLDBCQUN2RWhHLE1BQU07QUFBQSwwQkFDTkMsUUFBUTtBQUFBLHdCQUNaLENBQUM7QUFBQSwyQkFMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU1BO0FBQUE7QUFBQTtBQUFBLGtCQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBeUJBO0FBQUEsZ0JBQ0MyRSxPQUFPRSxNQUFNM0U7QUFBQUEsa0JBQUksQ0FBQ0csU0FDZjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFRztBQUFBLHNCQUNBO0FBQUEsc0JBQ0EsV0FBV29ELGdCQUFnQmxEO0FBQUFBLHNCQUMzQixXQUFXLENBQUNzRCxhQUNSSixnQkFBZ0J1QyxPQUFPO0FBQUEsd0JBQ25CckMsU0FBU2dCLE9BQU9TO0FBQUFBLHdCQUNoQnhCLFFBQVF2RCxLQUFLNEY7QUFBQUEsd0JBQ2JwQztBQUFBQSxzQkFDSixDQUFDO0FBQUE7QUFBQSxvQkFUQXhELEtBQUs0RjtBQUFBQSxvQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVdLO0FBQUEsZ0JBRVI7QUFBQTtBQUFBO0FBQUEsWUE1Q0l0QixPQUFPUztBQUFBQSxZQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBOENBO0FBQUEsUUFFUixDQUFDO0FBQUE7QUFBQSxNQXpFTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUEwRUE7QUFBQSxPQWhHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUdBO0FBRVI7QUFBQ3RDLEdBNUhlRCxpQkFBZTtBQUFBLFVBQ1BwRixnQkFDQ0csY0FRRkosVUFNS0QsV0FBVztBQUFBO0FBQUEsTUFoQnZCc0Y7QUFBZSxJQUFBRCxJQUFBc0Q7QUFBQSxhQUFBdEQsSUFBQTtBQUFBLGFBQUFzRCxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJhZHZhbmNlSXRlbVN0YXR1cyIsImdldFByZXBhcmF0aW9uUXVldWUiLCJ1c2VBdXRoU3RvcmUiLCJPcmRlckl0ZW1TdGF0dXMiLCJvcmRlckl0ZW1TdGF0dXNMYWJlbCIsIk9yZGVyVHlwZSIsIlF1ZXJ5RXJyb3IiLCJ0aW1lQ29sb3IiLCJyYXRpbyIsIm5leHRTdGF0dXMiLCJMYW5jYWRvIiwiaWQiLCJFbVByZXBhcm8iLCJsYWJlbCIsIkVudmlhZG9Db3ppbmhhIiwiUHJvbnRvIiwiRW50cmVndWUiLCJmb3JtYXRFbGFwc2VkIiwibXMiLCJ0b3RhbFNlY29uZHMiLCJNYXRoIiwibWF4IiwiZmxvb3IiLCJtaW51dGVzIiwic2Vjb25kcyIsIlN0cmluZyIsInBhZFN0YXJ0IiwicGFyc2VMb2NhbERhdGVUaW1lIiwiZGF0ZVN0cmluZyIsIkRhdGUiLCJub3ciLCJtYXRjaGVzIiwibWF0Y2giLCJnZXRUaW1lIiwieWVhciIsIm1vbnRoIiwiZGF5IiwiaG91ciIsIm1pbnV0ZSIsInNlY29uZCIsIm1hcCIsIk51bWJlciIsIkl0ZW1Sb3ciLCJpdGVtIiwib25BZHZhbmNlIiwiaXNQZW5kaW5nIiwic3RhcnRlZFRpbWUiLCJzdGFydGVkQXQiLCJlbGFwc2VkTXMiLCJsaW1pdE1zIiwibGltaXRNaW51dGVzIiwiY29sb3IiLCJuZXh0Iiwib3JkZXJJdGVtU3RhdHVzSWQiLCJvdmVyZHVlIiwidW5kZWZpbmVkIiwiZGlzcGxheSIsImdhcCIsInBhZGRpbmciLCJib3JkZXJCb3R0b20iLCJqdXN0aWZ5Q29udGVudCIsImFsaWduSXRlbXMiLCJmb250V2VpZ2h0IiwicXVhbnRpdHkiLCJwcm9kdWN0TmFtZSIsImlzQmFySXRlbSIsIm1hcmdpbkxlZnQiLCJmb250RmFtaWx5IiwiZm9udFNpemUiLCJsZXR0ZXJTcGFjaW5nIiwiYm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwidmVydGljYWxBbGlnbiIsIm5vdGVzIiwiYmFja2dyb3VuZCIsImhlaWdodCIsIm92ZXJmbG93Iiwid2lkdGgiLCJtaW4iLCJ0cmFuc2l0aW9uIiwicmVxdWVzdGVkQnkiLCJtaW5IZWlnaHQiLCJfYyIsIlByZXBhcmF0aW9uUGFnZSIsIl9zIiwicXVlcnlDbGllbnQiLCJicmFuY2hJZCIsInNldE5vdyIsInRpbWVyIiwic2V0SW50ZXJ2YWwiLCJjbGVhckludGVydmFsIiwicXVldWVRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInJlZmV0Y2hJbnRlcnZhbCIsImFkdmFuY2VNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJvcmRlcklkIiwiaXRlbUlkIiwic3RhdHVzSWQiLCJvblN1Y2Nlc3MiLCJpbnZhbGlkYXRlUXVlcmllcyIsInRpY2tldHMiLCJkYXRhIiwibWFyZ2luQm90dG9tIiwiaXNFcnJvciIsImVycm9yIiwibGVuZ3RoIiwiaXNMb2FkaW5nIiwicGxhY2VJdGVtcyIsInRleHRBbGlnbiIsIm92ZXJmbG93WCIsInBhZGRpbmdCb3R0b20iLCJ0aWNrZXQiLCJ3b3JzdFJhdGlvIiwiaXRlbXMiLCJlbGFwc2VkIiwiaGVhZENvbG9yIiwiY29tYW5kYU9yQ3VzdG9tZXJMYWJlbCIsImNvbWFuZGFDb2RlIiwiY3VzdG9tZXJOYW1lIiwidHJpbSIsImN1c3RvbWVyT3JkZXJJZCIsInRpY2tldFRpdGxlIiwidGFibGVOdW1iZXIiLCJtaW5XaWR0aCIsIm1heFdpZHRoIiwiZmxleFNocmluayIsImJvcmRlclRvcCIsIm9yZGVyVHlwZUlkIiwiTWVzYSIsIkRlbGl2ZXJ5Iiwib3BlbmVkQXQiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJtdXRhdGUiLCJvcmRlckl0ZW1JZCIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcmVwYXJhdGlvblBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIu+7v2ltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgYWR2YW5jZUl0ZW1TdGF0dXMsIGdldFByZXBhcmF0aW9uUXVldWUgfSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSBcIi4uLy4uL3N0b3Jlcy9hdXRoU3RvcmVcIjtcclxuaW1wb3J0IHsgT3JkZXJJdGVtU3RhdHVzLCBvcmRlckl0ZW1TdGF0dXNMYWJlbCwgT3JkZXJUeXBlIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgdHlwZSB7IFByZXBhcmF0aW9uSXRlbVJlc3BvbnNlIH0gZnJvbSBcIi4uLy4uL2xpYi90eXBlc1wiO1xyXG5pbXBvcnQgeyBRdWVyeUVycm9yIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUXVlcnlFcnJvclwiO1xyXG5mdW5jdGlvbiB0aW1lQ29sb3IocmF0aW86IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICBpZiAocmF0aW8gPj0gMSkgcmV0dXJuIFwidmFyKC0tZGFuZ2VyKVwiO1xyXG4gICAgaWYgKHJhdGlvID49IDAuNykgcmV0dXJuIFwidmFyKC0tYnVzeSlcIjtcclxuICAgIHJldHVybiBcInZhcigtLWZyZWUpXCI7XHJcbn1cclxuXHJcbmNvbnN0IG5leHRTdGF0dXM6IFJlY29yZDxudW1iZXIsIHsgaWQ6IG51bWJlcjsgbGFiZWw6IHN0cmluZyB9PiA9IHtcclxuICAgIFtPcmRlckl0ZW1TdGF0dXMuTGFuY2Fkb106IHsgaWQ6IE9yZGVySXRlbVN0YXR1cy5FbVByZXBhcm8sIGxhYmVsOiBcIkluaWNpYXJcIiB9LFxyXG4gICAgW09yZGVySXRlbVN0YXR1cy5FbnZpYWRvQ296aW5oYV06IHsgaWQ6IE9yZGVySXRlbVN0YXR1cy5FbVByZXBhcm8sIGxhYmVsOiBcIkluaWNpYXJcIiB9LFxyXG4gICAgW09yZGVySXRlbVN0YXR1cy5FbVByZXBhcm9dOiB7IGlkOiBPcmRlckl0ZW1TdGF0dXMuUHJvbnRvLCBsYWJlbDogXCJQcm9udG9cIiB9LFxyXG4gICAgW09yZGVySXRlbVN0YXR1cy5Qcm9udG9dOiB7IGlkOiBPcmRlckl0ZW1TdGF0dXMuRW50cmVndWUsIGxhYmVsOiBcIkVudHJlZ3VlXCIgfSxcclxufTtcclxuXHJcbmZ1bmN0aW9uIGZvcm1hdEVsYXBzZWQobXM6IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICBjb25zdCB0b3RhbFNlY29uZHMgPSBNYXRoLm1heCgwLCBNYXRoLmZsb29yKG1zIC8gMTAwMCkpO1xyXG4gICAgY29uc3QgbWludXRlcyA9IE1hdGguZmxvb3IodG90YWxTZWNvbmRzIC8gNjApO1xyXG4gICAgY29uc3Qgc2Vjb25kcyA9IHRvdGFsU2Vjb25kcyAlIDYwO1xyXG4gICAgcmV0dXJuIGAke1N0cmluZyhtaW51dGVzKS5wYWRTdGFydCgyLCBcIjBcIil9OiR7U3RyaW5nKHNlY29uZHMpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYXJzZUxvY2FsRGF0ZVRpbWUoZGF0ZVN0cmluZzogc3RyaW5nKTogbnVtYmVyIHtcclxuICAgIGlmICghZGF0ZVN0cmluZykgcmV0dXJuIERhdGUubm93KCk7XHJcblxyXG4gICAgY29uc3QgbWF0Y2hlcyA9IGRhdGVTdHJpbmcubWF0Y2goL14oXFxkezR9KS0oXFxkezJ9KS0oXFxkezJ9KVtUXFxzXShcXGR7Mn0pOihcXGR7Mn0pOihcXGR7Mn0pLyk7XHJcblxyXG4gICAgaWYgKCFtYXRjaGVzKSB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBEYXRlKGRhdGVTdHJpbmcpLmdldFRpbWUoKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBbLCB5ZWFyLCBtb250aCwgZGF5LCBob3VyLCBtaW51dGUsIHNlY29uZF0gPSBtYXRjaGVzLm1hcChOdW1iZXIpO1xyXG5cclxuICAgIHJldHVybiBuZXcgRGF0ZSh5ZWFyLCBtb250aCAtIDEsIGRheSwgaG91ciwgbWludXRlLCBzZWNvbmQpLmdldFRpbWUoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gSXRlbVJvdyh7XHJcbiAgICBpdGVtLFxyXG4gICAgbm93LFxyXG4gICAgb25BZHZhbmNlLFxyXG4gICAgaXNQZW5kaW5nLFxyXG59OiB7XHJcbiAgICBpdGVtOiBQcmVwYXJhdGlvbkl0ZW1SZXNwb25zZTtcclxuICAgIG5vdzogbnVtYmVyO1xyXG4gICAgb25BZHZhbmNlOiAoc3RhdHVzSWQ6IG51bWJlcikgPT4gdm9pZDtcclxuICAgIGlzUGVuZGluZzogYm9vbGVhbjtcclxufSkge1xyXG4gICAgY29uc3Qgc3RhcnRlZFRpbWUgPSBwYXJzZUxvY2FsRGF0ZVRpbWUoaXRlbS5zdGFydGVkQXQpO1xyXG4gICAgY29uc3QgZWxhcHNlZE1zID0gbm93IC0gc3RhcnRlZFRpbWU7XHJcbiAgICBjb25zdCBsaW1pdE1zID0gaXRlbS5saW1pdE1pbnV0ZXMgKiA2MF8wMDA7XHJcbiAgICBjb25zdCByYXRpbyA9IGxpbWl0TXMgPD0gMCA/IDEgOiBlbGFwc2VkTXMgLyBsaW1pdE1zO1xyXG4gICAgY29uc3QgY29sb3IgPSB0aW1lQ29sb3IocmF0aW8pO1xyXG4gICAgY29uc3QgbmV4dCA9IG5leHRTdGF0dXNbaXRlbS5vcmRlckl0ZW1TdGF0dXNJZF07XHJcbiAgICBjb25zdCBvdmVyZHVlID0gcmF0aW8gPj0gMTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtvdmVyZHVlID8gXCJrZHMtb3ZlcmR1ZVwiIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogXCJncmlkXCIsXHJcbiAgICAgICAgICAgICAgICBnYXA6IDYsXHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjEwcHggMTJweFwiLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCB2YXIoLS1saW5lLXNvZnQpXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGdhcDogOCwgYWxpZ25JdGVtczogXCJiYXNlbGluZVwiIH19PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNjAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnF1YW50aXR5fSDDlyB7aXRlbS5wcm9kdWN0TmFtZX1cclxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5pc0Jhckl0ZW0gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5MZWZ0OiA4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1jb25kKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjAuN3JlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4xZW1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCJ2YXIoLS1yZXNlcnZlZClcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHZhcigtLXJlc2VydmVkKVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogNCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjFweCA2cHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2ZXJ0aWNhbEFsaWduOiBcIm1pZGRsZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQkFSXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9uby1udW0gZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjEuMTVyZW1cIiwgY29sb3IgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEVsYXBzZWQoZWxhcHNlZE1zKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7aXRlbS5ub3RlcyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjgycmVtXCIsIGNvbG9yOiBcInZhcigtLWFtYmVyKVwiIH19PuKAnHtpdGVtLm5vdGVzfeKAnTwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogXCJ2YXIoLS1iZy1wcmVzcylcIiwgYm9yZGVyUmFkaXVzOiA5OTksIGhlaWdodDogOCwgb3ZlcmZsb3c6IFwiaGlkZGVuXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IGAke01hdGgubWluKDEwMCwgcmF0aW8gKiAxMDApfSVgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IFwiMTAwJVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBjb2xvcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogXCJ3aWR0aCAxcyBsaW5lYXIsIGJhY2tncm91bmQgMzAwbXMgZWFzZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiA4IH19PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMC43OHJlbVwiLCBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAge29yZGVySXRlbVN0YXR1c0xhYmVsW2l0ZW0ub3JkZXJJdGVtU3RhdHVzSWRdfSDCtyBsaW1pdGUge2l0ZW0ubGltaXRNaW51dGVzfSBtaW5cclxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5yZXF1ZXN0ZWRCeSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XCIgwrcgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZGltKVwiLCBmb250V2VpZ2h0OiA2MDAgfX0+cG9yIHtpdGVtLnJlcXVlc3RlZEJ5fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIHtuZXh0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1pbkhlaWdodDogNDAsIHBhZGRpbmc6IFwiMCAxNnB4XCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQWR2YW5jZShuZXh0LmlkKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtuZXh0LmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUHJlcGFyYXRpb25QYWdlKCkge1xyXG4gICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBicmFuY2hJZCB9ID0gdXNlQXV0aFN0b3JlKCk7XHJcbiAgICBjb25zdCBbbm93LCBzZXROb3ddID0gdXNlU3RhdGUoKCkgPT4gRGF0ZS5ub3coKSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHNldE5vdyhEYXRlLm5vdygpKSwgMTAwMCk7XHJcbiAgICAgICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwodGltZXIpO1xyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIGNvbnN0IHF1ZXVlUXVlcnkgPSB1c2VRdWVyeSh7XHJcbiAgICAgICAgcXVlcnlLZXk6IFtcInByZXBhcmF0aW9uXCIsIGJyYW5jaElkXSxcclxuICAgICAgICBxdWVyeUZuOiAoKSA9PiBnZXRQcmVwYXJhdGlvblF1ZXVlKGJyYW5jaElkKSxcclxuICAgICAgICByZWZldGNoSW50ZXJ2YWw6IDEwXzAwMCxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGFkdmFuY2VNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgICAgICBtdXRhdGlvbkZuOiAoeyBvcmRlcklkLCBpdGVtSWQsIHN0YXR1c0lkIH06IHsgb3JkZXJJZDogbnVtYmVyOyBpdGVtSWQ6IG51bWJlcjsgc3RhdHVzSWQ6IG51bWJlciB9KSA9PlxyXG4gICAgICAgICAgICBhZHZhbmNlSXRlbVN0YXR1cyhvcmRlcklkLCBpdGVtSWQsIHN0YXR1c0lkKSxcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogW1wicHJlcGFyYXRpb25cIl0gfSksXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCB0aWNrZXRzID0gcXVldWVRdWVyeS5kYXRhID8/IFtdO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPG1haW4gc3R5bGU9e3sgcGFkZGluZzogMjIgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlzZVwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImJhc2VsaW5lXCIsIGdhcDogMTQsIG1hcmdpbkJvdHRvbTogNiB9fT5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJkaXNwbGF5XCIgc3R5bGU9e3sgZm9udFNpemU6IFwiMS43cmVtXCIgfX0+UHJlcGFybzwvaDI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIsIGZvbnRTaXplOiBcIjAuOXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHZlcmRlIG5vIHByYXpvIMK3IGFtYXJlbG8gYXRlbsOnw6NvIMK3IHZlcm1lbGhvIGVzdG91cm91IG8gdGVtcG9cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7cXVldWVRdWVyeS5pc0Vycm9yICYmIDxRdWVyeUVycm9yIGVycm9yPXtxdWV1ZVF1ZXJ5LmVycm9yfSB3aGF0PVwiYSBmaWxhIGRlIHByZXBhcm9cIiAvPn1cclxuXHJcbiAgICAgICAgICAgIHt0aWNrZXRzLmxlbmd0aCA9PT0gMCAmJiAhcXVldWVRdWVyeS5pc0xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgcGxhY2VJdGVtczogXCJjZW50ZXJcIiwgbWluSGVpZ2h0OiBcIjUwdmhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgZGlzcGxheTogXCJncmlkXCIsIGdhcDogNiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGlzcGxheVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjIuMnJlbVwiLCBjb2xvcjogXCJ2YXIoLS1mcmVlKVwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVHVkbyBlbSBkaWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1pbmstZmFpbnQpXCIgfX0+TmVuaHVtIGl0ZW0gYWd1YXJkYW5kbyBwcmVwYXJvLjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIFJlZ3VhIGRlIHBlZGlkb3M6IHRyaWxobyBob3Jpem9udGFsLCB0aWNrZXQgbWFpcyBhbnRpZ28gcHJpbWVpcm8gKi99XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJpc2UgcmlzZS0xXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZ2FwOiAxNCxcclxuICAgICAgICAgICAgICAgICAgICBvdmVyZmxvd1g6IFwiYXV0b1wiLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmdCb3R0b206IDE0LFxyXG4gICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiZmxleC1zdGFydFwiLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3RpY2tldHMubWFwKCh0aWNrZXQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCB3b3JzdFJhdGlvID0gTWF0aC5tYXgoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnRpY2tldC5pdGVtcy5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGVsYXBzZWQgPSBub3cgLSBwYXJzZUxvY2FsRGF0ZVRpbWUoaXRlbS5zdGFydGVkQXQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGVsYXBzZWQgLyAoaXRlbS5saW1pdE1pbnV0ZXMgKiA2MF8wMDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGhlYWRDb2xvciA9IHRpbWVDb2xvcih3b3JzdFJhdGlvKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb21hbmRhT3JDdXN0b21lckxhYmVsID0gdGlja2V0LmNvbWFuZGFDb2RlICE9PSBudWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gYENvbWFuZGEgJHt0aWNrZXQuY29tYW5kYUNvZGV9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHRpY2tldC5jdXN0b21lck5hbWU/LnRyaW0oKSB8fCBgUGVkaWRvICMke3RpY2tldC5jdXN0b21lck9yZGVySWR9YDtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCB0aWNrZXRUaXRsZSA9IHRpY2tldC50YWJsZU51bWJlciAhPT0gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGBNZXNhICR7dGlja2V0LnRhYmxlTnVtYmVyfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBjb21hbmRhT3JDdXN0b21lckxhYmVsO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dGlja2V0LmN1c3RvbWVyT3JkZXJJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRpY2tldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5XaWR0aDogMzAwLCBtYXhXaWR0aDogMzQwLCBmbGV4U2hyaW5rOiAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0aWNrZXQtaGVhZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYm9yZGVyVG9wOiBgM3B4IHNvbGlkICR7aGVhZENvbG9yfWAsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZ3JpZFwiLCBnYXA6IDQgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRpc3BsYXlcIiBzdHlsZT17eyBmb250U2l6ZTogXCIxLjM1cmVtXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGlja2V0VGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBlZGlkbyBzZW0gbWVzYS9jb21hbmRhID0gUmV0aXJhZGEgb3UgRGVsaXZlcnkgKE9wZW5EZWxpdmVyeU9yZGVyRGlhbG9nKSDigJRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbSBlc3NlIHNlbG8gYSBjb3ppbmhhIHZpYSBzw7MgXCJDb21hbmRhID9cIiBlIG7Do28gdGluaGEgY29tbyBzYWJlciBxdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG8gcGVkaWRvIHByZWNpc2Egc2VyIGVtYmFsYWRvIHByYSBlbnRyZWdhL3JldGlyYWRhIGVtIHZleiBkZSBzZXJ2aWRvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1hIG1lc2EuICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGlja2V0Lm9yZGVyVHlwZUlkICE9PSBPcmRlclR5cGUuTWVzYSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGlwXCIgc3R5bGU9e3sgXCItLWRvdFwiOiBcInZhcigtLXJlc2VydmVkKVwiIH0gYXMgUmVhY3QuQ1NTUHJvcGVydGllc30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpY2tldC5vcmRlclR5cGVJZCA9PT0gT3JkZXJUeXBlLkRlbGl2ZXJ5ID8gXCJERUxJVkVSWVwiIDogXCJSRVRJUkFEQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1vbm8tbnVtXCIgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0taW5rLWZhaW50KVwiLCBmb250U2l6ZTogXCIwLjhyZW1cIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgI3t0aWNrZXQuY3VzdG9tZXJPcmRlcklkfSDCt3tcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKHBhcnNlTG9jYWxEYXRlVGltZSh0aWNrZXQub3BlbmVkQXQpKS50b0xvY2FsZVRpbWVTdHJpbmcoXCJwdC1CUlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBob3VyOiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbnV0ZTogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpY2tldC5pdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SXRlbVJvd1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ub3JkZXJJdGVtSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW09e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vdz17bm93fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1BlbmRpbmc9e2FkdmFuY2VNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQWR2YW5jZT17KHN0YXR1c0lkKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWR2YW5jZU11dGF0aW9uLm11dGF0ZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3JkZXJJZDogdGlja2V0LmN1c3RvbWVyT3JkZXJJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtSWQ6IGl0ZW0ub3JkZXJJdGVtSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICk7XHJcbn0iXSwiZmlsZSI6IkM6L1VzZXJzL0FNRC9zb3VyY2UvcmVwb3MvU3luY0Jhci9mcm9udGVuZC9zcmMvZmVhdHVyZXMvcHJlcGFyYXRpb24vUHJlcGFyYXRpb25QYWdlLnRzeCJ9