import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Dialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca0b4140"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Dialog.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { swal, swalClasses } from "/src/lib/swal.ts";
const dialogApi = {
  async confirm(options) {
    const result = await swal.fire({
      title: options.title ?? "Confirmar",
      text: options.message,
      icon: options.danger ? "warning" : "question",
      showCancelButton: true,
      confirmButtonText: options.confirmLabel ?? "Confirmar",
      cancelButtonText: options.cancelLabel ?? "Cancelar",
      customClass: {
        ...swalClasses,
        confirmButton: options.danger ? "btn-danger" : "btn-primary"
      }
    });
    return result.isConfirmed;
  },
  async prompt(options) {
    const result = await swal.fire({
      title: options.title ?? "Informe um valor",
      text: options.message,
      input: "text",
      inputLabel: options.label,
      inputValue: options.defaultValue ?? "",
      inputPlaceholder: options.placeholder,
      inputAttributes: {
        inputmode: options.inputMode ?? "text",
        autocapitalize: "off"
      },
      showCancelButton: true,
      confirmButtonText: options.confirmLabel ?? "Confirmar",
      cancelButtonText: options.cancelLabel ?? "Cancelar"
    });
    if (!result.isConfirmed) return null;
    return result.value ?? "";
  }
};
export function DialogProvider({ children }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
    fileName: "C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Dialog.tsx",
    lineNumber: 93,
    columnNumber: 10
  }, this);
}
_c = DialogProvider;
export function useDialog() {
  return dialogApi;
}
var _c;
$RefreshReg$(_c, "DialogProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AMD/source/repos/SyncBar/frontend/src/ui/Dialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUVTOzs7Ozs7Ozs7Ozs7Ozs7O0FBeEVULFNBQVNBLE1BQU1DLG1CQUFtQjtBQTBCbEMsTUFBTUMsWUFBdUI7QUFBQSxFQUMzQixNQUFNQyxRQUFRQyxTQUFTO0FBQ3JCLFVBQU1DLFNBQVMsTUFBTUwsS0FBS00sS0FBSztBQUFBLE1BQzdCQyxPQUFPSCxRQUFRRyxTQUFTO0FBQUEsTUFDeEJDLE1BQU1KLFFBQVFLO0FBQUFBLE1BQ2RDLE1BQU1OLFFBQVFPLFNBQVMsWUFBWTtBQUFBLE1BQ25DQyxrQkFBa0I7QUFBQSxNQUNsQkMsbUJBQW1CVCxRQUFRVSxnQkFBZ0I7QUFBQSxNQUMzQ0Msa0JBQWtCWCxRQUFRWSxlQUFlO0FBQUEsTUFDekNDLGFBQWE7QUFBQSxRQUNYLEdBQUdoQjtBQUFBQSxRQUNIaUIsZUFBZWQsUUFBUU8sU0FBUyxlQUFlO0FBQUEsTUFDakQ7QUFBQSxJQUNGLENBQUM7QUFDRCxXQUFPTixPQUFPYztBQUFBQSxFQUNoQjtBQUFBLEVBRUEsTUFBTUMsT0FBT2hCLFNBQVM7QUFDcEIsVUFBTUMsU0FBUyxNQUFNTCxLQUFLTSxLQUFLO0FBQUEsTUFDN0JDLE9BQU9ILFFBQVFHLFNBQVM7QUFBQSxNQUN4QkMsTUFBTUosUUFBUUs7QUFBQUEsTUFDZFksT0FBTztBQUFBLE1BQ1BDLFlBQVlsQixRQUFRbUI7QUFBQUEsTUFDcEJDLFlBQVlwQixRQUFRcUIsZ0JBQWdCO0FBQUEsTUFDcENDLGtCQUFrQnRCLFFBQVF1QjtBQUFBQSxNQUMxQkMsaUJBQWlCO0FBQUEsUUFDZkMsV0FBV3pCLFFBQVEwQixhQUFhO0FBQUEsUUFDaENDLGdCQUFnQjtBQUFBLE1BQ2xCO0FBQUEsTUFDQW5CLGtCQUFrQjtBQUFBLE1BQ2xCQyxtQkFBbUJULFFBQVFVLGdCQUFnQjtBQUFBLE1BQzNDQyxrQkFBa0JYLFFBQVFZLGVBQWU7QUFBQSxJQUMzQyxDQUFDO0FBRUQsUUFBSSxDQUFDWCxPQUFPYyxZQUFhLFFBQU87QUFDaEMsV0FBUWQsT0FBTzJCLFNBQWdDO0FBQUEsRUFDakQ7QUFDRjtBQVFPLGdCQUFTQyxlQUFlLEVBQUVDLFNBQWtDLEdBQUc7QUFDcEUsU0FBTyxtQ0FBR0EsWUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVk7QUFDckI7QUFBQ0MsS0FGZUY7QUFJVCxnQkFBU0csWUFBdUI7QUFDckMsU0FBT2xDO0FBQ1Q7QUFBQyxJQUFBaUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsic3dhbCIsInN3YWxDbGFzc2VzIiwiZGlhbG9nQXBpIiwiY29uZmlybSIsIm9wdGlvbnMiLCJyZXN1bHQiLCJmaXJlIiwidGl0bGUiLCJ0ZXh0IiwibWVzc2FnZSIsImljb24iLCJkYW5nZXIiLCJzaG93Q2FuY2VsQnV0dG9uIiwiY29uZmlybUJ1dHRvblRleHQiLCJjb25maXJtTGFiZWwiLCJjYW5jZWxCdXR0b25UZXh0IiwiY2FuY2VsTGFiZWwiLCJjdXN0b21DbGFzcyIsImNvbmZpcm1CdXR0b24iLCJpc0NvbmZpcm1lZCIsInByb21wdCIsImlucHV0IiwiaW5wdXRMYWJlbCIsImxhYmVsIiwiaW5wdXRWYWx1ZSIsImRlZmF1bHRWYWx1ZSIsImlucHV0UGxhY2Vob2xkZXIiLCJwbGFjZWhvbGRlciIsImlucHV0QXR0cmlidXRlcyIsImlucHV0bW9kZSIsImlucHV0TW9kZSIsImF1dG9jYXBpdGFsaXplIiwidmFsdWUiLCJEaWFsb2dQcm92aWRlciIsImNoaWxkcmVuIiwiX2MiLCJ1c2VEaWFsb2ciXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGlhbG9nLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzd2FsLCBzd2FsQ2xhc3NlcyB9IGZyb20gXCIuLi9saWIvc3dhbFwiO1xyXG5cclxuaW50ZXJmYWNlIENvbmZpcm1PcHRpb25zIHtcclxuICB0aXRsZT86IHN0cmluZztcclxuICBtZXNzYWdlOiBzdHJpbmc7XHJcbiAgY29uZmlybUxhYmVsPzogc3RyaW5nO1xyXG4gIGNhbmNlbExhYmVsPzogc3RyaW5nO1xyXG4gIGRhbmdlcj86IGJvb2xlYW47XHJcbn1cclxuXHJcbmludGVyZmFjZSBQcm9tcHRPcHRpb25zIHtcclxuICB0aXRsZT86IHN0cmluZztcclxuICBtZXNzYWdlPzogc3RyaW5nO1xyXG4gIGxhYmVsOiBzdHJpbmc7XHJcbiAgZGVmYXVsdFZhbHVlPzogc3RyaW5nO1xyXG4gIHBsYWNlaG9sZGVyPzogc3RyaW5nO1xyXG4gIGNvbmZpcm1MYWJlbD86IHN0cmluZztcclxuICBjYW5jZWxMYWJlbD86IHN0cmluZztcclxuICBpbnB1dE1vZGU/OiBcInRleHRcIiB8IFwiZGVjaW1hbFwiIHwgXCJudW1lcmljXCI7XHJcbn1cclxuXHJcbmludGVyZmFjZSBEaWFsb2dBcGkge1xyXG4gIGNvbmZpcm06IChvcHRpb25zOiBDb25maXJtT3B0aW9ucykgPT4gUHJvbWlzZTxib29sZWFuPjtcclxuICBwcm9tcHQ6IChvcHRpb25zOiBQcm9tcHRPcHRpb25zKSA9PiBQcm9taXNlPHN0cmluZyB8IG51bGw+O1xyXG59XHJcblxyXG5jb25zdCBkaWFsb2dBcGk6IERpYWxvZ0FwaSA9IHtcclxuICBhc3luYyBjb25maXJtKG9wdGlvbnMpIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHN3YWwuZmlyZSh7XHJcbiAgICAgIHRpdGxlOiBvcHRpb25zLnRpdGxlID8/IFwiQ29uZmlybWFyXCIsXHJcbiAgICAgIHRleHQ6IG9wdGlvbnMubWVzc2FnZSxcclxuICAgICAgaWNvbjogb3B0aW9ucy5kYW5nZXIgPyBcIndhcm5pbmdcIiA6IFwicXVlc3Rpb25cIixcclxuICAgICAgc2hvd0NhbmNlbEJ1dHRvbjogdHJ1ZSxcclxuICAgICAgY29uZmlybUJ1dHRvblRleHQ6IG9wdGlvbnMuY29uZmlybUxhYmVsID8/IFwiQ29uZmlybWFyXCIsXHJcbiAgICAgIGNhbmNlbEJ1dHRvblRleHQ6IG9wdGlvbnMuY2FuY2VsTGFiZWwgPz8gXCJDYW5jZWxhclwiLFxyXG4gICAgICBjdXN0b21DbGFzczoge1xyXG4gICAgICAgIC4uLnN3YWxDbGFzc2VzLFxyXG4gICAgICAgIGNvbmZpcm1CdXR0b246IG9wdGlvbnMuZGFuZ2VyID8gXCJidG4tZGFuZ2VyXCIgOiBcImJ0bi1wcmltYXJ5XCIsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICAgIHJldHVybiByZXN1bHQuaXNDb25maXJtZWQ7XHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgcHJvbXB0KG9wdGlvbnMpIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHN3YWwuZmlyZSh7XHJcbiAgICAgIHRpdGxlOiBvcHRpb25zLnRpdGxlID8/IFwiSW5mb3JtZSB1bSB2YWxvclwiLFxyXG4gICAgICB0ZXh0OiBvcHRpb25zLm1lc3NhZ2UsXHJcbiAgICAgIGlucHV0OiBcInRleHRcIixcclxuICAgICAgaW5wdXRMYWJlbDogb3B0aW9ucy5sYWJlbCxcclxuICAgICAgaW5wdXRWYWx1ZTogb3B0aW9ucy5kZWZhdWx0VmFsdWUgPz8gXCJcIixcclxuICAgICAgaW5wdXRQbGFjZWhvbGRlcjogb3B0aW9ucy5wbGFjZWhvbGRlcixcclxuICAgICAgaW5wdXRBdHRyaWJ1dGVzOiB7XHJcbiAgICAgICAgaW5wdXRtb2RlOiBvcHRpb25zLmlucHV0TW9kZSA/PyBcInRleHRcIixcclxuICAgICAgICBhdXRvY2FwaXRhbGl6ZTogXCJvZmZcIixcclxuICAgICAgfSxcclxuICAgICAgc2hvd0NhbmNlbEJ1dHRvbjogdHJ1ZSxcclxuICAgICAgY29uZmlybUJ1dHRvblRleHQ6IG9wdGlvbnMuY29uZmlybUxhYmVsID8/IFwiQ29uZmlybWFyXCIsXHJcbiAgICAgIGNhbmNlbEJ1dHRvblRleHQ6IG9wdGlvbnMuY2FuY2VsTGFiZWwgPz8gXCJDYW5jZWxhclwiLFxyXG4gICAgfSk7XHJcbiAgICAvLyBDb25maXJtYXIgZGV2b2x2ZSBvIHRleHRvIChtZXNtbyB2YXppbyk7IENhbmNlbGFyL0VzYy9mb3JhIGRldm9sdmUgbnVsbC5cclxuICAgIGlmICghcmVzdWx0LmlzQ29uZmlybWVkKSByZXR1cm4gbnVsbDtcclxuICAgIHJldHVybiAocmVzdWx0LnZhbHVlIGFzIHN0cmluZyB8IHVuZGVmaW5lZCkgPz8gXCJcIjtcclxuICB9LFxyXG59O1xyXG5cclxuLyoqXHJcbiAqIE8gU3dlZXRBbGVydDIgZ2VyZW5jaWEgc2V1IHByw7NwcmlvIG92ZXJsYXkvcG9ydGFsIGZvcmEgZGEgw6Fydm9yZSBkbyBSZWFjdFxyXG4gKiAoZm9jbyBwcmVzbywgRXNjLCByZXRvcm5vIGRlIGZvY28g4oCUIHR1ZG8gbmF0aXZvKSwgZW50w6NvIG7Do28gcHJlY2lzYSBtYWlzIGRlXHJcbiAqIGVzdGFkbyBSZWFjdCBuZW0gZGUgPE1vZGFsPi4gTWFudGlkbyBjb21vIHBhc3N0aHJvdWdoIHPDsyBwYXJhIG7Do28gcXVlYnJhclxyXG4gKiBxdWVtIGFpbmRhIG1vbnRhIDxEaWFsb2dQcm92aWRlcj4gZW0gbWFpbi50c3guXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gRGlhbG9nUHJvdmlkZXIoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdE5vZGUgfSkge1xyXG4gIHJldHVybiA8PntjaGlsZHJlbn08Lz47XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1c2VEaWFsb2coKTogRGlhbG9nQXBpIHtcclxuICByZXR1cm4gZGlhbG9nQXBpO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQU1EL3NvdXJjZS9yZXBvcy9TeW5jQmFyL2Zyb250ZW5kL3NyYy91aS9EaWFsb2cudHN4In0=